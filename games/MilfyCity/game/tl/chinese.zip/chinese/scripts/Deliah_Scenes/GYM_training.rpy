﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/GYM_training.rpy:67
translate chinese GYM_clothes_scene_54cd6c71:

    # MC "Let's see if I have suitable gym clothes."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:72
translate chinese GYM_clothes_scene_1b348d5c:

    # MC "No, that's not it. "
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:73
translate chinese GYM_clothes_scene_5b5b2d9d:

    # MC "Hmm... It looks good, but it's too small for me."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:74
translate chinese GYM_clothes_scene_6e52f37d:

    # MC "Ah! This one looks good."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:85
translate chinese GYM_training_4e218847:

    # MC "(I don't need to work out now.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:100
translate chinese GYM_training_37a7118e:

    # Chad "HNNNGGG!!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:101
translate chinese GYM_training_ec4c8aaf:

    # MC "Um, hey there, I was... uh... I was looking to join the gym."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:102
translate chinese GYM_training_cf08e474:

    # MC "(Jesus Christ, this guy’s biceps are bigger than Caroline’s breasts!)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:106
translate chinese GYM_training_98474c20:

    # Chad "AARRGGHHHH!!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:107
translate chinese GYM_training_dbd880fa:

    # MC "Um, I’m just... uh... I’ll ask someone else."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:108
translate chinese GYM_training_24b9b7f7:

    # Chad "So... you want to join my gym?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:112
translate chinese GYM_training_b9b402a9:

    # MC "Uh, if you’d asked me sixty seconds ago I would have probably said yes. Right now, I’m not so sure though."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:113
translate chinese GYM_training_9c9d41da:

    # Chad "HMMMMMM!!!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:114
translate chinese GYM_training_597fee4c:

    # MC "(What the fuck?)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:118
translate chinese GYM_training_51ecb466:

    # Chad "Well, the name’s Chad. Chad Bigkokski. I run this place. I own this place. And ever since my husband kicked me out, I LIVE in this place!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:121
translate chinese GYM_training_b10ee970:

    # MC "Oh, you’re gay?"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:122
translate chinese GYM_training_8e1e3aca:

    # Chad "No! I just married a man because I knew a woman would just distract me from my training with sex!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:123
translate chinese GYM_training_b8281ee6:

    # MC "...what?"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:124
translate chinese GYM_training_60cdb4c8:

    # Chad "So, do you wanna be a part of this gym or not?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:125
translate chinese GYM_training_a02d4888:

    # MC "I guess so?"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:126
translate chinese GYM_training_827fd93a:

    # Chad "Joining is the easy part! Getting out of our convoluted subscription-based customer retention model is the hard part!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:127
translate chinese GYM_training_db5b80a8:

    # MC "Uh huh. So, can I join?"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:131
translate chinese GYM_training_6c100c1a:

    # Chad "HAARRRGGGHHHH!! No."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:132
translate chinese GYM_training_7049a77d:

    # MC "What? You literally just said joining was easy!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:136
translate chinese GYM_training_823416ec:

    # Chad "Do you really think I’m going to let you train on my machines when you’re dressed like a generic protagonist from some hentai game?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:137
translate chinese GYM_training_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:138
translate chinese GYM_training_5ae17914:

    # Chad "Come back when you get yourself some proper gym clothes!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:142
translate chinese GYM_training_24ab9272:

    # MC "*Sigh* Fine, I’ll go and get some proper clothes then."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:143
translate chinese GYM_training_997b0bc8:

    # MC "(Christ almighty, this guy’s a dickhead.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:144
translate chinese GYM_training_d4022f26:

    # Chad "(Alluahh give me strength! This boy’s a dickhead.)"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:164
translate chinese GYM_training_ca1f5c41:

    # Chad "If you want to start the training, change your clothes first. The locker room is at the end of the gym. White doors."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:177
translate chinese GYM_training_51446cf3:

    # MC "Well, that’s me properly dressed!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:178
translate chinese GYM_training_49929224:

    # Chad "Lookin’ sharp, pal! Welcome to my gym! We’ll sort the contract stuff out later."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:179
translate chinese GYM_training_7fb1ae90:

    # Chad "So, what brings you here?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:183
translate chinese GYM_training_fe801588:

    # Chad "You looking to get strong? Build some muscle?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:187
translate chinese GYM_training_c316a815:

    # Chad "Learn some fightin’ moves!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:191
translate chinese GYM_training_fb78fee8:

    # Chad "Or just simply get fuckin’ SWOLE!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:192
translate chinese GYM_training_dd56bf2b:

    # MC "I’m just looking to get fit, actually. This girl and I are having a bet on who can swim faster, and I’m REALLY not in shape for it."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:193
translate chinese GYM_training_7c269063:

    # Chad "Ah, it’s about a girl then. She hot? You like her? You wanna get yourself strong to prove to her how amazing you are?!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:194
translate chinese GYM_training_78a04884:

    # MC "Like her?! Ha! You must be joking! She’s an arrogant, self-absorbed bullying bitch! I want to take her down a peg or two!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:195
translate chinese GYM_training_0219fcf1:

    # MC "Gotta admit, she IS hot though."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:199
translate chinese GYM_training_bf595728:

    # Chad "Well, in that case, what are we waiting for?! Let’s get you over to those weights and start putting some meat on those bones!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:200
translate chinese GYM_training_d3429cb3:

    # Chad "Can I get a “HELL YEAH”?!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:201
translate chinese GYM_training_5ef50361:

    # MC "HELL YEAH!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:205
translate chinese GYM_training_27ddd408:

    # Chad "Alright pal, let’s do this!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:206
translate chinese GYM_training_de0c748d:

    # MC "Where do I start?"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:207
translate chinese GYM_training_ccb93be4:

    # Chad "It doesn’t matter where you start. The only thing that matters is the destination."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:208
translate chinese GYM_training_8ddfc4b1:

    # MC "Okay, but I literally don’t know what any of these machines are."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:209
translate chinese GYM_training_9afba54e:

    # Chad "Ah, I can see that being a bit of a problem."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:225
translate chinese GYM_training_a2a5b9e9:

    # MC "(Darn, I don't have any gym clothes. If I remember correctly, I should have something in my room.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:233
translate chinese GYM_training_ca1f5c41_1:

    # Chad "If you want to start the training, change your clothes first. The locker room is at the end of the gym. White doors."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:248
translate chinese GYM_training_5477a073:

    # MC "(I've already talked with him.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:288
translate chinese locker_room_dd65a911:

    # MC "(I haven't done my training.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:314
translate chinese locker_room_f0c9e361:

    # MC "(Nothing interesting in there.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:383
translate chinese GYM_trainig_locker_room_dd65a911:

    # MC "(I haven't done my training.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:413
translate chinese GYM_training1_defa07e9:

    # MC "(I've already have done training on the treadmill.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:427
translate chinese GYM_training1_307c2615:

    # MC "(Alright, this one looks easy enough. It’s a treadmill, you just run on it, right?)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:431
translate chinese GYM_training1_5d9f83ae:

    # MC "(This is pretty easy. I should probably try turning up the speed a bit though if I want to have a hope of ever beating Delilah.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:435
translate chinese GYM_training1_d4e3ecd6:

    # "*Whirrr*"
    ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:437
translate chinese GYM_training1_460af725:

    # MC "That’s more like it!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:438
translate chinese GYM_training1_f578dda6:

    # MC "(Maybe just a little bit faster...)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:494
translate chinese GYM_training1_con_901e1d0e:

    # "*WHIIRRRRR*"
    ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:495
translate chinese GYM_training1_con_cfed7495:

    # MC "WHOA! SHIT!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:496
translate chinese GYM_training1_con_e8fb2ce0:

    # MC "Too fast! Too fast!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:497
translate chinese GYM_training1_con_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:514
translate chinese GYM_training2_debe7d90:

    # MC "(I've already have done training with dumbbells.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:522
translate chinese GYM_training2_550a8b9a:

    # MC "(It's enough for today.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:534
translate chinese GYM_training2_76c6e721:

    # MC "Hnnng... Ugh..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:535
translate chinese GYM_training2_4efd96f6:

    # MC "(Fuck, these things are heavier than I thought!)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:548
translate chinese GYM_training2_843b937f:

    # MC "(Alright, let’s try some weightlifting today. I really need to work on my upper body strength to beat Delilah.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:552
translate chinese GYM_training2_d4ff30ed:

    # MC "*Pant* Hnnnggg!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:553
translate chinese GYM_training2_89e1a67b:

    # MC "Arrggghh!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:557
translate chinese GYM_training2_39604a88:

    # Chad "How’s it goin’ pal?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:558
translate chinese GYM_training2_0ec65530:

    # MC "*Pant* Good, I’m *Pant* just working on my arms here."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:559
translate chinese GYM_training2_587eabc6:

    # Chad "I wasn’t talkin’ about the weights, pal. How’s the girl?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:560
translate chinese GYM_training2_f4226066:

    # MC "Oh, right. *Pant* Yeah, she’s a complete piece of shit. An absolute arrogant asshole."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:564
translate chinese GYM_training2_f5fea751:

    # Chad "Did yeh beat her though?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:565
translate chinese GYM_training2_4577fded:

    # MC "Oh yeah! She lost the *Pant* bet and I made her walk topless down the corridor."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:566
translate chinese GYM_training2_3d45c389:

    # Chad "Heh! Nice one! That’ll take her down a peg or two."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:570
translate chinese GYM_training2_5da040ed:

    # MC "You’d *Ugh* think so, right? *Pant* Unfortunately, it only seemed to - arrgh - make her worse! She and her cronies are *Pant* bullying a bunch of nerds on campus right now."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:571
translate chinese GYM_training2_a2bfe9fb:

    # Chad "Fuck me, sounds bad."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:572
translate chinese GYM_training2_a5c8f981:

    # MC "I know. So, *Pant*, we made another bet. If I win this time, then she has to give me a blowjob."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:573
translate chinese GYM_training2_e0b9094e:

    # Chad "Well, in that case you better get pumping. Let’s see another thirty lifts!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:574
translate chinese GYM_training2_a0bdb3da:

    # MC "Ha! *Pant* You gotta be joking!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:578
translate chinese GYM_training2_fde02d7e:

    # Chad "I’m serious, I’ll count you. One!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:579
translate chinese GYM_training2_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:580
translate chinese GYM_training2_803081a7:

    # Chad "Two!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:581
translate chinese GYM_training2_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:582
translate chinese GYM_training2_01db544a:

    # Chad "Three! PUSH THROUGH THE BURN!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:592
translate chinese GYM_training2_con_d8860b5b:

    # Chad "Aaaaaannnd... THIRTY!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:593
translate chinese GYM_training2_con_ea14f313:

    # MC "*PANT* *WHEEZE*"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:594
translate chinese GYM_training2_con_26083156:

    # Chad "Fuckin’ nailed it, pal. Nice job! Now, when she’s down on her knees sucking your cock, I want you to remember me - I’m the guy who got you there."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:595
translate chinese GYM_training2_con_2d05aefe:

    # MC "*Pant* I’d rather not..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:612
translate chinese GYM_training3_e2378ba7:

    # MC "(I've already have done training on the exercise bench.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:620
translate chinese GYM_training3_550a8b9a:

    # MC "(It's enough for today.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:632
translate chinese GYM_training3_76c6e721:

    # MC "Hnnng... Ugh..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:633
translate chinese GYM_training3_b86193bb:

    # MC "(It's too heavy. Let's try something easier.)"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:646
translate chinese GYM_training3_e29d71c1:

    # Chad "Hey pal, how’s it going? You get your dick sucked?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:647
translate chinese GYM_training3_97c0677d:

    # MC "*Pant* Yeah, big success there. She challenged me to a third bet though straight after."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:648
translate chinese GYM_training3_1016e0b5:

    # Chad "Oh, and how’d that go down?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:652
translate chinese GYM_training3_3f68be2f:

    # MC "I fucking lost!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:653
translate chinese GYM_training3_3afeeb11:

    # Chad "Ooof. Big L + Ratio. I’m almost afraid to ask, but what’d she make you do, pal?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:654
translate chinese GYM_training3_45523cbd:

    # MC "Made me come over to her house and cook her dinner."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:658
translate chinese GYM_training3_e36f16c5:

    # Chad "Huh?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:659
translate chinese GYM_training3_8658e774:

    # MC "Ugh! And give her a massage too! Argh! And make her some tea!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:660
translate chinese GYM_training3_422782a8:

    # Chad "That’s... uh... That’s pretty tame. She didn’t try to, like, make you eat her pussy or anything to get revenge for the blowjob?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:664
translate chinese GYM_training3_46259de9:

    # MC "*Pant* No... Wait, yeah! *Pant* Yeah, she did. Only after her friends goaded her on though."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:665
translate chinese GYM_training3_2cfa75b0:

    # Chad "Her friends were there too? Keep your head back on the bench, pal. That’s better."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:666
translate chinese GYM_training3_5c89ae77:

    # MC "Nah, they ugh... were just on the phone."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:670
translate chinese GYM_training3_90935728:

    # Chad "Man, I think this girl likes you."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:671
translate chinese GYM_training3_71a30dcb:

    # MC "Ha! You’ve gotta ugh... be joking. I mean... the thought did cross *Pant* my mind a bit."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:672
translate chinese GYM_training3_9566390e:

    # Chad "I’m serious, man. What do you get if you win this bet?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:673
translate chinese GYM_training3_fc87dfda:

    # MC "*Pant* She’s gonna let me fuck her."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:674
translate chinese GYM_training3_7ecd31e0:

    # Chad "Do it! Win the bet, show her a real good time, then ask her out on a date! Now lift!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:678
translate chinese GYM_training3_89e1a67b:

    # MC "Arrggghh!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:679
translate chinese GYM_training3_ded50d07:

    # Chad "You can do it, pal! Higher!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:680
translate chinese GYM_training3_57b098d7:

    # MC "Hnnngg!!!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:681
translate chinese GYM_training3_b2710f91:

    # Chad "C’mon pal! Show me you got the strength to push through this!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:685
translate chinese GYM_training3_ab6e4aa2:

    # MC "*Pant* *PANT* I... I can’t..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:686
translate chinese GYM_training3_7196d4c7:

    # Chad "Don’t you fucking give up on me, pal. That girl brought you over to her place for a reason. She wanted some home cooked gourmet food and a massage."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:687
translate chinese GYM_training3_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:688
translate chinese GYM_training3_29521bf5:

    # Chad "You told me yourself she didn’t try to do anything sexual until her friends egged her on."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:689
translate chinese GYM_training3_6ab7a737:

    # MC "*Pant* Hnngg!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:690
translate chinese GYM_training3_1d78f7e6:

    # Chad "Do you think she’s happy right now, having her life dictated to her by peer pressure?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:694
translate chinese GYM_training3_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:695
translate chinese GYM_training3_4b87d460:

    # Chad "She almost let her guard down around you, pal! You gotta break through to this girl."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:696
translate chinese GYM_training3_dff704b9:

    # MC "Hnnnggg!!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:697
translate chinese GYM_training3_eaf80c26:

    # Chad "If you aren’t strong enough to lift this bar, then you aren’t strong enough to beat her in a race."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:698
translate chinese GYM_training3_f5db5acf:

    # MC "Aaarrgghhh! *PANT* HNNNNGG!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:699
translate chinese GYM_training3_0e1792ad:

    # Chad "And if you aren’t strong enough to beat her in a race, then you aren’t strong enough to save her from whatever hellish social clique she’s trapped in."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:700
translate chinese GYM_training3_a6c270b5:

    # Chad "So fucking do it, pal! Pump that iron! Claim your prize! Ask her out to dinner!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:701
translate chinese GYM_training3_5423c515:

    # MC "Arrrgghhhh..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:710
translate chinese GYM_training3_con_8ecee55a:

    # MC "AAAAHHHH!!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:711
translate chinese GYM_training3_con_fd3918d6:

    # Chad "Yes! YES! You’ve got the strength in you, pal! I KNEW you had it in you!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:712
translate chinese GYM_training3_con_0876bb3c:

    # Chad "Now, go and save that girl!"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:734
translate chinese De_gym_end_bonus_98f4f471:

    # Chad "Hey, pal! I didn’t think I’d be seeing you again. "
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:736
translate chinese De_gym_end_bonus_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:740
translate chinese De_gym_end_bonus_bb76094e:

    # Chad "How’d your date with the lady go? Are you two going steady now?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:744
translate chinese De_gym_end_bonus_dc104c22:

    # MC "She said no."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:746
translate chinese De_gym_end_bonus_e36f16c5:

    # Chad "Huh?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:748
translate chinese De_gym_end_bonus_215b9d80:

    # MC "She rejected me. I won the bet. We had sex. I asked her out on a date, and she told me to leave."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:752
translate chinese De_gym_end_bonus_2388bc97:

    # Chad "*Sigh* I’m sorry, pal."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:754
translate chinese De_gym_end_bonus_b4dd4108:

    # MC "You told me that the only thing that mattered is the destination. Well, look at where I am now! "
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:756
translate chinese De_gym_end_bonus_72399f5d:

    # MC "Delilah is fucking gone! No one has seen her around campus! I’ve heard rumours her dad may have helped her move to another place to study!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:758
translate chinese De_gym_end_bonus_a446080f:

    # MC "Some fucking destination this is!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:760
translate chinese De_gym_end_bonus_57a7989a:

    # Chad "*Sigh* I was wrong, pal."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:764
translate chinese De_gym_end_bonus_bf62d6e0:

    # Chad "The truth is, there are very few happy destinations in life. The terminal point for most living things is death and decay."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:766
translate chinese De_gym_end_bonus_c4dcfa8f:

    # MC "WHAT?!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:770
translate chinese De_gym_end_bonus_0a66189a:

    # Chad "Nothing lasts forever, pal. Your first love? Your pet dog? Even your parents? Everything must pass, and it’s rarely a happy occasion when it happens."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:774
translate chinese De_gym_end_bonus_72711e65:

    # MC "Then what’s the fucking point to any of it if the ending is just dark and depressing?!"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:778
translate chinese De_gym_end_bonus_d289b6ee:

    # Chad "Because life’s not about where you end up. The default state of the journey IS dark and depressing, pal. It’s about finding little moments of happiness to illuminate the inevitable journey that makes it worthwhile."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:780
translate chinese De_gym_end_bonus_d7840482:

    # Chad "From what you’ve told me, you had fun with this girl. Training to beat her in races gave you some purpose. For a while, she lit up the dark path you walked like a vibrant lantern."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:784
translate chinese De_gym_end_bonus_6dbb7382:

    # MC "She did..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:788
translate chinese De_gym_end_bonus_f7e67282:

    # Chad "But there’s more to it than that! "
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:790
translate chinese De_gym_end_bonus_539920a8:

    # Chad "Think about how Delilah treated you when you went over to her house. You told me that she had you cook for her, massage her."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:792
translate chinese De_gym_end_bonus_3dd8da9b:

    # MC "Yeah, she did."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:794
translate chinese De_gym_end_bonus_6669d73b:

    # Chad "In that moment, I truly believe Delilah got to experience a small spark of her own happiness herself. Maybe not a bright lantern like Delilah was to you, but - perhaps - a tiny little cinder on that dark, lonely road she walks on."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:798
translate chinese De_gym_end_bonus_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:800
translate chinese De_gym_end_bonus_7328d5ec:

    # MC "You told me I could save her if I was strong enough."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:804
translate chinese De_gym_end_bonus_e3725e35:

    # Chad "You asked her out, didn’t you?"
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:806
translate chinese De_gym_end_bonus_09edc4ca:

    # MC "Y-Yeah, but-"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:810
translate chinese De_gym_end_bonus_48237bc2:

    # Chad "Then you WERE strong enough, pal. You were strong enough to defy the dark road we all walk on. You chose to make yourself vulnerable and risk a genuine connection with another human being."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:812
translate chinese De_gym_end_bonus_25a5ef4a:

    # Chad "You reached out to her. SHE was the one who wasn’t strong enough, pal. Not you."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:814
translate chinese De_gym_end_bonus_22578536:

    # Chad "I suspect that there’s always going to be a small part of Delilah that will remember that small glowing ember from the time you shared at her place. After all, even a single small star stands out against the dark night sky."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:816
translate chinese De_gym_end_bonus_9ac3207a:

    # Chad "And, maybe someday, she’ll be brave enough to allow someone to light up her road. Until then, you did all you could, pal."
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:820
translate chinese De_gym_end_bonus_7a4e1862:

    # MC "*Sigh* I guess you’re right. Thanks, Chad... Thanks for everything."
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:824
translate chinese De_gym_end_bonus_f3564e4a:

    # Chad "Hey, [player_name]. "
    Chad ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:826
translate chinese De_gym_end_bonus_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/Deliah_Scenes/GYM_training.rpy:828
translate chinese De_gym_end_bonus_be1daf6f:

    # Chad "I’m proud of you... king."
    Chad ""

translate chinese strings:

    # game/scripts/Deliah_Scenes/GYM_training.rpy:258
    old "Change your clothes."
    new ""

