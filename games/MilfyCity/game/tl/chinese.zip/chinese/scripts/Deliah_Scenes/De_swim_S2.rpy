﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:133
translate chinese De_swim_S2_Lose_e4bcdd3e:

    # Delilah "Ha! What did I tell ya? My winning formula never fails me! Identify the weakness, train, and overcome!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:134
translate chinese De_swim_S2_Lose_ea42fdc6:

    # Delilah "You never had a chance, [player_name]. Once I put my mind and body to something, I ALWAYS achieve my goal."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:138
translate chinese De_swim_S2_Lose_b201c08c:

    # MC "(Arggh! I can’t believe I lost! How the hell did she get so much better so quickly?!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:139
translate chinese De_swim_S2_Lose_997ee1fa:

    # MC "Fine, you won fair and square. Let’s just get this over with."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:143
translate chinese De_swim_S2_Lose_4f38255f:

    # Delilah "As per our bet, you and I are going to have a little fun in front of my friends from the swim team."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:144
translate chinese De_swim_S2_Lose_04f6599e:

    # Delilah "First things first though, we need to round them up. That involves you..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:148
translate chinese De_swim_S2_Lose_cf8f73aa:

    # Delilah "...getting out of those."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:149
translate chinese De_swim_S2_Lose_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:150
translate chinese De_swim_S2_Lose_63e2ea64:

    # Delilah "C’mon, lose the shorts. Let’s see that tiny cock of yours that I’m going to humili-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:154
translate chinese De_swim_S2_Lose_70afce02:

    # Delilah "-wow!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:155
translate chinese De_swim_S2_Lose_d97dd3cb:

    # Delilah "(He’s MUCH bigger than I thought he would be! Thank God I didn’t lose! How would I even fit that MONSTER in my mouth?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:156
translate chinese De_swim_S2_Lose_90b4efc0:

    # MC "What? Cat got your tongue?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:160
translate chinese De_swim_S2_Lose_611dd770:

    # Delilah "I’m mature enough to admit when I’m wrong. You’re... bigger than I expected."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:161
translate chinese De_swim_S2_Lose_4aa88fbe:

    # MC "Pretty huge, right?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:162
translate chinese De_swim_S2_Lose_72f7b522:

    # Delilah "(That’s an understatement if I ever heard one.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:166
translate chinese De_swim_S2_Lose_765c252c:

    # Delilah "Eh, I’ve seen bigger. You’re WAY too arrogant for what’s about to happen."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:167
translate chinese De_swim_S2_Lose_18324277:

    # MC "C’mon! You were impressed! Admit it! How about you and me strip our clothes off and we just fuck out this little feud between us right here, right now?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:168
translate chinese De_swim_S2_Lose_61a8b7c6:

    # Delilah "You want to fuck me here? Right by the pool?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:169
translate chinese De_swim_S2_Lose_8a159ac6:

    # MC "Yeah! Why not? We put all these silly bets behind us and just pound it out. How does that sound?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:173
translate chinese De_swim_S2_Lose_229d10be:

    # Delilah "Hmm... Sure, why not?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:174
translate chinese De_swim_S2_Lose_1e81afbe:

    # MC "R-Really?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:175
translate chinese De_swim_S2_Lose_b5e8b3ef:

    # Delilah "Yeah, let me just slip into the changing rooms and I’ll take this swimsuit off."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:179
translate chinese De_swim_S2_Lose_a1e59b88:

    # MC "Oh, uh... sweet! Well, I’ll be... uh... I’ll be ready when you get back."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:180
translate chinese De_swim_S2_Lose_f6b40839:

    # Delilah "I’ll only be gone for a couple of minutes. Don’t start without me."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:191
translate chinese De_swim_S2_Lose_aaea4dbc:

    # MC "(I honestly wasn’t expecting that to work!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:192
translate chinese De_swim_S2_Lose_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:193
translate chinese De_swim_S2_Lose_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:194
translate chinese De_swim_S2_Lose_9d908fc0:

    # MC "(Hmm... She’s been gone for some time. How long does it take to get out of a swimsuit?)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:198
translate chinese De_swim_S2_Lose_ed045305:

    # MC "Hey, you’re back, what took you so lon-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:199
translate chinese De_swim_S2_Lose_15b50353:

    # MC "Oh."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:200
translate chinese De_swim_S2_Lose_25a08d46:

    # Delilah "Ahaha! Did you ACTUALLY think I was coming back to screw you? God, you’re SO gullible!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:204
translate chinese De_swim_S2_Lose_b5841da0:

    # Delilah "Alright, chin up. I Need to fasten this collar in place. You and I are going for a little walk together."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:205
translate chinese De_swim_S2_Lose_48ce6a96:

    # MC "(Fucking hell... This is going to be ten times worse than what I went through with Ms. Celia!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:206
translate chinese De_swim_S2_Lose_f5344be2:

    # Delilah "There we go. Good boy."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:210
translate chinese De_swim_S2_Lose_8f034c4e:

    # Delilah "Ahaha! You look adorable!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:211
translate chinese De_swim_S2_Lose_489b0c3f:

    # Delilah "Now, get down on your hands and knees. You’re my bitch today, and I’m gonna walk you like one."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:212
translate chinese De_swim_S2_Lose_eaaa2cd0:

    # MC "You’ve got a real sadist streak in you. D’you know that?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:213
translate chinese De_swim_S2_Lose_badf5650:

    # Delilah "Hands and knees. Now."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:217
translate chinese De_swim_S2_Lose_68354c72:

    # Delilah "See? That wasn’t too hard, was it? Good boy."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:218
translate chinese De_swim_S2_Lose_baa4f1cb:

    # MC "Ugh..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:219
translate chinese De_swim_S2_Lose_23cc6d0d:

    # MC "God, the floor is so cold!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:223
translate chinese De_swim_S2_Lose_a3fd8e21:

    # Delilah "Oh, don’t act like you’re not enjoying this! I can clearly see your cock is rock hard!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:224
translate chinese De_swim_S2_Lose_c1883124:

    # MC "Only because you came out in that slutty short skirt!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:225
translate chinese De_swim_S2_Lose_cca7f70e:

    # Delilah "Mmm, my friends are going to love watching you be my personal slave. Let’s introduce you to the rest of the swim team."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:231
translate chinese De_swim_S2_Lose_2ad09afb:

    # Delilah "*AHEM* Listen up! Some of you MAY have heard RUMOURS about me dressing inappropriately in the corridors."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:232
translate chinese De_swim_S2_Lose_52bf2867:

    # Delilah "As a result of those rumours, some of you IDIOTS thought you could slap my ass or grope my tits."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:233
translate chinese De_swim_S2_Lose_a8bb2547:

    # Delilah "Let this be a lesson to ALL of you. If ANYONE DARES to even THINK about disrespecting me on campus, then you’ll end up like this little BITCH here."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:237
translate chinese De_swim_S2_Lose_3bc07c98:

    # Delilah "Say “hello”, [player_name]."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:239
translate chinese De_swim_S2_Lose_eb8355fb:

    # MC "...hello..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:240
translate chinese De_swim_S2_Lose_67509eca:

    # Delilah "Now, tell them - all your nerdy friends - that you’re my bitch."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:244
translate chinese De_swim_S2_Lose_e86bbb6d:

    # MC "*Whispered* I... I’m... your... bitch..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:245
translate chinese De_swim_S2_Lose_1dd3ca19:

    # Delilah "I couldn’t hear you. Loudly and clearly please. And say my name."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:246
translate chinese De_swim_S2_Lose_09517e9a:

    # MC "I’m Delilah’s bitch..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:250
translate chinese De_swim_S2_Lose_11203647:

    # Delilah "Louder. Unless you want to make me have to force you to ejaculate in this corridor, right in front of everyone."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:251
translate chinese De_swim_S2_Lose_ea40c2fe:

    # Delilah "Imagine if Ms. Celia saw that. Or, God forbid, if Sara saw that."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:252
translate chinese De_swim_S2_Lose_528631e9:

    # MC "Grr..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:256
translate chinese De_swim_S2_Lose_4ac48a44:

    # MC "I am Delilah’s bitch!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:260
translate chinese De_swim_S2_Lose_42cf5af2:

    # NM "Oh no..."
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:261
translate chinese De_swim_S2_Lose_ab53aa85:

    # GM "I thought she was finished! But she’s come back, and it’s even worse than before!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:262
translate chinese De_swim_S2_Lose_8d904dc1:

    # DM "I know! It’s like that moment when the rebels find that second death star orbiting the planet Endor!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:263
translate chinese De_swim_S2_Lose_bf00bcb8:

    # NM "Actually, the death star was orbiting the Forest Moon of the planet Endor."
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:264
translate chinese De_swim_S2_Lose_988a07dc:

    # GM "The planet and the forest moon are both called Endor!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:265
translate chinese De_swim_S2_Lose_b1f82778:

    # DM "Yeah, because they’re all in the Endor SYSTEM! This has been clarified in the Expanded Universe guys!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:269
translate chinese De_swim_S2_Lose_427e488f:

    # Delilah "Will you all just shut the fuck up about StorWors?! No one gives a shit about your planet of tiny Wookies, or your “Star Destroyer” that is OBVIOUSLY badly named given that it destroys planets, not stars!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:270
translate chinese De_swim_S2_Lose_b2d28c53:

    # NM "Actually, they’re Ewoks... Not Wookies."
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:271
translate chinese De_swim_S2_Lose_a54a9c9d:

    # GM "And it’s a Death Star, not a Star Destroyer! The Star Destroyer was a type of capital ship used by the Galactic Empire across numerous classes."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:272
translate chinese De_swim_S2_Lose_ff63e1ab:

    # GM "It was capable of carrying an array of TIE class fighters and bombers which could be launched from hangars on the underbelly. Most notable examples of Star Destroyer classes included the Imperial Star Destroyer and the-"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:273
translate chinese De_swim_S2_Lose_c4dd8ab0:

    # Delilah "WHAT PART OF SHUT THE FUCK UP DON’T YOU UNDERSTAND?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:274
translate chinese De_swim_S2_Lose_0e741a38:

    # NM "Hold on! The Star Destroyer wasn’t just used by the Galactic Empire! The Galactic Republic first piloted it’s production in the-"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:278
translate chinese De_swim_S2_Lose_f76bb2a5:

    # Delilah "*Whispered* Look at this shit, [player_name]. Can you SEE the consequences of what happens when you damage MY reputation?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:279
translate chinese De_swim_S2_Lose_92cafb8b:

    # Delilah "*Whispered* Without ME acting as a moderating influence on these insufferable dorks, the entire campus is going to start sounding, looking, and SMELLING like an anime convention!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:280
translate chinese De_swim_S2_Lose_1d43ee42:

    # Delilah "*Whispered* This is why campuses need a strong figure that everyone respects and fears. We uphold authority and order."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:284
translate chinese De_swim_S2_Lose_ed20835d:

    # MC "Ahh, just like Emperor Palpatine?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:288
translate chinese De_swim_S2_Lose_b4fead46:

    # Delilah "Don’t you fucking start too!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:289
translate chinese De_swim_S2_Lose_965df879:

    # MC "*Choke* S-Sorry!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:293
translate chinese De_swim_S2_Lose_18a16fe9:

    # NM "The Venator WASN’T a Star Destroyer though!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:294
translate chinese De_swim_S2_Lose_da0741a0:

    # DM "Was too! I’m a moderator on Wookipedia!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:295
translate chinese De_swim_S2_Lose_53e58e64:

    # NM "Oh yeah? We'll I'm a Raddit mod on /r/StorWors!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:299
translate chinese De_swim_S2_Lose_706b2b72:

    # Delilah "When you’re lying on your deathbed, [player_name], and you’re ruminating about all your life’s regrets, just remember... It was YOU who caused this. You’re the one who allowed cringe to grow like a fungus on this campus."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:303
translate chinese De_swim_S2_Lose_d0fc90be:

    # Delilah "SWIM TEAM! Join me at the pool, for an exclusive show in two minutes!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:307
translate chinese De_swim_S2_Lose_9c4ccce2:

    # Delilah "C’mon bitch. Time for the grand finale."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:314
translate chinese De_swim_S2_Lose_3b8bd84f:

    # Delilah "Good to see you, ladies."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:315
translate chinese De_swim_S2_Lose_5a93d92e:

    # Blonde_Girl "OMG! It’s him! It’s the creep who asked Ms. Celia out on a date!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:316
translate chinese De_swim_S2_Lose_08618220:

    # Brunette_Girl "I didn’t believe it when I got your text, Dee! You ACTUALLY beat him in a rematch?!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:317
translate chinese De_swim_S2_Lose_3c656374:

    # Delilah "What? Did you think I was gonna lose to his wimpy ass again?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:318
translate chinese De_swim_S2_Lose_f231832b:

    # Brunette_Girl "Well, just after what happened last time when he made you walk topless aroun-"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:319
translate chinese De_swim_S2_Lose_f5d0e8e9:

    # Delilah "OKAY! New swim club rule! We don’t talk about what happened last time!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:323
translate chinese De_swim_S2_Lose_ed22d60b:

    # Blonde_Girl "Do you want us to record this, Dee?"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:324
translate chinese De_swim_S2_Lose_b6dae154:

    # Delilah "Nah, no cameras. I’ve already humiliated him publicly. This next part is for Swim Club’s eyes only."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:325
translate chinese De_swim_S2_Lose_bcc6e42b:

    # MC "(Well, at least I’m not going to be filmed. The last thing I need is someone seeing some videos or pictures of me with Delilah!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:329
translate chinese De_swim_S2_Lose_59781124:

    # Delilah "I hope you enjoy the show ladies. I’m about to make this pathetic little pervert cum while he’s being watched."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:330
translate chinese De_swim_S2_Lose_c723cd00:

    # MC "Pfft! As if! What makes you think I’m going to cum after you’ve spent the past twenty minutes treating me like shit?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:334
translate chinese De_swim_S2_Lose_f3b5320b:

    # Delilah "Isn’t it obvious? I think you enjoy being treated like a bitch."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:335
translate chinese De_swim_S2_Lose_66f4fe49:

    # Blonde_Girl "OOOHHHH!!!!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:336
translate chinese De_swim_S2_Lose_dd8ec388:

    # MC "No, I don-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:337
translate chinese De_swim_S2_Lose_b089e217:

    # Delilah "Your dick’s already standing at attention, and I haven’t even started yet."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:341
translate chinese De_swim_S2_Lose_80ebdcd9:

    # Delilah "I was considering using my hands to jerk you off, but the more I thought about it, I realised that it just wasn’t humiliating enough."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:342
translate chinese De_swim_S2_Lose_b53d2437:

    # MC "I’d be SUPER humiliated if you used your pussy right now."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:346
translate chinese De_swim_S2_Lose_13e57c0f:

    # Delilah "Still got that sarcastic streak in you? We’ll see how long that lasts once I begin."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:347
translate chinese De_swim_S2_Lose_e05b1432:

    # MC "W-Wait, you’re getting naked too?! "
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:348
translate chinese De_swim_S2_Lose_caf83ccf:

    # Delilah "Duh, it’s just the swim team. We get changed together every single day."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:352
translate chinese De_swim_S2_Lose_0526541d:

    # MC "Oh, right."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:353
translate chinese De_swim_S2_Lose_48326337:

    # Delilah "I’ve decided that I’m going to use my feet on your cock. What do you think, ladies, is this little creep going to have a foot fetish?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:357
translate chinese De_swim_S2_Lose_e699a380:

    # Asian_Girl "Oh, definitely. Just look at his cock! It twitched as soon as you suggested it."
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:358
translate chinese De_swim_S2_Lose_8a3df20a:

    # MC "No, it didn’t!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:359
translate chinese De_swim_S2_Lose_416fe2ba:

    # Blonde_Girl "It TOTALLY did!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:360
translate chinese De_swim_S2_Lose_c920f87b:

    # Delilah "Let’s see how long you can last against my feet, pervert."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:364
translate chinese De_swim_S2_Lose_482f930e:

    # Asian_Girl "Get him, Dee! Show him who’s boss!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:365
translate chinese De_swim_S2_Lose_852c1966:

    # MC "(Shit! There’s so many of her friends here. I can’t afford to show any weakness right now. I might still be able to talk my way out of complete and utter humiliation though.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:366
translate chinese De_swim_S2_Lose_4c1ff7ca:

    # MC "(If I can force myself to last until the lunch bell rings again, then Delilah is just going to look like an idiot who can’t make a guy cum. Heh! I got this in the bag.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:367
translate chinese De_swim_S2_Lose_e9ba4795:

    # MC "Pfft! There’s NO WAY you’re gonna make me cum with just your feet. When the lunch bell rings again in fifteen minutes, you’re gonna be standing there naked by the pool with nothing to show for it."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:371
translate chinese De_swim_S2_Lose_cea7a4fd:

    # Delilah "Ha! You ACTUALLY believe you’re gonna last fifteen minutes?! I’ll be surprised if you make it two!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:372
translate chinese De_swim_S2_Lose_f1a3bcff:

    # MC "What can I say? You’re gonna be surprised."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:373
translate chinese De_swim_S2_Lose_cffbab0d:

    # Delilah "You’re talking a pretty big game for someone whose dick is already as stiff as an iron bar."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:374
translate chinese De_swim_S2_Lose_505a368b:

    # Delilah "But, if you’re REALLY that cocky, then let’s see if..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:378
translate chinese De_swim_S2_Lose_2e67a557:

    # Delilah "...you can resist me using both my feet while staring at my pussy."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:379
translate chinese De_swim_S2_Lose_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:381
translate chinese De_swim_S2_Lose_59e2799b:

    # Delilah "How does that feel, [player_name]? Are you enjoying the sensation of my soft soles slipping up and down your shaft?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:383
translate chinese De_swim_S2_Lose_baa4f1cb_1:

    # MC "Ugh..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:385
translate chinese De_swim_S2_Lose_5b707f0f:

    # MC "(Deep breaths! Just focus on breathing, [player_name]. I can do this. I can do-)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:386
translate chinese De_swim_S2_Lose_f26b15f1:

    # Asian_Girl "Fourteen minutes until the end of lunch!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:390
translate chinese De_swim_S2_Lose_441bbee2:

    # Delilah "Haha! Oh my God! You’re leaking precum!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:392
translate chinese De_swim_S2_Lose_e312114c:

    # Brunette_Girl "He is! He is!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:393
translate chinese De_swim_S2_Lose_3c950ff8:

    # MC "Hnnng... N-No, I’m not! Her feet are just wet from the pool!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:394
translate chinese De_swim_S2_Lose_3f3e9d27:

    # Blonde_Girl "Yeah, he’s TOTALLY leaking right now! You’re such a horny little bitch, aren’t you?"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:400
translate chinese De_swim_S2_Lose_505020cb:

    # MC "(Crap! I can’t focus on resisting her feet AND block out her friends teasing me at the same time. God, why are their taunts turning me on so much?!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:402
translate chinese De_swim_S2_Lose_55deb897:

    # MC "H-Hey, this isn’t fair, Delilah! You’re only supposed to ugh... use your feet! Your friends are taunting me as well - and I can’t concentr-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:404
translate chinese De_swim_S2_Lose_2b55c663:

    # Delilah "Whoopsie! Looks like someone let the cat out of the bag. Does it make it harder for you to hold all your cum in when my friends bully you like that? Hehe!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:409
translate chinese De_swim_S2_Lose_e703784f:

    # MC "N-No! I didn’t mean- Hnnng!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:411
translate chinese De_swim_S2_Lose_6712a84e:

    # Delilah "I guess we found his weakness, ladies. Our little pervert here is getting off on being bullied. Give him the best you got while I take things up a notch."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:412
translate chinese De_swim_S2_Lose_6747ca01:

    # MC "(Oh fuck! I didn’t mean to let them know like that!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:413
translate chinese De_swim_S2_Lose_444a37ec:

    # MC "N-No, I’m not-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:417
translate chinese De_swim_S2_Lose_6162fd7e:

    # Blonde_Girl "Ahaha! You’re SO pathetic! Just look at you clenching your fists and trembling."
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:419
translate chinese De_swim_S2_Lose_7b09088f:

    # MC "*Pant* I’m n-not- I- Ooohhhh!!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:420
translate chinese De_swim_S2_Lose_58605081:

    # Brunette_Girl "Oh my God! You’re, like, totally moaning when she’s rubbing her feet over your dick."
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:422
translate chinese De_swim_S2_Lose_f7666ef5:

    # MC "I- *Gasp* Sh-Shut up! Hnnngg!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:428
translate chinese De_swim_S2_Lose_5759f86c:

    # Asian_Girl "Look how much he’s shivering each time her toes pass over his glans. We’re barely sixty seconds in, and he’s already falling apart."
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:429
translate chinese De_swim_S2_Lose_3fa24760:

    # MC "I’m... arrgh... n-not gonna cum!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:430
translate chinese De_swim_S2_Lose_87e7e85e:

    # Brunette_Girl "I bet he’s going to cum everywhere pretty soon. I mean, what kind of loser can’t even last a few minutes?"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:432
translate chinese De_swim_S2_Lose_8bd94f47:

    # MC "Ah! I’m n-not a loser! *Gasp* Ahmmmm!!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:433
translate chinese De_swim_S2_Lose_e9b20057:

    # Asian_Girl "You’re a total loser. A dweeb. And you’re going to blow all your cum over your belly for us. Do it!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:434
translate chinese De_swim_S2_Lose_f1909f19:

    # MC "(Why is it turning me on every time they insult me?! This doesn’t make any fucking sense!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:435
translate chinese De_swim_S2_Lose_8f9d7a94:

    # MC "No, I’m arrghhh... n-not a- I’m not a-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:436
translate chinese De_swim_S2_Lose_1036a97e:

    # Blonde_Girl "Loser. Haha!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:437
translate chinese De_swim_S2_Lose_83f6c1a6:

    # Brunette_Girl "You’re Delilah’s little bitch."
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:438
translate chinese De_swim_S2_Lose_05e10f92:

    # MC "N-No, I’m... *Gasp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:439
translate chinese De_swim_S2_Lose_4ec4ccee:

    # MC "(I’m already starting to get close. There’s no way I’m gonna make it till the lunch bell.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:443
translate chinese De_swim_S2_Lose_379cd0a1:

    # Asian_Girl "Three minutes down, twelve to go."
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:444
translate chinese De_swim_S2_Lose_78343765:

    # Delilah "Well, what do you know? You surprised me again, [player_name]. Three whole minutes."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:445
translate chinese De_swim_S2_Lose_dd79d41e:

    # Brunette_Girl "But that’s not even half as good as any of the guys I’ve ever been with."
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:446
translate chinese De_swim_S2_Lose_72d64b08:

    # MC "Really? All fifty of them?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:447
translate chinese De_swim_S2_Lose_58f9516b:

    # Brunette_Girl "Hey!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:451
translate chinese De_swim_S2_Lose_b85a9af2:

    # Delilah "Alright, you’re talking WAAAAY too much, [player_name]. Time to shut you up."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:452
translate chinese De_swim_S2_Lose_dc8026a8:

    # MC "W-Wait, what are you-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:456
translate chinese De_swim_S2_Lose_fe05fe77:

    # Asian_Girl "That’s it, Delilah! Sit on that little bitch’s face!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:457
translate chinese De_swim_S2_Lose_398a2435:

    # Blonde_Girl "Ride his face, Dee! You go girl!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:458
translate chinese De_swim_S2_Lose_1b1d4745:

    # MC "H-Hey, hold on!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:462
translate chinese De_swim_S2_Lose_3d7c3066:

    # MC "Wait, w- Mppfff!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:463
translate chinese De_swim_S2_Lose_d741bd05:

    # Delilah "Ah, much better. Your constant chatting was beginning to annoy me. Now you can enjoy the scent of my pussy while I finish stroking your cock."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:467
translate chinese De_swim_S2_Lose_1fb373a0:

    # MC "(She’s rubbing her pussy against my nose!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:468
translate chinese De_swim_S2_Lose_e9d151db:

    # Delilah "Mmm! Feels good, doesn’t it? I bet you LOVE the sensation of my feet stroking your cock while I grind my mmmmm... wet cunt all over your Ooohhh... face! Ah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:470
translate chinese De_swim_S2_Lose_67d43a90:

    # MC "Mmppff! Hmmm!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:474
translate chinese De_swim_S2_Lose_44dbaf08:

    # Delilah "C’mon! Hurry up and blow your load for us, [player_name]."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:475
translate chinese De_swim_S2_Lose_2e847f63:

    # Blonde_Girl "Yeah, we all want to see how pathetic you are, cumming in front of us like this."
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:476
translate chinese De_swim_S2_Lose_d919e550:

    # MC "(I can’t concentrate while she’s sitting on my face like this! God, her pussy smells intoxicating!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:480
translate chinese De_swim_S2_Lose_9a2d713f:

    # MC "Mmm! Hnnngg..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:481
translate chinese De_swim_S2_Lose_2f77b044:

    # Asian_Girl "It sounds like he’s getting close, Dee!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:482
translate chinese De_swim_S2_Lose_2392a13e:

    # Brunette_Girl "Keep going! Faster, Dee!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:484
translate chinese De_swim_S2_Lose_c772cada:

    # Delilah "Oh yeah, you mmm... like that, don’t you? You just LOVE being humiliated in public like this, don’t you?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:489
translate chinese De_swim_S2_Lose_77955858:

    # MC "No, I- nmmpff!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:490
translate chinese De_swim_S2_Lose_3a2eedde:

    # Delilah "Aww, did the little bitch try to say something there? Is my pussy getting in the way?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:491
translate chinese De_swim_S2_Lose_559a9e33:

    # Brunette_Girl "Ahaha!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:493
translate chinese De_swim_S2_Lose_3bf15d65:

    # Asian_Girl "Hehe!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:494
translate chinese De_swim_S2_Lose_1fbde82e:

    # MC "(Why am I still hard when they’re all laughing at me?! I bet Judy would have A LOT to say about this if she saw it.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:500
translate chinese De_swim_S2_Lose_e35e8505:

    # MC "Ugh! Ahh... Mmmmpff!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:501
translate chinese De_swim_S2_Lose_575c6e20:

    # MC "(I can’t even see her friends while she’s sitting on my face - but just KNOWING that they’re there, watching me, mocking me, is making me so horny!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:502
translate chinese De_swim_S2_Lose_165844c7:

    # MC "(I don’t think I can do it. My cock’s super sensitive, right now. I can feel myself getting close to the edge!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:503
translate chinese De_swim_S2_Lose_09f68279:

    # MC "Hnnnggg! Aahmmmmmm!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:507
translate chinese De_swim_S2_Lose_165b56d0:

    # Delilah "Ooohhh! That feels nice, keep moaning like that for me!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:508
translate chinese De_swim_S2_Lose_18e01f33:

    # Delilah "Now, I want you to finish, [player_name]. Blow your load while all my friends are watching you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:509
translate chinese De_swim_S2_Lose_0ea24c6b:

    # MC "Ugh! As... if...! I’m going to ugh... hold it in aahh... n-no matter what!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:510
translate chinese De_swim_S2_Lose_3a140317:

    # Delilah "I’m LITERALLY sitting on top of you! It’s OVER, [player_name]. I have the high ground!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:516
translate chinese De_swim_S2_Lose_f90eb62c:

    # MC "(Shit, I can’t hold on any longer! She’s gonna make me- No! No! Fuck! This is so humiliating!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:518
translate chinese De_swim_S2_Lose_0a0c5cd0:

    # Delilah "That’s it! I can feel your cock pulsating beneath the soles of my feet. You’re about to cum. Do it!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:519
translate chinese De_swim_S2_Lose_ca231d43:

    # Brunette_Girl "Yeah! Cum for us, you little bitch!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:525
translate chinese De_swim_S2_Lose_f1b4da38:

    # Asian_Girl "Cum! Cum! Cum!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:526
translate chinese De_swim_S2_Lose_5f9e774f:

    # Blonde_Girl "Cum! Cum! Cum!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:527
translate chinese De_swim_S2_Lose_64b1edf4:

    # MC "Ah! Ahhhnnnggg! HNNNGHGGGG! Noooo!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:528
translate chinese De_swim_S2_Lose_0107a85f:

    # Delilah "Woooo! Here it comes!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:538
translate chinese De_swim_S2_Lose_cf958fc7:

    # MC "Arrrgggghhhh!! HNNNGGG!! UGH!!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:539
translate chinese De_swim_S2_Lose_b0e85a53:

    # Delilah "Ahahaha! Yes! Cum for me!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:540
translate chinese De_swim_S2_Lose_ea3b137f:

    # MC "Uhghhh! Fuck! I’m cumming!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:541
translate chinese De_swim_S2_Lose_26344e83:

    # Delilah "WOW! That is A LOT! Haha!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:545
translate chinese De_swim_S2_Lose_92ea25e7:

    # Asian_Girl "Haha! What a loser!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:546
translate chinese De_swim_S2_Lose_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:547
translate chinese De_swim_S2_Lose_14510ed6:

    # Blonde_Girl "LOL! He didn’t even last ten minutes! No wonder he couldn’t even beat you at swimming - he can BARELY hold his own cum in!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:548
translate chinese De_swim_S2_Lose_75105734:

    # MC "*Pant* *Gasp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:549
translate chinese De_swim_S2_Lose_c0d2fa7e:

    # Brunette_Girl "Aww, look at him trembling there in his little dog collar. Isn’t he adorable? Ahaha!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:553
translate chinese De_swim_S2_Lose_9f303368:

    # Delilah "I warned you not to fuck with me, [player_name]. Maybe you’ll think twice before trying to tango with the Ice Queen of this campus."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:554
translate chinese De_swim_S2_Lose_976c65f3:

    # Asian_Girl "Oh snap!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:555
translate chinese De_swim_S2_Lose_83e722ae:

    # Blonde_Girl "Fr Fr. No cap."
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:556
translate chinese De_swim_S2_Lose_e7743f8e:

    # MC "*Pant* I’m not... *Pant* ...done with you... yet."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:578
translate chinese De_swim_S2_Lose_84c5a218:

    # MC "Hnngg... You... *Pant* aren’t gonna make me aahh... cum with your feet!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:582
translate chinese De_swim_S2_Lose_582230fc:

    # Delilah "Oh really? Am I not?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:584
translate chinese De_swim_S2_Lose_64b1edf4_1:

    # MC "Ah! Ahhhnnnggg! HNNNGHGGGG! Noooo!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:589
translate chinese De_swim_S2_Lose_8ed681e6:

    # Delilah "Well, in that case then, I guess I should just take you right to the very edge of an orgasm, and just give up."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:593
translate chinese De_swim_S2_Lose_04f23384:

    # MC "W-Wait, what?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:594
translate chinese De_swim_S2_Lose_6024bbb4:

    # MC "(Wh-What’s she doing?! This isn’t like Delilah at all. She NEVER gives up!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:598
translate chinese De_swim_S2_Lose_b1dbae8b:

    # Delilah "Oh, one last thing. I couldn’t help but notice how hard and horny you got, every time my girls insulted you. So I wanted to conduct a little experiment."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:599
translate chinese De_swim_S2_Lose_686ce607:

    # Delilah "Ladies, let him have it."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:600
translate chinese De_swim_S2_Lose_e5ab47ca:

    # Asian_Girl "Go on, cum for us loser!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:601
translate chinese De_swim_S2_Lose_cbdbd8bf:

    # MC "Hnng... N-No!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:602
translate chinese De_swim_S2_Lose_63d188d1:

    # Brunette_Girl "She never even needed to finish you off with her feet. You’d just as easily get off on us bullying you, wouldn’t you?"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:603
translate chinese De_swim_S2_Lose_d85decd8:

    # MC "*Pant* I- I- No, I don’t-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:604
translate chinese De_swim_S2_Lose_5a72b930:

    # Blonde_Girl "Aww, his dicks twitching because the girls are being mean to him! LOL!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:605
translate chinese De_swim_S2_Lose_bcf1d70d:

    # MC "(Shit! I'm in trouble! Why is my body giving in to their taunting so easily?!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:606
translate chinese De_swim_S2_Lose_42df1cff:

    # MC "I’m ugh... not-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:607
translate chinese De_swim_S2_Lose_378067e3:

    # Asian_Girl "Hehe! I know, just look at him in that little dog collar! Oh! Did you see his balls clench up?! He’s about to ejaculate!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:608
translate chinese De_swim_S2_Lose_8062a564:

    # Blonde_Girl "Ahahah!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:609
translate chinese De_swim_S2_Lose_897fa33b:

    # MC "Hnnng!! UGH! Arrghhh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:610
translate chinese De_swim_S2_Lose_ccfe0443:

    # MC "(Hold it together, [player_name], the lunch bell can’t be far off now!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:611
translate chinese De_swim_S2_Lose_a4a640b4:

    # Brunette_Girl "Finish him off, Dee!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:612
translate chinese De_swim_S2_Lose_cab8fcf3:

    # Delilah "It would be my pleasure, ladies."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:613
translate chinese De_swim_S2_Lose_6f6c559e:

    # Delilah "Cum for me you, little bitch."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:614
translate chinese De_swim_S2_Lose_6d7065ab:

    # MC "I- Ah-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:615
translate chinese De_swim_S2_Lose_908f624a:

    # Delilah "Do it."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:616
translate chinese De_swim_S2_Lose_be21adf9:

    # MC "HNNNNGG!! Ugghh! Fuck! I’m cumming!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:628
translate chinese De_swim_S2_Lose_74c39a52:

    # Blonde_Girl "Ahahaha!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:629
translate chinese De_swim_S2_Lose_5cddd177:

    # Asian_Girl "LOL! He actually came from that!"
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:630
translate chinese De_swim_S2_Lose_49362f10:

    # Brunette_Girl "OMG! I can’t believe that ACTUALLY happened!"
    Brunette_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:631
translate chinese De_swim_S2_Lose_ebd871e9:

    # Delilah "Wow. I knew you were a loser, but did you seriously just cum just because I told you to?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:632
translate chinese De_swim_S2_Lose_e60d01a3:

    # MC "I was... *Pant* I was already... on the edge after your footjob!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:633
translate chinese De_swim_S2_Lose_7b4e6358:

    # Delilah "Uh huh. Suuuure!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:634
translate chinese De_swim_S2_Lose_09b140ad:

    # Asian_Girl "Haha! And look at the time, he didn’t even make it CLOSE to the end of lunch. Let’s go and grab something from the cafeteria."
    Asian_Girl ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:638
translate chinese De_swim_S2_Lose_5ee2ff2e:

    # MC "(That was fucking awful... I can’t let her get away with that. I need to start training harder so I can get my revenge on her.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:662
translate chinese De_swim_S2_Win_97ceb3a1:

    # Delilah "I can’t believe this."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:663
translate chinese De_swim_S2_Win_7f6eea42:

    # MC "*Pant* You really *Pant* put up more of a fight this time, but *Pant* I edged you out at the end there!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:664
translate chinese De_swim_S2_Win_fee3fc0a:

    # MC "Awk, don’t look so glum! You tried hard, you really did!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:668
translate chinese De_swim_S2_Win_e99d9fd7:

    # MC "However, it’s time for you to honour that bet we made. How about we start with you getting out of that tight swimsuit?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:669
translate chinese De_swim_S2_Win_4ac73da7:

    # Delilah "Hmmp..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:670
translate chinese De_swim_S2_Win_95228b07:

    # MC "Oh, and you’ll have to show me where you keep that leash you were talking about. I’m really looking forward to slipping that collar round your neck."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:674
translate chinese De_swim_S2_Win_7588f5d0:

    # Delilah "I don’t suppose you and I can come to a more... PRIVATE arrangement between the two of us?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:675
translate chinese De_swim_S2_Win_725fb249:

    # MC "Really? Are you seriously thinking I will go along with ANYTHING you suggest after what you were going to do to me if I lost?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:676
translate chinese De_swim_S2_Win_4642704f:

    # Delilah "Are you sure? There’s lots of other things I could do for-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:677
translate chinese De_swim_S2_Win_26550f65:

    # MC "Hurry up and strip. We don’t have all day."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:681
translate chinese De_swim_S2_Win_a6d89d4b:

    # Delilah "Ugh, fine."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:682
translate chinese De_swim_S2_Win_bd052c37:

    # Delilah "(How the FUCK did this little twerp beat me again?! I’ve never even SEEN him using the pool before we started making these bets!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:683
translate chinese De_swim_S2_Win_4345f7c5:

    # Delilah "(I mean, one day this guy shows up, cringes himself into the seventh circle of hell by asking out Ms. Celia, and NOW he’s got the swimming skills of a freaking sports jock?! What the fuck is going on?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:692
translate chinese De_swim_S2_Win_93eecba6:

    # MC "(Her breasts aren’t the biggest, but they’re nice and perky! I’m gonna have fun playing with these later.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:693
translate chinese De_swim_S2_Win_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:694
translate chinese De_swim_S2_Win_3d246789:

    # Delilah "Pig."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:698
translate chinese De_swim_S2_Win_741b1862:

    # MC "Oh, c’mon, don’t be a sore loser, Delilah. You lost fair and square."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:699
translate chinese De_swim_S2_Win_7e7c0a20:

    # MC "(Just look at that pussy! It must be soooo tight! I’d love to shove my cock deep inside her and mess it up with a deep creampie.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:700
translate chinese De_swim_S2_Win_fcd08228:

    # Delilah "(How long is this creep just going to leer at me?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:701
translate chinese De_swim_S2_Win_fc9271fb:

    # Delilah "Well? Are you finished gawking?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:705
translate chinese De_swim_S2_Win_9f509416:

    # MC "Yeah, all done. Where do you keep that leash you were talking about?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:706
translate chinese De_swim_S2_Win_a94ae332:

    # Delilah "Uh... It’s at home. I don’t have it with me today."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:707
translate chinese De_swim_S2_Win_dfb88d00:

    # MC "Liar! You were planning to collar me with it if I lost! That means it’s here on campus."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:708
translate chinese De_swim_S2_Win_c4619de0:

    # Delilah "No, it’s-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:709
translate chinese De_swim_S2_Win_a59b4959:

    # MC "Oh wait, how stupid of me, it’s just going to be in your locker."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:710
translate chinese De_swim_S2_Win_5cd5176c:

    # Delilah "(Shit. I was kind of hoping he’d give up. He’s a relentless bastard, I have to give him credit for that.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:714
translate chinese De_swim_S2_Win_0cf0ffab:

    # MC "Which locker is yours?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:715
translate chinese De_swim_S2_Win_77044568:

    # Delilah "*Sigh* Third on the left."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:716
translate chinese De_swim_S2_Win_98009527:

    # MC "Stay right there Delilah, I’ll be back in a minute."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:723
translate chinese De_swim_S2_Win_ebe2db81:

    # MC "Here we go! You’re gonna look great in this."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:725
translate chinese De_swim_S2_Win_38618426:

    # "*DING-A-LING*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:726
translate chinese De_swim_S2_Win_eb6ea106:

    # Delilah "Oh God..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:727
translate chinese De_swim_S2_Win_4a8a6e35:

    # MC "And there’s the lunch bell. We're just in time to take you for a walk down the corridor. Can you hear that, Delilah? The sound of all that chatter and all those footsteps?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:728
translate chinese De_swim_S2_Win_ae9378ca:

    # MC "That’s the sound of ALL the people who are going to see you walked like a dog in front of them. Completely naked."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:729
translate chinese De_swim_S2_Win_06507680:

    # Delilah "Bastard."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:730
translate chinese De_swim_S2_Win_f16a41e7:

    # MC "On your knees please, I need to get this on."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:734
translate chinese De_swim_S2_Win_ebfa910f:

    # Delilah "You’re going to regret this, you know. You may THINK you’ve won, but I will be plotting something FAR worse for you, you piece of-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:735
translate chinese De_swim_S2_Win_4a1519f1:

    # MC "Uh huh, sure thing."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:736
translate chinese De_swim_S2_Win_ca288ca6:

    # Delilah "(My reputation is going to be in tatters after today. NOBODY is going to respect me anymore if they see me being dragged around on a leash by the weirdo who asked out his professor.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:740
translate chinese De_swim_S2_Win_ee800e92:

    # MC "Good girl. Just hold there till I clip it into place."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:741
translate chinese De_swim_S2_Win_93789d6b:

    # Delilah "You have no idea how much I hate you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:743
translate chinese De_swim_S2_Win_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:744
translate chinese De_swim_S2_Win_5f1db235:

    # MC "That seems to be in place now."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:748
translate chinese De_swim_S2_Win_6531f738:

    # MC "Hey! You’re looking good - it suits you!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:749
translate chinese De_swim_S2_Win_70ea0d13:

    # Delilah "Grrr..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:750
translate chinese De_swim_S2_Win_aafd73ed:

    # MC "You’re even growling like a bitch. I always respected method actors."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:751
translate chinese De_swim_S2_Win_e326fc91:

    # Delilah "Oh fuck y- *Choke*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:755
translate chinese De_swim_S2_Win_ef47c99f:

    # MC "C’mon! Time to go! Don’t want to miss the lunch time rush! There’s a LOT of horny guys on campus who are just dying to see what’s become of you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:756
translate chinese De_swim_S2_Win_e4220f34:

    # Delilah "How long are you planning on parading me around out there?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:760
translate chinese De_swim_S2_Win_36582e23:

    # MC "Oh, I don’t know. Maybe a few minutes, maybe half an hour. I’ll stop when I feel like you’ve learned your lesson."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:761
translate chinese De_swim_S2_Win_21f6df10:

    # Delilah "Oh yeah? And what lesson is that?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:762
translate chinese De_swim_S2_Win_1e7839e2:

    # MC "To stop being such a bitch to the guys on campus. You’ve been treating the nerds around here like shit."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:763
translate chinese De_swim_S2_Win_7c44c550:

    # Delilah "Well, duh, they are shi- *Choke*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:767
translate chinese De_swim_S2_Win_3c815752:

    # MC "That collar’s a bit tight when I tug on it, isn’t it? We’ll see if your cocky attitude changes after our walk."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:768
translate chinese De_swim_S2_Win_7d48ce48:

    # MC "Just imagine how it’s going to feel to have all your friends watching you, staring at your exposed pussy, snapping photos of your butt as you crawl across the floor."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:769
translate chinese De_swim_S2_Win_454d18f4:

    # Delilah "*Gulp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:770
translate chinese De_swim_S2_Win_6f4eaf7c:

    # MC "I reckon it’s going to be a pretty humbling experience for an arrogant bully like you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:771
translate chinese De_swim_S2_Win_acdf8b7c:

    # MC "Alright, let’s go."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:780
translate chinese De_swim_S2_Win_92d35734:

    # MC "Good afternoon everyone!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:781
translate chinese De_swim_S2_Win_145cb676:

    # DM "Oh my God! It’s Delilah again!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:782
translate chinese De_swim_S2_Win_cd4844ef:

    # NM "Look! [player_name]’s walking her like a dog!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:783
translate chinese De_swim_S2_Win_a31f8995:

    # GM "Haha!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:787
translate chinese De_swim_S2_Win_88ff363b:

    # DM "What’s going on, [player_name]?"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:788
translate chinese De_swim_S2_Win_35366611:

    # MC "Nothing much, I’m just taking my bitch for a walk. Don’t you have something to tell these fellas, Delilah?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:789
translate chinese De_swim_S2_Win_fce69340:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:793
translate chinese De_swim_S2_Win_e4a529a3:

    # MC "Well?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:794
translate chinese De_swim_S2_Win_9d04a6b0:

    # Delilah "(Oh God, I’m actually going to have to do this...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:795
translate chinese De_swim_S2_Win_0d76b6fe:

    # Delilah "*Weakly* I... I’m a... stupid *cough* slut who lost a bet..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:796
translate chinese De_swim_S2_Win_401cb0bc:

    # MC "And...?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:797
translate chinese De_swim_S2_Win_ae0d48fd:

    # Delilah "...and I have to reward [player_name] with a... blowjob. *Sigh* Come and watch me... *mumble mumble*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:798
translate chinese De_swim_S2_Win_6cd21281:

    # MC "Hmm? What was that last part? A bit louder please."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:799
translate chinese De_swim_S2_Win_406e14d4:

    # Delilah "...come and watch me... suck his... cock."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:804
translate chinese De_swim_S2_Win_b4154eb9:

    # NM "Haha! What?! Wait - is she serious, [player_name]?"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:805
translate chinese De_swim_S2_Win_6e77dd8f:

    # GM "Naw, [player_name] is just pulling a prank on us. He HAS to be, right?"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:806
translate chinese De_swim_S2_Win_b8ebd73d:

    # MC "Why don’t you all join me in the pool and find out for yourselves?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:807
translate chinese De_swim_S2_Win_fa1247e7:

    # DM "R-Really?!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:808
translate chinese De_swim_S2_Win_950c0385:

    # MC "This may be a once-in-a-lifetime opportunity to see the girl who has bullied you for years get thoroughly facefucked."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:809
translate chinese De_swim_S2_Win_a04da43f:

    # NM "What are we waiting for?! Let’s go!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:817
translate chinese De_swim_S2_Win_4a95bbc2:

    # DM "Haha! I can’t believe this is actually happening!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:818
translate chinese De_swim_S2_Win_a72a5e89:

    # GM "OMG! This is going to be WAY hotter than the stuff she posts on OnlySimps!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:819
translate chinese De_swim_S2_Win_056a2303:

    # NM "Wait... why are you subscribed to her OnlySimps? Delilah and the swim team LITERALLY pinned you against a wall and stole your study notes last week."
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:820
translate chinese De_swim_S2_Win_65d0b3b5:

    # GM "Uh, yeah, but they did it in a HOT way."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:821
translate chinese De_swim_S2_Win_1413766a:

    # MC "Let’s get started. How about you reach out and pull my cock out?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:827
translate chinese De_swim_S2_Win_33566df5:

    # MC "See? This isn’t so bad, is it?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:828
translate chinese De_swim_S2_Win_da90a364:

    # Delilah "*Whispered* Fuck you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:829
translate chinese De_swim_S2_Win_a4f9cee8:

    # MC "You’re the one who agreed to the bet, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:830
translate chinese De_swim_S2_Win_7b9be283:

    # Delilah "Screw you. Only my friends get to call me that."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:832
translate chinese De_swim_S2_Win_7e832b78:

    # MC "Sorry, would you prefer it if I called you ‘bitch’ instead?."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:836
translate chinese De_swim_S2_Win_e4936890:

    # DM "Hold on! Did you guys see that?"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:838
translate chinese De_swim_S2_Win_2b5f1f59:

    # GM "I know! She’s holding his cock!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:839
translate chinese De_swim_S2_Win_c439d162:

    # DM "No! [player_name]’s trousers just vanished!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:843
translate chinese De_swim_S2_Win_babcf2c5:

    # NM "Are you sure?"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:844
translate chinese De_swim_S2_Win_57ada5d7:

    # DM "Of course I’m sure! Look! Where are they? He was wearing them like ten seconds ago!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:845
translate chinese De_swim_S2_Win_73db3b76:

    # GM "I dunno, buddy. Seems to me like Delilah just took them off him."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:846
translate chinese De_swim_S2_Win_500fe71e:

    # DM "WHAT THE FUCK ARE YOU TALKING ABOUT?! I’m telling you! She touched his crotch and his pants just fucking VANISHED!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:847
translate chinese De_swim_S2_Win_7ecad000:

    # NM "Did you see it?"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:848
translate chinese De_swim_S2_Win_d32370be:

    # GM "I dunno what he’s talking about, I was looking at her tits. He probably just slipped out of them."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:849
translate chinese De_swim_S2_Win_e562e4c6:

    # DM "HOW DID HE SLIP OUT OF HIS TROUSERS?! HE’S STILL WEARING HIS FUCKING SHOES! "
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:850
translate chinese De_swim_S2_Win_4db662d9:

    # NM "Eh, sounds to me like someone forgot their glasses. Ahaha!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:854
translate chinese De_swim_S2_Win_516261e9:

    # Delilah "*Whispered* You know I could just squeeze REALLY hard right now and put you in a whole world of pain."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:855
translate chinese De_swim_S2_Win_cbe1415c:

    # MC "*Whispered* Really? You want to assault me in front of three witnesses? Just take the L and suck the cock."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:856
translate chinese De_swim_S2_Win_eda2759d:

    # Delilah "*Sigh* Fine."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:860
translate chinese De_swim_S2_Win_41896fbf:

    # Delilah "*Whispered* But don’t you think for one single second that I am EVER going to forget this. I’m going to get my revenge on you and I will humiliate you ten times worse than what you did to me today."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:861
translate chinese De_swim_S2_Win_0f081d08:

    # Delilah "*Whispered* You’re a dead man walking, [player_name]."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:862
translate chinese De_swim_S2_Win_a2a14e86:

    # Delilah "*Whispered* I will make your encounter with Ms. Celia feel like a-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:866
translate chinese De_swim_S2_Win_160f1f52:

    # MC "Wow. You sure are talking a lot for someone who is supposed to have a dick in her mouth."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:867
translate chinese De_swim_S2_Win_f17c6b92:

    # MC "Oh, and you probably want to try and finish me off before the bell rings. There’s gonna be the male swim team arriving after lunch."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:868
translate chinese De_swim_S2_Win_26288113:

    # Delilah "(Oh shit! I forgot they had their practice today! It’s bad enough that the nerds are watching me right now, but I can’t afford to lose the respect of the guys who actually matter on campus!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:874
translate chinese De_swim_S2_Win_9b2bbd47:

    # MC "Mmm! That’s it. Stroke my cock like that."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:875
translate chinese De_swim_S2_Win_17a861f0:

    # NM "(God, I wish that was me. I’d cum in like five seconds if she touched me there.)"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:876
translate chinese De_swim_S2_Win_5a0b7d9d:

    # GM "(I don’t think I’m gonna need that OnlySimps subscription anymore. I’ll just fantasise about this every night.)"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:877
translate chinese De_swim_S2_Win_9b21d927:

    # DM "(Perhaps I blinked for a few seconds without realising it, his trousers could have slipped off, and then maybe been knocked into the pool by accident. That would explain why they suddenly disappeared.)"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:881
translate chinese De_swim_S2_Win_b3f968d0:

    # MC "Alright, if you’re going to be sucking my dick, then you don’t need to have this leash attached."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:882
translate chinese De_swim_S2_Win_c52a25f5:

    # MC "You said you’ve never given a blowjob before, didn’t you Delilah?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:883
translate chinese De_swim_S2_Win_f915921d:

    # Delilah "No, of course not! I’m not some harlot that sucks guys cocks for-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:887
translate chinese De_swim_S2_Win_3f1d68e5:

    # Delilah "*GLOMPPFFF!*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:889
translate chinese De_swim_S2_Win_83cd1078:

    # MC "Mmmm! Ohh fuck! Your mouth feels really fucking good!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:890
translate chinese De_swim_S2_Win_10efdd74:

    # Delilah "(What the fuck?! He just grabbed my head and shoved his cock in!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:896
translate chinese De_swim_S2_Win_f758d6c4:

    # Delilah "Mppff! *Shlick* *Shlurp* Nmmpfff!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:898
translate chinese De_swim_S2_Win_5fb6582a:

    # MC "Ugh! Hnnng! Mmm! Oh yeah! That’s it."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:900
translate chinese De_swim_S2_Win_da3c878e:

    # GM "Wooo! Suck it! Haha!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:902
translate chinese De_swim_S2_Win_04920f30:

    # Delilah "(Ugh! I can’t believe he took my oral virginity in front of all these fucking nerds!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:909
translate chinese De_swim_S2_Win_38799a6e:

    # MC "Let’s see how deep I can get my cock into your face, Dee. Mmm!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:911
translate chinese De_swim_S2_Win_2d345748:

    # Delilah "*Shlurp* NMMPFFF!! *GAG* HMMMPFFF!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:913
translate chinese De_swim_S2_Win_5b241b4b:

    # MC "Ugh! Oh yeah! That’s it!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:917
translate chinese De_swim_S2_Win_306e5717:

    # Delilah "(I can feel his cock touching the back of my throat!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:919
translate chinese De_swim_S2_Win_4b164c6d:

    # Delilah "(He’s holding my head and fucking my face like I’m his own personal fleshlight. Why am I starting to get wet?! This shouldn’t be turning me on!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:921
translate chinese De_swim_S2_Win_145a7bbf:

    # MC "Hnnngg... Ooh yeah! Your throat is so fucking tight!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:922
translate chinese De_swim_S2_Win_d6982067:

    # Delilah "(I can’t believe I’ve never given head before. I thought it would be degrading and humiliating, but I’m... actually kinda enjoying this.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:925
translate chinese De_swim_S2_Win_7ecbf165:

    # Delilah "*Shlurrrp* *Suck* Mmmpff!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:927
translate chinese De_swim_S2_Win_8d651547:

    # Delilah "(Wait... what if the reason that I’m enjoying sucking his dick is BECAUSE he is degrading me right now?! No way! I can’t let myself enjoy this! Pull yourself together, Delilah!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:931
translate chinese De_swim_S2_Win_82bb0b11:

    # Delilah "Mmpff! *Shlick* Hmmpff! *Shluurrp* *Suck*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:933
translate chinese De_swim_S2_Win_55141775:

    # MC "Hnnng! Ugh! Mmm!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:934
translate chinese De_swim_S2_Win_954276bd:

    # Delilah "(I can feel his cock starting to throb against my tongue! Is [player_name] about to cum soon? I wonder what semen tastes like?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:935
translate chinese De_swim_S2_Win_ba8ce2f9:

    # MC "(I’m getting pretty close! Should I pull her head in close and flood her mouth with my cum? Or should I ask her to stick her tongue out and give her a facial?)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:943
translate chinese De_swim_S2_Win_9554877f:

    # Delilah "*SHLURP* *Suck* *Suuuuck* "
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:947
translate chinese De_swim_S2_Win_0917d90e:

    # MC "Hnnnggg! UGH! Fuck! I’m cumming!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:948
translate chinese De_swim_S2_Win_40ff84ff:

    # Delilah "(Wait, what?! Already?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:949
translate chinese De_swim_S2_Win_5ea49c9b:

    # Delilah "Nmmpff?! NNNMMMM!!! *GAG* *SHLURP*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:950
translate chinese De_swim_S2_Win_dcbc8a29:

    # MC "Aaarrrghhh! Ugh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:951
translate chinese De_swim_S2_Win_40f6cad3:

    # NM "Yeah! Fill her mouth!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:952
translate chinese De_swim_S2_Win_cf72587d:

    # DM "Make her swallow it! Haha!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:956
translate chinese De_swim_S2_Win_8bf227f4:

    # MC "Arrrghh! Hnnnng! Fuck!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:957
translate chinese De_swim_S2_Win_181ad053:

    # MC "(I can feel her cheeks clamping around my shaft. Fuck! This feels incredible!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:959
translate chinese De_swim_S2_Win_4f39bdf5:

    # MC "Here it comes, Delilah! Arrgh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:961
translate chinese De_swim_S2_Win_81cd26d1:

    # Delilah "HMMM?!! *Gulp* *Shlurp* Nmppfff!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:965
translate chinese De_swim_S2_Win_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:972
translate chinese De_swim_S2_Win_b15072cd:

    # Delilah "(Oh God! I can feel his dick pulsing in my mouth! And there’s something... hot flowing out. It’s salty... Is that what cum tastes like?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:976
translate chinese De_swim_S2_Win_2e6b6a7d:

    # Delilah "(I can’t believe he’s pumping his cum into my mouth in front of all these losers! This is so fucking embarrassing...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:980
translate chinese De_swim_S2_Win_e79eaed6:

    # MC "Hnnngg... *Pant* Oh... Fuck... That was good. C’mon, look up at me and open your mouth Delilah. Let’s see what you’ve got in there."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:984
translate chinese De_swim_S2_Win_018968cb:

    # Delilah "Aaah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:986
translate chinese De_swim_S2_Win_b26bb414:

    # MC "Mmm, looking hot. It’s nice to see you being a submissive, obedient slut for a change."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:987
translate chinese De_swim_S2_Win_5a5b28ef:

    # Delilah "(W-Wait, why did I comply with [player_name]’s order so readily?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:988
translate chinese De_swim_S2_Win_f08948f2:

    # GM "Wow! D’you think she’d let me cum in her mouth too?"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:989
translate chinese De_swim_S2_Win_18bb5ff7:

    # DM "You wouldn’t even make it past her giving you a handjob!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:990
translate chinese De_swim_S2_Win_1521597f:

    # NM "Ayy lmao!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:994
translate chinese De_swim_S2_Win_6fac785e:

    # MC "Well, that was fun, but I got places to be and things to do. I’ll catch you later Delilah."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:995
translate chinese De_swim_S2_Win_f691ac9d:

    # Delilah "W-Wait... that’s it? You just came in my mouth in front of everyone, and now you’re leaving?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:996
translate chinese De_swim_S2_Win_57c26748:

    # MC "That was the terms of our bet, wasn’t it? We’re done. You’re free to go."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1004
translate chinese De_swim_S2_Win_39f0503a:

    # Delilah "*Gasp* Ahh... *Pant*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1005
translate chinese De_swim_S2_Win_59186497:

    # MC "Y’know, you’re not a bad cocksucker for a stuck-up bitch. I could really get used to fucking that little mouth of yours more often."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1006
translate chinese De_swim_S2_Win_a4d23601:

    # Delilah "Hah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1007
translate chinese De_swim_S2_Win_3e03dee7:

    # Delilah "(Why does my face feel so hot? Am I blushing?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1008
translate chinese De_swim_S2_Win_de4a5ccf:

    # MC "You really devolve into a mindless bimbo when your dick gets pushed into your throat, don’t you?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1009
translate chinese De_swim_S2_Win_dfb91c33:

    # Delilah "*Pant* I... Ah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1010
translate chinese De_swim_S2_Win_717bbf61:

    # Delilah "(Why can’t I think of something witty to say back?! I’m SUPPOSED to be good at putting twerps like [player_name] back in their place.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1011
translate chinese De_swim_S2_Win_ac542d6b:

    # MC "Stick out your tongue for me. I want to see what’s caressing my shaft while I’m fucking your face."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1015
translate chinese De_swim_S2_Win_251cb02b:

    # Delilah "Ahh..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1016
translate chinese De_swim_S2_Win_c543955a:

    # Delilah "(Wait - what am I doing?! I didn’t even think to question him!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1017
translate chinese De_swim_S2_Win_1d6f7150:

    # NM "*Whispered* She isn’t even fighting back anymore!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1018
translate chinese De_swim_S2_Win_5d66787b:

    # GM "*Whispered* I know! What’s going on?!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1019
translate chinese De_swim_S2_Win_8f40ec9b:

    # DM "*Whispered* How are you guys using exclamation marks when you’re whispering? And why am I the only one who can break the fourth wall?"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1020
translate chinese De_swim_S2_Win_bfaefc42:

    # NM "*Whispered* I think she enjoys being dominated and told what to do."
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1021
translate chinese De_swim_S2_Win_fb4a4b11:

    # MC "Now, Delilah, I want you to take my cock in your mouth again and then I want you to start sucking it until I finish. Tell me ‘Yes, sir’ if you understand."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1022
translate chinese De_swim_S2_Win_1990b523:

    # Delilah "*Pant* Y-Yes... sir."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1026
translate chinese De_swim_S2_Win_2c70bc88:

    # Delilah "Mmm! *Shlurp* Mmm! *Suck Suck*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1027
translate chinese De_swim_S2_Win_6dd2a373:

    # MC "Oohh... That's it. Just like that. Ahh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1028
translate chinese De_swim_S2_Win_cd7b562c:

    # Delilah "Mmm... *Suck*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1032
translate chinese De_swim_S2_Win_e7b79b66:

    # MC "Try and take it deeper. I want to feel my dick slide down your throat."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1036
translate chinese De_swim_S2_Win_e5294871:

    # Delilah "Mppff *Suck* *Shluurrrp* *GAG*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1040
translate chinese De_swim_S2_Win_0078b1f2:

    # Delilah "(I can’t believe I’m just complying with everything he tells me to do. Why am I getting so turned on by him treating me like this?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1041
translate chinese De_swim_S2_Win_6eff0831:

    # MC "Hnnng! Just like that! I want to feel you twirling your tongue around it. Ah! Yes, exactly like that."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1043
translate chinese De_swim_S2_Win_60d23853:

    # Delilah "*Shlurp* Mmm! *Suck* *Suck* *Gag* SHLURRRRP*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1047
translate chinese De_swim_S2_Win_778b5b19:

    # MC "Ugh! Fuck! I’m about to cum."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1049
translate chinese De_swim_S2_Win_004a3a2e:

    # MC "Hnnngg! Aarghh! Yes!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1053
translate chinese De_swim_S2_Win_7707f2c7:

    # Delilah "Mppf! *SHLURP* *Gag* *Suck*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1055
translate chinese De_swim_S2_Win_cd7b562c_1:

    # Delilah "Mmm... *Suck*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1057
translate chinese De_swim_S2_Win_2e92c67d_1:

    # MC "Argh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1063
translate chinese De_swim_S2_Win_92b64f87:

    # Delilah "(I can feel his hot cum blasting over my tongue! It’s so salty!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1073
translate chinese De_swim_S2_Win_5b27bd52:

    # MC "Ohh... *Pant* That was amazing. Open wide for me, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1077
translate chinese De_swim_S2_Win_456fc8a9:

    # Delilah "Ahhh...."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1078
translate chinese De_swim_S2_Win_47ab10d5:

    # MC "Oh, fucking perfect. You look so sexy right now. Just think how popular you could actually be if you spent your time being a freeuse cumslut instead of bullying everyone."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1079
translate chinese De_swim_S2_Win_251cb02b_1:

    # Delilah "Ahh..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1080
translate chinese De_swim_S2_Win_6db12c45:

    # MC "Y’know, instead of pushing these fellas into lockers, or stealing their study notes, or whatever the fuck you do, you could be on your knees in the changing room serving them on lunch break."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1081
translate chinese De_swim_S2_Win_eaaab14d:

    # Delilah "(God... I can just imagine dragging one of them into the changing room, pulling down their pants, letting them fuck my face while I finger my pussy.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1082
translate chinese De_swim_S2_Win_f05d855a:

    # MC "Sure, they’re nerds and dorks - but you have the choice to be nice to these guys."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1083
translate chinese De_swim_S2_Win_dfe79526:

    # MC "You have the power to end this bullying. You have the power to bring this marginalised group of socially awkward virgins some pleasure instead of pain."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1084
translate chinese De_swim_S2_Win_8dbb1ece:

    # MC "You don’t have to denigrate them! You could be giving blowjobs in the library while they study! Or maybe even join them for Dungeons and Dragons! I’m sure they’d be able to lend you a sexy outfit to match whatever character they create for you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1085
translate chinese De_swim_S2_Win_bc78824c:

    # Delilah "(What if I went along to their game and they made me dress up in a bikini like a slutty elf. I’d be all alone with three men. Barely dressed. My skin is exposed. They’d all be leering at me.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1086
translate chinese De_swim_S2_Win_2d8678a4:

    # Delilah "(Maybe my character would get knocked down and the only way to convince them to save me would be if I climbed under the table and sucked each of their-)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1087
translate chinese De_swim_S2_Win_bf802114:

    # GM "ACKCHYUALLY, nobody is playing DnD anymore. We’re all doing Pathfinder as they engage with the community better and have better rules for my Level 14 Half-Elf Wizar-"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1088
translate chinese De_swim_S2_Win_4f908725:

    # MC "Oh my God, shut the fuck up you fucking nerd!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1089
translate chinese De_swim_S2_Win_dd821c20:

    # GM "Sorry..."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1090
translate chinese De_swim_S2_Win_8e003ea9:

    # Delilah "(Shit! What am I doing?! I’m letting my imagination run wild right now! Pull it together, Delilah! Why are you fantasising about having a blowbang with a bunch of nerds?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1091
translate chinese De_swim_S2_Win_1988aaff:

    # MC "Now Delilah, how about you swallow?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1092
translate chinese De_swim_S2_Win_cb5e610d:

    # Delilah "(Swallow? Does he actually think I’m going to drink his cum just because he told me t-)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1094
translate chinese De_swim_S2_Win_7a718669:

    # Delilah "Ahh... *Gulp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1098
translate chinese De_swim_S2_Win_5589e17a:

    # MC "That’s it. Good girl."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1099
translate chinese De_swim_S2_Win_9c707500:

    # Delilah "(My body is just acting on instinct right now! Why is it so tempting to just give in and be a slut?! Why can’t I show any restraint around [player_name]?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1103
translate chinese De_swim_S2_Win_143a5341:

    # MC "Well, that was fun, but I got places to be and things to do. I’ll catch you later Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1104
translate chinese De_swim_S2_Win_df0029f4:

    # Delilah "W-Wait... that’s it? You just had me swallow your cum and now you’re leaving?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1105
translate chinese De_swim_S2_Win_184de4c9:

    # MC "That was the terms of our bet. We’re done. You’re free to go."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1113
translate chinese De_swim_S2_Win_295fc94b:

    # MC "Mmm! Okay Delilah, open wide and stick out your tongue. I’m about to give you your first facial."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1114
translate chinese De_swim_S2_Win_f907f3f2:

    # Delilah "...aaah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1115
translate chinese De_swim_S2_Win_c7e2c56b:

    # Delilah "(Just because you lost a bet doesn’t mean you have to do EVERYTHING he says! Pull yourself together, Delilah! You’re still the ice-queen of the campus, not some common whore!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1125
translate chinese De_swim_S2_Win_1e7e82d3:

    # MC "Hnnnggg! Ugh! Fuck! Here it comes!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1126
translate chinese De_swim_S2_Win_6f4e6701:

    # Delilah "Aaah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1127
translate chinese De_swim_S2_Win_dab790c6:

    # Delilah "(Oh shit! That’s a lot of-)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1128
translate chinese De_swim_S2_Win_57bffb73:

    # MC "Ohh *Pant* That was fucking amazing. I honestly can’t believe you’ve never sucked a cock before. You’re a natural at it."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1129
translate chinese De_swim_S2_Win_29d9ab0c:

    # NM "She looked like a pro!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1130
translate chinese De_swim_S2_Win_a3727e89:

    # Delilah "*Pant*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1134
translate chinese De_swim_S2_Win_143a5341_1:

    # MC "Well, that was fun, but I got places to be and things to do. I’ll catch you later Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1135
translate chinese De_swim_S2_Win_7b62e32d:

    # Delilah "W-Wait... that’s it? You just came on my face and now you’re leaving?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1136
translate chinese De_swim_S2_Win_91c9cd35:

    # MC "That was the terms of the bet. We’re done. You’re free to go."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1152
translate chinese De_swim_S2_Win_con_94dfceea:

    # MC "I mean, unless you want to stay here and make it up to all those fellas you’ve bullied. I’m sure they’d accept a blowjob each as a proper apology, wouldn’t you lads?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1153
translate chinese De_swim_S2_Win_con_50356748:

    # GM "Definitely."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1154
translate chinese De_swim_S2_Win_con_1dbe4beb:

    # NM "Only if she swallows."
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1155
translate chinese De_swim_S2_Win_con_454d18f4:

    # Delilah "*Gulp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1156
translate chinese De_swim_S2_Win_con_e7fdbba2:

    # DM "Wait - hold up! Where did your pants come from, [player_name]? Guys! His pants just appeared again!"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1157
translate chinese De_swim_S2_Win_con_9b79e8c2:

    # GM "She looks like she’s ready to suck some more. I think she enjoyed it!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1158
translate chinese De_swim_S2_Win_con_7cce84a0:

    # NM "Yeah! You can suck a few more dicks, can’t you?"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1159
translate chinese De_swim_S2_Win_con_d31b6668:

    # DM "(Why is nobody answering me?! Am I in some kind of horrifying sex simulation where object permanence doesn’t actually matter?)"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1160
translate chinese De_swim_S2_Win_con_921ce59d:

    # MC "Of course, you don’t have to suck their cocks if you don’t want to, Dee. The bet is already over. I’m going to leave now and let you make the decision for yourself."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1164
translate chinese De_swim_S2_Win_con_104f13e9:

    # NM "Well? What’s it going to be?"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1165
translate chinese De_swim_S2_Win_con_e8dea65e:

    # Delilah "I... Guys... I..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1166
translate chinese De_swim_S2_Win_con_df6a7c85:

    # Delilah "(I’m so horny after the way [player_name] treated me... I shouldn’t degrade myself any further.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1167
translate chinese De_swim_S2_Win_con_31ec656a:

    # Delilah "(I shouldn’t...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1168
translate chinese De_swim_S2_Win_con_b643bfab:

    # Delilah "(But...being made to suck his dick... it was so... hot...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1169
translate chinese De_swim_S2_Win_con_e497ce75:

    # GM "C’mon Delilah! You owe us this much! Just one quick blowjob each!"
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1170
translate chinese De_swim_S2_Win_con_c162c953:

    # NM "Yeah! It may be the ONLY one we ever get in our lives!"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1171
translate chinese De_swim_S2_Win_con_647ab405:

    # GM "And you were SOOOO good at it with [player_name]."
    GM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1172
translate chinese De_swim_S2_Win_con_dd3894bd:

    # Delilah "I don’t know... I... *Gulp* Maybe... I..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1181
translate chinese De_swim_S2_Win_con_0c4c2082:

    # MC "Alright fellas, you got a show and had your fun. Time to go."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1182
translate chinese De_swim_S2_Win_con_fb06d46e:

    # NM "Aww, can we not have some fun with her too?"
    NM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1183
translate chinese De_swim_S2_Win_con_4023be5a:

    # Delilah "(What?! No way! [player_name] isn’t going to let all these nerds have their way with me, is he?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1184
translate chinese De_swim_S2_Win_con_68dbf6ed:

    # MC "No. I was the one who beat her in the bet, she was mine to play with. Not yours."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1185
translate chinese De_swim_S2_Win_con_555c5556:

    # DM "Aww, c’mon [player_name], just let us-"
    DM ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1186
translate chinese De_swim_S2_Win_con_8d8e8bb1:

    # MC "I said no. You got the chance to see her degraded in front of you. As far as I am concerned that makes up for the bullying. You’re even now."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S2.rpy:1187
translate chinese De_swim_S2_Win_con_24b3d7c7:

    # DM "*Sigh* Fine. Let’s go guys."
    DM ""

translate chinese strings:

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:512
    old "You underestimate my powe- Oh fuck! I’m cumming! Hnnnggg!"
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:512
    old "Nice try! You’re not gonna ugh... make me cum though!"
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:937
    old "Grab Delilah’s head with your hands and flood her mouth with your hot, salty cum."
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:937
    old "Play into Delilah’s newfound submissiveness. Pull your cock from Delilah’s mouth and instruct her that she has to suck it until you finish."
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:937
    old "Order Delilah to stick out her tongue while you give her a facial."
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:1148
    old "Suggest that Delilah properly apologise to the nerds with a blowjob."
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S2.rpy:1148
    old "Tell the nerds to leave her alone."
    new ""

