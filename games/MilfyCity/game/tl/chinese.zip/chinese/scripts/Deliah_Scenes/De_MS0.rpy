﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_MS0.rpy:22
translate chinese De_MS0_2dc26da8:

    # NM "I can’t believe it happened again!"
    NM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:23
translate chinese De_MS0_79ae2a7a:

    # DM "I know, it’s even worse than when Peter Jackson cut Saruman’s death from Return of the King!"
    DM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:24
translate chinese De_MS0_bed997ed:

    # GM "Someone needs to say something! They can’t keep getting away with this!"
    GM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:28
translate chinese De_MS0_8866d68a:

    # MC "Who’s getting away with what?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:29
translate chinese De_MS0_5d5f3337:

    # NM "It’s the swim team! They’re bullies! All of them!"
    NM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:30
translate chinese De_MS0_8a150f70:

    # DM "Delilah’s the WORST though!"
    DM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:34
translate chinese De_MS0_09cfee95:

    # MC "Delilah? Is she that girl who’s all over DikDok?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:35
translate chinese De_MS0_f4e57610:

    # GM "Yeah! The dark-haired girl who’s always hanging out around the pool. She’s captain of the swim team. She’s also on Instaspam, and OnlySimps too. But she doesn’t do full nudes."
    GM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:36
translate chinese De_MS0_8f5aeb2d:

    # NM "She shoved me into a locker last week."
    NM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:37
translate chinese De_MS0_921eafe7:

    # DM "And copied my coursework! That’s ACTUAL plagiarism!"
    DM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:40
translate chinese De_MS0_b8b14f5a:

    # MC "Uh huh..."
    MC ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:41
translate chinese De_MS0_83c3288d:

    # GM "If you think that’s bad, Delilah and her friends stole my clothes from the locker while I was swimming! Next thing I know there were four women in bikinis ganging up on me in the locker room!"
    GM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:42
translate chinese De_MS0_48417f75:

    # GM "They pinned me to the wall, pulled down my swim shorts and... and..."
    GM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:44
translate chinese De_MS0_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:45
translate chinese De_MS0_10d0767b:

    # GM "..."
    GM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:46
translate chinese De_MS0_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:50
translate chinese De_MS0_6e1ac47e:

    # GM "Okay, I lied, that never happened... But they did steal my lunch money!"
    GM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:54
translate chinese De_MS0_fb5c79f1:

    # MC "So, why don’t you guys just tell one of the professors?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:55
translate chinese De_MS0_088f0269:

    # DM "LOL! Tell the professors?! Her dad is mega wealthy! He’s the biggest donor on campus. The professors won’t do anything."
    DM ""

# game/scripts/Deliah_Scenes/De_MS0.rpy:56
translate chinese De_MS0_edbcd1f1:

    # MC "Fine, I guess I’ll go and speak with this Delilah myself."
    MC ""

