﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:62
translate chinese De_swim_S1_Lose_0913e7cf:

    # Delilah "Hah! I didn’t even break a sweat! Were you actually TRYING to beat me? Or are you genuinely that pathetic?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:63
translate chinese De_swim_S1_Lose_70cf8416:

    # MC "Grrr..."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:64
translate chinese De_swim_S1_Lose_721d288f:

    # MC "(I’ve screwed up. She was WAY fitter than I thought she was!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:68
translate chinese De_swim_S1_Lose_ea9f9968:

    # "*DING-A-LING* *DING-A-LING*"
    ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:69
translate chinese De_swim_S1_Lose_01f90915:

    # Delilah "Ahaha! And there’s the sound of the lunch bell. Time to start parading down the corridors in your undies, [player_name]."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:70
translate chinese De_swim_S1_Lose_7aab0acc:

    # Delilah "Oh! Can you hear that? All those footsteps, all those muffled voices! There must be DOZENS of people out there!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:74
translate chinese De_swim_S1_Lose_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:75
translate chinese De_swim_S1_Lose_77a60b63:

    # MC "(Please don’t let Celia be standing out there...)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:76
translate chinese De_swim_S1_Lose_534f7b13:

    # Delilah "Aww, are you anxious, [player_name]?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:80
translate chinese De_swim_S1_Lose_1655c8ac:

    # MC "As if!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:81
translate chinese De_swim_S1_Lose_e1e2fde5:

    # Delilah "Oh, this is too good! The little creep that asked out Ms. Celia is going to be utterly humiliated AGAIN in front of the entire campus!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:82
translate chinese De_swim_S1_Lose_8587506a:

    # Delilah "Ahaha! Careful you don’t bump into Ms. Celia. We wouldn’t want you getting a boner in the hallway."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:83
translate chinese De_swim_S1_Lose_619164da:

    # MC "Oh, ha ha! VERY funny!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:87
translate chinese De_swim_S1_Lose_938a49b7:

    # Delilah "There’s a couple of lessons to be learned here, [player_name]. Firstly, don’t make bets that you can’t win."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:88
translate chinese De_swim_S1_Lose_0c9b3961:

    # MC "Eh, I had a good shot at beating-"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:89
translate chinese De_swim_S1_Lose_85bd720f:

    # Delilah "No, you didn’t. Not even close."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:93
translate chinese De_swim_S1_Lose_4d04491a:

    # Delilah "And second lesson, [player_name], is something EVERYONE else already knows on this campus. The popular girls and the nerds don’t mix. You stay in your fucking lane."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:94
translate chinese De_swim_S1_Lose_0c3ada22:

    # Delilah "Read my lips, [player_name], and listen closely. You’re not one of the cool boys. You’re not admired and you’re not special. You’re just a loser."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:95
translate chinese De_swim_S1_Lose_b561d843:

    # MC "(She’s even more of an asshole than the nerds had led me to believe. If she thinks that little of those guys then no wonder she thinks she can get away with bullying them so much!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:99
translate chinese De_swim_S1_Lose_c99bbf8b:

    # Delilah "Now, I want you to march into that hallway. I want you to present yourself to your classmates, and I want you to remember one VERY important thing from today."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:100
translate chinese De_swim_S1_Lose_f4877cc6:

    # Delilah "Know. Your. Fucking. Place."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:104
translate chinese De_swim_S1_Lose_70cf8416_1:

    # MC "Grrr..."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:106
translate chinese De_swim_S1_Lose_a6cf578b:

    # MC "(I fucking hate her! I can’t welch out on our bet now though!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:107
translate chinese De_swim_S1_Lose_a09e1912:

    # MC "(I’ve already experienced utter humiliation with Ms. Celia. I survived that. I’ll survive this too. I’ll train, I’ll come back when I’m stronger, and I’ll get my revenge on you, Delilah!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:108
translate chinese De_swim_S1_Lose_0d281175:

    # Delilah "Do you need a hand with that BIG HEAVY door, you weakling?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:109
translate chinese De_swim_S1_Lose_f191fad6:

    # MC "Fuck off, Delilah."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:110
translate chinese De_swim_S1_Lose_e9451414:

    # Delilah "Hehe! I cannot WAIT to hear them all laughing at you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:111
translate chinese De_swim_S1_Lose_c879e375:

    # MC "*Sigh* (Shit... Alright, let’s get this over with. The longer I drag it out the worse it’s gonna be.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:117
translate chinese De_swim_S1_Lose_8e156bb0:

    # Blonde_Girl "So, anyway, I told her that if she wants to meet up with Dan every Friday behind the gym then it’s not any of my busin-"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:118
translate chinese De_swim_S1_Lose_d40b9612:

    # Chubby_Girl "OH MY GOD!"
    Chubby_Girl ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:119
translate chinese De_swim_S1_Lose_1a8eb90a:

    # MC "(Ugh... This is gonna be bad.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:120
translate chinese De_swim_S1_Lose_bd8cdf56:

    # Blonde_Girl "Is that the student who asked out Ms. Celia?!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:121
translate chinese De_swim_S1_Lose_0b5f7c55:

    # BB_Girl "HOLY SHIT! You’re right! It’s him! It’s [player_name]!"
    BB_Girl ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:122
translate chinese De_swim_S1_Lose_41d99bf7:

    # Ginger_Guy "(I’m just glad I’m not going to be the punchline of every joke for the rest of the day!)"
    Ginger_Guy ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:126
translate chinese De_swim_S1_Lose_8e6b64c3:

    # MC "(Oh God... There’s Ms. Celia... Out of ALL the professors on this campus, why did it HAVE to be HER?!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:127
translate chinese De_swim_S1_Lose_b4f6db38:

    # Crowd "Ahahaha!"
    Crowd ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:128
translate chinese De_swim_S1_Lose_599e7519:

    # MC "(Aw no! Not Sara too!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:129
translate chinese De_swim_S1_Lose_5faeb902:

    # Blonde_Girl "What’s he doing?!"
    Blonde_Girl ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:133
translate chinese De_swim_S1_Lose_765b3db4:

    # Sara "[player_name], w-why are you? Y-You’re in your- your-"
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:134
translate chinese De_swim_S1_Lose_08453f6a:

    # MC "I lost a bet. I don’t wanna talk about it."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:135
translate chinese De_swim_S1_Lose_e89f64d5:

    # Sara "Oh my God..."
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:139
translate chinese De_swim_S1_Lose_2f999ac6:

    # Sara "(I can’t believe this is happening to him! It’s WAY too soon after everything went down with Ms. Celia!)"
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:140
translate chinese De_swim_S1_Lose_3317b4c5:

    # Sara "Y-You have to go and change! It’s lunchtime, everyone is going to be-"
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:144
translate chinese De_swim_S1_Lose_326b2473:

    # MC "I already told you Sara, I lost a bet. I have to take this like a man."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:145
translate chinese De_swim_S1_Lose_2283554f:

    # Sara "But you’re... You’re... practically naked..."
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:146
translate chinese De_swim_S1_Lose_f662a496:

    # MC "Yeah, and if I want to have a shot at revenge on the person who did this to me, then I need to show that I don’t back out on bets. I’m gonna see this through to the end."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:147
translate chinese De_swim_S1_Lose_4b24d394:

    # MC "It might be a little hard for you to understand Sara, but this is about more than just me. There’s a group of guys who don’t have the social skills to stand up for themselves."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:148
translate chinese De_swim_S1_Lose_47753f36:

    # MC "I may have lost the first battle, but I haven’t lost the war. Those nerds are counting on me, and I’m not gonna let them down."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:149
translate chinese De_swim_S1_Lose_7faed1f5:

    # MC "There comes a time in every man’s life when he realises that there are things bigger than his own ego or his dignity. Standing up for what is right, what is moral, what is JUST, in this world."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:153
translate chinese De_swim_S1_Lose_1a5c460a:

    # Sara "Uhh... It’s a nice speech and all, but it kinda loses any impact it was supposed to have when you’re only dressed in your underwear. "
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:154
translate chinese De_swim_S1_Lose_f696fd6b:

    # MC "Okay Sara, I get your point."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:155
translate chinese De_swim_S1_Lose_66396892:

    # Sara "I mean, it kinda feels like Martin Luther King delivering “I have a dream” while wearing a thong."
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:156
translate chinese De_swim_S1_Lose_24ee5cba:

    # MC "Thanks Sara, no need to elaborate any further. Anyway, I’ll see you after classes end today."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:157
translate chinese De_swim_S1_Lose_1a3128e8:

    # Sara "(Mmm, I can see the outline of his junk through those shorts. His underwear is soooo tight!)"
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:158
translate chinese De_swim_S1_Lose_eb42c38a:

    # Sara "(I’d love to reach out and trace my fingers over his huge package. I can just imagine it stiffening under my touch and-)"
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:159
translate chinese De_swim_S1_Lose_4e37f141:

    # Sara "Hmm? Sorry, what did you say?"
    Sara ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:160
translate chinese De_swim_S1_Lose_a9c984ec:

    # MC "Ugh, nevermind."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:164
translate chinese De_swim_S1_Lose_351697ab:

    # MC "(Alright... I have to walk the entire length of the hallway for this bet. This means passing by this bitch.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:165
translate chinese De_swim_S1_Lose_d9219893:

    # Celia "[player_name]."
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:166
translate chinese De_swim_S1_Lose_b761b3db:

    # MC "Ms. Celia."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:170
translate chinese De_swim_S1_Lose_be257427:

    # Celia "Should I be expecting another indecent proposal from you, [player_name]?"
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:171
translate chinese De_swim_S1_Lose_0a07ab39:

    # Celia "Because, if you are intending to impress me by showing off what’s in your shorts, I have to assure you, I have seen bigger."
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:172
translate chinese De_swim_S1_Lose_722e9b04:

    # MC "(Grrr... As if seeing Sara wasn’t bad enough!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:176
translate chinese De_swim_S1_Lose_8aaec236:

    # MC "Nope. I wasn’t planning to... *Ahem*... ask you out again."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:177
translate chinese De_swim_S1_Lose_7add237f:

    # Celia "Aww, that’s a shame. I’ve had plenty of time to come up with some great put-downs."
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:178
translate chinese De_swim_S1_Lose_bf1faff9:

    # MC "(Her dress is so tight! I can’t look - she’ll just humiliate me even more if I start to get a boner in the hallway!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:179
translate chinese De_swim_S1_Lose_1cbea9d2:

    # Celia "You’ve gone very quiet? Are you, perhaps, a bit distracted by my dress? I suppose it is a bit too short for the official dress code, but nobody has complained so far."
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:180
translate chinese De_swim_S1_Lose_2f6c5ab9:

    # MC "(Crap! I can feel blood rushing down there. I better get out of here fast!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:184
translate chinese De_swim_S1_Lose_f46d54ac:

    # Celia "Aww! What’s wrong, [player_name]? Are you leaving already?"
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:185
translate chinese De_swim_S1_Lose_9d74f35a:

    # MC "Got to get back to the pool."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:186
translate chinese De_swim_S1_Lose_5dea1729:

    # Celia "Uh huh... Try not to forget your clothes next time. Spare us all the embarrassment of having to see your tiny little pecker!"
    Celia ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:191
translate chinese De_swim_S1_Lose_f8181dd7:

    # "*CLUNK*"
    ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:195
translate chinese De_swim_S1_Lose_dd7637c5:

    # Delilah "Ahahaha! That was HILARIOUS! Oh God! That was Ms. Celia’s voice, wasn’t it?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:196
translate chinese De_swim_S1_Lose_4917d608:

    # MC "*Sigh* You KNEW she would be there, didn’t you?!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:197
translate chinese De_swim_S1_Lose_1a9f3be2:

    # Delilah "AHAHAHAAH! God, my sides are in fucking orbit!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:198
translate chinese De_swim_S1_Lose_64bb9287:

    # Delilah "Hahaha... You are correct though. Someone probably slipped Ms. Celia a note, asking her to meet in the hallway at lunch. God, who on Earth would do such a wicked thing?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:202
translate chinese De_swim_S1_Lose_669191f9:

    # MC "This isn’t over, Delilah! I’m going to come back and I’m going to beat you next time!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:203
translate chinese De_swim_S1_Lose_dc7b09a6:

    # Delilah "Next time?! Did you just say ‘NEXT TIME?’ HAHAHAHA! Bring it on, weakling! I’d relish the chance to humiliate you again."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:204
translate chinese De_swim_S1_Lose_953d429d:

    # Delilah "You’re going to serve as a warning to every other nerd, dork, and geek on this campus who dares to think above their station. There isn’t a social ladder on this campus, there’s a throne and I’m the fucking Queen."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:205
translate chinese De_swim_S1_Lose_21ad7236:

    # MC "(We’ll see how long that lasts, your majesty.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:206
translate chinese De_swim_S1_Lose_fee80c95:

    # MC "(If I want to win against her, I should go to the GYM.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:224
translate chinese De_swim_S1_Win_22dafe8d:

    # Delilah "Oh my God..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:225
translate chinese De_swim_S1_Win_f5d47c0f:

    # MC "WOOOO!!! *Pant* Ha! What was that you were saying? That there’s no way a “weakling” like me could beat you?"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:226
translate chinese De_swim_S1_Win_6cae5735:

    # Delilah "(No way... That did NOT just happen!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:227
translate chinese De_swim_S1_Win_35721648:

    # Delilah "Hold on, that was a fluke. You must have cheated or taken steroids or-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:231
translate chinese De_swim_S1_Win_145a944f:

    # MC "A bet’s a bet, Delilah! That means you have to walk around the hall dressed in your clothes with no bra and no blouse!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:232
translate chinese De_swim_S1_Win_eb6ea106:

    # Delilah "Oh God..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:233
translate chinese De_swim_S1_Win_26cd1104:

    # MC "You’ve been teasing all the guys on campus with your suggestive pictures on Instaspam for long enough, Delilah. It’s time to let them all see the real thing!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:237
translate chinese De_swim_S1_Win_1b7a9fa4:

    # MC "And don’t you even think about welching on our bet, or I’ll tell everyone that you’re just a chicken."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:238
translate chinese De_swim_S1_Win_9c35a76b:

    # Delilah "You can say whatever you want, [player_name]. No one is EVER going to believe you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:239
translate chinese De_swim_S1_Win_eaf4462b:

    # MC "Then we’ll just invite a crowd to see a live rematch! They can all watch me beat you a second time. I’m sure that would do wonders for your reputation."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:240
translate chinese De_swim_S1_Win_56be0568:

    # Delilah "(Fuck. He’s right. Getting made to walk around the hallway nearly-naked is one thing, but if the campus knew that their swim team captain got beaten by some scrawny loser - it’d be FAR worse.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:242
translate chinese De_swim_S1_Win_ea9f9968:

    # "*DING-A-LING* *DING-A-LING*"
    ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:243
translate chinese De_swim_S1_Win_13a9eb0b:

    # MC "And there’s the lunch bell. Time to get going!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:247
translate chinese De_swim_S1_Win_72c7f688:

    # Delilah "H-How about double or- or nothing? W-We race again in private, just you and me, and- and- if you win then I’ll- I’ll go without any skirt either!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:248
translate chinese De_swim_S1_Win_8d07be9f:

    # MC "Nope! You’re not wiggling your way out of this one, Delilah."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:249
translate chinese De_swim_S1_Win_e935cd36:

    # Delilah "Arrrgh! I don’t think you quite appreciate just what is at stake here. My ENTIRE reputation is based on respect. You don’t understand just how many people look up to me on campus. I’m the-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:250
translate chinese De_swim_S1_Win_660780a3:

    # MC "Time's ticking, Delilah. "
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:254
translate chinese De_swim_S1_Win_3784f5b2:

    # Delilah "Okay, listen, you’re a pretty hot guy. So how about I just slip out of my swimsuit right now and show you everything. I’ll even let you touch whatever you want above my waist! That’s a fair deal, right [player_name]?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:255
translate chinese De_swim_S1_Win_189a2c7c:

    # MC "Top off. Corridor. Now."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:256
translate chinese De_swim_S1_Win_b2de63e8:

    # Delilah "I’ll let you look at my breasts, my pussy, my ass... I’ll even let you touch my ass if you want to! Final offer!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:257
translate chinese De_swim_S1_Win_57b796c0:

    # MC "Nope. No deals, no double-or-nothings, no negotiations. You lost the bet."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:261
translate chinese De_swim_S1_Win_0ee71702:

    # Delilah "Arrgh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:262
translate chinese De_swim_S1_Win_fbdc06fb:

    # Delilah "(I cannot believe this is actually happening! He wouldn’t even take me up on my offers! Does this guy honestly want to damage my reputation THAT badly?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:263
translate chinese De_swim_S1_Win_fd0ad133:

    # MC "Remember Delilah! No blouse or bra! And you can’t cover your nipples!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:264
translate chinese De_swim_S1_Win_88994d4e:

    # Delilah "Fuck you, [player_name]."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:268
translate chinese De_swim_S1_Win_be2d7886:

    # MC "Hey! Don’t get grumpy at me! You’re the one who made the bet! You’d have made me waltz down the corridor in my underwear if I’d lost!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:269
translate chinese De_swim_S1_Win_562de8ee:

    # Delilah "Yeah, but you’re just an unpopular dork. It’s not like you’ve got a reputation to lose!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:273
translate chinese De_swim_S1_Win_4c7068ed:

    # Delilah "(Why did I even enter this dumb bet? I had NOTHING to gain from it!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:274
translate chinese De_swim_S1_Win_1a266e83:

    # MC "(Oh wow! Just look at that body! There’s gonna be A LOT of happy guys on campus today!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:275
translate chinese De_swim_S1_Win_29f9d10e:

    # MC "*Whistle* Nice ass!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:279
translate chinese De_swim_S1_Win_ae1cd566:

    # Delilah "(Ugh! What a pig! I swear to God, as soon as I get out of this I am going to get revenge on this piece of shit!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:280
translate chinese De_swim_S1_Win_14d9cee2:

    # Delilah "(How DARE he humiliate me like this?! He MUST have cheated! There’s no way he is faster than the regional swim champ! I bet those nerds helped him out. Those conniving bastards are all in on it together. Well, I’ll show them. I’ll show them all!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:281
translate chinese De_swim_S1_Win_1937d845:

    # MC "How about you lean over and give me a view of that ass?"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:282
translate chinese De_swim_S1_Win_c3197fe9:

    # Delilah "And why would I do that?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:283
translate chinese De_swim_S1_Win_9311bf37:

    # MC "Tell you what, do this for me, and I promise you I won’t take any photos or videos of you walking topless down the corridor. Deal?"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:287
translate chinese De_swim_S1_Win_3aaf0fbb:

    # Delilah "Argh... Fine. You BETTER appreciate this though, because it’s the ONLY time you’re EVER going to see this ass!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:288
translate chinese De_swim_S1_Win_075289af:

    # MC "(Given how badly Delilah lost, I highly doubt that!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:289
translate chinese De_swim_S1_Win_79b4347e:

    # MC "Trust me, I’m gonna cherish every second of it."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:293
translate chinese De_swim_S1_Win_6491d2cb:

    # Delilah "Ugh, creep."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:294
translate chinese De_swim_S1_Win_bb5d9c58:

    # Delilah "(This is so fucking embarrassing! And I haven’t even made it out to the corridor yet!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:298
translate chinese De_swim_S1_Win_ff95d706:

    # MC "(Her pussy looks so tight! Delilah has always been a tease on DikDok, but I don’t think I’ve EVER seen her with any guys before.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:299
translate chinese De_swim_S1_Win_40eb8276:

    # MC "(I wonder if she’s still a virgin?)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:303
translate chinese De_swim_S1_Win_45e4f040:

    # MC "(I bet her ass is even tighter. I don’t even know if my dick would fit in there!)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:304
translate chinese De_swim_S1_Win_a2757d29:

    # MC "(God, I hope she’s arrogant enough to challenge me to a rematch. I’d love to pound her cocky ass into submission.)"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:308
translate chinese De_swim_S1_Win_93b58aff:

    # Delilah "Well? Are you quite done gawking at me?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:309
translate chinese De_swim_S1_Win_83da03c8:

    # MC "Almost, just a couple more min-"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:310
translate chinese De_swim_S1_Win_44e8c717:

    # Delilah "Tough shit, time’s up."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:314
translate chinese De_swim_S1_Win_b5d265a8:

    # MC "Wow."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:315
translate chinese De_swim_S1_Win_c231429b:

    # Delilah "I know, I know. I’m hot. Let’s get this over."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:316
translate chinese De_swim_S1_Win_336c1172:

    # MC "Hey, wait, you’re still wearing a jacket! The bet was-"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:320
translate chinese De_swim_S1_Win_544905c3:

    # Delilah "The bet was no blouse and no bra. I found a loophole, dipshit. You didn’t think that one through, did ya?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:321
translate chinese De_swim_S1_Win_577c1090:

    # MC "Hold on! The bet was no blouse, no bra, AND everyone has to see your nipples. If they can’t see your nipples because you’re wearing your jacket then you’re not completing the bet!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:322
translate chinese De_swim_S1_Win_a395a06f:

    # Delilah "You didn’t say that I couldn’t wear a jacket!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:323
translate chinese De_swim_S1_Win_9941091e:

    # MC "This changing room stinks, let’s discuss this back at the pool."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:327
translate chinese De_swim_S1_Win_02e112fc:

    # Delilah "Ugh! It’s not MY fault that you didn’t think to close all the loopholes when you made your bet!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:328
translate chinese De_swim_S1_Win_8ee2c58d:

    # MC "It’s not my fault that you’re such a conniving bitch!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:329
translate chinese De_swim_S1_Win_e31f36e1:

    # Delilah "God, I hate you so much."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:330
translate chinese De_swim_S1_Win_a3b21cc6:

    # MC "Trust me, the feeling is mutual."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:334
translate chinese De_swim_S1_Win_d4e5336e:

    # Delilah "So, lunch time is ticking by. What do you propose?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:335
translate chinese De_swim_S1_Win_7d0e02fe:

    # MC "Fine. You can keep your jacket on."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:336
translate chinese De_swim_S1_Win_0502ee81:

    # Delilah "Thank y-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:337
translate chinese De_swim_S1_Win_558ce2c4:

    # MC "HOWEVER, you have to pull it open for all the guys to see when you’re halfway down the corridor. That way everyone gets to see your nipples - which was a KEY part of the bet!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:338
translate chinese De_swim_S1_Win_d2f35b42:

    # Delilah "Hmmph... Fine."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:339
translate chinese De_swim_S1_Win_a3e82193:

    # MC "Well, how about a demonstration then?"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:343
translate chinese De_swim_S1_Win_a3efac8f:

    # Delilah "Happy?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:344
translate chinese De_swim_S1_Win_64069b38:

    # MC "Exceptionally."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:345
translate chinese De_swim_S1_Win_368e7737:

    # Delilah "How long do I have to pose like this for?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:346
translate chinese De_swim_S1_Win_70592088:

    # MC "Long enough for everyone to have seen you."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:350
translate chinese De_swim_S1_Win_5ba2ecd1:

    # MC "Lunch time is almost over. Better get a move on, or you’ll miss the crowds!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:351
translate chinese De_swim_S1_Win_67cb72eb:

    # Delilah "*Sigh* I don’t suppose we can renegotiate-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:352
translate chinese De_swim_S1_Win_ea70dbad:

    # MC "Nope!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:356
translate chinese De_swim_S1_Win_0a8ba511:

    # Delilah "You’re despicable. It’s cruel to do this to a girl, y’know. What did I EVER do to you to deserve this?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:357
translate chinese De_swim_S1_Win_cc7ad102:

    # MC "Uh huh. You’d have done the same to me if I lost."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:358
translate chinese De_swim_S1_Win_70ea0d13:

    # Delilah "Grrr..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:364
translate chinese De_swim_S1_Win_00a1aaaf:

    # Delilah "(Oh God... I am NEVER going to recover from this!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:365
translate chinese De_swim_S1_Win_e21fdf37:

    # Delilah "(I put SO much care and effort into not revealing too much on DikDok. Now all my efforts are being sabotaged in one afternoon! Who’s going to want to subscribe to my OnlySimps when they’ve already seen it for free?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:366
translate chinese De_swim_S1_Win_768e1c3a:

    # NM1 "Hey! Look! Over there!"
    NM1 ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:370
translate chinese De_swim_S1_Win_f1541401:

    # NM "Is that... Holy moly! It’s Delilah!"
    NM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:371
translate chinese De_swim_S1_Win_8c3a8a81:

    # GM "No way! It is! She’s got her tits out!"
    GM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:372
translate chinese De_swim_S1_Win_94a98035:

    # DM "LOL! Look how embarrassed she looks! Her cheeks are scarlet red!"
    DM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:373
translate chinese De_swim_S1_Win_e9050a9f:

    # Delilah "(This is worse than I ever imagined it would be...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:377
translate chinese De_swim_S1_Win_2ce08396:

    # MC "Well? What are you waiting for, Delilah? Don’t you have something you want to show these nice fellas?"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:378
translate chinese De_swim_S1_Win_64ad96d3:

    # Delilah "*Whispered* [player_name]... these are all the dorks and geeks... Where’s the hot guys from the sports teams and-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:379
translate chinese De_swim_S1_Win_fcc602a8:

    # MC "Oh, they’re off playing a match today. What do you have against the dorks and geeks?"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:380
translate chinese De_swim_S1_Win_fad8e342:

    # NM "Yeah! She’s ALWAYS picking on us!"
    NM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:384
translate chinese De_swim_S1_Win_5cccd65e:

    # MC "Well, Delilah is here today to properly apologise to you fellas. C’mon Delilah, you know what to do."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:385
translate chinese De_swim_S1_Win_454d18f4:

    # Delilah "*Gulp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:386
translate chinese De_swim_S1_Win_7122c642:

    # Delilah "(I can’t believe what I’ve gotten myself into. Why the FUCK did I bet my reputation on a stupid race?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:387
translate chinese De_swim_S1_Win_551d83bd:

    # MC "Clock’s ticking, Delilah."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:391
translate chinese De_swim_S1_Win_7c004397:

    # NM "WOOO!"
    NM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:392
translate chinese De_swim_S1_Win_b7c1b96e:

    # GM "Awesome! They’re so much more 3D than I’m used to! Err.. I mean - than I expected."
    GM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:393
translate chinese De_swim_S1_Win_42438a47:

    # MC "I hope you will all find it in your hearts to forgive dear Delilah for bullying you. Make sure to take a long, hard look."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:394
translate chinese De_swim_S1_Win_c830d3c7:

    # Delilah "(God, this is humiliating. They’re leering at me with their tongues out, like dogs at a barbeque.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:398
translate chinese De_swim_S1_Win_04920d92:

    # MC "Yeah! Good idea, take your phone out, get some pictures! This could be a once-in-a-lifetime opportunity!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:399
translate chinese De_swim_S1_Win_a72f20c4:

    # Delilah "H-Hey, you said you wouldn’t take any photos!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:400
translate chinese De_swim_S1_Win_6db9020a:

    # MC "I said I wouldn’t take any photos! Emphasis on “I”. They can do whatever they want."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:401
translate chinese De_swim_S1_Win_3fd0194d:

    # Delilah "Ugh. Pig."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:402
translate chinese De_swim_S1_Win_007676ca:

    # MC "What? It’s not MY fault you didn’t think to close the loopholes when we were making the bet."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:407
translate chinese De_swim_S1_Win_ae444875:

    # "*Flash*"
    ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:408
translate chinese De_swim_S1_Win_131bc4f9:

    # GM "This is gonna be my new desktop background!"
    GM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:411
translate chinese De_swim_S1_Win_a18b01c3:

    # "*Flash Flash*"
    ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:412
translate chinese De_swim_S1_Win_ac0a6eed:

    # NM "Pfft! That’s so lame! I’m printing my picture onto a body pillow!"
    NM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:413
translate chinese De_swim_S1_Win_5d490e72:

    # Delilah "(Jesus Christ... This is unbearable.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:416
translate chinese De_swim_S1_Win_a18b01c3_1:

    # "*Flash Flash*"
    ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:421
translate chinese De_swim_S1_Win_28d47c52:

    # Delilah "ALRIGHT! That’s enough!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:422
translate chinese De_swim_S1_Win_8010b847:

    # DM "Hold on, I haven’t gotten a picture yet. I was in the middle of an arena run on Hearthbone! Just give me a-"
    DM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:423
translate chinese De_swim_S1_Win_dd33d6dd:

    # Delilah "You had your chances. If I find ANY of those photos you took being shared with ANYONE, then I’m going to have my father shut down the campus DnD club."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:424
translate chinese De_swim_S1_Win_41169f20:

    # GM "Heh, as if you could-"
    GM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:425
translate chinese De_swim_S1_Win_dfdaf61d:

    # DM "Shut up, you idiot! She’s not joking! Remember who her dad is!"
    DM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:429
translate chinese De_swim_S1_Win_fde22a6a:

    # MC "Yeah, best to keep those pictures to yourselves, fellas. Hope you all enjoyed the show!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:430
translate chinese De_swim_S1_Win_733a7f31:

    # NM "Is she gonna do it again?"
    NM ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:431
translate chinese De_swim_S1_Win_7b3b0ebf:

    # Delilah "Only in your wet dreams, nerd."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:432
translate chinese De_swim_S1_Win_49d2de1d:

    # MC "We’ll see. Perhaps."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:436
translate chinese De_swim_S1_Win_1d399153:

    # Delilah "*Whispered* Ugh... this is the worst day of my life."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:437
translate chinese De_swim_S1_Win_cbdac43f:

    # MC "The worst day of your life so far!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:438
translate chinese De_swim_S1_Win_fce69340:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:439
translate chinese De_swim_S1_Win_1e64556d:

    # MC "Aww, c’mon Delilah. All you had to do was show your tits. It could have been MUCH worse!"
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:443
translate chinese De_swim_S1_Win_682232c4:

    # Delilah "This isn’t over you know. I’m gonna make you pay for embarrassing me like this."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:444
translate chinese De_swim_S1_Win_c0cfabf8:

    # MC "You literally just lost a bet. You were going to do the exact same to me."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:445
translate chinese De_swim_S1_Win_70ea0d13_1:

    # Delilah "Grrr..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:446
translate chinese De_swim_S1_Win_51524bf3:

    # MC "It’s probably best to head back into the pool now before any professors show up."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:447
translate chinese De_swim_S1_Win_03a34169:

    # MC "But, hey, if you ever feel like having a rematch, I’d love to do this again."
    MC ""

# game/scripts/Deliah_Scenes/De_Swim_S1.rpy:448
translate chinese De_swim_S1_Win_b4b6d528:

    # Delilah "Piss off, [player_name]."
    Delilah ""

