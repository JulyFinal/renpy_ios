﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_MS3.rpy:19
translate chinese De_MS3_b1f744c7:

    # MC "(I'm not strong enough to win against her.)"
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:31
translate chinese De_MS3_bdf1532e:

    # Delilah "Ready for a rematch?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:62
translate chinese De_MS3_ec52d097:

    # MC "I’m honestly surprised to see you’re still here. If I was the famous “Ice Queen” of the campus, I wouldn’t be able to show my face in front of the swim team again after what happened."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:63
translate chinese De_MS3_302b577e:

    # Delilah "I’m not surprised that you wouldn’t be able to show your face again. You’re a weak, spineless man. That’s the difference between you and me - when I get knocked down, I get straight back up again."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:69
translate chinese De_MS3_d1141db9:

    # MC "How were things after I left, by the way? Did you have a lot of fun properly “apologising” to the nerds?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:70
translate chinese De_MS3_2b85f72f:

    # Delilah "Nothing happened between me and them."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:71
translate chinese De_MS3_27d6a1f0:

    # MC "Are you sure? Because they’ve been looking pretty fucking elated when I last saw them."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:75
translate chinese De_MS3_820aa1e6:

    # Delilah "Do I have to spell it out for you? NOTHING happened."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:76
translate chinese De_MS3_092f696f:

    # Delilah "I got up after you left and washed myself in the changing room. So whatever fantasy you’ve decided to spin in your head is complete and utter BS."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:80
translate chinese De_MS3_bd7dc996:

    # MC "Uh huh. Well, let me tell you what I think happened."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:81
translate chinese De_MS3_9e909924:

    # Delilah "I don’t want to hear what you think ha-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:82
translate chinese De_MS3_932c6f24:

    # MC "I think that after I fucked your pretty little face, you were really horny. I think you wanted more."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:86
translate chinese De_MS3_56f91c5e:

    # MC "And I also think that as soon as you were left alone with those three fellas, you happily sucked each one of them off."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:87
translate chinese De_MS3_454d18f4:

    # Delilah "*Gulp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:88
translate chinese De_MS3_563dd0cd:

    # MC "Because deep down, Delilah, you’re just a horny slut who WANTS to be used. I think being vulnerable and used is what really gets you going."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:96
translate chinese De_MS3_3d8f09fd:

    # MC "You don’t think I’m capable of getting back in the fight?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:97
translate chinese De_MS3_cc6cd33e:

    # Delilah "No, I don’t. I think you’re weak. You may have humiliated me last time, but I’m back up and standing proud."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:101
translate chinese De_MS3_c090d7b8:

    # Delilah "I KNOW that if I did the same thing to you, you’d end up running and crying to Ms. Celia."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:102
translate chinese De_MS3_a022fdf3:

    # Delilah "Or perhaps you’d just go to Judy. How is therapy by the way? Have you had any breakthroughs as to why you decided to suddenly ask out one of your professors?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:106
translate chinese De_MS3_68df4b80:

    # MC "Therapy’s great actually! I’m feeling better about myself with each session."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:107
translate chinese De_MS3_06af7692:

    # MC "Actually, maybe you should give therapy a go too! Perhaps Judy could help explain why you turn into such a submissive slut when a guy starts dominating you."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:114
translate chinese De_MS3_con_7cad1525:

    # Delilah "That sounds like fighting talk."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:115
translate chinese De_MS3_con_faf728de:

    # MC "What do you say? One final bet between us?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:116
translate chinese De_MS3_con_8f7df7ab:

    # Delilah "Nothing off limits."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:120
translate chinese De_MS3_con_d1897561:

    # MC "Nothing off limits."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:121
translate chinese De_MS3_con_06e3095f:

    # MC "(Heh! This is gonna be my chance to fuck her brains out!)"
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:125
translate chinese De_MS3_con_8e224a76:

    # Delilah "You may THINK that you have destroyed my reputation after our previous two bets. Let me assure you that this is NOT the case."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:126
translate chinese De_MS3_con_04ef17ba:

    # Delilah "Embarrassing me in front of a few nerds was NEVER going to be enough to break me. There are hundreds of other students who don’t know what happened - and even if the nerds say something, who is going to believe THEM over ME?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:130
translate chinese De_MS3_con_54e62887:

    # Delilah "You, on the other hand, are finished. When you lose this next bet I am going to make sure that EVERY SINGLE GIRL in the whole campus knows that you. Are. My. Bitch."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:131
translate chinese De_MS3_con_48f65a57:

    # Delilah "If you lose, then you have to be my slave for a full day."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:135
translate chinese De_MS3_con_0ddf1c91:

    # MC "Oh yeah? Well, WHEN you lose I get to fuck you."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:139
translate chinese De_MS3_con_a6733441:

    # Delilah "Hehe! Ahahah! You think you are going to FUCK me?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:140
translate chinese De_MS3_con_849929bc:

    # Delilah "I have NEVER let ANY guy fuck me! And my first time DEFINITELY isn’t going to be with a little dork like you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:141
translate chinese De_MS3_con_59685689:

    # MC "We’ll see how much you’re laughing when I’m pounding your virgin pussy."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:145
translate chinese De_MS3_con_f1751dd9:

    # Delilah "Ahaha! This is too much!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:146
translate chinese De_MS3_con_0fadb2c3:

    # Delilah "Okay, [player_name], let’s do it. One final bet. I hope you’re ready for me to completely and utterly humiliate you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:147
translate chinese De_MS3_con_9b45584c:

    # MC "And I hope you’re ready to lose your virginity."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:151
translate chinese De_MS3_con_bcd589a3:

    # Delilah "You don’t know what you’re getting yourself into, [player_name]. I’ve been training relentlessly since that fluke on our previous bet."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:152
translate chinese De_MS3_con_9e893e4f:

    # Delilah "I’m stronger and faster than I’ve ever been before. I’ve trained harder, I’ve put in the work, and I’m going to reap the reward of having you as my personal slave for a day."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:153
translate chinese De_MS3_con_02b6f5e9:

    # MC "Good luck."
    MC ""

# game/scripts/Deliah_Scenes/De_MS3.rpy:154
translate chinese De_MS3_con_498c7702:

    # Delilah "Skill doesn’t need luck."
    Delilah ""

