﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:145
translate chinese De_swim_S3_Lose_77f28960:

    # Delilah "*Pant* You put up a good *Pant* fight, [player_name], but I DID warn you that I’d been training.."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:146
translate chinese De_swim_S3_Lose_b65648a9:

    # Delilah "Y’know, you *Pant* ALMOST had me for a second though."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:147
translate chinese De_swim_S3_Lose_45a51da8:

    # MC "(Crap! I can’t believe she beat me! I thought I’d trained enough!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:148
translate chinese De_swim_S3_Lose_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:152
translate chinese De_swim_S3_Lose_9fac9278:

    # Delilah "You and I both know what comes next now - you’re my personal slave for the rest of the day."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:153
translate chinese De_swim_S3_Lose_2188e5cd:

    # Delilah "So, I’m thinking that we should swing by my place later on this evening. It gives me the privacy I need to do whatever I want with you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:154
translate chinese De_swim_S3_Lose_2706ab54:

    # MC "Well, at least I’ll be spared public humiliation if it’s at your place."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:158
translate chinese De_swim_S3_Lose_72f31a94:

    # Delilah "Eh... I wouldn’t be too sure about that final point. I still have a few ideas to wreck your reputation. Although, after Ms. Celia, do you even have a reputation to damage? Ahaha!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:159
translate chinese De_swim_S3_Lose_28f77937:

    # MC "You’re never letting this Celia thing go, are you?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:160
translate chinese De_swim_S3_Lose_63e04199:

    # Delilah "Nope. Meet me at the front of campus when classes end. We’ll walk back to my place together."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:161
translate chinese De_swim_S3_Lose_44b7f3c9:

    # MC "Aww, you make it almost sound like a date."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:165
translate chinese De_swim_S3_Lose_2a070ffc:

    # Delilah "Ha! Trust me, if you think tonight is going to be anything like a date, then you’re SORELY mistaken."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:169
translate chinese De_swim_S3_Lose_38618426:

    # "*DING-A-LING*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:170
translate chinese De_swim_S3_Lose_e819f1b4:

    # MC "(Well, that’s the final lecture of the day. I better meet Delilah out the front of campus.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:171
translate chinese De_swim_S3_Lose_9bd6b662:

    # MC "(I wonder what she has planned for me...)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:175
translate chinese De_swim_S3_Lose_5f2f1778:

    # Delilah "Y’know, I’m surprised you actually showed up."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:176
translate chinese De_swim_S3_Lose_de8261fa:

    # MC "Really? Have I ever welched out on one of our bets before?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:177
translate chinese De_swim_S3_Lose_ed0a36c8:

    # Delilah "To your credit, no. I just didn’t think you had the balls to go through with being my personal plaything for the rest of the night."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:178
translate chinese De_swim_S3_Lose_c00ca85e:

    # MC "Hmm. How far is your place?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:179
translate chinese De_swim_S3_Lose_112b9d4b:

    # Delilah "Ten minutes walk away."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:180
translate chinese De_swim_S3_Lose_0311fa59:

    # MC "Oh, so you live in the nice part of town? That figures."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:181
translate chinese De_swim_S3_Lose_45d508cb:

    # Delilah "What’s that supposed to mean?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:182
translate chinese De_swim_S3_Lose_92314360:

    # MC "You come from money, Dee. Everyone knows that your dad’s mega rich."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:183
translate chinese De_swim_S3_Lose_8ac44423:

    # Delilah "I already warned you about calling me Dee. Only people I actually like get to call me that."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:191
translate chinese De_swim_S3_Lose_8be797f8:

    # Delilah "Well, here we are. This is where you’re going to be treating me this evening."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:192
translate chinese De_swim_S3_Lose_17dc0c31:

    # MC "What exactly do you want me to do?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:193
translate chinese De_swim_S3_Lose_2c1cf0bb:

    # Delilah "I’m not quite sure yet. I was thinking of letting the evening develop organically. If I need something, or something tickles my fancy, I’ll call on you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:202
translate chinese De_swim_S3_Lose_menu_ca36d327:

    # MC "So I’m your butler for the evening?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:203
translate chinese De_swim_S3_Lose_menu_88e64134:

    # Delilah "‘Butler’ is far too elegant a term for all the degrading stuff I intend to do to you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:204
translate chinese De_swim_S3_Lose_menu_a7fbb69d:

    # Delilah "Stand up straight for me and cross your hands in front of yourself. I want to feel like I’m being served by a man with some class."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:208
translate chinese De_swim_S3_Lose_menu_1a7cb244:

    # Delilah "That’s better."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:209
translate chinese De_swim_S3_Lose_menu_8ce1b423:

    # MC "(Ugh, so this is how it’s going to be.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:223
translate chinese De_swim_S3_Lose_menu_11dbcdb9:

    # MC "Is that a self portrait on the wall?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:224
translate chinese De_swim_S3_Lose_menu_5836605d:

    # Delilah "Yeah, daddy hired a professional photographer for my birthday last year."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:225
translate chinese De_swim_S3_Lose_menu_b59ba573:

    # MC "It’s... uh... very big."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:237
translate chinese De_swim_S3_Lose_menu_e5623514:

    # MC "Does anyone else live here with you?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:238
translate chinese De_swim_S3_Lose_menu_c745a47e:

    # Delilah "No, just me. Daddy bought the house for me because it was close to campus."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:239
translate chinese De_swim_S3_Lose_menu_4e866719:

    # MC "Huh, and how does he feel about you bringing guys back here?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:240
translate chinese De_swim_S3_Lose_menu_cc39642c:

    # Delilah "Pfft. He doesn’t know."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:241
translate chinese De_swim_S3_Lose_menu_929dc4e3:

    # Delilah "(Or care, for that matter... He’s never even visited once since I moved in.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:255
translate chinese De_swim_S3_Lose_menu_814a11de:

    # MC "So, what are you actually intending to do with me this evening? It doesn’t really look like you could be conjuring any worse than parading me around on a dog leash in the middle of campus."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:259
translate chinese De_swim_S3_Lose_menu_649ea5ac:

    # Delilah "That is a hard one to top, to be fair."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:260
translate chinese De_swim_S3_Lose_menu_61722410:

    # MC "Haha! Do you remember all those nerds raging about StorWors?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:261
translate chinese De_swim_S3_Lose_menu_bb041b5e:

    # Delilah "Ahaha! Oh my God! That was surreal. “It’s nOt a DeAtH StAR! It’S a StAr DeSTRoYeR!”"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:262
translate chinese De_swim_S3_Lose_menu_489e8983:

    # MC "Haha! God, you were fucking furious with me when I finally got my revenge. Do you remember when I walked you down the hall with the leash on?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:266
translate chinese De_swim_S3_Lose_menu_8962296b:

    # MC "So, what were you planning to do with me tonight?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:267
translate chinese De_swim_S3_Lose_menu_188248aa:

    # Delilah "Oh, lots of... stuff. Humiliating stuff. Totally degrading. You’ll be socially ruined."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:268
translate chinese De_swim_S3_Lose_menu_f6e4b451:

    # MC "Uh huh."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:285
translate chinese De_swim_S3_Lose_con_1d76be95:

    # Delilah "Hmm, so how should we begin... You know what? I really fancy a nice chai tea right now."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:286
translate chinese De_swim_S3_Lose_con_eab81206:

    # MC "Chai... tea? You don’t want me to strip naked and dance for you or something?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:287
translate chinese De_swim_S3_Lose_con_0f4a16d4:

    # Delilah "Do you want to strip naked and dance for me?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:288
translate chinese De_swim_S3_Lose_con_f73d5512:

    # MC "Not particularly."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:292
translate chinese De_swim_S3_Lose_con_f958fc9f:

    # Delilah "Then just a chai tea for now. Kitchen is through there. You’ll find everything you need in the cupboards on the lower left side."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:293
translate chinese De_swim_S3_Lose_con_f61ac73b:

    # MC "Uh... okay."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:294
translate chinese De_swim_S3_Lose_con_178d990f:

    # Delilah "C’mon, chop chop!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:298
translate chinese De_swim_S3_Lose_con_d7c1c5e4:

    # MC "(This is weird... When Delilah said she was going to make me her personal slave for the rest of the day, I was expecting her to use me like her personal sex toy.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:299
translate chinese De_swim_S3_Lose_con_01383307:

    # MC "(Being her barista was the last thing that came to mind!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:301
translate chinese De_swim_S3_Lose_con_36664583:

    # "*RING RING* *RING RING*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:302
translate chinese De_swim_S3_Lose_con_65d7a580:

    # Delilah "(Oh crap. Swim team again...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:306
translate chinese De_swim_S3_Lose_con_1e3aa560:

    # Delilah "*Sigh*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:308
translate chinese De_swim_S3_Lose_con_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:309
translate chinese De_swim_S3_Lose_con_9b79ebb3:

    # Delilah "Hiya bestie! Uh huh. Yeah. [player_name]’s here now."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:310
translate chinese De_swim_S3_Lose_con_f9f0070e:

    # Delilah "Uh huh. Yup. I got him in the kitchen making me a chai."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:311
translate chinese De_swim_S3_Lose_con_4a22df13:

    # Delilah "What’s that? Bekki’s there too? Oh! The whole swim team’s there? Hi guys!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:312
translate chinese De_swim_S3_Lose_con_d8f8a9b4:

    # Delilah "Oh, you all wanted to hear what I was doing with him tonight... That’s... great."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:313
translate chinese De_swim_S3_Lose_con_142641ea:

    # Delilah "Uh huh! Sure, I can keep you all on the line. Oh, hang on, I think he’s coming back."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:317
translate chinese De_swim_S3_Lose_con_772f0489:

    # MC "There you go, one chai tea."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:318
translate chinese De_swim_S3_Lose_con_93838d74:

    # Delilah "Yeah, he just brought me my chai there now. Uh huh. You really don’t have to stay on the call. I’m happy enough to-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:319
translate chinese De_swim_S3_Lose_con_cb578806:

    # Delilah "You want to stay on? Okay..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:323
translate chinese De_swim_S3_Lose_con_f6122029:

    # Delilah "What am I planning to make him do next? Uh, I was going to finish my tea first before-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:324
translate chinese De_swim_S3_Lose_con_2db6ac17:

    # Delilah "Ha! Y-Yeah, I could make him do that. That would be... That would certainly be... something! Haha!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:325
translate chinese De_swim_S3_Lose_con_2bebcc1e:

    # MC "(Who on Earth is she on the phone with? She’s clearly talking about me...)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:326
translate chinese De_swim_S3_Lose_con_cbaadc23:

    # Delilah "Y’know what, let’s work up to that, ladies. I’ve had a long day and need to relax first. [player_name], down on your knees. "
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:327
translate chinese De_swim_S3_Lose_con_6a472a23:

    # Delilah "Since you enjoyed it when I used my feet so much when you lost that bet, I think it’s only fair you repay me properly with a foot massage."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:328
translate chinese De_swim_S3_Lose_con_540b65bd:

    # MC "*Sigh* Fine."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:329
translate chinese De_swim_S3_Lose_con_7ff32357:

    # Delilah "Oh! That’s a good one. Yeah, I’ll tell him now."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:330
translate chinese De_swim_S3_Lose_con_bb5ab585:

    # Delilah "[player_name], start off by kissing them."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:334
translate chinese De_swim_S3_Lose_con_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:335
translate chinese De_swim_S3_Lose_con_66deaa71:

    # Delilah "Ahaha! Yeah, he’s totally doing it right now. The little twerp has his lips planted right up against the soles of my feet."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:336
translate chinese De_swim_S3_Lose_con_9323d91f:

    # Delilah "Mmm..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:337
translate chinese De_swim_S3_Lose_con_8acde9e3:

    # MC "(I knew just making her tea was too good to be true. She’s going to keep escalating things over the course of the night.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:341
translate chinese De_swim_S3_Lose_con_6dfd983d:

    # Delilah "I didn’t say you could stop, [player_name]. Keep kissing."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:342
translate chinese De_swim_S3_Lose_con_91169ac9:

    # Delilah "Yup. Anything I tell him until the end of the day. What else do I have planned? I... uh... I’m just making it up as I go along."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:343
translate chinese De_swim_S3_Lose_con_7f0c53e5_1:

    # MC "*Mwah*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:344
translate chinese De_swim_S3_Lose_con_b0c36b84:

    # MC "(There’s something different about Delilah today. She’s less... cruel than she normally is. And it looks like she’s actually enjoying herself right now.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:345
translate chinese De_swim_S3_Lose_con_ebaec90d:

    # Delilah "What do you mean “too tame”? I’m just building up to the good stuff! A girl just wants a nice tea and a foot massage sometimes, y’know?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:349
translate chinese De_swim_S3_Lose_con_9e91c380:

    # Delilah "Alright [player_name], enough of that. You can start massaging them now. Make sure you get every last spot. There’s a lot of tension down there."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:350
translate chinese De_swim_S3_Lose_con_438e3446:

    # MC "Fine."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:351
translate chinese De_swim_S3_Lose_con_e36d360f:

    # Delilah "Ooh, that’s a good one, Bekki. [player_name], I want you to call me ‘Mistress’ for the rest of the day."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:352
translate chinese De_swim_S3_Lose_con_60f7dbef:

    # Delilah "So, when I ask you to massage my feet, you reply..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:353
translate chinese De_swim_S3_Lose_con_bbad3f12:

    # MC "...yes, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:357
translate chinese De_swim_S3_Lose_con_97a0cdb2:

    # Delilah "Did you all hear that? Yeah, he said it. Haha! "
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:358
translate chinese De_swim_S3_Lose_con_bc9e1af0:

    # MC "(Y’know what? This isn’t actually too bad. Her friends are all on the phone, and there’s nobody else around to see me. Plus, I get to spend the evening playing with a hot girl’s feet. What’s not to love?!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:359
translate chinese De_swim_S3_Lose_con_c67f6d81:

    # Delilah "Mmm! That’s it. Use your thumbs more."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:363
translate chinese De_swim_S3_Lose_con_38b9d0fb:

    # MC "Yes, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:364
translate chinese De_swim_S3_Lose_con_a0016f67:

    # Delilah "Ooohh... That’s the spot right there."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:365
translate chinese De_swim_S3_Lose_con_cbd535f4:

    # MC "(Her feet are so soft. She must moisturise them regularly.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:369
translate chinese De_swim_S3_Lose_con_8cb03cc2:

    # Delilah "Uh huh. *Shlurp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:370
translate chinese De_swim_S3_Lose_con_323c4f30:

    # Delilah "Y’know, you ladies don’t have to stay on the line. I can just update you with what happened tomorrow."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:374
translate chinese De_swim_S3_Lose_con_9acec326:

    # Delilah "Well, of course I- Yeah- I get it. Fine, I’ll keep you on the line. What am I planning to do with him next? I haven’t finished my chai and foot massage yet-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:375
translate chinese De_swim_S3_Lose_con_68c41429:

    # Delilah "*Sigh* Well, yeah, I know you all want to know what’s going to happen next. I’m actually planning to... umm... have him cook me dinner."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:376
translate chinese De_swim_S3_Lose_con_ab2dc8a1:

    # Delilah "Yes, I said dinner. Why? Because I’m fucking famished! We practiced for three hours today, Bekki!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:377
translate chinese De_swim_S3_Lose_con_4a7f323e:

    # Delilah "[player_name], make me a home cooked meal."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:378
translate chinese De_swim_S3_Lose_con_63fdeab0:

    # MC "Uh... Like pasta or-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:379
translate chinese De_swim_S3_Lose_con_881394ea:

    # Delilah "No, I want a proper meal. A full roast dinner."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:380
translate chinese De_swim_S3_Lose_con_54824beb:

    # MC "That’ll take like two hours minimum!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:384
translate chinese De_swim_S3_Lose_con_33240eb0:

    # Delilah "Well, you better get started, because I’m already starving! You’ll find all the ingredients you need in the kitchen."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:385
translate chinese De_swim_S3_Lose_con_bc6e53f0:

    # MC "*Groan*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:386
translate chinese De_swim_S3_Lose_con_2b93a114:

    # Delilah "Ahem. Aren’t you forgetting something?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:387
translate chinese De_swim_S3_Lose_con_2b4bcb1f:

    # MC "*Sigh* Yes, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:388
translate chinese De_swim_S3_Lose_con_0be93b81:

    # Delilah "Good boy. See, it wasn't that hard?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:389
translate chinese De_swim_S3_Lose_con_56f8936a:

    # MC "(This is... unusual. If I had Delilah as my slave for a day I’d be having her fuck me until we ran out of positions from the Karma Sutra.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:393
translate chinese De_swim_S3_Lose_con_2d83de25:

    # Delilah "Yeah, I just sent him off to cook me dinner. It’s just us for a while now. Yeah, we can just chat shit while we wait."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:394
translate chinese De_swim_S3_Lose_con_4bd537fd:

    # Delilah "Uh huh."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:395
translate chinese De_swim_S3_Lose_con_b731cd20:

    # Delilah "Oooh. Really? She actually said that?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:399
translate chinese De_swim_S3_Lose_con_04b50409:

    # Delilah "...but only on Tuesday when we’re-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:400
translate chinese De_swim_S3_Lose_con_d60cfc00:

    # Delilah "What took you so long?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:401
translate chinese De_swim_S3_Lose_con_9f970bfa:

    # MC "I worked my ass off in there trying to put this meal together for you!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:402
translate chinese De_swim_S3_Lose_con_ed6e7846:

    # Delilah "Bring it over here. Sit down beside me and feed it to me."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:403
translate chinese De_swim_S3_Lose_con_f89a768a:

    # MC "You want me to- Ugh... Yes, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:404
translate chinese De_swim_S3_Lose_con_845c6489:

    # Delilah "Hang on ladies, he’s back. I’ll give you a call later after dinner."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:408
translate chinese De_swim_S3_Lose_con_9817f468:

    # Delilah "You uh, you still want to stay on the line? *Sigh* Alright."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:409
translate chinese De_swim_S3_Lose_con_896acced:

    # Delilah "(Huh, it doesn’t actually look that bad. [player_name]’s a decent cook after all.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:410
translate chinese De_swim_S3_Lose_con_5ab250ef:

    # Delilah "Yeah, keep talking ladies, I’m just having [player_name] feed me."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:414
translate chinese De_swim_S3_Lose_con_9323d91f_1:

    # Delilah "Mmm..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:415
translate chinese De_swim_S3_Lose_con_c9bd4f6e:

    # Delilah "(Fuck. This is incredible. How did he make something so tasty?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:416
translate chinese De_swim_S3_Lose_con_b7e9e610:

    # MC "Well? Does it meet your standards?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:417
translate chinese De_swim_S3_Lose_con_68981a48:

    # Delilah "Mmm hmm. It’s... acceptable."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:418
translate chinese De_swim_S3_Lose_con_9332b856:

    # MC "(I wonder what else she has planned for me, this really hasn’t been that humiliating of an evening at all.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:422
translate chinese De_swim_S3_Lose_con_9d566521:

    # Delilah "What?! OMG, no way?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:423
translate chinese De_swim_S3_Lose_con_bdb08855:

    # Delilah "Mr. Johnson has always been a bit of a pervert, but I wasn’t expecting that. Uh huh."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:424
translate chinese De_swim_S3_Lose_con_2577ae5f:

    # Delilah "[player_name], my neck’s getting stiff. Come around and rub my shoulders for me."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:425
translate chinese De_swim_S3_Lose_con_38b9d0fb_1:

    # MC "Yes, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:429
translate chinese De_swim_S3_Lose_con_1844fc79:

    # MC "How’s this? Do you want me to go a bit harder?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:430
translate chinese De_swim_S3_Lose_con_e4f29424:

    # Delilah "Mmm... Right there. Ah... Perfect! Mmm!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:434
translate chinese De_swim_S3_Lose_con_e9316bb9:

    # MC "Y’know, tonight honestly isn’t half as bad as I thought it was going to be. Maybe you’re not that bad of a person, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:435
translate chinese De_swim_S3_Lose_con_be283f1e:

    # Delilah "Hold on ladies, need to mute you for a second."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:437
translate chinese De_swim_S3_Lose_con_b8a7705e:

    # "*Beep*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:441
translate chinese De_swim_S3_Lose_con_819a9d61:

    # Delilah "Did I say you could speak, [player_name]? And I warned you against calling me Dee."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:442
translate chinese De_swim_S3_Lose_con_4e5e4b68:

    # MC "Aw, c’mon. Don’t tell me you’re not enjoying this too. It’s nice to take a step back from hating each other and just relax like this, right?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:443
translate chinese De_swim_S3_Lose_con_fce69340:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:444
translate chinese De_swim_S3_Lose_con_c1262108:

    # Delilah "You’re still talking."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:445
translate chinese De_swim_S3_Lose_con_c9ac68ab:

    # MC "I’m just saying, you could probably have a happier life if you were a nicer person. Maybe even find yourself a guy who could enjoy being with you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:446
translate chinese De_swim_S3_Lose_con_e8f89139:

    # MC "I think it says a lot that you have the opportunity to do whatever you want with me. You could have had me do literally ANYTHING to you, and yet all you asked for was a home cooked dinner and a massage."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:447
translate chinese De_swim_S3_Lose_con_cb9fccc5:

    # Delilah "(He’s not wrong... How did I not notice this myself?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:451
translate chinese De_swim_S3_Lose_con_cc968cf9:

    # MC "I think, deep down, you’re just a bit lonely and-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:452
translate chinese De_swim_S3_Lose_con_c566c7ef:

    # Delilah "Alright, ENOUGH! You’ve been spending way too much time with that psychotherapist Judy. I’m going to lie down so you can massage my back."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:453
translate chinese De_swim_S3_Lose_con_ca2a6c32:

    # MC "Delilah, maybe you-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:454
translate chinese De_swim_S3_Lose_con_25cf26fb:

    # Delilah "We are NOT talking about this."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:455
translate chinese De_swim_S3_Lose_con_13a21dc9:

    # MC "Alright..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:459
translate chinese De_swim_S3_Lose_con_251cb02b:

    # Delilah "Ahh..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:461
translate chinese De_swim_S3_Lose_con_b8a7705e_1:

    # "*Beep*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:462
translate chinese De_swim_S3_Lose_con_d5b56540:

    # Delilah "Sorry, ladies, back now. Uh huh. No, I just needed to sort something out. Uh huh, he’s massaging my back now."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:463
translate chinese De_swim_S3_Lose_con_2b5c9ec5:

    # MC "I mean, perhaps what you’re longing for isn’t to be the most popular girl on campus, Dee - but rather to have a genuine emotional connection with-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:464
translate chinese De_swim_S3_Lose_con_c9918a60:

    # Delilah "*Groan* Hold on again, ladies."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:466
translate chinese De_swim_S3_Lose_con_b8a7705e_2:

    # "*Beep*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:467
translate chinese De_swim_S3_Lose_con_afab4f57:

    # Delilah "Three points, [player_name]. One, I’m on the phone. Two, I said we’re not talking about this anymore. And three, if you call me “Dee” instead of “Mistress” one more fucking time, I’m going to kick you in the balls. Are we clear?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:471
translate chinese De_swim_S3_Lose_con_cae546c1:

    # MC "*Sigh* Sorry, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:472
translate chinese De_swim_S3_Lose_con_821b263f:

    # MC "(I was actually kinda hoping I’d gotten through to her there.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:473
translate chinese De_swim_S3_Lose_con_3da6ce81:

    # MC "(There was a brief moment when she was holding her breath and I think she may have realised that simply by asking for a massage and dinner, she was letting on far more than she intended me to know.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:474
translate chinese De_swim_S3_Lose_con_46944ed2:

    # Delilah "(Ugh... It’s even worse now that he’s quiet. The silence is only making things more awkward. Right, I can’t let this evening end with him thinking I’m some needy, lonely loser.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:476
translate chinese De_swim_S3_Lose_con_b8a7705e_3:

    # "*Beep*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:477
translate chinese De_swim_S3_Lose_con_0546e29f:

    # Delilah "Sorry, got cut off again there. Yeah. Mmm! Yeah, he’s not actually that bad with his fingers. The Thai massage place is definitely better though."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:478
translate chinese De_swim_S3_Lose_con_d5d9430b:

    # Delilah "Nah, I’d rather not tonight. I’m enjoying the massag-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:479
translate chinese De_swim_S3_Lose_con_66f5f243:

    # Delilah "Yeah, but-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:480
translate chinese De_swim_S3_Lose_con_0718081f:

    # Delilah "*Sigh* Well, of course, I mean, why else would I have asked him to be my slave unless I was planning to make him do that?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:481
translate chinese De_swim_S3_Lose_con_d794d3e0:

    # Delilah "(Argh... Fuck you, Bekki.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:482
translate chinese De_swim_S3_Lose_con_513d9882:

    # Delilah "Right - hop off, [player_name]. I’ve had enough."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:486
translate chinese De_swim_S3_Lose_con_66d5bca0:

    # Delilah "We’re going to spice things up a bit now, [player_name]. On your knees. Now."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:487
translate chinese De_swim_S3_Lose_con_6fe339b6:

    # Delilah "Uh huh, that’s right Bekki."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:488
translate chinese De_swim_S3_Lose_con_27087ea4:

    # MC "(Huh, I wonder what she’s got in mind.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:492
translate chinese De_swim_S3_Lose_con_1d1408e1:

    # Delilah "Are you enjoying the view, [player_name]?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:493
translate chinese De_swim_S3_Lose_con_4093ded2:

    # MC "I’m certainly not complaining, if that’s what you’re asking, Mistress."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:494
translate chinese De_swim_S3_Lose_con_5520cf9d:

    # MC "(What is she up to?)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:498
translate chinese De_swim_S3_Lose_con_4094b558:

    # Delilah "Uh huh, I’m just about to start now. Tell Hira to be patient!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:499
translate chinese De_swim_S3_Lose_con_2f60ddc6:

    # Delilah "Haha, OF COURSE I will, I just need to wait for the perfect moment.."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:503
translate chinese De_swim_S3_Lose_con_6e1bba00:

    # MC "What... uh... What exactly do you want me to do, Mistress?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:504
translate chinese De_swim_S3_Lose_con_77d028e5:

    # Delilah "Nothing, until I tell you to."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:505
translate chinese De_swim_S3_Lose_con_eb19fb2c:

    # MC "Err, okay..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:511
translate chinese De_swim_S3_Lose_con_e83e51f3:

    # Delilah "Are you enjoying looking at my ass, [player_name]?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:512
translate chinese De_swim_S3_Lose_con_8e6d05a0:

    # MC "Of course I am - what guy wouldn’t?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:513
translate chinese De_swim_S3_Lose_con_5d85c019:

    # Delilah "Perhaps you’d have a better view if I took these out of the way."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:517
translate chinese De_swim_S3_Lose_con_5e0b4064:

    # MC "(I’m not sure what Delilah is playing at, but I don’t really feel like her slave right now.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:518
translate chinese De_swim_S3_Lose_con_57a7a34e:

    # Delilah "You want to fuck me so badly, don’t you, [player_name]?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:522
translate chinese De_swim_S3_Lose_con_83be8dbe:

    # Delilah "You’d love to shove your fat cock right into my tight asshole, wouldn’t you?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:523
translate chinese De_swim_S3_Lose_con_ad8c714e:

    # MC "(Is she actually inviting me to fuck her in the ass tonight?!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:524
translate chinese De_swim_S3_Lose_con_d7f23ecb:

    # MC "Uh, y-yeah, I would, Mistress!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:528
translate chinese De_swim_S3_Lose_con_4af2321d:

    # Delilah "Well, that’s unfortunate, because you’re not going to be getting anywhere near it tonight."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:529
translate chinese De_swim_S3_Lose_con_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:530
translate chinese De_swim_S3_Lose_con_b4518421:

    # Delilah "You’re going to be eating my pussy. Consider it payback for what happened after our last bet."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:531
translate chinese De_swim_S3_Lose_con_57d371aa:

    # Delilah "For God’s sake! I already told you Bekki, I’m not talking about what happened at the last bet. Use your fucking imagination if you have to."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:535
translate chinese De_swim_S3_Lose_con_4f709e9a:

    # MC "Wait, your friends are still on the phone?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:536
translate chinese De_swim_S3_Lose_con_b7024fc8:

    # Delilah "(Unfortunately so.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:537
translate chinese De_swim_S3_Lose_con_428cfad8:

    # Delilah "Of course they are! They’re all dying to hear just how good you are at giving oral. Maybe I’ll share you with them if you’re good enough. You could be the swim team’s own private pussy eater."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:541
translate chinese De_swim_S3_Lose_con_2bfef090:

    # MC "(Her pussy looks amazing. I should probably focus on her clitoris. If I make her cum hard enough, maybe she’ll be horny enough to fuck me?)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:542
translate chinese De_swim_S3_Lose_con_4b23de10:

    # Delilah "You’re stalling, [player_name]. Get to work."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:543
translate chinese De_swim_S3_Lose_con_9cef5554:

    # MC "Sorry, Mistre-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:547
translate chinese De_swim_S3_Lose_con_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:548
translate chinese De_swim_S3_Lose_con_a393ee30:

    # MC "(She just wrapped her legs around my head and pulled me in!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:549
translate chinese De_swim_S3_Lose_con_aaef7f3b:

    # Delilah "C’mon! Put some effort into it! I didn’t slack off when I lost our last bet."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:550
translate chinese De_swim_S3_Lose_con_280687d1:

    # MC "*Lick* *Slurp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:551
translate chinese De_swim_S3_Lose_con_4fa1ffab:

    # Delilah "Ooohh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:555
translate chinese De_swim_S3_Lose_con_58a42465:

    # MC "*Shlurp* *Suck* Lick*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:556
translate chinese De_swim_S3_Lose_con_c9c8ded9:

    # Delilah "Ooohhh! Ahhmmmm! Ugh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:557
translate chinese De_swim_S3_Lose_con_5477ba45:

    # Delilah "It’s a shame you guys aren’t here to - aahhh - see this. Mmm! He’s good at this. Oooh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:558
translate chinese De_swim_S3_Lose_con_a5401cdc:

    # Delilah "Ohh! Do I really have to? Can’t I just enjoy the moment? Uh fine. Yeah, hold on."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:562
translate chinese De_swim_S3_Lose_con_65eccabb:

    # Delilah "Mmm! Don’t stop licking me there! Ah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:564
translate chinese De_swim_S3_Lose_con_09d06ab8_1:

    # "*Click*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:565
translate chinese De_swim_S3_Lose_con_93abd652:

    # MC "*Shlurp* *Lick*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:568
translate chinese De_swim_S3_Lose_con_ae444875:

    # "*Flash*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:569
translate chinese De_swim_S3_Lose_con_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:570
translate chinese De_swim_S3_Lose_con_0a5000e5:

    # MC "(I can feel her clit getting stiffer! She’s absolutely loving this right now!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:574
translate chinese De_swim_S3_Lose_con_84d72400:

    # Delilah "Ah! Ohhh! I’ve mmm sent it now! What do you think? It’s good, right?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:578
translate chinese De_swim_S3_Lose_con_387b72ea:

    # MC "*Lick* *Shlurp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:579
translate chinese De_swim_S3_Lose_con_e22cacff:

    # MC "(What on Earth is she talking about?)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:583
translate chinese De_swim_S3_Lose_con_e6c42e95:

    # Delilah "Oooh! Fuuuuck... Mmm!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:587
translate chinese De_swim_S3_Lose_con_86e9a1be:

    # Delilah "(Damn, [player_name] is good with his tongue! He doesn’t miss a spot!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:591
translate chinese De_swim_S3_Lose_con_e7c2723d:

    # Delilah "*Gasp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:595
translate chinese De_swim_S3_Lose_con_280687d1_1:

    # MC "*Lick* *Slurp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:599
translate chinese De_swim_S3_Lose_con_93abd652_1:

    # MC "*Shlurp* *Lick*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:603
translate chinese De_swim_S3_Lose_con_354cba58:

    # Delilah "Ah! Yes! Yes, just like that! Don’t stop!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:607
translate chinese De_swim_S3_Lose_con_b0d62d51:

    # MC "*Shlurp* *Suck* *Lick*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:611
translate chinese De_swim_S3_Lose_con_f75f4bc3:

    # MC "(Her legs are tightening around the back of my head! I think she’s about to cum!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:615
translate chinese De_swim_S3_Lose_con_d1b8a8a0:

    # Delilah "Oh my God! Yes! Ooohhhh fuuuuccck! Aaahhhh!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:616
translate chinese De_swim_S3_Lose_con_ccac5508:

    # Delilah "(It’s a shame I only have him for tonight. His tongue is WAY better than any of my toys!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:617
translate chinese De_swim_S3_Lose_con_b6bbcfee:

    # MC "(I can’t believe she’s letting her friends listen in on everything that’s going on!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:618
translate chinese De_swim_S3_Lose_con_6b73a5ed:

    # Delilah "Oh my God! I’m getting close! Ah! Don’t stop! Ah! Just like that! AAHHHH!!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:622
translate chinese De_swim_S3_Lose_con_280687d1_2:

    # MC "*Lick* *Slurp*"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:623
translate chinese De_swim_S3_Lose_con_2daf082c:

    # Delilah "I’m cummmiiinnngg! AAAHHHHH!!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:624
translate chinese De_swim_S3_Lose_con_b4ca127d:

    # MC "(Holy crap! I can feel her whole body shaking, right now! She’s losing it!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:625
translate chinese De_swim_S3_Lose_con_afa9910f:

    # Delilah "Ahhhh... Haaah... *Pant* Wow!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:629
translate chinese De_swim_S3_Lose_con_be99438e:

    # Delilah "Haah... *Pant* That was... *Gasp* ...incredible."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:630
translate chinese De_swim_S3_Lose_con_697c7e4a:

    # Delilah "Did you hear that *pant* ladies? Uh huh! Yeah. I know, right? Great angle."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:631
translate chinese De_swim_S3_Lose_con_b4139d0a:

    # MC "Great angle? What do you mean?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:635
translate chinese De_swim_S3_Lose_con_17e40740:

    # Delilah "Heh... You’ll find out soon enough."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:636
translate chinese De_swim_S3_Lose_con_b93511a0:

    # Delilah "I’m done for the night. You’re free to go."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:637
translate chinese De_swim_S3_Lose_con_a2df2d2a:

    # MC "Wait, already?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:638
translate chinese De_swim_S3_Lose_con_bad5caa5:

    # Delilah "Uh huh. Door is that way."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:642
translate chinese De_swim_S3_Lose_con_71fa1316:

    # MC "(Huh, I was genuinely expecting her to do more to embarrass me than that. All of the bets we have pulled on each other so far, have involved public humiliation.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:643
translate chinese De_swim_S3_Lose_con_bf5e0cfb:

    # MC "(It just seems really out of character for Delilah to have me lick her pussy and then just leave.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:675
translate chinese De_swim_S3_Win_87a2d89b:

    # MC "Hah! *Pant* I won! In your face!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:676
translate chinese De_swim_S3_Win_06b425d9:

    # Delilah "(Oh my God... How did this happen again? How did some guy who never even joined the swim club manage to beat me?)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:677
translate chinese De_swim_S3_Win_cc1f62e4:

    # Delilah "(It’s over. He’s going to screw me - and there’s nothing I can do. I shouldn’t have been so arrogant when I was making those bets.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:681
translate chinese De_swim_S3_Win_1a461fce:

    # MC "I hope you’re ready, Delilah. I might have been the one who won the bet, but I think you’re going to enjoy this just as much as I am."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:682
translate chinese De_swim_S3_Win_fce69340:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:683
translate chinese De_swim_S3_Win_9faea50b:

    # MC "What’s wrong? Not got any witty comeback for me?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:686
translate chinese De_swim_S3_Win_fce69340_1:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:687
translate chinese De_swim_S3_Win_076356cd:

    # MC "Silence works well for you. Nice for a change."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:688
translate chinese De_swim_S3_Win_61676c0b:

    # MC "Any preferences on where we do this? Your place? Mine? Heck, the changing rooms would do just fine for me!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:696
translate chinese De_swim_S3_Win_f238b952:

    # MC "(Huh, that’s unusual. She just turned and walked into the changing rooms without uttering a word.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:697
translate chinese De_swim_S3_Win_e23fc141:

    # MC "Uh, you okay there, Delilah?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:698
translate chinese De_swim_S3_Win_fce69340_2:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:699
translate chinese De_swim_S3_Win_31f80ac1:

    # Delilah "Well? What are you waiting for? You won, didn’t you?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:703
translate chinese De_swim_S3_Win_ee6d0390:

    # MC "Awesome! Let’s start by getting you out of this swimsuit."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:704
translate chinese De_swim_S3_Win_76768be5:

    # Delilah "(Grrr... I fucking hate you, [player_name].)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:705
translate chinese De_swim_S3_Win_41e084c5:

    # Delilah "(I spend YEARS practicing, exercising, waking up at the crack of dawn - and suddenly YOU with ZERO experience somehow beat me! You’re SUPPOSED to be a loser who got humiliated by his professor!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:709
translate chinese De_swim_S3_Win_736693cf:

    # MC "Heh! Your tits are amazing!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:710
translate chinese De_swim_S3_Win_fce69340_3:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:711
translate chinese De_swim_S3_Win_d9d48f1b:

    # MC "Still giving me the silent treatment, eh? We’ll see how long that lasts for when I start fucking you. I bet you’ll be moaning and screaming so loudly, the whole campus will hear you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:715
translate chinese De_swim_S3_Win_39042aaa:

    # Delilah "(As if. Your pathetic cock couldn’t possibly make me scream.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:716
translate chinese De_swim_S3_Win_cbaf205a:

    # MC "Oh c’mon, not even a little banter? Gee, I must have REALLY pissed you off! Haha!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:717
translate chinese De_swim_S3_Win_9913cea6:

    # MC "Alright, let’s get you back on the bench. Face up. I want to see your eyes as I plunge my cock in and take your virginity."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:721
translate chinese De_swim_S3_Win_d50b4a52:

    # MC "Just like that. Perfect. Heh, you’re blushing right now, you know that?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:722
translate chinese De_swim_S3_Win_497e9f85:

    # Delilah "(I hate you so fucking much. Nerds and dorks like you are the scum of the campus.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:723
translate chinese De_swim_S3_Win_fce69340_4:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:727
translate chinese De_swim_S3_Win_c44e5cee:

    # MC "Don’t worry, I’ll be gentle at the start. Just because you lost the bet doesn’t mean I’m going to hurt you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:728
translate chinese De_swim_S3_Win_925e92ce:

    # Delilah "(Ugh, I don’t need your fucking pity.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:729
translate chinese De_swim_S3_Win_e35fb2b4:

    # MC "I was wondering whether or not I should have brought lube with me, but I’m going to take a gamble that you’re already soaking wet."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:730
translate chinese De_swim_S3_Win_f294f819:

    # MC "You see, I remember how horny you got the last time you lost a bet and had to suck my cock. You crumbled into a horny slut SO quickly."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:731
translate chinese De_swim_S3_Win_1258fb3a:

    # Delilah "(Bullshit.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:735
translate chinese De_swim_S3_Win_3e61cbe7:

    # MC "So, I’m going to guess you’re JUST as horny right now."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:736
translate chinese De_swim_S3_Win_55ad7ad3:

    # Delilah "(No way! I’m not getting turned on by-)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:740
translate chinese De_swim_S3_Win_b90a88d9:

    # Delilah "...ah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:744
translate chinese De_swim_S3_Win_8e760d1f:

    # MC "Huh, I was right. Your pussy is drenched right now. It’s going to be so easy to slide my dick in."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:745
translate chinese De_swim_S3_Win_6fa59c1a:

    # Delilah "*Pant* ..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:746
translate chinese De_swim_S3_Win_d87bf802:

    # MC "Perhaps you’d like to admit that you’re excited to have my cock buried deep inside you?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:747
translate chinese De_swim_S3_Win_51e21a8f:

    # Delilah "(No way!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:755
translate chinese De_swim_S3_Win_80f51ea6:

    # Delilah "...aahhh.... Hmmmmm!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:756
translate chinese De_swim_S3_Win_e104535d:

    # MC "God, you’re really fucking tight. I think I can feel my dick pushing up against your hymen."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:757
translate chinese De_swim_S3_Win_88ee5208:

    # Delilah "Hah... Ah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:761
translate chinese De_swim_S3_Win_ec7ad1b1:

    # MC "I’m going to guess that you’re enjoying this now, given that you’re starting to moan a bit."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:762
translate chinese De_swim_S3_Win_8f3c7145:

    # Delilah "...ah... *Pant* ... In your dreams, creep..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:763
translate chinese De_swim_S3_Win_2fb4b8fc:

    # MC "Ah, you’re not mute after all! I’m going to take your virginity now, Delilah. This might sting for a second."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:767
translate chinese De_swim_S3_Win_b90a88d9_1:

    # Delilah "...ah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:771
translate chinese De_swim_S3_Win_02a2b333:

    # MC "Hnng!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:772
translate chinese De_swim_S3_Win_8b0299ab:

    # Delilah "Ah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:776
translate chinese De_swim_S3_Win_8fb25cb2:

    # MC "Goddamn, your pussy feels amazing. I should have known that from the first minute I saw you standing by the pool."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:780
translate chinese De_swim_S3_Win_d236240f:

    # Delilah "*Pant* W-Wait, you need a condom!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:781
translate chinese De_swim_S3_Win_7d5566b9:

    # MC "We never said anything about condoms when you agreed to the bet!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:785
translate chinese De_swim_S3_Win_80f51ea6_1:

    # Delilah "...aahhh.... Hmmmmm!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:789
translate chinese De_swim_S3_Win_940894a2:

    # Delilah "Hold on, are you planning on finishing INSIDE me?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:790
translate chinese De_swim_S3_Win_cc79ffb2:

    # MC "Maybe? I haven’t decided yet."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:791
translate chinese De_swim_S3_Win_7d8ffb40:

    # Delilah "You can’t finish inside me without a condom!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:795
translate chinese De_swim_S3_Win_d25508e8:

    # MC "How about we make one final bet? You let me fuck you until the lunch bell rings. If you cum then I get to cum WHEREVER I want without a condom."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:796
translate chinese De_swim_S3_Win_4b00de93:

    # Delilah "And if I win?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:797
translate chinese De_swim_S3_Win_fc1603f3:

    # MC "If you last until the lunch bell rings without cumming then I’ll finish into a condom. "
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:801
translate chinese De_swim_S3_Win_7b2399f1:

    # Delilah "*Pant* ...deal. But if you cum, before the lunch bell, I swear to God I will fucking kill you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:802
translate chinese De_swim_S3_Win_550a1d75:

    # MC "Haha, you’re really sexy when you get angry."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:806
translate chinese De_swim_S3_Win_ea36730b:

    # MC "Hnng! Ugh! "
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:807
translate chinese De_swim_S3_Win_d53cf202:

    # Delilah "Ah... Hah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:808
translate chinese De_swim_S3_Win_53eaf98f:

    # MC "Sounds like you’re enjoying yourself there, Delilah. Perhaps I should start thrusting a bit deeper?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:809
translate chinese De_swim_S3_Win_e71c788c:

    # Delilah "W-Wait-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:813
translate chinese De_swim_S3_Win_02a2b333_1:

    # MC "Hnng!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:817
translate chinese De_swim_S3_Win_dd1f270e:

    # Delilah "*Gasp* Oooh!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:818
translate chinese De_swim_S3_Win_365d1474:

    # MC "Oh, did someone just cum?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:819
translate chinese De_swim_S3_Win_6ca1d302:

    # Delilah "Haaah! N-No! You’re just so bi- ..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:823
translate chinese De_swim_S3_Win_9ccd335d:

    # MC "Hnng! Ugh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:827
translate chinese De_swim_S3_Win_660e3ec9:

    # MC "So “what”, Delilah? How were you intending to finish that sentence?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:828
translate chinese De_swim_S3_Win_fce69340_5:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:829
translate chinese De_swim_S3_Win_d03d23d3:

    # MC "So BIG perhaps? Ahaha!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:830
translate chinese De_swim_S3_Win_a835fe13:

    # Delilah "Fuck you, dork. You’re still just the LOSER who *Gasp* tried asking out- ooohh... M-Ms. Celiaaahhh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:834
translate chinese De_swim_S3_Win_88ee5208_1:

    # Delilah "Hah... Ah..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:838
translate chinese De_swim_S3_Win_4895df77:

    # MC "Uh huh. It really sounds like you’re struggling not to cum from this loser’s cock, buried deep in your pussy."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:839
translate chinese De_swim_S3_Win_7ff7ae70:

    # Delilah "Ahh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:845
translate chinese De_swim_S3_Win_fa53d3d2:

    # Delilah "(Shit! It’s taking all my willpower to try and not cum right now! Why the fuck does this dork’s dick feel so good?!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:846
translate chinese De_swim_S3_Win_1e8971f6:

    # MC "Alright, let’s switch things up a bit, Delilah. Get on all fours - we'll do some doggy-style."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:850
translate chinese De_swim_S3_Win_63db73cb:

    # MC "(I can hardly believe that Delilah went so long without letting a guy fuck her pussy. Not that I’m complaining - she’s REALLY tight!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:851
translate chinese De_swim_S3_Win_6c21b6d3:

    # MC "(I bet her butt is even tighter, just look at how puckered her asshole is. It must feel heavenly to plunge a dick in there.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:852
translate chinese De_swim_S3_Win_6402090e:

    # Delilah "What’s wrong, loser? Too afraid to continue?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:856
translate chinese De_swim_S3_Win_1c982ff1:

    # MC "I was just admiring the view, but if you’re that eager to get going again, then I’m happy to oblige."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:857
translate chinese De_swim_S3_Win_141b5b78:

    # MC "(I should be hitting her g-spot more from this angle. If I do this right, she’ll be cumming in no time at all, and I’ll be able to properly creampie her.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:861
translate chinese De_swim_S3_Win_1e7a59bb:

    # MC "(Hmm, I wonder if she’s even on birth control. I doubt it. Especially if she wasn’t intending on having sex with any guys.)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:862
translate chinese De_swim_S3_Win_fe589e67:

    # MC "(If she had any common sense she would have taken some precautions before our bet. Her own arrogance may have cost her more than she realises!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:863
translate chinese De_swim_S3_Win_40c03e48:

    # Delilah "(Okay, Dee. You can do this. Focus on your breathing. It can’t be much longer until the lunch bell rings. All you have to do is endure a bit longer.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:864
translate chinese De_swim_S3_Win_1e970f2d:

    # Delilah "Do your worst, [player_name]. You’re never going to make me c-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:872
translate chinese De_swim_S3_Win_f5019681:

    # Delilah "-OOHHHHH!!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:873
translate chinese De_swim_S3_Win_574fdf99:

    # MC "Ugh! Mmm!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:874
translate chinese De_swim_S3_Win_ca311083:

    # Delilah "(Holy crap! It’s SO much more intense from this angle!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:882
translate chinese De_swim_S3_Win_01ba5e23:

    # MC "Haha! Having some trouble there, Dee?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:883
translate chinese De_swim_S3_Win_946faf67:

    # Delilah "Arrrghh! I already told you - o-only my friends *gasp* get to call me, *Pant* Dee!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:884
translate chinese De_swim_S3_Win_0b5746db:

    # MC "Uh huh. Sure."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:888
translate chinese De_swim_S3_Win_8b946d63:

    # Delilah "*Pant* Ohhh! Ah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:892
translate chinese De_swim_S3_Win_7b6708f7:

    # Delilah "Arrgh! God, I fucking hate you! Ooohh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:893
translate chinese De_swim_S3_Win_7eb0c238:

    # MC "With the way you’re moaning, it’s hard to believe that you actually do."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:894
translate chinese De_swim_S3_Win_098fad94:

    # Delilah "Ohh! Haah!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:902
translate chinese De_swim_S3_Win_472b9f72:

    # Delilah "(Fuck! Pull yourself together, Delilah! You can’t let this bastard make you cum!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:903
translate chinese De_swim_S3_Win_7a65a144:

    # MC "I bet you’ve secretly wanted this since we made our first bet, Dee. I mean, what kind of woman bets her own body unless a part of her secretly wants to be fu-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:904
translate chinese De_swim_S3_Win_f319e542:

    # Delilah "No! Ah! That’s n-not true! Oooh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:908
translate chinese De_swim_S3_Win_7ab5001b:

    # MC "Of course it is! You’re just a horny slut who got turned on by the thought of betting your body. I don’t think these games we’ve been playing have EVER been about you humiliating me or trying to put me in my place."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:912
translate chinese De_swim_S3_Win_d5a89941:

    # Delilah "Ah! Ahnnnnnggg!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:913
translate chinese De_swim_S3_Win_1674530b:

    # MC "Deep down, what you’ve always wanted is the thrill that you MIGHT lose. You didn’t do all this to humiliate me, you did it because you wanted the risk of being humiliated yourself."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:914
translate chinese De_swim_S3_Win_439123c5:

    # Delilah "Nooooohhh! *Pant* Aaaahhhh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:922
translate chinese De_swim_S3_Win_1cc2a4a1:

    # Delilah "Oooh fuuucck!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:926
translate chinese De_swim_S3_Win_011f626d:

    # Delilah "(Holy shit! He’s ramming his cock so deep!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:927
translate chinese De_swim_S3_Win_5af59f66:

    # MC "I remember how wet you got when I made you ugh... suck my cock in front of those guys. That all but confirmed hnnng... my suspicions."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:935
translate chinese De_swim_S3_Win_c2359418:

    # Delilah "*Pant* Oh! Ah! Ahh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:939
translate chinese De_swim_S3_Win_f6ee394f:

    # MC "Go on, cum for me."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:940
translate chinese De_swim_S3_Win_23bc9075:

    # Delilah "Ahhnnnnngg! N-Nooohh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:948
translate chinese De_swim_S3_Win_db0fecdf:

    # MC "I know you won’t be able to resist my cock for much longer, Dee. Can you feel it slamming deep into your dripping wet cunt?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:949
translate chinese De_swim_S3_Win_066b83fd:

    # Delilah "Ahhhh! Haaahhhh! Aahnnnggg! I’m noooohht g-gonna c-cum!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:950
translate chinese De_swim_S3_Win_2d150f24:

    # Delilah "(Why does this feel so fucking good?! This bastard humiliated me, ruined my reputation across the entire campus - and SOMEHOW I’m hornier than I’ve ever been in my entire life. None of this makes any fucking sense!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:954
translate chinese De_swim_S3_Win_a901beb7:

    # MC "Hnng! Ah! God, I could pound your tight pussy all day. I can’t wait until you cum, because the second you do, I’m going to empty my balls deep in your unprotected pussy."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:955
translate chinese De_swim_S3_Win_3fcec9c5:

    # Delilah "Noohh... Ooohhhh!! Aaahhhhh! *Gasp*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:956
translate chinese De_swim_S3_Win_c1c74c4b:

    # MC "Cum for me, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:957
translate chinese De_swim_S3_Win_29dbb07c:

    # Delilah "*Gasp* N-No!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:961
translate chinese De_swim_S3_Win_7776709d:

    # MC "Cum for me!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:962
translate chinese De_swim_S3_Win_28c916ca:

    # Delilah "No, I-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:966
translate chinese De_swim_S3_Win_7776709d_1:

    # MC "Cum for me!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:967
translate chinese De_swim_S3_Win_f6cbbe60:

    # Delilah "Nooohhh! Ayaaahhhhh!!!!! I’m cummmmiiinnngg!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:968
translate chinese De_swim_S3_Win_fdead737:

    # MC "(I can feel her pussy clamping down around my dick! She’s definitely cumming hard!)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:977
translate chinese De_swim_S3_Win_81e81931:

    # Delilah "Aaaahhh!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:978
translate chinese De_swim_S3_Win_e8220154:

    # Delilah "(Shit! I can’t stop myself! [player_name]’s cock feels so fucking good!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:979
translate chinese De_swim_S3_Win_d981ceef:

    # MC "Sorry Dee, y’lost! Hnnngg!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:980
translate chinese De_swim_S3_Win_f53e4a75:

    # MC "(I’m about to cum. Should I paint her insides? Or pull out and show her a little bit of mercy?)"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:986
translate chinese De_swim_S3_Win_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:987
translate chinese De_swim_S3_Win_fe0e2f3b:

    # Delilah "H-Huh?! W-Wait, c-condom, you-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:988
translate chinese De_swim_S3_Win_57c90a49:

    # MC "You lost the bet, Dee! HNNNGG!!! Enjoy your first ever creampie!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:989
translate chinese De_swim_S3_Win_9f6ac8df:

    # Delilah "Nooooooo!! I told you I’m not on birth control, you idiot!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:994
translate chinese De_swim_S3_Win_0d6653ce:

    # Delilah "Pull out! Pull it-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:995
translate chinese De_swim_S3_Win_0c547d0f:

    # MC "AAHHHH!!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:996
translate chinese De_swim_S3_Win_75a01dab:

    # Delilah "NOOO!!!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:997
translate chinese De_swim_S3_Win_d4887927:

    # Delilah "(Oh God! I can feel his cock pulsating deep inside me! Something hot is blasting up against my cervix! He’s actually cumming inside me!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1007
translate chinese De_swim_S3_Win_bd179162:

    # MC "*Pant* Ha... Wow! That was... *Pant* fucking amazing."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1008
translate chinese De_swim_S3_Win_6c0ac508:

    # Delilah "You idiot! You just came inside me!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1009
translate chinese De_swim_S3_Win_a4e84415:

    # MC "Fuuuuuck, that was mmm... perfect!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1013
translate chinese De_swim_S3_Win_5dfa9392:

    # Delilah "I... I can’t believe you ACTUALLY did that!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1014
translate chinese De_swim_S3_Win_6bb008b9:

    # MC "You lost the bet, fair and square. Just like you lost every other bet we made."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1015
translate chinese De_swim_S3_Win_5e6c0c14:

    # Delilah "Grr..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1019
translate chinese De_swim_S3_Win_cb93545a:

    # Delilah "I’m fucking done with you. You made me look weak in front of my swim team, you humiliated me in front of those fucking nerds!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1020
translate chinese De_swim_S3_Win_2808600e:

    # Delilah "And now you had the AUDACITY to not only take my virginity, but also cum INSIDE my pussy too! Are you proud of yourself?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1021
translate chinese De_swim_S3_Win_8469a362:

    # MC "Immensely. But I know that you enjoyed it as well."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1022
translate chinese De_swim_S3_Win_7c16d6d6:

    # Delilah "I did not!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1023
translate chinese De_swim_S3_Win_e7081698:

    # MC "In fact, I think you’ve been enjoying A LOT more of our time together than you’ve been letting on."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1024
translate chinese De_swim_S3_Win_fce69340_6:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1025
translate chinese De_swim_S3_Win_affc4761:

    # MC "Think back to that day when you made me your personal slave. You didn’t even make me do anything even REMOTELY sexual for most of the day. And you didn’t even try to humiliate me that much."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1026
translate chinese De_swim_S3_Win_4d126198:

    # Delilah "Shut up."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1027
translate chinese De_swim_S3_Win_6842923a:

    # MC "What did you ask for? A cup of tea, a home cooked meal, and a back massage? I think that, more than anything, you wanted the illusion of having someone who actually loved and cared for you in your life."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1028
translate chinese De_swim_S3_Win_4601f5a9:

    # Delilah "I told you to shut up!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1029
translate chinese De_swim_S3_Win_080cfa3c:

    # MC "When we started making those bets I figured that you enjoyed being humiliated as much as I did but it’s deeper than that, isn’t it?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1030
translate chinese De_swim_S3_Win_d0e3ecb3:

    # MC " I think you were just looking for a genuine connection with someone who knew what you were like when you were at your most vulnerable."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1031
translate chinese De_swim_S3_Win_66614fac:

    # Delilah "SHUT IT!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1032
translate chinese De_swim_S3_Win_b550ac86:

    # MC "I ALSO think you’re putting up these walls because you’re afraid of showing any emotions. You’re afraid of people knowing who you really are and what you’re like."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1033
translate chinese De_swim_S3_Win_40b20691:

    # MC "I don’t know how or why you turned out this way, but I do know that the only time you seemed genuinely happy was when I was taking care of you at your place."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1034
translate chinese De_swim_S3_Win_fce69340_7:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1035
translate chinese De_swim_S3_Win_a89b668e:

    # MC "Perhaps we could start over, Dee?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1036
translate chinese De_swim_S3_Win_914dc9fa:

    # Delilah "Not another word. I’m warning you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1037
translate chinese De_swim_S3_Win_ab120c12:

    # MC "Maybe I could take you out sometime. Candlelit dinner at Antony’s Italian and a movie. I think you have feelings for me, maybe even romantic fe-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1038
translate chinese De_swim_S3_Win_b61d64f8:

    # Delilah "FUCK YOU!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1044
translate chinese De_swim_S3_Win_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1045
translate chinese De_swim_S3_Win_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1049
translate chinese De_swim_S3_Win_ef137816:

    # MC "Wh-What the- What did I do wrong?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1053
translate chinese De_swim_S3_Win_b17eeb7d:

    # Delilah "Don’t pretend as if you understand me! You’re not fucking Judy! You can’t psychoanalyse my mind!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1054
translate chinese De_swim_S3_Win_7137c6da:

    # Delilah "Get the fuck out of here! We’re done."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1058
translate chinese De_swim_S3_Win_0b4e5813:

    # MC "Fine, I’ll leave. But don’t you dare look back on today in twenty years and think that I never tried to get through to you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1059
translate chinese De_swim_S3_Win_ddbf0ab2:

    # MC "I honestly enjoyed what we had going. It was a little rough at the start, and we were probably nastier to each other than we needed to be. And for what it’s worth, I’m sorry for how I treated you. I was, perhaps, a bit too harsh with you and the nerds."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1060
translate chinese De_swim_S3_Win_fce69340_8:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1061
translate chinese De_swim_S3_Win_45c83c6a:

    # MC "*Sigh* It didn’t have to end like this, Delilah. Your fear of being unpopular has trapped you in a prison cell of your own creation. And I think you’re beginning to realise that."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1065
translate chinese De_swim_S3_Win_0932856c:

    # MC "The saddest part is, I don’t even think you’re happy being the so-called ‘Ice Queen.’ There was a moment at your house when I was massaging your feet. I looked up at you, and I noticed something different about you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1066
translate chinese De_swim_S3_Win_fbaf6f45:

    # MC "I couldn’t put my finger on it at the time, but I think I know what it was now. You were genuinely happy with the brief illusion that there was someone in your life who would selflessly give you attention and treat you well."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1067
translate chinese De_swim_S3_Win_151b905f:

    # MC "Someone who wasn’t a viper like those other girls in the swim team, out to take your spot as the most popular girl."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1068
translate chinese De_swim_S3_Win_1d70a92e:

    # MC "You said that I was supposed to be your slave that night, but YOU were the one who couldn’t get away from your friends on the phone. You’re a slave to your own popularity."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1069
translate chinese De_swim_S3_Win_a159c9ee:

    # MC "This obsession with popularity has spread like a venom into every facet of your life, and it’s preventing you from making a real human connection."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1070
translate chinese De_swim_S3_Win_0558f6e0:

    # Delilah "Shut up. Shut up! *Sob* Shut up!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1071
translate chinese De_swim_S3_Win_0260f8e2:

    # MC "I don’t even think you wanted to sit on my face that evening. You just wanted that platonic illusion to last a little longer. To let yourself be vulnerable beyond the gaze of the public eye."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1072
translate chinese De_swim_S3_Win_8919a8cd:

    # Delilah "SHUT UP! *SOB*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1073
translate chinese De_swim_S3_Win_3770634c:

    # MC "But you couldn’t escape it. Not even in the privacy of the house your dad bought you. You’re the Ice Queen, and the constant scrutiny never ends. It was your friends on the phone who were pressuring you to humiliate me further."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1074
translate chinese De_swim_S3_Win_3106fc19:

    # Delilah "SHUT UP! SHUTI UP! Please... *Sob* Just leave me alone!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1075
translate chinese De_swim_S3_Win_3b207a56:

    # MC "*Sigh* I might not be Judy, but point out where anything that I’ve said is wrong. Think about when I was feeding you. You were actually smiling. Maybe even actually happy."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1076
translate chinese De_swim_S3_Win_6020d711:

    # MC "It wasn’t the fake superior smirk you like to project on campus either. It was an actual genuine smile."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1077
translate chinese De_swim_S3_Win_b11ea1f6:

    # MC "It’s not too late though. You can still have that happiness in your life. Just unlock that prison you’ve built and let someone in. The only person who can save you at this point is yourself, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1078
translate chinese De_swim_S3_Win_fce69340_9:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1079
translate chinese De_swim_S3_Win_69842a33:

    # Delilah "*Sob* Just go. *Sob*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1080
translate chinese De_swim_S3_Win_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1081
translate chinese De_swim_S3_Win_512333e9:

    # MC "Goodbye, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1082
translate chinese De_swim_S3_Win_fce69340_10:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1086
translate chinese De_swim_S3_Win_fce69340_11:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1087
translate chinese De_swim_S3_Win_fce69340_12:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1088
translate chinese De_swim_S3_Win_acd5a9f2:

    # Delilah "*Sob*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1089
translate chinese De_swim_S3_Win_fce69340_13:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1090
translate chinese De_swim_S3_Win_908a4653:

    # Delilah "(Please don’t leave me...)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1097
translate chinese De_swim_S3_Win_561f2efc:

    # MC "Shit! I’m gonna cum! Hnnng!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1098
translate chinese De_swim_S3_Win_41ef2216:

    # Delilah "Wh-What?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1099
translate chinese De_swim_S3_Win_09d5b887:

    # MC "Aaaghhhh!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1109
translate chinese De_swim_S3_Win_c5fe73b2:

    # MC "Ughh! Damn, you were a good fuck."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1110
translate chinese De_swim_S3_Win_58740bec:

    # Delilah "Eww! Did you just cum over my butt?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1111
translate chinese De_swim_S3_Win_d7c0e9cb:

    # MC "Well, I DID win the bet, so I could have shot my load inside you with no condom instead. With that in mind, is cumming all over your ass really that bad?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1115
translate chinese De_swim_S3_Win_03be4f9c:

    # Delilah "Wh... Why didn’t you finish inside me?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1116
translate chinese De_swim_S3_Win_f96495a9:

    # MC "Eh, I just decided that I wanted to finish on your butt."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1120
translate chinese De_swim_S3_Win_82e380d9:

    # Delilah "No! You WON the bet! You had every right to fill my pussy with your hot cum! Why didn’t you?!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1121
translate chinese De_swim_S3_Win_5f52c5d0:

    # MC "Honestly? Because deep down I know you probably didn’t want me to."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1122
translate chinese De_swim_S3_Win_ec3e06ce:

    # Delilah "Enough."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1123
translate chinese De_swim_S3_Win_affc4761_1:

    # MC "Think back to that day when you made me your personal slave. You didn’t even make me do anything even REMOTELY sexual for most of the day. And you didn’t even try to humiliate me that much."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1124
translate chinese De_swim_S3_Win_4d126198_1:

    # Delilah "Shut up."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1125
translate chinese De_swim_S3_Win_6842923a_1:

    # MC "What did you ask for? A cup of tea, a home cooked meal, and a back massage? I think that, more than anything, you wanted the illusion of having someone who actually loved and cared for you in your life."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1126
translate chinese De_swim_S3_Win_4601f5a9_1:

    # Delilah "I told you to shut up!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1127
translate chinese De_swim_S3_Win_9d7b3d6e:

    # MC "When we started making those bets I figured that you enjoyed being humiliated as much as I did, but it’s deeper than that, isn’t it?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1128
translate chinese De_swim_S3_Win_5126b8f8:

    # MC "I think you were just looking for a genuine connection with someone who knew what you were like when you were at your most vulnerable."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1129
translate chinese De_swim_S3_Win_66614fac_1:

    # Delilah "SHUT IT!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1130
translate chinese De_swim_S3_Win_b550ac86_1:

    # MC "I ALSO think you’re putting up these walls because you’re afraid of showing any emotions. You’re afraid of people knowing who you really are and what you’re like."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1131
translate chinese De_swim_S3_Win_40b20691_1:

    # MC "I don’t know how or why you turned out this way, but I do know that the only time you seemed genuinely happy was when I was taking care of you at your place."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1132
translate chinese De_swim_S3_Win_fce69340_14:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1133
translate chinese De_swim_S3_Win_a89b668e_1:

    # MC "Perhaps we could start over, Dee?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1134
translate chinese De_swim_S3_Win_914dc9fa_1:

    # Delilah "Not another word. I’m warning you."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1135
translate chinese De_swim_S3_Win_ab120c12_1:

    # MC "Maybe I could take you out sometime. Candlelit dinner at Antony’s Italian and a movie. I think you have feelings for me, maybe even romantic fe-"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1136
translate chinese De_swim_S3_Win_b61d64f8_1:

    # Delilah "FUCK YOU!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1141
translate chinese De_swim_S3_Win_4875f5be_1:

    # "*SLAP*"
    ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1142
translate chinese De_swim_S3_Win_c9682c6a_1:

    # MC "Ouch!"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1146
translate chinese De_swim_S3_Win_ef137816_1:

    # MC "Wh-What the- What did I do wrong?"
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1150
translate chinese De_swim_S3_Win_4d83302a:

    # Delilah "Don’t pretend as if you understand me! You’re not - fucking Judy! You can’t psychoanalyse my mind!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1151
translate chinese De_swim_S3_Win_7137c6da_1:

    # Delilah "Get the fuck out of here! We’re done."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1155
translate chinese De_swim_S3_Win_0b4e5813_1:

    # MC "Fine, I’ll leave. But don’t you dare look back on today in twenty years and think that I never tried to get through to you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1156
translate chinese De_swim_S3_Win_ddbf0ab2_1:

    # MC "I honestly enjoyed what we had going. It was a little rough at the start, and we were probably nastier to each other than we needed to be. And for what it’s worth, I’m sorry for how I treated you. I was, perhaps, a bit too harsh with you and the nerds."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1157
translate chinese De_swim_S3_Win_fce69340_15:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1158
translate chinese De_swim_S3_Win_45c83c6a_1:

    # MC "*Sigh* It didn’t have to end like this, Delilah. Your fear of being unpopular has trapped you in a prison cell of your own creation. And I think you’re beginning to realise that."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1162
translate chinese De_swim_S3_Win_0932856c_1:

    # MC "The saddest part is, I don’t even think you’re happy being the so-called ‘Ice Queen.’ There was a moment at your house when I was massaging your feet. I looked up at you, and I noticed something different about you."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1163
translate chinese De_swim_S3_Win_fbaf6f45_1:

    # MC "I couldn’t put my finger on it at the time, but I think I know what it was now. You were genuinely happy with the brief illusion that there was someone in your life who would selflessly give you attention and treat you well."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1164
translate chinese De_swim_S3_Win_151b905f_1:

    # MC "Someone who wasn’t a viper like those other girls in the swim team, out to take your spot as the most popular girl."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1165
translate chinese De_swim_S3_Win_1d70a92e_1:

    # MC "You said that I was supposed to be your slave that night, but YOU were the one who couldn’t get away from your friends on the phone. You’re a slave to your own popularity."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1166
translate chinese De_swim_S3_Win_a159c9ee_1:

    # MC "This obsession with popularity has spread like a venom into every facet of your life, and it’s preventing you from making a real human connection."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1167
translate chinese De_swim_S3_Win_0558f6e0_1:

    # Delilah "Shut up. Shut up! *Sob* Shut up!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1168
translate chinese De_swim_S3_Win_0260f8e2_1:

    # MC "I don’t even think you wanted to sit on my face that evening. You just wanted that platonic illusion to last a little longer. To let yourself be vulnerable beyond the gaze of the public eye."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1169
translate chinese De_swim_S3_Win_8919a8cd_1:

    # Delilah "SHUT UP! *SOB*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1170
translate chinese De_swim_S3_Win_3770634c_1:

    # MC "But you couldn’t escape it. Not even in the privacy of the house your dad bought you. You’re the Ice Queen, and the constant scrutiny never ends. It was your friends on the phone who were pressuring you to humiliate me further."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1171
translate chinese De_swim_S3_Win_3106fc19_1:

    # Delilah "SHUT UP! SHUTI UP! Please... *Sob* Just leave me alone!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1172
translate chinese De_swim_S3_Win_3b207a56_1:

    # MC "*Sigh* I might not be Judy, but point out where anything that I’ve said is wrong. Think about when I was feeding you. You were actually smiling. Maybe even actually happy."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1173
translate chinese De_swim_S3_Win_6020d711_1:

    # MC "It wasn’t the fake superior smirk you like to project on campus either. It was an actual genuine smile."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1174
translate chinese De_swim_S3_Win_b11ea1f6_1:

    # MC "It’s not too late though. You can still have that happiness in your life. Just unlock that prison you’ve built and let someone in. The only person who can save you at this point is yourself, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1175
translate chinese De_swim_S3_Win_fce69340_16:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1176
translate chinese De_swim_S3_Win_69842a33_1:

    # Delilah "*Sob* Just go. *Sob*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1177
translate chinese De_swim_S3_Win_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1178
translate chinese De_swim_S3_Win_512333e9_1:

    # MC "Goodbye, Dee."
    MC ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1179
translate chinese De_swim_S3_Win_fce69340_17:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1183
translate chinese De_swim_S3_Win_fce69340_18:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1184
translate chinese De_swim_S3_Win_fce69340_19:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1185
translate chinese De_swim_S3_Win_acd5a9f2_1:

    # Delilah "*Sob*"
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1186
translate chinese De_swim_S3_Win_fce69340_20:

    # Delilah "..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_swim_S3.rpy:1187
translate chinese De_swim_S3_Win_908a4653_1:

    # Delilah "(Please don’t leave me...)"
    Delilah ""

translate chinese strings:

    # game/scripts/Deliah_Scenes/De_swim_S3.rpy:199
    old "So, I’m your butler for this evening?"
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S3.rpy:199
    old "Is that a self-portrait on the wall?"
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S3.rpy:199
    old "Does anybody else live here with you?"
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S3.rpy:199
    old "So, what do you ACTUALLY intend to do with me this evening?"
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S3.rpy:982
    old "Grab Delilah’s ass and pull her in close for a creampie."
    new ""

    # game/scripts/Deliah_Scenes/De_swim_S3.rpy:982
    old "Show her a little bit of sympathy. Pull out at the last second and cum over Delilah’s ass."
    new ""

