﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_MS1.rpy:15
translate chinese De_talked_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:29
translate chinese De_MS1_b1f744c7:

    # MC "(I'm not strong enough to win against her.)"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:41
translate chinese De_MS1_bdf1532e:

    # Delilah "Ready for a rematch?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:70
translate chinese De_MS1_f794e638:

    # Delilah "Well, well... if it isn’t the creep who tried asking out Ms. Celia. Managed to find yourself a girlfriend yet?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:71
translate chinese De_MS1_2f39f924:

    # MC "As a matter of fact, I-"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:72
translate chinese De_MS1_520e8326:

    # Delilah "“As a MaTtEr oF fAcT!” Ahaha, fucking dork!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:76
translate chinese De_MS1_939f5422:

    # MC "Hey! You can’t speak to me like th-"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:77
translate chinese De_MS1_31cfc3b3:

    # Delilah "Seriously though, are you always this much of a fucking loser? What makes someone like YOU think they have the right to just saunter up to one of the most popular girls on campus? Ha!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:78
translate chinese De_MS1_b9823314:

    # MC "I was just passing by the pool and-"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:82
translate chinese De_MS1_8f08c5ba:

    # Delilah "First you try to ask out Ms. Celia and make an ass of yourself in front of everybody, and NOW you have the audacity to approach me."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:83
translate chinese De_MS1_22226f14:

    # Delilah "What are you gonna do? Ask me out on a date as well? Let me guess, something SUPER cliche like candlelit dinner at Antony’s Italian followed by a movie?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:84
translate chinese De_MS1_0c43af34:

    # MC "I literally never brought up the subject of asking you ou-"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:85
translate chinese De_MS1_d25b9e08:

    # Delilah "Oh! I think I’ve worked out what’s happening here. You’ve got a fetish for being publicly humiliated! Is that right, you weak little dork?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:89
translate chinese De_MS1_bd9f4fe4:

    # MC "Alright, I’ve had just about enough of this nonsense. You’re a real piece of shit, you know that? I should’ve listened to those guys in the hallway. They warned me about you."
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:90
translate chinese De_MS1_3d911c58:

    # Delilah "Oh, do go on. I can’t wait to be lectured by the guy who thought asking out his own professor was socially acceptable."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:91
translate chinese De_MS1_000ba314:

    # MC "Yeah, I fucked up with Ms. Celia, but I’m not gonna spend the rest of my time on campus getting mocked and degraded by some vapid, insipid, posh bitch."
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:92
translate chinese De_MS1_a5d69a55:

    # MC "I’ve seen your pics on Instaspam. You’re just a vacuous, self-absorbed rich-girl. Subtract all this exercising and the- the- Instaspam and the swimming and what’s left? Nothing but your shitty, toxic personality."
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:96
translate chinese De_MS1_297185eb:

    # Delilah "Haha! A wimpy guy like you mocking me for exercising and actually taking care of my body? That’s hilarious!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:97
translate chinese De_MS1_1aad09b2:

    # Delilah "I bet the only work-out you ever get is your right arm when you’re lying ALL ALONE in bed at night. Ahaha!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:101
translate chinese De_MS1_05800672:

    # MC "Oh yeah? Is that what you think? I bet I’m stronger than you are!"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:102
translate chinese De_MS1_cec2a585:

    # Delilah "Pfft! Bullshit. I’d beat your wimpy ass any day of the week with one hand tied behind my back."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:103
translate chinese De_MS1_9a7f4a39:

    # MC "Is that a bet?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:104
translate chinese De_MS1_0eed23a8:

    # Delilah "Y’know what, if it gets you off my back, then yeah - it’s a bet. First one to the other side of the pool wins."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:105
translate chinese De_MS1_d9dc62f4:

    # MC "Fine. And if - WHEN I win, you have to walk around campus with no blouse and no bra."
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:106
translate chinese De_MS1_554c017b:

    # Delilah "Pfft - is that all?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:107
translate chinese De_MS1_ecff9ed5:

    # MC "...during lunch. And I’m going to make sure those nerds that you and your swim team bully are hanging around."
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:108
translate chinese De_MS1_44bb9944:

    # Delilah "Hmmph! Fine, but WHEN I win I’m going to parade you around in just nothing more than your underwear. "
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:112
translate chinese De_MS1_5e7bace0:

    # MC "Deal!"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:113
translate chinese De_MS1_54afac73:

    # Delilah "(Hah! I can’t believe this little weakling actually thinks he can beat me in a race. I’ve been the regional champ for the past two years!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:114
translate chinese De_MS1_62ca9037:

    # Delilah "(As for walking topless around the college. It would damage my reputation. A LOT of guys are following me on Instaspam and DikDok, but I’m very careful not to show too much.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:115
translate chinese De_MS1_384afed9:

    # Delilah "(It doesn't matter anyway! There’s no way this twerp stands a chance of beating me. I’ll easily kick his ass and then publicly humiliate him in front of the whole campus. That ought to make him leave me alone!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:120
translate chinese De_MS1_3cb9d87d:

    # MC "Alright! That’s me ready!"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:121
translate chinese De_MS1_e8063b61:

    # Delilah "(Oh wow... he may not have the muscles, but he HAS got a HUGE package!)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:122
translate chinese De_MS1_2e364430:

    # MC "Uh, Delilah? That’s me ready to go?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:123
translate chinese De_MS1_9e1cf1e2:

    # Delilah "Oh! Uh huh, let’s do it. I hope you’re ready for the whole campus to see you in your boxers."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:127
translate chinese De_MS1_99e06351:

    # MC "You’re far too confident for someone who is about to flash her rack in front of her fellow students."
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:128
translate chinese De_MS1_d6518014:

    # Delilah "Only in your perverted wet dreams, weakling. Here we go, on three."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:129
translate chinese De_MS1_c2b17a24:

    # Delilah "One..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:130
translate chinese De_MS1_37672df8:

    # Delilah "(I’m going to humiliate this little twerp so badly that the incident with Ms. Celia will pale in comparison.)"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:131
translate chinese De_MS1_be438c97:

    # Delilah "Two..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:132
translate chinese De_MS1_e5aa4009:

    # MC "(I’m gonna win this race and put this entitled bitch back in her place! By the time I’m done with her, she won’t even THINK about bullying anyone ever again!)"
    MC ""

# game/scripts/Deliah_Scenes/De_MS1.rpy:133
translate chinese De_MS1_c5c46351:

    # Delilah "Three!"
    Delilah ""

translate chinese strings:

    # game/scripts/Deliah_Scenes/De_MS1.rpy:42
    old "Yeah."
    new ""

    # game/scripts/Deliah_Scenes/De_MS1.rpy:42
    old "I'll come back later."
    new ""

