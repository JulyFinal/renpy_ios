﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Deliah_Scenes/De_MS2.rpy:14
translate chinese De_MS2_b1f744c7:

    # MC "(I'm not strong enough to win against her.)"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:26
translate chinese De_MS2_bdf1532e:

    # Delilah "Ready for a rematch?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:57
translate chinese De_MS2_9ab95d18:

    # MC "You’re looking rather cheery today."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:58
translate chinese De_MS2_9490126e:

    # Delilah "Do I?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:59
translate chinese De_MS2_a40b59e3:

    # MC "You do. I must say, I’m surprised given how furiously embarrassed you were the other day. Not pissed off at me anymore?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:60
translate chinese De_MS2_d285815e:

    # Delilah "I had time to sleep on it and... reflect on things."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:61
translate chinese De_MS2_1894d916:

    # MC "Ah, so you got visited by three ghosts and now you’re a changed person who doesn’t go around bullying people anymore?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:65
translate chinese De_MS2_726767d8:

    # Delilah "Not exactly. You see, this isn’t the first time I’ve lost. I realised that as I was lying in bed last night, with those thoughts ruminating in my mind."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:66
translate chinese De_MS2_dc09185d:

    # Delilah "It might be difficult for you to believe, but I’ve been beaten before. Beaten by women who were faster than me, stronger than me, more talented than me."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:67
translate chinese De_MS2_5aa105f3:

    # Delilah "It NEVER stopped me though. They beat me, I trained harder, I beat them. I climbed the ladder of competitive swimming IN SPITE of the challenges that I faced."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:68
translate chinese De_MS2_25e1bd5c:

    # Delilah "And, as I lay in bed, playing over those events in my mind, that’s when I came to a sudden realisation."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:69
translate chinese De_MS2_1fc0b5f3:

    # MC "And what exactly was that?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:73
translate chinese De_MS2_945aaaa8:

    # Delilah "You, [player_name], are just another challenge for me to beat."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:74
translate chinese De_MS2_5d549648:

    # Delilah "Sure, the stakes are higher this time. I’m not competing for medals or trophies. It’s my REPUTATION that we’re wagering. But I know one thing for certain..."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:75
translate chinese De_MS2_a2f33de6:

    # Delilah "...the same formula that has won me trophies and medals in swimming, is the same formula that will win another bet against you. I will analyse my weaknesses, I will train them out of existence, and I will-"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:79
translate chinese De_MS2_4f7a355a:

    # MC "Are you asking for a rematch?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:80
translate chinese De_MS2_0f4ad22e:

    # Delilah "Ugh! You could have AT LEAST let me finish my speech!"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:81
translate chinese De_MS2_a1156e9b:

    # MC "It was a terrible speech. But fine. A rematch it is. What are the stakes this time? You want me to parade around nearly-naked again?"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:85
translate chinese De_MS2_270698c8:

    # Delilah "Mmm, I wouldn’t describe it as “parading.” I was planning to leash you up like the dog you are, walk you down the hallway, round up the rest of my girls in the swim team, and drag your ass back in here."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:86
translate chinese De_MS2_83d672f7:

    # Delilah "THEN, I’m going to force your weak little ass to cum in front of ALL my friends."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:87
translate chinese De_MS2_fa112fcb:

    # MC "Ahh, you’re DEFINITELY still pissed at me, then. In that case it only seems fair that I increase my wager too."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:88
translate chinese De_MS2_60b6ac4a:

    # Delilah "Naturally."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:89
translate chinese De_MS2_2cbb6f87:

    # MC "If I win... then... Hmm..."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:90
translate chinese De_MS2_8a84c79f:

    # MC "Aha! If I win, then I’ll walk you down the corridor on a leash as well. Except, you’ll have to announce “I’m a stupid slut who lost a bet. I have to reward [player_name] with a blowjob. Come and watch me suck his cock!”"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:91
translate chinese De_MS2_5c6b9238:

    # MC "Then, I’ll round up all the guys you’ve bullied over the years and make you suck my dick right in front of them all."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:92
translate chinese De_MS2_115f53fd:

    # Delilah "Ew, you really are a pervert, aren’t you?"
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:93
translate chinese De_MS2_0438b24a:

    # Delilah "Alas, someone is feeling a little too overconfident, methinks."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:94
translate chinese De_MS2_5c620338:

    # MC "And I think you’re secretly salivating for the taste of my cock."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:98
translate chinese De_MS2_ee8e39bf:

    # Delilah "Ha! I wouldn’t know what cock tastes like. Girls like me don’t need to stoop to sucking dick to get what we want."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:99
translate chinese De_MS2_73bdf85f:

    # MC "Hold on! You’ve NEVER given a blowjob? This just keeps getting better!"
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:100
translate chinese De_MS2_9032ab73:

    # Delilah "Nope. And I never will."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:101
translate chinese De_MS2_ed0955c3:

    # MC "Heh. The fellas you bullied are going to love watching you choke on my dick."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:102
translate chinese De_MS2_147d50e2:

    # Delilah "Pfft! Your cock’s so tiny that even the State of California would refuse to slap a “choking risk” label on it, [player_name]."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:103
translate chinese De_MS2_93da2d79:

    # MC "When you finally see my dick, your own words aren’t going to be the only thing that you’ll be swallowing."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:104
translate chinese De_MS2_8689ae3f:

    # Delilah "I must confess, [player_name], as much as I enjoy our verbal sparring sessions, I am particularly looking forward to seeing you be utterly humiliated when you cum. "
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:105
translate chinese De_MS2_92be867b:

    # Delilah "The whole swim team watching you, laughing at you, taunting you as you tremble and squirm while I force every last drop of semen out of your pathetic little balls."
    Delilah ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:106
translate chinese De_MS2_a874f671:

    # MC "Aww, were you “ruminating” about that in bed last night too?."
    MC ""

# game/scripts/Deliah_Scenes/De_MS2.rpy:107
translate chinese De_MS2_a04c9953:

    # Delilah "Let’s see how feisty you are when I beat your ass."
    Delilah ""

translate chinese strings:

    # game/scripts/Deliah_Scenes/De_MS2.rpy:118
    old "{color=#FF0000}Let her win.{/color}"
    new ""

    # game/scripts/Deliah_Scenes/De_MS2.rpy:118
    old "{color=#00ff00}Don't let her win.{/color}"
    new ""

