﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/GYM/GYM.rpy:11
translate chinese GYM_map_4a24d7b6:

    # MC "(Closed. It's open only at the morning and in the afternoon.)"
    MC ""

