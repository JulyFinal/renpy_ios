﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Bathroom/M/a_bathroom_M.rpy:10
translate chinese a_bathroom_M1_58ddab6c:

    # MC "(Eh!? Fuck! She's in there! I think it's not the best idea to talk to her, after what happened... Especially while she's nude...)"
    MC ""

