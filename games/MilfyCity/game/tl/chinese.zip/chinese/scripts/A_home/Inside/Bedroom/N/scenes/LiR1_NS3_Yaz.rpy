﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:71
translate chinese LiR1_NS3_label_5df1c715:

    # MC "(I've already done something tonight... I’ll let them sleep.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:88
translate chinese LiR1_NS3_label_b41e6ce6:

    # MC "Hey Liza! Hey Yazmin - love the lingerie!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:89
translate chinese LiR1_NS3_label_c49ab3ba:

    # Liza "Thanks, [player_name]. What are you doing here though?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:92
translate chinese LiR1_NS3_label_7f60dda0:

    # MC "I actually came here to ask if you guys wanted to try some roleplay tonight?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:93
translate chinese LiR1_NS3_label_ab5be588:

    # Liza "What do you mean by ‘roleplay’?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:94
translate chinese LiR1_NS3_label_debfe87f:

    # MC "I was thinking you two could pretend to be asleep while I play with your bodies."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:97
translate chinese LiR1_NS3_label_a662c5cc:

    # Liza "Ooh, that sounds hot! What do you think, Yazmin? You down for it?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:98
translate chinese LiR1_NS3_label_c0102b57:

    # Yazmin "Hmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:101
translate chinese LiR1_NS3_label_008da8e1:

    # Yazmin "It’s very late, Liza. I need to sleep."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:102
translate chinese LiR1_NS3_label_7b6e2dd0:

    # Liza "Aww, c’mon! It’ll be fun! Don’t be such a sourpuss!"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:105
translate chinese LiR1_NS3_label_d87c41fb:

    # Yazmin "*Sigh* Fine. It does sound sexy as hell, I’ll give you that."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:106
translate chinese LiR1_NS3_label_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:107
translate chinese LiR1_NS3_label_2f3e2bda:

    # Liza "So, which of us do you want to play with first?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:110
translate chinese LiR1_NS3_label_9b7b333f:

    # MC "Hmm... That’s a tough choice! You both look ravishing right now."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:111
translate chinese LiR1_NS3_label_a15ff399:

    # Yazmin "Well, don’t keep us waiting!"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:116
translate chinese LiR1_NS3_label_9de53309:

    # MC "(It looks like both of them are pretending to be asleep like we agreed.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:119
translate chinese LiR1_NS3_label_addd5c6f:

    # MC "Psst... Yazmin? Are you awake?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:120
translate chinese LiR1_NS3_label_e7ec234e:

    # Yazmin "(I thought we already agreed that we would be pretending to be asleep? Can this guy not even follow the basic rules of roleplay.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:121
translate chinese LiR1_NS3_label_d1e660d9:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:122
translate chinese LiR1_NS3_label_d6e6948d:

    # MC "Was that a-"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:123
translate chinese LiR1_NS3_label_e30d40e9:

    # Yazmin "*SNORE*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:124
translate chinese LiR1_NS3_label_ee8c8ac0:

    # MC "O-Okay, I get it. Sorry."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:125
translate chinese LiR1_NS3_label_3c0a6bc0:

    # MC "(It’s going to be great fun playing with her body!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:126
translate chinese LiR1_NS3_label_dad37f6b:

    # MC "(She was even kind enough to make my job easier by not sleeping with a bra on!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:129
translate chinese LiR1_NS3_label_41127d56:

    # MC "(And there’s Liza - God she looks so sexy.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:130
translate chinese LiR1_NS3_label_3afc9b45:

    # MC "(It’s a shame she’s wearing underwear, but at least it’s see-through! At least Yazmin made this roleplay a bit easier by stripping down.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:131
translate chinese LiR1_NS3_label_e7782a18:

    # MC "(Damn, her tits look incredible. Just look at the size of those nipples!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:132
translate chinese LiR1_NS3_label_36dbc26f:

    # MC "Hmm... (Yazmin or Liza... who should I play with first?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:138
translate chinese LiR1_NS3_label_bcf06506:

    # MC "(It looks like, both of them are asleep - I should go closer, to make absolutely certain of it though.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:141
translate chinese LiR1_NS3_label_d1e660d9_1:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:142
translate chinese LiR1_NS3_label_fed19657:

    # MC "(Yeah, it sounds like Yazmin’s definitely asleep. It could be great fun, playing with her body, while she’s out for the count.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:143
translate chinese LiR1_NS3_label_f6caaa0d:

    # MC "(She was even - kind enough - to make my job easier, by not sleeping with a bra on!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:146
translate chinese LiR1_NS3_label_132fb729:

    # MC "(And there’s my sexy Auntie - dead to the world.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:147
translate chinese LiR1_NS3_label_8bdf2e3f:

    # MC "(It’s a shame she’s wearing underwear, but at least it’s see-through!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:148
translate chinese LiR1_NS3_label_09245e2c:

    # MC "(Damn, her tits look incredible! Just look at the size of those nipples!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:149
translate chinese LiR1_NS3_label_5ffb15c4:

    # MC "Hmm... (Yazmin or Auntie Liza... Which one should I play with?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:196
translate chinese LiR1_NS3_menu_d0befd40:

    # MC "(Let’s play with Yazmin’s body, while she’s sleeping.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:197
translate chinese LiR1_NS3_menu_dbae2deb:

    # MC "(Hmm? Should I mess with her feet? They could be a lot of fun.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:198
translate chinese LiR1_NS3_menu_f7b0063a:

    # MC "(Or I could try and get her to give me a blowjob...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:199
translate chinese LiR1_NS3_menu_865f5714:

    # MC "(Alternatively, I could go straight for her ass)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:200
translate chinese LiR1_NS3_menu_fd7a254f:

    # MC "(Then again... I could try turning her body over, and see what’s on the other side.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:206
translate chinese LiR1_NS3_menu_275568a8:

    # MC "(Let’s play with Yazmin’s body first. She stripped her clothes off, so she’s obviously more eager for my attention!) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:207
translate chinese LiR1_NS3_menu_70375924:

    # MC "(Hmm, should I toy with her feet? They could be a lot of fun.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:208
translate chinese LiR1_NS3_menu_f7b0063a_1:

    # MC "(Or I could try and get her to give me a blowjob...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:209
translate chinese LiR1_NS3_menu_865f5714_1:

    # MC "(Alternatively, I could go straight for her ass)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:210
translate chinese LiR1_NS3_menu_fd7a254f_1:

    # MC "(Then again... I could try turning her body over, and see what’s on the other side.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:216
translate chinese LiR1_NS3_menu_87afdf76:

    # MC "(Let’s play with [Liza_name]’s body, while she’s sleeping.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:220
translate chinese LiR1_NS3_menu_d8269ff1:

    # MC "(Let’s play with [Liza_name]’s body.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:246
translate chinese Yaz_NS_B_feet_ac7e726f:

    # MC "(I think I’ll begin by, playing with her feet, for a bit.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:247
translate chinese Yaz_NS_B_feet_0f9bda3e:

    # MC "(They’re already in the perfect position for me to press my cock between them!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:248
translate chinese Yaz_NS_B_feet_1d49f59c:

    # Yazmin "*Snooore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:250
translate chinese Yaz_NS_B_feet_60cc7c5d:

    # MC "(That’s probably her way of telling me to hurry up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:254
translate chinese Yaz_NS_B_feet_64fba74c:

    # MC "(She’s got a REALLY nice pair of soles. They look so soft!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:255
translate chinese Yaz_NS_B_feet_6fd93982:

    # MC "(I bet they would feel incredible, against my cock.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:256
translate chinese Yaz_NS_B_feet_7ce4b848:

    # MC "(Let’s reach out and see how they feel...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:260
translate chinese Yaz_NS_B_feet_385edd04:

    # Yazmin "*Yawn*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:261
translate chinese Yaz_NS_B_feet_e7ecc236:

    # MC "(Easy does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:263
translate chinese Yaz_NS_B_feet_77997ab0:

    # MC "(Oh yeah! These are perfect! I’ll just get my cock out, here. If I’m slow enough, she probably won’t be able to feel me using them, to wank myself off.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:267
translate chinese Yaz_NS_B_feet_3125197a:

    # MC "(There we go... Almost ready to get this show started.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:268
translate chinese Yaz_NS_B_feet_d1e660d9:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:270
translate chinese Yaz_NS_B_feet_4d8429e3:

    # MC "(It sounds like she’s drifting into a deep sleep. So now’s my chance!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:272
translate chinese Yaz_NS_B_feet_972476b1:

    # MC "(She’s still going along with the roleplay - it must mean she’s enjoying it!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:275
translate chinese Yaz_NS_B_feet_d481ac03:

    # MC "*Whispered* Oh yeah..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:276
translate chinese Yaz_NS_B_feet_e8768f71:

    # MC "Mmm... That feels good..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:277
translate chinese Yaz_NS_B_feet_020f020a:

    # MC "(I’ll just position her feet a little wider, and I’ll be able to begin.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:280
translate chinese Yaz_NS_B_feet_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:281
translate chinese Yaz_NS_B_feet_059b2e96:

    # MC "(Okay, my cock should slip through that gap, fairly easily now.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:282
translate chinese Yaz_NS_B_feet_5050e9fa:

    # MC "(Let’s give it a go and see if it works.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:285
translate chinese Yaz_NS_B_feet_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:288
translate chinese Yaz_NS_B_feet_86299a2e:

    # Yazmin "*Yawn!*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:290
translate chinese Yaz_NS_B_feet_a4dbd6b1:

    # MC "(Shit! I have to keep my voice down. I almost woke her up, there!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:291
translate chinese Yaz_NS_B_feet_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:292
translate chinese Yaz_NS_B_feet_f34d15bf:

    # MC "(At least [Liza_name] is still completely asleep...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:296
translate chinese Yaz_NS_B_feet_08c8acef:

    # MC "(This seems to be the perfect angle. I’m able to rock my hips back and forth to have her stimulate my glans, with her heels.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:297
translate chinese Yaz_NS_B_feet_5336b0af:

    # MC "(Thank God, she doesn’t have tickly feet, or I could have woken her up!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:299
translate chinese Yaz_NS_B_feet_3a38b3fc:

    # MC "(This seems to be the perfect angle. I’m able to rock my hips back and forth to have her stimulate my glans with her heels.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:300
translate chinese Yaz_NS_B_feet_df9ff3f8:

    # MC "(Thank God she doesn’t have tickly feet or she’d be laughing right now!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:305
translate chinese Yaz_NS_B_feet_6d6d091f:

    # MC "(It would be EXTREMELY difficult to explain to them both, why I was in their room in the middle of the night with my cock out.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:306
translate chinese Yaz_NS_B_feet_61596a2b:

    # MC "Mmm... Ah..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:309
translate chinese Yaz_NS_B_feet_6501384d:

    # MC "(God, this feels so good!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:313
translate chinese Yaz_NS_B_feet_ab8885d9:

    # MC "(Her feet are so soft. I can only imagine how good this would feel, if she was actually awake and moving them, herself!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:315
translate chinese Yaz_NS_B_feet_f5dab836:

    # MC "(Her feet are so soft. I can only imagine how good this would feel if she was proactively doing this to me!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:316
translate chinese Yaz_NS_B_feet_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:318
translate chinese Yaz_NS_B_feet_366cc009:

    # MC "(I’m not gonna last much longer. I’ll have to try and keep my voice down, when I cum.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:320
translate chinese Yaz_NS_B_feet_df211317:

    # MC "(I’m not gonna last much longer.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:323
translate chinese Yaz_NS_B_feet_69261df8:

    # MC "Hnnng.... Ugh.... ah...."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:324
translate chinese Yaz_NS_B_feet_1e401439:

    # MC "(Oh yeah, this is it! I think I’ll just cum, all over her feet.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:326
translate chinese Yaz_NS_B_feet_da1ce7bb:

    # MC "(It will have dried, by the time she wakes up in the morning - so she won't even know!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:328
translate chinese Yaz_NS_B_feet_dd4c388a:

    # Yazmin "([player_name] is starting to thrust faster, he must be about to cum.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:332
translate chinese Yaz_NS_B_feet_99d5f361:

    # MC "Hnnng! Ah... Ugh!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:333
translate chinese Yaz_NS_B_feet_ddca5cd9:

    # MC "(Goddamn! This feels so fucking good!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:343
translate chinese Yaz_NS_B_feet_0adfa706:

    # MC "Ugh! Ahhh...."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:345
translate chinese Yaz_NS_B_feet_6fdde746:

    # Yazmin "(Wow, that is a LOT of hot cum. I just wish he’d finished somewhere more exciting than my feet...)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:346
translate chinese Yaz_NS_B_feet_f8f95b72:

    # MC "(Phew... That was great!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:348
translate chinese Yaz_NS_B_feet_46cd0fb6:

    # MC "(I hope I wasn’t too loud though!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:349
translate chinese Yaz_NS_B_feet_d6726ec0:

    # MC "(There’s something amazing about playing with a sleeping woman’s body. Maybe it’s the sense of complete control, that gets me off?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:351
translate chinese Yaz_NS_B_feet_dd23644a:

    # MC "(I’m really enjoying doing this sleep roleplay! I hope she’s enjoying it as much as I am.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:355
translate chinese Yaz_NS_B_feet_57b4d3a9:

    # Yazmin "*Yawn!* Hmm? You going to the bathroom, Liza?"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:356
translate chinese Yaz_NS_B_feet_ea4cd4e8:

    # MC "(Shit! Yazmin’s waking up! Time for me to bolt!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:357
translate chinese Yaz_NS_B_feet_ba14a034:

    # MC "(I’ll have to come back another night, for some more fun with her!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:359
translate chinese Yaz_NS_B_feet_062ce431:

    # Yazmin "(I should probably get some actual sleep now. Let’s give [player_name] a signal that the fun’s over.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:360
translate chinese Yaz_NS_B_feet_57b4d3a9_1:

    # Yazmin "*Yawn!* Hmm? You going to the bathroom, Liza?"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:361
translate chinese Yaz_NS_B_feet_da49155b:

    # MC "(Okay, time for me to go. I’ll come back another night and play with another part of her body.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:367
translate chinese Yaz_NS_B_ass_bea76be9:

    # MC "(I think I’ll play with Yazmin’s ass for a change. She’s already lying face down on the bed, so I’ve got easy access to it.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:369
translate chinese Yaz_NS_B_ass_87e275b0:

    # MC "(As long as I take things slow, I don’t think there’s any chance of me waking her up, by accident.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:371
translate chinese Yaz_NS_B_ass_4fc5f5df:

    # MC "(It’s probably where she wants me to play with anyway given that she’s lying in that position.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:374
translate chinese Yaz_NS_B_ass_2add952c:

    # MC "(She’s got a really great butt on her. Nice firm cheeks!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:375
translate chinese Yaz_NS_B_ass_50b346f7:

    # MC "(I think I’ll begin by, climbing on the bed and feeling them up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:376
translate chinese Yaz_NS_B_ass_54a329a6:

    # MC "(Okay, here we go - Slowly does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:380
translate chinese Yaz_NS_B_ass_c6471c5e:

    # MC "(Perfect! That’s me on the bed... Thankfully, it didn’t creak when I climbed up. Now it’s time for the fun to begin!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:381
translate chinese Yaz_NS_B_ass_4fe1b0f9:

    # Yazmin "*Snore...*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:382
translate chinese Yaz_NS_B_ass_13cda164:

    # MC "(That’s it, Yazmin... Go into a nice deep sleep for me.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:384
translate chinese Yaz_NS_B_ass_e2bf6591:

    # MC "(Perfect! That’s me on the bed... Now it’s time for the fun to begin!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:385
translate chinese Yaz_NS_B_ass_2a02d45d:

    # Yazmin "(Looks like [player_name] took the hint and is going for my ass! I’ll pretend to snore so he knows he’s doing the right thing.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:386
translate chinese Yaz_NS_B_ass_4fe1b0f9_1:

    # Yazmin "*Snore...*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:389
translate chinese Yaz_NS_B_ass_4e4a45a3:

    # MC "(This ass is amazing! I wonder how many guys have been lucky enough to fuck this?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:390
translate chinese Yaz_NS_B_ass_36c4787f:

    # MC "(Hmm? I know Yazmin is bisexual - I wonder if she did anal sex much, before she met [Liza_name]?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:391
translate chinese Yaz_NS_B_ass_208981e2:

    # MC "(Maybe [Liza_name] and her, still do some anal play together. I’ve only watched them, a couple of times, so far...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:394
translate chinese Yaz_NS_B_ass_6308ed60:

    # MC "(She’s got such firm buttocks. I could play with these for hours!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:395
translate chinese Yaz_NS_B_ass_a22a8f78:

    # MC "(It’s little surprise, that she works as a model. She’s got the figure for it!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:399
translate chinese Yaz_NS_B_ass_0e70521c:

    # MC "Hmm... (I wonder if she’s in a deep enough sleep, for me to bury my face in it, for a while.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:401
translate chinese Yaz_NS_B_ass_8896f934:

    # MC "Hmm... (I wonder if she’s would mind me burying my face in her butt for a while.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:402
translate chinese Yaz_NS_B_ass_3ba93e8a:

    # MC "(Let’s risk it!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:403
translate chinese Yaz_NS_B_ass_58d8bcb5:

    # MC "(Here goes nothing...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:406
translate chinese Yaz_NS_B_ass_866d418a:

    # MC "*Sniff*"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:407
translate chinese Yaz_NS_B_ass_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:408
translate chinese Yaz_NS_B_ass_7a4a32c8:

    # MC "(I can smell her pussy from here through the thin fabric of her panties.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:411
translate chinese Yaz_NS_B_ass_7abf1263:

    # MC "(I might not get another chance at this... I think I should go all-in tonight!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:412
translate chinese Yaz_NS_B_ass_8a6e9635:

    # MC "(Let’s give her a little lovebite, while I’m down here.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:414
translate chinese Yaz_NS_B_ass_3cee0265:

    # Yazmin "(Oooh! That’s nice!)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:415
translate chinese Yaz_NS_B_ass_5848fe87:

    # Yazmin "*Zzzzz*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:419
translate chinese Yaz_NS_B_ass_46e2c0c9:

    # MC "(Mmm! I could nibble at this ass, all night!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:420
translate chinese Yaz_NS_B_ass_2187eade:

    # Yazmin "Ow!"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:422
translate chinese Yaz_NS_B_ass_9c14818a:

    # MC "(Fuck! I must have bitten too hard! I gotta run!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:424
translate chinese Yaz_NS_B_ass_a44de962:

    # MC "(Fuck! I must have bitten too hard! She’s gonna be pissed! I gotta run!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:427
translate chinese Yaz_NS_B_ass_634d8716:

    # Liza "Hmm..? You okay, Honey..?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:429
translate chinese Yaz_NS_B_ass_ccb7b3f5:

    # Yazmin "Ugh... yeah... Fucking mosquito bit me..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:430
translate chinese Yaz_NS_B_ass_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:431
translate chinese Yaz_NS_B_ass_6833411a:

    # Yazmin "*Sigh* I’ll have to make sure I close the windows, before we go to bed tomorrow night..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:433
translate chinese Yaz_NS_B_ass_513ac37a:

    # Yazmin "Ugh, yeah... [player_name] got a little overexcited when playing with me there."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:434
translate chinese Yaz_NS_B_ass_ae0bc390:

    # Liza "Oh, hehe... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:435
translate chinese Yaz_NS_B_ass_a1d4ff2f:

    # Yazmin "*Sigh* (Well, she fell asleep again quickly. At least[player_name] knows not to bite so hard next time!) "
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:442
translate chinese Yaz_NS_B_mouth_7171be00:

    # MC "(Let’s see if I can get her to suck my cock, while she is sleeping!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:444
translate chinese Yaz_NS_B_mouth_91f4cbe9:

    # MC "(Let’s see if Yazmin wants to suck my cock during the roleplay!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:445
translate chinese Yaz_NS_B_mouth_39fd951e:

    # MC "(She’s not in a bad position right now, for it... I’ll just need to tilt her head a little bit more, to face me.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:448
translate chinese Yaz_NS_B_mouth_4f97ab99:

    # MC "Easy does it..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:450
translate chinese Yaz_NS_B_mouth_8789160e:

    # Yazmin "(What’s he planning to do to me?)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:451
translate chinese Yaz_NS_B_mouth_d1e660d9:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:453
translate chinese Yaz_NS_B_mouth_32994171:

    # MC "Shush... it’s alright... Just a few more inches..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:455
translate chinese Yaz_NS_B_mouth_bf616065:

    # MC "(Just a few more inches.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:459
translate chinese Yaz_NS_B_mouth_a158d20d:

    # MC "(There we go! Perfect!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:461
translate chinese Yaz_NS_B_mouth_65b1df65:

    # MC "(She looks so damn sexy - even when she’s sleeping! How the hell does she do it?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:462
translate chinese Yaz_NS_B_mouth_e2093df2:

    # MC "(I know that I wake up, looking like complete shit.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:464
translate chinese Yaz_NS_B_mouth_a6e5c77f:

    # MC "(She looks so damn sexy! No wonder she’s a model!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:468
translate chinese Yaz_NS_B_mouth_053e228d:

    # MC "(Okay, let’s test it out with a finger, first! I don’t want her to accidentally bite me when I put my cock in.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:469
translate chinese Yaz_NS_B_mouth_a02ead5f:

    # MC "(I’ll have to be gentle here - lips are very sensitive parts of the body, and I could easily wake her up if I’m not careful!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:471
translate chinese Yaz_NS_B_mouth_ed3c17f7:

    # MC "(Okay, let’s test it out with a finger first and see if she’s into it.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:472
translate chinese Yaz_NS_B_mouth_6e9db1d9:

    # Yazmin "(Ahh, of course. He wants a blowjob!)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:475
translate chinese Yaz_NS_B_mouth_d1e660d9_1:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:477
translate chinese Yaz_NS_B_mouth_cbbfe9d5:

    # MC "(It sounds like she’s still sleeping... I think I’ve gotten away with it, so far. Let’s hope my luck keeps up!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:478
translate chinese Yaz_NS_B_mouth_e4ff1c44:

    # MC "(Okay... Now for the moment of truth... Hopefully she won’t bite down! I suppose losing a finger is better than losing your dick, though!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:480
translate chinese Yaz_NS_B_mouth_e2430cde:

    # MC "(She’s not objecting, sounds like she’s up for it! I’ll keep an ear open in case she changes her mind.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:481
translate chinese Yaz_NS_B_mouth_c8a2194b:

    # MC "(Okay, now for the moment of truth... Let’s see if she is as okay with my dick as she was with my finger.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:486
translate chinese Yaz_NS_B_mouth_db1fd57c:

    # MC "Phew..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:487
translate chinese Yaz_NS_B_mouth_3221c8ce:

    # MC "(She had me worried there, for a second... but it doesn’t seem like, she’s the type to bite down.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:488
translate chinese Yaz_NS_B_mouth_b94aec26:

    # MC "(Okay - let’s see how far I can take this...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:490
translate chinese Yaz_NS_B_mouth_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:491
translate chinese Yaz_NS_B_mouth_4419febf:

    # MC "(Yup! Seems like she’s enjoying this too!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:492
translate chinese Yaz_NS_B_mouth_d416f9fa:

    # MC "(Okay, let’s see how far I can take this.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:496
translate chinese Yaz_NS_B_mouth_4311f07d:

    # MC "(Alright - that’s her tongue out. It seems that she REALLY IS a deep sleeper.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:497
translate chinese Yaz_NS_B_mouth_e83c81dc:

    # MC "(I’ll let that, slide back in her mouth, and get my trousers unbuckled - Then I’ll be good, to push my penis in.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:500
translate chinese Yaz_NS_B_mouth_91c27684:

    # MC "(Damn... She has a really fine body! I’ll have to come back some other nights, to explore more parts.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:501
translate chinese Yaz_NS_B_mouth_874a9f76:

    # MC "(I’m sure I could have A LOT of fun with those sexy feet!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:505
translate chinese Yaz_NS_B_mouth_45b980ff:

    # MC "(Okay, that’s my cock out. Time for the main event!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:507
translate chinese Yaz_NS_B_mouth_13044b88:

    # MC "(My heart’s racing, right now... It’s gonna feel amazing, if I, somehow pull this off though.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:508
translate chinese Yaz_NS_B_mouth_e72b1d57:

    # MC "(I’ll have to try and not laugh, the next time I’m speaking with her. She won’t ever know, that she’s sucked my cock, while she was asleep! Haha!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:510
translate chinese Yaz_NS_B_mouth_b893e1fc:

    # Yazmin "(What’s taking him so long? If he wants a blowjob he should just hurry up and stick it in my mouth!)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:511
translate chinese Yaz_NS_B_mouth_e6f543d1:

    # MC "(My heart’s racing right now... This is gonna be amazing!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:516
translate chinese Yaz_NS_B_mouth_ff20330e:

    # MC "Ohhhh.... Wow..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:518
translate chinese Yaz_NS_B_mouth_a4ebe3bb:

    # Yazmin "*Slurrrrp*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:519
translate chinese Yaz_NS_B_mouth_b3059d42:

    # MC "(Holy shit, that’s good!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:520
translate chinese Yaz_NS_B_mouth_a605a230:

    # MC "(Her lips, just wrapped around the tip of my dick, like a vacuum seal!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:523
translate chinese Yaz_NS_B_mouth_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:524
translate chinese Yaz_NS_B_mouth_991eafe5:

    # Yazmin "*Deep breathing*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:525
translate chinese Yaz_NS_B_mouth_09b8562d:

    # MC "(She’s breathing through her nose now. At least, that’s stopped her snoring!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:529
translate chinese Yaz_NS_B_mouth_062b8286:

    # MC "(I’m gonna push it in now, and see how far I can take this.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:531
translate chinese Yaz_NS_B_mouth_de36d286:

    # MC "(I’m gonna push it in now and see how far she wants to go. I wonder if she’ll let me cum inside her mouth.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:532
translate chinese Yaz_NS_B_mouth_6c566a8b:

    # Yazmin "*Shluuuurrrrrp*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:533
translate chinese Yaz_NS_B_mouth_b79801e7:

    # MC "Ahh.... Oh...."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:536
translate chinese Yaz_NS_B_mouth_403fb735:

    # MC "(Fuck, this is good! I don’t think I’ll last much longer though.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:538
translate chinese Yaz_NS_B_mouth_a428b54c:

    # MC "(I wonder if I can get away with, cumming in her mouth. I don’t want to wake her up though...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:540
translate chinese Yaz_NS_B_mouth_3bad9d0e:

    # MC "(Fuck, this is good. I don’t think I’ll last much longer though.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:541
translate chinese Yaz_NS_B_mouth_584b61b4:

    # Yazmin "*Suck*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:543
translate chinese Yaz_NS_B_mouth_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:544
translate chinese Yaz_NS_B_mouth_c0966eb2:

    # MC "(She’s started sucking, by herself!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:546
translate chinese Yaz_NS_B_mouth_969e8917:

    # MC "Hnngg! Oohhh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:547
translate chinese Yaz_NS_B_mouth_f518ec1a:

    # MC "(She’s started sucking!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:550
translate chinese Yaz_NS_B_mouth_75d9ed1f:

    # MC "Ah! Fuck... Hnnnng!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:551
translate chinese Yaz_NS_B_mouth_4e041f7e:

    # Yazmin "*Suck Suck*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:554
translate chinese Yaz_NS_B_mouth_308a394d:

    # MC "(Shit! I’m cumming!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:555
translate chinese Yaz_NS_B_mouth_6f4acd7c:

    # Yazmin "*Gulp Gulp*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:557
translate chinese Yaz_NS_B_mouth_37ed9ccf:

    # Yazmin "(Mmm... I missed the taste of semen.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:561
translate chinese Yaz_NS_B_mouth_7c36bfd1:

    # MC "(Oh, my God... She just swallowed my cum, while she was sleeping!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:562
translate chinese Yaz_NS_B_mouth_a883939c:

    # MC "(Her subconsciousness, must REALLY be missing cocks!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:563
translate chinese Yaz_NS_B_mouth_66503eb2:

    # MC "(I better sneak out of here, pronto! The last thing I need, is her waking up with the taste of semen in her mouth!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:565
translate chinese Yaz_NS_B_mouth_fcb29639:

    # MC "(Oh my God... she just swallowed my cum!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:566
translate chinese Yaz_NS_B_mouth_1e540452:

    # MC "(She must have REALLY enjoyed our roleplay sessions!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:567
translate chinese Yaz_NS_B_mouth_6d83c300:

    # MC "(I’ll leave now and let those two catch up on their sleep.)"
    MC ""

translate chinese strings:

    # game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:193
    old "Play with Yazmin’s body, while she sleeps."
    new ""

    # game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:193
    old "Play with Yazmin’s body while she pretends to sleep."
    new ""

    # game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:193
    old "Play with [Liza_name]’s body, while she sleeps."
    new ""

    # game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:193
    old "Play with [Liza_name]’s body, while she pretends to sleep."
    new ""

    # game/scripts/A_home/Inside/Bedroom/N/scenes/LiR1_NS3_Yaz.rpy:193
    old "Cancel."
    new ""

