﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:35
translate chinese LiR1_MAS1a_label_ce75c1fb:

    # Yazmin "I caught him, lurking around the back of the house. He was perving on me, while I was sunbathing, Liza."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:36
translate chinese LiR1_MAS1a_label_733f7ad4:

    # MC "WHAT?! N-No, I wasn’t! I-"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:37
translate chinese LiR1_MAS1a_label_2ae6d828:

    # Yazmin "Hehe! I’m teasing!"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:41
translate chinese LiR1_MAS1a_label_8122d642:

    # Liza "Oh, c’mon Yazmin, you’re gonna scare the poor guy."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:43
translate chinese LiR1_MAS1a_label_a13f545c:

    # Liza "Long time no see! How’s my favourite nephew been doing? You’re at college now, right?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:44
translate chinese LiR1_MAS1a_label_03e734c1:

    # MC "I’m keeping well, Auntie Liza! Yeah - college is super busy. I gotta say, I love your new place. This house looks amazing!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:45
translate chinese LiR1_MAS1a_label_5c1524a3:

    # Liza "Oh please - you can just call me Liza. "
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:47
translate chinese LiR1_MAS1a_label_a6fe5eb6:

    # Liza "Long time no see! How have you been doing? You’re at college now, right?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:48
translate chinese LiR1_MAS1a_label_d8f4da43:

    # MC "I’m keeping well, Liza! Yeah - college is super busy. I gotta say, I love your new place. This house looks amazing!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:49
translate chinese LiR1_MAS1a_label_b9ba4833:

    # Liza "Aww, thank you! I put so much work into decorating it."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:53
translate chinese LiR1_MAS1a_label_3a2aa51b:

    # Liza "I’m guessing you’ve already caught up with Yazmin. Has she told you about, her new line of work?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:54
translate chinese LiR1_MAS1a_label_4d5a27c6:

    # MC "We spoke briefly, outside, but she didn’t mention her new job."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:55
translate chinese LiR1_MAS1a_label_e1a77a4b:

    # Liza "She’s a supermodel now!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:56
translate chinese LiR1_MAS1a_label_be852707:

    # Yazmin "You’re exaggerating, Liza. The only thing I really do is model clothes for local chains."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:57
translate chinese LiR1_MAS1a_label_4911fc7f:

    # Liza "Well, you look like a supermodel to me. Take a seat, [player_name]. Can I get you something to drink? "
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:58
translate chinese LiR1_MAS1a_label_eb196aeb:

    # MC "I’m alright - thanks for offering."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:77
translate chinese LiR1_MAS1a_menu_03488339:

    # MC "So, how long have you been living here then, [Liza_name]? Last time I visited you was back in that old bungalow on the West Coast."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:81
translate chinese LiR1_MAS1a_menu_59d853b1:

    # Liza "Wow, has it really been that long?! I must have been living here for... three or four years now."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:82
translate chinese LiR1_MAS1a_menu_83a14150:

    # MC "Seriously? Has it been that long?! I’m feeling bad now, for not visiting sooner!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:83
translate chinese LiR1_MAS1a_menu_6ebdc0b1:

    # Liza "Hehe, don’t worry about it! I remember how busy I was at your age. Honestly, it just felt like a video game at times, jumping from one event to the next. Do you know what I mean?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:84
translate chinese LiR1_MAS1a_menu_f3ebb9bd:

    # MC "Uhh... Yeah, I think so."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:88
translate chinese LiR1_MAS1a_menu_2f989c3f:

    # Liza "Anyway! Truth be told - I’m just glad to be out of that bungalow. The whole place stunk of dampness and mould. Moving into a new building was the best decision I ever made in my life!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:89
translate chinese LiR1_MAS1a_menu_01a24f4f:

    # MC "Great to hear! Glad it’s going well for you."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:97
translate chinese LiR1_MAS1a_menu_1be87dff:

    # MC "So, what are you working as now, [Liza_name]?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:98
translate chinese LiR1_MAS1a_menu_101e7295:

    # Liza "I’m a secretary at a local law firm. Answering calls, taking minutes, organising meetings. That kind of drudgery!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:99
translate chinese LiR1_MAS1a_menu_3e3c2790:

    # MC "Ah, kinda like a paralegal? Do you enjoy it?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:103
translate chinese LiR1_MAS1a_menu_2254796a:

    # Liza "Not quite. Paralegals are a bit more qualified than I am! As for whether I enjoy it... Not really. But it pays the bills. Does anyone really love their job?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:104
translate chinese LiR1_MAS1a_menu_014c1d05:

    # Yazmin "I could always get you into my line of work. There’s plenty of work for models in-"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:105
translate chinese LiR1_MAS1a_menu_aa72af8a:

    # Liza "No! I don’t have the body for that!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:113
translate chinese LiR1_MAS1a_menu_36bcfc9f:

    # MC "Did you want me to take a look at your swimming pool? I’m pretty good with my hands, and I can probably get it cleaned up for you, pretty quickly!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:114
translate chinese LiR1_MAS1a_menu_2c12413d:

    # Liza "Definitely! It’s an absolute pigsty right now! I’m happy to pay you if you can maintain it for us regularly."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:118
translate chinese LiR1_MAS1a_menu_5528a565:

    # MC "Sure, happy to help. Out of interest... Did you not think about hiring a professional maid or handyman to do this?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:120
translate chinese LiR1_MAS1a_menu_fe2d153d:

    # Yazmin "Yeah... your aunt hired a handyman a month ago. Tell [player_name] what happened, Liza."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:122
translate chinese LiR1_MAS1a_menu_fe4d3bc3:

    # Yazmin "Yeah... Liza hired a handyman a month ago. Tell [player_name] what happened, Liza."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:123
translate chinese LiR1_MAS1a_menu_33c55bf9:

    # Liza "*Sigh* I caught the bastard stealing my underwear when it was drying on the line."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:124
translate chinese LiR1_MAS1a_menu_1b8ff3e9:

    # MC "Haha! Wow! That’s insane!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:126
translate chinese LiR1_MAS1a_menu_d3334c73:

    # Liza "So yeah, in order to avoid any more... inappropriate situations, I’ve decided to reserve this particular job, in the family. Does that make sense?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:128
translate chinese LiR1_MAS1a_menu_9e2468d0:

    # Liza "So yeah, in order to avoid any more... inappropriate situations, I’ve decided to keep this particular job for someone I already know and trust. Does that make sense?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:132
translate chinese LiR1_MAS1a_menu_3e431d68:

    # MC "Yeah, I understand completely. I’d be creeped out too, if someone was stealing MY underwear."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:133
translate chinese LiR1_MAS1a_menu_a1f2bbaf:

    # Liza "Great! When are you free to start?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:134
translate chinese LiR1_MAS1a_menu_63f98392:

    # MC "Whenever you want."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:138
translate chinese LiR1_MAS1a_menu_7955e60e:

    # Liza "Hmm... In that case we have all the cleaning stuff you’ll need in the garage."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:139
translate chinese LiR1_MAS1a_menu_afe1f686:

    # Liza "The handyman left it behind, when Yazmin chased him away. He hasn’t shown up to collect it - so I guess it’s ours now."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:140
translate chinese LiR1_MAS1a_menu_0b8e3687:

    # MC "Cool! I’ll go and grab that."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:148
translate chinese LiR1_MAS1a_menu_f3196f3c:

    # Yazmin "It’s going to be so nice to be able to use our pool, together again. Especially with the warmer weather we’ve been having."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:149
translate chinese LiR1_MAS1a_menu_7d65e102:

    # Liza "If he finishes it today, perhaps you and I could take a swim together tonight. How does that sound?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:150
translate chinese LiR1_MAS1a_menu_eb736c5f:

    # Yazmin "Absolutely perfect, darling."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:155
translate chinese LiR1_MAS1a_menu_ad272199:

    # Liza "I love you so much."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:156
translate chinese LiR1_MAS1a_menu_3bbb0af9:

    # Yazmin "I love you too, my sugar pie."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:157
translate chinese LiR1_MAS1a_menu_8c33475d:

    # MC "(Hmm... Well, this is starting to get a little bit awkward.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:161
translate chinese LiR1_MAS1a_menu_636f5ac8:

    # MC "(They’re not going to seriously start making out in front of me... are they?)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:163
translate chinese LiR1_MAS1a_menu_327bd353:

    # MC "(I mean, Auntie Liza and Yazmin have been married for quite a few years now - but they’re not going to just start snogging each other, right in front of their nephew.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:165
translate chinese LiR1_MAS1a_menu_501cdf7a:

    # MC "(I mean, Liza and Yazmin have been married for quite a few years now - but they’re not going to just start snogging each other right in front of-)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:166
translate chinese LiR1_MAS1a_menu_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:170
translate chinese LiR1_MAS1a_menu_2585411f:

    # Liza "Mmm!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:171
translate chinese LiR1_MAS1a_menu_a483be82:

    # Yazmin "Ohmmmm!"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:172
translate chinese LiR1_MAS1a_menu_9c198980:

    # MC "(And... I guess it’s time for me to leave.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:176
translate chinese LiR1_MAS1a_menu_9feea2d6:

    # MC "I’ll... erm... just go. I’ll be back tomorrow, to start cleaning the swimming pool. Okay?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:177
translate chinese LiR1_MAS1a_menu_6b4382dd:

    # Yazmin "Mmm!"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:178
translate chinese LiR1_MAS1a_menu_16b7983a:

    # MC "(Yeah, I don’t think they can hear me. I’ll just sneak out...) "
    MC ""

translate chinese strings:

    # game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:73
    old "How long have you been living in your new house, [Liza_name]?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:73
    old "What are you working as, [Liza_name]?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS1a.rpy:73
    old "{color=#00ff00}Did you want me to come over to take a look at your swimming pool?{/color}"
    new ""

