﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:23
translate chinese LiR1_MAS1_label_37265de6:

    # Yazmin "Why, hello there. If it isn't [player_name]. It’s been years since I last saw you. How’ve you been?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:25
translate chinese LiR1_MAS1_label_004b40f1:

    # MC "Yeah, I think it was - the family barbeque on the beach."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:27
translate chinese LiR1_MAS1_label_40a7f3ba:

    # MC "Yeah, I think it was at the big barbeque on the beach. Remember Bob brought down that hog roast?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:28
translate chinese LiR1_MAS1_label_7def22a8:

    # Yazmin "Oh my God, yes! That was it. Geez, that must have been two or three years ago? You don’t look a day older than when I last saw you."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:32
translate chinese LiR1_MAS1_label_cb7a606d:

    # MC "Thanks, Yazmin. You’re looking great too."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:33
translate chinese LiR1_MAS1_label_6f425029:

    # MC "(She was wearing a similar bikini all those years ago on the beach too. I remember staring at her from the dunes while the sun set into the Pacific Ocean.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:36
translate chinese LiR1_MAS1_label_5ecb65bd:

    # MC "(Mom had gone for a walk with Caroline, while Dad slept on the - warm golden sand. I think Auntie and Sara were beginning to pack away some beach towels.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:38
translate chinese LiR1_MAS1_label_24919ab1:

    # MC "(Linda had gone for a walk with Caroline while Bob dozed off on the warm golden sands. I think Liza and Sara were beginning to pack away some beach towels.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:39
translate chinese LiR1_MAS1_label_e76e65c1:

    # MC "(Yazmin was lying at the water’s edge - so the waves would lap at her feet every few seconds.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:42
translate chinese LiR1_MAS1_label_745dc73f:

    # Yazmin "So, what brings you over today?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:44
translate chinese LiR1_MAS1_label_5341c89b:

    # MC "I’m actually here to help clean the pool. My aunt mentioned - it was in need of a thorough scrubbing."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:46
translate chinese LiR1_MAS1_label_c650fa4b:

    # MC "I’m actually here to help clean the pool. Liza mentioned it was in need of a thorough scrubbing."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:47
translate chinese LiR1_MAS1_label_be15bb4f:

    # MC "(I love the way the sunlight falls on her hair. I hope she doesn’t notice my eyes wandering over her body.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:51
translate chinese LiR1_MAS1_label_94f27132:

    # Yazmin "Ugh. Don’t get me started on that fucking pool. It’s a curse! I wish I’d never bought the damn thing."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:52
translate chinese LiR1_MAS1_label_1f56319f:

    # MC "Really? Why?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:53
translate chinese LiR1_MAS1_label_1aa24a1d:

    # Yazmin "You spend two hours dragging all the detritus out with a net and the next day it’s filled up again with drowned bugs, garbage, and rotting leaves."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:54
translate chinese LiR1_MAS1_label_aad0726c:

    # Yazmin "Well, that’s your problem now. I swear, I think I’d go crazy if I had to clean that Godawful thing one more time!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:58
translate chinese LiR1_MAS1_label_5f1e4106:

    # MC "Well, put that out of your head. I’m gonna be cleaning it, from now on. I really need the money! Haha!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:59
translate chinese LiR1_MAS1_label_f463ddfe:

    # Yazmin "I know exactly how it is - trust me. The things I used to do for money, when I was your age..."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:60
translate chinese LiR1_MAS1_label_1c1b5038:

    # MC "What did you work as?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:61
translate chinese LiR1_MAS1_label_48f806ce:

    # Yazmin "Err... Forget I said that."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:66
translate chinese LiR1_MAS1_label_9c565c86:

    # Yazmin "I think your aunt was inside the house last time I saw her. She doesn't like being out in the heat on scorching days like this."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:68
translate chinese LiR1_MAS1_label_e4f2938c:

    # Yazmin "I think Liza was inside the house last time I saw her. She doesn't like being out in the heat on scorching days like this."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:69
translate chinese LiR1_MAS1_label_ba9241ab:

    # Yazmin "(Damn, this little guy would look so hot cleaning our pool. No shirt, no pants - just a tight pair of Y-fronts. God... just thinking about it is getting me super wet!)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:70
translate chinese LiR1_MAS1_label_787c8a3f:

    # MC "Yeah, she’s never been the sunbathing type. How do I get inside?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:74
translate chinese LiR1_MAS1_label_7574a3bc:

    # Yazmin "Oh! I forgot, you probably haven’t visited our new place yet."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:75
translate chinese LiR1_MAS1_label_07a2bbf0:

    # MC "Yeah, it’s my first time here."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:76
translate chinese LiR1_MAS1_label_08453b5d:

    # Yazmin "That’s okay. The back door is just over there at the top of those steps."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:80
translate chinese LiR1_MAS1_label_0687dc40:

    # Yazmin "Are you okay, going around the front entrance? I’ll need some privacy to get changed out of my swimsuit."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:81
translate chinese LiR1_MAS1_label_785de004:

    # MC "Sure. No problem."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:82
translate chinese LiR1_MAS1_label_c8f8af9c:

    # Yazmin "(I wonder how large his package is down there... Now that [player_name] will be cleaning our pool we might have him over more regularly. Perhaps I’ll get a chance to see his cock.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:86
translate chinese LiR1_MAS1_label_179b9cd3:

    # Yazmin "Head on round the front. I’ll meet you and your aunt inside after I get changed."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:88
translate chinese LiR1_MAS1_label_6049b1e3:

    # Yazmin "Head on round the front. I’ll meet you and Liza inside after I get changed."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS1.rpy:89
translate chinese LiR1_MAS1_label_46f3a3c9:

    # MC "Cool. I’ll see you in a few minutes!"
    MC ""

