﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Garage/M/scenes/Li_Car.rpy:20
translate chinese Li_car_label_money_d8293799:

    # MC "Nice! +[money]$"
    MC ""

