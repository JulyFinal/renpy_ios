﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Living/E/a_living_E.rpy:9
translate chinese a_living_E1_aeb91391:

    # MC "(It's locked.)"
    MC ""

