﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:36
translate chinese LiR1_MAS4_label_ae9c9fa8:

    # MC "Hello? Auntie Liza? Yazmin?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:38
translate chinese LiR1_MAS4_label_3493d669:

    # MC "Hello? Liza? Yazmin?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:39
translate chinese LiR1_MAS4_label_1cefb823:

    # MC "Anybody?!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:40
translate chinese LiR1_MAS4_label_9f44814d:

    # MC "(Where the heck has everyone gone? Maybe they’re at work.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:44
translate chinese LiR1_MAS4_label_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:45
translate chinese LiR1_MAS4_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:46
translate chinese LiR1_MAS4_label_de453ffe:

    # MC "(I think I heard a footstep from the bathroom.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:50
translate chinese LiR1_MAS4_label_f2adbf6e:

    # MC "(Holy shit! It’s [Liza_name]!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:51
translate chinese LiR1_MAS4_label_c8bcdd8f:

    # MC "(She must have just finished, having a bath. It looks like she’s getting changed.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:52
translate chinese LiR1_MAS4_label_b5e5c3eb:

    # MC "(Wow! Just look at - the ass on her! It’s amazing!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:56
translate chinese LiR1_MAS4_label_9945a18a:

    # MC "(Goddamn... It’s a shame that she’s a lesbian. If she was bi, then I would have at least had a small chance of getting into her.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:57
translate chinese LiR1_MAS4_label_5c1276ff:

    # MC "(Her skin is so smooth, as well. I’m getting so hard, just staring at those pantyhose, she’s wearing.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:58
translate chinese LiR1_MAS4_label_a1bb50ba:

    # Liza "C’mon... hook into place, for me..."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:62
translate chinese LiR1_MAS4_label_339a108d:

    # Liza "There we go... Perfect!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:63
translate chinese LiR1_MAS4_label_55c1d9bd:

    # MC "(Her tits are fucking huge! They might even be larger than [Mom_name]’s!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:64
translate chinese LiR1_MAS4_label_8aac8a00:

    # MC "(Yazmin is a lucky woman. Imagine, getting to suck and lick those breasts, every night.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:68
translate chinese LiR1_MAS4_label_b1c2352a:

    # Liza "Yeah... the white ones, suit me much better."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:69
translate chinese LiR1_MAS4_label_a4354e3c:

    # Liza "(I don’t know why I ever thought, I should switch to grey.)"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:70
translate chinese LiR1_MAS4_label_744571ae:

    # Liza "(Yazmin is going to LOVE these! I can’t wait to strip down to these, tonight, and go down on her. She’s going to cum soooo hard!)"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:74
translate chinese LiR1_MAS4_label_58b5901a:

    # MC "(Okay, this is getting a little bit dangerous... I should probably back away now, before [Liza_name] catches me peeping in at her.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:76
translate chinese LiR1_MAS4_label_a0dbe459:

    # MC "(Okay, this is getting a little bit dangerous... I should probably back away now, before she catches me peeping in at her.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:77
translate chinese LiR1_MAS4_label_0835e7ba:

    # MC "(She does have an incredible body though... I wish I had a camera with me, to snap some pictures.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:81
translate chinese LiR1_MAS4_label_43e8359c:

    # MC "(Mmm... It looks like she keeps her bush trimmed neatly as well.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:82
translate chinese LiR1_MAS4_label_9c31b015:

    # MC "(My cock would fit so perfectly in there. She’s probably super tight given that she’s never been with a guy before...)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:86
translate chinese LiR1_MAS4_label_32179b6e:

    # Yazmin "(Well, well, well... What do we have here?)"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:87
translate chinese LiR1_MAS4_label_2afe5327:

    # Yazmin "Ahem!"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:90
translate chinese LiR1_MAS4_label_ccd43c58:

    # MC "Huh?!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:91
translate chinese LiR1_MAS4_label_d9a1fc52:

    # MC "(Oh shit!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:95
translate chinese LiR1_MAS4_label_fa967fa0:

    # Liza "Is that you home, Yazmin?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:96
translate chinese LiR1_MAS4_label_bee36e35:

    # Yazmin "Yeah, that’s me home! I’m just going upstairs to the bedroom. I’ll see you in fifteen minutes?"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:97
translate chinese LiR1_MAS4_label_acd0b6b8:

    # Liza "Perfect! See you then, darling!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:98
translate chinese LiR1_MAS4_label_b0d5ff21:

    # Yazmin "*Whispered* Okay you little perv, follow me upstairs. We’re going to sort this out right now."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:99
translate chinese LiR1_MAS4_label_78441245:

    # MC "(Fuck! I am in so much shit... At least Yazmin hasn’t given me up to [Liza_name] yet.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:105
translate chinese LiR1_MAS4_label_3c50de5d:

    # Yazmin "So... What am I to do with the little pervert spying on his auntie?"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:107
translate chinese LiR1_MAS4_label_74a5b4da:

    # Yazmin "So... What am I to do with the little pervert spying on my wife?"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:108
translate chinese LiR1_MAS4_label_46c55adf:

    # MC "I... uh... was just looking for the... pool cleaning... stuff."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:109
translate chinese LiR1_MAS4_label_1ca2ccb3:

    # Yazmin "You’re a miserable liar, fella. I should just turn you in to the cops right now. Y’know that?"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:110
translate chinese LiR1_MAS4_label_208bac11:

    # MC "W-wait! You don’t have to-"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:114
translate chinese LiR1_MAS4_label_8755edb8:

    # Yazmin "I’ll tell you what - I’ll make you a deal."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:115
translate chinese LiR1_MAS4_label_e68773c7:

    # MC "Anything!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:116
translate chinese LiR1_MAS4_label_6f1ee682:

    # Yazmin "Pull down your pants."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:117
translate chinese LiR1_MAS4_label_11b995f4:

    # MC "M-My pants?! Why?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:121
translate chinese LiR1_MAS4_label_41685b06:

    # Yazmin "Because I need to check something. Now, hurry up and do it, before I lose my patience with you."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:122
translate chinese LiR1_MAS4_label_4ff8d775:

    # MC "Alright fine! Two seconds."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:123
translate chinese LiR1_MAS4_label_2c55f6e4:

    # MC "(What the hell does she want?)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:124
translate chinese LiR1_MAS4_label_403f8332:

    # MC "(Crap, my cock is still hard... I hope she doesn’t notice it!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:128
translate chinese LiR1_MAS4_label_20f21c4a:

    # Yazmin "Okay - that’s perfect... Hmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:129
translate chinese LiR1_MAS4_label_3b1d9e97:

    # Yazmin "It’s been so long since I last saw one, in real life."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:130
translate chinese LiR1_MAS4_label_4bf5bc83:

    # MC "Are you not a lesbian?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:131
translate chinese LiR1_MAS4_label_31ded71f:

    # Yazmin "I go both ways, pal. Now, just you stand right there."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:135
translate chinese LiR1_MAS4_label_3d0c4752:

    # Yazmin "Yes... That’s probably about the right thickness."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:136
translate chinese LiR1_MAS4_label_0f3cef7f:

    # Yazmin "I just need to double check the length, then we can get this show on the road."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:140
translate chinese LiR1_MAS4_label_95f55dba:

    # Yazmin "Aha! There we go, I knew I had it lying around somewhere."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:141
translate chinese LiR1_MAS4_label_5cafcc3d:

    # MC "W-Wait! Is that a dildo?! You’re not planning to use that on me, are you?!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:142
translate chinese LiR1_MAS4_label_60a77af1:

    # Yazmin "Hmm... I wasn’t. But you know something - that’s not a bad idea!"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:146
translate chinese LiR1_MAS4_label_c4dcfa8f:

    # MC "WHAT?!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:147
translate chinese LiR1_MAS4_label_27322773:

    # Yazmin "I’m teasing you. Now, hold still and keep your voice down, or Liza will hear you. This will only take a second."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:148
translate chinese LiR1_MAS4_label_b0579874:

    # MC "Well, that’s a slight relief."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:152
translate chinese LiR1_MAS4_label_21883848:

    # Yazmin "Okay... your cock is, only a little bit bigger than my toy. Hardly noticeable - in the heat of the moment..."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:153
translate chinese LiR1_MAS4_label_a1a9959b:

    # MC "Heat of the moment? What do you mean?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:154
translate chinese LiR1_MAS4_label_cfb4500e:

    # Yazmin "Oh yeah - this is perfect. Mmm... I can’t wait for tonight..."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:155
translate chinese LiR1_MAS4_label_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:156
translate chinese LiR1_MAS4_label_256971f9:

    # MC "(She can’t wait for tonight...?)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:160
translate chinese LiR1_MAS4_label_12f5b189:

    # Yazmin "All done. You can go now!"
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:161
translate chinese LiR1_MAS4_label_dd8c27ff:

    # MC "Wait - just like that? What about - you catching me-"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:163
translate chinese LiR1_MAS4_label_3a0422b5:

    # Yazmin "I said you can go now. Your aunt will be coming upstairs soon - and I HIGHLY doubt, you want to be standing in front of me with no pants on, when she comes in."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:165
translate chinese LiR1_MAS4_label_0b3fcd5d:

    # Yazmin "I said you can go now. Liza will be coming upstairs soon - and I HIGHLY doubt, you want to be standing in front of me with no pants on when she comes in."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:166
translate chinese LiR1_MAS4_label_1ca20a74:

    # MC "Good point."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:170
translate chinese LiR1_MAS4_label_a5db65f1:

    # MC "Are we square, then?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:171
translate chinese LiR1_MAS4_label_f206eb98:

    # Yazmin "Eh... For now. I might need to borrow you again, in the future. But for the meantime, I have everything I need."
    Yazmin ""

# game/scripts/A_home/Inside/Living/M/scenes/LiR1_MAS4.rpy:172
translate chinese LiR1_MAS4_label_bf2513c1:

    # MC "Okay, see you later... I guess."
    MC ""

