﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:17
translate chinese LiR1_MAS8_label_caa7d502:

    # MC "(I've already talked to her. I should go talk to [Liza_name].)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:32
translate chinese LiR1_MAS8_label_da7f3080:

    # Yazmin "(Ohh... here comes the star of the show!)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:33
translate chinese LiR1_MAS8_label_c20af431:

    # MC "(Yazmin’s looking pretty intently at me! I wonder what’s on her mind, after the last fiasco when I fucked her, in front of [Liza_name].)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:37
translate chinese LiR1_MAS8_label_09a988c0:

    # Yazmin "Hello there, handsome."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:38
translate chinese LiR1_MAS8_label_074d4010:

    # MC "Hey, Yazmin."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:39
translate chinese LiR1_MAS8_label_6f471ca8:

    # Yazmin "Have you recovered, after your last round with me?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:40
translate chinese LiR1_MAS8_label_8e916436:

    # MC "Huh? What do you mean?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:44
translate chinese LiR1_MAS8_label_ab760856:

    # Yazmin "I seem to recall you, cumming very... very... hard. And honestly ...rather quickly - when I was riding you."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:45
translate chinese LiR1_MAS8_label_acc69dea:

    # MC "Shush! [Liza_name] might hear you! Was she not - super pissed off at you, afterwards?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:46
translate chinese LiR1_MAS8_label_e9fd8779:

    # Yazmin "No? Why would she be?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:50
translate chinese LiR1_MAS8_label_cc852204:

    # MC "It REALLY sounded like she was furious with you! I mean, you WERE practically cheating on her, right in front of her face!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:51
translate chinese LiR1_MAS8_label_c3de1e58:

    # Yazmin "Hehe... I guess I kinda was. At least I was blatantly honest about it though."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:52
translate chinese LiR1_MAS8_label_51ff7822:

    # MC "Umm... you kinda weren’t. Remember the ice lolly and the blindfold?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:56
translate chinese LiR1_MAS8_label_edbbf366:

    # Yazmin "Heeeey! This isn’t ALL my fault! You participated too! Don’t make ME out to be the ONLY bad guy here!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:58
translate chinese LiR1_MAS8_label_bdb52aa1:

    # Yazmin "*Sigh* Anyway - I’m not here to get into an argument with you. Your Aunt Liza has calmed down."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:60
translate chinese LiR1_MAS8_label_fa0657a9:

    # Yazmin "*Sigh* Anyway, I’m not going to get into an argument with you over this. Liza has calmed down."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:61
translate chinese LiR1_MAS8_label_54fa0230:

    # MC "Really? She’s not angry at me?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:66
translate chinese LiR1_MAS8_label_90cfc28d:

    # Yazmin "I’m almost certain she’s not..."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:67
translate chinese LiR1_MAS8_label_31241d30:

    # MC "Almost certain?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:69
translate chinese LiR1_MAS8_label_b8a0653f:

    # Yazmin "I mean, she’s probably still A LITTLE bit pissed at me for making her suck your cock... But that was- Ugh... fine! I’ll admit it - That was my bad."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:71
translate chinese LiR1_MAS8_label_54c72f64:

    # Yazmin "I mean, she’s probably still a LITTLE bit pissed at me for having sex with you in front of her... btu that was... UGh! Fine! I’ll admit it, that was my bad. I got carried away."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:75
translate chinese LiR1_MAS8_label_2005478f:

    # Yazmin "Anyway, half my degree was in public relations. I’m EXTREMELY good, at swaying people’s opinions."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:76
translate chinese LiR1_MAS8_label_ba51722e:

    # MC "What are you getting at?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:78
translate chinese LiR1_MAS8_label_f8300da3:

    # Yazmin "Your aunt is now waiting for you in the bathroom - for round two."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:80
translate chinese LiR1_MAS8_label_e4557ad2:

    # Yazmin "Liza is now waiting for you in the bathroom - for round two."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:81
translate chinese LiR1_MAS8_label_a1bdb64e:

    # MC "Round two of what?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:82
translate chinese LiR1_MAS8_label_75b536ba:

    # Yazmin "Just go inside and talk with her. Please...?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS8.rpy:83
translate chinese LiR1_MAS8_label_5a3b9239:

    # MC "(I hope she’s not gonna kill me, and Yazmin is not lying...)"
    MC ""

