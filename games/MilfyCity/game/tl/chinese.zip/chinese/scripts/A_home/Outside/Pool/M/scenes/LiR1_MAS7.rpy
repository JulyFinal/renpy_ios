﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:58
translate chinese LiR1_MAS7_label_387e6a4a:

    # MC "(I should go for a beer.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:82
translate chinese LiR1_MAS7_label_cce69afd:

    # Yazmin "...and then he told me, “Well, if you want to earn the big bucks, you’ve gotta lose that bra!”"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:83
translate chinese LiR1_MAS7_label_86b046eb:

    # Liza "OMG! No way! What did you say?!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:84
translate chinese LiR1_MAS7_label_08cbe8e5:

    # Yazmin "I told him, he can stick his money up his ass. And that he’s not getting the rights to any of the pictures we took."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:88
translate chinese LiR1_MAS7_label_8afe9c56:

    # Liza "You’ll have to call your agent - I don’t want you putting yourself at risk, doing photoshoots for these creepy... perverts!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:89
translate chinese LiR1_MAS7_label_3376db62:

    # Yazmin "Relax, Dear. I’m fine. I can handle myself. Besides, I’ve already called my agent and let him know. They’ll blacklist the guy - he’ll be getting no more models from us."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:90
translate chinese LiR1_MAS7_label_87358915:

    # Liza "Oh, thank God... I really worry about you sometimes, you know that? I get nightmares of you being attacked, by one of those perverted bastards..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:94
translate chinese LiR1_MAS7_label_dd7f0077:

    # Yazmin "Liza, there’s no difference between a photoshoot, and me walking down the street. Pervs are gonna perv. That’s the way it’s always been. You just gotta stand up to them."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:95
translate chinese LiR1_MAS7_label_e9ef6ab9:

    # Liza "I guess so..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:96
translate chinese LiR1_MAS7_label_2dea45dd:

    # Yazmin "Relax - and drink with me. Some champagne, will help take your mind off things."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:97
translate chinese LiR1_MAS7_label_df7863b0:

    # MC "(It sounds like [Liza_name] is having a - pretty intense discussion - about her wife’s line of work...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:103
translate chinese LiR1_MAS7_label_2ef8a69f:

    # Liza "You’d tell me... right?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:104
translate chinese LiR1_MAS7_label_fbd43c63:

    # Yazmin "Tell you what, Honey?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:105
translate chinese LiR1_MAS7_label_e47d4d5e:

    # Liza "If you ever started doing... adult films, instead of just fashion modelling."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:106
translate chinese LiR1_MAS7_label_f0e789c1:

    # Yazmin "Haha! I’m not going into the porn industry, Liza. I wouldn’t betray your trust, like that."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:110
translate chinese LiR1_MAS7_label_105287b8:

    # Yazmin "Remember what we vowed together, on our wedding day? Complete openness and honesty."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:111
translate chinese LiR1_MAS7_label_ede174df:

    # Yazmin "I’ve never cheated on you, Liza, and I never could. You’re the only one for me."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:112
translate chinese LiR1_MAS7_label_0dc38abc:

    # Liza "Promise?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:113
translate chinese LiR1_MAS7_label_5468ac87:

    # Yazmin "I promise."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:117
translate chinese LiR1_MAS7_label_2105b784:

    # Liza "Mmm..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:118
translate chinese LiR1_MAS7_label_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:119
translate chinese LiR1_MAS7_label_3fd1bc1e:

    # MC "(Uh oh! Maybe I should have announced my presence sooner.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:123
translate chinese LiR1_MAS7_label_f206d2cd:

    # MC "Hello..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:124
translate chinese LiR1_MAS7_label_6b4382dd:

    # Yazmin "Mmm!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:125
translate chinese LiR1_MAS7_label_ee566ea3:

    # MC "(Well - shit! This is just getting awkward now.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:129
translate chinese LiR1_MAS7_label_5a28de91:

    # Liza "I love you so much, Yazmin."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:130
translate chinese LiR1_MAS7_label_61a84e26:

    # Yazmin "I love you too, Liza."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:131
translate chinese LiR1_MAS7_label_f2bb8b6d:

    # MC "(Okay, I think I can pretend that I’ve just arrived.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:139
translate chinese LiR1_MAS7_label_2c1087c4:

    # MC "Hey guys! Hope I’m not bothering you!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:140
translate chinese LiR1_MAS7_label_d94a885f:

    # Liza "Oh! Hi there, [player_name]! Were you, uh... standing there long?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:141
translate chinese LiR1_MAS7_label_9368fdf8:

    # MC "No, I just arrived."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:142
translate chinese LiR1_MAS7_label_2da50db5:

    # Liza "(Thank God...)"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:143
translate chinese LiR1_MAS7_label_a2be5d24:

    # Yazmin "Are you driving today?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:144
translate chinese LiR1_MAS7_label_ce67ae7b:

    # MC "No. Why?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:145
translate chinese LiR1_MAS7_label_2ab3a830:

    # Yazmin "Great! That means you’re joining us for drinks. We’ve used the last of the champagne, but there’s plenty of beer in the fridge. Go and grab yourself - a cold one."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:146
translate chinese LiR1_MAS7_label_055ccf74:

    # MC "Sweet! Thanks, Yazmin!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:148
translate chinese LiR1_MAS7_label_824aaa9a:

    # MC "(Hmm... The house is empty now... Maybe I could find something interesting?)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:163
translate chinese LiR1_MAS7_label_con1_63e4486b:

    # MC "Thanks for the beer, Yazmin."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:164
translate chinese LiR1_MAS7_label_con1_c12ae0aa:

    # Yazmin "No problem! We’ve got plenty in the fridge so if you want another one-"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:166
translate chinese LiR1_MAS7_label_con1_fb56a154:

    # Liza "Umm... maybe not... And PLEASE don’t tell your mother about this, [player_name]."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:168
translate chinese LiR1_MAS7_label_con1_5581003f:

    # Liza "Umm, maybe not. And PLEASE don’t tell Linda about this, [player_name]. I know she doesn’t like her tenants drinking."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:170
translate chinese LiR1_MAS7_label_con1_2284bff7:

    # Yazmin "Oh, come on Liza, it’s just a beer."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:173
translate chinese LiR1_MAS7_label_con1_9c86f0d9:

    # Liza "I don’t want Linda thinking we’re trying to get childrens drunk!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:175
translate chinese LiR1_MAS7_label_con1_d61860e4:

    # Liza "I don’t want Linda thinking we’re trying to get her tenants drunk!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:179
translate chinese LiR1_MAS7_label_con1_34a11dbe:

    # MC "Haha! Don’t worry. I won’t say a word!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:180
translate chinese LiR1_MAS7_label_con1_c4f90405:

    # Liza "So, what are your plans today?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:181
translate chinese LiR1_MAS7_label_con1_82a0e8e5:

    # MC "Nothing much - just taking it easy and relaxing. What about, you two?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:185
translate chinese LiR1_MAS7_label_con1_46c40bec:

    # Yazmin "We’re both off work today - decided to use our holidays, and make the most of the brilliant weather!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:186
translate chinese LiR1_MAS7_label_con1_a7120225:

    # MC "Cheers to that!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:187
translate chinese LiR1_MAS7_label_con1_c96c1362:

    # Yazmin "Thanks again, for working so hard on our pool. It’s great to have it ready to use, whenever we want."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:191
translate chinese LiR1_MAS7_label_con1_442bcb5b:

    # MC "No problem! I’m happy to help. You guys are great to work for."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:192
translate chinese LiR1_MAS7_label_con1_dc2686ad:

    # MC "(Plus, I get to look at your - smoking hot bodies - all the time, without you knowing! Haha!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:193
translate chinese LiR1_MAS7_label_con1_981df184:

    # Yazmin "(This little pervert, probably enjoys working for us, because he gets to see us, in our bikinis so much.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:197
translate chinese LiR1_MAS7_label_con1_28ee7fbb:

    # Liza "Your mother doesn’t mind you coming over here, all the time, does she?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:199
translate chinese LiR1_MAS7_label_con1_67721feb:

    # Liza "Linda doesn’t mind you coming over here all the time, does she? I know she really wants her tenants focused on their studies."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:201
translate chinese LiR1_MAS7_label_con1_4a9aff8d:

    # MC "I don’t think so. I haven’t really told her where I’m going."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:202
translate chinese LiR1_MAS7_label_con1_3e96fd29:

    # Liza "Ahh... Well, it’s probably best not to draw her attention to it much."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:203
translate chinese LiR1_MAS7_label_con1_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:207
translate chinese LiR1_MAS7_label_con1_dac4121a:

    # Yazmin "(Uh oh! Things sounds like they’re gonna get awkward, if this conversation continues.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:208
translate chinese LiR1_MAS7_label_con1_044c2694:

    # Yazmin "(Time to interrupt this, before things get worse!)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:209
translate chinese LiR1_MAS7_label_con1_7d7f6669:

    # Yazmin "Last one in the pool is a loser!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:210
translate chinese LiR1_MAS7_label_con1_e18c8618:

    # Liza "Huh?!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:214
translate chinese LiR1_MAS7_label_con1_da3dad84:

    # Yazmin "Wahooo!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:215
translate chinese LiR1_MAS7_label_con1_8828d70b:

    # Liza "Yazmin!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:216
translate chinese LiR1_MAS7_label_con1_e89f719a:

    # MC "Huh?! What got into her?!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:217
translate chinese LiR1_MAS7_label_con1_a979b0b1:

    # Liza "I have... no idea..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:222
translate chinese LiR1_MAS7_label_con1_f2534168:

    # Liza "Shall we join her?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:223
translate chinese LiR1_MAS7_label_con1_2d160dcb:

    # MC "Yeah, let’s go!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:224
translate chinese LiR1_MAS7_label_con1_ea0e9bd3:

    # Liza "Okay! You dive in there, I’m not feeling like swimming today. I think I’ve had a little too much champagne. I’m gonna relax on the lilo."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:225
translate chinese LiR1_MAS7_label_con1_079328b3:

    # MC "No problem. See you from the water."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:231
translate chinese LiR1_MAS7_label_con1_456e0ee9:

    # MC "Are you sure you don’t want to come into the pool, [Liza_name]? It’s really cool!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:233
translate chinese LiR1_MAS7_label_con1_176e419c:

    # MC "Are you sure you don’t want to come into the pool? The water is really cool!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:234
translate chinese LiR1_MAS7_label_con1_5bfdd619:

    # Liza "Don’t worry, I’m still feeling a little light-headed from the alcohol."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:235
translate chinese LiR1_MAS7_label_con1_96592521:

    # MC "Okay, as long as you’re sure."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:236
translate chinese LiR1_MAS7_label_con1_989423aa:

    # Yazmin "She’s always been like that, [player_name]. She never swims after a drink."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:240
translate chinese LiR1_MAS7_label_con1_3b8d4987:

    # MC "That’s quite a fancy ring you’re wearing!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:242
translate chinese LiR1_MAS7_label_con1_006f627e:

    # Liza "Oh! Yeah, I got the one on my right hand, when your aunt and I took a holiday to Switzerland."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:244
translate chinese LiR1_MAS7_label_con1_0520f6a9:

    # Liza "Oh! Yeah, I got the one on my right hand, when Yazmin and I took a holiday to Switzerland."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:245
translate chinese LiR1_MAS7_label_con1_5b606049:

    # MC "You two went to Switzerland?!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:250
translate chinese LiR1_MAS7_label_con1_7bc0b35d:

    # Liza "And Austria, and France, and Czechoslovakia!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:251
translate chinese LiR1_MAS7_label_con1_e9880e40:

    # Yazmin "Czechoslovakia doesn’t exist, Honey! We went to the CZECH REPUBLIC!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:252
translate chinese LiR1_MAS7_label_con1_d62e40b9:

    # Liza "Oops! Sorry, Dear! Hehe..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:256
translate chinese LiR1_MAS7_label_con1_200da58d:

    # Liza "It was a skiing holiday, mostly. I was pretty good at it. Your Auntie Yazmin was atrocious through, she couldn’t keep herself, up straight, on the slopes."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:258
translate chinese LiR1_MAS7_label_con1_7d8440fd:

    # Liza "It was a skiing holiday, mostly. I was pretty good at it. Yazmin was atrocious through, she couldn’t keep herself, up straight, on the slopes."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:259
translate chinese LiR1_MAS7_label_con1_790b8e2b:

    # MC "Haha! Did she get any better, after practice?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:260
translate chinese LiR1_MAS7_label_con1_38ae0845:

    # Liza "Honestly? No! Haha!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:264
translate chinese LiR1_MAS7_label_con1_df7b6ec8:

    # Liza "Sorry, I was just teasing you, Dear."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:265
translate chinese LiR1_MAS7_label_con1_7acf2e64:

    # Liza "Dear?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:266
translate chinese LiR1_MAS7_label_con1_acc57a3f:

    # MC "Huh? Yazmin?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:270
translate chinese LiR1_MAS7_label_con1_8636537c:

    # Liza "Where did she go?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:271
translate chinese LiR1_MAS7_label_con1_1494ac8d:

    # MC "I’m not sure. Did you see her leave the pool?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:272
translate chinese LiR1_MAS7_label_con1_6723cd8b:

    # Liza "Strange... She must have stepped inside for a drink."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:278
translate chinese LiR1_MAS7_label_con1_2961b003:

    # MC "(Huh?! My shorts just came down?!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:279
translate chinese LiR1_MAS7_label_con1_f76ac569:

    # MC "(Dammit! I NEED to buy myself, ones with a tighter elastic on the waist!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:283
translate chinese LiR1_MAS7_label_con1_466a28fb:

    # MC "(Wait... Is that...? No way!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:284
translate chinese LiR1_MAS7_label_con1_96f6da76:

    # MC "(Yazmin is under the water! Does she not understand how risky this is, right now?!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:285
translate chinese LiR1_MAS7_label_con1_1c09167f:

    # MC "(What the hell is she playing at?!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:289
translate chinese LiR1_MAS7_label_con1_18bcf183:

    # Liza "Is something wrong, [player_name]?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:290
translate chinese LiR1_MAS7_label_con1_1c5d353a:

    # MC "N-No! Everything is fine. T-Tell me more about your holidays together!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:291
translate chinese LiR1_MAS7_label_con1_fe663e1b:

    # Liza "Huh? You just looked a little shocked, there. Let me think..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:298
translate chinese LiR1_MAS7_label_con1_b3cd14bb:

    # Liza "We also took a holiday to the Great Barrier Reef in Australia."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:299
translate chinese LiR1_MAS7_label_con1_4e041f7e:

    # Yazmin "*Suck Suck*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:300
translate chinese LiR1_MAS7_label_con1_ab6617ed:

    # MC "Mmm... Uh huh..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:301
translate chinese LiR1_MAS7_label_con1_b7d458ef:

    # MC "(Fuck! This feels amazing...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:305
translate chinese LiR1_MAS7_label_con1_8b56e127:

    # Liza "We went snorkeling together and learned how to do long underwater dives."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:306
translate chinese LiR1_MAS7_label_con1_b96e9008:

    # Liza "I could never beat a minute underwater. Yazmin could stay under for almost four minutes easily."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:307
translate chinese LiR1_MAS7_label_con1_4686f7ca:

    # Liza "She’d dive really deep and harvest these oysters with her bare hands."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:308
translate chinese LiR1_MAS7_label_con1_d5b24a77:

    # MC "D-Did you say f-four minutes?!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:309
translate chinese LiR1_MAS7_label_con1_43c23724:

    # Yazmin "*GULP GULP*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:313
translate chinese LiR1_MAS7_label_con1_ded5b597:

    # Liza "Yeah, why?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:314
translate chinese LiR1_MAS7_label_con1_b587cc8d:

    # MC "W-Wow! That’s... ah... a really long time, to be able to hold your breath... oh... underwater!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:315
translate chinese LiR1_MAS7_label_con1_874b3ff7:

    # Liza "Yeah... I guess it is. I can’t really think of a use for such a skill in our small pool though."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:320
translate chinese LiR1_MAS7_label_con1_ca1aee63:

    # MC "Hnnngg.... N-Neither can I..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:321
translate chinese LiR1_MAS7_label_con1_2bf3812f:

    # MC "(Fuck! She’s taking my cock - so deep - into her mouth!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:322
translate chinese LiR1_MAS7_label_con1_fe560e26:

    # Yazmin "*Shllllurrrrp*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:326
translate chinese LiR1_MAS7_label_con1_6b4382dd:

    # Yazmin "Mmm!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:327
translate chinese LiR1_MAS7_label_con1_925a8d84:

    # Yazmin "(God, I forgot how much fun it was sucking cocks! I used to do it so much before I settled down with Liza.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:328
translate chinese LiR1_MAS7_label_con1_862932f9:

    # Yazmin "(The feeling of a guy exploding in your mouth as you shlurp his shaft is unparalleled.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:332
translate chinese LiR1_MAS7_label_con1_b2bc2462:

    # MC "(Dammit, I can’t believe she’s doing this, right now - And in front of her wife!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:333
translate chinese LiR1_MAS7_label_con1_3c6db239:

    # MC "(I guess I SHOULD have seen it coming though. Especially after that morning when she grabbed my cock, behind the breakfast bar, while Liza was sitting on the couch.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:337
translate chinese LiR1_MAS7_label_con1_76b4aeef:

    # Liza "Yeah... Yazmin really could hold her breath. Honestly, it surprised the instructors!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:338
translate chinese LiR1_MAS7_label_con1_bee2143c:

    # MC "*Gulp* Y-Yeah, it surprised me too."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:339
translate chinese LiR1_MAS7_label_con1_2640061b:

    # MC "Err- I mean, it SOUNDS surprising that she could ahh... hold her breath THAT long... Mmm!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:343
translate chinese LiR1_MAS7_label_con1_095a44c9:

    # Yazmin "(Okay - time to wrap my legs around his, and prepare for the finisher!)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:344
translate chinese LiR1_MAS7_label_con1_ffe8786a:

    # Yazmin "(I’ve never had a guy last longer than twenty seconds when I’m using this technique.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:345
translate chinese LiR1_MAS7_label_con1_19c5934e:

    # MC "(Huh?! What’s Yazmin doing now?)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:349
translate chinese LiR1_MAS7_label_con1_1da8e28e:

    # Yazmin "*Shlurrrp Suck*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:350
translate chinese LiR1_MAS7_label_con1_fa89c851:

    # MC "(Holy fuck! She’s deepthroating me!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:351
translate chinese LiR1_MAS7_label_con1_5b528ba6:

    # MC "Hnnng...."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:352
translate chinese LiR1_MAS7_label_con1_4aa731f6:

    # Liza "Are you okay there, [player_name]?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:356
translate chinese LiR1_MAS7_label_con1_025d1592:

    # MC "Ugh... Y-yeah... Just stretching my legs, under the water. I don’t want myself getting any cramps while I’m swimming!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:357
translate chinese LiR1_MAS7_label_con1_c27a94e6:

    # Liza "Good call. Always stretch before you exercise - that’s what my instructor always told me."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:358
translate chinese LiR1_MAS7_label_con1_4e041f7e_1:

    # Yazmin "*Suck Suck*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:362
translate chinese LiR1_MAS7_label_con1_2da3d0ea:

    # Liza "... Well, I suppose I better go and look for Yazmin. It always SUCKS when she leaves without telling me."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:363
translate chinese LiR1_MAS7_label_con1_ebc997ae:

    # MC "Yeah, I’m sure it really... ah... blows, when she does that."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:364
translate chinese LiR1_MAS7_label_con1_8b611a75:

    # Liza "Honestly, if she was feeling tired she should have just SWALLOWED her pride and told me that she needed to go get something. Y’know?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:365
translate chinese LiR1_MAS7_label_con1_d8b213ef:

    # MC "([Liza_name] can’t seriously be making these puns on purpose, can she?!))"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:366
translate chinese LiR1_MAS7_label_con1_ec0ce22f:

    # MC "Hnng.... D-Definitely."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:367
translate chinese LiR1_MAS7_label_con1_67f5b23f:

    # Liza "Anyway, I’m off now. Have fun!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:369
translate chinese LiR1_MAS7_label_con1_94bacde1:

    # MC "S-See you later, Ahhuntie!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:371
translate chinese LiR1_MAS7_label_con1_2bb6c205:

    # MC "S-See you later, Lizzzaaah!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:375
translate chinese LiR1_MAS7_label_con1_7facf295:

    # MC "Hnnng... Oh..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:376
translate chinese LiR1_MAS7_label_con1_0828f7e6:

    # MC "(Now that she’s gone. I can finally moan!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:377
translate chinese LiR1_MAS7_label_con1_fbcbf21e:

    # MC "Ah... Fuck..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:381
translate chinese LiR1_MAS7_label_con1_6bf735d9:

    # MC "(She’s soooo good with her mouth! I’m gonna cum soon!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:382
translate chinese LiR1_MAS7_label_con1_0527a49e:

    # Yazmin "*Shllurrrp*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:383
translate chinese LiR1_MAS7_label_con1_4e041f7e_2:

    # Yazmin "*Suck Suck*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:384
translate chinese LiR1_MAS7_label_con1_457d1811:

    # MC "Hnnnng! Arrghhhh! I’m cumming!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:395
translate chinese LiR1_MAS7_label_con1_39f1b453:

    # Yazmin "(Finally made him cum! He lasted much longer than most guys I’ve met!)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:396
translate chinese LiR1_MAS7_label_con1_9f306b4f:

    # Yazmin "(I better swallow it, or [player_name] will have to clean the whole pool, again.)"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:397
translate chinese LiR1_MAS7_label_con1_6f4acd7c:

    # Yazmin "*Gulp Gulp*"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:398
translate chinese LiR1_MAS7_label_con1_213dca4c:

    # MC "Phew... Holy fuck... (That was incredible...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:405
translate chinese LiR1_MAS7_label_con1_a379e6e1:

    # Yazmin "Haha! I think you enjoyed that!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:407
translate chinese LiR1_MAS7_label_con1_21b756c5:

    # MC "Y-You... Right in front of my auntie!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:409
translate chinese LiR1_MAS7_label_con1_e9e6cfb4:

    # MC "Y-You... Right in front of Liza!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:410
translate chinese LiR1_MAS7_label_con1_a343f04a:

    # Yazmin "I know! Pretty hot, right?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:415
translate chinese LiR1_MAS7_label_con1_83edd887:

    # MC "That felt so fucking good! Where did you learn to do that?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:416
translate chinese LiR1_MAS7_label_con1_b823c0b1:

    # Yazmin "I gave A LOT of deepthroats, in my college days. When it came to free diving without oxygen tanks I was already adept at holding my breath."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:417
translate chinese LiR1_MAS7_label_con1_c2febbe9:

    # Yazmin "I figured, I may as well combine my two skills into one useless talent."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:418
translate chinese LiR1_MAS7_label_con1_49de6b69:

    # MC "Well, I’d hardly call it USELESS!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:423
translate chinese LiR1_MAS7_label_con1_50ced199:

    # MC "How could you do that!? If she’d caught us, we would BOTH be dead right now!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:424
translate chinese LiR1_MAS7_label_con1_0d3106e9:

    # Yazmin "Huh? Did you not enjoy it?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:426
translate chinese LiR1_MAS7_label_con1_323f45a8:

    # MC "It doesn’t matter! She’s my auntie, and she’s YOUR wife! You’re cheating on her, right now. You know that?! AND you’re making ME complicit in it!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:428
translate chinese LiR1_MAS7_label_con1_2fc9f0c4:

    # MC "It doesn’t matter! She’s YOUR wife! You’re cheating on her, right now. You know that?! AND you’re making ME complicit in it!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:429
translate chinese LiR1_MAS7_label_con1_04224885:

    # Yazmin "Oh..."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:435
translate chinese LiR1_MAS7_continue_0a509096:

    # Yazmin "I’ll tell you what - let me make it up to you. How about, you come and spy on us again, some night?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:436
translate chinese LiR1_MAS7_continue_5a207846:

    # Yazmin "I’ll let you watch, for as long as you want."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:437
translate chinese LiR1_MAS7_continue_895293c7:

    # MC "As long as I want..?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:441
translate chinese LiR1_MAS7_continue_36ba1794:

    # Yazmin "Does that sound like a fair deal, to repay you for what I did?"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:442
translate chinese LiR1_MAS7_continue_c03562fe:

    # MC "I guess... Seriously though, you can’t do that again. We almost got caught!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:443
translate chinese LiR1_MAS7_continue_850e2b13:

    # MC "What if [Liza_name] had looked down, into the pool, and seen you?!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:447
translate chinese LiR1_MAS7_continue_7b3d1925:

    # Yazmin "You worry too much!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:448
translate chinese LiR1_MAS7_continue_005e35ca:

    # Yazmin "Like I said, come and watch us during the night. I’ll make sure that it’s a little more... interactive for you, this time. If you catch my drift..."
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:449
translate chinese LiR1_MAS7_continue_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:453
translate chinese LiR1_MAS7_continue_796c81b7:

    # Yazmin "I’m not gonna spoil the surprise. You’re just gonna have to come, and see for yourself!"
    Yazmin ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:454
translate chinese LiR1_MAS7_continue_75b53d27:

    # MC "*Sigh* Fine!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:455
translate chinese LiR1_MAS7_continue_56e1053a:

    # MC "Liza has gone inside, by the way. She’s looking for you! You better have a good excuse, for why you disappeared."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:456
translate chinese LiR1_MAS7_continue_74cf1fe7:

    # Yazmin "Don’t worry - I’ll think of something."
    Yazmin ""

translate chinese strings:

    # game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:411
    old "That felt so fucking good! Where did you learn to do that?"
    new ""

    # game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS7.rpy:411
    old "How could you do that?! We would BOTH have been killed if she caught us!"
    new ""

