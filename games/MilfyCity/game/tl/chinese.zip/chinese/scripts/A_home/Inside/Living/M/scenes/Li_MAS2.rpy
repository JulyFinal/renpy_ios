﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:32
translate chinese Li_MAS2_label_f8d86cab:

    # MC "Hey, [Liza_name]. How’re you doing?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:33
translate chinese Li_MAS2_label_4a1ef02b:

    # Liza "Hi, [player_name]! Not too bad! What’s up?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:34
translate chinese Li_MAS2_label_f9be9903:

    # MC "I just had a few minutes free, so I thought I’d drop by to say hello!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:35
translate chinese Li_MAS2_label_7bad074d:

    # Liza "Aww, that’s sweet. Take a seat!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:41
translate chinese Li_MAS2_label_0b18e7a8:

    # Liza "What’s new with you then? Anything exciting or interesting happening in your life?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:42
translate chinese Li_MAS2_label_bb58c26d:

    # MC "(Almost everything is too private or lewd for me to tell her! I better change the conversation topic, before I let something slip about my current romantic entanglements, or that cringeworthy kerfuffle with my professor!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:43
translate chinese Li_MAS2_label_342e67da:

    # MC "Err... nothing much."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:59
translate chinese Li_MAS2_menu_60a1213c:

    # MC "So, how long have you and Yazmin been married?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:63
translate chinese Li_MAS2_menu_78f32a3e:

    # Liza "Oh wow... it must be... five or six years now. Wait, it’s definitely six. We celebrated our five year anniversary last July."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:64
translate chinese Li_MAS2_menu_f3679dbf:

    # MC "That’s lovely to hear."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:68
translate chinese Li_MAS2_menu_eba15e2c:

    # Liza "I know! Yazmin’s like a dream come true!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:78
translate chinese Li_MAS2_menu_575816a5:

    # MC "How come [Mom_name] and you, don’t really hang out, that often?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:82
translate chinese Li_MAS2_menu_c350b718:

    # Liza "..."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:83
translate chinese Li_MAS2_menu_d4b02dcb:

    # MC "[Liza_name]? You okay?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:84
translate chinese Li_MAS2_menu_97dc5bcc:

    # Liza "We DO hang out!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:85
translate chinese Li_MAS2_menu_e48d3e4d:

    # MC "But-"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:86
translate chinese Li_MAS2_menu_acd63350:

    # Liza "You saw me at your house the other morning, right?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:90
translate chinese Li_MAS2_menu_8eecf3e8:

    # Liza "We’re both adults with... full time jobs, and we’re... um... very busy people."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:91
translate chinese Li_MAS2_menu_ee61e437:

    # Liza "I mean, Linda owns her own business for Christ’s sake!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:93
translate chinese Li_MAS2_menu_6c19448c:

    # MC "(What’s going on?! I’ve clearly struck a nerve here! I should probably leave this topic alone, until I get to know Auntie Liza better.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:95
translate chinese Li_MAS2_menu_649c88ea:

    # MC "(What’s going on?! I’ve clearly struck a nerve here! I should probably leave this topic alone, until I get to know Liza better.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:105
translate chinese Li_MAS2_menu_93748e17:

    # MC "How did you and Yazmin meet each other?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:109
translate chinese Li_MAS2_menu_2d0b3459:

    # Liza "Well... I was a freshman in university, almost nineteen years old. I was heavily involved in my local sorority. The building we lived in was a wreck - it hadn’t been properly maintained in decades!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:110
translate chinese Li_MAS2_menu_ad1f65af:

    # Liza "Anyway, the President of the Sorority organised a cleanup project. I volunteered to do some painting and Yazmin got assigned to my group. It ended up just being me and her painting the second floor."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:111
translate chinese Li_MAS2_menu_95ffe659:

    # MC "Aww, that’s really nice? What happened next?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:115
translate chinese Li_MAS2_menu_d8693d6d:

    # Liza "(Honestly? She pushed me up against the wall and started making out with me before she’d even asked my name.)"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:116
translate chinese Li_MAS2_menu_1ea81fbf:

    # Liza "(I was wearing these really tight leggings, and she STILL somehow managed, to slip her hand inside them. God... she had me soaking my panties for almost an hour.)"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:121
translate chinese Li_MAS2_menu_b12121a5:

    # Liza "Err... She asked me out for coffee and we went to the local Barstucks for our first date."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:122
translate chinese Li_MAS2_menu_68507683:

    # MC "Aww, that sounds really sweet!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:123
translate chinese Li_MAS2_menu_f2e6bd81:

    # Liza "Yeah, it was... exhilarating."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:135
translate chinese Li_MAS2_menu_5593279a:

    # MC "So, how did [Mom_name] react, when she found out you were a lesbian?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:139
translate chinese Li_MAS2_menu_dac9cb79:

    # Liza "It wasn’t me being a lesbian that bothered her!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:140
translate chinese Li_MAS2_menu_188d3986:

    # MC "(Huh... What a strange way to phrase her answer. Why didn’t she just say that it didn’t bother [Mom_name]?)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:141
translate chinese Li_MAS2_menu_77017ff8:

    # Liza "You know, Linda isn’t as straight as she makes herself out to be. She was a real locomotive back in her youth!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:142
translate chinese Li_MAS2_menu_d83989df:

    # MC "A... locomotive?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:143
translate chinese Li_MAS2_menu_f48ff8e3:

    # Liza "Yeah, she could go both ways."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:145
translate chinese Li_MAS2_menu_5b5fe14c:

    # MC "Oh, I understand now. What did you mean when you said, “It wasn’t me being a lesbian that bothered her!” Was there something else that bothered [Mom_name]?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:147
translate chinese Li_MAS2_menu_e40e4f94:

    # MC "Oh, I understand now. What did you mean when you said, “It wasn’t me being a lesbian that bothered her!” Was there something else that bothered her?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:151
translate chinese Li_MAS2_menu_108b93ff:

    # Liza "Ah... I misspoke. I MEANT to say that it didn’t bother my sister at all, at the time."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:153
translate chinese Li_MAS2_menu_32805b4a:

    # MC "At the time?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:154
translate chinese Li_MAS2_menu_2925e622:

    # Liza "Err - I think we should change the subject. This isn’t appropriate for us to be discussing."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:164
translate chinese Li_MAS2_menu_98d862bc:

    # MC "Are you and Yazmin planning to have a child, in the future?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:168
translate chinese Li_MAS2_menu_fbef5706:

    # Liza "I guess the thought has... crossed my mind once or twice. It would be nice to have a little one to take care of once we get settled down."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:169
translate chinese Li_MAS2_menu_513ce897:

    # MC "That’s awesome! Have you thought about how you’ll do it?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:170
translate chinese Li_MAS2_menu_40ac0738:

    # Liza "My mind has been so set on the end result, that I haven’t really thought about the process at all. I wouldn’t mind doing IVF as long as Yazmin could support us both financially."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:174
translate chinese Li_MAS2_menu_2dec3336:

    # Liza "Then again... there are A LOT of young children, who need adopting. We could help, change a life."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:184
translate chinese Li_MAS2_menu_635ffd7f:

    # MC "Are you enjoying your job? You mentioned you were a secretary for a law firm, didn’t you?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:188
translate chinese Li_MAS2_menu_2abff239:

    # Liza "It’s alright - but I’m keeping an eye open for other posts."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:189
translate chinese Li_MAS2_menu_24b21855:

    # MC "Have you thought about becoming a paralegal?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:190
translate chinese Li_MAS2_menu_de9204a3:

    # Liza "It’s funny you should mention that - my firm actually offers training to become paralegals."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:191
translate chinese Li_MAS2_menu_81da5451:

    # Liza "I was thinking of taking them up on the offer. The only downside is that you have to go to night school."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:192
translate chinese Li_MAS2_menu_b7054790:

    # MC "Ugh, sounds rough. Is the pay any better?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:196
translate chinese Li_MAS2_menu_7cdff961:

    # Liza "About $5,000 more, per annum. Not too shabby!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:208
translate chinese Li_MAS2_menu_3a34b65a:

    # MC "What’s REALLY going on, between you and [Mom_name]? You hardly ever visit each other anymore."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:212
translate chinese Li_MAS2_menu_d05d5881:

    # Liza "*Sigh* You asked me about this, a few days ago."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:213
translate chinese Li_MAS2_menu_a2092560:

    # MC "You weren’t completely honest with me, were you?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:214
translate chinese Li_MAS2_menu_bad34e07:

    # Liza "... No."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:215
translate chinese Li_MAS2_menu_487f832b:

    # MC "Hmm... I thought so."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:219
translate chinese Li_MAS2_menu_6a475763:

    # Liza "My sister and I... We were always so close. We did everything together."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:222
translate chinese Li_MAS2_menu_ea8e0d65:

    # Liza "She never minded that I was gay."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:224
translate chinese Li_MAS2_menu_49a16dbe:

    # Liza "She never minded when I snuck girls home without my Mom and Dad knowing."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:226
translate chinese Li_MAS2_menu_1328fc6d:

    # Liza "It all changed when Linda met Yazmin. She took an intense, irrational dislike towards her."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:230
translate chinese Li_MAS2_menu_20b05ee7:

    # Liza "And when I told Linda that Yazmin and I were engaged she had the AUDACITY to tell me that I needed to grow out of my ‘gay phase’."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:231
translate chinese Li_MAS2_menu_d631edfe:

    # Liza "I mean - how damn rude can you be?!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:232
translate chinese Li_MAS2_menu_82d86a3c:

    # MC "Oh my God... [Liza_name]..."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:236
translate chinese Li_MAS2_menu_856c2158:

    # Liza "Your mom and I, barely spoke after that. Months went by when we didn’t exchange a word. You might have noticed that we didn’t really interact, at the beach barbeque, all those years ago."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:238
translate chinese Li_MAS2_menu_20f288be:

    # Liza "Linda and I barely spoke after that. Months went by when we didn’t exchange a word. You might have noticed that we didn’t really interact, at the beach barbeque, all those years ago."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:239
translate chinese Li_MAS2_menu_960cd3c7:

    # MC "Yeah - come to mention it - that makes sense."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:241
translate chinese Li_MAS2_menu_ba11a266:

    # Liza "Things have thawed since then, but I try to keep Yazmin out of the picture. There’s no need to antagonise my sister any more than my wedding ring already does. I think she views Yazmin as stealing away her best friend."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:244
translate chinese Li_MAS2_menu_aa67cf6b:

    # Liza "So yeah, that’s the story, with all the gory details. There are a few other things your mother may have called Yazmin and I - but they don't to be repeated. There’s no sense in reopening old wounds."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:246
translate chinese Li_MAS2_menu_72001667:

    # Liza "So yeah, that’s the story, with all the gory details. There are a few other things Linda may have called Yazmin and I - but they don't need to be repeated. There’s no sense in reopening old wounds."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:247
translate chinese Li_MAS2_menu_e1929461:

    # MC "I’m... so sorry. I never realised."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:248
translate chinese Li_MAS2_menu_d8272d1a:

    # Liza "It’s okay, we’re slowly getting over it. Time heals all wounds after all."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:258
translate chinese Li_MAS2_menu_6b7ddab1:

    # MC "So, you feel nothing towards men?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:259
translate chinese Li_MAS2_menu_bfe751be:

    # Liza "Wow! That’s quite a... personal question."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:260
translate chinese Li_MAS2_menu_76961743:

    # MC "I’m just curious! Sorry, I didn’t mean to offend you."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:261
translate chinese Li_MAS2_menu_92462af7:

    # Liza "N-No, you didn’t offend me. I just wasn’t... expecting the question."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:265
translate chinese Li_MAS2_menu_61c2bf7b:

    # Liza "Umm... What’s the best way to explain this? Hmm..."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:266
translate chinese Li_MAS2_menu_cad17f17:

    # Liza "Have you ever heard of the Kinsey Scale?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:267
translate chinese Li_MAS2_menu_82386156:

    # MC "I’m not familiar with it."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:268
translate chinese Li_MAS2_menu_e5056336:

    # Liza "It’s a scale to measure sexuality. It runs from one to six. Someone who is a one on the scale is ONLY attracted to the opposite sex. Someone who is a six, is exclusively attracted to the same sex."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:272
translate chinese Li_MAS2_menu_9d8829e1:

    # MC "Ah, so ones are straight and sixes are gay?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:273
translate chinese Li_MAS2_menu_38ece3f7:

    # Liza "Bingo!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:274
translate chinese Li_MAS2_menu_88393772:

    # MC "So, where do you fall, on that scale?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:278
translate chinese Li_MAS2_menu_b9bf7a20:

    # Liza "I’m basically a six. Maybe a five point five at a push. I can count the number of men that I have found sexually attractive in my whole life on a single hand. Haha!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:279
translate chinese Li_MAS2_menu_4ff87f51:

    # MC "What about me?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:283
translate chinese Li_MAS2_menu_a5a03554:

    # Liza "W-What do you mean?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:284
translate chinese Li_MAS2_menu_063f3321:

    # MC "Do you find me attractive?"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:285
translate chinese Li_MAS2_menu_02ed8ffc:

    # Liza "Umm... That’s a little bit of an awkward question to answer. Don’t you think?"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:286
translate chinese Li_MAS2_menu_e43270f3:

    # MC "I’m just curious! This is the first time I’ve ever heard about this Kinder Scale stuff!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:287
translate chinese Li_MAS2_menu_1dcc28a8:

    # Liza "Kin-SEY scale. And... honestly, not really. If you had long dark hair, C-Cup breasts, and a vagina, I MIGHT find you attractive."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:288
translate chinese Li_MAS2_menu_22c2b3cf:

    # MC "(Damn, it really doesn’t sound like there’s much hope, for me seducing her!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:299
translate chinese Li_MAS2_menu_a05c0623:

    # MC "That’s me finished cleaning the pool, by the way!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:300
translate chinese Li_MAS2_menu_e6f1407f:

    # Liza "Really?! Fantastic work!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:301
translate chinese Li_MAS2_menu_0dd2664b:

    # Liza "You’re such a great help - it’s nice to have someone around the house that I can actually trust!"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:305
translate chinese Li_MAS2_menu_ca2520d8:

    # Liza "*Mwah!*"
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:307
translate chinese Li_MAS2_menu_fa9dd558:

    # MC "Aww, thanks, Auntie Liza!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:309
translate chinese Li_MAS2_menu_8a7e137b:

    # MC "Aww, thanks, Liza!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:310
translate chinese Li_MAS2_menu_4fe50d8d:

    # Liza "The pool gets dirty very quickly - feel free to drop by again if you want to earn some more cash."
    Liza ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:311
translate chinese Li_MAS2_menu_3012b834:

    # MC "Will do! Catch you later, [Liza_name]!"
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:319
translate chinese Li_MAS2_menu_91531e7f:

    # MC "Well, I’ve taken up enough of your time. I should probably head on."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:320
translate chinese Li_MAS2_menu_86b0de34:

    # MC "See you later, [Liza_name]."
    MC ""

# game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:321
translate chinese Li_MAS2_menu_dfb2165b:

    # Liza "Bye, [player_name]."
    Liza ""

translate chinese strings:

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "How long have you and Yazmin been married?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "How come [Mom_name] and you, don’t really hang out, that often?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "How did you and Yazmin meet?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "How did [Mom_name] react, when she found out you were a lesbian?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "Are you two planning to have a child?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "Are you enjoying your job? You mentioned you were a secretary for a law firm, didn’t you?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "What’s REALLY going on, between you and [Mom_name]? You hardly ever visit each other."
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "You feel nothing towards men?"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "{color=#00ff00}I finished cleaning the pool.{/color}"
    new ""

    # game/scripts/A_home/Inside/Living/M/scenes/Li_MAS2.rpy:55
    old "Bye"
    new ""

