﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:23
translate chinese Li_MAS3_label_03b87a11:

    # Yazmin "Hey there, [player_name]. What’s up?"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:24
translate chinese Li_MAS3_label_9cf134bc:

    # MC "I just thought I’d drop by to say hello. Are you free for a few minutes?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:25
translate chinese Li_MAS3_label_9586cdd4:

    # Yazmin "Of course! I just finished, booking a course. What can I do for you?"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:41
translate chinese Li_MAS3_menu_215dc943:

    # MC "So, what’s it like, working as a supermodel?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:45
translate chinese Li_MAS3_menu_f5358777:

    # Yazmin "Supermodel?! Haha! God, I wish I was one!"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:46
translate chinese Li_MAS3_menu_280ea17e:

    # Yazmin "That’s a bit of an exaggeration. Honestly, I’m not that famous... yet. I’ll get there someday, but right now I’m just your regular old fashion model."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:57
translate chinese Li_MAS3_menu_614b75ed:

    # MC "Have you always been a fashion model?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:62
translate chinese Li_MAS3_menu_22d5caaf:

    # Yazmin "Hmm... Not always. I started in my early twenties after college."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:63
translate chinese Li_MAS3_menu_54a2e1f5:

    # Yazmin "I also held a couple of other jobs when I was younger. I used to work for a congressman when I was twenty. That only lasted six months though."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:64
translate chinese Li_MAS3_menu_0b7e7785:

    # MC "That’s pretty cool! What did you do for him?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:65
translate chinese Li_MAS3_menu_35e293ae:

    # Yazmin "Public relations, accompanied him to formal events, some light secretarial stuff."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:69
translate chinese Li_MAS3_menu_758ddff8:

    # Yazmin "Honestly, I left because he was using me as eye candy rather than as an actual employee."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:70
translate chinese Li_MAS3_menu_5a77a2f6:

    # Yazmin " Not that I minded being eye candy - I just really needed proper work experience if I ever wanted to advance my career, and I wasn’t getting any while working for him."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:82
translate chinese Li_MAS3_menu_4e089796:

    # MC "Where’s your favourite place?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:86
translate chinese Li_MAS3_menu_db29245e:

    # Yazmin "My favourite place? What do you mean?"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:87
translate chinese Li_MAS3_menu_fe33768e:

    # MC "Y’know - I’m sure you’ve travelled around, a lot. Where’s your favourite city or country?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:88
translate chinese Li_MAS3_menu_0991a48d:

    # Yazmin "What a bizarre question. Are you usually this bad at small talk?"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:89
translate chinese Li_MAS3_menu_7930fa34:

    # MC "Yeah, I guess so."
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:93
translate chinese Li_MAS3_menu_31b89d57:

    # Yazmin "Fine. Let me think... Hmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:94
translate chinese Li_MAS3_menu_377a8156:

    # Yazmin "I travelled to so many places, after I turned eighteen. I’m struggling to remember - half of them! Granted... I was rather drunk, for a lot of them."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:98
translate chinese Li_MAS3_menu_9d5d0151:

    # Yazmin "Barcelona! Yeah, that’s where I enjoyed, the most."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:99
translate chinese Li_MAS3_menu_e5e67e5d:

    # MC "What’s in Barcelona?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:100
translate chinese Li_MAS3_menu_3b603f08:

    # Yazmin "It’s a city in Catalonia in Spain. Absolutely stunning city! It’s filled with all this really old architecture - if you’re into that kinda thing."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:101
translate chinese Li_MAS3_menu_ae45a9a2:

    # Yazmin "Plus - Spanish guys are soooo hot! I had a couple of amazing... ‘encounters’ in youth hostels."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:113
translate chinese Li_MAS3_menu_c363b2f3:

    # MC "What’s it like, working on the catwalk?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:117
translate chinese Li_MAS3_menu_d246c46f:

    # Yazmin "Honestly? It’s far less glamorous, than you would imagine."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:118
translate chinese Li_MAS3_menu_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:119
translate chinese Li_MAS3_menu_ce037eec:

    # Yazmin "When you turn on the TV and see a girl walking down the runway, or when you look at a beautiful woman in an advertisement, you’re only seeing the very end of the process."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:120
translate chinese Li_MAS3_menu_5188a934:

    # Yazmin "Prior to that, is hours, or even days - of excruciatingly difficult work."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:121
translate chinese Li_MAS3_menu_3c734d6b:

    # MC "Like what?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:122
translate chinese Li_MAS3_menu_d5401b1a:

    # Yazmin "Exercising, having clothes fitted and refitted, DOZENS of rejected photoshoots and retries! It’s an exhausting process."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:134
translate chinese Li_MAS3_menu_ca4ec808:

    # MC "What did you study at university?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:138
translate chinese Li_MAS3_menu_c9e30ffc:

    # Yazmin "I did a joint major in Art and Public Relations at a small regional university, down in Texas. Loved the art aspect, and absolutely LOATHED the public relations half of my degree."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:139
translate chinese Li_MAS3_menu_3c425da0:

    # MC "That sounds cool! What kind of art did you do?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:140
translate chinese Li_MAS3_menu_efb9009c:

    # Yazmin "Mostly photography stuff. It’s how I met most of my contacts, for my current job."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:152
translate chinese Li_MAS3_menu_086280cb:

    # MC "I don’t see you and Auntie Liza coming up to visit us, very often. Why is that?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:157
translate chinese Li_MAS3_menu_7b8829cf:

    # Yazmin "Ooh, that’s a touchy subject. Honestly, I’m not comfortable talking about this. It’s something you’d need to take up with your auntie."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:158
translate chinese Li_MAS3_menu_7e846e5c:

    # Yazmin "Let’s just say... your mother isn’t my biggest fan."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:161
translate chinese Li_MAS3_menu_fecf8815:

    # MC "(Yikes... It sounds like I’ve touched a nerve here!)"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:174
translate chinese Li_MAS3_menu_9fda3bea:

    # MC "I don’t see you and Liza coming up to visit us, very often. Why is that?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:178
translate chinese Li_MAS3_menu_72c5e40c:

    # Yazmin "Ooh, that’s a touchy subject. Honestly, I’m not comfortable talking about this. It’s something you’d need to take up with Liza herself."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:179
translate chinese Li_MAS3_menu_3e036710:

    # Yazmin "Let’s just say... Linda isn’t my biggest fan."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:181
translate chinese Li_MAS3_menu_fecf8815_1:

    # MC "(Yikes... It sounds like I’ve touched a nerve here!)"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:193
translate chinese Li_MAS3_menu_587bd6c2:

    # MC "It’s a personal question - but does being a model pay well?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:197
translate chinese Li_MAS3_menu_d8d6b37f:

    # Yazmin "Ahahaha! It SHOULD! But there are some crazy stories I could tell you!"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:198
translate chinese Li_MAS3_menu_6ebebaa2:

    # MC "Go on! Tell me some!"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:203
translate chinese Li_MAS3_menu_361a51cc:

    # Yazmin "There are a lot of designers and companies out there, who try to get girls like me, to model for free."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:204
translate chinese Li_MAS3_menu_95f830b6:

    # Yazmin "“How would you like to be the new face of our exclusive line of dresses? We can’t pay you right now, but think of the exposure you’ll get, for your portfolio!”"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:205
translate chinese Li_MAS3_menu_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:210
translate chinese Li_MAS3_menu_6d506fbd:

    # Yazmin "A lot of people don’t realise, that being an artist or a model is a full time job. They seem to have this opinion that they are entitled to take photos of us, and use them for free. It’s only gotten worse, with the rise of the internet."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:211
translate chinese Li_MAS3_menu_c93ba3a5:

    # MC "Damn. I’m sorry to hear that."
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:222
translate chinese Li_MAS3_menu_9b7dfa44:

    # MC "Are you and [Liza_name] thinking of trying for kids in the future?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:226
translate chinese Li_MAS3_menu_85ce58ea:

    # Yazmin "You mean, though IVF or a sperm donor?"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:227
translate chinese Li_MAS3_menu_73f3d981:

    # MC "Yeah. Either way."
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:228
translate chinese Li_MAS3_menu_2e8e370c:

    # Yazmin "Maybe? I haven’t put a lot of thought into it. I obviously need to find a really good guy who would want to donate to us."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:230
translate chinese Li_MAS3_menu_63c9ed87:

    # Yazmin "And then there’s the issue about which of us would carry the baby. I don’t know if your auntie would be too fond of it - and I certainly can’t put my modelling career on hold for the better part of a year!"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:232
translate chinese Li_MAS3_menu_60395ca7:

    # Yazmin "And then there’s the issue about which of us would carry the baby. I don’t know if Liza would be too fond of it - and I certainly can’t put my modelling career on hold for the better part of a year!"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:244
translate chinese Li_MAS3_menu_ab6b89b8:

    # MC "Why doesn’t my mother like you?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:248
translate chinese Li_MAS3_menu_603b75f5:

    # Yazmin "It’s a loooong story. Your mom hasn’t always had the friendliest of relationships with gay people - like your auntie. She didn’t approve of our “lifestyle”."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:249
translate chinese Li_MAS3_menu_b21ec693:

    # Yazmin "I think your mother had a few lesbian flings, in her younger days - but she always sort of viewed women as fun, rather than the basis for a permanent relationship."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:253
translate chinese Li_MAS3_menu_96c13f67:

    # Yazmin "Then - I came into the picture - and started dating her sister. Prior to me coming along - your mother and Liza were inseparable. They might has well have been best friends."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:254
translate chinese Li_MAS3_menu_cc6b7fd6:

    # Yazmin "Your mother has mellowed, in recent years, but it’s still left some open wounds between her and your auntie. I think she still views me - as stealing Liza away from her."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:255
translate chinese Li_MAS3_menu_a96e19f5:

    # MC "Fuck... I’m sorry... I never knew she was like that..."
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:259
translate chinese Li_MAS3_menu_dc1be64d:

    # Yazmin "Don’t take it to heart. Your mother is NOT a bad person. People are complex individuals. And trying to fit them into narrow categories of ‘good’ and ‘bad’..."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:260
translate chinese Li_MAS3_menu_3bdfea10:

    # Yazmin "Your mother, clearly experienced some kind of emotional agony when I dated - and later married - her sister."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:261
translate chinese Li_MAS3_menu_086bd8bb:

    # Yazmin "She evidently isn’t over it yet - but rather than see a therapist, she seems to be redirecting her frustration towards gay people, and bisexuals like myself."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:262
translate chinese Li_MAS3_menu_90914744:

    # MC "Do you want me to talk to-"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:263
translate chinese Li_MAS3_menu_a86e488a:

    # Yazmin "Absolutely not! Do NOT bring this up with her. I have been walking a very fine tightrope for months on this subject. Please don’t endanger the little amount of progress I have made."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:275
translate chinese Li_MAS3_menu_62bd4bfc:

    # MC "Why doesn’t Linda like you?"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:279
translate chinese Li_MAS3_menu_08d691f6:

    # Yazmin "It’s a loooong story. Linda hasn’t always had the friendliest of relationships with gay people like Liza. She didn’t approve of our “lifestyle”."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:280
translate chinese Li_MAS3_menu_03e179b2:

    # Yazmin "I think she had a few lesbian flings in her younger days - but she always sort of viewed women as fun, rather than the basis for a permanent relationship."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:284
translate chinese Li_MAS3_menu_65b313ad:

    # Yazmin "Then I came into the picture and started dating Liza. Prior to me coming along, Linda and Liza were inseparable. They might as well have been best friends."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:285
translate chinese Li_MAS3_menu_4e7305fa:

    # Yazmin "She has mellowed in recent years, but her reaction still left some open wounds between her and Liza. I think she still views me as stealing her best friend away from her."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:286
translate chinese Li_MAS3_menu_a96e19f5_1:

    # MC "Fuck... I’m sorry... I never knew she was like that..."
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:290
translate chinese Li_MAS3_menu_dc5d9ebe:

    # Yazmin "Don’t take it to heart. Linda is NOT a bad person. People are complex individuals and trying to fit them into narrow categories of ‘good’ and ‘bad’ doesn’t work."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:291
translate chinese Li_MAS3_menu_30a827d3:

    # Yazmin "Linda has clearly experienced some kind of emotional agony when I dated, and later married, Liza."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:292
translate chinese Li_MAS3_menu_086bd8bb_1:

    # Yazmin "She evidently isn’t over it yet - but rather than see a therapist, she seems to be redirecting her frustration towards gay people, and bisexuals like myself."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:293
translate chinese Li_MAS3_menu_90914744_1:

    # MC "Do you want me to talk to-"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:294
translate chinese Li_MAS3_menu_a86e488a_1:

    # Yazmin "Absolutely not! Do NOT bring this up with her. I have been walking a very fine tightrope for months on this subject. Please don’t endanger the little amount of progress I have made."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:306
translate chinese Li_MAS3_menu_91531e7f:

    # MC "Well, I’ve taken up enough of your time. I should probably head on."
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:307
translate chinese Li_MAS3_menu_71babec7:

    # Yazmin "No problemo. I’m sure we’ll chat again soon."
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:311
translate chinese Li_MAS3_menu_34ab56eb:

    # Yazmin "(And maybe, if I’m lucky, I’ll see you with less clothes next time!)"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:312
translate chinese Li_MAS3_menu_88e94f41:

    # Yazmin "(God... it’s been so long since I’ve been able to fuck a man. I could just strip him down, right here, plant him in my chair, and ride his cock, till he came inside me.)"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:316
translate chinese Li_MAS3_menu_cd53e751:

    # Yazmin "(Dammit Yazmin! You need to calm down. You’ve still got preparation to do, before your next photoshoot!)"
    Yazmin ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:317
translate chinese Li_MAS3_menu_2c644445:

    # Yazmin "(Okay, now where was I before I got interrupted...)"
    Yazmin ""

translate chinese strings:

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "What’s it like, working as a supermodel?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "Have you always been a model?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "Where’s your favourite place?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "What’s it like, working on the catwalk?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "What did you study at university?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "I don’t see you and Auntie Liza coming to visit, very often. Why is that?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "I don’t see you and Liza coming to visit, very often. Why is that?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "It’s a personal question - but does being a model pay well?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "Are you and [Liza_name] thinking of trying for kids in the future?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "Why doesn’t my mother like you?"
    new ""

    # game/scripts/A_home/Inside/Office/M/scenes/Li_MAS3.rpy:37
    old "Why doesn’t Linda like you?"
    new ""

