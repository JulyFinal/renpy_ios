﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:39
translate chinese LiR1_MAS9_label_2d4955bc:

    # Liza "Ahh..."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:40
translate chinese LiR1_MAS9_label_9f08a6e8:

    # MC "(Jesus Christ! [Liza_name] is having a bath! Did Yazmin send me in here as a joke?!)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:41
translate chinese LiR1_MAS9_label_fceada27:

    # MC "(I better back off before she sees me!)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:46
translate chinese LiR1_MAS9_label_4f9399de:

    # Liza "[player_name]."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:47
translate chinese LiR1_MAS9_label_68d95730:

    # MC "(Fuck! How did she know I was here?! She didn’t even open her eyes!)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:48
translate chinese LiR1_MAS9_label_da7e5f47:

    # Liza "Please, come over here. Now..."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:52
translate chinese LiR1_MAS9_label_2bde15b9:

    # MC "A-Auntie... I... I didn’t mean to- Yazmin told me to-"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:54
translate chinese LiR1_MAS9_label_2fddb558:

    # MC "L-Liza... I... I didn’t mean to- Yazmin told me to-"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:55
translate chinese LiR1_MAS9_label_00e5c572:

    # Liza "I know she did. I’m well aware of that."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:56
translate chinese LiR1_MAS9_label_ed571186:

    # MC "But you’re... um... naked..."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:60
translate chinese LiR1_MAS9_label_2f264a48:

    # Liza "(Is he seriously this dense?! Maybe Yazmin just hasn’t explained the deal that the two of us made.)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:61
translate chinese LiR1_MAS9_label_0db5f2a3:

    # Liza "You don’t know why Yazmin told you to come in here?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:62
translate chinese LiR1_MAS9_label_fa311e4f:

    # MC "N-No, she never said."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:66
translate chinese LiR1_MAS9_label_f952dbb7:

    # Liza "Hmm... The reason why you’re here today... is because I’m curious."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:67
translate chinese LiR1_MAS9_label_b4212488:

    # MC "You’re curious?"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:68
translate chinese LiR1_MAS9_label_61326a61:

    # Liza "I want to know what Yazmin sees in your cock. Why does it make her so excited?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:69
translate chinese LiR1_MAS9_label_5eaa71f3:

    # Liza "I’m almost entirely homosexual, but I want to see if it can elicit the same response in me."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:70
translate chinese LiR1_MAS9_label_2115cbd1:

    # MC "D-Do you want me to-"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:71
translate chinese LiR1_MAS9_label_303b830b:

    # Liza "Yes. Take your cock out, [player_name]."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:79
translate chinese LiR1_MAS9_label_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:80
translate chinese LiR1_MAS9_label_33d90ae4:

    # Liza "(Wow... It’s massive...)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:81
translate chinese LiR1_MAS9_label_11973f6e:

    # Liza "You’re... already hard."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:82
translate chinese LiR1_MAS9_label_3fcb0752:

    # MC "Yeah, you’re naked in the bath. I was hard from the moment I stepped inside and saw you."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:86
translate chinese LiR1_MAS9_label_c350b718:

    # Liza "..."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:87
translate chinese LiR1_MAS9_label_56dbcc5d:

    # MC "Are you alright, [Liza_name]? I can put it away again, if you want."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:88
translate chinese LiR1_MAS9_label_243cec4b:

    # Liza "N-No... Do you mind if I... touch it?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:89
translate chinese LiR1_MAS9_label_9be225bb:

    # MC "Go ahead. Just be gentle."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:93
translate chinese LiR1_MAS9_label_534998fd:

    # Liza "Huh..."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:94
translate chinese LiR1_MAS9_label_43e0990a:

    # MC "Is something wrong?"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:95
translate chinese LiR1_MAS9_label_e6d90d4f:

    # Liza "It’s squishier than I expected it to be... I guess I was just so used to hard plastic dildos that I never imagined it to feel this way."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:96
translate chinese LiR1_MAS9_label_58ba5038:

    # MC "Don’t squeeze too hard. It’s incredibly sensitive!"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:100
translate chinese LiR1_MAS9_label_30034a6e:

    # MC "Oh..."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:101
translate chinese LiR1_MAS9_label_07b2dbe4:

    # Liza "Oops! Sorry, did I hurt you?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:102
translate chinese LiR1_MAS9_label_9bf7776e:

    # MC "No, don’t worry. The tip is just where most of the nerves are."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:106
translate chinese LiR1_MAS9_label_6963698f:

    # Liza "So... when you... um... touch yourself. How do you do it?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:107
translate chinese LiR1_MAS9_label_5251b3ae:

    # MC "I wrap my hand around it, and hold it like the handle of a tennis racket."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:108
translate chinese LiR1_MAS9_label_2d4955bc_1:

    # Liza "Ahh..."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:112
translate chinese LiR1_MAS9_label_0574dba4:

    # Liza "Like this?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:113
translate chinese LiR1_MAS9_label_c8b611ca:

    # MC "Yeah, just like that. You can grip a little bit harder."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:114
translate chinese LiR1_MAS9_label_cd082a03:

    # Liza "(Holy shit... The shaft is so thick, that I can barely get my fingers wrapped around it!)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:115
translate chinese LiR1_MAS9_label_238283d6:

    # MC "You can move your hand up and down, if you want."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:119
translate chinese LiR1_MAS9_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:120
translate chinese LiR1_MAS9_label_86a1399b:

    # Liza "How’s that?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:121
translate chinese LiR1_MAS9_label_f61391ff:

    # MC "That’s... ah... really good, [Liza_name]."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:125
translate chinese LiR1_MAS9_label_ab762def:

    # Liza "(Holy crap! It’s getting harder, as I rub it!)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:126
translate chinese LiR1_MAS9_label_7d9bdce7:

    # MC "(Damn, her hands are so soft! I don’t know if I’ll be able to last long, if she keeps rubbing me like this)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:127
translate chinese LiR1_MAS9_label_19b90bd6:

    # Liza "(I wonder what it feels like to give oral sex to a man...)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:131
translate chinese LiR1_MAS9_label_a9059e58:

    # MC "Huh? (Why’d she stop?)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:132
translate chinese LiR1_MAS9_label_95fd783e:

    # MC "(Oh, my God! Is she thinking of sucking me off!?)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:133
translate chinese LiR1_MAS9_label_746b7370:

    # Liza "(I can taste a little hint of his cock on my finger... Maybe it wouldn’t be so bad, putting it in my mouth for a little while.)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:137
translate chinese LiR1_MAS9_label_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:138
translate chinese LiR1_MAS9_label_1ae5062c:

    # Liza "(Okay Liza, you can do this. Just draw in a deep breath and give it a go.)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:142
translate chinese LiR1_MAS9_label_694120ae:

    # MC "Uh, are you okay, [Liza_name]? Do you want me to do anything?"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:143
translate chinese LiR1_MAS9_label_897054d4:

    # Liza "Just... stay right there. I want to try something out."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:144
translate chinese LiR1_MAS9_label_8834736f:

    # MC "Okay... As long as you’re comfortable with this."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:148
translate chinese LiR1_MAS9_label_9317a59c:

    # Liza "Can I... Can I lick it?"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:149
translate chinese LiR1_MAS9_label_76b96517:

    # MC "(This is a dream come true! I never thought she would be able to give me a blowjob: given her sexuality!)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:150
translate chinese LiR1_MAS9_label_e60a0549:

    # MC "Sure. Go ahead."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:154
translate chinese LiR1_MAS9_label_8f13bd5c:

    # Liza "*Lick*"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:155
translate chinese LiR1_MAS9_label_f42250d3:

    # MC "Ohh... fuck... that’s good."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:156
translate chinese LiR1_MAS9_label_834acec6:

    # Liza "(This is... different to how I imagined it would be...)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:160
translate chinese LiR1_MAS9_label_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:161
translate chinese LiR1_MAS9_label_6eca9058:

    # MC "(Damn! She’s really good with her tongue! It probably comes from years of practice, eating out Yazmin’s pussy!)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:162
translate chinese LiR1_MAS9_label_52685707:

    # Liza "(I wonder if I can put the tip in my mouth...)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:166
translate chinese LiR1_MAS9_label_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:167
translate chinese LiR1_MAS9_label_d24e7ef8:

    # Liza "*Lick Lick*"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:168
translate chinese LiR1_MAS9_label_c9de8b62:

    # Liza "(Okay... Here we go, Liza. You can do this...)"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:169
translate chinese LiR1_MAS9_label_956ee5de:

    # MC "(Holy shit! She’s about to do it!)"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:176
translate chinese LiR1_MAS9_label_5b6d714d:

    # Liza "Yuck! Ugh!"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:177
translate chinese LiR1_MAS9_label_78eac6f9:

    # MC "Are you alright?!"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:178
translate chinese LiR1_MAS9_label_20d607f9:

    # Liza "Sorry, I can’t do this! *Shudder*"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:182
translate chinese LiR1_MAS9_label_7af66d23:

    # Liza "I tried - That’s all Yazmin asked of me. Sorry! I just don’t bend that way."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:183
translate chinese LiR1_MAS9_label_748d482a:

    # MC "That’s okay. We don’t have to do it again..."
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:184
translate chinese LiR1_MAS9_label_2275ce47:

    # Liza "*Sigh* We might..."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:185
translate chinese LiR1_MAS9_label_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:189
translate chinese LiR1_MAS9_label_539f76de:

    # Liza "Yazmin wants to see you to join us again another night."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:190
translate chinese LiR1_MAS9_label_4bb28a47:

    # MC "Really!? Are you okay with that?"
    MC ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:191
translate chinese LiR1_MAS9_label_afa7e043:

    # Liza "I agreed to it because it will make her happy, and I love her. It doesn’t mean that I’m fully into it though. Yazmin has agreed to some of my kinks though, doing this is the least I can do for her."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:193
translate chinese LiR1_MAS9_label_d6a104ae:

    # Liza "My sister would murder me if she found out what I was doing with her son. I mean, this whole situation is positively ridiculous!"
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:197
translate chinese LiR1_MAS9_label_83da94c8:

    # Liza "Anyway, I need to finish my bath. (And use some mouthwash!) I’ll see you later on."
    Liza ""

# game/scripts/A_home/Inside/Bathroom/M/scenes/LiR1_MAS9.rpy:198
translate chinese LiR1_MAS9_label_2ab1d41b:

    # MC "Okay, [Liza_name]. See you later."
    MC ""

