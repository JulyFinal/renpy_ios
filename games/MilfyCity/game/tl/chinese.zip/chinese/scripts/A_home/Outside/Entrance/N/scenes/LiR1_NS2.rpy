﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:33
translate chinese LiR1_NS2_label_fc5e4b05:

    # MC "(I’ve arrived a little bit later tonight! I hope I haven’t missed anything!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:37
translate chinese LiR1_NS2_label_7a392c1e:

    # Yazmin "Oh! Ahh!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:38
translate chinese LiR1_NS2_label_a3c70f22:

    # MC "(Shit! It sounds like they’ve already started!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:42
translate chinese LiR1_NS2_label_0bdcc3ed:

    # Yazmin "Oh God! Fuck! You’re sooo good with your lips!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:43
translate chinese LiR1_NS2_label_d24e7ef8:

    # Liza "*Lick Lick*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:44
translate chinese LiR1_NS2_label_47fad3c2:

    # Yazmin "Yeeeessss..."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:45
translate chinese LiR1_NS2_label_5f19deba:

    # MC "(It looks like it’s Yazmin’s turn to get pleasured tonight! And there’s no sign of that strap-on dildo.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:49
translate chinese LiR1_NS2_label_e99a63e6:

    # MC "(I can see [Liza_name]’s pussy from this angle. Just look at how perfect, her vulva is!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:50
translate chinese LiR1_NS2_label_1855b1cb:

    # MC "(And that asshole is just, so tight!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:51
translate chinese LiR1_NS2_label_7ff93cf6:

    # MC "(I can’t decide, which I’d rather push my dick into. I can only dream, that someday, I’ll be able to fuck both!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:55
translate chinese LiR1_NS2_label_faf7c991:

    # Yazmin "Ohh... Do that thing ahh... with your lips, Honey! Mmm! The one where you suck, really oooh... hard!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:57
translate chinese LiR1_NS2_label_23576104:

    # Liza "*SUCK SUCK*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:58
translate chinese LiR1_NS2_label_5b8e6123:

    # Yazmin "Fuuuuuuckk.... Mmmmm! It’s sooo good!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:62
translate chinese LiR1_NS2_label_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:63
translate chinese LiR1_NS2_label_3169c6c5:

    # Yazmin "Ah! Ah... Oh- Okay! Stop! Ah!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:64
translate chinese LiR1_NS2_label_8f13bd5c:

    # Liza "*Lick*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:68
translate chinese LiR1_NS2_label_cab9abdb:

    # MC "(Huh? Why is Yazmin stopping her?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:69
translate chinese LiR1_NS2_label_7c978308:

    # Liza "Is everything okay? Why’d you want me to stop?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:70
translate chinese LiR1_NS2_label_02d89652:

    # Yazmin "*Pant* Y-Yeah, I’m good. Just let me catch my breath."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:74
translate chinese LiR1_NS2_label_1930c73b:

    # Liza "It felt like you were really close to cumming there!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:75
translate chinese LiR1_NS2_label_d98d9141:

    # Yazmin "Hehe, I was. That’s why I wanted you to stop. It’s not fair that I get to have ALL the fun! Spin yourself around and we’ll sixty-nine."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:76
translate chinese LiR1_NS2_label_9ae17c94:

    # Liza "Haha! Aren’t I a lucky girl?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:80
translate chinese LiR1_NS2_label_5c46952a:

    # Yazmin "*Lick Lick*"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:81
translate chinese LiR1_NS2_label_2585411f:

    # Liza "Mmm!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:82
translate chinese LiR1_NS2_label_21757c0a:

    # Liza "*Shllurrrp*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:86
translate chinese LiR1_NS2_label_4a7b9901:

    # MC "(Damn! The sound of them eating each other out is getting me rock-hard!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:87
translate chinese LiR1_NS2_label_37456724:

    # MC "(I wish I could just hop in, and fuck them both, right now!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:88
translate chinese LiR1_NS2_label_172b9e2f:

    # Yazmin "(Holy fuck, she’s good with her mouth - I still remember the first time she ate me out like it was yesterday...)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:89
translate chinese LiR1_NS2_label_8eb096f9:

    # Yazmin "(We went on a date to a forest park together, and ended up getting lost in the woods. We were only supposed to go camping for a few hours - but we ended up sleeping there, overnight.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:90
translate chinese LiR1_NS2_label_256103c5:

    # Yazmin "(The rain was lashing down, outside - and it was so damn loud against the tent’s tarpaulin, that neither of us could sleep. We ended up snuggling together in a sleeping bag, to keep warm.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:91
translate chinese LiR1_NS2_label_496263f9:

    # Yazmin "(The next thing I knew, she had slunk under, and was tugging at my panties. I must have came five or six times in a row that night.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:95
translate chinese LiR1_NS2_label_598011a1:

    # Liza "Oh God! Just like that! Rub your pussy, up against my clitty!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:96
translate chinese LiR1_NS2_label_823e8afa:

    # Yazmin "(Huh?! Oops! I spent so much time reminiscing about the past, that I didn’t realise we’d changed positions again!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:97
translate chinese LiR1_NS2_label_163c436a:

    # Yazmin "(The memories we’ve made keep getting better with each passing year. I think we’re going to have a wonderful life together.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:101
translate chinese LiR1_NS2_label_8fd4caed:

    # Yazmin "Ohhh! Mmm! Ahh!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:102
translate chinese LiR1_NS2_label_fc7ffe58:

    # MC "(It looks like they’re rubbing their pussies together now. Is this what lesbians call tribadism?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:103
translate chinese LiR1_NS2_label_5aa4267a:

    # Yazmin "God! I’m so fucking wet right now..."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:107
translate chinese LiR1_NS2_label_9a8ac415:

    # Yazmin "Harder! Faster! Mmm! Don’t stop moving your hips, Liza!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:108
translate chinese LiR1_NS2_label_6e6d4c09:

    # Liza "Ah! Ahhh! Yes!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:109
translate chinese LiR1_NS2_label_c9210647:

    # MC "(I wonder how it feels for lesbians to rub their pussies together. It looks like they’re both REALLY enjoying it!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:113
translate chinese LiR1_NS2_label_0966b6e6:

    # Yazmin "Hnnnnng! Fuuuuck! I’m gonna cum!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:114
translate chinese LiR1_NS2_label_b527f1de:

    # Liza "Ahh! Me too! Ohhh!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:115
translate chinese LiR1_NS2_label_97ce1dcc:

    # Yazmin "Yes! Just like that! AHH! AHHH!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:119
translate chinese LiR1_NS2_label_b9e74f6a:

    # Yazmin "(She’s angled it perfectly! I can feel her clitoris, brushing up against mine. Every time she moves her hips, it’s like a miniature explosion of pleasure in my pussy.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:120
translate chinese LiR1_NS2_label_ec50ca4a:

    # Liza "Mmm! I love you, Yazmin!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:121
translate chinese LiR1_NS2_label_4525330a:

    # Yazmin "I love yooooohhhhh! OHH! AHHHH!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:125
translate chinese LiR1_NS2_label_6f5f2c58:

    # MC "(They’re both trembling, while they hold each other. It looks like they climaxed at the same time.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:126
translate chinese LiR1_NS2_label_3b2541aa:

    # MC "(That was actually kinda cute. Hopefully I’ll have a partner I can do that with, someday.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:127
translate chinese LiR1_NS2_label_3d37b3dd:

    # Yazmin "*Pant Pant*"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:131
translate chinese LiR1_NS2_label_25db0804:

    # Liza "*Pant* H-How was it for you?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:132
translate chinese LiR1_NS2_label_2e3a64d1:

    # Yazmin "Absolutely indescribable. *Pant* It was... perfect."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:133
translate chinese LiR1_NS2_label_0cb2b089:

    # Liza "Same here. You’re the best, Dear. You know that?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:134
translate chinese LiR1_NS2_label_7b8cceed:

    # Yazmin "Hehe... I know."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:138
translate chinese LiR1_NS2_label_a0aca9e0:

    # Yazmin "(Mmm, I can taste my own pussy juices, as I’m making out with her. I wonder if she notices too.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:139
translate chinese LiR1_NS2_label_6420ca39:

    # Yazmin "(The same thing happened that night in the forest, after she had finished eating me out. We were still awake and making out with each other at three AM - and the rain STILL hadn’t stopped!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:143
translate chinese LiR1_NS2_label_65b06725:

    # Yazmin "(She only fell asleep, after I started kissing her breasts. I don’t know if she found it relaxing - perhaps she was just tired from the walk.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:144
translate chinese LiR1_NS2_label_07a10ca2:

    # Yazmin "(Whatever the reason - she slept like a baby, all night, in my arms. We became an official couple, the next day. I don’t think we’ve been apart since.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:151
translate chinese LiR1_NS2_label_f7d4aa0e:

    # Yazmin "..."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:152
translate chinese LiR1_NS2_label_8d5661f6:

    # MC "(Oh fuck... I think Yazmin has spotted me...)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:153
translate chinese LiR1_NS2_label_33a02bf8:

    # MC "*Gulp* (She hasn’t said or done anything yet. Maybe I’m in the clear?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:157
translate chinese LiR1_NS2_label_6cc09d8e:

    # Yazmin "(Yup - just as I thought, it’s Liza’s nephew. The little pervert must have been spying on us. I wonder how many night’s he’s been doing this - without me knowing!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:159
translate chinese LiR1_NS2_label_937dbcca:

    # Yazmin "(Yup - just as I thought, it’s [player_name]. The little pervert must have been spying on us. I wonder how many night’s he’s been doing this without me knowing!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:160
translate chinese LiR1_NS2_label_865cb979:

    # Yazmin "(Time to scare the little bastard off.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:161
translate chinese LiR1_NS2_label_44bb9a52:

    # Liza "Is everything okay, Yazmin?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:162
translate chinese LiR1_NS2_label_e9464f91:

    # Yazmin "Yeah, Honey. Just thought I saw something at the window."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:167
translate chinese LiR1_NS2_label_716debab:

    # MC "(Fuck! She just pointed at me! She’s DEFINITELY seen me! I better dash away from here before Auntie sees me!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:168
translate chinese LiR1_NS2_label_4f86c158:

    # MC "(How would Mom react if Auntie told her that I’d been spying on her? She’d probably kill me... Or them..!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:170
translate chinese LiR1_NS2_label_8363e19a:

    # MC "(She just pointed at me! She’s DEFINITELY seen me, but she isn’t saying anything...Does she enjoy having me watch her like this?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:171
translate chinese LiR1_NS2_label_8eaad1ae:

    # MC "(I probably shouldn’t hang around much longer. Maybe Yazmin will speak to me about it the next time we meet.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:175
translate chinese LiR1_NS2_label_e1f9ac62:

    # MC "(Damn, this is pretty high... Why was it so much easier to climb up, than to get down?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS2.rpy:176
translate chinese LiR1_NS2_label_bcf05de4:

    # MC "(I’ll have to be more careful, in future!)"
    MC ""

