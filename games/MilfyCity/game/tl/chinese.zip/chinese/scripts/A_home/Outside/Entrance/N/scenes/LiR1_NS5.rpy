﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:103
translate chinese LiR1_NS5_label_039a2ae3:

    # Liza "Yes! Yes! Oh, my God! Yes!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:104
translate chinese LiR1_NS5_label_d08ae390:

    # Yazmin "*Shllluuurrrrp*"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:105
translate chinese LiR1_NS5_label_b78cbfbf:

    # MC "(I always walk in at the best moments! It’s like I’m the main character in a story!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:109
translate chinese LiR1_NS5_label_8f66577a:

    # Liza "That’s sooooo goood! Don’t stop! Right there!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:110
translate chinese LiR1_NS5_label_c3aacfb0:

    # MC "([Liza_name] MUST do yoga! She has some seriously good stretching going on there!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:111
translate chinese LiR1_NS5_label_521d03fc:

    # MC "(I wonder what Yazmin wanted me to come up for? Should I interrupt them now..? Or just let them continue fooling around with each other?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:115
translate chinese LiR1_NS5_label_b95d3656:

    # MC "(I guess there’s - no harm - in watching, for a little while longer.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:116
translate chinese LiR1_NS5_label_5c46952a:

    # Yazmin "*Lick Lick*"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:117
translate chinese LiR1_NS5_label_4b9e9bfd:

    # Liza "Yeessss! Oh Yazmin! Ugh!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:121
translate chinese LiR1_NS5_label_a8f90b62:

    # Liza "Oh fuck! I’m so fucking wet, right now! My pussy is soaked!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:122
translate chinese LiR1_NS5_label_4b8863e9:

    # Yazmin "*Shlurp Suck*"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:123
translate chinese LiR1_NS5_label_8ccec385:

    # MC "(Damn... Look at how stiff, [Liza_name]’s nipple’s are! She’s definitely loving this!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:127
translate chinese LiR1_NS5_label_9817d380:

    # MC "(I was a bit worried, the two of them would be angry at each other, after the blowjob incident the other night. But it seems they’re getting on really well again.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:128
translate chinese LiR1_NS5_label_034daa83:

    # Liza "AHH! I’M CUMMING! OH! OHHHH! OHHHHHHH!!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:129
translate chinese LiR1_NS5_label_6f8f69f3:

    # Yazmin "(Ugh... Finally! My tongue is exhausted!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:133
translate chinese LiR1_NS5_label_6686db00:

    # MC "(It looks like everything is coming to a climax, so I’ll interrupt them now.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:134
translate chinese LiR1_NS5_label_eb60a235:

    # MC "Ummm... *Ahem*"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:135
translate chinese LiR1_NS5_label_e18c8618:

    # Liza "Huh?!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:139
translate chinese LiR1_NS5_label_b74222ae:

    # Yazmin "Ahh, [player_name]! Glad you could make it! I was hoping you would join us!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:140
translate chinese LiR1_NS5_label_36270e9f:

    # Yazmin "Sorry, I was just getting my wife ready for round two tonight. That’s her all fired up and raring to go!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:141
translate chinese LiR1_NS5_label_fbf0d75c:

    # Liza "Umm... Hi, [player_name]."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:145
translate chinese LiR1_NS5_label_66897496:

    # MC "What do you want me to do?"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:146
translate chinese LiR1_NS5_label_fd05d186:

    # Yazmin "How about, you get your ass over here, and start taking your clothes off?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:148
translate chinese LiR1_NS5_label_2e0dab86:

    # MC "Y-Yeah, okay. Are you alright, if I join you, [Liza_name]?"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:150
translate chinese LiR1_NS5_label_e07a70de:

    # MC "Y-Yeah, okay. Are you alright, if I join you?"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:154
translate chinese LiR1_NS5_label_6548a432:

    # Liza "Umm... I’m not... sure...."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:155
translate chinese LiR1_NS5_label_0cf2d79d:

    # Yazmin "Oh c’mon, Dear..? We talked about this for hours! You said you were good to go."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:156
translate chinese LiR1_NS5_label_2aebc102:

    # Liza "Yeah, but that’s just because I was really horny and you wouldn’t let me cum unless I said yes..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:157
translate chinese LiR1_NS5_label_1d256e8c:

    # Yazmin "Oh yeah..! I forgot I did that. Haha! I’ll tell you what, Honey - you just sit back and relax. Let me start things off with [player_name]. And we’ll take it from there."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:161
translate chinese LiR1_NS5_label_057d7d0a:

    # Yazmin "Okay - let’s get you ready for the show."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:162
translate chinese LiR1_NS5_label_79ca793d:

    # MC "Do you want me to strip off now?"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:167
translate chinese LiR1_NS5_label_1b743d72:

    # Yazmin "Hold on, a second. I just want to give my favourite nephew a hug, before we do this."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:169
translate chinese LiR1_NS5_label_7297d899:

    # Yazmin "Hold on, a second. I just want to give you a hug, before we do this."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:171
translate chinese LiR1_NS5_label_30569251:

    # MC "Huh? I never knew you were the hugging type."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:172
translate chinese LiR1_NS5_label_8b016ff8:

    # Yazmin "I’ve ALWAYS been the hugging type."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:176
translate chinese LiR1_NS5_label_8fe29977:

    # Yazmin "*Whispered* Whenever we’re making out on the bed, I’m going to kick your leg."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:177
translate chinese LiR1_NS5_label_f40d492e:

    # Yazmin "*Whispered* When you feel me do that, I want you to reach up and wrap your fingers around my throat."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:178
translate chinese LiR1_NS5_label_785a791c:

    # Yazmin "*Whispered* Treat me as rough as you like. Don’t worry - you’re not strong enough to really hurt me, pal."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:182
translate chinese LiR1_NS5_label_09f97be3:

    # MC "*Whispered* Th-That’s insane!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:183
translate chinese LiR1_NS5_label_b1e9f859:

    # Yazmin "*Whispered* Trust me - it will get Liza wetter, than New Delhi in monsoon season."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:184
translate chinese LiR1_NS5_label_80e2c5f7:

    # Yazmin "*Whispered* She’s got a real kink for rough and tumble sex. A bit of light choking, spanking - that kinda thing."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:188
translate chinese LiR1_NS5_label_cd1e45b8:

    # Liza "What are, you two whispering about?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:189
translate chinese LiR1_NS5_label_0cb24059:

    # MC "Uh, we were... um..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:190
translate chinese LiR1_NS5_label_64a35b39:

    # Yazmin "Nothing, Dear! Just you lay back and enjoy the show!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:194
translate chinese LiR1_NS5_label_289c223d:

    # Yazmin "*Whispered* You clearly haven’t done anything like this before. But you have to promise me right now that as soon as I kick you, you’ll get rough with me, okay?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:195
translate chinese LiR1_NS5_label_dc3b0659:

    # Yazmin "*Whispered* This plan isn’t going to work unless you play your part. Got it?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:196
translate chinese LiR1_NS5_label_d5e5c3ec:

    # MC "*Whispered* Y-Yeah, I got it."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:200
translate chinese LiR1_NS5_label_55c7d82c:

    # Yazmin "*Whispered* This could very well be my ONLY chance to convince Liza to add some cock to our sex life."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:201
translate chinese LiR1_NS5_label_37391f67:

    # Yazmin "*Whispered* I have spent WEEKS concocting this plan, gauging her reactions, and testing the waters."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:202
translate chinese LiR1_NS5_label_56567cf1:

    # Yazmin "*Whispered* So please, for the love of God, promise me that you will do EXACTLY like I said."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:203
translate chinese LiR1_NS5_label_9d4fc6d6:

    # MC "O-Okay, I promise."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:207
translate chinese LiR1_NS5_label_bbadc50e:

    # Liza "Umm, are you guys planning to start anytime soon? Or is this how boring straight sex usually is?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:208
translate chinese LiR1_NS5_label_5bd215ef:

    # Yazmin "Ha... ha... Very funny, Liza! We’re just warming up!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:209
translate chinese LiR1_NS5_label_34ff7da2:

    # Yazmin "C’mon, [player_name]! Hurry up and get those trousers off, and sit on the edge of the bed."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:213
translate chinese LiR1_NS5_label_bcde87ad:

    # Yazmin "We’re gonna do a different position tonight, Liza. I’ll still be on top, but I’ll be sitting on his cock, instead."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:214
translate chinese LiR1_NS5_label_2783d040:

    # Liza "Oh wow..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:215
translate chinese LiR1_NS5_label_d51a212d:

    # Yazmin "From this angle, I could probably take him - in my ass OR my pussy. I think I’ll have him, fuck my cunt again, though."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:219
translate chinese LiR1_NS5_label_cd960478:

    # MC "I wouldn’t mind, fucking your ass!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:220
translate chinese LiR1_NS5_label_9b420e23:

    # Yazmin "Yeah... you’re not getting my ass. Only really lucky guys get to put their dick in there, and it has to be a special occasion!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:221
translate chinese LiR1_NS5_label_2f4e41a1:

    # MC "Is this not a special occasion?"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:225
translate chinese LiR1_NS5_label_af7d94e9:

    # Yazmin "It is - you’re just not a really lucky guy. But don’t worry - I’m sure you’ll get there, someday."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:226
translate chinese LiR1_NS5_label_ba29f9d1:

    # MC "Mmm... Do you and Liza, ever do anal play?"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:227
translate chinese LiR1_NS5_label_aff924e6:

    # Yazmin "Sometimes - but not really, much penetration. It’s mostly just - tongue and finger stuff."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:231
translate chinese LiR1_NS5_label_bfa132de:

    # Yazmin "Oh God! Yes!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:232
translate chinese LiR1_NS5_label_a5adf357:

    # MC "Mmm! Ohhh..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:233
translate chinese LiR1_NS5_label_e14cb513:

    # MC "(Damn, her pussy is so hot and wet! It’ll be a miracle, if I don’t blow my load in a couple of minutes!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:237
translate chinese LiR1_NS5_label_7ac5d9c3:

    # Yazmin "What were we talking about, again? Oh yeah - anal stuff."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:238
translate chinese LiR1_NS5_label_1fd25339:

    # Yazmin "Liza REALLY likes it, if you stick a finger in her ass, while you’re eating her pussy."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:239
translate chinese LiR1_NS5_label_358e33e0:

    # Liza "Hey! That’s private! You can’t just go, giving out my secre-"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:240
translate chinese LiR1_NS5_label_f35c78a1:

    # Yazmin "The trick is to time your finger so that it enters just as she climaxes. It’s amazing, she screams her head off in pleasure."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:244
translate chinese LiR1_NS5_label_7c5460ec:

    # Liza "I can’t believe you! Do you have no shame - telling your nephew about these things?!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:246
translate chinese LiR1_NS5_label_db3ac305:

    # Liza "I can’t believe you! Do you have no shame - telling [player_name] about these things?!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:247
translate chinese LiR1_NS5_label_f7d382de:

    # Yazmin "Aww, Honey. You’ve been married to me for YEARS now - you must know that I don’t have ANY shame. Do you not remember that time I stole your bra on the beach in Malaga?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:248
translate chinese LiR1_NS5_label_18ad7e60:

    # Liza "Shut up! Oh, my God!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:249
translate chinese LiR1_NS5_label_cdf1e475:

    # Yazmin "I’m pretty sure, some guys caught you on camera, while you were chasing me across the sandy dunes."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:253
translate chinese LiR1_NS5_label_a57808a5:

    # Yazmin "Ah! Ah..! Don’t pretend you didn’t enjoy it!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:254
translate chinese LiR1_NS5_label_d65e75a1:

    # MC "Mmm! (She’s telling this story, while she’s fucking me!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:255
translate chinese LiR1_NS5_label_ce507489:

    # Yazmin "Don’t you remember, when you finally caught me? You were soaking wet! You got off on the thought of being seen naked, in public."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:256
translate chinese LiR1_NS5_label_c350b718:

    # Liza "..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:260
translate chinese LiR1_NS5_label_802100ef:

    # Yazmin "Oh God! Yes! Yes! Ahhh!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:262
translate chinese LiR1_NS5_label_8855822e:

    # MC "Aahhh! (She’s picking up the pace now! I don’t know if I’ll be able to - last much longer.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:263
translate chinese LiR1_NS5_label_215b1a1d:

    # Liza "(Why am I watching this? Straight porn never turned me on very much - how is watching it live, any different?)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:267
translate chinese LiR1_NS5_label_028fa965:

    # Yazmin "I’ve got another little technique I picked up from a smoking hot guy in Italy. I like to call it the ‘lift and drop’."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:268
translate chinese LiR1_NS5_label_05fbc502:

    # Yazmin "The trick is, to slowly lift your hips - massaging his cock with your vulva, as you go up."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:270
translate chinese LiR1_NS5_label_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:271
translate chinese LiR1_NS5_label_b51288d2:

    # Yazmin "And when you reach the top, you... "
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:275
translate chinese LiR1_NS5_label_534d386b:

    # Yazmin "...drop back down! AH! AHHHHHH!!!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:276
translate chinese LiR1_NS5_label_94f8a103:

    # MC "MMMM!!! OHHH!!!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:277
translate chinese LiR1_NS5_label_91167a6c:

    # Liza "Wow..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:281
translate chinese LiR1_NS5_label_ca6cc508:

    # Yazmin "Yes! Yes! Oh God! Your cock feels so good, [player_name]!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:282
translate chinese LiR1_NS5_label_66e4e10c:

    # Yazmin "Mmm! It’s filling up my tight little pussy so well!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:283
translate chinese LiR1_NS5_label_46ff3b2c:

    # MC "(Yazmin is incredible, with her hips! She knows exactly how to grind and rock them, to get a guy off!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:287
translate chinese LiR1_NS5_label_638c46d3:

    # Liza "*Sigh*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:288
translate chinese LiR1_NS5_label_8d73846a:

    # Liza "(This really isn’t doing anything for me, at all... How much longer do they have to fuck each other, before I can go to sleep?)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:289
translate chinese LiR1_NS5_label_480837b7:

    # Yazmin "(Crap! It looks like she’s losing interest... Time to - put my plan into motion!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:293
translate chinese LiR1_NS5_label_abb4c5c9:

    # "*Kick*"
    ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:294
translate chinese LiR1_NS5_label_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:295
translate chinese LiR1_NS5_label_c5d5f679:

    # MC "(Yazmin just kicked me! That must mean, she is ready for me to start choking her! I don’t know if I want to do this, but I can’t risk, ruining her relationship.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:299
translate chinese LiR1_NS5_label_0c1bf7c1:

    # Yazmin "(What’s he waiting for?! Did he not feel the kick?! We’re running out of time!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:300
translate chinese LiR1_NS5_label_4734fedd:

    # Yazmin "Ah! Ah! Ah!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:301
translate chinese LiR1_NS5_label_61915913:

    # "*KICK*"
    ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:302
translate chinese LiR1_NS5_label_31bbb934:

    # MC "Ouch! (Dammit! I felt the first one!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:306
translate chinese LiR1_NS5_label_56722415:

    # Yazmin "Ahhhh! Oooh!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:307
translate chinese LiR1_NS5_label_e616c12d:

    # Yazmin "(FINALLY! Okay, let’s see how THIS goes down with Liza!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:308
translate chinese LiR1_NS5_label_a3be0aae:

    # MC "(I hope I’m not gripping her, too tightly. I have to do as she says, but I really don’t want to hurt her, either!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:312
translate chinese LiR1_NS5_label_7143ee47:

    # Liza "(Holy fuck! He’s choking her!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:313
translate chinese LiR1_NS5_label_7fca39a6:

    # Liza "(He’s so... dominant in bed... Yazmin is just, being pinned back and fucked like a toy.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:314
translate chinese LiR1_NS5_label_4097cb2c:

    # Yazmin "AH! AHHH! AHHHH!!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:318
translate chinese LiR1_NS5_label_96ac2d57:

    # MC "(Damn, this is actually pretty hot! Thrusting my hips into her, like this - feels so good!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:319
translate chinese LiR1_NS5_label_974506b0:

    # MC "Ugh! How do you like that, bitch..? I’m gonna break your pussy, with my hard cock..!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:320
translate chinese LiR1_NS5_label_5cb2cefc:

    # Liza "(Wow... He’s acting, completely different.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:324
translate chinese LiR1_NS5_label_3698470e:

    # MC "Hnnng! Ugh! Ah!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:326
translate chinese LiR1_NS5_label_3de22ec3:

    # Yazmin "AAAHH! OHHH! GOD! YEEEESSSSS!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:327
translate chinese LiR1_NS5_label_51572351:

    # Liza "(Holy shit... He’s fucking her, so hard!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:331
translate chinese LiR1_NS5_label_4f817020:

    # Liza "(Look at how deep he’s gone... He must be all the way up to her cervix!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:332
translate chinese LiR1_NS5_label_545dc06d:

    # Liza "(If he were to cum, right now, there’s no way she WOULDN’T get pregnant!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:333
translate chinese LiR1_NS5_label_238552ff:

    # MC "Ugh! I love fucking your - soaking wet cunt, you slut!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:337
translate chinese LiR1_NS5_label_a67487dd:

    # Yazmin "AHHHH! HOLY FUCK!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:339
translate chinese LiR1_NS5_label_4b82892a:

    # Yazmin "(He is even better than I imagined he would be! He’s a fucking NATURAL at this rough sex stuff!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:340
translate chinese LiR1_NS5_label_df10ea2b:

    # Yazmin "(If all goes according to plan, then Liza will be jilling herself off by the time he cums!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:344
translate chinese LiR1_NS5_label_c1fa7674:

    # MC "Ugh! I’m gonna cum - so fucking deep, and so fucking hard - inside your pussy! And there is NOTHING you can do to stop it! Ah! Ahhh!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:345
translate chinese LiR1_NS5_label_da70cfe9:

    # Yazmin "Ayaaaaahhh! I’m cumming! EEEEEEEKKKK!!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:346
translate chinese LiR1_NS5_label_d8c04467:

    # Liza "(This is... really hot...)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:350
translate chinese LiR1_NS5_label_2d0f059f:

    # Liza "(I guess I could touch myself, a little bit...)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:351
translate chinese LiR1_NS5_label_947bf118:

    # Liza "(Seeing a guy force himself on a woman like that, is such a huge turn on for me... I don’t understand why?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:352
translate chinese LiR1_NS5_label_d8906a19:

    # Liza "I’ve always been attracted to women, but as soon as a man gets super-dominant - I melt like butter.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:356
translate chinese LiR1_NS5_label_5b82e823:

    # Yazmin "YES! YES! YES! AHAHHHHHHHH!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:357
translate chinese LiR1_NS5_label_c0415c23:

    # MC "(I can feel her pussy quivering and contracting around my cock. Time for me to cum too!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:358
translate chinese LiR1_NS5_label_4f11db9a:

    # MC "I’m gonna fill you up with my hot, potent cum!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:362
translate chinese LiR1_NS5_label_398babae:

    # MC "Hnnnnggg! GAAAAHHHHH! UGH!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:364
translate chinese LiR1_NS5_label_989c4f3a:

    # Liza "Ohh... ah... Mmnmm..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:366
translate chinese LiR1_NS5_label_8fb11f1a:

    # Yazmin "(Yes! He’s cumming inside me! God, it feels so fucking good!)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:377
translate chinese LiR1_NS5_label_88b6e38a:

    # MC "Hnnnngggg.... Ugh... Ah..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:378
translate chinese LiR1_NS5_label_08d67cbc:

    # MC "*Pant* Wow..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:379
translate chinese LiR1_NS5_label_dc1a7a51:

    # Yazmin "Fuuuck.... That was goood..."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:383
translate chinese LiR1_NS5_label_94fa5552:

    # Liza "Ah... Mmm... Oh..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:384
translate chinese LiR1_NS5_label_bea69ef3:

    # MC "(Huh? Is Yazmin still moaning?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:385
translate chinese LiR1_NS5_label_8b087332:

    # MC "(Wait a minute - that’s not Yazmin’s voice!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:389
translate chinese LiR1_NS5_label_1c90feda:

    # Yazmin "(Well, it looks like, someone else finally decided to join in on the fun.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:390
translate chinese LiR1_NS5_label_7be36adf:

    # Yazmin "(My plan worked - just as intended. Now that she’s all wet and horny we can bring her in, on the action.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:391
translate chinese LiR1_NS5_label_1e3215bd:

    # Yazmin "(I hope [player_name] has a second round left in him, because we’re nowhere near done yet.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:395
translate chinese LiR1_NS5_label_c7bbaab3:

    # Liza "Ah... Oh... Ahhh..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:396
translate chinese LiR1_NS5_label_929f362a:

    # Liza "(Dammit - my imagination is running wild, right now...)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:397
translate chinese LiR1_NS5_label_7475a89f:

    # Liza "(I’m lying alone in my house at night, Yazmin is gone for the evening. I hear the bedroom door click open - and suddenly slam shut.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:401
translate chinese LiR1_NS5_label_471dce75:

    # Liza "Ah... Ohhh!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:402
translate chinese LiR1_NS5_label_5fb63975:

    # Liza "(I open my eyes to see a - tall, dark-haired man. He’s six foot tall and rippling with massive muscles. I get up from my bed, to scream, but he rushes towards me, and clamps a hand over my mouth.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:403
translate chinese LiR1_NS5_label_1fffabdc:

    # Liza "(I’m too weak to fight back, as he tears my nightie off me - stripping me naked. I can barely resist as he pushes his cock up against my virgin pussy.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:407
translate chinese LiR1_NS5_label_bd6927b3:

    # Liza "(Suddenly, he thrusts his humongous cock inside me. It tears me open, with a stinging pain - but I can’t resist the pleasure it brings either.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:408
translate chinese LiR1_NS5_label_5edcc13f:

    # Liza "(Soon, he is fucking me with a regular rhythm. I can feel him rapidly approaching a climax. His balls clench up. I remember, I’m not on birth control! He’s going to shoot his semen inside me and get me pregnant!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:409
translate chinese LiR1_NS5_label_9d7c514f:

    # Liza "AH! AHH! AHHH! N-NO! NOT INSIDE! OHHHH! I’M CUMMMMIIING!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:413
translate chinese LiR1_NS5_label_c1078684:

    # Yazmin "Not inside?! Are you having one of your naughty fantasies again? Hehe!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:414
translate chinese LiR1_NS5_label_a434d925:

    # Liza "Wh-What?!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:415
translate chinese LiR1_NS5_label_4de17339:

    # Yazmin "I think it’s time you stopped playing with yourself and joined us."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:419
translate chinese LiR1_NS5_label_5e98b502:

    # Liza "N-No, it wasn’t what you thought it was-"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:420
translate chinese LiR1_NS5_label_958eb73d:

    # Yazmin "Oh please... You were CLEARLY masturbating!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:421
translate chinese LiR1_NS5_label_852a1903:

    # Yazmin "Now, how about you come over here, and taste - [player_name]’s delicious cock - one more time?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:425
translate chinese LiR1_NS5_label_fb784252:

    # Liza "B-But, I can’t stand the taste of it!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:426
translate chinese LiR1_NS5_label_05b7d478:

    # Yazmin "You might like it more, now that you’re SUPER horny?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:427
translate chinese LiR1_NS5_label_a2eab16b:

    # Yazmin "I know I’m always down for kinkier things, when I get - extra horny. Like anal!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:431
translate chinese LiR1_NS5_label_eb307154:

    # Liza "I don’t know..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:432
translate chinese LiR1_NS5_label_4868fe55:

    # Yazmin "Please, Dear? Just one more time? Do it for me..."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:433
translate chinese LiR1_NS5_label_d21a05f6:

    # Liza "*Sigh* Promise, this will be the last time, if I don’t like it?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:434
translate chinese LiR1_NS5_label_5468ac87:

    # Yazmin "I promise."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:438
translate chinese LiR1_NS5_label_d576157d:

    # Liza "It’s so large, though... I mean, how do you put it in your mouth, without gagging?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:439
translate chinese LiR1_NS5_label_5a29a530:

    # Yazmin "Honestly? If you’re doing it properly, then gagging is - half the fun!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:440
translate chinese LiR1_NS5_label_1e3d65c0:

    # Liza "WHAT?!"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:444
translate chinese LiR1_NS5_label_5b224210:

    # Yazmin "Listen - I’ll be right by your side, throughout it, to help. Okay?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:445
translate chinese LiR1_NS5_label_703ff522:

    # Yazmin "You know that I love you, and that I’d never hurt you. I’m only trying to open you up to some new sexual experiences, which I KNOW you are going to love."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:446
translate chinese LiR1_NS5_label_bbf19e26:

    # Yazmin "We just need to get you over this anxious hurdle you’re facing."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:450
translate chinese LiR1_NS5_label_8a8d9fcb:

    # Liza "*Sigh* Okay, I’ll do it."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:451
translate chinese LiR1_NS5_label_66ba5f9c:

    # Yazmin "Great! Are you ready for round two, [player_name]?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:452
translate chinese LiR1_NS5_label_c48c4409:

    # MC "Yup! Hard and - good to go!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:456
translate chinese LiR1_NS5_label_03968496:

    # Yazmin "Try not to think about it too much, Liza. If you HAVE to think of something, then just keep that fantasy of yours in mind."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:457
translate chinese LiR1_NS5_label_76851c5b:

    # Yazmin "Remember, sex is as much a mental and psychological experience as it is a physcial one. Just keep thinking about things, that REALLY turn you on."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:458
translate chinese LiR1_NS5_label_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:462
translate chinese LiR1_NS5_label_ba13f455:

    # Liza "(Okay... take a deep breath... I can do this...)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:463
translate chinese LiR1_NS5_label_370f8d32:

    # MC "(Here we go! Let’s see if [Liza_name] can actually finish a blowjob this time.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:464
translate chinese LiR1_NS5_label_f9fcf8ca:

    # MC "(I’m not sure how far she will get - she still looks incredibly nervous. Being horny might help, a bit but I’m not sure if she’ll actually make it to the end.)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:468
translate chinese LiR1_NS5_label_dc892d03:

    # Yazmin "(Come on, Honey! You can do it! Just a couple more inches...)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:469
translate chinese LiR1_NS5_label_f014b56a:

    # Yazmin "(I love the thought of you, sucking a guy’s cock, bobbing your head back and forth, letting him blow a load, deep into your - pretty little mouth.)"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:473
translate chinese LiR1_NS5_label_757a4b55:

    # Yazmin "If you’re nervous, Dear - then you could always start, with your hands."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:474
translate chinese LiR1_NS5_label_aedd8b93:

    # Liza "M-My hands?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:475
translate chinese LiR1_NS5_label_a43f8d1f:

    # Yazmin "Yeah. Just wrap them around the shaft, and move them up and down."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:476
translate chinese LiR1_NS5_label_5a500eba:

    # Yazmin "Most guys, probably only need one hand, but [player_name] here, has such a big dick that you could use two."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:480
translate chinese LiR1_NS5_label_b889716c:

    # Liza "Is... is this okay?"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:481
translate chinese LiR1_NS5_label_a1080c48:

    # MC "Mmm... that’s good. Just like that..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:482
translate chinese LiR1_NS5_label_25994884:

    # Liza "*Gulp* (I hope they don’t notice, how nervous I am about this.)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:486
translate chinese LiR1_NS5_label_be348f28:

    # Yazmin "Okay... Now, just lower your head towards the tip, and slowly take it in your mouth. You don’t have to go all the way on your first attempt."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:487
translate chinese LiR1_NS5_label_ce3b1ba5:

    # Yazmin "In fact, it’s probably better if you tease it out slowly, over time. Gradually build things up - if you know what I mean."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:488
translate chinese LiR1_NS5_label_38ee6409:

    # Liza "(My heart’s racing, right now!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:492
translate chinese LiR1_NS5_label_29190571:

    # Yazmin "Excellent! You’re getting there. Don’t be afraid to use your tongue, to tease the tip."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:494
translate chinese LiR1_NS5_label_c6de3fe0:

    # Yazmin "That bit at the top is called the glans - it’s basically the guy’s version of a clitoris. You know the way you would focus on licking mine? Do EXACTLY the same to him."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:495
translate chinese LiR1_NS5_label_78fffd3d:

    # Yazmin "It’s not as sensitive as a clitoris is - so you can be a little more forceful with your tongue, too."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:499
translate chinese LiR1_NS5_label_d24e7ef8:

    # Liza "*Lick Lick*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:500
translate chinese LiR1_NS5_label_3ae04744:

    # MC "Hnng... Mmmm..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:501
translate chinese LiR1_NS5_label_70aa6a36:

    # Yazmin "Do you hear those moans? You’re making him feel good, right now. See! This isn’t so bad, is it?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:505
translate chinese LiR1_NS5_label_1e6ac963:

    # Liza "*Suck*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:506
translate chinese LiR1_NS5_label_d72d81d9:

    # Yazmin "Good job, Liza! You’re doing great! It’ll feel amazing for [player_name], now that you have your lips wrapped tightly around his cock."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:508
translate chinese LiR1_NS5_label_9afcbbfc:

    # Yazmin "Remember to suck, as well as move your tongue."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:509
translate chinese LiR1_NS5_label_77b9344f:

    # MC "Oh fuck..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:513
translate chinese LiR1_NS5_label_eac3e31e:

    # Yazmin "Does it taste better this time, now that it has my pussy juices on it?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:514
translate chinese LiR1_NS5_label_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:516
translate chinese LiR1_NS5_label_3e1944b9:

    # Liza "(Hmm... Now that she mentions it - it kinda does!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:520
translate chinese LiR1_NS5_label_bc38c3f3:

    # Yazmin "Do you think you would be able to go any deeper than that?"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:521
translate chinese LiR1_NS5_label_8d061e82:

    # Yazmin "Hmm... Probably not..? I think I might be able to give you the encouragement you need, to give a proper blowjob."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:525
translate chinese LiR1_NS5_label_93afe721:

    # Yazmin "Okay, Dear - take your hands out of the way. Keep your mouth, wrapped around the tip."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:526
translate chinese LiR1_NS5_label_b40588f7:

    # MC "(Huh? What’s Yazmin planning to do now?)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:527
translate chinese LiR1_NS5_label_c8c7b6f7_1:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:531
translate chinese LiR1_NS5_label_9258a3e6:

    # Yazmin "If I straddle [player_name]’s cock, like this, then you should be able to taste my juices, as they coat his cock."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:532
translate chinese LiR1_NS5_label_54ebd77a:

    # Liza "Oh... okay... I guess this might be better..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:536
translate chinese LiR1_NS5_label_9d407d81:

    # Yazmin "Just do, exactly what you were doing earlier - but this time, try to take the cock even deeper into your mouth."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:537
translate chinese LiR1_NS5_label_86b345f3:

    # Yazmin "I’ll be standing here - so you’ll always have the taste of my pussy on it."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:538
translate chinese LiR1_NS5_label_7d430343:

    # Liza "Y-Yeah, I got it."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:542
translate chinese LiR1_NS5_label_d931ff86:

    # MC "(Here we go... The moment of truth!)"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:543
translate chinese LiR1_NS5_label_6611b1f0:

    # Liza "(You’re soooo close, Liza! You can do this!)"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:547
translate chinese LiR1_NS5_label_9fea839d:

    # Liza "*Shhhllluurrrrp*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:548
translate chinese LiR1_NS5_label_532e983b:

    # Yazmin "Woohoo! You did it!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:549
translate chinese LiR1_NS5_label_c8c7b6f7_2:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:550
translate chinese LiR1_NS5_label_d6def6f9:

    # MC "Ohhh fuck! Mmm!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:554
translate chinese LiR1_NS5_label_23576104:

    # Liza "*SUCK SUCK*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:555
translate chinese LiR1_NS5_label_d52b2016:

    # Liza "*GAG*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:556
translate chinese LiR1_NS5_label_5cb2c532:

    # Yazmin "Jesus Christ! That’s almost more than I can take! You’re a NATURAL at this, Liza!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:557
translate chinese LiR1_NS5_label_98a1006c:

    # Yazmin "It’s a shame you’re only into women. You’re wasting a REAL talent here!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:558
translate chinese LiR1_NS5_label_991d6a53:

    # MC "Ah... Ohh..."
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:563
translate chinese LiR1_NS5_label_c3bf748e:

    # Liza "*SHLURP*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:564
translate chinese LiR1_NS5_label_7363b0cd:

    # MC "Fuck... Ah! AHHH!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:565
translate chinese LiR1_NS5_label_6b624da6:

    # Yazmin "Good girl! Keep sucking that fucking cock!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:569
translate chinese LiR1_NS5_label_88531388:

    # Liza "*Gulp Gulp*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:571
translate chinese LiR1_NS5_label_6ecbbbc0:

    # MC "I’m gonna cum!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:572
translate chinese LiR1_NS5_label_521e8c16:

    # Yazmin "Go ahead and squirt it - wherever you want, [player_name]. She won’t object."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:576
translate chinese LiR1_NS5_label_a0dc799c:

    # MC "Hnnnngggg! AHHHHH!!!!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:577
translate chinese LiR1_NS5_label_df05982a:

    # Liza "*SUCK SUCK SUCK*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:578
translate chinese LiR1_NS5_label_7fb9d0ae:

    # Yazmin "Yes, that’s it! Keep sucking on that fat cock!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:582
translate chinese LiR1_NS5_label_fd2f77fa:

    # MC "AHHH! I’M CUMMING! HNNG!"
    MC ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:583
translate chinese LiR1_NS5_label_23576104_1:

    # Liza "*SUCK SUCK*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:584
translate chinese LiR1_NS5_label_396de7c9:

    # Liza "*GASP!*"
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:595
translate chinese LiR1_NS5_label_6882baf1:

    # Yazmin "Oh wow! That is QUITE the facial!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:596
translate chinese LiR1_NS5_label_10f63360:

    # Yazmin "Hehe... The look on your face, is just adorable!"
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:597
translate chinese LiR1_NS5_label_ac43a2bf:

    # Yazmin "You pulled away too quickly which is a shame. You could have had a tasty mouthful of cum."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:598
translate chinese LiR1_NS5_label_86fd2605:

    # Liza "I... uh... um..."
    Liza ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:603
translate chinese LiR1_NS5_label_8767498b:

    # Yazmin "You can head on home, [player_name]. I have to clean your auntie up, now."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:605
translate chinese LiR1_NS5_label_0664bfa2:

    # Yazmin "You can head on home, [player_name]. I have to clean Liza up, now."
    Yazmin ""

# game/scripts/A_home/Outside/Entrance/N/scenes/LiR1_NS5.rpy:606
translate chinese LiR1_NS5_label_90924dd3:

    # Yazmin "Mmm, delicious..."
    Yazmin ""

