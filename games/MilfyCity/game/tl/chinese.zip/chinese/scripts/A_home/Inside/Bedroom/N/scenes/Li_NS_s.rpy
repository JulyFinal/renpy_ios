﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:94
translate chinese Li_NS_B_feet_1ef0965f:

    # MC "(I think I’ll begin by, playing with [Liza_name]’s feet tonight. They look gorgeous!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:96
translate chinese Li_NS_B_feet_bdafead2:

    # MC "(If I didn't think it would wake her up. I would get down on my knees and suck on her toes.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:97
translate chinese Li_NS_B_feet_07bdc0a7:

    # MC "(I guess I’ll just settle for, massaging them with my hands and rubbing my cock against them.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:101
translate chinese Li_NS_B_feet_03cb20ca:

    # MC "(Damn, just look at how perfect they are. Auntie Liza obviously takes, very good care of them.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:103
translate chinese Li_NS_B_feet_d6222c00:

    # MC "(Damn, just look at how perfect they are. Liza obviously takes, very good care of them.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:104
translate chinese Li_NS_B_feet_78c0080c:

    # MC "(I wonder if her and Yazmin do any footplay together. How do lesbians even play with each other's feet? Do they rub them against their pussies?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:105
translate chinese Li_NS_B_feet_ffeefc15:

    # MC "(I’ll have to ask Yazmin about that, someday.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:108
translate chinese Li_NS_B_feet_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:109
translate chinese Li_NS_B_feet_f6b97d0b:

    # MC "(They’re so soft. I could rub these for hours!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:110
translate chinese Li_NS_B_feet_de2ab4ce:

    # MC "(Thankfully, they’re not too sensitive either! I know that some women have especially sensitive and ticklish feet.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:112
translate chinese Li_NS_B_feet_7ccaae32:

    # Liza "(Mmm! I wasn’t expecting to get a foot massage when I agreed to this sleep roleplay. This is actually surprisingly nice!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:116
translate chinese Li_NS_B_feet_f23f17ce:

    # MC "(Okay, let’s get my cock, in between them, and see how this feels.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:117
translate chinese Li_NS_B_feet_1bc0e24a:

    # MC "Oh fuck... that’s good..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:119
translate chinese Li_NS_B_feet_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:121
translate chinese Li_NS_B_feet_ec1ed59f:

    # Liza "Mmm... "
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:125
translate chinese Li_NS_B_feet_4f02e50d:

    # MC "(Easy does it... I’ll just slowly thrust my hips back and forth until I cum.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:128
translate chinese Li_NS_B_feet_e3c1a75f:

    # MC "(It’s very kind of her to sleep without a blanket on - It makes this sooo much easier for me! Haha!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:130
translate chinese Li_NS_B_feet_4fb47b96:

    # MC "(It’s very kind of Liza to “sleep” without a blanket on - it makes this sooo much easier for us to do this roleplay!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:134
translate chinese Li_NS_B_feet_7e39c023:

    # MC "Ah... uh... mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:136
translate chinese Li_NS_B_feet_e329c7dd:

    # MC "(I think it’s time to change position. Let’s rub my cock against the soles of her feet, for a while!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:139
translate chinese Li_NS_B_feet_7bfad863:

    # MC "Ohhh yeah..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:140
translate chinese Li_NS_B_feet_d0d69ae2:

    # Liza "Zzz...."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:141
translate chinese Li_NS_B_feet_9912f8de:

    # MC "(My glans is rubbing, right up between her toes. That’s fucking perfect!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:145
translate chinese Li_NS_B_feet_23eba3d9:

    # MC "Mmm... Damn, this is good..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:149
translate chinese Li_NS_B_feet_f740ac3b:

    # Liza "(It sounds like he’s having a good time down there! I’ll keep pretending to sleep.)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:150
translate chinese Li_NS_B_feet_1c68c6f7_1:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:151
translate chinese Li_NS_B_feet_0059b63b:

    # MC "Ah... Ah..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:155
translate chinese Li_NS_B_feet_cf261f90:

    # MC "(I love the feeling of her big toes, curling back, against my cock.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:157
translate chinese Li_NS_B_feet_da70cb88:

    # MC "(I wonder how much longer I can get away with doing this, before she wakes up?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:159
translate chinese Li_NS_B_feet_b1c85923:

    # MC "(I wonder how much longer she’ll let me do this?) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:163
translate chinese Li_NS_B_feet_a457c9fb:

    # MC "(I should probably play it safe, I’ll do one last - big thrust, then just wank myself off over her feet.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:165
translate chinese Li_NS_B_feet_b9f5a526:

    # MC "(By the time she wakes up, the cum will have dried up and disappeared.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:167
translate chinese Li_NS_B_feet_60f878db:

    # MC "Ugh... Ah... I’m getting close... "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:171
translate chinese Li_NS_B_feet_ac013fc4:

    # MC "Ugh! Ah... Hnnnggg!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:172
translate chinese Li_NS_B_feet_f51d45e6:

    # MC "(Yes! I’m gonna cum!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:174
translate chinese Li_NS_B_feet_8a38873a:

    # MC "(Damn, I have to try and keep my voice down!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:184
translate chinese Li_NS_B_feet_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:185
translate chinese Li_NS_B_feet_aa05bf9b:

    # MC "(Wow... That was amazing!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:187
translate chinese Li_NS_B_feet_dada6e07:

    # MC "(Okay - time for me to bail, before Auntie Liza wakes up! I’ll have to come back another night, for some more fun with them!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:189
translate chinese Li_NS_B_feet_e99d7898:

    # MC "(I hope Liza had as much fun as I did! I’ll have to come back another night for some more fun with her again!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:196
translate chinese Li_NS_B_mouth_de86f302:

    # MC "(I think I’ll play with Auntie Liza’s mouth tonight. I can probably get away with kissing her. And I might even be able to make her suck on my cock for a while, without waking her up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:197
translate chinese Li_NS_B_mouth_00b57697:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:199
translate chinese Li_NS_B_mouth_09ca4b03:

    # MC "(I think I’ll play with Liza’s mouth tonight. I can probably get away with kissing her, and I might even be able to make her suck on my cock for a while. I think that’s something she’d enjoy.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:200
translate chinese Li_NS_B_mouth_f9b808fa:

    # Liza "(I wonder what [player_name] is going to do to me tonight?)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:201
translate chinese Li_NS_B_mouth_35cca795:

    # MC "(Okay - time to make my move.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:205
translate chinese Li_NS_B_mouth_75958cf9:

    # MC "(Mmm... she smells beautiful. She must have put on some perfume, before she went to bed.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:206
translate chinese Li_NS_B_mouth_e5ec0587:

    # MC "(Perhaps Yazmin and her, were having a romantic night together?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:210
translate chinese Li_NS_B_mouth_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:211
translate chinese Li_NS_B_mouth_31460af9:

    # Liza "Zz... Mm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:213
translate chinese Li_NS_B_mouth_53ebe444:

    # MC "(She seems to have reacted well, to me kissing her lips. Perhaps she is dreaming that Yazmin is doing it.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:215
translate chinese Li_NS_B_mouth_e835abef:

    # MC "(She seems to have reacted well to me kissing her lips. Perhaps she is fantasising that Yazmin is doing it.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:219
translate chinese Li_NS_B_mouth_bad23532:

    # MC "(Let’s see if I can take this kiss a little bit further. I wonder how easy it will be, to open her mouth a little bit.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:220
translate chinese Li_NS_B_mouth_15865e40:

    # MC "(Hmm? if I gently, grab her chin and pull it down...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:224
translate chinese Li_NS_B_mouth_f48a2b8f:

    # MC "*Whispered* Perfect..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:225
translate chinese Li_NS_B_mouth_97f72c2f:

    # MC "(God, she’s so fucking sexy...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:229
translate chinese Li_NS_B_mouth_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:230
translate chinese Li_NS_B_mouth_a82518c8:

    # Liza "Hmmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:231
translate chinese Li_NS_B_mouth_9f3eb2c2:

    # MC "(Nice! I’ve got some tongue action going on with her now.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:235
translate chinese Li_NS_B_mouth_922c71ab:

    # MC "(Okay, that’s gone on long enough. I think it’s time for me to take things to the next level.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:237
translate chinese Li_NS_B_mouth_dbad87fc:

    # MC "(I know I can open her mouth, and put my tongue in without waking her up. Let’s see if this sleeping beauty can handle something bigger?!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:239
translate chinese Li_NS_B_mouth_dfc72d4a:

    # MC "(I know she enjoys making out. Let’s see if she is willing to handle something bigger!) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:243
translate chinese Li_NS_B_mouth_cf67cfcd:

    # MC "(Here goes nothing... I’ll just gently rub it against her lips, to start with.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:245
translate chinese Li_NS_B_mouth_5246998e:

    # MC "(Hopefully, if she gets used to the sensation, her body won’t wake her up!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:246
translate chinese Li_NS_B_mouth_00b57697_1:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:248
translate chinese Li_NS_B_mouth_a41e7330:

    # MC "(Hopefully if she gets used to the sensation she will enjoy it!) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:249
translate chinese Li_NS_B_mouth_ea90627b:

    # Liza "(Is that a... Wow! His cock feels so big!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:253
translate chinese Li_NS_B_mouth_61c3437a:

    # MC "(And now, I’ll just apply a little bit of pressure, to try and get through her lips.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:254
translate chinese Li_NS_B_mouth_4c0d442f:

    # MC "*Whispred* Come on... open your mouth..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:256
translate chinese Li_NS_B_mouth_b6a397bc:

    # Liza "*Glompf* Mmmpf..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:260
translate chinese Li_NS_B_mouth_324d37f5:

    # MC "*Whispered* Yes!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:261
translate chinese Li_NS_B_mouth_f6ef4700:

    # MC "(Now we’re on a roll! I’ll have it pushed inside in no time!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:265
translate chinese Li_NS_B_mouth_312847cd:

    # MC "Mmm...."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:266
translate chinese Li_NS_B_mouth_e7d4f503:

    # Liza "Hmmm... *Shlurp*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:268
translate chinese Li_NS_B_mouth_155020fc:

    # MC "Ah... (This is so good... I just wish she was THIS relaxed about blowjobs, in real life!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:270
translate chinese Li_NS_B_mouth_9d0c73e7:

    # MC "Ah... (This is so good... This roleplay has really helped relax Liza when it comes to giving blowjobs!) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:274
translate chinese Li_NS_B_mouth_2440bb64:

    # MC "Hnnng! Oh God..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:275
translate chinese Li_NS_B_mouth_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:277
translate chinese Li_NS_B_mouth_9ba0c358:

    # MC "(Fuck... She’s sucking on my cock, in her sleep!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:279
translate chinese Li_NS_B_mouth_488fd294:

    # MC "(Fuck... She’s sucking on my cock!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:280
translate chinese Li_NS_B_mouth_68141de5:

    # MC "Hnnng! (The sensation of my dick, rubbing against her cheek, is too much! I’m cumming!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:284
translate chinese Li_NS_B_mouth_252048f2:

    # MC "Hnnng... Ugh..... arghh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:285
translate chinese Li_NS_B_mouth_1be3c6e7:

    # MC "*Phew...*"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:286
translate chinese Li_NS_B_mouth_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:288
translate chinese Li_NS_B_mouth_895f78cc:

    # MC "(Wow! She swallowed it, in her sleep! Time for me to bail!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:290
translate chinese Li_NS_B_mouth_db6336d0:

    # MC "(Wow! She swallowed it all! I’ll come back another time and play with Liza and Yazmin again!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:294
translate chinese Li_NS_B_mouth_108d2a8d:

    # Liza "Huh? (Why do I have a salty taste in my mouth? I'm almost certain I brushed my teeth, after I ate those crisps...)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:295
translate chinese Li_NS_B_mouth_bfb798ec:

    # Liza "Hmm... (Maybe I forgot..?)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:297
translate chinese Li_NS_B_mouth_6e6be314:

    # Liza "Mmm... (That was quite salty! Not too bad though!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:298
translate chinese Li_NS_B_mouth_00b57697_2:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:305
translate chinese Li_NS_B_pussy_023ad8d8:

    # MC "(I think I’ll begin tonight, by pulling down [Liza_name]’s pantyhose and licking her pussy.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:307
translate chinese Li_NS_B_pussy_a3ba6a48:

    # MC "(I wonder if I can make her cum, while she’s sleeping! That would be quite the feat!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:309
translate chinese Li_NS_B_pussy_95eb8b18:

    # MC "(I wonder if I can make her cum! That would be quite the feat considering she’s more used to Yazmin’s tongue!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:313
translate chinese Li_NS_B_pussy_5ee3f966:

    # MC "(She’s wearing those frail, lacy, pantyhose. These things will be a breeze to remove!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:315
translate chinese Li_NS_B_pussy_e38704ec:

    # Liza "(I wonder what he’s going to do to my body tonight... I’m getting wet with anticipation.)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:316
translate chinese Li_NS_B_pussy_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:317
translate chinese Li_NS_B_pussy_6224e4e3:

    # MC "(Alright... I’ll just slip my fingers under the waistband.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:321
translate chinese Li_NS_B_pussy_e8f67d75:

    # MC "(Just like that... Perfect... Okay, gently does it. Let’s see how far I can slide these down.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:323
translate chinese Li_NS_B_pussy_f541f428:

    # MC "(Obviously, I can’t go the whole way, and take them off. It would be almost impossible to get them back on, while she’s asleep.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:325
translate chinese Li_NS_B_pussy_a08536f6:

    # MC "(Obviously, I can’t go the whole way and take them off. I don’t want to accidentally damage them!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:329
translate chinese Li_NS_B_pussy_4b7e57f2:

    # MC "(Okay, this is probably far enough. I should have plenty of room to get my tongue, up against her clitoris.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:331
translate chinese Li_NS_B_pussy_c5713450:

    # MC "(It’s a shame I can’t do this when she’s awake. I’d love to see her writing and moaning with pleasure, as I eat her out.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:333
translate chinese Li_NS_B_pussy_0724ac50:

    # MC "(I wish I could see her face when I eat her out. I’d love to see her writing and moaning with pleasure as I lick her wet pussy.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:334
translate chinese Li_NS_B_pussy_8a0fbccd:

    # Liza "Mmm... (I’m getting so excited!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:336
translate chinese Li_NS_B_pussy_00b57697:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:340
translate chinese Li_NS_B_pussy_6cba51e9:

    # MC "Oh yeah... This is good..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:342
translate chinese Li_NS_B_pussy_702aacac:

    # MC "Oh yeah... This is gonna be perfect... "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:343
translate chinese Li_NS_B_pussy_1c68c6f7_1:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:344
translate chinese Li_NS_B_pussy_c296f5bc:

    # MC "(Her bush is so soft to touch... Yazmin is a really lucky woman, that she gets to play with this body every night!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:348
translate chinese Li_NS_B_pussy_5adf89a0:

    # MC "(Damn, her pussy is beautiful. She hasn’t fucked any guys before - so it must be REALLY tight!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:349
translate chinese Li_NS_B_pussy_822ec66f:

    # MC "(I bet my cock would feel so good, inside there. I probably wouldn’t last very long, if she started riding me!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:350
translate chinese Li_NS_B_pussy_00b57697_1:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:354
translate chinese Li_NS_B_pussy_866d418a:

    # MC "*Sniff*"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:355
translate chinese Li_NS_B_pussy_b9ae0d7c:

    # MC "Mmm... (She smells so fucking sexy... God, I could just screw her right now!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:356
translate chinese Li_NS_B_pussy_04710e18:

    # MC "(Time to give her a little taste, as well!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:360
translate chinese Li_NS_B_pussy_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:361
translate chinese Li_NS_B_pussy_4e36f323:

    # Liza "Zzz... Ah... Mmm... Ohh..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:363
translate chinese Li_NS_B_pussy_95a2f289:

    # MC "(Oh shit! That must have been too sensitive! She’s started moaning!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:364
translate chinese Li_NS_B_pussy_356bb678:

    # MC "(If [Liza_name] doesn't wake up, then Yazmin certainly will! I better get out of here!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:366
translate chinese Li_NS_B_pussy_5f12f985:

    # Liza "(Holy shit, his tongue’s incredible!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:367
translate chinese Li_NS_B_pussy_87048438:

    # MC "(Maybe I should hold off for another night. I don’t think she’ll be able to keep pretending to be asleep if I eat her out like this. She’s already moaning pretty loudly!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:372
translate chinese Li_NS_B_pussy_27c98ec0:

    # Liza "Wow... I just had the most wonderful dream, Dear..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:373
translate chinese Li_NS_B_pussy_5c15ca60:

    # Yazmin "Uh huh... Zzz..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:374
translate chinese Li_NS_B_pussy_6fe43854:

    # Liza "*Yawn* Remind me to tell you about it tomorrow..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:376
translate chinese Li_NS_B_pussy_4bab8768:

    # Liza "Wow... That was... "
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:377
translate chinese Li_NS_B_pussy_09ba74da:

    # Yazmin "Hmm?"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:378
translate chinese Li_NS_B_pussy_74fd88c8:

    # Liza "[player_name] is really good with his tongue."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:379
translate chinese Li_NS_B_pussy_a8d90eb4:

    # Yazmin "Can’t be as good as me. Hehe! Goodnight dear."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:380
translate chinese Li_NS_B_pussy_49ec0cc9:

    # Liza "*Yawn* Night, Yazmin."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:388
translate chinese Li_NS_tits_00b57697:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:389
translate chinese Li_NS_tits_72a79b15:

    # MC "(Nice! I love Liza’s sheer lingerie tonight! I don’t even have to do anything and I can already see her nipples!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:391
translate chinese Li_NS_tits_40bfe6cb:

    # MC "(Okay, let’s see if I can slide this off without waking her...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:392
translate chinese Li_NS_tits_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:394
translate chinese Li_NS_tits_ab7939dc:

    # Liza "...zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:395
translate chinese Li_NS_tits_e7ecc236:

    # MC "(Easy does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:397
translate chinese Li_NS_tits_288ad4c3:

    # MC "(Awesome! God, her breasts are incredible! It looks like Liza is still in a deep sleep. I wonder if I can play with her nipples without waking her.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:398
translate chinese Li_NS_tits_00b57697_1:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:400
translate chinese Li_NS_tits_6debb865:

    # MC "Hehe..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:401
translate chinese Li_NS_tits_20fd4c2c:

    # Liza "Zzz... Mmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:403
translate chinese Li_NS_tits_ab1c58f6:

    # Liza "Hmmm.... Zzz... Yazmin... knock it off... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:405
translate chinese Li_NS_tits_4fe51b9f:

    # MC "(Heh, she thinks Yazmin is playing with her breasts right now!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:407
translate chinese Li_NS_tits_b8e6eeea:

    # MC "(It’d be a waste if I didn’t grope her funbags when they’re already on display!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:408
translate chinese Li_NS_tits_2f438e8b:

    # Yazmin "Zzz..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:410
translate chinese Li_NS_tits_33bce11e:

    # MC "(God, they’re so firm!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:411
translate chinese Li_NS_tits_94fa5552:

    # Liza "Ah... Mmm... Oh..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:412
translate chinese Li_NS_tits_bdedbbe8:

    # Liza "*Pant* Yazmin... Go to sleep... We can fool around tomorrow."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:414
translate chinese Li_NS_tits_87d19be7:

    # MC "(Uh oh... She’s waking up!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:415
translate chinese Li_NS_tits_ec10cbf0:

    # Liza "Mmm? Yazmin?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:417
translate chinese Li_NS_tits_d6e28705:

    # MC "*Whispered* Crap, crap, crap..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:418
translate chinese Li_NS_tits_b7b0065d:

    # MC "(I gotta get out of here.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:424
translate chinese Li_NS_tits_97c84b78:

    # MC "Hey Liza."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:426
translate chinese Li_NS_tits_a1b9420a:

    # Liza "*Yawn* [player_name]? Hmm... what time is it?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:428
translate chinese Li_NS_tits_2430d5b1:

    # MC "It’s the middle of the night. I was wondering if you wanted to do some roleplaying?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:430
translate chinese Li_NS_tits_26d2847c:

    # Liza "Uh huh... *Yawn* What are you thinking of?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:432
translate chinese Li_NS_tits_467e22bb:

    # MC "I was wondering if you’d like to try pretending to sleep while I played with your body?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:434
translate chinese Li_NS_tits_3ac334af:

    # Liza "Sure, why not? Just don’t wake Yazmin. She gets real cranky if she doesn’t get a full night’s rest."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:436
translate chinese Li_NS_tits_00b57697_2:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:437
translate chinese Li_NS_tits_72a79b15_1:

    # MC "(Nice! I love Liza’s sheer lingerie tonight! I don’t even have to do anything and I can already see her nipples!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:439
translate chinese Li_NS_tits_27a5d804:

    # MC "(Okay, if she’s pretending to sleep then she shouldn’t mind me slipping her dress off...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:440
translate chinese Li_NS_tits_d84968a5:

    # Liza "(Mmm, I wonder what he’s going to do to me?)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:441
translate chinese Li_NS_tits_1c68c6f7_1:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:443
translate chinese Li_NS_tits_ab7939dc_1:

    # Liza "...zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:444
translate chinese Li_NS_tits_e7ecc236_1:

    # MC "(Easy does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:446
translate chinese Li_NS_tits_e7b1afb9:

    # MC "(Awesome! God, her breasts are incredible! I wonder if she would like me playing with her nipples.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:447
translate chinese Li_NS_tits_00b57697_3:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:449
translate chinese Li_NS_tits_6debb865_1:

    # MC "Hehe..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:450
translate chinese Li_NS_tits_20fd4c2c_1:

    # Liza "Zzz... Mmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:451
translate chinese Li_NS_tits_513e3a2c:

    # Liza "(Oh, that feels nice!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:453
translate chinese Li_NS_tits_ab1c58f6_1:

    # Liza "Hmmm.... Zzz... Yazmin... knock it off... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:455
translate chinese Li_NS_tits_4fe51b9f_1:

    # MC "(Heh, she thinks Yazmin is playing with her breasts right now!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:457
translate chinese Li_NS_tits_b8e6eeea_1:

    # MC "(It’d be a waste if I didn’t grope her funbags when they’re already on display!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:458
translate chinese Li_NS_tits_2f438e8b_1:

    # Yazmin "Zzz..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:460
translate chinese Li_NS_tits_33bce11e_1:

    # MC "(God, they’re so firm!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:461
translate chinese Li_NS_tits_94fa5552_1:

    # Liza "Ah... Mmm... Oh..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:462
translate chinese Li_NS_tits_77b861bc:

    # Liza "(I should probably get some sleep now. I’ll give [player_name] a sign to stop.)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:463
translate chinese Li_NS_tits_bdedbbe8_1:

    # Liza "*Pant* Yazmin... Go to sleep... We can fool around tomorrow."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:465
translate chinese Li_NS_tits_148ea581:

    # MC "(Oh! I guess she’s giving me a sign that she’s done for the night.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:466
translate chinese Li_NS_tits_ec10cbf0_1:

    # Liza "Mmm? Yazmin?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:468
translate chinese Li_NS_tits_89138016:

    # MC "(I‘ll head home now. I can always come back another time to play with her body again.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:475
translate chinese Li_NS_titsjob_00b57697:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:476
translate chinese Li_NS_titsjob_cb599683:

    # MC "(Mmm, she’s so fucking hot.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:478
translate chinese Li_NS_titsjob_1ce7a9cc:

    # MC "(I think I’ll try rubbing my cock against her tits tonight.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:479
translate chinese Li_NS_titsjob_d88e2f30:

    # MC "(I just need to get her bra out of the way first...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:480
translate chinese Li_NS_titsjob_a9a90334:

    # Liza "Zzz... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:482
translate chinese Li_NS_titsjob_2a1fd616:

    # MC "(There we go... Slowly does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:483
translate chinese Li_NS_titsjob_40cc334f:

    # Liza "*Yawn* Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:485
translate chinese Li_NS_titsjob_893607f9:

    # MC "(Her breasts look incredible! I can’t wait to rub my dick all over them!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:486
translate chinese Li_NS_titsjob_0497613f:

    # MC "(Alright, here we go!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:488
translate chinese Li_NS_titsjob_16d78e46:

    # Liza "Zzz... *Snore* Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:489
translate chinese Li_NS_titsjob_b15aca04:

    # MC "(Awesome!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:491
translate chinese Li_NS_titsjob_35d30245:

    # MC "(Okay, here goes nothing... Let’s hope she’s in a deep enough sleep that my dick doesn’t end wake her!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:492
translate chinese Li_NS_titsjob_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:494
translate chinese Li_NS_titsjob_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:495
translate chinese Li_NS_titsjob_3a1fe6f6:

    # MC "(Her boobs are so soft!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:497
translate chinese Li_NS_titsjob_00d9141d:

    # MC "*Pant* Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:498
translate chinese Li_NS_titsjob_00b57697_1:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:500
translate chinese Li_NS_titsjob_bd1175a1:

    # MC "Hnnngg.... Oh"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:501
translate chinese Li_NS_titsjob_22f478bc:

    # MC "*Pant* Mmm... *Whispered* Fuck... Your breasts are amazing."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:503
translate chinese Li_NS_titsjob_00b57697_2:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:504
translate chinese Li_NS_titsjob_a0f8b2b5:

    # MC "*Pant* Hnnng... Oh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:506
translate chinese Li_NS_titsjob_0f751ab6:

    # MC "(I’m getting close. I’ll try thrusting my cock against her nipple until I finish!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:507
translate chinese Li_NS_titsjob_1c68c6f7_1:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:509
translate chinese Li_NS_titsjob_47371bdc:

    # MC "Hnnng... Ah! Hnnnngg... Shit... *Pant* Mmm... Fuck..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:511
translate chinese Li_NS_titsjob_5251f962:

    # Liza "Mmm... Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:513
translate chinese Li_NS_titsjob_57cd55a9:

    # MC "Ah... fuck... I’m gonna cum... Arrgh... Hnnngg!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:514
translate chinese Li_NS_titsjob_92c9324b:

    # Liza "Hmm?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:515
translate chinese Li_NS_titsjob_7e79ec2d:

    # MC "Hnnnggg! Ohhhh!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:525
translate chinese Li_NS_titsjob_d0790869:

    # MC "Argh! Ohh... *Pant* Ughhh!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:526
translate chinese Li_NS_titsjob_0a4fadfa:

    # MC "Ohhh *Pant* Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:528
translate chinese Li_NS_titsjob_51ff3dc3:

    # MC "*Pant* (That was incredible! I’ll sneak out now before she wakes up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:529
translate chinese Li_NS_titsjob_00b57697_3:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:536
translate chinese Li_NS_titsjob_97c84b78:

    # MC "Hey Liza."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:538
translate chinese Li_NS_titsjob_a1b9420a:

    # Liza "*Yawn* [player_name]? Hmm... what time is it?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:540
translate chinese Li_NS_titsjob_2430d5b1:

    # MC "It’s the middle of the night. I was wondering if you wanted to do some roleplaying?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:542
translate chinese Li_NS_titsjob_26d2847c:

    # Liza "Uh huh... *Yawn* What are you thinking of?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:544
translate chinese Li_NS_titsjob_467e22bb:

    # MC "I was wondering if you’d like to try pretending to sleep while I played with your body?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:546
translate chinese Li_NS_titsjob_3ac334af:

    # Liza "Sure, why not? Just don’t wake Yazmin. She gets real cranky if she doesn’t get a full night’s rest."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:549
translate chinese Li_NS_titsjob_00b57697_4:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:550
translate chinese Li_NS_titsjob_cb599683_1:

    # MC "(Mmm, she’s so fucking hot.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:552
translate chinese Li_NS_titsjob_1ce7a9cc_1:

    # MC "(I think I’ll try rubbing my cock against her tits tonight.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:553
translate chinese Li_NS_titsjob_d88e2f30_1:

    # MC "(I just need to get her bra out of the way first...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:554
translate chinese Li_NS_titsjob_a9a90334_1:

    # Liza "Zzz... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:556
translate chinese Li_NS_titsjob_2a1fd616_1:

    # MC "(There we go... Slowly does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:557
translate chinese Li_NS_titsjob_40cc334f_1:

    # Liza "*Yawn* Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:559
translate chinese Li_NS_titsjob_893607f9_1:

    # MC "(Her breasts look incredible! I can’t wait to rub my dick all over them!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:560
translate chinese Li_NS_titsjob_0497613f_1:

    # MC "(Alright, here we go!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:562
translate chinese Li_NS_titsjob_16d78e46_1:

    # Liza "Zzz... *Snore* Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:563
translate chinese Li_NS_titsjob_b15aca04_1:

    # MC "(Awesome!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:565
translate chinese Li_NS_titsjob_d6e285eb:

    # MC "(Okay, here we go! This is gonna feel amazing!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:566
translate chinese Li_NS_titsjob_1c68c6f7_2:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:568
translate chinese Li_NS_titsjob_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:569
translate chinese Li_NS_titsjob_3a1fe6f6_1:

    # MC "(Her boobs are so soft!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:571
translate chinese Li_NS_titsjob_00d9141d_1:

    # MC "*Pant* Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:572
translate chinese Li_NS_titsjob_00b57697_5:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:574
translate chinese Li_NS_titsjob_bd1175a1_1:

    # MC "Hnnngg.... Oh"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:575
translate chinese Li_NS_titsjob_22f478bc_1:

    # MC "*Pant* Mmm... *Whispered* Fuck... Your breasts are amazing."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:577
translate chinese Li_NS_titsjob_00b57697_6:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:578
translate chinese Li_NS_titsjob_a0f8b2b5_1:

    # MC "*Pant* Hnnng... Oh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:580
translate chinese Li_NS_titsjob_0f751ab6_1:

    # MC "(I’m getting close. I’ll try thrusting my cock against her nipple until I finish!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:581
translate chinese Li_NS_titsjob_1c68c6f7_3:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:583
translate chinese Li_NS_titsjob_47371bdc_1:

    # MC "Hnnng... Ah! Hnnnngg... Shit... *Pant* Mmm... Fuck..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:585
translate chinese Li_NS_titsjob_5251f962_1:

    # Liza "Mmm... Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:587
translate chinese Li_NS_titsjob_57cd55a9_1:

    # MC "Ah... fuck... I’m gonna cum... Arrgh... Hnnngg!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:588
translate chinese Li_NS_titsjob_92c9324b_1:

    # Liza "Hmm?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:589
translate chinese Li_NS_titsjob_7e79ec2d_1:

    # MC "Hnnnggg! Ohhhh!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:599
translate chinese Li_NS_titsjob_d0790869_1:

    # MC "Argh! Ohh... *Pant* Ughhh!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:600
translate chinese Li_NS_titsjob_0a4fadfa_1:

    # MC "Ohhh *Pant* Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:602
translate chinese Li_NS_titsjob_f500d36a:

    # MC "*Pant* (That was incredible! I’ll let Liza get some rest now.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:603
translate chinese Li_NS_titsjob_00b57697_7:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:611
translate chinese Li_NS_turn_label_2fbe6b7d:

    # MC "(I think I’ll try playing with her ass tonight. If I’m gonna do that though, I’m gonna need to flip her over first.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:613
translate chinese Li_NS_turn_label_bcb7f83e:

    # MC "(This is the risky part!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:616
translate chinese Li_NS_turn_label_80aaf2e8:

    # MC "*Whispered* Don’t wake up... Don’t wake up..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:618
translate chinese Li_NS_turn_label_00b57697:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:622
translate chinese Li_NS_turn_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:624
translate chinese Li_NS_turn_label_00b57697_1:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:626
translate chinese Li_NS_turn_label_360f9336:

    # MC "Phew... (Alright, that’s the hard part out of the way.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:631
translate chinese Li_NS_turn_label_97c84b78:

    # MC "Hey Liza."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:633
translate chinese Li_NS_turn_label_a1b9420a:

    # Liza "*Yawn* [player_name]? Hmm... what time is it?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:635
translate chinese Li_NS_turn_label_2430d5b1:

    # MC "It’s the middle of the night. I was wondering if you wanted to do some roleplaying?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:637
translate chinese Li_NS_turn_label_26d2847c:

    # Liza "Uh huh... *Yawn* What are you thinking of?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:639
translate chinese Li_NS_turn_label_467e22bb:

    # MC "I was wondering if you’d like to try pretending to sleep while I played with your body?"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:641
translate chinese Li_NS_turn_label_3ac334af:

    # Liza "Sure, why not? Just don’t wake Yazmin. She gets real cranky if she doesn’t get a full night’s rest."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:645
translate chinese Li_NS_turn_label_2fbe6b7d_1:

    # MC "(I think I’ll try playing with her ass tonight. If I’m gonna do that though, I’m gonna need to flip her over first.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:647
translate chinese Li_NS_turn_label_a0ae527e:

    # Liza "(Oh, I wonder what he’s going to do to me tonight! This is exciting!)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:649
translate chinese Li_NS_turn_label_80aaf2e8_1:

    # MC "*Whispered* Don’t wake up... Don’t wake up..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:651
translate chinese Li_NS_turn_label_00b57697_2:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:655
translate chinese Li_NS_turn_label_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:657
translate chinese Li_NS_turn_label_00b57697_3:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:659
translate chinese Li_NS_turn_label_360f9336_1:

    # MC "Phew... (Alright, that’s the hard part out of the way.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:666
translate chinese Li_NS_ass_450cb081:

    # MC "Mmm... (Her ass looks incredible. I wonder if I’ll be able to stick my dick in it tonight without waking her?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:668
translate chinese Li_NS_ass_a9a90334:

    # Liza "Zzz... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:672
translate chinese Li_NS_ass_29a93f77:

    # MC "(I’ll play it safe to start and just rub my dick against her buttcheeks for the meantime...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:676
translate chinese Li_NS_ass_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:678
translate chinese Li_NS_ass_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:682
translate chinese Li_NS_ass_af7b99b7:

    # MC "*Pant* Ohh... *Whispered* God... I love your fat ass."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:684
translate chinese Li_NS_ass_00b57697:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:688
translate chinese Li_NS_ass_4a488bec:

    # MC "Ohh.... *Pant* Hnnng..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:692
translate chinese Li_NS_ass_51ef377c:

    # MC "(Her ass is so squeezable!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:694
translate chinese Li_NS_ass_20fd4c2c:

    # Liza "Zzz... Mmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:698
translate chinese Li_NS_ass_435c972c:

    # MC "(Fuck it. I can’t take it anymore. I have to know what it feels like to slide my dick in her ass.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:701
translate chinese Li_NS_ass_17e30b62:

    # MC "(I bet she’s super tight down there.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:705
translate chinese Li_NS_ass_66044a87:

    # MC "(Mmm, your ass is just begging to be fucked right now. Isn’t it?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:707
translate chinese Li_NS_ass_00b57697_1:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:711
translate chinese Li_NS_ass_9ca74690:

    # MC "(I wonder if Yazmin ever fucks your ass with a strap-on? Probably not. I reckon you’re still a virgin here.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:713
translate chinese Li_NS_ass_6e1b6bf5:

    # Liza "*Snore* Hmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:717
translate chinese Li_NS_ass_2af1bbd3:

    # MC "Hnnng... Ohhh my God..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:719
translate chinese Li_NS_ass_140ab758:

    # MC "(Her ass is heavenly! I’ve barely even got the tip in and it already feels so fucking good!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:721
translate chinese Li_NS_ass_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:725
translate chinese Li_NS_ass_22a1474e:

    # MC "Hnnnggg... *Pant* Ohh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:727
translate chinese Li_NS_ass_65f24403:

    # MC "*Whispered* Fuck... Shit! Arrgh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:729
translate chinese Li_NS_ass_4bd33c3f:

    # MC "(Oh crap! I’m cumming already! Shit, I didn’t mean to creampie her asshole!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:731
translate chinese Li_NS_ass_c89ec560:

    # MC "*Pant* Hnnng.... Ohhh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:741
translate chinese Li_NS_ass_36ed7852:

    # MC "(Oh crap, oh crap... That is not good... I better leg it before she wakes up!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:743
translate chinese Li_NS_ass_92a85420:

    # Liza "Mmm... Hmm? What’s going on?"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:751
translate chinese Li_NS_ass_e3a2abbe:

    # MC "Mmm... (Her ass looks incredible. I wonder if she’ll let me stick my dick in it tonight?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:753
translate chinese Li_NS_ass_a9a90334_1:

    # Liza "Zzz... *Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:757
translate chinese Li_NS_ass_29a93f77_1:

    # MC "(I’ll play it safe to start and just rub my dick against her buttcheeks for the meantime...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:761
translate chinese Li_NS_ass_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:763
translate chinese Li_NS_ass_1c68c6f7_1:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:767
translate chinese Li_NS_ass_af7b99b7_1:

    # MC "*Pant* Ohh... *Whispered* God... I love your fat ass."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:769
translate chinese Li_NS_ass_00b57697_2:

    # Liza "Zzz..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:773
translate chinese Li_NS_ass_4a488bec_1:

    # MC "Ohh.... *Pant* Hnnng..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:777
translate chinese Li_NS_ass_51ef377c_1:

    # MC "(Her ass is so squeezable!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:779
translate chinese Li_NS_ass_20fd4c2c_1:

    # Liza "Zzz... Mmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:783
translate chinese Li_NS_ass_435c972c_1:

    # MC "(Fuck it. I can’t take it anymore. I have to know what it feels like to slide my dick in her ass.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:786
translate chinese Li_NS_ass_17e30b62_1:

    # MC "(I bet she’s super tight down there.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:790
translate chinese Li_NS_ass_66044a87_1:

    # MC "(Mmm, your ass is just begging to be fucked right now. Isn’t it?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:792
translate chinese Li_NS_ass_5305e5cf:

    # Liza "(Mmm... Yes please! I hope he tries that...)"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:796
translate chinese Li_NS_ass_9ca74690_1:

    # MC "(I wonder if Yazmin ever fucks your ass with a strap-on? Probably not. I reckon you’re still a virgin here.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:798
translate chinese Li_NS_ass_6e1b6bf5_1:

    # Liza "*Snore* Hmm..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:802
translate chinese Li_NS_ass_2af1bbd3_1:

    # MC "Hnnng... Ohhh my God..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:804
translate chinese Li_NS_ass_140ab758_1:

    # MC "(Her ass is heavenly! I’ve barely even got the tip in and it already feels so fucking good!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:806
translate chinese Li_NS_ass_9944bb22_1:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:810
translate chinese Li_NS_ass_22a1474e_1:

    # MC "Hnnnggg... *Pant* Ohh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:812
translate chinese Li_NS_ass_65f24403_1:

    # MC "*Whispered* Fuck... Shit! Arrgh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:814
translate chinese Li_NS_ass_4bd33c3f_1:

    # MC "(Oh crap! I’m cumming already! Shit, I didn’t mean to creampie her asshole!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:816
translate chinese Li_NS_ass_c89ec560_1:

    # MC "*Pant* Hnnng.... Ohhh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:826
translate chinese Li_NS_ass_02c46c7a:

    # MC "(Oh crap, oh crap... That is not good...I hope she’s not too angry...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Li_NS_s.rpy:828
translate chinese Li_NS_ass_ffdb3fbc:

    # Liza "(Whoops. Looks like [player_name] couldn’t last too long! That’s a shame, I was kinda hoping he’d actually get the whole thing in before he shot his load.)"
    Liza ""

