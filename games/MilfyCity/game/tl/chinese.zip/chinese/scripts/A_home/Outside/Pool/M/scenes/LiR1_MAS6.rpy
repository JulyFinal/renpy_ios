﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:45
translate chinese LiR1_MAS6_label_dd0dad13:

    # MC "(Cool! Looks like [Liza_name] is finally getting some use out of her swimming pool, now that I’ve finished cleaning it up for her.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:46
translate chinese LiR1_MAS6_label_1709631a:

    # MC "(She looks incredible in that bikini. I should go over and say hello.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:50
translate chinese LiR1_MAS6_label_c8fd07f2:

    # MC "Hey, Aunt Liza! How are you?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:52
translate chinese LiR1_MAS6_label_fe146c08:

    # MC "Hey, Liza! How are you?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:53
translate chinese LiR1_MAS6_label_c1e541ee:

    # Liza "Oh! Hi, [player_name]. I decided to take a quick dip in the pool today. It’s so nice just being able to use it any time you want, now that it has been properly cleaned."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:54
translate chinese LiR1_MAS6_label_1ef7f923:

    # Liza "Thanks so much for your hard work!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:55
translate chinese LiR1_MAS6_label_6dc9c68d:

    # MC "It was nothing! I’m just glad that you’re enjoying it!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:59
translate chinese LiR1_MAS6_label_e2c38d0e:

    # Liza "What brings you over today, then?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:60
translate chinese LiR1_MAS6_label_a6203f41:

    # MC "I was just passing through the neighbourhood, and thought I’d drop by to say hello."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:61
translate chinese LiR1_MAS6_label_f83630a4:

    # Liza "Aww, that’s nice. I’m afraid that Yazmin isn’t around at the minute. Can I get you something to drink? A cola perhaps?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:65
translate chinese LiR1_MAS6_label_53024951:

    # MC "I’m good, [Liza_name], thanks for offering though. Is that you done in the pool for today?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:66
translate chinese LiR1_MAS6_label_d93e9626:

    # Liza "No, I’m just going to take a short break, then I’ll be back in."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:67
translate chinese LiR1_MAS6_label_996afca7:

    # MC "I have to say - you’re looking very well toned there!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:71
translate chinese LiR1_MAS6_label_4823752f:

    # Liza "Yeah, I’ve been practicing diving and doing laps. I used to be a competitive swimmer in college."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:72
translate chinese LiR1_MAS6_label_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:73
translate chinese LiR1_MAS6_label_04675643:

    # Liza "Oh yeah, almost qualified for the national championships! "
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:74
translate chinese LiR1_MAS6_label_6813a4a9:

    # MC "Wow! What happened? Why didn’t you qualify?"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:75
translate chinese LiR1_MAS6_label_9b1afe7c:

    # Liza "(I can’t tell him the real reason...)"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:76
translate chinese LiR1_MAS6_label_9febb726:

    # Liza "(I missed the tryouts because Yazmin had me tied up in the gym showers eating my pussy out for several hours straight.)"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:77
translate chinese LiR1_MAS6_label_73cc3584:

    # Liza "(The only reason I forgave her was because, she’s so damn good with that tongue!)"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:78
translate chinese LiR1_MAS6_label_7dcf20f0:

    # Liza "I... uh... came fourth in the qualifiers. Only the top three got through."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:79
translate chinese LiR1_MAS6_label_34b4fcc3:

    # MC "Aww... Sorry to hear that."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:83
translate chinese LiR1_MAS6_label_2253b948:

    # Liza "Say, why don’t you join me for a few laps?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:84
translate chinese LiR1_MAS6_label_dc00daac:

    # MC "Sure! Why not? Umm... I don’t have any swimming trunks though."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:85
translate chinese LiR1_MAS6_label_0b709203:

    # Liza "Don’t worry about it - just take your pants off. It’ll be fine."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:86
translate chinese LiR1_MAS6_label_c517a391:

    # MC "Okay, [Liza_name]!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:90
translate chinese LiR1_MAS6_label_d5980217:

    # MC "(Wow! She’s good!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:91
translate chinese LiR1_MAS6_label_7c297b27:

    # MC "(It’s a shame that she didn’t qualify. She’s clearly a natural at this kinda thing!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:95
translate chinese LiR1_MAS6_label_c4b7366f:

    # MC "(And just look at how perfect her ass is! It’s the epitome of a bubble butt!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:96
translate chinese LiR1_MAS6_label_700e92a6:

    # MC "(I could squeeze that thing for hours and never get bored! Yazmin is a REALLY lucky woman to get to sleep her Liza every single night!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:103
translate chinese LiR1_MAS6_label_717d17d8:

    # Liza "Well? Are you coming in or not?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:104
translate chinese LiR1_MAS6_label_df5d2bdc:

    # MC "Hang on! I’m coming now!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:108
translate chinese LiR1_MAS6_label_e4c4165c:

    # MC "(Hopefully, I won’t get a boner, when I’m in the water with her...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:109
translate chinese LiR1_MAS6_label_e5634773:

    # MC "(I’ll be swimming and moving around a lot. The chances of me getting hard, are VERY slim! It’ll be fine!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:110
translate chinese LiR1_MAS6_label_1947214c:

    # MC "(I just need to calm down and relax. That’s all!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:114
translate chinese LiR1_MAS6_label_2f72700c:

    # MC "Geronimo!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:115
translate chinese LiR1_MAS6_label_9e30042c:

    # Liza "Haha!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:118
translate chinese LiR1_MAS6_label_9ee0bfab:

    # "*SPLASH*"
    ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:122
translate chinese LiR1_MAS6_label_90b9772d:

    # MC "(Oh cool! I’ve got a great view of her bikini bottoms down here!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:123
translate chinese LiR1_MAS6_label_a1ee3f57:

    # MC "(I don’t think she’ll be suspicious if I spend another few seconds lingering down here after my dive.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:127
translate chinese LiR1_MAS6_label_98762370:

    # MC "(That bra is so tight, that I can almost see the outline of [Liza_name]’s nipples!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:129
translate chinese LiR1_MAS6_label_dad5ae9c:

    # MC "(That bra is so tight that I can almost see the outline of her nipples!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:130
translate chinese LiR1_MAS6_label_b16b7089:

    # MC "(God, her tits are just incredible! I could stare at them for hours!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:131
translate chinese LiR1_MAS6_label_b6404b40:

    # MC "(I better get back up, before she starts wondering what’s taking me so long!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:135
translate chinese LiR1_MAS6_label_d8a675df:

    # Liza "It’s a scorcher of a day - you must be enjoying the cool water."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:136
translate chinese LiR1_MAS6_label_aa53c6ec:

    # MC "Yeah, it’s great. Thanks for letting me use your pool."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:137
translate chinese LiR1_MAS6_label_ac9f6d9d:

    # Liza "Don’t think anything of it! You’re the one who helps keep it clean, after all! You might as well enjoy the fruits of your labour."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:138
translate chinese LiR1_MAS6_label_1dd26975:

    # Liza "C’mon! Let’s go for a swim! I’m aiming to burn another two hundred calories today!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:139
translate chinese LiR1_MAS6_label_c64df325:

    # MC "You don’t need to be burning calories - you’re looking great as you are."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:143
translate chinese LiR1_MAS6_label_578fa356:

    # Liza "You’re very kind, but I’ve got to keep in shape. Let’s get started!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:144
translate chinese LiR1_MAS6_label_9d51146f:

    # MC "Sure! I’m right behind you."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:148
translate chinese LiR1_MAS6_label_629178b0:

    # MC "(I was hoping to catch up to her, and get a better view of that ass.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:149
translate chinese LiR1_MAS6_label_b206f4bd:

    # MC "(She’s WAY too fast though - I never imagined she’d be THIS quick in the water.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:150
translate chinese LiR1_MAS6_label_e8b66420:

    # MC "(Then again, she DID use to be a near-professional swimmer - so I guess it makes sense.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:154
translate chinese LiR1_MAS6_label_6bb792da:

    # MC "(Dammit - I’m gonna have to swim EXTREMELY hard if I’m gonna catch her.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:155
translate chinese LiR1_MAS6_label_f8744e84:

    # MC "(Alright, let’s take a deep breath - and push myself to my limit.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:156
translate chinese LiR1_MAS6_label_239e756f:

    # MC "(I’m a man, and I’m much younger than she is, I might be able to gain on her!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:160
translate chinese LiR1_MAS6_label_5f100a8e:

    # MC "(Yes! Almost made it!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:162
translate chinese LiR1_MAS6_label_6afc7b66:

    # MC "(Damn, just look at how that tight thong rides up between her thighs! I’d love to pull those panties aside and bury my cock deep in her lesbian pussy.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:164
translate chinese LiR1_MAS6_label_2bddff35:

    # MC "(Damn, just look at how that tight thong rides up between her thighs! I’d love to pull those panties aside and bury my cock deep in her wet pussy!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:168
translate chinese LiR1_MAS6_label_0f2b7522:

    # MC "(I can almost see the outline of her tight little asshole too!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:169
translate chinese LiR1_MAS6_label_528efa21:

    # MC "(It’d feel amazing wrapped all snugly around my cock. I’d give anything to fuck her doggystyle.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:170
translate chinese LiR1_MAS6_label_4dfd4f60:

    # MC "(Uh oh! I think I’ve gotten a bit too close.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:174
translate chinese LiR1_MAS6_label_b81ee79a:

    # "*Bump*"
    ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:175
translate chinese LiR1_MAS6_label_e18c8618:

    # Liza "Huh?!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:176
translate chinese LiR1_MAS6_label_c42ad36b:

    # MC "Oof!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:180
translate chinese LiR1_MAS6_label_a874ddfb:

    # MC "(Dammit! She slowed down, and I face planted myself, right between her buttcheeks!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:181
translate chinese LiR1_MAS6_label_f47e0ab5:

    # MC "(Fuck! She’s gonna think I did this on purpose!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:182
translate chinese LiR1_MAS6_label_cdc794e5:

    # Liza "Whoops!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:186
translate chinese LiR1_MAS6_label_130c5339:

    # Liza "Sorry about that! I slowed down too fast, there. Did you hurt yourself?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:187
translate chinese LiR1_MAS6_label_b9375ac6:

    # MC "(Huh? She thinks it was her fault, that I bumped into her.)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:188
translate chinese LiR1_MAS6_label_dae22959:

    # MC "Uh... Y-Yeah, I’m fine. I didn’t hit anywhere, hard."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:189
translate chinese LiR1_MAS6_label_c8788675:

    # Liza "It isn’t sore, is it?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:190
translate chinese LiR1_MAS6_label_dd637733:

    # MC "N-No - just a little bit. I’m good - really."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:194
translate chinese LiR1_MAS6_label_10d56cfb:

    # Liza "Oh! Good to hear - My sister would kill me, if I hurt her son!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:196
translate chinese LiR1_MAS6_label_d5055067:

    # Liza "Oh! Good to hear, I was worried I’d actually hurt you there!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:197
translate chinese LiR1_MAS6_label_e01c634f:

    # Liza "C’mere, let me give you a hug and make it all better."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:198
translate chinese LiR1_MAS6_label_170e5469:

    # MC "(Uh oh... There’s no way I’m gonna be able to hug her, without getting a huge boner!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:202
translate chinese LiR1_MAS6_label_540d9b2b:

    # MC "It’s- ah- I’m okay! Really! Don’t worry about me!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:204
translate chinese LiR1_MAS6_label_5819709a:

    # Liza "Aww c’mon... you’re never too old to get a cuddle from your auntie. Don’t be embarrassed, it’s not like any of your friends are around to see you."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:206
translate chinese LiR1_MAS6_label_31b67d10:

    # Liza "Aww, c’mon... you’re never too old to get a cuddle! Don’t be embarrassed, it’s not like any of your friends are around to see you."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:208
translate chinese LiR1_MAS6_label_4f497db3:

    # MC "I... uh..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:209
translate chinese LiR1_MAS6_label_4af209c8:

    # MC "(Oh shit... I can feel it getting hard!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:213
translate chinese LiR1_MAS6_label_75d87347:

    # Liza "See? There we go. It’s not so bad after all, is it?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:214
translate chinese LiR1_MAS6_label_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:215
translate chinese LiR1_MAS6_label_b69ff44d:

    # MC "Y-Yeah, all... g-good."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:216
translate chinese LiR1_MAS6_label_cd095c58:

    # Liza "You seem a little anxious. Is everything okay?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:220
translate chinese LiR1_MAS6_label_287d30a3:

    # MC "(Dammit! I’m rock hard right now! Hopefully she won't feel it...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:221
translate chinese LiR1_MAS6_label_3cc428e6:

    # MC "Y-Yeah, I’m just... maybe a little warm... it’s a really hot day."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:222
translate chinese LiR1_MAS6_label_6f2afdc5:

    # MC "In fact, I’m gonna leave now and get myself a drink..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:226
translate chinese LiR1_MAS6_label_7aaa5722:

    # Liza "Hey! Don’t you go yet - something’s up!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:227
translate chinese LiR1_MAS6_label_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:228
translate chinese LiR1_MAS6_label_8c83d1fb:

    # MC "(She’s right, there! Something is definitely up...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:232
translate chinese LiR1_MAS6_label_2f50e5d3:

    # Liza "Are you hiding something from me?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:233
translate chinese LiR1_MAS6_label_a5e718c2:

    # MC "Ye-No! No, I’m not!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:234
translate chinese LiR1_MAS6_label_62f8f5da:

    # Liza "What have you got there?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:240
translate chinese LiR1_MAS6_label_88ac8da7:

    # MC "No! Wait!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:241
translate chinese LiR1_MAS6_label_00e6ab4b:

    # Liza "Oh, my God!"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:242
translate chinese LiR1_MAS6_label_4b1eb919:

    # MC "(Fuck...)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:246
translate chinese LiR1_MAS6_label_a36f6a4b:

    # Liza "(He’s... erect! Oh, my God...)"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:247
translate chinese LiR1_MAS6_label_06e4bf9a:

    # MC "(I should have worn proper swimming trunks into the pool. My boxer shorts are too loose! They’ve just slipped down!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:248
translate chinese LiR1_MAS6_label_3b9b84c0:

    # MC "(Now she’s seen that I’ve got a boner, from her hugging me. Fucking fantastic..!)"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:252
translate chinese LiR1_MAS6_label_91e26a0e:

    # MC "[Liza_name]! I’m so, so sorry!"
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:253
translate chinese LiR1_MAS6_label_2b169a71:

    # MC "When you hugged me, and your... chest was pressed up against me, I just..."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:254
translate chinese LiR1_MAS6_label_1a7d0092:

    # MC "I’m sorry, it’s just a reaction I have to every woman."
    MC ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:255
translate chinese LiR1_MAS6_label_c350b718:

    # Liza "..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:259
translate chinese LiR1_MAS6_label_11fc9b8d:

    # Liza "I guess you are a young man..."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:260
translate chinese LiR1_MAS6_label_b49a30dd:

    # Liza "Sorry for prying, I shouldn’t have pushed it once you tried to hide it. That was my fault."
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:261
translate chinese LiR1_MAS6_label_6e96bf27:

    # Liza "Can we just agree to NEVER talk about this again?"
    Liza ""

# game/scripts/A_home/Outside/Pool/M/scenes/LiR1_MAS6.rpy:262
translate chinese LiR1_MAS6_label_4588af1c:

    # MC "Y-Yeah, I think that’s a good idea."
    MC ""

