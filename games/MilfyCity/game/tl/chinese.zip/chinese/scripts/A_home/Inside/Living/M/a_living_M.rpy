﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:39
translate chinese a_living_M1_80da6a6d:

    # MC "(I shouldn't go in there.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:59
translate chinese a_living_M1_aeb91391:

    # MC "(It's locked.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:61
translate chinese a_living_M1_e0605670:

    # MC "(It's locked. Maybe, I should look for someone around?)"
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:121
translate chinese a_living_M1_locked_967e6950:

    # MC "(Okay, here goes nothing... Let’s hope this spare key works...)"
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:123
translate chinese a_living_M1_locked_54b6842e:

    # MC "(Okay, I’ve got the spare key. Liza and Yazim both said they were up for some sleep-play. Let’s see how this goes.) "
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:128
translate chinese a_living_M1_locked_b9b8e06d:

    # "*Creeeaaak*"
    ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:134
translate chinese a_living_M1_locked_2486d862:

    # MC "(Perfect!)"
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:135
translate chinese a_living_M1_locked_9e3a217c:

    # MC "(The hinges are a little loud - but at least I’m in now.)"
    MC ""

# game/scripts/A_home/Inside/Living/M/a_living_M.rpy:142
translate chinese a_living_M1_locked_1778adac:

    # MC "(It's locked. I need a key to go inside.)"
    MC ""

