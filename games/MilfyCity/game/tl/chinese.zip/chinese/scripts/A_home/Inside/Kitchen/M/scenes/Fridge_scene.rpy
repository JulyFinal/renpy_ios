﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Kitchen/M/scenes/Fridge_scene.rpy:14
translate chinese fridge_scene_label2_39c48e53:

    # MC "(Nice! The beer is cold. It will be relief in that hot weather.)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/Fridge_scene.rpy:16
translate chinese fridge_scene_label2_a5f85ff8:

    # MC "(Okay... Done! Let's go back to them.)"
    MC ""

