﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:32
translate chinese LiR1_MAS5_label_91a14666:

    # Yazmin "Oh! I didn’t hear you come in, [player_name]. How’s it going?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:33
translate chinese LiR1_MAS5_label_f6439646:

    # MC "(Holy fuck! She’s practically naked! Is she not worried about me seeing her like this?!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:34
translate chinese LiR1_MAS5_label_48de8432:

    # MC "I- uh... You’re... um... good... Do you want me to... go?"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:38
translate chinese LiR1_MAS5_label_3d3495d0:

    # Yazmin "Ooooh, are you all flustered because I’m in my dressing gown?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:39
translate chinese LiR1_MAS5_label_f2fe739a:

    # Yazmin "That’s really cute. I never took you to be the shy type."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:41
translate chinese LiR1_MAS5_label_1e52ff6f:

    # Yazmin "*Whispered* Especially after I caught you perving on your auntie, the other day."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:43
translate chinese LiR1_MAS5_label_10e110fd:

    # Yazmin "*Whispered* Especially after I caught you perving on Liza the other day."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:44
translate chinese LiR1_MAS5_label_6cba33bc:

    # MC "Shush! She’s sitting right behind me..."
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:48
translate chinese LiR1_MAS5_label_7b8cceed:

    # Yazmin "Hehe... I know."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:49
translate chinese LiR1_MAS5_label_db77de63:

    # Yazmin "Good morning, Honey!"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:50
translate chinese LiR1_MAS5_label_6bdb44ea:

    # Liza "Hey, Yazmin - I see you’ve finally finished your shower. You’ll have to try and be quicker - our water bill was through the roof last month!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:51
translate chinese LiR1_MAS5_label_d8ae545f:

    # Yazmin "I know. I know."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:56
translate chinese LiR1_MAS5_label_2642e417:

    # Liza "And speaking of water - my nephew has come over to tidy up our pool again, for us."
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:58
translate chinese LiR1_MAS5_label_3e6e41b5:

    # Liza "And speaking of water - [player_name] has come over to tidy up our pool again, for us."
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:59
translate chinese LiR1_MAS5_label_6bee0f2d:

    # Yazmin "Yeah, he was just telling me that. He’s such a good, sweet man."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:60
translate chinese LiR1_MAS5_label_c6b14c51:

    # Liza "Do you fancy going out, later tonight?"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:61
translate chinese LiR1_MAS5_label_fe415118:

    # Yazmin "Maybe. What were you thinking? Dinner or drinks?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:65
translate chinese LiR1_MAS5_label_824a31e4:

    # MC "(Huh?! She just grabbed my crotch!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:66
translate chinese LiR1_MAS5_label_9576a7cf:

    # MC "(This is so fucking dangerous! [Liza_name] is sitting literally a few metres away!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:67
translate chinese LiR1_MAS5_label_3c037f1c:

    # Liza "I’m in the mood for pasta... or maybe Indian. I don’t know! It’s so hard, choosing. Can’t you just pick a place for us?"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:68
translate chinese LiR1_MAS5_label_fb87f82e:

    # Yazmin "Oh, come on! Is it really THAT HARD to choose a place to eat?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:69
translate chinese LiR1_MAS5_label_d4d1e3a5:

    # Liza "It is! I’ll pick a place that you don’t like, and then you’ll moan about it for the next week!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:73
translate chinese LiR1_MAS5_label_2c346c53:

    # Yazmin "How about you, [player_name]? Do you think it’s HARD?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:74
translate chinese LiR1_MAS5_label_2ccae577:

    # MC "Ahh.... um... wh-what?"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:75
translate chinese LiR1_MAS5_label_cfe1e783:

    # Yazmin "Do you think it’s hard to choose a place to eat..?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:76
translate chinese LiR1_MAS5_label_309fcadd:

    # MC "Er... sometimes. I don't really want to get between you guys."
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:82
translate chinese LiR1_MAS5_label_41737bb0:

    # Yazmin "Hmm... of course. But, if your mother picked a place for you to eat and you didn’t like it. Would you be the type to MOAN about it?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:84
translate chinese LiR1_MAS5_label_afe1e2a4:

    # Yazmin "Hmm... of course. But, if your date picked a place for you to eat and you didn’t like it. Would you be the type to MOAN about it?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:85
translate chinese LiR1_MAS5_label_0f242e1c:

    # MC "(Fuck... she’s teasing me, while [Liza_name]’s not looking! I’m getting rock hard right now!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:86
translate chinese LiR1_MAS5_label_a98ac518:

    # MC "I... uh... would probably just keep quiet and say I... ah... liked the food to keep my date happy."
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:90
translate chinese LiR1_MAS5_label_742f4ab2:

    # Liza "See! That’s the spirit! Go and pick an Indian or an Italian place. I don’t care which one!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:91
translate chinese LiR1_MAS5_label_0e7735aa:

    # Liza "Make sure to do it soon, before they all book-up and we can’t get a seat anywhere! Remember our last anniversary?"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:92
translate chinese LiR1_MAS5_label_21e886ba:

    # Yazmin "Ugh! Fine! I’ll go online and book a place soon."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:96
translate chinese LiR1_MAS5_label_20d023ce:

    # Yazmin "I just want to stand and stretch my legs, for a while - I’m still a bit STIFF... after sleeping in late."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:97
translate chinese LiR1_MAS5_label_d8cffd5c:

    # Yazmin "Do you ever get STIFF, after lying the wrong way in bed, [player_name]?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:98
translate chinese LiR1_MAS5_label_b5751f53:

    # MC "(Holy fuck... she’s unzipped my jeans now!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:99
translate chinese LiR1_MAS5_label_91938dda:

    # MC "N-Not very... mmm... often... ah..."
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:103
translate chinese LiR1_MAS5_label_b7d33063:

    # Yazmin "I find, a great way to get rid of the stiffness is to just... massage it out."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:105
translate chinese LiR1_MAS5_label_ae7f2a1b:

    # Yazmin "Your auntie is exceptional at massaging - you should feel how soft her hands are."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:107
translate chinese LiR1_MAS5_label_ffc8d749:

    # Yazmin "Liza is exceptional at giving massages - you should feel how soft her hands are."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:111
translate chinese LiR1_MAS5_label_301ecf12:

    # Liza "Aww, that’s so sweet. Your hands are extremely soft too, Dear!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:112
translate chinese LiR1_MAS5_label_efb51ca8:

    # MC "(Oh yeah, there’s no doubting that fact, right now! Yazmin’s hands feel amazing, against my cock!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:116
translate chinese LiR1_MAS5_label_6c4077b5:

    # Yazmin "So, [player_name], tell me - have you got any BIG plans, for today?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:117
translate chinese LiR1_MAS5_label_9aacacf2:

    # Yazmin "Or were you just COMING over to clean our pool for us?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:118
translate chinese LiR1_MAS5_label_2af022c4:

    # MC "*Gasp* N-No big plans, ohh..."
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:120
translate chinese LiR1_MAS5_label_51757f36:

    # MC "(Fuck, if [Liza_name] catches me right now, she’ll either tell [Mom_name] or murder me! I’m not sure which is worse! I have to keep my voice down.)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:122
translate chinese LiR1_MAS5_label_d1c8e7f2:

    # MC "(Fuck, if she catches me right now, she’ll murder me! God - it would be so embarrassing if she told Linda about this! I have to keep my voice down.) "
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:126
translate chinese LiR1_MAS5_label_4e970bce:

    # Yazmin "*Whispered* I’ve got a present here for you, [player_name]."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:128
translate chinese LiR1_MAS5_label_6c83e74d:

    # MC "*Whispered* N-No... my aunt is sitting LITERALLY over there!"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:130
translate chinese LiR1_MAS5_label_f29bc2e7:

    # MC "*Whispered* N-No... Liza is sitting LITERALLY over there!"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:131
translate chinese LiR1_MAS5_label_5ab65ed6:

    # Yazmin "*Whispered* I guess I should just tell her about you spying on her then."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:132
translate chinese LiR1_MAS5_label_90acf90a:

    # Yazmin "Liza?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:136
translate chinese LiR1_MAS5_label_2070d021:

    # Liza "Yes, Dear?"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:137
translate chinese LiR1_MAS5_label_531871a2:

    # MC "*Whispered* W-Wait!"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:138
translate chinese LiR1_MAS5_label_b0e04ef6:

    # Yazmin "Oh! It’s okay, nevermind. I found, what I was looking for."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:139
translate chinese LiR1_MAS5_label_19f245e7:

    # Yazmin "*Whispered* I want you to stay very still while I slip your cock between my thighs."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:143
translate chinese LiR1_MAS5_label_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:145
translate chinese LiR1_MAS5_label_e78723ca:

    # Yazmin "*Whispered* Perfect... After I caught you the other day I got to wondering - could it be possible that my pervy little nephew wants to fuck an older woman?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:147
translate chinese LiR1_MAS5_label_ac4f82f3:

    # Yazmin "*Whispered* Perfect... After I caught you the other day I got to wondering - could it be possible that this little perv wants to fuck an older woman?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:148
translate chinese LiR1_MAS5_label_7eb13cd9:

    # MC "(She’s soaking wet, right now! I can feel her pussy, rubbing up against my cock.)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:152
translate chinese LiR1_MAS5_label_14417167:

    # Yazmin "*Whispered* Yes, you’re sooo hard right now. Aren’t you?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:153
translate chinese LiR1_MAS5_label_f7b9da1e:

    # Yazmin "*Whispered* You just couldn’t resist spying on my wife while she was getting changed, could you?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:154
translate chinese LiR1_MAS5_label_1813764e:

    # Yazmin "*Whispered* In fact, you probably wank yourself off thinking about us when you’re lying in bed or taking a bath. Don’t you?"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:158
translate chinese LiR1_MAS5_label_ab6f043a:

    # Yazmin "*Whispered* I know guys your age like the back of my hand. I know exactly how you think, what you fantasise about, who you dream of fucking."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:159
translate chinese LiR1_MAS5_label_e382b775:

    # Yazmin "*Whispered* Well, let me tell you a little fantasy of mine too. I swing both ways, it doesn't matter to me if you’ve got a pussy or a cock."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:160
translate chinese LiR1_MAS5_label_5cf3e20c:

    # Yazmin "*Whispered* Someday in the near future, I’m going to feel that cock of yours, buried deep inside me. I’ll ride you so hard that you won’t last a minute."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:161
translate chinese LiR1_MAS5_label_1a149699:

    # MC "(Holy shit... Yazmin is totally into me!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:162
translate chinese LiR1_MAS5_label_b898042e:

    # Yazmin "*Whispered* And then when you’re..."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:166
translate chinese LiR1_MAS5_label_e40d08b3:

    # Liza "*Ahem*"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:167
translate chinese LiR1_MAS5_label_4ebe7b96:

    # MC "(Oh fuck! [Liza_name]’s caught us!)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:171
translate chinese LiR1_MAS5_label_3c5f5ac1:

    # Yazmin "Liza! I was-"
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:172
translate chinese LiR1_MAS5_label_2ed1b5e5:

    # Liza "I know EXACTLY what you were doing!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:173
translate chinese LiR1_MAS5_label_93164d5d:

    # MC "(Oh shit... Fuck...)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:174
translate chinese LiR1_MAS5_label_17171962:

    # Liza "You’re procrastinating! I told you to book the restaurant for tonight like ten minutes ago!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:178
translate chinese LiR1_MAS5_label_de8174f0:

    # Yazmin "Uh, y-yeah! I was procrastinating. Sorry. My bad. I’ll go and book us a table now."
    Yazmin ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:179
translate chinese LiR1_MAS5_label_13eac489:

    # Liza "Thank you!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:180
translate chinese LiR1_MAS5_label_65d3e8a2:

    # Liza "Honestly, [player_name], she is a wonderful caring person - but she is terrible when it comes to actually getting stuff done!"
    Liza ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:181
translate chinese LiR1_MAS5_label_960a4248:

    # MC "Uh, y-yeah... I know the type. (I better go away from here and come back later... maybe at night again...)"
    MC ""

# game/scripts/A_home/Inside/Kitchen/M/scenes/LiR1_MAS5.rpy:182
translate chinese LiR1_MAS5_label_77c7f65d:

    # MC "(Fuck me... That was FAR too close!)"
    MC ""

