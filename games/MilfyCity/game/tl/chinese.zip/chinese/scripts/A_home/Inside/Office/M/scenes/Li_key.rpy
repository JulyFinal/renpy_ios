﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Office/M/scenes/Li_key.rpy:9
translate chinese Li_key_label_1480ad11:

    # MC "(Oh.. Nice! This should be the key to the front door. Let's try it at night.)"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_key.rpy:18
translate chinese Li_key_label_1480ad11_1:

    # MC "(Oh.. Nice! This should be the key to the front door. Let's try it at night.)"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_key.rpy:30
translate chinese Li_key_label_04a76171:

    # MC "(I can't take that key, when someone is here.)"
    MC ""

# game/scripts/A_home/Inside/Office/M/scenes/Li_key.rpy:40
translate chinese Li_key_label2_04a76171:

    # MC "(I can't take that key, when someone is here.)"
    MC ""

