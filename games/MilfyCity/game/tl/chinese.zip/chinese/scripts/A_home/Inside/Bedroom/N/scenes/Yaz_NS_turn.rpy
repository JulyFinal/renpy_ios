﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:36
translate chinese Yaz_NS_turn_label_e51e6235:

    # MC "(Okay - I have to be extremely careful, right now... This is probably, one of the riskiest things, I’ll ever do in my life...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:38
translate chinese Yaz_NS_turn_label_a20801e1:

    # MC "(I wonder if Yazmin would mind if I flipped her over before we began our roleplay.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:39
translate chinese Yaz_NS_turn_label_cfa20448:

    # MC "(Alright! I’ll take a deep breath and try to flip her on the count of three.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:40
translate chinese Yaz_NS_turn_label_db055a48:

    # MC "*Whispered* One... Two... Three..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:43
translate chinese Yaz_NS_turn_label_baa4f1cb:

    # MC "Ugh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:44
translate chinese Yaz_NS_turn_label_313f6541:

    # MC "Phew... (There we go...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:45
translate chinese Yaz_NS_turn_label_b638d5b5:

    # MC "(That frees up her breasts and bush, for me to play with. Which one should I go for, first?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:52
translate chinese Yaz_NS_B_turn_bush_ab82552a:

    # MC "(Let’s play with Yazmin’s pussy and bush, while she’s sleeping.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:53
translate chinese Yaz_NS_B_turn_bush_18fbd2c7:

    # MC "(I probably won’t be able to slip her panties off, without waking her. So I’ll just have to make do with how she is, right now.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:55
translate chinese Yaz_NS_B_turn_bush_105ba154:

    # MC "(Let’s play with Yazmin’s pussy and bush.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:56
translate chinese Yaz_NS_B_turn_bush_45d59c42:

    # MC "(Yazmin kept her panties on - it probably means she isn’t comfortable taking them off around me yet. I’ll just have to make do with how she is right now.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:59
translate chinese Yaz_NS_B_turn_bush_2f438e8b:

    # Yazmin "Zzz..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:61
translate chinese Yaz_NS_B_turn_bush_d9e999f8:

    # MC "(Okay, it sounds like she’s in a deep sleep. Let’s see if I can slip a hand, down her panties.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:63
translate chinese Yaz_NS_B_turn_bush_02f5e536:

    # MC "(Okay, it sounds like she’s still pretending to sleep. That means she’s enjoying the roleplay so far. Let’s see if I can slip a hand down her panties.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:67
translate chinese Yaz_NS_B_turn_bush_1d89fe75:

    # MC "(I just have to be slow and careful, when I’m doing this... If I go too quickly, I’ll probably wake her up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:68
translate chinese Yaz_NS_B_turn_bush_393b3cb2:

    # MC "(Hmm... Her pubic hair is really soft! She must use a conditioner on it.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:71
translate chinese Yaz_NS_B_turn_bush_1c45ca21:

    # MC "(Slowly and gently does it...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:72
translate chinese Yaz_NS_B_turn_bush_143667f2:

    # MC "(Wow, her pubic hair is really soft! She must use a conditioner on it.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:73
translate chinese Yaz_NS_B_turn_bush_d1e660d9:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:76
translate chinese Yaz_NS_B_turn_bush_9261de80:

    # MC "(There we go! I can feel her vulva now. She’s got such a perfect slit - I’d love to slip my fingers inside her.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:77
translate chinese Yaz_NS_B_turn_bush_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:79
translate chinese Yaz_NS_B_turn_bush_1391dce9:

    # MC "(It sounds like she’s moaning in her sleep - I must have brushed against her clitoris, by accident.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:81
translate chinese Yaz_NS_B_turn_bush_8084238a:

    # MC "(That was a moan! She’s really enjoying this! I must have brushed against her clitoris with my fingers.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:84
translate chinese Yaz_NS_B_turn_bush_c11c98c2:

    # Yazmin "Ohh..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:86
translate chinese Yaz_NS_B_turn_bush_c0f8ffb2:

    # MC "(Her breathing is growing deeper. I should probably stop this now, before I accidentally wake her up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:88
translate chinese Yaz_NS_B_turn_bush_c39f35c1:

    # MC "(Her breathing is growing deeper.) "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:89
translate chinese Yaz_NS_B_turn_bush_88c197e7:

    # MC "(Hmm... What can I do next? I know! I’ll take my cock out and wank myself off, over her pussy!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:92
translate chinese Yaz_NS_B_turn_bush_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:93
translate chinese Yaz_NS_B_turn_bush_67fb3bfc:

    # MC "(That’s perfect! Her bush feels so soft, against my cock. I could do this all night!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:94
translate chinese Yaz_NS_B_turn_bush_d1e660d9_1:

    # Yazmin "*Snore*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:98
translate chinese Yaz_NS_B_turn_bush_e849d63c:

    # MC "(It sounds like she’s falling into a deep sleep again. I should be able to gently thrust my hips without waking her up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:100
translate chinese Yaz_NS_B_turn_bush_632755c1:

    # MC "(She seems pretty relaxed about this. I should be able to gently thrust my hips without annoying her too much.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:101
translate chinese Yaz_NS_B_turn_bush_00f88da8:

    # MC "Ohh.... Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:103
translate chinese Yaz_NS_B_turn_bush_82b56250:

    # Yazmin "(Someone’s getting a bit naughty!)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:104
translate chinese Yaz_NS_B_turn_bush_41436ad1:

    # MC "(I wonder what else I can do to her body.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:107
translate chinese Yaz_NS_B_turn_bush_1808ca76:

    # MC "Hmm... (Perhaps I could slip my cock, down her panties?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:108
translate chinese Yaz_NS_B_turn_bush_79b46c00:

    # MC "(The waistband is elastic, so I might be able to squeeze it down, without her knowing.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:109
translate chinese Yaz_NS_B_turn_bush_3478daac:

    # MC "(Okay, let’s try this...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:112
translate chinese Yaz_NS_B_turn_bush_0a5e45b6:

    # MC "Oh yeah... Mmm..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:114
translate chinese Yaz_NS_B_turn_bush_63c8b1cb:

    # MC "(God, that feels so good!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:115
translate chinese Yaz_NS_B_turn_bush_8fbff7c8:

    # MC "Fuck... (I’m gonna cum!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:116
translate chinese Yaz_NS_B_turn_bush_21da379c:

    # MC "Hnnngg.... Ugh!"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:117
translate chinese Yaz_NS_B_turn_bush_c0102b57:

    # Yazmin "Hmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:128
translate chinese Yaz_NS_B_turn_bush_70acfed5:

    # MC "Phew... Wow..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:130
translate chinese Yaz_NS_B_turn_bush_6391bce6:

    # MC "(Damn, that felt good... But I better get out of here, before she wakes up!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:132
translate chinese Yaz_NS_B_turn_bush_695f4231:

    # MC "(Damn, that felt good! I hope she enjoyed it as much as I did!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:133
translate chinese Yaz_NS_B_turn_bush_385edd04:

    # Yazmin "*Yawn*"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:137
translate chinese Yaz_NS_B_turn_bush_8992f107:

    # Yazmin "(Why do my panties feel sticky?)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:138
translate chinese Yaz_NS_B_turn_bush_bcf58790:

    # Yazmin "(Hmm? I must be imagining it...)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:140
translate chinese Yaz_NS_B_turn_bush_06dc0a70:

    # Yazmin "(God... My panties feel all sticky with [player_name]’s cum. That’s really fucking hot.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:141
translate chinese Yaz_NS_B_turn_bush_9dcb165f:

    # Yazmin "(Mmm... That was really satisfying...)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:142
translate chinese Yaz_NS_B_turn_bush_0f8170c3:

    # Yazmin "Zzz...."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:148
translate chinese Yaz_NS_B_turn_tits_dd9be9a4:

    # MC "(Nice! She’s got a brilliant pair of tits on her.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:149
translate chinese Yaz_NS_B_turn_tits_f62ff6f6:

    # MC "(And just look at how stiff her nipples already are - she’s either cold, or a little horny.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:150
translate chinese Yaz_NS_B_turn_tits_f44f6e98:

    # MC "(Given, how warm it is tonight. I’m gonna guess, it is the latter!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:153
translate chinese Yaz_NS_B_turn_tits_21c87c80:

    # MC "(Oh yeah - rock hard!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:154
translate chinese Yaz_NS_B_turn_tits_f9224c15:

    # MC "(They’re just so firm and pinchable - I’m gonna have A LOT of fun with these!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:156
translate chinese Yaz_NS_B_turn_tits_2a3a67f9:

    # MC "(Let’s see if I can tug on them a bit, without waking her up.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:158
translate chinese Yaz_NS_B_turn_tits_bf12cb55:

    # MC "(Let’s see if she enjoys me tugging on them a bit.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:162
translate chinese Yaz_NS_B_turn_tits_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:163
translate chinese Yaz_NS_B_turn_tits_39563101:

    # MC "Hehe... (She doesn’t have a clue!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:164
translate chinese Yaz_NS_B_turn_tits_38e57b24:

    # MC "(I have to feel, some more... I might not get another chance to do this!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:166
translate chinese Yaz_NS_B_turn_tits_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:167
translate chinese Yaz_NS_B_turn_tits_90f21d39:

    # MC "Hehe... (Sounds like she’s enjoying this! Her moans are getting louder.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:168
translate chinese Yaz_NS_B_turn_tits_601a087a:

    # MC "(Let’s grope her boobs a bit more!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:171
translate chinese Yaz_NS_B_turn_tits_f0a71c2c:

    # MC "(Here we go! That’s more like it!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:172
translate chinese Yaz_NS_B_turn_tits_9cbdfc91:

    # MC "(Her breasts feel, really soft - I wonder how squishy they are..?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:175
translate chinese Yaz_NS_B_turn_tits_9f3a5fa5:

    # Yazmin "Mmm... Oh.... Zzz..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:176
translate chinese Yaz_NS_B_turn_tits_a476ad5d:

    # MC "(Hehe... It sounds like she’s enjoying the feeling, of me doing this. Maybe I should get my cock out, and up my game?)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:178
translate chinese Yaz_NS_B_turn_tits_2f438e8b:

    # Yazmin "Zzz..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:179
translate chinese Yaz_NS_B_turn_tits_ad820a95:

    # MC "(Yeah - she’s dead to the world. Now’s my chance!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:181
translate chinese Yaz_NS_B_turn_tits_cf253153:

    # Yazmin "Oh... Mmm..."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:182
translate chinese Yaz_NS_B_turn_tits_37d0ead7:

    # MC "(Yeah, she’s in heaven right now. Now’s my chance to escalate things.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:186
translate chinese Yaz_NS_B_turn_tits_3bed34e9:

    # MC "*Whispered* Just you lie back and relax, Yazmin."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:187
translate chinese Yaz_NS_B_turn_tits_f0c748ab:

    # MC "(I just need to get this pesky belt buckle out of the way.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:188
translate chinese Yaz_NS_B_turn_tits_e29c1f33:

    # MC "(And... there we go.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:191
translate chinese Yaz_NS_B_turn_tits_6e3035ee:

    # MC "Mmm... "
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:192
translate chinese Yaz_NS_B_turn_tits_010aacae:

    # MC "(It feels so good, having her nipple, press up against my frenulum.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:193
translate chinese Yaz_NS_B_turn_tits_8a3b82fd:

    # MC "(It’s such a sensitive spot - so it’s perfect, having it rub up against something, so soft and delicate.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:196
translate chinese Yaz_NS_B_turn_tits_2339695a:

    # MC "Mmm! Oh yeah! Just like that..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:198
translate chinese Yaz_NS_B_turn_tits_8486c44f:

    # Yazmin "*Yawn* Oooh...."
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:200
translate chinese Yaz_NS_B_turn_tits_7714290b:

    # MC "(Fuck... I need to stay quiet...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:202
translate chinese Yaz_NS_B_turn_tits_9972d534:

    # MC "(Fuck... This feels way too good...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:205
translate chinese Yaz_NS_B_turn_tits_f7a6d70e:

    # MC "(I might even be able to get myself off, if I keep thrusting my hips back and forward like this.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:207
translate chinese Yaz_NS_B_turn_tits_8189c90b:

    # MC "(If I’m quick enough, I should be able to cum over her tits and get out...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:208
translate chinese Yaz_NS_B_turn_tits_cdaac1ee:

    # MC "(Fuck me... that’s insanely risky...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:210
translate chinese Yaz_NS_B_turn_tits_ec4500f3:

    # MC "(I should be able to cum over her tits and get out...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:211
translate chinese Yaz_NS_B_turn_tits_6c3cb1f1:

    # MC "(I wonder if she’d mind me doing that... it’s a bit risky.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:215
translate chinese Yaz_NS_B_turn_tits_71f28b0b:

    # MC "(Ahh, what the hell! Let’s do it!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:216
translate chinese Yaz_NS_B_turn_tits_47d82f0f:

    # MC "Ah... Mmm... Oh..."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:217
translate chinese Yaz_NS_B_turn_tits_3a1f5d33:

    # MC "Fuck... (I’m getting close now... Time to finish it off, with my hand!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:220
translate chinese Yaz_NS_B_turn_tits_8fb3459a:

    # MC "Hnnng! Ugh! Ahh...."
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:222
translate chinese Yaz_NS_B_turn_tits_d42a42fc:

    # Liza "*Yawn* Go back to sleep, Dear..."
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:223
translate chinese Yaz_NS_B_turn_tits_86feec64:

    # MC "(Shit! I’m cumming! I think [Liza_name]’s waking up, though!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:226
translate chinese Yaz_NS_B_turn_tits_3c5582db:

    # Liza "*Yawn*"
    Liza ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:227
translate chinese Yaz_NS_B_turn_tits_9a8dd422:

    # MC "(Shit, I’m cumming! I hope she doesn’t mind this!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:238
translate chinese Yaz_NS_B_turn_tits_2868a1be:

    # MC "(Damn... That was an intense orgasm...)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:240
translate chinese Yaz_NS_B_turn_tits_7d52c92d:

    # MC "(I should probably clean up this cum... but if I stay any longer, I’ll risk, [Liza_name] waking up and catching me.)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:241
translate chinese Yaz_NS_B_turn_tits_1348a26c:

    # MC "(It’ll dry by morning - If I’m lucky, Yazmin will roll back over, and wipe it on the bed. Besides, why would either of them suspect me of wanking over them in the middle of the night? Haha!)"
    MC ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:243
translate chinese Yaz_NS_B_turn_tits_f095da6d:

    # Yazmin "(Ooh... I can feel his hot cum over my tits.)"
    Yazmin ""

# game/scripts/A_home/Inside/Bedroom/N/scenes/Yaz_NS_turn.rpy:244
translate chinese Yaz_NS_B_turn_tits_a811a36b:

    # MC "(I’ll visit them another night and have some more fun with their bodies! I think they enjoyed this sleep roleplay as much as I did!)"
    MC ""

