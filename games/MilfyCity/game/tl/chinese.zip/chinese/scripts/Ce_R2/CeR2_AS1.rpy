﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_AS1.rpy:61
translate chinese CeR2_AS1_lab_06d7f1f5:

    # MC "(There it is in all it’s glory. Excuse the pun.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:62
translate chinese CeR2_AS1_lab_adef43ae:

    # MC "(In a few minutes time I’m going to have that arrogant bitch, on her knees with her lips wrapped tightly around my cock.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:63
translate chinese CeR2_AS1_lab_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:65
translate chinese CeR2_AS1_lab_b9b23b8d:

    # MC "Mwahahaha..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:67
translate chinese CeR2_AS1_lab_7d03ea45:

    # MC "(I knew revenge would be fun, but I never realised it could be THIS sweet.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:69
translate chinese CeR2_AS1_lab_bf772099:

    # MC "(Heh, I knew this fantasy would be fun, but I never realised it would be THIS hot!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:71
translate chinese CeR2_AS1_lab_bb6ed167:

    # MC "(Now, I better get myself prepared for when Ms. Celia arrives.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:72
translate chinese CeR2_AS1_lab_eb13f056:

    # MC "(I’ll slip my pants down while I wait for her.) "
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:75
translate chinese CeR2_AS1_lab_b9b8e06d:

    # "*Creeeaaak*"
    ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:76
translate chinese CeR2_AS1_lab_5afe872f:

    # MC "(That’s the toilet door opening! She must have finally arrived!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:77
translate chinese CeR2_AS1_lab_c5ae3ffd:

    # MC "(I can hear some footsteps crossing the floor. Hopefully they belong to her.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:79
translate chinese CeR2_AS1_lab_6f050731:

    # "*Clunk*"
    ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:80
translate chinese CeR2_AS1_lab_76d3af95:

    # MC "(And the cubicle door to my right just closed!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:82
translate chinese CeR2_AS1_lab_f3fde3ae:

    # Celia "(Ugh... fuck me.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:83
translate chinese CeR2_AS1_lab_4aac19e5:

    # Celia "(Why are men’s toilets always so fucking gross?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:84
translate chinese CeR2_AS1_lab_509e8344:

    # Celia "(I suppose I should say something to let him know that I’ve arrived.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:85
translate chinese CeR2_AS1_lab_9d498901:

    # Celia "*Ahem* I’m here."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:87
translate chinese CeR2_AS1_lab_a79a9289:

    # MC "(And that’s my cue!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:89
translate chinese CeR2_AS1_lab_9db02654:

    # MC "(This will teach you to humiliate me like that in public, Ms. Celia!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:91
translate chinese CeR2_AS1_lab_69a30b9d:

    # MC "(Let's assess your teaching skills in other subjects with this! Hehe! Ms. Celia!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:93
translate chinese CeR2_AS1_lab_7f1ea0e7:

    # Celia "Ugh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:95
translate chinese CeR2_AS1_lab_3c656ae6:

    # Celia "(A tiny part of me was hoping that the blackmailer was only joking.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:96
translate chinese CeR2_AS1_lab_179a28e8:

    # Celia "(I guess I knew deep down that he was telling the truth though. I’m going to have to suck some random stranger’s cock.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:98
translate chinese CeR2_AS1_lab_53bdf525:

    # Celia "(Ugh, I’ve nerver used a glory hole before... It feels so... degrading... in a hot way.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:99
translate chinese CeR2_AS1_lab_976d9939:

    # Celia "(God, my panties are soaking wet right now. I can't believe I'm actually going to use a glory hole!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:101
translate chinese CeR2_AS1_lab_4dfdfd95:

    # MC "(I’m not feeling anything yet...)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:102
translate chinese CeR2_AS1_lab_4cdacd6d:

    # MC "(Maybe I didn’t think this through. What’s to stop her hurting me? Come to think of it, I’m actually in quite a vulnerable position right now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:103
translate chinese CeR2_AS1_lab_ea8fc136:

    # MC "(I’ll just stay still and see how this plays out...)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:106
translate chinese CeR2_AS1_lab_36172914:

    # Celia "(I won’t be able to see this fucker’s face when I’m blowing him, so God knows when he’ll decide to cum.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:108
translate chinese CeR2_AS1_lab_a6342365:

    # Celia "(I won’t be able to see [player_name]'s face when I’m blowing him, so God knows when he’ll decide to cum.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:109
translate chinese CeR2_AS1_lab_dad777c4:

    # Celia "(I’ll take my dress off. The last thing I need is an unexplainable white stain down the front of me.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:111
translate chinese CeR2_AS1_lab_92203d40:

    # Celia "(Alright... Here we go.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:112
translate chinese CeR2_AS1_lab_934cba7b:

    # MC "(I can hear her moving! She must be about to start sucking my dick!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:115
translate chinese CeR2_AS1_lab_1b0a0325:

    # Celia "(I wonder who you REALLY are...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:116
translate chinese CeR2_AS1_lab_8ecba5c5:

    # Celia "(This is one of the blackmailer’s friends. This means that he has told at LEAST one other person that I’m being blackmailed.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:117
translate chinese CeR2_AS1_lab_028ed44c:

    # Celia "(Someone simply HAS to start bragging or boasting at some point.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:119
translate chinese CeR2_AS1_lab_d9dee901:

    # Celia "(And when they do, I’ll catch them.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:120
translate chinese CeR2_AS1_lab_fa3ed065:

    # Celia "(I’ll catch every single one of the bastards who did this to me.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:121
translate chinese CeR2_AS1_lab_49436736:

    # Celia "Hmm... (Now that I think about it, I’ve got quite a long list of students that I altered grades for. I should cross reference their names. Maybe one of them is the blackmailer?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:123
translate chinese CeR2_AS1_lab_9cbfec71:

    # Celia "(Until that day though, I’ve got to bite my tongue and bide my time.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:125
translate chinese CeR2_AS1_lab_7f808eec:

    # Celia "(How much farther can this fantasy possibly go?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:126
translate chinese CeR2_AS1_lab_0ef66af6:

    # Celia "(I mean, it doesn’t get more degrading than being fucked in a mens’ toilets.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:127
translate chinese CeR2_AS1_lab_b6efad21:

    # Celia "(Oh... Imagine if someone saw me coming in here. Word would spread really fast on campus. My reputation would be ruined. Mmm... That’s so fucking hot.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:129
translate chinese CeR2_AS1_lab_789f3aeb:

    # Celia "(I wonder if I should roleplay catching him in order to shake things up a bit?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:130
translate chinese CeR2_AS1_lab_4ea5ea13:

    # Celia "(I could certainly have A LOT of fun turning the tables.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:131
translate chinese CeR2_AS1_lab_c71e0987:

    # Celia "Mmm... (Now that I think about it, I’ve got quite a long list of students that I altered grades for. I probably had something like this coming for a LONG time!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:133
translate chinese CeR2_AS1_lab_62afe204:

    # Celia "(For the meantime, I’ll bite my tongue and keep playing the submissive one in this fantasy.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:135
translate chinese CeR2_AS1_lab_fb613c3b:

    # Celia "(You’ll make it through this, Celia. You have always made it, in the end.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:136
translate chinese CeR2_AS1_lab_84299fb4:

    # Celia "(Remember Harvard, Celia. Remember how those elitist pricks treated you, for coming from a poor family. They weren’t laughing when you made the Dean’s list!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:138
translate chinese CeR2_AS1_lab_2fadd999:

    # Celia "(You’re going to suck this cock and act like the helpless victim.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:139
translate chinese CeR2_AS1_lab_8db4e524:

    # Celia "(Then, whenever your time comes, you’re going to strike! You’re going to turn the tables on this shitlord!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:145
translate chinese CeR2_AS1_lab_3c427cbd:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:146
translate chinese CeR2_AS1_lab_f4864c18:

    # MC "Mmm... Oh..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:148
translate chinese CeR2_AS1_lab_e80e20e1:

    # MC "(Shit, I better try to keep my moaning to a minimum. I don’t want to risk Celia recognising my voice.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:150
translate chinese CeR2_AS1_lab_45f62667:

    # MC "(I’ll try changing my voice as well to make it easier for Celia to pretend it isn’t me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:152
translate chinese CeR2_AS1_lab_5a369e5a:

    # Celia "*Lick Lick*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:153
translate chinese CeR2_AS1_lab_dd87aefc:

    # MC "Mmmpfff... Mmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:154
translate chinese CeR2_AS1_lab_c5e91253:

    # MC "(Fuck, this feels so good!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:156
translate chinese CeR2_AS1_lab_43a28118:

    # Celia "(I better make sure I give a good blowjob here. I don’t want this asshole going back and saying I didn’t give good head.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:158
translate chinese CeR2_AS1_lab_3c427cbd_1:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:160
translate chinese CeR2_AS1_lab_df3bb48a:

    # MC "Ohh... Ah..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:162
translate chinese CeR2_AS1_lab_b9258bea:

    # MC "(Her tongue feels so good flicking up and down the side of my cock.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:163
translate chinese CeR2_AS1_lab_1db042ee:

    # Celia "*Slurp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:165
translate chinese CeR2_AS1_lab_5f7bf351:

    # MC "(Oh shit... This is so good... I wish I’d thought to make Celia do this earlier!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:166
translate chinese CeR2_AS1_lab_5596ab4a:

    # Celia "*Shluurrrp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:168
translate chinese CeR2_AS1_lab_7ac91f92:

    # Celia "Mmppfff!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:170
translate chinese CeR2_AS1_lab_f58cfda9:

    # Celia "*Suuucccck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:171
translate chinese CeR2_AS1_lab_5c4e3662:

    # MC "Ah.... "
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:173
translate chinese CeR2_AS1_lab_36b68398:

    # MC "(Holy shit... Her mouth feels incredible!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:174
translate chinese CeR2_AS1_lab_05ac408d:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:175
translate chinese CeR2_AS1_lab_22adba9e:

    # MC "Hnngg..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:176
translate chinese CeR2_AS1_lab_00ddd76c:

    # MC "(Damn, it’s a struggle not to moan!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:178
translate chinese CeR2_AS1_lab_faa250ca:

    # MC "(I really want to beg her to move her head more quickly, but I can’t or I’ll give myself away.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:181
translate chinese CeR2_AS1_lab_bdc41643:

    # MC "(Even though she’s the one being blackmailed, for the next few minutes I’m at HER mercy!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:183
translate chinese CeR2_AS1_lab_3588d32d:

    # MC "(Even though she's the one that is pretending, for the next few minutes I'm at HER mercy!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:185
translate chinese CeR2_AS1_lab_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:187
translate chinese CeR2_AS1_lab_59cea1f3:

    # Celia "(I’m giving this all I can! The sooner I get this bastard to cum, the sooner I can move on with my day!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:188
translate chinese CeR2_AS1_lab_2e2198b4:

    # Celia "(I guess I’ll just have to suck extra hard. Let’s see if that gets a reaction out of him!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:190
translate chinese CeR2_AS1_lab_a5f02c73:

    # Celia "*SUUUUCCCCK*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:191
translate chinese CeR2_AS1_lab_3be1ed6f:

    # MC "HMMMMMMM!!!!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:192
translate chinese CeR2_AS1_lab_e57b66ab:

    # MC "(Dammit! I’m having to clench my teeth to try and suppress my moaning.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:193
translate chinese CeR2_AS1_lab_66b1b3ea:

    # MC "(Her mouth is like a fucking vacuum!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:195
translate chinese CeR2_AS1_lab_05ac408d_1:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:196
translate chinese CeR2_AS1_lab_eb0a0c57:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:197
translate chinese CeR2_AS1_lab_ad2904ff:

    # MC "Mmm.... Hnnnnggg...."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:199
translate chinese CeR2_AS1_lab_5e0d9587:

    # MC "(My heart’s pounding right now. She has a real talent for sucking cock!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:200
translate chinese CeR2_AS1_lab_0854c568:

    # MC "(I’ll definitely be making her do this again in the future!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:202
translate chinese CeR2_AS1_lab_66f0bdd8:

    # Celia "(Grr... come on, you bastard! Blow your load already!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:203
translate chinese CeR2_AS1_lab_cf87f08c:

    # Celia "(I can’t spend all day here, or my class will wonder where the fuck I’ve wandered off to!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:205
translate chinese CeR2_AS1_lab_f00cc479:

    # Celia "(I didn’t want to have to do this... but drastic times call for drastic measures.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:206
translate chinese CeR2_AS1_lab_3aaf811a:

    # MC "(Huh? She’s stopped? What’s she doing?)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:208
translate chinese CeR2_AS1_lab_075eda35:

    # Celia "(Take a deep breath, Celia. You can do this!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:209
translate chinese CeR2_AS1_lab_8c6a19af:

    # Celia "(Let’s deepthroat this little bastard until he cums. Once he squirts, you’ll be able to nail him!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:212
translate chinese CeR2_AS1_lab_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:214
translate chinese CeR2_AS1_lab_b4cee80e:

    # MC "(Ahh, there she is. I wonder why she stopped for a minute, there.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:215
translate chinese CeR2_AS1_lab_a68b0d2d:

    # MC "(Maybe she was just-)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:217
translate chinese CeR2_AS1_lab_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:219
translate chinese CeR2_AS1_lab_e1dc771e:

    # Celia "*SHLUUURRRRP*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:220
translate chinese CeR2_AS1_lab_0b609764:

    # MC "(HOLY FUCK! God, she’s deepthroating me! Her throat is so damn tight around my cock!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:221
translate chinese CeR2_AS1_lab_8d56a97e:

    # Celia "*GAG*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:224
translate chinese CeR2_AS1_lab_4b84470a:

    # Celia "(I KNEW that would work!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:226
translate chinese CeR2_AS1_lab_2ed81abd:

    # Celia "*SUCK SHLURP* "
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:228
translate chinese CeR2_AS1_lab_8d56a97e_1:

    # Celia "*GAG*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:230
translate chinese CeR2_AS1_lab_9c65680e:

    # MC "(Oh fuck! OH FUCK!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:231
translate chinese CeR2_AS1_lab_3e63c42a:

    # MC "HNNNNGGG!! UGH!!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:232
translate chinese CeR2_AS1_lab_e5f9c628:

    # MC "(I’m cumming! Oh fuck! I’m gonna cum down this bitch’s throat!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:242
translate chinese CeR2_AS1_lab_c06dafe1:

    # Celia "*GULP*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:243
translate chinese CeR2_AS1_lab_6f2e2082:

    # Celia "HMMPFFF?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:244
translate chinese CeR2_AS1_lab_5323338a:

    # Celia "(NO! He wasn’t supposed to cum that quickly!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:245
translate chinese CeR2_AS1_lab_c367bdba:

    # Celia "(Fuck! I swallowed it as it hit the back of my throat. It was a fucking reflex!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:247
translate chinese CeR2_AS1_lab_34bbb127:

    # Celia "*Cough*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:248
translate chinese CeR2_AS1_lab_01efb74b:

    # Celia "Y-You better not to lie to your boss about the quality of this blowjob, fucker..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:249
translate chinese CeR2_AS1_lab_9a645688:

    # Celia "I’m serious!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:251
translate chinese CeR2_AS1_lab_30c636fb:

    # Celia "(Okay, I’ll linger outside the toilets and wait for this little shitstain to come out. Then I’ll catch the bastard red-handed!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:253
translate chinese CeR2_AS1_lab_df8a2f08:

    # Celia "(Okay, I’ll linger outside the toilets and wait for [player_name] to come out. Then I can confront him and turn the tables on our little fantasy!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:255
translate chinese CeR2_AS1_lab_72c25f75:

    # MC "(Heh heh, I’ll just wait here. Celia has a class that she has to teach.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:256
translate chinese CeR2_AS1_lab_ab1e1660:

    # MC "(She can’t afford to sit outside the mens’ toilets and wait for me forever.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:257
translate chinese CeR2_AS1_lab_e2b572ba:

    # MC "(Time is on my side!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:261
translate chinese CeR2_AS1_lab_6f050731_1:

    # "*Clunk*"
    ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:263
translate chinese CeR2_AS1_lab_c6ac72d7:

    # MC "(There goes the cubicle door... followed by her footsteps. And, she is out of here!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:264
translate chinese CeR2_AS1_lab_bc075b0e:

    # MC "(Now, time to sit back on my phone and chillax.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:266
translate chinese CeR2_AS1_lab_7c3d5855:

    # Celia "Grr... (C’mon! Where the fuck are you?!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:267
translate chinese CeR2_AS1_lab_de88b28e:

    # Celia "(You can’t hide in there forever, you little shit!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS1.rpy:268
translate chinese CeR2_AS1_lab_c924388b:

    # Celia "(Fuck it, it’s been twenty minutes... I can’t hang around here forever, or I’ll lose my job.)"
    Celia ""

