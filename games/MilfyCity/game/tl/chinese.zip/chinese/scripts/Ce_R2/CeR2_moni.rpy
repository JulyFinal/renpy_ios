﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_moni.rpy:23
translate chinese CeR2_moni_lab_78ba640c:

    # MC "(I've already talked to him.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:42
translate chinese CeR2_moni_lab_d6a36ef2:

    # MC "(Oh wow... this place is awesome!)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:43
translate chinese CeR2_moni_lab_1a8520a9:

    # MC "(It looks like something straight out of a James Bald film!)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:46
translate chinese CeR2_moni_lab_73ec4ec1:

    # MC "(This must be the guy who handles the security. He’s way too overweight to be a conventional security guard. This must be why they have him holed up in this backroom.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:47
translate chinese CeR2_moni_lab_af40a793:

    # MC "Hey there, I love your setup. You can see the entire college from here!"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:50
translate chinese CeR2_moni_lab_c7638d81:

    # B_J "*Wheeze*"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:51
translate chinese CeR2_moni_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:52
translate chinese CeR2_moni_lab_67b9eee4:

    # MC "Umm... There’s a lot of buttons and stuff. Do you use them all?"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:55
translate chinese CeR2_moni_lab_0217dd9b:

    # B_J "*SHLUUURRRRP*"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:56
translate chinese CeR2_moni_lab_d0a93a06:

    # MC "Not a very talkative guy, are you?"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:57
translate chinese CeR2_moni_lab_0e38a918:

    # B_J "*Shlurp*"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:60
translate chinese CeR2_moni_lab_3f986cdf:

    # B_J "Whatcha want?"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:61
translate chinese CeR2_moni_lab_c3d54bb6:

    # MC "I was just looking around. The name’s [player_name]."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:63
translate chinese CeR2_moni_lab_32514e57:

    # B_J "Uh huh... I’m Big Jake."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:67
translate chinese CeR2_moni_lab_9b0f4aa4:

    # MC "Nice to meet-"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:68
translate chinese CeR2_moni_lab_fc643412:

    # B_J "Ya shouldn’t be here. *Wheeze* No students."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:69
translate chinese CeR2_moni_lab_8cd13e4f:

    # MC "Yeah, I was just-"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:70
translate chinese CeR2_moni_lab_8dd176ac:

    # B_J "Scram, lad."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:73
translate chinese CeR2_moni_lab_949ccce9:

    # MC "Umm... Okay, no problem."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:74
translate chinese CeR2_moni_lab_b4f6c065:

    # MC "Just before I go, how long have you worked here? I don’t remember seeing you around before."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:75
translate chinese CeR2_moni_lab_d3330551:

    # B_J "I’ve been here ever since they hired me."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:76
translate chinese CeR2_moni_lab_6e197a35:

    # MC "And that was..."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:77
translate chinese CeR2_moni_lab_ea489652:

    # B_J "The same day I started *Wheeze* working here."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:78
translate chinese CeR2_moni_lab_0b0d7f0e:

    # MC "(Fuck me... It’s like talking with a Furby.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:81
translate chinese CeR2_moni_lab_ffde4454:

    # B_J "I’m serious, lad. No students in the security suite. Scam."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:82
translate chinese CeR2_moni_lab_02e41b4d:

    # MC "Are there rules about having food in the security suite?"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:83
translate chinese CeR2_moni_lab_1504b44b:

    # B_J "*Wheeze* That’s it, I’m calling the *Wheeze* Dean."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:84
translate chinese CeR2_moni_lab_e96a20b2:

    # MC "Ugh, don’t bother. I’m leaving."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:85
translate chinese CeR2_moni_lab_0645bb4d:

    # B_J "Don’t let the *Wheeze* door hit you ass on the way out."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:98
translate chinese CeR2_moni_lab_d65e734e:

    # MC "Hey there, Big Jake. Me again!"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:99
translate chinese CeR2_moni_lab_1c2b9298:

    # MC "How are you keeping?"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:102
translate chinese CeR2_moni_lab_7bf87c86:

    # B_J "*Slurp*"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:103
translate chinese CeR2_moni_lab_eabe74a7:

    # MC "I... uh... I see you got yourself another burger..."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:104
translate chinese CeR2_moni_lab_3681c17c:

    # B_J "*Shlurrrp*"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:105
translate chinese CeR2_moni_lab_5e6de579:

    # MC "...and a pizza too."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:108
translate chinese CeR2_moni_lab_ffb743b3:

    # MC "(None of the fast food packaging matches. The only explanation I can come up with is that this guy has literally gone to at least three different fast food joints on his lunch break.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:109
translate chinese CeR2_moni_lab_40da96f7:

    # MC "(He must have picked up the burger from one place, the pizza from another, and God-knows-what was in that red box.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:110
translate chinese CeR2_moni_lab_7dfa36ad:

    # MC "(It’s actually rather impressive, the dedication that he is putting into his lunch hour.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:111
translate chinese CeR2_moni_lab_ca925c2f:

    # B_J "Didn’t I see you before? No students in here. Vamanos!"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:114
translate chinese CeR2_moni_lab_b9138a2d:

    # MC "Aww, c’mon man. I just wanted to see how it all worked in here."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:115
translate chinese CeR2_moni_lab_9dbd90e7:

    # B_J "*Wheeze* You’re interrupting my lunch hour. This is my happy time - and you’re ruining it."
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:116
translate chinese CeR2_moni_lab_ad2ecb68:

    # MC "Just-"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:117
translate chinese CeR2_moni_lab_871d6625:

    # B_J "Do I have to *Wheeze* get off my seat and call the Dean?"
    B_J ""

# game/scripts/Ce_R2/CeR2_moni.rpy:120
translate chinese CeR2_moni_lab_e3dfe18f:

    # MC "*Sigh* No. I’ll go now."
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:121
translate chinese CeR2_moni_lab_5e2341c9:

    # MC "(There has to be a way to distract this guy so I can actually get access to the monitoring system.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:123
translate chinese CeR2_moni_lab_0f7d9a45:

    # MC "(It’s the only way I’ll ever be able to delete those security tapes.)"
    MC ""

# game/scripts/Ce_R2/CeR2_moni.rpy:125
translate chinese CeR2_moni_lab_afa88146:

    # MC "(It’s the only way I’ll ever be able to get to those security tapes and delete them! That will really surprise Celia. I wonder if she even thought of that?)"
    MC ""

