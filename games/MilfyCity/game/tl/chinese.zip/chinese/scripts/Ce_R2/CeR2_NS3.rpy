﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_NS3.rpy:41
translate chinese CeR2_NS3_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:42
translate chinese CeR2_NS3_lab_0d0848e6:

    # MC "(It’s okay, [player_name]. Try to relax. You can do this...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:45
translate chinese CeR2_NS3_lab_9830fd45:

    # MC "(All you have to do is sneak in, gather the evidence, and then escape.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:46
translate chinese CeR2_NS3_lab_de0f5e11:

    # MC "(I guess I’ll check out the bedroom first. Maybe there are some photos or sex toys in there I can use!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:50
translate chinese CeR2_NS3_lab_c0613901:

    # Celia "HMMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:51
translate chinese CeR2_NS3_lab_f6083f2d:

    # Celia "MMMPFFF!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:53
translate chinese CeR2_NS3_lab_9376faae:

    # MC "*Whispered* What the..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:56
translate chinese CeR2_NS3_lab_563268fd:

    # MC "(Oh, my God!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:57
translate chinese CeR2_NS3_lab_a762ff65:

    # MC "(Holy fucking shit!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:58
translate chinese CeR2_NS3_lab_a649ff04:

    # Celia "Hnnng! Mmmmmm! AAHMMMMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:64
translate chinese CeR2_NS3_lab_d3a329bf:

    # MC "Whoa..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:65
translate chinese CeR2_NS3_lab_f7061f20:

    # MC "(Judy was right! Celia is into some seriously lewd stuff!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:68
translate chinese CeR2_NS3_lab_b85d4a67:

    # MC "(A gag, vibrating nipple clamps, a handheld vibrator...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:69
translate chinese CeR2_NS3_lab_e7bd0866:

    # MC "(What the fuck is she doing with a tennis racket though?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:72
translate chinese CeR2_NS3_lab_a4e1fbf6:

    # Celia "Hnnggg.... Mmmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:73
translate chinese CeR2_NS3_lab_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:74
translate chinese CeR2_NS3_lab_c9eb920b:

    # Celia "AAAHHHHMMMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:77
translate chinese CeR2_NS3_lab_73720b7e:

    # Celia "Aaahhmmmffff...."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:78
translate chinese CeR2_NS3_lab_5963817a:

    # MC "(And just look at how hot that mesh bodysuit is!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:81
translate chinese CeR2_NS3_lab_ddcd503f:

    # MC "(She’s moving that tennis racket close to her boob. Is it for spanking?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:82
translate chinese CeR2_NS3_lab_918d215f:

    # MC "(I don’t think I’ve ever seen ANYTHING like it, in my life.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:83
translate chinese CeR2_NS3_lab_53247e6f:

    # MC "(Is it even a sex toy?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:87
translate chinese CeR2_NS3_lab_371aeb52:

    # "*ZAP*"
    ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:88
translate chinese CeR2_NS3_lab_a7948724:

    # Celia "HMMPPFFFFF!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:89
translate chinese CeR2_NS3_lab_f2fbf408:

    # MC "H-Holy shit..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:92
translate chinese CeR2_NS3_lab_6b9e2504:

    # Celia "Aahhmmm..... Mmmm....."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:93
translate chinese CeR2_NS3_lab_e2133e83:

    # MC "(She’s into being electrocuted!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:96
translate chinese CeR2_NS3_lab_c1da3b76:

    # MC "(Oh wow!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:97
translate chinese CeR2_NS3_lab_d38bcac5:

    # MC "(I never could have predicted this!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:98
translate chinese CeR2_NS3_lab_752bf6a9:

    # MC "(Judy is going to LOVE hearing about this!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:102
translate chinese CeR2_NS3_lab_371aeb52_1:

    # "*ZAP*"
    ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:103
translate chinese CeR2_NS3_lab_a9010fa6:

    # Celia "AHHHMMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:104
translate chinese CeR2_NS3_lab_a5c1c391:

    # Celia "OHHMMMMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:107
translate chinese CeR2_NS3_lab_adb4ca4a:

    # Celia "Hnnnnnngggg...."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:108
translate chinese CeR2_NS3_lab_189c5668:

    # Celia "HNNNGGGGG!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:109
translate chinese CeR2_NS3_lab_13d7b9a8:

    # MC "(She’s trembling right now!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:112
translate chinese CeR2_NS3_lab_71a10401:

    # Celia "(Oh fuck! I’m going to cum again!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:113
translate chinese CeR2_NS3_lab_19678efc:

    # Celia "NMMPFFFFF!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:114
translate chinese CeR2_NS3_lab_85ed899e:

    # Celia "(F-Fuck... That’s number six!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:117
translate chinese CeR2_NS3_lab_0702ceae:

    # MC "(And now she’s choking herself!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:118
translate chinese CeR2_NS3_lab_25595a8b:

    # MC "(Holy crap, this woman is seriously kinky!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:122
translate chinese CeR2_NS3_lab_d150605b:

    # MC "(She probably enjoyed me blackmailing her!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:124
translate chinese CeR2_NS3_lab_3d0fd9bd:

    # MC "(She probably enjoyed our roleplaying as blackmailing her, as a fun sexy joke...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:125
translate chinese CeR2_NS3_lab_1dd826ab:

    # MC "(I really have to tell Judy about all of this! She’ll know what to do next!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:128
translate chinese CeR2_NS3_lab_1103eb28:

    # Celia "HNNNNGGGGG!! MMMPFFFF!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:129
translate chinese CeR2_NS3_lab_a829be74:

    # Celia "(Oh fuck! Oh fuck! That’s the spot!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:132
translate chinese CeR2_NS3_lab_935fe48a:

    # MC "(Holy shit, she’s really putting on a great show for me!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:133
translate chinese CeR2_NS3_lab_ca8045da:

    # Celia "MMMPPFFF! HNNNNGGGG!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:136
translate chinese CeR2_NS3_lab_6cf7289a:

    # Celia "(Where did I put my electric bat?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:137
translate chinese CeR2_NS3_lab_10583be3:

    # Celia "(I need it for my climax!!!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:141
translate chinese CeR2_NS3_lab_371aeb52_2:

    # "*ZAP*"
    ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:142
translate chinese CeR2_NS3_lab_9cdaa881:

    # Celia "HNNNGGGGGFFFFF!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:143
translate chinese CeR2_NS3_lab_49405fd7:

    # MC "(Oh my God! She just used it directly on her pussy!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:147
translate chinese CeR2_NS3_lab_bedf0713:

    # MC "(This couldn’t have worked out any better for me. I’ll have everything I need to end Celia’s torture!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:149
translate chinese CeR2_NS3_lab_874fb633:

    # MC "(This couldn’t have worked out any better! I have everything I need to regain the upper hand in our roleplay!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:150
translate chinese CeR2_NS3_lab_b9b23b8d:

    # MC "Mwahahaha..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:154
translate chinese CeR2_NS3_lab_371aeb52_3:

    # "*ZAP*"
    ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:156
translate chinese CeR2_NS3_lab_6afada55:

    # "*ZAP ZAP*"
    ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:157
translate chinese CeR2_NS3_lab_e7827d35:

    # Celia "Eeaaaayyaahhhhhhhh!!!! MMPFFFF!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:160
translate chinese CeR2_NS3_lab_6d214b08:

    # Celia "*GASP*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:161
translate chinese CeR2_NS3_lab_8a328116:

    # MC "(I wish I could just dive onto her right now and start slamming my cock into her pussy!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:164
translate chinese CeR2_NS3_lab_5e55e8e3:

    # Celia "(F-Fuck! I’m cumming again!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:165
translate chinese CeR2_NS3_lab_da0d8c46:

    # Celia "AAAAYAAAAHHHHHHHHH!!! HNNNNGGGG!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:168
translate chinese CeR2_NS3_lab_9657d606:

    # Celia "AAAHHHHHMMMMMM!!!! MMMMMFFFFF!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:169
translate chinese CeR2_NS3_lab_2452de5c:

    # Celia "*Pant Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:172
translate chinese CeR2_NS3_lab_be4ca4dc:

    # MC "(She’s shaking and trembling like crazy right now!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:173
translate chinese CeR2_NS3_lab_aa8ff184:

    # MC "(I don’t think I’ve ever seen a woman climax, so hard, in my life!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:175
translate chinese CeR2_NS3_lab_d2c67290:

    # MC "(I better leave now. I’m so dead if she catches me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:177
translate chinese CeR2_NS3_lab_4024a1ec:

    # MC "(I better leave right now... Got a lot of work to do!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:180
translate chinese CeR2_NS3_lab_48c1e588:

    # "*Creak*"
    ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:183
translate chinese CeR2_NS3_lab_2452de5c_1:

    # Celia "*Pant Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:184
translate chinese CeR2_NS3_lab_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS3.rpy:185
translate chinese CeR2_NS3_lab_27d34b07:

    # Celia "W-Wow... That was... fucking amazing..."
    Celia ""

