﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_MS1.rpy:36
translate chinese CeR2_MS1_lab_1c30e579:

    # Celia "Did you get a copy of the tape?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:37
translate chinese CeR2_MS1_lab_69dcc0bd:

    # MC "I tried my best, Ms. Celia. There must have been some kind of failsafe though!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:40
translate chinese CeR2_MS1_lab_7087a8f3:

    # Celia "Why, what happened?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:41
translate chinese CeR2_MS1_lab_ab26a6e2:

    # MC "As soon as I tried to access the files it asked me for a password. I tried a few times and then..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:43
translate chinese CeR2_MS1_lab_17291f84:

    # Celia "Then what?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:44
translate chinese CeR2_MS1_lab_6d574ba0:

    # MC "Everything just deleted! The whole system!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:46
translate chinese CeR2_MS1_lab_37aeaf2a:

    # Celia "Are you serious?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:48
translate chinese CeR2_MS1_lab_a0c2c10f:

    # Celia "Are you serious?! (Fuck! I did not think of that... but he did not delete the entire surveillance system at college!? Did he!?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:50
translate chinese CeR2_MS1_lab_b5ad3ee1:

    # MC "There’s nothing left at all."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:51
translate chinese CeR2_MS1_lab_5ac1b1b4:

    # Celia "That was our BEST chance at catching the blackmailer red-handed!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:52
translate chinese CeR2_MS1_lab_ed52c32a:

    # Celia "Ugh! You idiot! You’ve cost us our best chance at fixing this."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:56
translate chinese CeR2_MS1_lab_420a2134:

    # Celia "God dammit... I’m out of here."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:57
translate chinese CeR2_MS1_lab_62cff699:

    # Celia "(This is REALLY fishy. How could you accidentally delete the entire security camera footage?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:58
translate chinese CeR2_MS1_lab_edd66c84:

    # Celia "(I wonder if [player_name] is an accomplice to the blackmailer - or even worse, the blackmailer himself.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:59
translate chinese CeR2_MS1_lab_03c1ce75:

    # MC "(Heh, that worked like a charm! She doesn’t suspect a thing!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:61
translate chinese CeR2_MS1_lab_9fbb279e:

    # Celia "God dammit... I’m out of here. (That’s was clean regardless, he’s still in charge.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:62
translate chinese CeR2_MS1_lab_e0bb8324:

    # Celia "(Mmm, nice touch by [player_name] there. I love the way he makes me feel so helpless!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:63
translate chinese CeR2_MS1_lab_3bdcf791:

    # Celia "(I wonder how he’d feel if I turned things around and started dominating him instead?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:64
translate chinese CeR2_MS1_lab_dd2191e7:

    # MC "(Heh, that worked like a charm! She seemed to enjoy the prospect of dragging this fantasy out a little longer!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:89
translate chinese CeR2_MS1_lab_1bb79ef1:

    # Celia "Well?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:90
translate chinese CeR2_MS1_lab_28067539:

    # MC "Well what?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:91
translate chinese CeR2_MS1_lab_f0492112:

    # Celia "Have you found the security footage yet?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:94
translate chinese CeR2_MS1_lab_ff142d87:

    # MC "I’m getting blocked from seeing it."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:95
translate chinese CeR2_MS1_lab_4b52731f:

    # Celia "What do you mean you’re getting blocked?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:97
translate chinese CeR2_MS1_lab_71ab477e:

    # Celia "Do you not realise how damn serious it is?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:99
translate chinese CeR2_MS1_lab_afc8183f:

    # Celia "*Yawn* (You could at least come up with something better...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:102
translate chinese CeR2_MS1_lab_769a2161:

    # MC "It’s not my fault!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:103
translate chinese CeR2_MS1_lab_2d39a925:

    # Celia "Then whose fault is it?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:106
translate chinese CeR2_MS1_lab_acd4984b:

    # MC "Big Jake! The fat guy who operates the security suite."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:107
translate chinese CeR2_MS1_lab_56ad8135:

    # Celia "Hold up, let me get this straight."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:108
translate chinese CeR2_MS1_lab_3111e4d3:

    # Celia "You’re getting pushed around by Big Jake?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:111
translate chinese CeR2_MS1_lab_fde9151b:

    # MC "Yes! He won’t let me anywhere near the security system. I can’t access any videos if he is there."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:112
translate chinese CeR2_MS1_lab_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:113
translate chinese CeR2_MS1_lab_5a14a8f6:

    # MC "He threatened to call the Dean on me! I just need you to distract him for five minutes. I’ll slip inside, grab the footage, and then we’ll know who the dickhead blackmailing you is. Okay?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:116
translate chinese CeR2_MS1_lab_967c53ee:

    # Celia "You got intimidated by an obese blob of lard that weighs at least six hundred pounds."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:117
translate chinese CeR2_MS1_lab_4fb80981:

    # MC "Yeah, but-"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:118
translate chinese CeR2_MS1_lab_dd1886d5:

    # Celia "That guy wheezes more than a fucking whoopee cushion!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:119
translate chinese CeR2_MS1_lab_4905d286:

    # Celia "Christ almighty... Fine! I’ll distract Big Jake. This was SUPPOSED to be YOUR job though!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:137
translate chinese CeR2_MS1_lab_193b7fc4:

    # MC "(I haven't found out anything yet.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:150
translate chinese CeR2_MS1_lab_1c0c1c64:

    # MC "Hi Celia, are you free to talk for a minute?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:151
translate chinese CeR2_MS1_lab_b131f594:

    # Celia "I was just about to begin my class, but I can spare a minute."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:154
translate chinese CeR2_MS1_lab_d09b7341:

    # Celia "What’s up, [player_name]?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:155
translate chinese CeR2_MS1_lab_9d374c47:

    # MC "I just wanted to update you on what I’ve found out about the blackmailer."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:156
translate chinese CeR2_MS1_lab_ea04d5d5:

    # Celia "Oh yeah? Tell me! What did you find out?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:159
translate chinese CeR2_MS1_lab_f138ef7d:

    # MC "Umm... Nothing so far."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:160
translate chinese CeR2_MS1_lab_b29a984d:

    # Celia "Seriously? You came over to tell me you found NOTHING?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:161
translate chinese CeR2_MS1_lab_b5ad04d9:

    # MC "Well, not exactly nothing. There’s nobody suspicious in my class. This leads me to believe the blackmailer is in ANOTHER classroom."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:164
translate chinese CeR2_MS1_lab_0f6800dd:

    # Celia "Hmm..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:166
translate chinese CeR2_MS1_lab_77532866:

    # Celia "(He has a good point. Even though he didn’t find me the actual asshole, [player_name] has helped me tighten the net on them.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:167
translate chinese CeR2_MS1_lab_e1947faa:

    # Celia "(I’ll have [player_name] search the other classes. As soon as he notifies me of anyone even remotely suspicious, I’ll take them down.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:169
translate chinese CeR2_MS1_lab_73c26016:

    # Celia "(Well, this is an interesting direction. I didn’t expect us to be roleplaying as detectives alongside our little blackmail fantasy.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:170
translate chinese CeR2_MS1_lab_1df9af68:

    # Celia "(I guess the best way to handle this is to direct [player_name] to search the other classes. He could then “notify” me if he finds anyone suspicious.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:173
translate chinese CeR2_MS1_lab_c687756f:

    # MC "Sorry I couldn’t be of more help."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:174
translate chinese CeR2_MS1_lab_a75fdf00:

    # Celia "No... this is good. I can work with this."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:175
translate chinese CeR2_MS1_lab_652f36a3:

    # Celia "I need you to expand your search to other classrooms. Speak to your classmates, ask around, see if anyone knows anything."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:178
translate chinese CeR2_MS1_lab_bbb5eba9:

    # MC "Are you sure? What if people grow suspicious about me sticking my nose into their business?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:180
translate chinese CeR2_MS1_lab_b6c9a787:

    # Celia "It’s a risk we’ll have to take. I can’t let this blackmail go on any longer."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:182
translate chinese CeR2_MS1_lab_7c6926c3:

    # Celia "It’s a risk we’ll have to take."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:185
translate chinese CeR2_MS1_lab_a160dc3b:

    # MC "I understand that. Do you have any idea about who would want to do this to you though?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:186
translate chinese CeR2_MS1_lab_a94cd0bb:

    # Celia "Do you honestly think I know any more than you do?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:187
translate chinese CeR2_MS1_lab_67aaf58c:

    # Celia "If I even had a slight inclination about who was behind this I would have already hunted them down."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:190
translate chinese CeR2_MS1_lab_e5974f4c:

    # MC "Fair enough, but what could you actually do? Getting a confession mightn’t be easy-"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:192
translate chinese CeR2_MS1_lab_9974bf8e:

    # Celia "I’m not going to the police with this. I’m not going to handle him myself. By the time I’m finished with them, their classmates will be wondering who used to sit in that empty chair. "
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:194
translate chinese CeR2_MS1_lab_0411ae15:

    # Celia "Oh, you have NO IDEA how harshly I am going to come down on the person doing this to me!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:195
translate chinese CeR2_MS1_lab_15f529c2:

    # Celia "This punk won’t be on any attendance register, their name won’t be in the front of any textbooks, their photo won’t be in any fucking yearbooks."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:196
translate chinese CeR2_MS1_lab_1e7e87a7:

    # Celia "I’m going to fucking erase them from existence."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:199
translate chinese CeR2_MS1_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:200
translate chinese CeR2_MS1_lab_4a80d4b8:

    # Celia "Now, I have to get to class. I expect to hear from you tomorrow about what you find out."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:201
translate chinese CeR2_MS1_lab_742c176c:

    # MC "S-Sure, no problem."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:202
translate chinese CeR2_MS1_lab_b6645055:

    # Celia "God willing, I’ll catch this bastard. And when I do, I’ll tear him limb from fucking limb."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:207
translate chinese CeR2_MS1_lab_9ab6d555:

    # MC "(Yikes... She can be pretty damn scary when she’s angry.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:208
translate chinese CeR2_MS1_lab_bbf4327b:

    # MC "(Ah well, time to pretend to search for the blackmailer. Let's check out the security cameras again.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:210
translate chinese CeR2_MS1_lab_a40d771d:

    # MC "(Yikes... She can be pretty damn sacary when she’s acting like that. Women are good actresses - she’s a perfect example of that.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:211
translate chinese CeR2_MS1_lab_8730eaad:

    # MC "(Ah well, time to do my part in “pretending” to search for the blackmailer. I guess this makes the fantasy feel more real for her? I’ll check out the security cameras again.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:231
translate chinese CeR2_MS1_lab_e9e54dd3:

    # MC "Hey Ms. Celia, can I borrow you for a minute?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:232
translate chinese CeR2_MS1_lab_1caf4273:

    # Celia "Yes, did you find out anything?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:233
translate chinese CeR2_MS1_lab_ce881095:

    # MC "Nothing, I’m afraid."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:236
translate chinese CeR2_MS1_lab_5c99789b:

    # Celia "Nothing? Seriously?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:237
translate chinese CeR2_MS1_lab_6233d5c1:

    # MC "Yeah, I’m sorry."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:238
translate chinese CeR2_MS1_lab_2068636c:

    # Celia "*Sigh* I don’t believe it. You’re telling me that there are NO students acting suspicious in ANY of the classes?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:239
translate chinese CeR2_MS1_lab_bf2f6b57:

    # MC "None that I could see."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:242
translate chinese CeR2_MS1_lab_5c81f022:

    # Celia "Shit."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:243
translate chinese CeR2_MS1_lab_8607dde6:

    # MC "I really am sorry. I want to get to the bottom of this as much as you do."
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:244
translate chinese CeR2_MS1_lab_e2a4b16d:

    # MC "(I know that Ms. Celia can’t go to the police. If she does, then they’ll catch her selling those grades for money.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:245
translate chinese CeR2_MS1_lab_bf163f26:

    # MC "How about we just give up and call the police? They’re professionals and they can-"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:248
translate chinese CeR2_MS1_lab_820a386a:

    # Celia "No! No cops!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:249
translate chinese CeR2_MS1_lab_8bbf8356:

    # MC "What? Are you su-"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:250
translate chinese CeR2_MS1_lab_50cf68d4:

    # Celia "I swear to God, if you let the police know about this I will lose my fucking shit! This is embarrassing enough as it is."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:253
translate chinese CeR2_MS1_lab_cae6b91e:

    # Celia "*Sigh* No cops. Understand?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:254
translate chinese CeR2_MS1_lab_2c2a80af:

    # MC "Yes, Ms. Celia. "
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:256
translate chinese CeR2_MS1_lab_6f606649:

    # MC "(Hehe, if she thinks I want to call the police then she won’t suspect me of being the blackmailer!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:258
translate chinese CeR2_MS1_lab_994c96d4:

    # MC "(I knew she wouldn't want to involve the cops. It's fun to talk about it though, makes our little roleplay seem even more realistic!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:260
translate chinese CeR2_MS1_lab_784fb320:

    # MC "Is there anything else you would like me to do?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:261
translate chinese CeR2_MS1_lab_f06428a3:

    # Celia "I don’t fucking know. Grr..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:262
translate chinese CeR2_MS1_lab_4c5e9aaf:

    # Celia "I'll call you if I need you. Right now I've got a lecture to deliver."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:265
translate chinese CeR2_MS1_lab_ce78c2aa:

    # Celia "Jesus... fucking... Christ..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:267
translate chinese CeR2_MS1_lab_e0f25536:

    # Celia "(Could it be one of the other professors? They do have access to the staffroom, and it is conceivable that one of them might have stolen my password.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:269
translate chinese CeR2_MS1_lab_61937301:

    # Celia "(I wonder if we could expand this fantasy to some of the other professors on campus... I quite liked Judy and the Headmaster... No! That's silly. I'm just exposing myself by doing that! I'll keep it contained to just me and [player_name])"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:270
translate chinese CeR2_MS1_lab_3dc7eec5:

    # MC "(Hehe, another victory for [player_name].)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS1.rpy:287
translate chinese CeR2_MS1_lab_a57f2be7:

    # MC "(Not now, [player_name])"
    MC ""

