﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_NS2.rpy:150
translate chinese CeR2_NS2_lab_5374bcae:

    # MC "(And once again, door fifty-three.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:151
translate chinese CeR2_NS2_lab_065cf247:

    # MC "(Y’know, if I was designing an erotic videogame I would have probably used this moment to choose number sixty-nine.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:152
translate chinese CeR2_NS2_lab_3a84277e:

    # MC "(Eh, probably too cliche.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:155
translate chinese CeR2_NS2_lab_bc29d68c:

    # Gustav "Fuck the lights in this fucking hallway..."
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:156
translate chinese CeR2_NS2_lab_23ff0e06:

    # MC "(Shit! This must be Celia’s husband! I need to act cool.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:159
translate chinese CeR2_NS2_lab_42987d84:

    # Gustav "I mean, what the fuck do I pay the management company to do? Watch the grass grow in my non-existent garden?"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:160
translate chinese CeR2_NS2_lab_44c1e414:

    # MC "Hello sir, umm, excuse me?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:163
translate chinese CeR2_NS2_lab_3857e5ad:

    # Gustav "Huh? The heck do you want, pal?"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:164
translate chinese CeR2_NS2_lab_c3329d04:

    # MC "I’m looking for Celia. I’m one of her students."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:167
translate chinese CeR2_NS2_lab_10926a57:

    # Gustav "Oh, right. You must be the special needs student... [player_name], right?"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:168
translate chinese CeR2_NS2_lab_6228e865:

    # MC "The WHAT?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:169
translate chinese CeR2_NS2_lab_c60982ef:

    # Gustav "She’s a good person - Celia. She spends extra time teaching the developmentally challenged. She said you might be coming over for some extra tutoring."
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:170
translate chinese CeR2_NS2_lab_16e3f9a3:

    # MC "I’m not developmentally challenged!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:173
translate chinese CeR2_NS2_lab_e20f1d81:

    # Gustav "It’s okay, a low IQ is nothing to be ashamed of. My name is Gustav."
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:178
translate chinese CeR2_NS2_lab_24ac8c83:

    # Gustav "You spell that, G-U-S-T-"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:179
translate chinese CeR2_NS2_lab_f04cf02c:

    # MC "I KNOW HOW TO SPELL GUSTAV!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:182
translate chinese CeR2_NS2_lab_e77c266b:

    # Gustav "It’s okay, pal. Relax. Celia will help you out. She told me all the difficulty you’ve had with her and with reading."
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:183
translate chinese CeR2_NS2_lab_4f199a08:

    # MC "(Fucking bitch! She must have told her husband this to avoid suspicion, but she could have chosen a less embarrassing alibi!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:185
translate chinese CeR2_NS2_lab_5dbf2973:

    # Gustav "I’m popping off for a few days on a business trip. Ought to be back within the week. Hopefully."
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:186
translate chinese CeR2_NS2_lab_81917539:

    # Gustav "I better dash on now, or I’ll be late for my plane!"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:189
translate chinese CeR2_NS2_lab_dbdf99e6:

    # Gustav "Oh! How rude of me! A plane is like a... flying bus. Do you ever take the bus?"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:190
translate chinese CeR2_NS2_lab_8d53fc80:

    # MC "I know what a plane is."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:193
translate chinese CeR2_NS2_lab_19b977b6:

    # Gustav "Imagine that you’re sitting in the bus and it starts rising into the air. It takes you places very, very fast!"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:194
translate chinese CeR2_NS2_lab_5bb38632:

    # MC "(Her husband thinks I’m mentally disabled. Thanks a fucking lot, Celia.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:195
translate chinese CeR2_NS2_lab_c0d72ffe:

    # MC "(And he’s not even listening to what I say.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:198
translate chinese CeR2_NS2_lab_de9f8d58:

    # MC "Thanks for explaining that. I had absolutely no idea what you were talking about."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:199
translate chinese CeR2_NS2_lab_94ec1782:

    # Gustav "No problemo!"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:202
translate chinese CeR2_NS2_lab_d1e261bb:

    # Gustav "I’ll catch you around, [player_name]. Keep working hard."
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:203
translate chinese CeR2_NS2_lab_6f4a2338:

    # MC "Thanks."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:204
translate chinese CeR2_NS2_lab_83b78486:

    # Gustav "Seriously, I mean it - boys like you make me so proud!"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:205
translate chinese CeR2_NS2_lab_9c99b967:

    # MC "(For fuck's sake...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:208
translate chinese CeR2_NS2_lab_3af08f47:

    # Gustav "(Poor boy. He’ll be lucky to work as a waiter.)"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:209
translate chinese CeR2_NS2_lab_b3324f31:

    # MC "(Poor bastard, I’m going to be screwing his wife when he’s away.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:212
translate chinese CeR2_NS2_lab_9591d8a7:

    # MC "(Christ, that guy is dense!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:213
translate chinese CeR2_NS2_lab_992aa3f6:

    # MC "(Seriously, how does he still think I’m retarded after having a full conversation with me?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:214
translate chinese CeR2_NS2_lab_5cb552c0:

    # MC "(He must have realised that I was at least somewhat lucid?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:217
translate chinese CeR2_NS2_lab_4af9f116:

    # Gustav "I left the door open for you there, just in case you can’t figure it out, okay?"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:218
translate chinese CeR2_NS2_lab_b45c1b88:

    # Gustav "Ta ta for now!"
    Gustav ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:221
translate chinese CeR2_NS2_lab_310e3f42:

    # MC "(And now he thinks I can’t open a door?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:222
translate chinese CeR2_NS2_lab_63962d29:

    # MC "(Jesus Christ... no wonder Celia is stressed out. I would be too if I was married to a twat like that!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:226
translate chinese CeR2_NS2_lab_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:227
translate chinese CeR2_NS2_lab_ca6b39c1:

    # MC "(Alright, let’s find Celia.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:230
translate chinese CeR2_NS2_lab_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:231
translate chinese CeR2_NS2_lab_cb84f89b:

    # MC "Celia? Are you around?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:234
translate chinese CeR2_NS2_lab_32bb50ef:

    # MC "(Where the hell is she?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:235
translate chinese CeR2_NS2_lab_35d248b2:

    # MC "(Gustav must have turned out the lights before he left. Maybe she’s in another room waiting for me?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:238
translate chinese CeR2_NS2_lab_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:239
translate chinese CeR2_NS2_lab_370c69b5:

    # MC "CELIA?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:240
translate chinese CeR2_NS2_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:243
translate chinese CeR2_NS2_lab_4bf1fb2a:

    # MC "Where could she be?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:244
translate chinese CeR2_NS2_lab_81dafe48:

    # MC "(I guess I’ll just go exploring and see if I can find her.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:265
translate chinese CeR2_NS2_boxing_lab_7373418e:

    # MC "(Oh, there she is!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:266
translate chinese CeR2_NS2_boxing_lab_8d4ac986:

    # MC "Hey Celia, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:267
translate chinese CeR2_NS2_boxing_lab_675fb8a4:

    # MC "(Oh man, is that a picture of ME on that punching bag?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:270
translate chinese CeR2_NS2_boxing_lab_5eb6cde0:

    # Celia "Ugh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:273
translate chinese CeR2_NS2_boxing_lab_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:274
translate chinese CeR2_NS2_boxing_lab_58a76f14:

    # Celia "Arrgh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:277
translate chinese CeR2_NS2_boxing_lab_89418302:

    # MC "Hey, I was looking for you. I didn’t see you in the living room, so I went searching for you."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:278
translate chinese CeR2_NS2_boxing_lab_c11128b1:

    # MC "Umm, I met your husband earlier on when he was leaving."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:279
translate chinese CeR2_NS2_boxing_lab_5d08a233:

    # MC "Gustav?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:282
translate chinese CeR2_NS2_boxing_lab_bc2fd556:

    # MC "You do know I’m not actually mentally retarded, right?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:285
translate chinese CeR2_NS2_boxing_lab_b116b5ad:

    # "*Whack* *Thud*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:289
translate chinese CeR2_NS2_boxing_lab_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:290
translate chinese CeR2_NS2_boxing_lab_e305167a:

    # MC "I should probably just leave now."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:291
translate chinese CeR2_NS2_boxing_lab_d63a1847:

    # MC "I’ll, uhh, see you later on?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:296
translate chinese CeR2_NS2_boxing_lab_7f572810:

    # MC "(I wonder if she heard me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:301
translate chinese CeR2_NS2_boxing_lab_933aa022:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:305
translate chinese CeR2_NS2_boxing_lab_933aa022_1:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:309
translate chinese CeR2_NS2_boxing_lab_933aa022_2:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:313
translate chinese CeR2_NS2_boxing_lab_f766bc02:

    # MC "(God, she must really hate me right now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:314
translate chinese CeR2_NS2_boxing_lab_1404b756:

    # MC "(It must be because of the makeout session and the blowjob.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:316
translate chinese CeR2_NS2_boxing_lab_fd4a7e40:

    # MC "(Jesus, she’s REALLY taking out some stress on that punching bag!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:317
translate chinese CeR2_NS2_boxing_lab_55d1dbf5:

    # MC "(I’d be stressed too if I’d a husband as annoying as Gustav.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:321
translate chinese CeR2_NS2_boxing_lab_3c726d8a_1:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:324
translate chinese CeR2_NS2_boxing_lab_e000cbed:

    # Celia "Hiii-yah!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:328
translate chinese CeR2_NS2_boxing_lab_7b3ebabd:

    # "*THWACK*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:330
translate chinese CeR2_NS2_boxing_lab_7660fed3:

    # MC "Look Celia, I’m sorry again for making you do stuff for me, but I promise I’ll help you."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:332
translate chinese CeR2_NS2_boxing_lab_71c798ee:

    # MC "H-Hey Celia, how’s it going?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:337
translate chinese CeR2_NS2_boxing_lab_0d6317fa:

    # Celia "UGH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:343
translate chinese CeR2_NS2_boxing_lab_0c4b6ba1:

    # "*Whack*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:344
translate chinese CeR2_NS2_boxing_lab_35d33bb0:

    # Celia "AAHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:348
translate chinese CeR2_NS2_boxing_lab_91ea4cf9_1:

    # "*Thud*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:349
translate chinese CeR2_NS2_boxing_lab_ec9493d2:

    # Celia "YAH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:350
translate chinese CeR2_NS2_boxing_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:353
translate chinese CeR2_NS2_boxing_lab_22277f16:

    # MC "(Ugh, this is ridiculous. I shouldn’t have bothered coming here.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:354
translate chinese CeR2_NS2_boxing_lab_7f9dc71b:

    # MC "(I’ll try again some other time.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:358
translate chinese CeR2_NS2_boxing_lab_a79ede7b:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:361
translate chinese CeR2_NS2_boxing_lab_60035870:

    # MC "(She finally stopped!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:362
translate chinese CeR2_NS2_boxing_lab_bf5672e8:

    # MC "(Maybe I’ll be able to get a word in now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:365
translate chinese CeR2_NS2_boxing_lab_a79ede7b_1:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:366
translate chinese CeR2_NS2_boxing_lab_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:367
translate chinese CeR2_NS2_boxing_lab_a79ede7b_2:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:370
translate chinese CeR2_NS2_boxing_lab_7e636943:

    # MC "Oh hey Celia, how’s the workout session going?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:371
translate chinese CeR2_NS2_boxing_lab_e6383e56:

    # MC "Struggling to catch your breath?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:374
translate chinese CeR2_NS2_boxing_lab_35c32a8a:

    # Celia "What the-?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:375
translate chinese CeR2_NS2_boxing_lab_9a2917f5:

    # MC "I just came to-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:382
translate chinese CeR2_NS2_boxing_lab_8a3a8cbb:

    # Celia "Haven’t you ever heard of “knocking”?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:383
translate chinese CeR2_NS2_boxing_lab_637c665a:

    # MC "I tried yelling at you. It seemed you were deep in the zone!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:384
translate chinese CeR2_NS2_boxing_lab_013b692d:

    # MC "Your husband thinks I’m mentally challenged, by the way. You wouldn’t know anything about that, would you?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:387
translate chinese CeR2_NS2_boxing_lab_149af7ac:

    # Celia "Hiiii-yah!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:388
translate chinese CeR2_NS2_boxing_lab_a83d3f49:

    # MC "WHOA!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:391
translate chinese CeR2_NS2_boxing_lab_cf0b8b36:

    # MC "Whoa! Hold on!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:392
translate chinese CeR2_NS2_boxing_lab_447b4912:

    # MC "Easy, easy!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:393
translate chinese CeR2_NS2_boxing_lab_6148f0eb:

    # Celia "*Pant* *Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:396
translate chinese CeR2_NS2_boxing_lab_15d8ffc8:

    # Celia "Haha, gotcha... *Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:397
translate chinese CeR2_NS2_boxing_lab_b7aa1c19:

    # MC "Christ, you’re gonna give me a heart attack."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:400
translate chinese CeR2_NS2_boxing_lab_a78dde61:

    # Celia "I had to tell my husband you were a special needs student. How else was I supposed to prevent him from getting suspicious?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:401
translate chinese CeR2_NS2_boxing_lab_dcfaa958:

    # MC "I don’t know, maybe LITERALLY ANYTHING ASIDE FROM THAT?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:404
translate chinese CeR2_NS2_boxing_lab_977fc3e7:

    # Celia "Oh please, you’re overreacting."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:405
translate chinese CeR2_NS2_boxing_lab_215d7a75:

    # MC "How would you feel if I said that about you?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:406
translate chinese CeR2_NS2_boxing_lab_d2ff4b13:

    # Celia "Haha! You wouldn’t have the balls to."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:409
translate chinese CeR2_NS2_boxing_lab_92de97c9:

    # Celia "I need to take a shower and freshen up. Are you okay waiting for me in the living room?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:410
translate chinese CeR2_NS2_boxing_lab_7f4c5170:

    # MC "Sure, I’ll see you there."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:413
translate chinese CeR2_NS2_boxing_lab_8b5bf163:

    # MC "Want me to get tea or coffee sorted for us tonight?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:414
translate chinese CeR2_NS2_boxing_lab_39c7915f:

    # Celia "Nope, I’m good."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:417
translate chinese CeR2_NS2_boxing_lab_8fd87be4:

    # Celia "(Fuck, I hope he didn’t see that picture of himself on the punching bag. My body was probably blocking his line of sight anyway.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:418
translate chinese CeR2_NS2_boxing_lab_6134a499:

    # MC "(Tsk, what’s this bitch’s problem?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:421
translate chinese CeR2_NS2_boxing_lab_a79ede7b_3:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:422
translate chinese CeR2_NS2_boxing_lab_5d5b5ea8:

    # Celia "(Okay, time to cool off with a shower.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:426
translate chinese CeR2_NS2_boxing_lab_ea5905c5:

    # Celia "(And then we’ll see what progress has been made catching our blackmailer.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:428
translate chinese CeR2_NS2_boxing_lab_c86c3848:

    # Celia "(And then we’ll see if I can reset the direction we’re taking this little fantasy of ours.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:429
translate chinese CeR2_NS2_boxing_lab_a79ede7b_4:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:430
translate chinese CeR2_NS2_boxing_lab_9329497e:

    # Celia "(Jeez, I really went all out there. My thighs are gonna burn like hell tomorrow.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:450
translate chinese CeR2_NS2_wait_lab_b6dc0b03:

    # MC "(It’s already getting really dark outside...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:451
translate chinese CeR2_NS2_wait_lab_b1c96d0c:

    # MC "(I should probably try and find a light switch.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:455
translate chinese CeR2_NS2_wait_lab_737951da:

    # MC "*Click*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:456
translate chinese CeR2_NS2_wait_lab_20da70c8:

    # MC "(Much better.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:459
translate chinese CeR2_NS2_wait_lab_e9ce8360:

    # MC "(Hmm, that’s a really fancy decanter on the table.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:460
translate chinese CeR2_NS2_wait_lab_d97f8eff:

    # MC "(I wonder who was drinking.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:461
translate chinese CeR2_NS2_wait_lab_d2cbf0b4:

    # MC "(Probably Celia and Gustav, before he left for his business trip.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:464
translate chinese CeR2_NS2_wait_lab_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:465
translate chinese CeR2_NS2_wait_lab_aa70ab61:

    # MC "(How long does it take a woman to get showered?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:468
translate chinese CeR2_NS2_wait_lab_27237811:

    # MC "(Gah, I’m so fucking bored...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:469
translate chinese CeR2_NS2_wait_lab_7562a692:

    # MC "(I didn’t come here to waste my evening sitting around.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:472
translate chinese CeR2_NS2_wait_lab_79398991:

    # MC "(Hmmmm, in fact...maybe I could sneak in and peek while she’s showering?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:475
translate chinese CeR2_NS2_wait_lab_1373d794:

    # MC "(She’d kick my ass if she actually caught me...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:476
translate chinese CeR2_NS2_wait_lab_cde40ab3:

    # MC "(But the chance to see her naked body covered in soapy bubbles. Mmm! That would be so fucking hot!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:479
translate chinese CeR2_NS2_wait_lab_fa9723c4:

    # MC "(Fuck, I’m wasting my time here.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:480
translate chinese CeR2_NS2_wait_lab_579dd185:

    # MC "(I should just man up and go to the shower.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:483
translate chinese CeR2_NS2_wait_lab_0fdd4858:

    # MC "(The longer I lie here the greater the chance that she actually WILL catch me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:484
translate chinese CeR2_NS2_wait_lab_4fdb9f3a:

    # MC "(Okay, [player_name] you have to make a choice. It’s now or never!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:487
translate chinese CeR2_NS2_wait_lab_45c05437:

    # MC "(Let’s do this!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:490
translate chinese CeR2_NS2_wait_lab_f37c0419:

    # MC "(Alright, here goes nothing!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:491
translate chinese CeR2_NS2_wait_lab_be082538:

    # MC "(I either get to see a sexy naked woman or I get beaten to a pulp.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:492
translate chinese CeR2_NS2_wait_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:507
translate chinese CeR2_NS2_bath_lab_1ce637ca:

    # MC "(Celia told me to wait for her in the living room.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:516
translate chinese CeR2_NS2_bath_lab_75f89a7a:

    # MC "(I should go back to the living room before she finishes showering.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:530
translate chinese CeR2_NS2_bath_lab_4ecebbcf:

    # MC "(Wow, I came at the perfect time!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:531
translate chinese CeR2_NS2_bath_lab_ad02068a:

    # MC "(She hasn’t even stepped into the shower yet!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:535
translate chinese CeR2_NS2_bath_lab_c976f868:

    # "*Creeak*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:536
translate chinese CeR2_NS2_bath_lab_09519923:

    # MC "(She must have spent more time training, after I left.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:537
translate chinese CeR2_NS2_bath_lab_9c9c81c3:

    # MC "(Or maybe she just wanted to hide that picture of me she had hanging up.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:540
translate chinese CeR2_NS2_bath_lab_c7b09304:

    # MC "(Hehe, this is going to be awesome!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:541
translate chinese CeR2_NS2_bath_lab_c149b0fd:

    # MC "(She won’t suspect a thing. I’ll be back in the living room before she leaves.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:544
translate chinese CeR2_NS2_bath_lab_343f60ec:

    # MC "(Oh yeah, that’s it, Celia. Soap your body up for me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:545
translate chinese CeR2_NS2_bath_lab_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:548
translate chinese CeR2_NS2_bath_lab_6aaac2b3:

    # MC "(God, I wish I was in that shower with her right now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:549
translate chinese CeR2_NS2_bath_lab_f1ffb5e5:

    # MC "(I would do unspeakably dirty things to her in there.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:552
translate chinese CeR2_NS2_bath_lab_478feb75:

    # MC "(And her ass is fucking perfect!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:553
translate chinese CeR2_NS2_bath_lab_0bcc8a82:

    # MC "(I’d bend her over, make her put her hands up against the glass, and then ram my cock inside her.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:556
translate chinese CeR2_NS2_bath_lab_906d1d4e:

    # MC "(She’d be screaming with pleasure as I fucked her, over and over.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:557
translate chinese CeR2_NS2_bath_lab_59f7dc83:

    # MC "(And I’d play with those massive tits she has, while I’m doing it.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:561
translate chinese CeR2_NS2_bath_lab_efebe60a:

    # MC "(I’d make that bitch cum so hard, that she would wish she’d never turned me down.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:563
translate chinese CeR2_NS2_bath_lab_e384b72e:

    # MC "(I’d make her cum soooo fucking hard, that the neighbours would hear her!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:564
translate chinese CeR2_NS2_bath_lab_d4265a79:

    # MC "(She would be screaming my name as she climaxed again and again.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:567
translate chinese CeR2_NS2_bath_lab_865e2f17:

    # MC "(Fuck, I wish I had a camera on me right now to take some pictures.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:568
translate chinese CeR2_NS2_bath_lab_75d4389e:

    # MC "(Probably too risky anyway. I wouldn’t get a good photo with all the condensation in the room.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:571
translate chinese CeR2_NS2_bath_lab_845c19ac:

    # MC "(Oh yeah, just like that, Celia. Let’s see those big titties of yours!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:572
translate chinese CeR2_NS2_bath_lab_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:575
translate chinese CeR2_NS2_bath_lab_be94fa59:

    # MC "(You’re so fucking hot.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:578
translate chinese CeR2_NS2_bath_lab_0daff976:

    # MC "(Wash your boobs and pussy for me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:579
translate chinese CeR2_NS2_bath_lab_5ed906d9:

    # MC "(I want to see your hands rub all over your body.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:582
translate chinese CeR2_NS2_bath_lab_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:583
translate chinese CeR2_NS2_bath_lab_7c7a1871:

    # MC "(That’s it, Celia. Just like that!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:586
translate chinese CeR2_NS2_bath_lab_e4ad642b:

    # MC "(Damn, I’ve got the biggest boner right now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:587
translate chinese CeR2_NS2_bath_lab_2c0a537e:

    # MC "(At least Celia will be able to help me out with that when she finishes her shower.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:590
translate chinese CeR2_NS2_bath_lab_96ff609e:

    # MC "(I wonder if I should request another blowjob tonight.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:591
translate chinese CeR2_NS2_bath_lab_926f64a5:

    # MC "(Or maybe to fuck her tits?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:592
translate chinese CeR2_NS2_bath_lab_fe10e82b:

    # Celia "Huh?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:595
translate chinese CeR2_NS2_bath_lab_84cde9b7:

    # MC "(Shit, time to abort!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:596
translate chinese CeR2_NS2_bath_lab_eec566cc:

    # MC "(I don’t think she saw me yet. I won’t risk it though.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:600
translate chinese CeR2_NS2_bath_lab_48c1e588:

    # "*Creak*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:602
translate chinese CeR2_NS2_bath_lab_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:608
translate chinese CeR2_NS2_bath_lab_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:609
translate chinese CeR2_NS2_bath_lab_ce366a8d:

    # MC "(My heart’s pounding right now!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:610
translate chinese CeR2_NS2_bath_lab_4fc7adc3:

    # MC "(This is gonna be okay, just relax. Breathe. She didn't see you.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:613
translate chinese CeR2_NS2_bath_lab_5b438910:

    # MC "(I’ll just go back to the living room and wait for her there.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:614
translate chinese CeR2_NS2_bath_lab_d6b10443:

    # MC "(I can act as if nothing happened.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:617
translate chinese CeR2_NS2_bath_lab_983de9fb:

    # MC "(Fuck, I better be quick!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:618
translate chinese CeR2_NS2_bath_lab_5761a25d:

    # MC "(She won’t take long drying her body down!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:640
translate chinese CeR2_NS2_talking_lab_ab52e3eb:

    # MC "(I think I heard the shower stop. That must mean she’s on her way.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:641
translate chinese CeR2_NS2_talking_lab_ffcea0dc:

    # MC "(Okay, [player_name]. Just act cool!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:645
translate chinese CeR2_NS2_talking_lab_b9b8e06d:

    # "*Creeeaaak*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:646
translate chinese CeR2_NS2_talking_lab_3dc90f96:

    # MC "(Here she comes!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:647
translate chinese CeR2_NS2_talking_lab_3cb6cd05:

    # Celia "Sorry it took me a while."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:650
translate chinese CeR2_NS2_talking_lab_f584ce55:

    # MC "No problem, I’ve just been waiting here. On this couch."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:651
translate chinese CeR2_NS2_talking_lab_d7110186:

    # Celia "Sure."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:654
translate chinese CeR2_NS2_talking_lab_8abcdfa5:

    # Celia "I was just taking a shower after my training."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:655
translate chinese CeR2_NS2_talking_lab_551ec1f6:

    # MC "Yeah, you were really giving it your all earlier."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:658
translate chinese CeR2_NS2_talking_lab_f0ccb46a:

    # Celia "I like to get a strong cardio routine going each day. It keeps me fit and healthy."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:659
translate chinese CeR2_NS2_talking_lab_b8f2a68c:

    # Celia "Plus, it means I can deal with jerks who think it’s okay to lay their hands on me."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:660
translate chinese CeR2_NS2_talking_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:663
translate chinese CeR2_NS2_talking_lab_05942d7d:

    # Celia "Are you okay there, [player_name]?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:664
translate chinese CeR2_NS2_talking_lab_20cbd26f:

    # MC "Y-Yeah, I’m *Gulp* good!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:665
translate chinese CeR2_NS2_talking_lab_61d73f72:

    # Celia "You sound a little flustered. Can I get you something to drink?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:668
translate chinese CeR2_NS2_talking_lab_6b9d66b9:

    # MC "I-I’m fine."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:669
translate chinese CeR2_NS2_talking_lab_f8cff00c:

    # Celia "Good. That’s good to hear."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:672
translate chinese CeR2_NS2_talking_lab_72b16d28:

    # Celia "So, I’ve been doing some thinking about this whole blackmail case."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:673
translate chinese CeR2_NS2_talking_lab_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:674
translate chinese CeR2_NS2_talking_lab_4c0a6965:

    # Celia "It’s led me to a couple of possible conclusions."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:677
translate chinese CeR2_NS2_talking_lab_25597e9d:

    # Celia "There’s only two people that it could possibly be."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:678
translate chinese CeR2_NS2_talking_lab_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:679
translate chinese CeR2_NS2_talking_lab_04f53d9a:

    # MC "H-How come you think that?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:682
translate chinese CeR2_NS2_talking_lab_c5930e24:

    # Celia "Process of elimination."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:683
translate chinese CeR2_NS2_talking_lab_828d8053:

    # Celia "I thought about all the times you helped me “investigate.” The moment that our investigation reached a dead end was when you went to get me that video footage."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:684
translate chinese CeR2_NS2_talking_lab_6646a4b5:

    # Celia "Remember how it “conveniently” got deleted?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:687
translate chinese CeR2_NS2_talking_lab_4a4c3b33:

    # Celia "It leaves me with two possibilities for who is behind this."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:688
translate chinese CeR2_NS2_talking_lab_6631cfa8:

    # Celia "First, is Big Jake. He has access to the cameras and I think he is in the college after hours, so he has the means to blackmail me."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:691
translate chinese CeR2_NS2_talking_lab_f4c7d0b2:

    # Celia "He’s also creepy as fuck..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:692
translate chinese CeR2_NS2_talking_lab_fbbd0049:

    # MC "And... Umm... Who is the other person?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:695
translate chinese CeR2_NS2_talking_lab_15be8492:

    # Celia "You."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:696
translate chinese CeR2_NS2_talking_lab_fef36d0d:

    # MC "M-Me?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:697
translate chinese CeR2_NS2_talking_lab_7cbd836b:

    # Celia "You were the only other one who accessed those computer video files. Perhaps you WANTED them to be deleted to cover your ass."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:700
translate chinese CeR2_NS2_talking_lab_8b4023d9:

    # Celia "I just want you to do one thing for me today, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:701
translate chinese CeR2_NS2_talking_lab_3f0a3dda:

    # Celia "Admit what you did. That’s all."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:704
translate chinese CeR2_NS2_talking_lab_68c0d575:

    # MC "B-But, I didn’t do anything! It must be Big Jake, then! We should investigate him!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:705
translate chinese CeR2_NS2_talking_lab_d7dc87a0:

    # MC "I can help, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:708
translate chinese CeR2_NS2_talking_lab_6877ae59:

    # Celia "Ahahaha, I’m just kidding you."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:709
translate chinese CeR2_NS2_talking_lab_c47b8f5e:

    # MC "Oh! Phew, that’s a relief. Haha!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:712
translate chinese CeR2_NS2_talking_lab_b8e80772:

    # MC "For a second, I thought you were actually serious about me being the blackmailer there."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:713
translate chinese CeR2_NS2_talking_lab_8bc55dae:

    # MC "I mean, it’s absurd. Right?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:717
translate chinese CeR2_NS2_talking_lab_a6bbc853:

    # Celia "Totally... absurd..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:718
translate chinese CeR2_NS2_talking_lab_f3ecb9c5:

    # MC "Well, if it isn’t too much trouble, I’ll just head out now. It’s getting late and I’ve already distrubed you."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:721
translate chinese CeR2_NS2_talking_lab_8ed12e2b:

    # Celia "You’re not going anywhere, you duplicitous piece of shit!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:722
translate chinese CeR2_NS2_talking_lab_77a612f3:

    # MC "AHH!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:725
translate chinese CeR2_NS2_talking_lab_939f8174:

    # MC "Celia! What the fuck are you doing?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:726
translate chinese CeR2_NS2_talking_lab_7e1d5fc3:

    # Celia "Something I should have done DAYS ago!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:730
translate chinese CeR2_NS2_talking_lab_060947e2:

    # MC "I-Is that a fucking knife?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:732
translate chinese CeR2_NS2_talking_lab_0c707252:

    # MC "I-Is that a fucking knife?! (Jesus! She takes her roleplaying WAAAY too seriously!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:733
translate chinese CeR2_NS2_talking_lab_e6e9beb6:

    # Celia "You bet your ass it is."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:737
translate chinese CeR2_NS2_talking_lab_6d5a6ca4:

    # MC "*Gulp* Wh-What are you doing?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:739
translate chinese CeR2_NS2_talking_lab_182f9cf8:

    # MC "*Gulp* Wh-What are you doing?! (If it’s still roleplaying, I think I’m gonna lose...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:740
translate chinese CeR2_NS2_talking_lab_df796fc3:

    # Celia "I’m going to kill you right now. Unless you start telling me the truth."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:743
translate chinese CeR2_NS2_talking_lab_137dd4cd:

    # MC "I HAVE BEEN TELLING YOU THE TRUTH!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:744
translate chinese CeR2_NS2_talking_lab_1bd92bd5:

    # MC "I’M NOT THE BLACKMAlLER!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:747
translate chinese CeR2_NS2_talking_lab_650438c1:

    # Celia "Time is running out for you, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:748
translate chinese CeR2_NS2_talking_lab_98976ddd:

    # Celia "If you just confess and own up to what you’ve done, I’ll let you live."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:751
translate chinese CeR2_NS2_talking_lab_e1d9f7dc:

    # MC "B-But... I didn’t do anything... "
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:752
translate chinese CeR2_NS2_talking_lab_c32369ef:

    # MC "Y-You’ve got the wrong guy!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:755
translate chinese CeR2_NS2_talking_lab_e2ed8d40:

    # Celia "BULLSHIT!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:756
translate chinese CeR2_NS2_talking_lab_d5e80335:

    # Celia "I know it was you all along! You were the one on webcam! You were the one in the toilets! Weren’t you?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:760
translate chinese CeR2_NS2_talking_lab_83622072:

    # MC "(Fuck, I’m finished. Should I scream for help?! Would anyone even come before she finished me off?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:762
translate chinese CeR2_NS2_talking_lab_a8de285a:

    # MC "(How should I play this? I could scream for help, but I don’t know if that’s the direction Celia wants to take this.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:768
translate chinese CeR2_NS2_talking_lab_4033e166:

    # MC "HELP ME! ANYBODY! HELP ME!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:769
translate chinese CeR2_NS2_talking_lab_7f48adcd:

    # MC "PLEASE! SHE’S GOT A KNIFE! APARTMENT 53!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:775
translate chinese CeR2_NS2_talking_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:776
translate chinese CeR2_NS2_talking_lab_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:783
translate chinese CeR2_NS2_talking_con1_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:784
translate chinese CeR2_NS2_talking_con1_31d3cd4d:

    # Celia "Still not admitting to it?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:787
translate chinese CeR2_NS2_talking_con1_12af9cfe:

    # Celia "Aw, fuck."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:788
translate chinese CeR2_NS2_talking_con1_8a352700:

    # MC "(Is she backing down?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:791
translate chinese CeR2_NS2_talking_con1_646af29f:

    # Celia "ARRRGHHHH!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:792
translate chinese CeR2_NS2_talking_con1_68d34cb1:

    # MC "NO!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:795
translate chinese CeR2_NS2_talking_con1_a4868fd1:

    # Celia "FUCK! YOU!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:796
translate chinese CeR2_NS2_talking_con1_51ae3be2:

    # MC "W-WAIT!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:799
translate chinese CeR2_NS2_talking_con1_933aa022:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:800
translate chinese CeR2_NS2_talking_con1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:804
translate chinese CeR2_NS2_talking_con1_9147c481:

    # Celia "(He’s either a fantastic liar, not scared of me, or completely innocent.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:805
translate chinese CeR2_NS2_talking_con1_36928e80:

    # Celia "(And I have no fucking clue which.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:807
translate chinese CeR2_NS2_talking_con1_75894bfa:

    # Celia "(Damn, he’s as committed to this roleplay as I am! Gustav was always shit at this kinda thing. He broke character so quickly.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:808
translate chinese CeR2_NS2_talking_con1_4595d01b:

    # Celia "(This certainly makes for a nice change of pace.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:809
translate chinese CeR2_NS2_talking_con1_d3552052:

    # MC "I’m innocent, Celia..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:812
translate chinese CeR2_NS2_talking_con1_0cd82829:

    # Celia "Perhaps you are, after all."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:813
translate chinese CeR2_NS2_talking_con1_7de446e4:

    # MC "Y-Yeah, like I told you I was, all along!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:816
translate chinese CeR2_NS2_talking_con1_147a52b7:

    # MC "H-Hey!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:817
translate chinese CeR2_NS2_talking_con1_c9b229cc:

    # Celia "You might not be the blackmailer."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:821
translate chinese CeR2_NS2_talking_con1_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:822
translate chinese CeR2_NS2_talking_con1_8f1c7b24:

    # Celia "But you were still peeping on me in the bathroom. Perv."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:823
translate chinese CeR2_NS2_talking_con1_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:826
translate chinese CeR2_NS2_talking_con1_b85d86b0:

    # Celia "Fuck. Fuck. Shit. Shit."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:828
translate chinese CeR2_NS2_talking_con1_5be1b538:

    # Celia "(What do I do now? I’ve got no leads left. It can’t actually be Big Jake, can it? That buffoon wouldn’t be smart enough to run a blackmail operation like this.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:831
translate chinese CeR2_NS2_talking_con1_947000c8:

    # MC "(Holy shit... I thought I was going to die there!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:833
translate chinese CeR2_NS2_talking_con1_f5de2154:

    # Celia "(What direction should I take things now? I still really want to dominate [player_name], but he’s holding firm.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:836
translate chinese CeR2_NS2_talking_con1_19ba9ecd:

    # MC "(Holy shit, that was intense... She’s a terrifying actress! She made it seem so real!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:837
translate chinese CeR2_NS2_talking_con1_b72d1fe5:

    # MC "I’m... I’m sorry for peeping on you. I was wondering where you went, since you were taking so long."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:840
translate chinese CeR2_NS2_talking_con1_718268d8:

    # MC "I didn’t mean to look at you in the shower. It was an accident, I promise."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:841
translate chinese CeR2_NS2_talking_con1_5bf51b61:

    # Celia "Uh huh. Sure."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:844
translate chinese CeR2_NS2_talking_con1_05e713fb:

    # Celia "Right, I need you to go to Big Jake’s-"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:845
translate chinese CeR2_NS2_talking_con1_a99f00b8:

    # MC "No."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:848
translate chinese CeR2_NS2_talking_con1_dbc5821c:

    # Celia "What do you mean, ‘no’?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:849
translate chinese CeR2_NS2_talking_con1_61628b2b:

    # MC "I’m not being your errand boy any longer. You’re treating me like shit."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:850
translate chinese CeR2_NS2_talking_con1_13300707:

    # MC "All I have EVER done is try to help you through this!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:853
translate chinese CeR2_NS2_talking_con1_a739bedb:

    # Celia "[player_name], you can't deny that you look like a prime suspect, right now."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:854
translate chinese CeR2_NS2_talking_con1_c03bc385:

    # MC "Fuck you! You’re crazy!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:857
translate chinese CeR2_NS2_talking_con1_4f9b560e:

    # Celia "Just one more-"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:858
translate chinese CeR2_NS2_talking_con1_28ae22c1:

    # MC "No more detective work! I’m done! I got dragged into this by the blackmailer, but I’m dragging myself out."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:859
translate chinese CeR2_NS2_talking_con1_7ea4ef65:

    # MC "I don’t want to see you again. Please don’t approach me in college. Okay?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:862
translate chinese CeR2_NS2_talking_con1_104cadc2:

    # Celia "*Sigh*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:863
translate chinese CeR2_NS2_talking_con1_552373e2:

    # Celia "Fine."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:864
translate chinese CeR2_NS2_talking_con1_af063ba6:

    # MC "Goodbye."
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:867
translate chinese CeR2_NS2_talking_con1_920522b9:

    # Celia "Goodbye, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:868
translate chinese CeR2_NS2_talking_con1_6b4cf976:

    # Celia "(This isn’t over yet.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:872
translate chinese CeR2_NS2_talking_con1_90f58199:

    # MC "(I’m going to blackmail her so hard now. She thought she had it rough before?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:874
translate chinese CeR2_NS2_talking_con1_6f543068:

    # MC "(I’m gonna dominate her so hard. If she thought she had it rough before, she’s got another thing coming!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:875
translate chinese CeR2_NS2_talking_con1_418342f6:

    # MC "(She ain’t seen NOTHING yet!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:878
translate chinese CeR2_NS2_talking_con1_5b86c93c:

    # Celia "(Shit! I ruined the sofa.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:879
translate chinese CeR2_NS2_talking_con1_3bb7dcc3:

    # Celia "(How the fuck am I going to explain this to Gustav when he returns?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:880
translate chinese CeR2_NS2_talking_con1_29bfd33e:

    # Celia "(God fucking dammit.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:884
translate chinese CeR2_NS2_talking_con1_36c7991a:

    # Celia "(It can’t be Big Jake...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:885
translate chinese CeR2_NS2_talking_con1_5779f8eb:

    # Celia "(But that only leaves us with [player_name].)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:886
translate chinese CeR2_NS2_talking_con1_9bb32722:

    # Celia "(I need to confirm for certain if [player_name] is the one blackmailing me.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:888
translate chinese CeR2_NS2_talking_con1_52734514:

    # Celia "(This little fantasy with [player_name] is starting to spiral out of control... It’s getting harder to hide my rendezvous with [player_name] from Gustav.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:889
translate chinese CeR2_NS2_talking_con1_fedf55f2:

    # Celia "(But I’m having such a great time playing this game with him...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:890
translate chinese CeR2_NS2_talking_con1_c5ca2aae:

    # Celia "(Ugh... I don’t want it to end, and I can’t stop myself.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:891
translate chinese CeR2_NS2_talking_con1_273b0c56:

    # Celia "(I’ve never been so horny in my entire life!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:894
translate chinese CeR2_NS2_talking_con1_b245b089:

    # Celia "(And that means I need to access his home computer.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:895
translate chinese CeR2_NS2_talking_con1_58074514:

    # Celia "(Let’s find if this bastard has me as a webcam contact. Once I’ve seen that I’ll know for certain who is behind this. Big Jake or [player_name].)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:897
translate chinese CeR2_NS2_talking_con1_66731c26:

    # Celia "(Hmm... What if I went to [player_name]’s bedroom and took the fantasy to where he lives?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS2.rpy:898
translate chinese CeR2_NS2_talking_con1_6ddb6665:

    # Celia "(Yeah! I’ll check out his PC and see if he has me as a webcam contact. Then I can “confront” him in person and FINALLY turn this fantasy around to me being in control!)"
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R2/CeR2_NS2.rpy:764
    old "Scream for help"
    new ""

    # game/scripts/Ce_R2/CeR2_NS2.rpy:764
    old "Stay silent"
    new ""

