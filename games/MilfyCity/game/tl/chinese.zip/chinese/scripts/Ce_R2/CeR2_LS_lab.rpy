﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:175
translate chinese CeR2_LS_lab_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:176
translate chinese CeR2_LS_lab_5db555d5:

    # Celia "Good morning to you too. You look like you have barely slept a wink."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:177
translate chinese CeR2_LS_lab_3d8f3175:

    # MC "I barely slept..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:178
translate chinese CeR2_LS_lab_008ac47d:

    # MC "(And it’s the stress that you’re putting me under that’s causing it!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:180
translate chinese CeR2_LS_lab_c3103add:

    # Celia "Well, perk up! You’re no good as a sex slave if you’re going to fall asleep on me!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:181
translate chinese CeR2_LS_lab_baa4f1cb:

    # MC "Ugh..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:182
translate chinese CeR2_LS_lab_9bacdaeb:

    # Celia "And lose the attitude."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:184
translate chinese CeR2_LS_lab_cc0629ce:

    # MC "Listen Celia, I’m exhausted. What did you actually want me to come here for today?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:185
translate chinese CeR2_LS_lab_b36364b0:

    # MC "Are you expecting me to lick your pussy again? Because if you are, can we just get it over with?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:186
translate chinese CeR2_LS_lab_ab5e77b3:

    # MC "I just want to get back home and rest."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:188
translate chinese CeR2_LS_lab_7a224bcc:

    # Celia "I want you on the floor. Now."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:189
translate chinese CeR2_LS_lab_303ff584:

    # MC "So I am eating you out again."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:190
translate chinese CeR2_LS_lab_7907cea2:

    # Celia "I never said that."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:192
translate chinese CeR2_LS_lab_cad9e6a6:

    # MC "*Sigh* You implied it."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:193
translate chinese CeR2_LS_lab_5e5df4e4:

    # Celia "No, eating out my pussy isn’t humiliating enough for a pathetic piece of shit like you."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:195
translate chinese CeR2_LS_lab_ba3248dc:

    # MC "What the hell do you want me to do, then?!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:197
translate chinese CeR2_LS_lab_e0fb6b9e:

    # MC "What the hell do you want me to do then?! (What’s her game play for today?)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:199
translate chinese CeR2_LS_lab_908723b1:

    # Celia "I already told you. Get down on the floor."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:200
translate chinese CeR2_LS_lab_9ffbcfa6:

    # Celia "I want to see you on your hands and knees."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:201
translate chinese CeR2_LS_lab_a0ba16a8:

    # MC "Are you serious?!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:204
translate chinese CeR2_LS_lab_0d55f47b:

    # Celia "NOW, [player_name]! Don’t make me drag Sara or Linda into this!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:206
translate chinese CeR2_LS_lab_707b7f6c:

    # Celia "NOW, [player_name]! Don’t make me punch you again! (Though I kinda like it when he’s resisting...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:207
translate chinese CeR2_LS_lab_528631e9:

    # MC "Grr..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:208
translate chinese CeR2_LS_lab_2083f110:

    # Celia "You know that I will."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:209
translate chinese CeR2_LS_lab_438e3446:

    # MC "Fine."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:211
translate chinese CeR2_LS_lab_973cbe9a:

    # MC "(Fuck, this is so humiliating.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:213
translate chinese CeR2_LS_lab_8cd1b846:

    # MC "(I can’t do this much longer. I need to think of a way to get her to take this pill.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:215
translate chinese CeR2_LS_lab_25d06681:

    # MC "(I can’t do this much longer. I need to open up a conversation with her about switching back into a dominant role!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:217
translate chinese CeR2_LS_lab_7980e28f:

    # Celia "That’s much better. Good boy."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:218
translate chinese CeR2_LS_lab_5884d9de:

    # MC "Are you happy now? When can I get back up?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:220
translate chinese CeR2_LS_lab_1fc9175b:

    # Celia "Not for a while. I haven’t had my fun yet!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:221
translate chinese CeR2_LS_lab_c92d8e09:

    # MC "Fun? What do you mean?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:222
translate chinese CeR2_LS_lab_ea481008:

    # Celia "Don’t move an inch."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:224
translate chinese CeR2_LS_lab_66a65ca4:

    # MC "Ooff, you’re heavy!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:225
translate chinese CeR2_LS_lab_bada512f:

    # Celia "How rude! A gentleman should NEVER comment on a girl’s weight."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:227
translate chinese CeR2_LS_lab_38e9e7b0:

    # Celia "I think I’m going to sit here for a while and enjoy this."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:228
translate chinese CeR2_LS_lab_528631e9_1:

    # MC "Grr..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:229
translate chinese CeR2_LS_lab_1c9800cd:

    # MC "(Fuck, I can’t keep holding her like this forever. My arms are already beginning to hurt!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:231
translate chinese CeR2_LS_lab_f1177ba6:

    # Celia "Haha, you really are pathetic, aren’t you, [player_name]?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:232
translate chinese CeR2_LS_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:234
translate chinese CeR2_LS_lab_cc026db7:

    # Celia "The great blackmailer, reduced to nothing more than a pet."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:236
translate chinese CeR2_LS_lab_3b5c6392:

    # Celia "The guy who was in charge was reduced to nothing more than a pet."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:238
translate chinese CeR2_LS_lab_f29d89b4:

    # Celia "I want to go for a walk about my house now."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:239
translate chinese CeR2_LS_lab_b91acd9f:

    # MC "You want me to carry you around your own apartment?!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:240
translate chinese CeR2_LS_lab_7dede3ce:

    # Celia "You’ve got working ears, don't you?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:242
translate chinese CeR2_LS_lab_897f30c8:

    # Celia "Chop, chop! Get a move on!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:244
translate chinese CeR2_LS_lab_d086b030:

    # MC "(I can’t handle this much longer... but if I fight back she’ll just kick my ass.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:246
translate chinese CeR2_LS_lab_c1ad3c67:

    # MC "(Ooof, she’s heavy!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:248
translate chinese CeR2_LS_lab_4ac08b1a:

    # Celia "Oh, I almost forgot about that time you spanked me."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:249
translate chinese CeR2_LS_lab_a32cf678:

    # Celia "I really should repay that favour, shouldn’t I?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:252
translate chinese CeR2_LS_lab_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:253
translate chinese CeR2_LS_lab_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:254
translate chinese CeR2_LS_lab_dcd615c8:

    # Celia "Ahahaha!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:256
translate chinese CeR2_LS_lab_528631e9_2:

    # MC "Grr..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:257
translate chinese CeR2_LS_lab_8fb26ce8:

    # Celia "How does it feel to be the one getting degraded and humiliated? Pretty shit, right?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:259
translate chinese CeR2_LS_lab_ea74b1bf:

    # Celia "Now think about how I fucking felt!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:260
translate chinese CeR2_LS_lab_ab3b3ce7:

    # Celia "Imagine being forced to strip naked on webcam for some fucking creep!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:261
translate chinese CeR2_LS_lab_73dde587:

    # Celia "Imagine not knowing if naked pictures of you were going to show up online!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:263
translate chinese CeR2_LS_lab_5d4182f2:

    # Celia "This might feel bad, but trust me, it pales in comparison to what you did to me."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:264
translate chinese CeR2_LS_lab_d7a5a987:

    # Celia "Now, take me back over to my couch."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:266
translate chinese CeR2_LS_lab_ddbe6670:

    # Celia "Ahh, that was fun."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:267
translate chinese CeR2_LS_lab_ef26d4bf:

    # MC "Can I get up now?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:269
translate chinese CeR2_LS_lab_f3f53d55:

    # Celia "Haha, alright. You can stand on your feet."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:270
translate chinese CeR2_LS_lab_fcf7cd33:

    # MC "(Thank God! My knees are killing me!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:272
translate chinese CeR2_LS_lab_b75d532b:

    # Celia "But only because I’m thirsty. Get me a drink."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:273
translate chinese CeR2_LS_lab_eac3d06a:

    # MC "Can you not get yourself a drink?!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:274
translate chinese CeR2_LS_lab_e44b7e33:

    # Celia "No, that’s a pet’s job. Fetch me something to drink. Now."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:277
translate chinese CeR2_LS_lab_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:279
translate chinese CeR2_LS_lab_78385421:

    # MC "*Sigh* (Keeping my character in this roleplay is really hard.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:280
translate chinese CeR2_LS_lab_ae2b0315:

    # Celia "And hurry up! I’m parched!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:282
translate chinese CeR2_LS_lab_0f6800dd:

    # Celia "Hmm..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:283
translate chinese CeR2_LS_lab_0b482682:

    # Celia "(What else should I make him do?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:284
translate chinese CeR2_LS_lab_5109d934:

    # Celia "(I’ve always wanted to peg a guy in the ass. Maybe I should buy a strap-on dildo and fuck him the same way he fucked me?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:289
translate chinese CeR2_LS_lab_9af71c7a:

    # MC "(Hold on! I’ve still got that sleeping pill in my pocket!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:290
translate chinese CeR2_LS_lab_6467d057:

    # MC "(Now could be my chance to spike Celia’s drink!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:292
translate chinese CeR2_LS_lab_bef36641:

    # MC "(I've still got that pill that Judy gave me! I could ask Celia if she wants to try that fantasy out now!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:293
translate chinese CeR2_LS_lab_a885b217:

    # MC "(I CAN’T fuck this up!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:295
translate chinese CeR2_LS_lab_961d0c06:

    # Celia "(Yes, I think I’ll do that. I’ll pop down to the sex shop later on this week.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:296
translate chinese CeR2_LS_lab_94a3cdcb:

    # Celia "(In the meantime, I’ll make him eat me out again. Maybe in the shower this time.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:298
translate chinese CeR2_LS_lab_0b68a837:

    # MC "(Okay, this looks like the alcohol that Celia and Gustav had been drinking when I was here before.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:300
translate chinese CeR2_LS_lab_7a15e543:

    # MC "(I should be able to spike this one easily enough.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:302
translate chinese CeR2_LS_lab_152b806c:

    # MC "(I’ll have to be quick when I do this. I don’t want her getting suspicious.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:304
translate chinese CeR2_LS_lab_06a63294:

    # MC "(I’ll pop the pill in one of these glasses and see if Celia is interested in trying it out!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:306
translate chinese CeR2_LS_lab_f37c0419:

    # MC "(Alright, here goes nothing!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:309
translate chinese CeR2_LS_lab_3511bdd8:

    # MC "(I hope to God this little pill dissolves, or this is all in vain!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:311
translate chinese CeR2_LS_lab_15790ebb:

    # MC "(Alright, I'll check one final time with Celia that she definitely wants to do this roleplay!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:312
translate chinese CeR2_LS_lab_81e28f81:

    # MC "(Here goes nothing!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:315
translate chinese CeR2_LS_lab_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:317
translate chinese CeR2_LS_lab_a67acf63:

    # MC "(I think I’ll pour two glasses. It’ll be less suspicious if I pour myself a tumbler of this drink too.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:319
translate chinese CeR2_LS_lab_acc7c26a:

    # MC "(I hope she actually wants to do this, or I’ll have to end our little roleplay fantasy.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:321
translate chinese CeR2_LS_lab_6459df9e:

    # Celia "Are you almost done?! What’s taking you so long, boy?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:322
translate chinese CeR2_LS_lab_5f53cdd6:

    # MC "Two seconds! I’m almost finished!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:324
translate chinese CeR2_LS_lab_b11b8577:

    # MC "Sorry, Ma’am. I couldn’t get the stopper out of the bottle."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:325
translate chinese CeR2_LS_lab_1add9493:

    # Celia "*Sigh* That’s to be expected from someone as inept as you."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:326
translate chinese CeR2_LS_lab_78bd00fe:

    # Celia "Oh, and it looks like you poured yourself some too?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:329
translate chinese CeR2_LS_lab_0fdc00e9:

    # MC "I was thirsty after walking you around."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:330
translate chinese CeR2_LS_lab_4eae16e9:

    # Celia "So you thought you would just take some of my cognac without asking?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:332
translate chinese CeR2_LS_lab_2cb99983:

    # Celia "Ugh, you have a lot of lessons to learn."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:333
translate chinese CeR2_LS_lab_c898a977:

    # Celia "*Sigh* Fine. You can have ONE glass. But only because I don’t want it to go to waste."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:334
translate chinese CeR2_LS_lab_20c07608:

    # MC "Thank you, Ma’am."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:336
translate chinese CeR2_LS_lab_2575a11c:

    # Celia "*Ahem*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:337
translate chinese CeR2_LS_lab_0654b1f3:

    # MC "Yes?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:339
translate chinese CeR2_LS_lab_8feb853b:

    # MC "Listen Celia, I wanted to try something a little different today. I’m gonna break character for a minute. I’m not really enjoying being a sub."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:340
translate chinese CeR2_LS_lab_b384663c:

    # Celia "Oh? You’re not? It’s not like you to break your character... (Don't tell me that he wants to end it?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:341
translate chinese CeR2_LS_lab_08b5c246:

    # MC "It’s just not for me. I enjoyed being the dominant one, but being a sub just feels... shit."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:342
translate chinese CeR2_LS_lab_68cf23f7:

    # Celia "Well, what are you proposing?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:343
translate chinese CeR2_LS_lab_35af4741:

    # MC "I've got a sedative pill in here. I was wondering if you'd be up for trying something new to let me regain control of this fantasy of roleplaying."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:344
translate chinese CeR2_LS_lab_9143ecdd:

    # Celia "You want me to take a sedative pill? Probably a strong one judging from your face... (I wonder if this shit will even work on me...?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:345
translate chinese CeR2_LS_lab_7de1f853:

    # MC "Yeah, I’ll tie you up after you take it, and then I’ll have a surprise fantasy waiting for you."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:346
translate chinese CeR2_LS_lab_aad9e406:

    # Celia "Hmm... I was gonna say no, but after hearing that you will tie me up... also what kind of surprise?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:347
translate chinese CeR2_LS_lab_9a7d681b:

    # MC "I promise, you’re going to enjoy it."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:348
translate chinese CeR2_LS_lab_1f9c6cfa:

    # Celia "Hmm... Not going to tell me? Fine, I'll bite. (I wonder what [player_name] prepared? I hope I will not be bored...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:351
translate chinese CeR2_LS_lab_5219a197:

    # Celia "Hand me my drink. Do I have to spell out EVERYTHING I want you to do?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:353
translate chinese CeR2_LS_lab_3a877c8e:

    # MC "S-Sorry, Ma’am. Here you go!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:355
translate chinese CeR2_LS_lab_9dbfa965:

    # MC "(And this is the last order I EVER take from you.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:357
translate chinese CeR2_LS_lab_a40cd92f:

    # MC "(I’m surprised she actually agreed! Judy did say it was okay as long as she consented.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:359
translate chinese CeR2_LS_lab_751a17ef:

    # Celia "See? That wasn’t so bad, was it?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:360
translate chinese CeR2_LS_lab_9ee57117:

    # MC "No, Ma’am."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:362
translate chinese CeR2_LS_lab_3988250c:

    # Celia "Good. Drink up. I have a lot of other activities planned for today. Gustav isn’t back, so I have you all to myself."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:364
translate chinese CeR2_LS_lab_e2871bd9:

    # Celia "Good. Drink up. I have a lot of other activities planned for today. Gustav isn’t back, so I have you all to myself. I don’t think that this sedative pill will help you in any way, so let’s back to my game."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:366
translate chinese CeR2_LS_lab_989d42b8:

    # Celia "*Glug Glug*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:367
translate chinese CeR2_LS_lab_fa931ef2:

    # MC "(Drink up, bitch.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:368
translate chinese CeR2_LS_lab_e8ffd01b:

    # MC "Haha..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:370
translate chinese CeR2_LS_lab_0910d260:

    # Celia "Is something funny?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:371
translate chinese CeR2_LS_lab_a327c665:

    # MC "Not at all."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:373
translate chinese CeR2_LS_lab_15f377be:

    # Celia "What are you smiling at? Don’t tell me you’re getting off on being degraded like this."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:375
translate chinese CeR2_LS_lab_8b684ece:

    # Celia "What are you smiling at? Don’t tell me that you thought that this sedative pill would take me on. Come on, that was your whole plan?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:377
translate chinese CeR2_LS_lab_27539eea:

    # MC "Oh God, not at all."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:378
translate chinese CeR2_LS_lab_0f6800dd_1:

    # Celia "Hmm..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:379
translate chinese CeR2_LS_lab_96139daf:

    # Celia "If you thought crawling around on your hands and knees was bad, just wait till tonight. I’m going to have you doing far worse things."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:381
translate chinese CeR2_LS_lab_18cd7f53:

    # MC "And if I refuse?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:382
translate chinese CeR2_LS_lab_5c0e314b:

    # Celia "Do I seriously have to keep reminding you of the consequences?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:384
translate chinese CeR2_LS_lab_6f7c4e43:

    # MC "(I just have to buy myself enough time for her to finish off her drink.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:386
translate chinese CeR2_LS_lab_4812e085:

    # MC "(And she seems to be drinking up!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:388
translate chinese CeR2_LS_lab_d2f9d7e9:

    # Celia "If you don’t do as I say, then *YAAAAWN* I’ll..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:389
translate chinese CeR2_LS_lab_0654b1f3_1:

    # MC "Yes?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:391
translate chinese CeR2_LS_lab_1a57de50:

    # Celia "...I’ll umm... I’ll tell Linda about everything you’ve done."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:393
translate chinese CeR2_LS_lab_03c77540:

    # Celia "...I'll hmm... I'll tell... (Ugh... I'm sleepy... That small pill is really working...?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:395
translate chinese CeR2_LS_lab_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:396
translate chinese CeR2_LS_lab_b66b77bf:

    # MC "(She’s beginning to doze off! I think it’s working!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:398
translate chinese CeR2_LS_lab_135c0b00:

    # Celia "*Glug*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:399
translate chinese CeR2_LS_lab_c5b7e40d:

    # MC "(That’s it, drink every last drop! Mwahahaha!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:401
translate chinese CeR2_LS_lab_803c9c0c:

    # Celia "*Yawn*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:402
translate chinese CeR2_LS_lab_8306313e:

    # Celia "Actually... we might do *yawn* our next session after I take a short... nap."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:403
translate chinese CeR2_LS_lab_c5eb1ccc:

    # MC "Are you sure? You’re looking rather sleepy."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:405
translate chinese CeR2_LS_lab_c1b27578:

    # Celia "Ugh, my head..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:406
translate chinese CeR2_LS_lab_2e12f8e3:

    # MC "What’s wrong, Celia? Can’t hold your alcohol?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:409
translate chinese CeR2_LS_lab_06ceed26:

    # Celia "Y-You fucker! You’ve done something to my drink!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:410
translate chinese CeR2_LS_lab_528109ae:

    # MC "Haha, I don’t know what you’re talking about."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:412
translate chinese CeR2_LS_lab_3a281440:

    # Celia "Y-You fucker! That pill is strong! What is your plan for today!?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:413
translate chinese CeR2_LS_lab_740a1c4a:

    # MC "Haha! I don’t know! Besides, now you’re breaking your character Celia!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:415
translate chinese CeR2_LS_lab_1d9986a0:

    # Celia "(Fuck! I have to get out of here before I pass out!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:417
translate chinese CeR2_LS_lab_56483f9f:

    # Celia "(My panties are soaking right now... I wonder what way I’m going to find myself when I finally wake up.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:419
translate chinese CeR2_LS_lab_7a024437:

    # MC "You’re overreacting, Celia. I haven’t put anything in your drink."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:420
translate chinese CeR2_LS_lab_bc85f71f:

    # Celia "(I have to... I have to get...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:422
translate chinese CeR2_LS_lab_d10fb0eb:

    # MC "Well, nothing except a little drug to help you sleep."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:424
translate chinese CeR2_LS_lab_f19a03ef:

    # MC "Well, nothing except that sedative pill... You were too sure of yourself, Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:426
translate chinese CeR2_LS_lab_66ae9775:

    # Celia "Y... You... bastard..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:427
translate chinese CeR2_LS_lab_d855cace:

    # MC "Goodnight, Celia. Sweet dreams."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:429
translate chinese CeR2_LS_lab_130dfb06:

    # Celia "(Shit... He’s going to... be able to do whatever he wants with my body while I’m asleep...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:431
translate chinese CeR2_LS_lab_8bf8e945:

    # Celia "(Mmm... He’s going to... be able to do whatever he wants with my body while I’m asleep... That’s so... fucking hot...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:436
translate chinese CeR2_LS_lab_3937d7b6:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:437
translate chinese CeR2_LS_lab_c207974d:

    # MC "Mwahahaha!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:439
translate chinese CeR2_LS_lab_7d598253:

    # MC "This is the end, Celia. I don’t know if you can hear me right now, but if you can..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:440
translate chinese CeR2_LS_lab_aefc9091:

    # MC "You almost had me. You were SO close to winning. You were stronger than me, and probably a lot smarter than I am too."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:441
translate chinese CeR2_LS_lab_d96ce073:

    # MC "But you forgot one thing - I’m far more crafty than you ever were."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:443
translate chinese CeR2_LS_lab_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:444
translate chinese CeR2_LS_lab_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:446
translate chinese CeR2_LS_lab_6cb15a81:

    # MC "And one last thing..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:447
translate chinese CeR2_LS_lab_3937d7b6_1:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:448
translate chinese CeR2_LS_lab_7874cbd7:

    # MC "Your cognac sucks."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:450
translate chinese CeR2_LS_lab_cbba3ffb:

    # MC "I’m off to grab a very special toy for you, Celia. I think you’ll enjoy it."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:451
translate chinese CeR2_LS_lab_7aaa88c6:

    # MC "Stay right there. I’ll be back."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:452
translate chinese CeR2_LS_lab_44fcbaef:

    # Celia "*SNORE*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:456
translate chinese CeR2_LS_lab_1cf0eb51:

    # MC "(Here we go. That’s the toy all charged up and ready to use!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:457
translate chinese CeR2_LS_lab_47bc4db2:

    # MC "(Time to give Celia the shock of her life!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:459
translate chinese CeR2_LS_lab_186cdb01:

    # MC "(Okay, I’ll just get her undressed, first of all.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:460
translate chinese CeR2_LS_lab_3c7c7464:

    # MC "(Once I get this bad boy inside her, she won’t be able to contain her excitement!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:462
translate chinese CeR2_LS_lab_8b9ee6fd:

    # MC "(Easy does it... I don’t want to wake her up yet.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:463
translate chinese CeR2_LS_lab_3937d7b6_2:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:464
translate chinese CeR2_LS_lab_08175398:

    # MC "(There’s probably not a big chance of that happening anyway. Whatever Judy gave me seems to be really strong stuff!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:466
translate chinese CeR2_LS_lab_ad2a2e9b:

    # MC "(Alright, I just have to take these panties off her.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:467
translate chinese CeR2_LS_lab_0cb49de6_1:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:469
translate chinese CeR2_LS_lab_4e023640:

    # MC "(Haha, this thing is going to destroy her pussy!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:470
translate chinese CeR2_LS_lab_e3ddf273:

    # MC "(And judging from what I’ve seen so far, I know she is going to love every second of this punishment!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:472
translate chinese CeR2_LS_lab_786ce310:

    # MC "(That rope ought to hold the toy in place, no matter how much she wriggles around or tries to fight it.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:473
translate chinese CeR2_LS_lab_c4134c96:

    # MC "(Now I simply have to wait for her to wake up!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:475
translate chinese CeR2_LS_lab_3e5e9126:

    # MC "(Oh! And before I forget, I better catch this whole thing on camera.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:477
translate chinese CeR2_LS_lab_d35264af:

    # MC "(Partially for blackmail, and partially because it’ll be REALLY fucking hot to watch it happen again!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:479
translate chinese CeR2_LS_lab_ce71d066:

    # MC "(I think we’re BOTH going to love watching her reaction get recorded!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:481
translate chinese CeR2_LS_lab_3937d7b6_3:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:482
translate chinese CeR2_LS_lab_52fabdf3:

    # MC "(I wonder how much longer she’ll be asleep for.)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:484
translate chinese CeR2_LS_lab_0cb49de6_2:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:485
translate chinese CeR2_LS_lab_495ec048:

    # MC "Hey, Celia! Time to wake up!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:486
translate chinese CeR2_LS_lab_3937d7b6_4:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:488
translate chinese CeR2_LS_lab_fb451634:

    # MC "Hey! Nap time’s over!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:489
translate chinese CeR2_LS_lab_55df4a1e:

    # Celia "Ugh... Huh?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:490
translate chinese CeR2_LS_lab_15008554:

    # Celia "What... Where?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:492
translate chinese CeR2_LS_lab_d63dce95:

    # Celia "YOU!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:494
translate chinese CeR2_LS_lab_88e1d6dd:

    # Celia "Wh-What the FUCK did you do to me?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:496
translate chinese CeR2_LS_lab_c8590271:

    # Celia "Wh-What the FUCK did you do to me?! (Fuck... That pill really took me down...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:498
translate chinese CeR2_LS_lab_741f4c96:

    # MC "Nice to see you too."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:500
translate chinese CeR2_LS_lab_f3cf41a1:

    # Celia "Y-You spiked my fucking drink!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:502
translate chinese CeR2_LS_lab_113bc22e:

    # Celia "Y-You spiked my fucking drink! (Let’s stop breaking character for now... Let’s check what [player_name] prepared for me...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:503
translate chinese CeR2_LS_lab_37f5ad1a:

    # MC "Guilty as charged. I wouldn’t raise your voice at me if I was you though. You’re in no position to-"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:505
translate chinese CeR2_LS_lab_7c39daa7:

    # Celia "I’m going to wring your fucking neck!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:506
translate chinese CeR2_LS_lab_4aeb970f:

    # MC "*Sigh* I tried to warn you."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:511
translate chinese after_e_mg1_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:512
translate chinese after_e_mg1_fe10e82b:

    # Celia "Huh?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:515
translate chinese after_e_mg1_75359e15:

    # "*BUZZZZZZZZ*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:516
translate chinese after_e_mg1_ccebb97c:

    # Celia "Ahhh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:518
translate chinese after_e_mg1_9b3dabdf:

    # MC "Electroshock vibrating dildo."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:519
translate chinese after_e_mg1_0475866a:

    # Celia "AHHHH!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:520
translate chinese after_e_mg1_af6fa863:

    # MC "Oh yeah, I know about your dirty little secret."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:522
translate chinese after_e_mg1_1f11b3eb:

    # Celia "Give me that fucking remote! (So THAT was his plan!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:523
translate chinese after_e_mg1_123a154b:

    # MC "Ah, ah! Don’t you swear at your master like that!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:524
translate chinese after_e_mg1_00c44850:

    # Celia "Master? Haha! I said, give me the-"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:529
translate chinese after_e_mg2_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:532
translate chinese after_e_mg2_2018962a:

    # "*BUZZZZZZZ*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:533
translate chinese after_e_mg2_e0be45da:

    # Celia "AYAAAHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:535
translate chinese after_e_mg2_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:536
translate chinese after_e_mg2_a79ede7b:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:537
translate chinese after_e_mg2_4224fa45:

    # MC "I bet it feels good, doesn’t it? The pleasure and pain combining together like that."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:539
translate chinese after_e_mg2_b378791d:

    # MC "There’s going to be a few changes around here."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:540
translate chinese after_e_mg2_08a48f7d:

    # MC "To begin with, you’re not getting called Ma’am any longer. You’re “slut” now. Do you understand that, slut?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:541
translate chinese after_e_mg2_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:543
translate chinese after_e_mg2_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:544
translate chinese after_e_mg2_f4ce0a1e:

    # Celia "Fuck you, you piece of shi-"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:549
translate chinese after_e_mg3_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:552
translate chinese after_e_mg3_75359e15:

    # "*BUZZZZZZZZ*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:553
translate chinese after_e_mg3_65cb33b0:

    # Celia "AARRGGHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:555
translate chinese after_e_mg3_11d15bb3:

    # Celia "(H-Holy fuck! This thing is going to make me cum!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:556
translate chinese after_e_mg3_9d267a28:

    # Celia "S-Stop this!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:557
translate chinese after_e_mg3_9e2fd965:

    # MC "Sorry slut, you need to be punished."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:559
translate chinese after_e_mg3_d3e79833:

    # Celia "Stop pushing that-"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:560
translate chinese after_e_mg3_764e041e:

    # MC "Don’t touch my leg."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:562
translate chinese after_e_mg3_1b570a41:

    # Celia "Ahh! S-Stop! It’s too intense!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:564
translate chinese after_e_mg3_05cb7b05:

    # Celia "Ahh! S-Stop! It’s too intense! (Ah... Where did he get that amazing stuff from!?)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:565
translate chinese after_e_mg3_3edd6e66:

    # MC "I said, don’t touch my leg!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:566
translate chinese after_e_mg3_4277db2f:

    # Celia "[player_name], stop the-"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:569
translate chinese after_e_mg3_09d06ab8_1:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:571
translate chinese after_e_mg3_09d06ab8_2:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:573
translate chinese after_e_mg3_09d06ab8_3:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:577
translate chinese after_e_mg3_06bc4ca8:

    # "*BUZZZZZZZZZZZZZZZZZZZZ*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:578
translate chinese after_e_mg3_343c2629:

    # Celia "AYYYAAAHHHHHHHH! I’M CUMMMING!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:579
translate chinese after_e_mg3_6fcaa387:

    # Celia "HOLY FUCK! I’M CUMMING!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:581
translate chinese after_e_mg3_ce75e69a:

    # MC "I told you not to touch me!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:582
translate chinese after_e_mg3_916cc768:

    # MC "I am NOT your pet anymore! You’re MINE now! It’s time you got that into your head, slut!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:584
translate chinese after_e_mg3_873c6969:

    # Celia "*Pant* *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:585
translate chinese after_e_mg3_5d2ea7aa:

    # MC "Is that clear?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:586
translate chinese after_e_mg3_9b4ca9e4:

    # Celia "I... I... *Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:588
translate chinese after_e_mg3_83430ff9:

    # MC "I said, is that clear, slut?!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:589
translate chinese after_e_mg3_3c26e5ea:

    # Celia "Y... *Gasp* Yes..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:590
translate chinese after_e_mg3_fc3ac46e:

    # MC "Good."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:592
translate chinese after_e_mg3_09d06ab8_4:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:594
translate chinese after_e_mg3_32322e60:

    # Celia "Ahhhhh!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:595
translate chinese after_e_mg3_7cc11428:

    # Celia "(How the fuck did he find a toy this powerful?!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:596
translate chinese after_e_mg3_49053bb3:

    # MC "Let’s crank this bad boy up and see what he can do!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:603
translate chinese after_e_mg3_4488bfef:

    # "*CLICK CLICK CLICK*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:606
translate chinese after_e_mg3_4fed9faa:

    # Celia "AHHHH! HNNNGGG!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:607
translate chinese after_e_mg3_072e64d3:

    # Celia "OHHHH!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:608
translate chinese after_e_mg3_30d3a39d:

    # Celia "FUCK! C-CUMMMING!! AAYAAHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:610
translate chinese after_e_mg3_2a94aead:

    # Celia "Ahh... Ahh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:611
translate chinese after_e_mg3_6148f0eb:

    # Celia "*Pant* *Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:612
translate chinese after_e_mg3_67ebbe66:

    # MC "Are you still conscious, there?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:613
translate chinese after_e_mg3_4085741e:

    # Celia "*Pant* Ah... I... "
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:615
translate chinese after_e_mg3_18821a94:

    # MC "Sorry, I can’t quite hear you! I’m going to turn up the power again."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:617
translate chinese after_e_mg3_87801311:

    # Celia "N-N-No... *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:619
translate chinese after_e_mg3_f14e3654:

    # Celia "N-N-No... *Gasp* (It feels amazing... I LOVE IT!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:621
translate chinese after_e_mg3_a1f184e9:

    # "*CLICK*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:624
translate chinese after_e_mg3_34672a8f:

    # "*BUZZZZZ*"
    ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:625
translate chinese after_e_mg3_50dea6a3:

    # Celia "AAAHHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:626
translate chinese after_e_mg3_18440852:

    # Celia "(My entire pussy is exploding with pleasure! I can’t take it anymore!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:628
translate chinese after_e_mg3_b3d79890:

    # MC "This could have been so much easier, Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:629
translate chinese after_e_mg3_27c7a2a4:

    # MC "All you had to do was agree to be my girlfriend, or be polite when you turned me down."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:630
translate chinese after_e_mg3_eea7609e:

    # Celia "Ahhhhh!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:631
translate chinese after_e_mg3_1744c37e:

    # MC "You brought this upon yourself."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:633
translate chinese after_e_mg3_9a2db28b:

    # MC "I’m going to untie you now. I doubt you have the strength to fight back at this point."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:634
translate chinese after_e_mg3_4b892d96:

    # Celia "*Gasp* *Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:636
translate chinese after_e_mg3_58186086:

    # MC "There we go."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:637
translate chinese after_e_mg3_760b5ac4:

    # Celia "Ah... Hah... Ahh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:638
translate chinese after_e_mg3_43de5c02:

    # MC "You’re a wreck, aren’t you?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:640
translate chinese after_e_mg3_23469447:

    # MC "The great Celia, laid low by a fancy dildo. Everyone has their weaknesses, I guess."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:641
translate chinese after_e_mg3_9517a055:

    # Celia "*Pant* I..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:642
translate chinese after_e_mg3_2d74da6f:

    # MC "Did you say something?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:644
translate chinese after_e_mg3_5934615e:

    # Celia "*Pant* Wh... What are you... going to do to me?"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:645
translate chinese after_e_mg3_9b6e17ec:

    # MC "Oh, I’m going to fuck you now."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:646
translate chinese after_e_mg3_d29958f8:

    # Celia "You won't get... away with this... It will only help you once, and then you’ll be mine again..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:648
translate chinese after_e_mg3_4167ba7c:

    # MC "Oh! You’re completely wrong, Celia. I have prepared everything so I won’t be on the sub side anymore!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:649
translate chinese after_e_mg3_8325c7a9:

    # MC "See, I knew you wouldn’t go down forever. So I needed some insurance."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:651
translate chinese after_e_mg3_2ef1fdc5:

    # MC "It comes in the form of 1080p."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:652
translate chinese after_e_mg3_0c0df92c:

    # MC "You’re being recorded live as we speak, in HD. It captured each squirting climax, each scream, and each moan you made. Your crusade against me is finished."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:655
translate chinese after_e_mg3_1193fe6e:

    # Celia "N-No..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:657
translate chinese after_e_mg3_b84a9a04:

    # Celia "N-No... (Did he really even think of that...? Gustav is nothing more than a boy, in front of him - in my eyes.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:658
translate chinese after_e_mg3_7ed4c2fc:

    # MC "Oh yeah, but it’s time to get onto the fun part. Excuse me while I get undressed."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:660
translate chinese after_e_mg3_041648e4:

    # MC "Much better!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:661
translate chinese after_e_mg3_a79ede7b:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:662
translate chinese after_e_mg3_2f0451b2:

    # MC "What’s wrong? Too weak to get yourself off the table?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:664
translate chinese after_e_mg3_cc399410:

    # MC "I guess all that climaxing must have left you exhausted."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:665
translate chinese after_e_mg3_cf2da95f:

    # MC "I’m going to fuck you now. And there’s nothing you can do to stop me."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:667
translate chinese after_e_mg3_7615162a:

    # Celia "Ah..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:668
translate chinese after_e_mg3_c66215f4:

    # MC "I’m going to shove my cock inside you. I’m going to fuck you really hard."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:669
translate chinese after_e_mg3_85c4028f:

    # MC "And when I cum, I’m going to flood your pussy with my semen."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:670
translate chinese after_e_mg3_7ce1d3b1:

    # Celia "W... Wait..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:672
translate chinese after_e_mg3_5930eaa0:

    # Celia "Ahhhh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:674
translate chinese after_e_mg3_c10e4e1c:

    # MC "Ugh! Damn, you’re wet, Celia!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:675
translate chinese after_e_mg3_a0459efa:

    # Celia "Ohh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:677
translate chinese after_e_mg3_64928402:

    # Celia "F-Fuck... *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:678
translate chinese after_e_mg3_1fcef346:

    # MC "Ugh! Ah! Oh yeah!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:680
translate chinese after_e_mg3_284f5374:

    # MC "If you thought that toy was destroying your pussy, then you’re in for a shock."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:682
translate chinese after_e_mg3_3c9a737b:

    # MC "It is nothing compared to what I’m going to do with my cock."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:683
translate chinese after_e_mg3_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:685
translate chinese after_e_mg3_6e5f2585:

    # MC "Mmm! Fuck, you’re so tight, Celia!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:687
translate chinese after_e_mg3_41012c3d:

    # MC "I’m going to enjoy fucking your pussy until you’re screaming my name."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:689
translate chinese after_e_mg3_1b07a0ce:

    # Celia "Ahh! *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:690
translate chinese after_e_mg3_9b22892a:

    # Celia "Ohhh!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:691
translate chinese after_e_mg3_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:693
translate chinese after_e_mg3_75aee020:

    # Celia "(I can’t take this any more! It feels soooo good!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:695
translate chinese after_e_mg3_9f46324d:

    # MC "Ugh! Hnnnng! Ah..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:697
translate chinese after_e_mg3_c3130c06:

    # Celia "(Fuck... His raw cock inside me is making me so wet and horny!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:699
translate chinese after_e_mg3_d0f56d21:

    # Celia "(I can’t keep cumming like this, or I’ll lose my mind!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:701
translate chinese after_e_mg3_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:702
translate chinese after_e_mg3_1412c334:

    # Celia "AAAHHHHHH!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:704
translate chinese after_e_mg3_478fd1d8:

    # Celia "AHHHHH!! "
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:705
translate chinese after_e_mg3_5abafc65:

    # Celia "(It’s so deep inside me!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:707
translate chinese after_e_mg3_4b0f748e:

    # MC "Mmm! Fuck! It feels so good screwing you like this, Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:708
translate chinese after_e_mg3_61e42653:

    # Celia "Ahh! Ahh! Ahhhhh!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:710
translate chinese after_e_mg3_cdbd446f:

    # MC "That’s it. Keep screaming for me!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:711
translate chinese after_e_mg3_86f205ad:

    # MC "I want to hear you give in to the pleasure!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:712
translate chinese after_e_mg3_dd889bbe:

    # MC "Hnnnngggg!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:714
translate chinese after_e_mg3_198d87bb:

    # Celia "Ayaaahhhh!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:715
translate chinese after_e_mg3_2d621dad:

    # Celia "*Pant* It’s t-too intense! Ahhhhh!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:716
translate chinese after_e_mg3_b240aa41:

    # MC "Ugh! I want you to take every single inch inside you!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:718
translate chinese after_e_mg3_d65de7af:

    # Celia "Ohhh fuck..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:720
translate chinese after_e_mg3_1e2cf340:

    # Celia "(How did he know I get turned on by choking too?! Not even Gustav knows that!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:721
translate chinese after_e_mg3_b3b71815:

    # Celia "(Have I not got ANY secrets left anymore?!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:723
translate chinese after_e_mg3_4f372a0e:

    # Celia "Y... You don’t want to aaah... do this..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:724
translate chinese after_e_mg3_2340e5ee:

    # MC "Oh yeah, I REALLY do!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:726
translate chinese after_e_mg3_7eb73f47:

    # Celia "Ahhhh! C-Cuummmiinnnnggg!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:727
translate chinese after_e_mg3_4552188a:

    # MC "(Haha, what a slut! I can’t believe she enjoys being degraded so much, like this!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:729
translate chinese after_e_mg3_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:731
translate chinese after_e_mg3_03722b9a:

    # Celia "F-Fuck... Ohhhh!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:733
translate chinese after_e_mg3_1ae6bb6e:

    # MC "Mmm! Ohhh!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:735
translate chinese after_e_mg3_ed93d934:

    # Celia "Ahhh! AHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:737
translate chinese after_e_mg3_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:738
translate chinese after_e_mg3_da5610a7:

    # Celia "Ayaaahhhhh!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:739
translate chinese after_e_mg3_c39c25ee:

    # Celia "(His cock is so fucking big! God, it’s making me cum so hard!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:741
translate chinese after_e_mg3_8284b4b0:

    # MC "You deserve this, you stupid slut! Don’t you?!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:742
translate chinese after_e_mg3_a1b7b5a0:

    # Celia "Ahh! AHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:743
translate chinese after_e_mg3_eaca089a:

    # MC "Say you deserve it!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:745
translate chinese after_e_mg3_d12da620:

    # Celia "AHH! I’M A STUPID SLUT! OHHH! I DESERVE AAHHH - THIS!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:746
translate chinese after_e_mg3_158ef57e_1:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:748
translate chinese after_e_mg3_d56617bf:

    # MC "(Time to slam this bitch’s pussy as hard as I can!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:750
translate chinese after_e_mg3_9adaacef_1:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:752
translate chinese after_e_mg3_1d63bea3:

    # MC "UGH!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:753
translate chinese after_e_mg3_e16a2a30:

    # Celia "AAHHHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:754
translate chinese after_e_mg3_381e8b63:

    # Celia "(Fuck! He’s breaking me!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:756
translate chinese after_e_mg3_46dc6b67:

    # Celia "(I’ve lost count of how many times he’s made me cum now!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:757
translate chinese after_e_mg3_c923e468:

    # Celia "(I can barely keep myself conscious!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:759
translate chinese after_e_mg3_d7722b2d:

    # MC "Don’t pass out on me, Celia!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:760
translate chinese after_e_mg3_cae90ba5:

    # MC "I’m not done with you yet!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:761
translate chinese after_e_mg3_b1ed91a7:

    # MC "I want you to be completely awake, the moment I fill your womb with my cum!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:763
translate chinese after_e_mg3_3df43045:

    # MC "Ugh! Ahh! Ohhh! Fuck!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:765
translate chinese after_e_mg3_52e2af86:

    # Celia "AHHH! AHHHHH! *PANT* AHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:767
translate chinese after_e_mg3_03cbb2fc:

    # Celia "HOLLLLYYYY SHIT! MMMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:769
translate chinese after_e_mg3_4c9b803f:

    # MC "(I can feel myself almost there. I’ll blow my load inside her soon enough!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:771
translate chinese after_e_mg3_6148f0eb_1:

    # Celia "*Pant* *Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:772
translate chinese after_e_mg3_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:774
translate chinese after_e_mg3_ecc3c616:

    # MC "Ugh! Hnnnggg!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:775
translate chinese after_e_mg3_a44206c5:

    # MC "(It feels so good slamming my cock, balls-deep into her cunt!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:777
translate chinese after_e_mg3_e41060c7:

    # Celia "F-Fuck! I’m cumming! I’M CUMMING!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:778
translate chinese after_e_mg3_dd451e80:

    # MC "Hnnnggg! So am I!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:780
translate chinese after_e_mg3_e0ec1d52:

    # Celia "N-Not inside! It’s OHHH... not safe! AHHHHH!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:781
translate chinese after_e_mg3_8d0a7651:

    # MC "HNNNNGGG!! UGH!!!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:783
translate chinese after_e_mg3_84c50a2e:

    # Celia "P-Pull out! AHHHH! OHHHH MY GODDD!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:784
translate chinese after_e_mg3_14c80818:

    # MC "(Fuck, should I cum inside her or pull out?)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:789
translate chinese after_e_mg3_fb0dc365:

    # MC "(Fuck it! I’m not respecting the wishes of a woman who publicly humiliated me, and tried to turn me into a sex slave!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:791
translate chinese after_e_mg3_906bf62f:

    # MC "(I know she loves getting creampied! She’ll really enjoy it if I fill her up!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:792
translate chinese after_e_mg3_654a6532:

    # MC "I’m cumming inside you!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:794
translate chinese after_e_mg3_9fb077c9:

    # Celia "NOOOOOHHHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:796
translate chinese after_e_mg3_e602f9cb:

    # Celia "NOOOOHHHH!!!! (YEESSSSSSS!!!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:797
translate chinese after_e_mg3_6cb8af2f:

    # MC "UUGGGHHH!! HHNNNNNGGG!!!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:806
translate chinese after_e_mg3_94af6517:

    # Celia "(Oh God! I can feel his hot cum blasting up against my cervix! Fuck! He’s filling me up!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:808
translate chinese after_e_mg3_2452de5c:

    # Celia "*Pant Pant*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:809
translate chinese after_e_mg3_bce1f5dd:

    # Celia "Y-You came inside me... *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:815
translate chinese after_e_mg3_26a0da62:

    # MC "(As much as I hate her, I’d rather not risk getting her pregnant!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:816
translate chinese after_e_mg3_99329df1:

    # MC "(I better pull out and finish somewhere safer. I’ve already had my fun breaking this bitch!)"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:817
translate chinese after_e_mg3_686d4459:

    # MC "Hnnnggg! Ugh!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:828
translate chinese after_e_mg3_3408f975:

    # Celia "*Pant* Thank God..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:833
translate chinese CeR2_LS_con_9ef5406a:

    # MC "Did you have fun, Celia?"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:835
translate chinese CeR2_LS_con_58bddff7:

    # Celia "When I *Pant* get myself... together... *Pant* I am going to the police with this!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:837
translate chinese CeR2_LS_con_b2c9c016:

    # Celia "When I *Pant* get myself... together... *Pant* I am going to-"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:839
translate chinese CeR2_LS_con_ba6b9c70:

    # MC "I told you earlier on, but I guess your brain got all scrambled when I was fucking you."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:840
translate chinese CeR2_LS_con_42147d6a:

    # MC "There’s an HD camera on my phone, right over there."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:841
translate chinese CeR2_LS_con_747d04a9:

    # MC "It’s recorded everything. Say a word to anyone, and it all goes on PornHab."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:842
translate chinese CeR2_LS_con_9361bf4f:

    # MC "Celia. It’s over."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:844
translate chinese CeR2_LS_con_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:845
translate chinese CeR2_LS_con_a58d3209:

    # MC "I’ll take that as you giving up."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:847
translate chinese CeR2_LS_con_3ad347dc:

    # Celia "Shit..."
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:849
translate chinese CeR2_LS_con_4ab32c36:

    # Celia "Shit... (He thought about everything... It’s so good being treated like that...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:851
translate chinese CeR2_LS_con_f1888447:

    # MC "Catch you later, Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:852
translate chinese CeR2_LS_con_52d2a7c9:

    # MC "You better get yourself, and your place, cleared up before Gustav comes home."
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:854
translate chinese CeR2_LS_con_a84f173b:

    # MC "Oh! And I’m taking this toy with me!"
    MC ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:856
translate chinese CeR2_LS_con_648d9d3f:

    # Celia "W-What?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:858
translate chinese CeR2_LS_con_9e675422:

    # Celia "W-What?! Y-You... "
    Celia ""

# game/scripts/Ce_R2/CeR2_LS_lab.rpy:859
translate chinese CeR2_LS_con_6b31c334:

    # Celia "(Gah, the bastard couldn’t even leave that behind for me!)"
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R2/CeR2_LS_lab.rpy:785
    old "Plant your fertile seed deep in this bitch’s womb"
    new ""

    # game/scripts/Ce_R2/CeR2_LS_lab.rpy:785
    old "Pull out and cum on Celia’s belly"
    new ""

