﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_J_q.rpy:58
translate chinese CeR2_J_q_lab_08938b2f:

    # Judy "Welcome back, [player_name]."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:59
translate chinese CeR2_J_q_lab_59630510:

    # Judy "I always knew our therapy sessions would last longer than you originally envisioned them to."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:60
translate chinese CeR2_J_q_lab_adbca3c6:

    # Judy "That’s alright. Don’t think about setting an end goal. Therapy and healing is about the journey. Now, how about you tell me what’s on your mind?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:63
translate chinese CeR2_J_q_lab_d8eb93d0:

    # MC "I need your help."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:64
translate chinese CeR2_J_q_lab_d47f513b:

    # Judy "Absolutely, that’s what I’m here for. Are you experiencing depression or suicidal thoughts?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:66
translate chinese CeR2_J_q_lab_1a0d96c5:

    # MC "No, but I’m at my wits end. I’m being bullied."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:69
translate chinese CeR2_J_q_lab_fa674373:

    # Judy "What are the names of the pupils who are bullying you?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:70
translate chinese CeR2_J_q_lab_10734e08:

    # MC "She’s not a pupil."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:71
translate chinese CeR2_J_q_lab_f4557f5a:

    # MC "It’s Ms. Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:73
translate chinese CeR2_J_q_lab_15d712aa:

    # MC "No, but I’m exhausted. Celia and me have been doing a roleplay where I was dominating her, but she’s turned the tables on me. Now I’ve got the taste of her pussy lingering in my mouth all day!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:76
translate chinese CeR2_J_q_lab_3e75afec:

    # Judy "Oh? Do tell me more."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:77
translate chinese CeR2_J_q_lab_82e7eb1c:

    # MC "She started dominating me instead. Now she’s making me lick her pussy over and over!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:78
translate chinese CeR2_J_q_lab_0b8a0ecb:

    # Judy "Oh?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:82
translate chinese CeR2_J_q_lab_29e92aa0:

    # Judy "Intriguing. Please tell me more."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:84
translate chinese CeR2_J_q_lab_e2cc446d:

    # MC "She beats me, and threatens me... She showed up at my fucking house!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:86
translate chinese CeR2_J_q_lab_e2a9e7fa:

    # MC "I was really having fun dominating her, but I’m not too keen on her dominating me."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:87
translate chinese CeR2_J_q_lab_cdd501f9:

    # MC "She’s using me like a... like a... a pet!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:90
translate chinese CeR2_J_q_lab_3468b245:

    # Judy "And you don’t like being her pet?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:91
translate chinese CeR2_J_q_lab_c9881d4a:

    # MC "What?! No! Why would I-"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:92
translate chinese CeR2_J_q_lab_371e7811:

    # Judy "Nothing, it’s just that some people are into that sort of thing."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:93
translate chinese CeR2_J_q_lab_05769a00:

    # MC "Not me."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:94
translate chinese CeR2_J_q_lab_e5cbb332:

    # Judy "How did this all start?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:96
translate chinese CeR2_J_q_lab_1c56ade5:

    # MC "She caught me blackmailing her..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:98
translate chinese CeR2_J_q_lab_83273dd0:

    # MC "I already told you that I found her altering grades for money, and then we came to a mutual agreement where I would dominate her instead of telling anyone. Such a roleplay, but for her it's really important."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:101
translate chinese CeR2_J_q_lab_163fad40:

    # Judy "Ah... right. I told you that she’s too hard to handle for a young man like you. That is really not good."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:102
translate chinese CeR2_J_q_lab_6de3a2f8:

    # MC "Please, I’m begging you. As my therapist, please help me..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:103
translate chinese CeR2_J_q_lab_4fa39ea0:

    # Judy "Slow down, draw in a deep breath, and take it from the top. Tell me all that happened."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:106
translate chinese CeR2_J_q_lab_2a92e8d2:

    # MC "I was... I found those Goddamn grades that she had changed. I wish I’d never fucking seen them now. She was altering test scores for money."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:108
translate chinese CeR2_J_q_lab_9f9dc0f3:

    # MC "And... I tried to blackmail her. It worked, for a while."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:110
translate chinese CeR2_J_q_lab_c198030d:

    # MC "It was fun at the start, we both enjoyed it!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:111
translate chinese CeR2_J_q_lab_1027d0e5:

    # Judy "How exactly did it ‘work’?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:112
translate chinese CeR2_J_q_lab_8c7ef722:

    # MC "I was having her strip and do stuff for me on webcam. She was obeying everything, so I upped the ante. I made her start... doing stuff for me in real life."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:116
translate chinese CeR2_J_q_lab_28c0cc91:

    # MC "And she fucking CAUGHT me! She figured out it was me and now my life is in ruins!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:117
translate chinese CeR2_J_q_lab_266ebeb7:

    # MC "She’s using me and abusing me! She’s just treating me like absolute shit!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:119
translate chinese CeR2_J_q_lab_c5eb6e79:

    # MC "But now she’s flipped the script - and I’m not used to be submissive like that!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:120
translate chinese CeR2_J_q_lab_d0b361d0:

    # MC "I just really want things to go back to the way they were, but she’s NEVER breaking character in this roleplay!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:123
translate chinese CeR2_J_q_lab_f2b03551:

    # MC "I can’t take it anymore. Every single day of my life I’m being treated like her fucking slave."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:124
translate chinese CeR2_J_q_lab_52a20835:

    # Judy "Hmm... Kind of like you did to her?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:127
translate chinese CeR2_J_q_lab_79cfa724:

    # MC "I..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:128
translate chinese CeR2_J_q_lab_26567932:

    # Judy "And that, is a classic moment of self-realisation."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:130
translate chinese CeR2_J_q_lab_709f2a2d:

    # Judy "Celia is only repaying in kind what you have done to her. How would you feel if she had blackmailed you into stripping on webcam for her?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:132
translate chinese CeR2_J_q_lab_fcb4c1c0:

    # Judy "Celia is only repaying in kind what you did to her. She enjoyed what you were doing, and now thinks that you also enjoy being humiliated."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:133
translate chinese CeR2_J_q_lab_1c9fabee:

    # MC "I... I need to apologise..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:136
translate chinese CeR2_J_q_lab_cc8d5663:

    # Judy "No! You need to fight fire with fire."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:137
translate chinese CeR2_J_q_lab_19570c32:

    # MC "What?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:138
translate chinese CeR2_J_q_lab_cd616c83:

    # Judy "I’m saying you have to fight back. Don’t let Celia get the best of you."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:141
translate chinese CeR2_J_q_lab_2ede6e6a:

    # MC "But... isn’t therapy supposed to be about finding peace and-"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:142
translate chinese CeR2_J_q_lab_8680207c:

    # Judy "This is Freudian therapy. A big part of Freud’s theory is finding peace through revenge."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:143
translate chinese CeR2_J_q_lab_5daab424:

    # MC "Really? I don’t ever remember hearing about that... like anywhere, ever."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:146
translate chinese CeR2_J_q_lab_ebf2d696:

    # Judy "Have you ever studied Psychology?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:147
translate chinese CeR2_J_q_lab_bf09af38:

    # MC "No, but-"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:148
translate chinese CeR2_J_q_lab_476c0e13:

    # Judy "Then why do you think you know better than your therapist?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:151
translate chinese CeR2_J_q_lab_006793bc:

    # MC "...I guess you’re right?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:152
translate chinese CeR2_J_q_lab_33963c26:

    # MC "What are you doing over there?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:153
translate chinese CeR2_J_q_lab_a26da760:

    # Judy "I’ve got a present for you, [player_name]."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:156
translate chinese CeR2_J_q_lab_e7048414:

    # MC "A key? What for?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:157
translate chinese CeR2_J_q_lab_0ac090ea:

    # Judy "Celia’s home."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:159
translate chinese CeR2_J_q_lab_a06ef234:

    # MC "Her home?! Are you fucking insane?! If she catches me there she’ll cut my head off!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:162
translate chinese CeR2_J_q_lab_c5415075:

    # Judy "Take the key, [player_name]. It’s your only escape from this hell."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:164
translate chinese CeR2_J_q_lab_8426f736:

    # MC "Her home?! Are you fucking insane?! Where did you even get that?!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:167
translate chinese CeR2_J_q_lab_a1229c6c:

    # Judy "Take the key, [player_name]. It’s the best way for you to get back on top, here."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:169
translate chinese CeR2_J_q_lab_e261d2bb:

    # MC "How did you even get these?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:170
translate chinese CeR2_J_q_lab_c7385c72:

    # Judy "I would rather not say."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:174
translate chinese CeR2_J_q_lab_3b3def0b:

    # Judy "I had a feeling you would get caught, sooner or later. Nothing lasts forever, after all."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:176
translate chinese CeR2_J_q_lab_4847321d:

    # Judy "This was going to happen sooner or later, [player_name]. Nothing lasts forever, after all."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:177
translate chinese CeR2_J_q_lab_ca4c9bff:

    # Judy "I have my suspicions about Celia. I think I have a solution to this mess you find yourself in. It’s going to require some work though."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:178
translate chinese CeR2_J_q_lab_05f6d717:

    # MC "What do I need to do?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:181
translate chinese CeR2_J_q_lab_8457c202:

    # Judy "Firstly, sneak into Celia’s house. I suspect she has some rather... unusual sexual fetishes."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:182
translate chinese CeR2_J_q_lab_1a58ca1b:

    # Judy "I want you to gather evidence of this for me. Once we know what she’s into, we’ll be able to formulate a plan to help you escape this predicament."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:185
translate chinese CeR2_J_q_lab_8a2270ac:

    # MC "This doesn’t sound safe..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:186
translate chinese CeR2_J_q_lab_50b4bf84:

    # Judy "It won’t be. Celia is very skilled at martial arts. If you get caught, you’ll be in for a beating."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:187
translate chinese CeR2_J_q_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:190
translate chinese CeR2_J_q_lab_ed81f0fe:

    # MC "I... I can’t do this..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:192
translate chinese CeR2_J_q_lab_1d26e801:

    # Judy "And you’d rather live your life as her pet? Bullied and beaten every single day, for her amusement."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:194
translate chinese CeR2_J_q_lab_5a38f8c3:

    # Judy "And you’d rather live as her sub? Licking her pussy every day for her amusement?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:195
translate chinese CeR2_J_q_lab_7a01cb0a:

    # MC "No..."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:198
translate chinese CeR2_J_q_lab_17c52466:

    # Judy "*Mwah*"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:199
translate chinese CeR2_J_q_lab_ccd43c58:

    # MC "Huh?!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:202
translate chinese CeR2_J_q_lab_e8c68179:

    # Judy "Celia might be strong and confident, but so are you."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:203
translate chinese CeR2_J_q_lab_6671c245:

    # Judy "You are the one who was brave enough to ask her out, after all."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:204
translate chinese CeR2_J_q_lab_90370e24:

    # MC "I... I guess so. Alright, I’ll do it."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:207
translate chinese CeR2_J_q_lab_fdd4efcc:

    # Judy "Go and get her, tiger! Find that evidence and bring it back to me."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:208
translate chinese CeR2_J_q_lab_7ba3c999:

    # Judy "We’ll get you out of this mess together."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:211
translate chinese CeR2_J_q_lab_e6e81d8a:

    # Judy "(God, I love my job!)"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:212
translate chinese CeR2_J_q_lab_cd5dbea2:

    # Judy "(I wonder when Samantha comes in for therapy again... I’m really close to a breakthrough with that girl.)"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:213
translate chinese CeR2_J_q_lab_cc932b2a:

    # Judy "(Breaking through her panties, that is! Hahaha!)"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:236
translate chinese CeR2_J_q_lab2_e5aefa7e:

    # Judy "I’m very glad to see you again, [player_name]. Before we begin our therapy session, I would like to do a short recap. May I?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:237
translate chinese CeR2_J_q_lab2_556a6392:

    # MC "Go ahead."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:239
translate chinese CeR2_J_q_lab2_07e1c99a:

    # Judy "When we left, off you were being harassed by your professor, Ms. Celia. Is that a fair assessment?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:241
translate chinese CeR2_J_q_lab2_ca97ea42:

    # Judy "When we left, off you were being dominated by your professor, Ms. Celia. Is that a fair assessment?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:244
translate chinese CeR2_J_q_lab2_dcee7422:

    # MC "Ah, yeah. I guess so."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:245
translate chinese CeR2_J_q_lab2_7a3a0ca3:

    # Judy "We concluded last session’s therapy with you finding a key on the floor of my office."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:246
translate chinese CeR2_J_q_lab2_71c2a5db:

    # MC "The one you gave me?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:247
translate chinese CeR2_J_q_lab2_86aca68e:

    # Judy "The one you found. On the floor."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:248
translate chinese CeR2_J_q_lab2_0f49b9be:

    # MC "Ahh, gotcha."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:249
translate chinese CeR2_J_q_lab2_e4e443ac:

    # Judy "Finally, we agreed that you would visit Ms. Celia’s place and try to locate evidence of sexual abnormality. Did you manage to locate anything?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:252
translate chinese CeR2_J_q_lab2_4dda8472:

    # MC "Abso-fucking-lutely."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:253
translate chinese CeR2_J_q_lab2_ecc8f3dc:

    # Judy "Oh, really? Please elaborate."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:254
translate chinese CeR2_J_q_lab2_4fd54a75:

    # MC "She’s into EVERYTHING. I’m talking electrical stimulation, pain, choking, nipple pinching. You name it, she probably loves it."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:257
translate chinese CeR2_J_q_lab2_b307d1ba:

    # Judy "How fascinating..."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:258
translate chinese CeR2_J_q_lab2_56840d3b:

    # Judy "(I don’t recall ever having heard of an actual subject who enjoys electrical stimulation. Not outside of some of the more obscure journals on the topic, at least.)"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:261
translate chinese CeR2_J_q_lab2_03224d2b:

    # MC "Oh! Did I mention she enjoys getting electrocuted?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:262
translate chinese CeR2_J_q_lab2_66381628:

    # Judy "Yes, you did. It’s certainly a quaint fetish."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:265
translate chinese CeR2_J_q_lab2_1c0cb43d:

    # Judy "Do you know what you’re going to do now, [player_name]?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:266
translate chinese CeR2_J_q_lab2_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:267
translate chinese CeR2_J_q_lab2_d005ffe4:

    # Judy "You’re going to take the fight back to Celia, and she’s going to be putty in your hands once more."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:271
translate chinese CeR2_J_q_lab2_da1138f2:

    # MC "I dunno... I was just kinda hoping to get out of this situation alive."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:273
translate chinese CeR2_J_q_lab2_7b3f0262:

    # MC "I dunno... I was just kinda thinking of calling things off maybe?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:274
translate chinese CeR2_J_q_lab2_53b0c173:

    # MC "Maybe just a clean break and escape from her? "
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:275
translate chinese CeR2_J_q_lab2_d6c44a08:

    # MC "I can live with awkwardly passing each other in the hallways for the next couple of years."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:278
translate chinese CeR2_J_q_lab2_980950ca:

    # Judy "But that isn’t what you really want, [player_name]. Is it? You want to fuck her."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:279
translate chinese CeR2_J_q_lab2_c4a5e95b:

    # Judy "You can fuck her again. You can make her your little fucktoy, and she will enjoy every second of it."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:282
translate chinese CeR2_J_q_lab2_6c8ea2a8:

    # Judy "All you have to do is trust me."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:283
translate chinese CeR2_J_q_lab2_82e92613:

    # Judy "I have worked with Ms. Celia for many years - I know what makes that woman tick. I know how she thinks, I know how she behaves, how she acts."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:284
translate chinese CeR2_J_q_lab2_138879ac:

    # Judy "If you push for a stalemate now, then you’ve lost. Because you already have Ms. Celia by the proverbial gonads."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:287
translate chinese CeR2_J_q_lab2_d710e2a5:

    # MC "A-Alright, let’s do this, then! What should I do?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:288
translate chinese CeR2_J_q_lab2_17ebb8e8:

    # Judy "If you want to do this properly, then it is of utmost importance that you listen to all of my instructions, and follow them through to completion."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:289
translate chinese CeR2_J_q_lab2_58339f54:

    # MC "Sure! Anything!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:292
translate chinese CeR2_J_q_lab2_cda49cd4:

    # Judy "I want you to take this pill."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:293
translate chinese CeR2_J_q_lab2_fa4afdd4:

    # MC "What does it do?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:297
translate chinese CeR2_J_q_lab2_91126a1c:

    # Judy "It’s a powerful sedative. It should knock Ms. Celia out for a full hour, at the very least."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:298
translate chinese CeR2_J_q_lab2_14ae188c:

    # Judy "Slip it in once of her drinks. One she consumes it, wait for it to take full effect."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:300
translate chinese CeR2_J_q_lab2_c9bab3d0:

    # Judy "It’s a powerful sedative. Ask Ms. Celia if you can put it in her drink. She’ll enjoy being knocked out. That way you can surprise her with your new dominant role."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:301
translate chinese CeR2_J_q_lab2_2e3c7b6b:

    # Judy "Ask her permission, and once she takes it, just wait for it to take effect. Simple!"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:302
translate chinese CeR2_J_q_lab2_f6e4b451:

    # MC "Uh huh."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:305
translate chinese CeR2_J_q_lab2_2750fc16:

    # MC "What then? What do you want me to do after she falls asleep?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:306
translate chinese CeR2_J_q_lab2_0af409f3:

    # Judy "Well, based on what you’ve told me, I think I’ve come up with a rather ingenious plan."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:309
translate chinese CeR2_J_q_lab2_43f68c6f:

    # Judy "I want you to purchase the most expensive, most powerful electrostimulation dildo you can possibly find on the market."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:310
translate chinese CeR2_J_q_lab2_3d7be780:

    # Judy "It MUST be electrostimulation. Otherwise this plan won’t work."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:311
translate chinese CeR2_J_q_lab2_cbba9046:

    # Judy "Ensure that she cannot move, and set up a camera to record her. Then, make her cum, again and again and again."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:315
translate chinese CeR2_J_q_lab2_3063fd8b:

    # Judy "You must tell Ms. Celia that her silly little powerplay is over. Threaten to leak the video if she ever tries anything on you again."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:317
translate chinese CeR2_J_q_lab2_65ba2b0e:

    # Judy "You must tell Ms. Celia that her silly little powerplay is over."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:318
translate chinese CeR2_J_q_lab2_580e06dc:

    # MC "I guess that makes sense."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:321
translate chinese CeR2_J_q_lab2_f1d7db28:

    # Judy "Listen up."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:323
translate chinese CeR2_J_q_lab2_f1ef2538:

    # Judy "This doesn't just “make sense”, [player_name]. It’s your only chance at escaping this torture."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:326
translate chinese CeR2_J_q_lab2_bd15e306:

    # MC "So, what you’re saying is, I get to have revenge for her bullying me, and I get an awesome video of her?"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:327
translate chinese CeR2_J_q_lab2_b02b4dfd:

    # Judy "AND you also blackmail her. It protects you."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:329
translate chinese CeR2_J_q_lab2_43f0346b:

    # Judy "It’s ABSOLUTELY CRITICAL that you get Celia’s consent first. If you’re doing this roleplay, then you absolutely have to make sure she wants to go down this route. Okay?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:332
translate chinese CeR2_J_q_lab2_66390112:

    # MC "Y-Yeah, I got it! I’ll ask her consent."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:333
translate chinese CeR2_J_q_lab2_8ce56356:

    # Judy "Good."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:334
translate chinese CeR2_J_q_lab2_5bf3ed28:

    # MC "Thanks, Judy. You’ve been a great help."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:337
translate chinese CeR2_J_q_lab2_337375f1:

    # MC "I’ll do it."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:338
translate chinese CeR2_J_q_lab2_ce70930a:

    # MC "I’ll make that arrogant bitch cum so damn hard!"
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:339
translate chinese CeR2_J_q_lab2_a814b53a:

    # Judy "That’s the spirit!"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:342
translate chinese CeR2_J_q_lab2_9c7c8615:

    # Judy "I think this seems like a good point to finish up our therapy session today."
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:343
translate chinese CeR2_J_q_lab2_d862a2cf:

    # Judy "Shall I see you again sometime soon?"
    Judy ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:344
translate chinese CeR2_J_q_lab2_ef2992b0:

    # MC "I think you will."
    MC ""

# game/scripts/Ce_R2/CeR2_J_q.rpy:345
translate chinese CeR2_J_q_lab2_772d3c30:

    # Judy "(Ms. Celia won’t be able to resist that intense stimulation. She’ll be crawling to you, on her hands and knees, begging for more and more.)"
    Judy ""

