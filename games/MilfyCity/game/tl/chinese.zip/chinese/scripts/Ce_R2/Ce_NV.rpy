﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/Ce_NV.rpy:117
translate chinese Ce_NV_lab_4ea5d130:

    # MC "(I've already done something tonight.. I’ll let her sleep.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:134
translate chinese Ce_NV_lab_48c1e588:

    # "*Creak*"
    ""

# game/scripts/Ce_R2/Ce_NV.rpy:135
translate chinese Ce_NV_lab_5b7e86fd:

    # MC "(It looks like Ms. Celia’s asleep.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:136
translate chinese Ce_NV_lab_548c4e0a:

    # MC "Psst... Ms. Celia?"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:138
translate chinese Ce_NV_lab_0f6800dd:

    # Celia "Hmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:139
translate chinese Ce_NV_lab_5dbb4430:

    # MC "Hey, Ms. Celia."
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:140
translate chinese Ce_NV_lab_1fb7eb41:

    # Celia "Ugh... what are you? What time is it?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:142
translate chinese Ce_NV_lab_25f2270d:

    # MC "It’s the middle of the night - I figured you might want to have a little fun."
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:143
translate chinese Ce_NV_lab_b38a3689:

    # Celia "*Yawn* What are you suggesting?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:144
translate chinese Ce_NV_lab_3db5f821:

    # MC "How about we do some roleplay where you pretend to be asleep?"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:146
translate chinese Ce_NV_lab_146e4a4b:

    # Celia "What exactly do you want to do?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:147
translate chinese Ce_NV_lab_c8e1d72a:

    # MC "Only what you’re comfortable with."
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:148
translate chinese Ce_NV_lab_0f6800dd_1:

    # Celia "Hmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:150
translate chinese Ce_NV_lab_07efce64:

    # Celia "Alright. I’m up early tomorrow though, so make this quick."
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:151
translate chinese Ce_NV_lab_3f5bf033:

    # MC "Alright! Awesome!"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:154
translate chinese Ce_NV_lab_0133ae5a:

    # MC "(Judy giving me a key to Celia’s home, was the best thing that therapy ever did for me!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:155
translate chinese Ce_NV_lab_261efa4d:

    # MC "(I guess you could call it a ‘break in’ rather than a ‘breakthrough.’)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:157
translate chinese Ce_NV_lab_3937d7b6:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:158
translate chinese Ce_NV_lab_23f178e2:

    # MC "(Let’s strip these sheets back and see what I’ve got to play with.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:160
translate chinese Ce_NV_lab_e8c7d2dc:

    # MC "(And voila!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:161
translate chinese Ce_NV_lab_6bdda79b:

    # MC "(Very nice! She sleeps in her underwear - that makes things so much easier for me!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:164
translate chinese Ce_NV_lab_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:166
translate chinese Ce_NV_lab_f4b172b5:

    # Celia "*Snore* (Come on... That would wake me up for sure...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:167
translate chinese Ce_NV_lab_be1e6bd3:

    # MC "(Okay, now to figure out what I’m going to do to this bitch!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:169
translate chinese Ce_NV_lab_c00fe20d:

    # MC "(I could play with her pussy or her tits.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:170
translate chinese Ce_NV_lab_0bea0e14:

    # MC "(But then again, it would be fun to make her give me a footjob.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:172
translate chinese Ce_NV_lab_03c990e0:

    # MC "(Alternatively, I could just make her lips suck my cock.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:173
translate chinese Ce_NV_lab_25482701:

    # MC "(Or I could make out with her.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:175
translate chinese Ce_NV_lab_a1b9fa93:

    # MC "(I really am spoiled for choice. I guess I’ll roll her over first, and just take things from there.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:176
translate chinese Ce_NV_lab_80bc9a68:

    # Celia "Ugh... Mmm... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:178
translate chinese Ce_NV_lab_0cb49de6_1:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV.rpy:180
translate chinese Ce_NV_lab_e1af15f5:

    # MC "*Phew* (I thought I’d woken her up for a second, there!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:182
translate chinese Ce_NV_lab_11129b76:

    # MC "*Phew* (I thought I'd woken her up for a second, there! She plays her role perfectly!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV.rpy:183
translate chinese Ce_NV_lab_2e11b2a9:

    # MC "(Alright, it’s party time!)"
    MC ""

