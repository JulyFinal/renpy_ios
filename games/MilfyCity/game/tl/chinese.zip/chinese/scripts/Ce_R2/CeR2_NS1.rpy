﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_NS1.rpy:119
translate chinese CeR2_NS1_lab_699c314d:

    # MC "(Hmm, these apartments reminds me of an old dorm I used to live in.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:120
translate chinese CeR2_NS1_lab_f00759a0:

    # MC "(It must be those massive numbers, because I’m getting a real sense of deja vu.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:123
translate chinese CeR2_NS1_lab_e86928f9:

    # MC "Let’s see... 51... 52... 53!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:124
translate chinese CeR2_NS1_lab_2efd9ea7:

    # MC "(Ahh, that’s it! Number 53)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:127
translate chinese CeR2_NS1_lab_6818f356:

    # MC "(I wonder if Celia left it open for me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:129
translate chinese CeR2_NS1_lab_737951da:

    # MC "*Click*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:130
translate chinese CeR2_NS1_lab_192304fb:

    # MC "(Huh, it seems that she did!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:133
translate chinese CeR2_NS1_lab_97f2f3a9:

    # MC "(Whoa! She’s got a REALLY nice apartment!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:134
translate chinese CeR2_NS1_lab_ea98b812:

    # MC "(The view from the bay window must be spectacular during the day. I bet you could see half the city from up here!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:135
translate chinese CeR2_NS1_lab_2916fb9b:

    # MC "(And that must be her husband up on the wall.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:138
translate chinese CeR2_NS1_lab_857a76d5:

    # MC "(He looks like he wandered straight out of the 1980’s. I thought Celia would surely have a hotter partner than that.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:139
translate chinese CeR2_NS1_lab_ed3b5b0c:

    # MC "(Eh, I guess that must be the kind of guy she’s into. It explains why she rejected me.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:143
translate chinese CeR2_NS1_lab_48c1e588:

    # "*Creak*"
    ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:144
translate chinese CeR2_NS1_lab_5db021fe:

    # MC "H-Hello?!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:148
translate chinese CeR2_NS1_lab_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:149
translate chinese CeR2_NS1_lab_152268e7:

    # Celia "Ahh, I’m glad you came, [player_name]. Let me just get these lights on."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:152
translate chinese CeR2_NS1_lab_e13cf496:

    # MC "(Oh my God! She looks so much hotter in her everyday clothes.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:153
translate chinese CeR2_NS1_lab_0475b78c:

    # Celia "Hey! Eyes up here, pal!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:154
translate chinese CeR2_NS1_lab_8a5b1a5b:

    # MC "S-Sorry! I wasn’t-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:157
translate chinese CeR2_NS1_lab_f74c287e:

    # Celia "Haha, I was just pulling your leg. Thanks for helping me out with this one. You’re a lifesaver."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:158
translate chinese CeR2_NS1_lab_c5ef5fbc:

    # MC "(Are those boobs even real?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:159
translate chinese CeR2_NS1_lab_2ea4699e:

    # MC "(She must have had at least a couple of boobjobs to increase their size! They’re just too perfect!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:162
translate chinese CeR2_NS1_lab_3dc2810e:

    # Celia "Cat got your tongue?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:163
translate chinese CeR2_NS1_lab_136f5316:

    # MC "Y-Yeah, I mean n-no!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:166
translate chinese CeR2_NS1_lab_114784a7:

    # Celia "Have a seat. Can I get you a coffee? Tea? Whiskey?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:167
translate chinese CeR2_NS1_lab_95dff586:

    # MC "I, uh, I’ll take a whiskey."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:168
translate chinese CeR2_NS1_lab_b872605c:

    # Celia "Haha, I’m not giving one of my students alcohol."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:171
translate chinese CeR2_NS1_lab_ddbd1f9f:

    # MC "(Ah well, it was worth a shot!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:172
translate chinese CeR2_NS1_lab_30ad597e:

    # MC "(It’s so dark and foggy outside. I’d love to see this place during clear daylight!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:175
translate chinese CeR2_NS1_lab_e87fbb53:

    # MC "Okay, let’s get down to brass tacks."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:176
translate chinese CeR2_NS1_lab_7203bbdc:

    # MC "I’m willing to help you catch that blackmailer, but I-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:179
translate chinese CeR2_NS1_lab_6865db8f:

    # Celia "Hold that thought, the kettle has just finished. Coffee or tea?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:180
translate chinese CeR2_NS1_lab_96fed41a:

    # MC "What are you having?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:181
translate chinese CeR2_NS1_lab_c67abbf0:

    # Celia "Probably just a coffee, black and strong. Same way I like my men."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:182
translate chinese CeR2_NS1_lab_1e3f249f:

    # MC "I’m the same."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:183
translate chinese CeR2_NS1_lab_04b86899:

    # Celia "You like strong black men?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:184
translate chinese CeR2_NS1_lab_7754cd1d:

    # MC "N-No, wait, I mean-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:187
translate chinese CeR2_NS1_lab_f627ceba:

    # Celia "Haha, I’ll go and get you a coffee too."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:188
translate chinese CeR2_NS1_lab_592994af:

    # MC "(Fuck. Talk about foot in mouth syndrome!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:191
translate chinese CeR2_NS1_lab_ace0cc5b:

    # MC "(Just try and relax, [player_name]. This isn’t so bad, right?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:192
translate chinese CeR2_NS1_lab_84c7b361:

    # MC "(You’re in the apartment of a beautiful woman. Her husband isn’t home, and she’s dressed like a grade A slut!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:195
translate chinese CeR2_NS1_lab_49fd1a48:

    # MC "(I mean, damn. Your ass looks good enough to eat!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:196
translate chinese CeR2_NS1_lab_039cc635:

    # MC "(What I wouldn’t give to pound that again!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:199
translate chinese CeR2_NS1_lab_a93e33ef:

    # Celia "Careful, it’s hot."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:200
translate chinese CeR2_NS1_lab_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:201
translate chinese CeR2_NS1_lab_0c698352:

    # Celia "Your coffee. It’s hot."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:202
translate chinese CeR2_NS1_lab_9e67bef8:

    # MC "Oh! Thank you."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:205
translate chinese CeR2_NS1_lab_b2bdd56c:

    # Celia "Listen, I have a plan to catch the blackmailer."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:207
translate chinese CeR2_NS1_lab_62e1d2eb:

    # MC "You do?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:209
translate chinese CeR2_NS1_lab_cf241df5:

    # MC "(Yup! She STILL isn’t breaking character! Celia must REALLY be enjoying this little fantasy we’ve got going!) You do?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:210
translate chinese CeR2_NS1_lab_3a84466d:

    # Celia "It would involve you investigating the students and faculty."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:211
translate chinese CeR2_NS1_lab_5be075e6:

    # MC "All of them?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:212
translate chinese CeR2_NS1_lab_e32fde6c:

    # Celia "No, we’ll target our investigation and spread our net as necessary."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:215
translate chinese CeR2_NS1_lab_951abff0:

    # MC "Why can you not do the faculty side by yourself?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:216
translate chinese CeR2_NS1_lab_a849cf33:

    # Celia "Cause it’s gonna be obvious. You’re going to be my inside guy."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:219
translate chinese CeR2_NS1_lab_c69eab7a:

    # Celia "The blackmailer made us get together and do things. They won’t be expecting us to be working together."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:220
translate chinese CeR2_NS1_lab_7c0a884f:

    # Celia "Let me give you an example. I could lure professors out of the faculty room and you will be the guy who breaks in and looks for something suspicious in their desks."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:223
translate chinese CeR2_NS1_lab_18f12d3a:

    # MC "How sure are you that it could be a faculty member?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:224
translate chinese CeR2_NS1_lab_3654ac78:

    # Celia "Honestly? I think it’s far more likely that it is one of my students. And I HATE that thought..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:227
translate chinese CeR2_NS1_lab_f32645e4:

    # Celia "Fuck it, I hate this right now!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:228
translate chinese CeR2_NS1_lab_8d63dafa:

    # Celia "This bastard is ruining my fucking life!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:229
translate chinese CeR2_NS1_lab_429dd672:

    # Celia "You know exact- don’t know HALF of what he or she is making me do!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:232
translate chinese CeR2_NS1_lab_106a05f5:

    # Celia "Whenever I find out who is doing this, I’m going to crush them."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:233
translate chinese CeR2_NS1_lab_a91e2a43:

    # Celia "They’ll wish that they had NEVER been born."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:234
translate chinese CeR2_NS1_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:237
translate chinese CeR2_NS1_lab_cc164b53:

    # MC "Hey, hey easy there, tiger. We’ll catch the bastard behind this."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:238
translate chinese CeR2_NS1_lab_34bbaf1a:

    # MC "Take a breather and finish your coffee."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:241
translate chinese CeR2_NS1_lab_12be2c4d:

    # MC "Look, I’m with you. Okay?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:242
translate chinese CeR2_NS1_lab_66280b9c:

    # MC "Just chill out! With the two of us working together the blackmailer doesn’t stand a chance of hiding much longer."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:243
translate chinese CeR2_NS1_lab_3c98c8c5:

    # Celia "*Sigh* Thank you, [player_name]. It’s nice to have someone I can talk to about this."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:246
translate chinese CeR2_NS1_lab_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:248
translate chinese CeR2_NS1_lab_469b0c8e:

    # MC "(Hehe, she doesn’t suspect a thing!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:250
translate chinese CeR2_NS1_lab_362527c4:

    # MC "(Jesus, she’s scary when she acts like that! Haha!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:251
translate chinese CeR2_NS1_lab_05ac408d:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:254
translate chinese CeR2_NS1_lab_ce3be15e:

    # MC "Mmm...! Goddamn, Celia! This coffee is some serious gourmet shit!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:255
translate chinese CeR2_NS1_lab_7aed9520:

    # MC "That shit you drink in class stinks compared to this stuff... Pardon my French."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:258
translate chinese CeR2_NS1_lab_933fa193:

    # Celia "Knock it off, [player_name]. I don’t need you to tell me how fucking good my coffee is."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:259
translate chinese CeR2_NS1_lab_887f203b:

    # Celia "I’m the one who buys it. When my husband goes to buy coffee, he buys shit."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:260
translate chinese CeR2_NS1_lab_c606930b:

    # Celia "But you know what’s on my mind right now, it ain’t the coffee - it’s the blackmailer trying to ruin my fucking life."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:261
translate chinese CeR2_NS1_lab_5f4d26b1:

    # MC "I’m sorry, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:264
translate chinese CeR2_NS1_lab_254621ae:

    # Celia "*Sigh* No, I’m sorry. I shouldn’t have snapped at you like that."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:265
translate chinese CeR2_NS1_lab_a5b19428:

    # MC "It’s okay, I understand you're stressed."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:268
translate chinese CeR2_NS1_lab_4eba7bd9:

    # MC "So, how did you end up getting blackmailed anyway?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:269
translate chinese CeR2_NS1_lab_8fa1b12a:

    # Celia "It’s a long story. I’d rather not get into it."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:270
translate chinese CeR2_NS1_lab_2c7939dc:

    # MC "Aw, c’mon. If you’re expecting me to help you out, you’ve got to at least let me know how this all began!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:273
translate chinese CeR2_NS1_lab_acb48322:

    # Celia "Maybe some other time."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:274
translate chinese CeR2_NS1_lab_200f79f4:

    # Celia "Anyway, I’m pretty sure there is something you want in return?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:277
translate chinese CeR2_NS1_lab_83410934:

    # MC "I’m sure you could do something for me."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:278
translate chinese CeR2_NS1_lab_046d6ac3:

    # Celia "*Sigh* What are you thinking of?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:281
translate chinese CeR2_NS1_lab_88ad86e5:

    # MC "Hmm, probably something naughty. I quite enjoyed what we did before."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:282
translate chinese CeR2_NS1_lab_cfbd5c49:

    # Celia "Damn it, I wish I never asked."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:285
translate chinese CeR2_NS1_lab_f788778c:

    # MC "Don’t worry, I’m not gonna ask for a huge favour."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:286
translate chinese CeR2_NS1_lab_7361fe06:

    # Celia "You better not."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:287
translate chinese CeR2_NS1_lab_5e79a72a:

    # MC "How about we just make out?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:290
translate chinese CeR2_NS1_lab_e95bbfe9:

    # Celia "Fuck's sake..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:291
translate chinese CeR2_NS1_lab_11d5efc3:

    # Celia "Right here?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:292
translate chinese CeR2_NS1_lab_bbfdd810:

    # MC "Here on the couch, right now. That’s all I’m asking for. (And I'm again on top!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:295
translate chinese CeR2_NS1_lab_a7d73f0e:

    # Celia "*Sigh* Fine. Let’s get this over with."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:296
translate chinese CeR2_NS1_lab_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:302
translate chinese CeR2_NS1_lab_c7844892:

    # Celia "I’m going give you the best makeout session you’ve ever had."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:303
translate chinese CeR2_NS1_lab_daf31614:

    # Celia "And in return, you’re going to give me the best you can do to help me catch this fucker. Deal?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:304
translate chinese CeR2_NS1_lab_3c690260:

    # MC "Ab-so-lutely!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:307
translate chinese CeR2_NS1_lab_40293ef1:

    # Celia "*Sigh* Alright, let’s get this over with."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:308
translate chinese CeR2_NS1_lab_555f9e00:

    # MC "(This is gonna be awesome! She’s dressed so sexily too!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:311
translate chinese CeR2_NS1_lab_3dd592f7:

    # Celia "Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:312
translate chinese CeR2_NS1_lab_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:315
translate chinese CeR2_NS1_lab_6e12088b:

    # MC "(Fuck, she is so hot!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:316
translate chinese CeR2_NS1_lab_940ea3ba:

    # MC "(I wish she had just said yes to being my girlfriend when I first asked her. We’d be doing stuff like this all the time!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:319
translate chinese CeR2_NS1_lab_2e589664:

    # MC "(It’s hardly a makeout session if there’s no second base, right?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:320
translate chinese CeR2_NS1_lab_eb11726f:

    # MC "(She won’t mind if I give her tits a little bit of a feel.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:321
translate chinese CeR2_NS1_lab_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:324
translate chinese CeR2_NS1_lab_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:325
translate chinese CeR2_NS1_lab_d2801b97:

    # MC "(Hey! She didn’t slap me! I think she actually likes me touching there!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:327
translate chinese CeR2_NS1_lab_3a04f391:

    # Celia "(Ugh, he’s touching my tits now. Oh well, I’ve already had to do FAR worse to him. This is a blessing in comparison.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:329
translate chinese CeR2_NS1_lab_05d08dd1:

    # Celia "(Mmm... He’s touching my tits now. I wonder how things are going to progress over the next few days. I’ve got a couple of ideas floating in my head about what direction to take this.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:332
translate chinese CeR2_NS1_lab_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:333
translate chinese CeR2_NS1_lab_d2fdfba5:

    # Celia "MMM!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:336
translate chinese CeR2_NS1_lab_00e08ef4:

    # MC "(Oh wow, she’s climbing on top of me now!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:337
translate chinese CeR2_NS1_lab_537eac57:

    # Celia "(Oh crap, I think I hit the cups!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:341
translate chinese CeR2_NS1_lab_5d6a8ef7:

    # "*CLATTER*"
    ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:342
translate chinese CeR2_NS1_lab_5cc148fa:

    # MC "Shit! Did something fall?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:345
translate chinese CeR2_NS1_lab_70e5aa17:

    # Celia "Just the cups. Don’t worry, they didn’t shatter."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:346
translate chinese CeR2_NS1_lab_d72cde2c:

    # MC "Oh, good."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:349
translate chinese CeR2_NS1_lab_cd88c9a6:

    # MC "I love you lying on top of me like this."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:350
translate chinese CeR2_NS1_lab_6098f84c:

    # MC "It kinda feels like... you’re my girlfriend and we’re..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:351
translate chinese CeR2_NS1_lab_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:352
translate chinese CeR2_NS1_lab_bdff4dd6:

    # Celia "(Shit, I think I’ve led him on too much. Judy will kill me if she thinks I’ve interfered with his therapy.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:355
translate chinese CeR2_NS1_lab_b8cd0e06:

    # MC "(God, I’m so fucking horny right now. This is like a fantasy come true!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:356
translate chinese CeR2_NS1_lab_0652f26b:

    # MC "(I must have dreamt about Celia a dozen times!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:357
translate chinese CeR2_NS1_lab_a53d2073:

    # MC "(She won’t mind me lightly spanking her ass, will she? That’s part of making out too.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:360
translate chinese CeR2_NS1_lab_58d8bcb5:

    # MC "(Here goes nothing...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:361
translate chinese CeR2_NS1_lab_83b4b5b0:

    # Celia "(I’ve gone too far. If Judy finds out, she'll report me, and then I’ll have to endure another Godawful staff review meeting.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:365
translate chinese CeR2_NS1_lab_0c4b6ba1:

    # "*Whack*"
    ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:366
translate chinese CeR2_NS1_lab_db696836:

    # Celia "OUCH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:367
translate chinese CeR2_NS1_lab_1292b001:

    # MC "(Uh oh...)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:370
translate chinese CeR2_NS1_lab_2770528a:

    # Celia "What the fuck?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:371
translate chinese CeR2_NS1_lab_23ff7e7e:

    # Celia "Did you just spank me?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:372
translate chinese CeR2_NS1_lab_c405af36:

    # MC "M-My hand slipped! Sorry!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:373
translate chinese CeR2_NS1_lab_84b9c9cf:

    # Celia "It better have JUST been your hand slipping!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:376
translate chinese CeR2_NS1_lab_d325d6bc:

    # Celia "Time to go and uphold your end of the bargain. We start tracking down this bastard ASAP."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:377
translate chinese CeR2_NS1_lab_a3af909b:

    # MC "Gotcha!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:380
translate chinese CeR2_NS1_lab_94e65389:

    # MC "Oh, Celia? One last thing."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:381
translate chinese CeR2_NS1_lab_1983e7f6:

    # Celia "Yes, [player_name]?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:382
translate chinese CeR2_NS1_lab_6a70efbf:

    # MC "Thanks for making out with me. It was REALLY hot."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:383
translate chinese CeR2_NS1_lab_104cadc2:

    # Celia "*Sigh*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:406
translate chinese CeR2_NS1_lab_1582bd93:

    # Celia "Alright. Please, PLEASE tell me you’ve got some good news."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:407
translate chinese CeR2_NS1_lab_34629128:

    # MC "Don’t worry, I’ve made some progress. We’re closing in on them."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:408
translate chinese CeR2_NS1_lab_0ab51aab:

    # Celia "Excellent."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:411
translate chinese CeR2_NS1_lab_ca7a725b_1:

    # MC "*Slurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:412
translate chinese CeR2_NS1_lab_aad4648f:

    # MC "(Time to misdirect her attention to a completely different set of students now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:415
translate chinese CeR2_NS1_lab_cdfe1e0b:

    # MC "It was risky having me investigate this though."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:416
translate chinese CeR2_NS1_lab_5f923e68:

    # Celia "What are you talking about?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:419
translate chinese CeR2_NS1_lab_7fc3bc0f:

    # MC "I mean, what if the blackmailer noticed me? He, or she, could try and blackmail me too!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:420
translate chinese CeR2_NS1_lab_98edb1f1:

    # Celia "*Sigh* I see what you’re getting at. Fine, what do you want this time?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:421
translate chinese CeR2_NS1_lab_89318d0a:

    # MC "I simply want you to suck my dick."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:424
translate chinese CeR2_NS1_lab_fdc321d1:

    # Celia "Tell me what you know, first, and I’ll decide if the information is worth a blowjob."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:425
translate chinese CeR2_NS1_lab_0b2ce7ac:

    # MC "How do I know you’ll actually do it for me?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:426
translate chinese CeR2_NS1_lab_c99ae696:

    # Celia "Do you have any doubts that it is good information you are giving me?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:427
translate chinese CeR2_NS1_lab_a99f00b8:

    # MC "No."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:428
translate chinese CeR2_NS1_lab_27c6c4f4:

    # Celia "Then I’ll be sucking your dick, but you’re going to need to tell me what you know first."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:431
translate chinese CeR2_NS1_lab_2862f011:

    # MC "Fine. Deal."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:432
translate chinese CeR2_NS1_lab_1b09a671:

    # MC "I’ve searched my entire class. I’ve spoken with everyone and listened in to all the gossip of the day."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:433
translate chinese CeR2_NS1_lab_c845bf07:

    # Celia "And?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:436
translate chinese CeR2_NS1_lab_9fd4a214:

    # MC "None of them are linked to this."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:437
translate chinese CeR2_NS1_lab_ad059d70:

    # Celia "God dammit..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:438
translate chinese CeR2_NS1_lab_8e94d07b:

    # MC "This is good news! We can rule out your students! It has to be someone in a different professor's group!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:441
translate chinese CeR2_NS1_lab_66f01b63:

    # Celia "Hmm, I do teach quite a few classes."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:442
translate chinese CeR2_NS1_lab_de33da21:

    # Celia "You have no idea who did it? A name? A description?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:443
translate chinese CeR2_NS1_lab_352a4c90:

    # MC "The only thing I know, is that they are probably male."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:446
translate chinese CeR2_NS1_lab_00094839:

    # Celia "Ugh! Well, at least we've ruled out one batch of students."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:447
translate chinese CeR2_NS1_lab_9797bab9:

    # MC "True, it knocks off about twenty students. We’re making great progress."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:450
translate chinese CeR2_NS1_lab_6583ea43:

    # Celia "I need to ask a favour of you now."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:451
translate chinese CeR2_NS1_lab_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:452
translate chinese CeR2_NS1_lab_b3ede99d:

    # Celia "Do you know the security camera room?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:453
translate chinese CeR2_NS1_lab_75381924:

    # MC "Yeah, I think so."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:455
translate chinese CeR2_NS1_lab_a730b94b:

    # Celia "I reckon we can catch the blackmailer on camera."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:456
translate chinese CeR2_NS1_lab_4ab2f375:

    # Celia "There’s a camera positioned directly outside the men’s toilets. All I have to do is look and see who goes into there before me."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:458
translate chinese CeR2_NS1_lab_c28fb025:

    # Celia "(Haha! That would end our BDSM relationship if he did not even think of that! I hope [player_name] is not that stupid.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:459
translate chinese CeR2_NS1_lab_5fb1e495:

    # MC "(Shit! Why didn’t I think about the cameras?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:461
translate chinese CeR2_NS1_lab_5fcca09c:

    # MC "Th-That’s a great idea! (Fuck! She’s really smart!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:462
translate chinese CeR2_NS1_lab_ffc7408b:

    # Celia "I can’t do it myself though. The guard would see me walking into the boy’s toilets."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:463
translate chinese CeR2_NS1_lab_c504c37f:

    # MC "So, that’s why you need me! I can go in and view the footage for you!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:466
translate chinese CeR2_NS1_lab_7a8a191b:

    # Celia "Bingo."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:467
translate chinese CeR2_NS1_lab_ea865e0d:

    # MC "Okay, I think we’ve got a solid plan going on here."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:469
translate chinese CeR2_NS1_lab_87fec9ea:

    # Celia "Bingo. Of course, I want you to record that as well with your smartphone. That wouldn't be a problem [player_name]?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:470
translate chinese CeR2_NS1_lab_f663ea50:

    # MC "N-No not all. I think we’ve got a solid plan going on here."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:473
translate chinese CeR2_NS1_lab_012c6970:

    # MC "So, about that blowjob..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:474
translate chinese CeR2_NS1_lab_42dd7e20:

    # Celia "Yeah, yeah. You did alright..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:477
translate chinese CeR2_NS1_lab_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:479
translate chinese CeR2_NS1_lab_26ef2ba2:

    # Celia "I need you to keep working this case for me though. You’ve made more progress in a day than I have in a week!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:481
translate chinese CeR2_NS1_lab_5dc3ef34:

    # Celia "I need you to keep working on this case for me though. You've made more progress in a day than I have in a week! (Also... This whole acting is starting to be nice in a different way...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:487
translate chinese CeR2_NS1_lab_a9230c82:

    # MC "Thanks, Celia. Now it’s time for you to use that pretty little mouth of yours!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:488
translate chinese CeR2_NS1_lab_0148a7e8:

    # Celia "Yeah... fine."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:489
translate chinese CeR2_NS1_lab_c3efda89:

    # MC "Mind if I put my finger in first?"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:492
translate chinese CeR2_NS1_lab_2af1372b:

    # Celia "Wha-"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:493
translate chinese CeR2_NS1_lab_65ed375e:

    # MC "Mmm, I can’t wait to feel your lips wrapped tightly around my shaft."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:497
translate chinese CeR2_NS1_lab_20c73366:

    # "*Slap*"
    ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:498
translate chinese CeR2_NS1_lab_fe52187c:

    # Celia "Alright, enough of this nonsense. Stand up and take your clothes off."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:499
translate chinese CeR2_NS1_lab_90c52b84:

    # MC "Okay!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:502
translate chinese CeR2_NS1_lab_9eb42abf:

    # MC "Ready!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:503
translate chinese CeR2_NS1_lab_a1e7ef78:

    # Celia "You’ve still got your pants on."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:504
translate chinese CeR2_NS1_lab_e7601482:

    # MC "I was kinda hoping you’d help with that part."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:507
translate chinese CeR2_NS1_lab_104cadc2_1:

    # Celia "*Sigh*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:508
translate chinese CeR2_NS1_lab_2ca4b487:

    # Celia "You’re not making this easy for me, you know that?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:509
translate chinese CeR2_NS1_lab_2ff890a3:

    # MC "Sorry. I just worked hard to get you that information, and now I really want to enjoy the reward for it."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:512
translate chinese CeR2_NS1_lab_e4137da9:

    # MC "(Fuck, her breasts look incredible from this angle!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:513
translate chinese CeR2_NS1_lab_85f970a0:

    # MC "(I can see right down her cleavage!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:516
translate chinese CeR2_NS1_lab_0ecd0010:

    # Celia "Hard already?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:517
translate chinese CeR2_NS1_lab_d9d31f7b:

    # MC "What can I say? I was excited from the moment you agreed to suck my dick."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:518
translate chinese CeR2_NS1_lab_97280197:

    # Celia "Fine, let’s get this finished."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:521
translate chinese CeR2_NS1_lab_009dc290:

    # Celia "*Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:522
translate chinese CeR2_NS1_lab_2786c3d7:

    # MC "Ohh... yeah... Mmm!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:525
translate chinese CeR2_NS1_lab_cbcec2e8:

    # MC "(Ugh! Her mouth is so hot and wet! It feels amazing wrapped around my cock like that.)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:526
translate chinese CeR2_NS1_lab_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:527
translate chinese CeR2_NS1_lab_eb0a0c57:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:530
translate chinese CeR2_NS1_lab_c445d6f2:

    # Celia "(Okay, time to go to town on this boy’s dick. He won’t last two minutes if I put some effort into this.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:532
translate chinese CeR2_NS1_lab_009dc290_1:

    # Celia "*Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:533
translate chinese CeR2_NS1_lab_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:536
translate chinese CeR2_NS1_lab_98352518:

    # Celia "Mppfff!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:537
translate chinese CeR2_NS1_lab_77f7ca97:

    # MC "Ohhhh... holy fuck..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:538
translate chinese CeR2_NS1_lab_198a3323:

    # Celia "*Shlluurrrp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:541
translate chinese CeR2_NS1_lab_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:542
translate chinese CeR2_NS1_lab_f1bedc9e:

    # MC "Mmm! Damn, you’re so good at this, Celia!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:543
translate chinese CeR2_NS1_lab_009dc290_2:

    # Celia "*Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:546
translate chinese CeR2_NS1_lab_0a72f13a:

    # Celia "*Shlurp* *Suck* *SHLUURRRRP*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:548
translate chinese CeR2_NS1_lab_bcfc55da:

    # MC "Ahh! Ahhh... Hnnnnggg.... Ugh!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:551
translate chinese CeR2_NS1_lab_15c61d5f:

    # Celia "*SHLURP* *SUCK*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:553
translate chinese CeR2_NS1_lab_6fefa6cf:

    # MC "Ahh... H-Holy fuck... Ugh!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:554
translate chinese CeR2_NS1_lab_b9d9e23e:

    # MC "(Fuck, I’m going to start thrusting! I want to feel my cock in her throat!)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:557
translate chinese CeR2_NS1_lab_9ce16e89:

    # Celia "NNNMMPFFFF?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:559
translate chinese CeR2_NS1_lab_cc61c6e4:

    # Celia "*SPLUTTER* *GAG*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:561
translate chinese CeR2_NS1_lab_ad55eeff:

    # MC "HNNNGGG!! UGH!!! Oh fuck!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:563
translate chinese CeR2_NS1_lab_009dc290_3:

    # Celia "*Suck*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:566
translate chinese CeR2_NS1_lab_75c6d02a:

    # Celia "(Fuck! He gave me no warning at all!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:567
translate chinese CeR2_NS1_lab_59627aab:

    # Celia "(I’m gonna need to change my panties after he leaves - he’s making me all wet, treating me like this!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:568
translate chinese CeR2_NS1_lab_46aa2b5b:

    # Celia "*GAG* *SHLURP*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:571
translate chinese CeR2_NS1_lab_65302a41:

    # MC "Ah! Ugh! Ohh!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:572
translate chinese CeR2_NS1_lab_a550070a:

    # Celia "*SHLURP* *SUCK SUCK*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:573
translate chinese CeR2_NS1_lab_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:576
translate chinese CeR2_NS1_lab_27952c5d:

    # Celia "*GAG* *SPLUTTER*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:577
translate chinese CeR2_NS1_lab_a8e62204:

    # MC "Hnnnggg! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:578
translate chinese CeR2_NS1_lab_c114ec84:

    # Celia "*SUCK SUCK SUCK*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:581
translate chinese CeR2_NS1_lab_7483a7dc:

    # MC "Aaahh! Ugh!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:582
translate chinese CeR2_NS1_lab_1232e993:

    # MC "(Should I cum in her mouth or over her face?)"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:586
translate chinese CeR2_NS1_lab_097f355d:

    # MC "I’m gonna cum! Stick out your tongue!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:589
translate chinese CeR2_NS1_lab_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:590
translate chinese CeR2_NS1_lab_df786ee5:

    # MC "UGHHH! AAHHHHH! Hnnnngg!!!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:599
translate chinese CeR2_NS1_lab_e7cd61bb:

    # Celia "(Ugh, the things a girl has to do to get by in the world...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:601
translate chinese CeR2_NS1_lab_92d1c390:

    # Celia "(Mmm... It really turns me on when he uses my body like that. I’m gonna have some fun with my vibrator when he leaves.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:607
translate chinese CeR2_NS1_lab_9434b032:

    # MC "Fuck, I’m going to blow my load over your face!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:610
translate chinese CeR2_NS1_lab_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:611
translate chinese CeR2_NS1_lab_9d747446:

    # Celia "(This is fine.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:612
translate chinese CeR2_NS1_lab_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:613
translate chinese CeR2_NS1_lab_c1e5aa30:

    # Celia "(I’m honestly okay with this.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:614
translate chinese CeR2_NS1_lab_643f27ba:

    # MC "Fuck! Ahhh! Hnnnggg!"
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:623
translate chinese CeR2_NS1_lab_89c49931:

    # Celia "(It’s not like I spent half an hour putting my fucking makeup together.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:624
translate chinese CeR2_NS1_lab_18224611:

    # MC "*Pant* That was amazing..."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:625
translate chinese CeR2_NS1_lab_622ab713:

    # Celia "(Dickhead.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:631
translate chinese CeR2_NS1_visit2_blow_con1_2faa359c:

    # MC "Thanks again, Celia. I’ll catch you later on."
    MC ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:632
translate chinese CeR2_NS1_visit2_blow_con1_53fdfc25:

    # Celia "Uh huh... *Cough*"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:633
translate chinese CeR2_NS1_visit2_blow_con1_9ce1c3a5:

    # Celia "Get me any more information you can. *Cough* Let me know as soon as possible. Okay?"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:634
translate chinese CeR2_NS1_visit2_blow_con1_1d04fe10:

    # Celia "(Fuck, I need to get a drink and a throat losenge after that!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_NS1.rpy:635
translate chinese CeR2_NS1_visit2_blow_con1_f89e1852:

    # MC "Will do! See ya later, Celia!"
    MC ""

translate chinese strings:

    # game/scripts/Ce_R2/CeR2_NS1.rpy:584
    old "Pull out and wank yourself until your jizz covers Celia’s tongue."
    new ""

    # game/scripts/Ce_R2/CeR2_NS1.rpy:584
    old "Spray your jizz over Celia’s face."
    new ""

