﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/Ce_NV_S.rpy:94
translate chinese Ce_NV_blow_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:95
translate chinese Ce_NV_blow_a9a65592:

    # MC "(Let’s start off by making her suck my dick!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:98
translate chinese Ce_NV_blow_2292450c:

    # MC "(I have to be super careful doing this - one slip and she’ll catch me red-handed!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:100
translate chinese Ce_NV_blow_f87e560b:

    # MC "(I have to be super careful doing this - one slip and she’ll catch me red-handed! And this would be the end of roleplaying!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:101
translate chinese Ce_NV_blow_3937d7b6:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:103
translate chinese Ce_NV_blow_ffa4c9d7:

    # MC "(I’ll just pinch her nose to make her open her mouth now.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:104
translate chinese Ce_NV_blow_9daf480d:

    # MC "(C’mon Celia... open wide for me!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:106
translate chinese Ce_NV_blow_b8d82a5c:

    # MC "(Haha! Gotcha! Good girl!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:107
translate chinese Ce_NV_blow_bca4844b:

    # MC "(Now I just have to slip my cock inside!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:109
translate chinese Ce_NV_blow_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:110
translate chinese Ce_NV_blow_1db042ee:

    # Celia "*Slurp*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:112
translate chinese Ce_NV_blow_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:113
translate chinese Ce_NV_blow_dbb8c206:

    # MC "Oh fuck... That’s good... "
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:115
translate chinese Ce_NV_blow_1db042ee_1:

    # Celia "*Slurp*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:117
translate chinese Ce_NV_blow_2696ea7e:

    # Celia "*Slurp* (That was smart to pinch my nose a little... I’m not gonna lie, that was hot...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:119
translate chinese Ce_NV_blow_43165fd4:

    # MC "*Pant* Oh yeah..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:120
translate chinese Ce_NV_blow_1ad48a5e:

    # Celia "*Slurp* *Slurp*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:122
translate chinese Ce_NV_blow_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:123
translate chinese Ce_NV_blow_59857edb:

    # MC "(Damn, it’s hard to keep my voice down! It feels so fucking good!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:124
translate chinese Ce_NV_blow_bcb35b72:

    # MC "(I have to put it down her throat while I have the chance!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:126
translate chinese Ce_NV_blow_1d344265:

    # Celia "*Shlurp* *Gag*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:128
translate chinese Ce_NV_blow_60ad498c:

    # MC "Ugh... Hnnng... "
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:129
translate chinese Ce_NV_blow_e7698c15:

    # MC "(Shit, her throat is so tight! This feels amazing wrapped around my glans!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:131
translate chinese Ce_NV_blow_08d67cbc:

    # MC "*Pant* Wow..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:134
translate chinese Ce_NV_blow_086be61f:

    # MC "(I wish I could make Celia do this any time I wanted. Shame she has to be asleep right now.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:136
translate chinese Ce_NV_blow_024df958:

    # MC "(I wish I could make Celia do this any time I wanted. Shame she has to be pretending to be asleep right now.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:138
translate chinese Ce_NV_blow_3061bb84:

    # MC "Hnngg... Mmm!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:139
translate chinese Ce_NV_blow_8d56a97e:

    # Celia "*GAG*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:140
translate chinese Ce_NV_blow_5f52eb99:

    # MC "(Uh oh. I think I made her gag a bit too hard there!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:142
translate chinese Ce_NV_blow_38bdd0f6:

    # Celia "*Cough Cough*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:143
translate chinese Ce_NV_blow_b3a23017:

    # MC "(Shit! She’s waking up! I need to get out of here!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:148
translate chinese Ce_NV_foot_c03eb438:

    # MC "(Okay, I think it’s time to try out Celia’s feet.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:149
translate chinese Ce_NV_foot_d68e0460:

    # MC "(Hopefully she isn’t too ticklish - I don’t want to wake her up!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:151
translate chinese Ce_NV_foot_e0cdaffb:

    # MC "(They’re a bit too far apart for me to use them. I’m just going to need to reposition her a bit first.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:152
translate chinese Ce_NV_foot_e7ecc236:

    # MC "(Easy does it...)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:154
translate chinese Ce_NV_foot_01b4f9fe:

    # MC "(There we go! Much better!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:156
translate chinese Ce_NV_foot_3937d7b6:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:158
translate chinese Ce_NV_foot_7a5312e4:

    # Celia "Zzz... (He likes foot? Kinky...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:159
translate chinese Ce_NV_foot_0e3ed944:

    # MC "(That should be me ready to go! Time to get undressed!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:161
translate chinese Ce_NV_foot_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:162
translate chinese Ce_NV_foot_fb80d5d2:

    # MC "(Here’s the moment of truth - please don’t wake up.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:164
translate chinese Ce_NV_foot_80564582:

    # MC "(Here we go...)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:166
translate chinese Ce_NV_foot_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:167
translate chinese Ce_NV_foot_0cb49de6_1:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:169
translate chinese Ce_NV_foot_9a92c920:

    # MC "Ooohhh... "
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:170
translate chinese Ce_NV_foot_f18f1dc7:

    # MC "(That’s perfect! Her feet are so soft!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:172
translate chinese Ce_NV_foot_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:173
translate chinese Ce_NV_foot_90567cb5:

    # MC "(I can fuck her feet much faster at this angle!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:175
translate chinese Ce_NV_foot_da44427c:

    # Celia "Hmm... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:176
translate chinese Ce_NV_foot_4a1d1c8c:

    # MC "Ugh... Mmm!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:178
translate chinese Ce_NV_foot_d702e007:

    # MC "(Damn, she really is so hot!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:179
translate chinese Ce_NV_foot_730e1e0c:

    # MC "(Her breasts look incredible from this angle!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:181
translate chinese Ce_NV_foot_fe170244:

    # MC "Fuck... ah... oh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:182
translate chinese Ce_NV_foot_0cb49de6_2:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:184
translate chinese Ce_NV_foot_4a19cd6d:

    # MC "Hnnng.... Mmm!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:186
translate chinese Ce_NV_foot_05e83620:

    # MC "(I’m getting closer to cumming. Hopefully I’ll be able to finish before she wakes up!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:188
translate chinese Ce_NV_foot_6c08ba78:

    # MC "(I’ll pull her feet closer together - it’ll feel better if they’re tighter around my cock.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:189
translate chinese Ce_NV_foot_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:191
translate chinese Ce_NV_foot_77e8dba8:

    # MC "Hnnng... Fuck... Ahh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:192
translate chinese Ce_NV_foot_a8e6fb85:

    # MC "(I’m cumming!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:194
translate chinese Ce_NV_foot_4908f5b0:

    # MC "Ugh! Hnnnggg! Ahh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:204
translate chinese Ce_NV_foot_d279e5e2:

    # Celia "Zzz... Hmm?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:205
translate chinese Ce_NV_foot_803c9c0c:

    # Celia "*Yawn*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:207
translate chinese Ce_NV_foot_285c663c:

    # Celia "(What time is it?)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:208
translate chinese Ce_NV_foot_d03e07f4:

    # Celia "(Ugh, I was having the weirdest dream...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:210
translate chinese Ce_NV_foot_e8d798b9:

    # MC "(Oh shit, oh shit, oh shit!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:211
translate chinese Ce_NV_foot_23983a37:

    # MC "(I gotta bail!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:213
translate chinese Ce_NV_foot_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:215
translate chinese Ce_NV_foot_d0d184c7:

    # Celia "Huh? Is someone there?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:217
translate chinese Ce_NV_foot_1e3a49c8:

    # Celia "Huh? Is someone there? (Did he really just cum on my feet and quickly left!? Where's the fun for me?)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:218
translate chinese Ce_NV_foot_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:219
translate chinese Ce_NV_foot_93928317:

    # Celia "Mmm, I must have been dreaming... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:224
translate chinese Ce_NV_kiss_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:225
translate chinese Ce_NV_kiss_83e6f631:

    # MC "(Celia’s lips are so soft. I could use this opportunity to make out with her.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:227
translate chinese Ce_NV_kiss_c2b14759:

    # MC "(They would feel so good wrapped around my cock right now.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:228
translate chinese Ce_NV_kiss_4397580d:

    # MC "(I’m getting hard just thinking about it!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:230
translate chinese Ce_NV_kiss_ee2f2798:

    # MC "(Plunging my cock slowly into her mouth.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:231
translate chinese Ce_NV_kiss_eab26014:

    # MC "(That would really shut this bitch up!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:233
translate chinese Ce_NV_kiss_3937d7b6:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:235
translate chinese Ce_NV_kiss_ec03b742:

    # Celia "Zzz... ([player_name] is playing a dentist?)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:237
translate chinese Ce_NV_kiss_50ff9367:

    # MC "(Then I’d start to really fuck her face. Hard and fast.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:238
translate chinese Ce_NV_kiss_394e448b:

    # MC "(She’d be spluttering and gagging, but she’d accept it, because deep down she knows she’s nothing but a cocksucking whore.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:240
translate chinese Ce_NV_kiss_ad6ca94e:

    # Celia "Ahhmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:241
translate chinese Ce_NV_kiss_1526c130:

    # MC "(And then I’d cum. I’d fill her mouth will my semen and make her swallow every last drop.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:243
translate chinese Ce_NV_kiss_e4c7c3d8:

    # MC "(But that’s for another day...)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:244
translate chinese Ce_NV_kiss_5906e9c2:

    # MC "(Tonight I’ll content myself with just kissing you.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:246
translate chinese Ce_NV_kiss_cb365c7b:

    # MC "(She really is beautiful.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:247
translate chinese Ce_NV_kiss_beaf81d8:

    # MC "(We could have been such a lovely couple, if she’d only said yes.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:249
translate chinese Ce_NV_kiss_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:250
translate chinese Ce_NV_kiss_8da008d9:

    # MC "(Hell, we could have even just been friends if she hadn’t been so nasty about how she turned me down!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:252
translate chinese Ce_NV_kiss_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:255
translate chinese Ce_NV_kiss_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:257
translate chinese Ce_NV_kiss_ee4c8048:

    # Celia "Mmm... (He’s mocking me... Now I want more...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:259
translate chinese Ce_NV_kiss_fa1223cc:

    # MC "(Her mouth is amazing!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:260
translate chinese Ce_NV_kiss_95db8b7e:

    # MC "(Kissing her feels incredible! She’s even responding to my tongue!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:262
translate chinese Ce_NV_kiss_411c9804_1:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:263
translate chinese Ce_NV_kiss_7a6058c1:

    # MC "(I wonder what she’s dreaming about right now.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:265
translate chinese Ce_NV_kiss_81e3b94a:

    # MC "(Oh yeah! She’s properly making out with me now!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:266
translate chinese Ce_NV_kiss_aface5b8:

    # MC "(She might as well be awake!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:268
translate chinese Ce_NV_kiss_876b1d66:

    # Celia "Ohh... More..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:269
translate chinese Ce_NV_kiss_7930b41e:

    # MC "(Shit, did she just say something?"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:272
translate chinese Ce_NV_kiss_996e3671:

    # MC "(Nah, I must be imagining things. I’m just getting anxious about being in her place!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:274
translate chinese Ce_NV_kiss_3291da4e:

    # MC "I'm a little anxious about being in her place. It seems much more intimate than the College campus!"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:275
translate chinese Ce_NV_kiss_3937d7b6_1:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:277
translate chinese Ce_NV_kiss_a0af2644:

    # Celia "*YAWN*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:278
translate chinese Ce_NV_kiss_03ea195c:

    # Celia "Gustav? Are you home?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:281
translate chinese Ce_NV_kiss_01af156f:

    # MC "(SHIT! That was too fucking close!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:283
translate chinese Ce_NV_kiss_979d8c4f:

    # MC "((SHIT! That was too fucking close! The roleplay is over!))"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:284
translate chinese Ce_NV_kiss_66130b2c:

    # Celia "Huh?!"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:285
translate chinese Ce_NV_kiss_5ee1d1da:

    # Celia "Oh... (I must have been dreaming.)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:290
translate chinese Ce_NV_pussy_762eb1e7:

    # MC "(What’s that famous expression again?)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:291
translate chinese Ce_NV_pussy_ec2a7e76:

    # MC "(Go big or go home?)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:294
translate chinese Ce_NV_pussy_c8cb8e9f:

    # MC "(I’ve risked my ass, quite literally, sneaking in here. If Celia was to catch me I’d be dead meat.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:295
translate chinese Ce_NV_pussy_568ca4b7:

    # MC "(If I’m putting that much risk into it, then you can bet that I’m settling for nothing less than her pussy!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:297
translate chinese Ce_NV_pussy_7285d895:

    # MC "(My heart's racing right now! I can't believe I'm so close to such a sexy woman!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:299
translate chinese Ce_NV_pussy_7d64b3c3:

    # MC "Nice..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:300
translate chinese Ce_NV_pussy_736c3153:

    # MC "(Okay, it’s not worth the risk of pulling her panties off completely. I’ll leave them there.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:302
translate chinese Ce_NV_pussy_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:303
translate chinese Ce_NV_pussy_27ed1d51:

    # MC "(Damn, her pussy looks really good! Let’s see if a little bit of saliva can get me inside it!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:305
translate chinese Ce_NV_pussy_fd13668b:

    # Celia "Zzz... Mmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:306
translate chinese Ce_NV_pussy_5e152c72:

    # MC "(There we go!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:308
translate chinese Ce_NV_pussy_5c219d2c:

    # MC "(That’s what I’m talking about!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:309
translate chinese Ce_NV_pussy_653c2a39:

    # MC "(I barely needed to wet my finger at all - she’s already soaking after being touched!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:311
translate chinese Ce_NV_pussy_63c66a46:

    # Celia "Ohh... Ah... *Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:313
translate chinese Ce_NV_pussy_d9005e14:

    # MC "(Hehe, she’s moaning like crazy in her sleep!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:315
translate chinese Ce_NV_pussy_acc39d22:

    # MC "(Wow! She's moaning like crazy right now!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:316
translate chinese Ce_NV_pussy_3cee586f:

    # MC "(Let’s see how she reacts if I massage her g-spot.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:318
translate chinese Ce_NV_pussy_3d03acd4:

    # Celia "Ahh! Ohhh!"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:319
translate chinese Ce_NV_pussy_2f241492:

    # MC "(Holy crap - she’s loud! I better stop before she wakes herself up!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:321
translate chinese Ce_NV_pussy_e2c08039:

    # MC "(Let’s try sliding my cock up and down. I probably won’t be able to stick it inside, but I should get away with grinding against her cunt.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:322
translate chinese Ce_NV_pussy_1a1893ef:

    # Celia "Mmm... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:324
translate chinese Ce_NV_pussy_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:325
translate chinese Ce_NV_pussy_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:326
translate chinese Ce_NV_pussy_5e152c72_1:

    # MC "(There we go!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:328
translate chinese Ce_NV_pussy_580cd464:

    # MC "(Fuck, it feels good between her thighs!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:330
translate chinese Ce_NV_pussy_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:332
translate chinese Ce_NV_pussy_e8197874:

    # Celia "Ahh... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:334
translate chinese Ce_NV_pussy_3d6b11bf:

    # Celia "Ahh... Zzz... (I hope [player_name] decides to fuck me in this roleplay...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:336
translate chinese Ce_NV_pussy_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:338
translate chinese Ce_NV_pussy_a186a787:

    # MC "(I’m glad this bitch is a heavy sleeper!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:340
translate chinese Ce_NV_pussy_e6e84b0c:

    # MC "(God, she looks fucking incredible... She's got the body of a pornstar!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:341
translate chinese Ce_NV_pussy_29359448:

    # MC "(I wonder if I’ll be able to cum, here, before she wakes up. I might as well give it a shot and see how far I get!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:343
translate chinese Ce_NV_pussy_957b0134:

    # MC "Ooohh... That’s the spot..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:345
translate chinese Ce_NV_pussy_3ba8484c:

    # Celia "Mmm hmm.... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:346
translate chinese Ce_NV_pussy_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:348
translate chinese Ce_NV_pussy_9ec851cc:

    # MC "Ooohhh... Right there... "
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:349
translate chinese Ce_NV_pussy_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:350
translate chinese Ce_NV_pussy_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:352
translate chinese Ce_NV_pussy_9e8941fe:

    # Celia "Mmm... Huh... I’m so..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:353
translate chinese Ce_NV_pussy_fa991ebe:

    # MC "(Fuck! She’s starting to wake up!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:355
translate chinese Ce_NV_pussy_03ea195c:

    # Celia "Gustav? Are you home?"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:356
translate chinese Ce_NV_pussy_dbac434b:

    # MC "(God dammit! I was SECONDS away from cumming, all over her pussy!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:357
translate chinese Ce_NV_pussy_00187f67:

    # MC " *Sigh* (Oh well, maybe next time.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:363
translate chinese Ce_NV_tits_165928d7:

    # MC "(It would be a shame to come ALL this way and not play with those massive tits, right?)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:364
translate chinese Ce_NV_tits_1fd83ef8:

    # MC "(Let’s get these bad boys out!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:366
translate chinese Ce_NV_tits_eb8d6e34:

    # MC "(Gently does it...)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:367
translate chinese Ce_NV_tits_3937d7b6:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:369
translate chinese Ce_NV_tits_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:370
translate chinese Ce_NV_tits_45e4ffd7:

    # MC "(Jackpot! Just look at those suckers! They’re fucking HUGE!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:372
translate chinese Ce_NV_tits_ff948b31:

    # MC "(I wonder if they’re natural? There’s no way she’s had work done on these. Right?)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:373
translate chinese Ce_NV_tits_a8376aaf:

    # MC "(I mean, I can’t see any surgery scars. They MUST be real, then?)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:375
translate chinese Ce_NV_tits_0cb49de6:

    # Celia "*Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:376
translate chinese Ce_NV_tits_b66d5b10:

    # MC "(Hehe, I love these nipples. They’re so perky!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:378
translate chinese Ce_NV_tits_8cc05f22:

    # MC "(I’d love to shove my cock between them.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:379
translate chinese Ce_NV_tits_91cd9096:

    # MC "(I’d thrust and thrust until I blew my load all over her smarmy face!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:381
translate chinese Ce_NV_tits_6255a393:

    # MC "(Time to give them a squeeze!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:382
translate chinese Ce_NV_tits_3937d7b6_1:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:384
translate chinese Ce_NV_tits_3f039335:

    # MC "(Oh yeah! That’s perfect!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:386
translate chinese Ce_NV_tits_1a1893ef:

    # Celia "Mmm... Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:388
translate chinese Ce_NV_tits_33caa687:

    # MC "(Look at that! They spring back perfectly!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:389
translate chinese Ce_NV_tits_3937d7b6_2:

    # Celia "Zzz..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:390
translate chinese Ce_NV_tits_b1bc6a36:

    # MC "(She’s sleeping like a bear in Winter. I think I’ll try sucking on her tits now.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:392
translate chinese Ce_NV_tits_1a610654:

    # Celia "Mmm... *Snore*"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:393
translate chinese Ce_NV_tits_534f3aed:

    # MC "(That’s it, keep snoozing, Celia.)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:395
translate chinese Ce_NV_tits_496b593d:

    # MC "*Suck*"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:397
translate chinese Ce_NV_tits_ebdc30b6:

    # Celia "Ohh...."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:399
translate chinese Ce_NV_tits_1aad3a87:

    # Celia "Ohh... ([player_name] is making me wet...)"
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:401
translate chinese Ce_NV_tits_90128fc0:

    # MC "(Mmm, this is amazing!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:402
translate chinese Ce_NV_tits_988f7f87:

    # MC "*Suck* *Suck*"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:403
translate chinese Ce_NV_tits_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:405
translate chinese Ce_NV_tits_ad9a35f0:

    # MC "*Suck* *Slurp*"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:406
translate chinese Ce_NV_tits_13e88d67:

    # Celia "F... Fuck.... Ah..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:407
translate chinese Ce_NV_tits_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:409
translate chinese Ce_NV_tits_de507756:

    # Celia "Oh God... Mmm..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:410
translate chinese Ce_NV_tits_ae3ac66f:

    # MC "(Huh? Fuck! She’s waking up! I was just getting started!)"
    MC ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:412
translate chinese Ce_NV_tits_5225f1aa:

    # Celia "Huh? Oh..."
    Celia ""

# game/scripts/Ce_R2/Ce_NV_S.rpy:413
translate chinese Ce_NV_tits_fe348db6:

    # Celia "(I was having the strangest dream...)"
    Celia ""

