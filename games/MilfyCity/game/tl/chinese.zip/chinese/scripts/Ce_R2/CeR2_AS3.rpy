﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_AS3.rpy:79
translate chinese CeR2_AS3_lab_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:80
translate chinese CeR2_AS3_lab_adb7b8a2:

    # MC "Are you not afraid of being seen in here?!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:81
translate chinese CeR2_AS3_lab_dbab40b9:

    # Celia "You weren’t afraid of me being seen when you were blackmailing me. What makes you think I give a flying fuck this time?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:84
translate chinese CeR2_AS3_lab_92af822a:

    # Celia "Now, get your ass in here."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:85
translate chinese CeR2_AS3_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:86
translate chinese CeR2_AS3_lab_eb796d11:

    # MC "(I wonder what she’s planning to do.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:89
translate chinese CeR2_AS3_lab_b3cdd352:

    # Celia "Stop dawdling. If you keep wasting time, someone is going to show up before I get a chance to close this damn door."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:90
translate chinese CeR2_AS3_lab_5df67409:

    # MC "Okay, coming now."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:93
translate chinese CeR2_AS3_lab_7a8db939:

    # MC "(She’s not wearing any underwear!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:94
translate chinese CeR2_AS3_lab_6f127cc5:

    # MC "(Is she expecting me to eat her out again - in here?)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:95
translate chinese CeR2_AS3_lab_5cb43c8d:

    # MC "(Or maybe she wants to fuck me?)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:98
translate chinese CeR2_AS3_lab_3f917b37:

    # MC "Uhh, do you want me to undress?"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:99
translate chinese CeR2_AS3_lab_a7976bba:

    # Celia "Lock the door."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:102
translate chinese CeR2_AS3_lab_db4eed68:

    # MC "Oh shit, sorry, I forgot."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:104
translate chinese CeR2_AS3_lab_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:105
translate chinese CeR2_AS3_lab_84ccea21:

    # MC "There we go. What do you want me to do now?"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:108
translate chinese CeR2_AS3_lab_788132a4:

    # Celia "You made my life a living hell for days upon days, [player_name]. I kinda liked that, you know?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:109
translate chinese CeR2_AS3_lab_16b8fbf1:

    # Celia " I woke up every morning not knowing if I would be forced to suck a cock or ride a dick."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:110
translate chinese CeR2_AS3_lab_4c7e0364:

    # Celia "Heck, for all I know, there might be videos of me stripping, uploaded onto PornHab!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:117
translate chinese CeR2_AS3_lab_d7608c4a:

    # MC "There isn’t any - I never recorded you on webcam!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:118
translate chinese CeR2_AS3_lab_c2c5b161:

    # Celia "Shut up. I don’t believe a single word you say."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:121
translate chinese CeR2_AS3_lab_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:122
translate chinese CeR2_AS3_lab_ece3e180:

    # MC "What do you want from me now? I’ve already apologised."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:125
translate chinese CeR2_AS3_lab_147b254f:

    # Celia "I don’t want an apology. You can’t make things better."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:126
translate chinese CeR2_AS3_lab_cf745f0f:

    # Celia "The only thing I want right now is revenge. Revenge for EVERYTHING that you have done to me."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:129
translate chinese CeR2_AS3_lab_03927fb2:

    # MC "What are you going to do? Strangle me in the toilet?"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:130
translate chinese CeR2_AS3_lab_352c7205:

    # Celia "Heh, strangling you wouldn’t be enough for me. I want to see you thoroughly and utterly broken."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:133
translate chinese CeR2_AS3_lab_8af6e038:

    # MC "What are you-"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:134
translate chinese CeR2_AS3_lab_aeda2160:

    # Celia "Let’s hope the janitor is thorough when he cleans these things!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:135
translate chinese CeR2_AS3_lab_e2d254b0:

    # MC "W-Wait!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:138
translate chinese CeR2_AS3_lab_8ed44592:

    # MC "*BLURP* *GURGLE*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:139
translate chinese CeR2_AS3_lab_a4868fd1:

    # Celia "FUCK! YOU!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:140
translate chinese CeR2_AS3_lab_17f8ff03:

    # Celia "THIS IS FOR TRYING TO RUIN MY LIFE!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:145
translate chinese CeR2_AS3_lab_eb213679:

    # MC "MPFPFFFF!! *BLURP*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:146
translate chinese CeR2_AS3_lab_d9fb04bb:

    # MC "(Shit! I can’t breathe!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:148
translate chinese CeR2_AS3_lab_79bc046b:

    # MC "MPPFFF!!!! *GURGLE* (This BDSM roleplay is fucking hard! She’s soo good at this!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:149
translate chinese CeR2_AS3_lab_bc422f11:

    # MC "(I keep expecting her to break character, but she never even slips up for a second!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:152
translate chinese CeR2_AS3_lab_1b106f3c:

    # Celia "I hope you can still hear me! Because we’re only getting started!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:153
translate chinese CeR2_AS3_lab_021ac6a2:

    # Celia "You better hold your breath, boy!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:157
translate chinese CeR2_AS3_lab_b5c6797e:

    # "*FLUSH*"
    ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:160
translate chinese CeR2_AS3_lab_a9f1f63b:

    # MC "MPPFFF!!!! *GURGLE*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:161
translate chinese CeR2_AS3_lab_a8311a73:

    # Celia "Do you feel the disgust? The humiliation? The degradation?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:162
translate chinese CeR2_AS3_lab_d90f27f3:

    # Celia "This is how I felt, every fucking day!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:165
translate chinese CeR2_AS3_lab_81450acf:

    # Celia "But I suppose I better let you come up for a breath now."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:166
translate chinese CeR2_AS3_lab_60ac03bf:

    # MC "*GASP*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:169
translate chinese CeR2_AS3_lab_fc7f9667:

    # MC "*Cough* *Splutter*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:170
translate chinese CeR2_AS3_lab_f0fe7bb4:

    # MC "Y-You’re *Splutter* disgusting... *Cough*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:173
translate chinese CeR2_AS3_lab_1181e55b:

    # Celia "I love it when you get angry. You’re like a little chihuahua - so noisy, yet so powerless."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:174
translate chinese CeR2_AS3_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:175
translate chinese CeR2_AS3_lab_90dd53ea:

    # Celia "We’re wasting time, though. Let’s move onto the main event."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:178
translate chinese CeR2_AS3_lab_ec24a1d2:

    # Celia "C’mere, boy."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:179
translate chinese CeR2_AS3_lab_6296908f:

    # MC "F-Fuck you... *cough*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:182
translate chinese CeR2_AS3_lab_64ed0436:

    # Celia "I said come here!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:183
translate chinese CeR2_AS3_lab_3ef2838a:

    # MC "You almost fucking drowned me!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:184
translate chinese CeR2_AS3_lab_986e730f:

    # Celia "Ugh, you’re so melodramatic."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:191
translate chinese CeR2_AS3_lab_90bb3144:

    # Celia "Get over here and lick my pussy. Now!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:192
translate chinese CeR2_AS3_lab_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:193
translate chinese CeR2_AS3_lab_9c5de4f8:

    # Celia "Do you want your face flushed down the toilet again?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:196
translate chinese CeR2_AS3_lab_6ab1f08a:

    # Celia "Mmm... See? That wasn’t so hard."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:197
translate chinese CeR2_AS3_lab_9a3b05e4:

    # Celia "Obeying your mistress makes things so much simpler. Doesn’t it?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:198
translate chinese CeR2_AS3_lab_aef2252b:

    # MC "*Lick* "
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:201
translate chinese CeR2_AS3_lab_8552eb18:

    # Celia "Ohh... yeah. Mmm."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:202
translate chinese CeR2_AS3_lab_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:205
translate chinese CeR2_AS3_lab_1de4b9b9:

    # Celia "Mmm! Get your tongue deep in there! Ahh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:206
translate chinese CeR2_AS3_lab_c298f5f7:

    # MC "*Shlurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:207
translate chinese CeR2_AS3_lab_63a21fe8:

    # Celia "Ahh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:210
translate chinese CeR2_AS3_lab_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:211
translate chinese CeR2_AS3_lab_d7831259:

    # Celia "Oh God! Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:214
translate chinese CeR2_AS3_lab_280be771:

    # Celia "Fuck..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:215
translate chinese CeR2_AS3_lab_716e494d:

    # Celia "(This is heavenly... I could REALLY get used to having my pussy eaten out whenever I want.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:218
translate chinese CeR2_AS3_lab_873c6969:

    # Celia "*Pant* *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:219
translate chinese CeR2_AS3_lab_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:222
translate chinese CeR2_AS3_lab_845fb1cb:

    # Celia "(Fuck, I have to pull him in closer! This feels TOO damn good!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:223
translate chinese CeR2_AS3_lab_d8e6e578:

    # MC "*Suck* *Shlurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:224
translate chinese CeR2_AS3_lab_3a85be09:

    # Celia "Ah! AHHH! AYAAAHHHH!!!!! I’m cumming!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:227
translate chinese CeR2_AS3_lab_06ee024b:

    # Celia "H-Holy shit! AHHH! Ohhhh Goddddd!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:228
translate chinese CeR2_AS3_lab_de900249:

    # MC "(How much longer is she expecting me to do this for?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:231
translate chinese CeR2_AS3_lab_c64dd207:

    # Celia "Ah! Ahhh! AHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:232
translate chinese CeR2_AS3_lab_e0e380e5:

    # MC "(Is she not even worried about someone hearing us in here?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:233
translate chinese CeR2_AS3_lab_5b70b21e:

    # MC "(She’s completely throwing caution to the wind right now!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:236
translate chinese CeR2_AS3_lab_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:237
translate chinese CeR2_AS3_lab_4317c7ae:

    # Celia "Why’d you stop?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:238
translate chinese CeR2_AS3_lab_b17002f9:

    # MC "My tongue... I’m exhausted!"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:241
translate chinese CeR2_AS3_lab_0a1f79cf:

    # Celia "Tough shit. I was exhausted, every night you made me stay up late and perform for you on camera."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:242
translate chinese CeR2_AS3_lab_d1f996a8:

    # MC "But, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:245
translate chinese CeR2_AS3_lab_13220b99:

    # Celia "I’ll spread my legs. Does that help?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:246
translate chinese CeR2_AS3_lab_69d7718b:

    # MC "Not really..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:247
translate chinese CeR2_AS3_lab_beb99617:

    # Celia "Well, I honestly don’t care. Chop chop!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:250
translate chinese CeR2_AS3_lab_3f7459e1:

    # MC "*Pant* Just, give me a minute to catch my breath."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:251
translate chinese CeR2_AS3_lab_6f8b5faf:

    # Celia "Like the way you gave me breaks when I was sucking your cock?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:252
translate chinese CeR2_AS3_lab_278dad06:

    # Celia "Do you think {b}I{/b} could breathe when you were making me deepthroat you?"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:255
translate chinese CeR2_AS3_lab_2ffb9920:

    # MC "P-Point taken..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:256
translate chinese CeR2_AS3_lab_ac908534:

    # Celia "Good boy - you’re finally seeing some sense!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:259
translate chinese CeR2_AS3_lab_83bd14bb_2:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:260
translate chinese CeR2_AS3_lab_e7cc741c:

    # Celia "Mmm... Ohh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:263
translate chinese CeR2_AS3_lab_cfd1749f:

    # Celia "You’ve got a talent for doing this. Ahh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:264
translate chinese CeR2_AS3_lab_73b98d33:

    # MC "*Slurp* *Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:265
translate chinese CeR2_AS3_lab_134e3cde:

    # Celia "Ohh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:268
translate chinese CeR2_AS3_lab_47efa6ca:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:269
translate chinese CeR2_AS3_lab_a963ff5f:

    # Celia "Ahh... Ohh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:272
translate chinese CeR2_AS3_lab_c298f5f7_1:

    # MC "*Shlurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:274
translate chinese CeR2_AS3_lab_bb722cd1:

    # Celia "Mmm, just like that... Focus on my clitoris. Ahh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:276
translate chinese CeR2_AS3_lab_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:278
translate chinese CeR2_AS3_lab_352f0920:

    # Celia "Oh God... *Gasp*"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:280
translate chinese CeR2_AS3_lab_5930eaa0:

    # Celia "Ahhhh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:283
translate chinese CeR2_AS3_lab_ea9ef68c:

    # Celia "Right there! That’s the spot! Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:285
translate chinese CeR2_AS3_lab_1dc77284:

    # Celia "Don’t stop, [player_name]! Lick my fucking pussy!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:286
translate chinese CeR2_AS3_lab_98b1236d:

    # Celia "O-Okay! W-Wow, let’s swap positions! Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:289
translate chinese CeR2_AS3_lab_cf22bb32:

    # Celia "I want you to eat me out from behind now."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:290
translate chinese CeR2_AS3_lab_46506e91:

    # MC "*Pant* S-Sure..."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:291
translate chinese CeR2_AS3_lab_96a62998:

    # Celia "Aww, don’t look so down. You’ll build up stamina doing this. Soon you’ll be able to do it for an hour without breaking a sweat!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:294
translate chinese CeR2_AS3_lab_83bd14bb_3:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:295
translate chinese CeR2_AS3_lab_260f6fc0:

    # MC "(Great... I’m going to spend the rest of my life, doing nothing but eating pussy.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:296
translate chinese CeR2_AS3_lab_929de295:

    # MC "(I suppose there ARE worse ways to go.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:299
translate chinese CeR2_AS3_lab_01c229f7:

    # Celia "Ahhh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:300
translate chinese CeR2_AS3_lab_a1f3e861:

    # Celia "Oh! Yes! MMM!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:303
translate chinese CeR2_AS3_lab_dc9ddee6:

    # Celia "Oh God! Fuck! Ahhh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:304
translate chinese CeR2_AS3_lab_47efa6ca_1:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:307
translate chinese CeR2_AS3_lab_4be753dc:

    # Celia "I’m getting close! Mmm! Don’t stop! Ahh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:308
translate chinese CeR2_AS3_lab_7dfbceb2:

    # MC "*SHLURP* *LICK*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:309
translate chinese CeR2_AS3_lab_4e21b05f:

    # Celia "AHHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:312
translate chinese CeR2_AS3_lab_105d4805:

    # Celia "Oh God! Oh God! Yes!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:314
translate chinese CeR2_AS3_lab_582deac0:

    # MC "*LICK LICK* *SHLURP* *SUCK*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:316
translate chinese CeR2_AS3_lab_83bd14bb_4:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:318
translate chinese CeR2_AS3_lab_6a61471f:

    # MC "(Her legs are starting to shake! I think this is the big climax she was wanting!)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:319
translate chinese CeR2_AS3_lab_8a8b89bf:

    # Celia "AAAAHHHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:322
translate chinese CeR2_AS3_lab_d5e8907b:

    # MC "*LICK* *SUCK* *SLURP*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:324
translate chinese CeR2_AS3_lab_a8fd41e1:

    # Celia "F-Fuck! I’m cummminng! AAAAYAAAAAAHHHHHHHH!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:326
translate chinese CeR2_AS3_lab_6b79174f:

    # MC "*LICK*"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:327
translate chinese CeR2_AS3_lab_443a7d48:

    # Celia "*PANT* *GASP* OHHHH MY GOOOODDDDDDD!!!!"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:330
translate chinese CeR2_AS3_lab_e6cbc9b8:

    # Celia "Well, that was *Pant* very enjoyable."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:331
translate chinese CeR2_AS3_lab_e5cc9be6:

    # Celia "I’ll be expecting you to use that tongue much more often."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:334
translate chinese CeR2_AS3_lab_88e045b7:

    # Celia "Now scram! I have to get changed. It’ll look suspicious if we leave at the same time."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:335
translate chinese CeR2_AS3_lab_ad029612:

    # MC "Won’t it look suspicious if you come out of the men’s toilets, for any reason?"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:336
translate chinese CeR2_AS3_lab_2ff3a777:

    # Celia "Get out. Now."
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:339
translate chinese CeR2_AS3_lab_09990932:

    # MC "Ugh, fine."
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:344
translate chinese CeR2_AS3_lab_09d06ab8_1:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:346
translate chinese CeR2_AS3_lab_e57f9db9:

    # MC "(I can’t keep living like this. I need to find a way out of this predicament.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:348
translate chinese CeR2_AS3_lab_f33fd6b4:

    # MC "(As fun as this is, I think I need to find a way to get myself back in the dominant position in this relationship.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:349
translate chinese CeR2_AS3_lab_72588daf:

    # MC "(But how?)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:352
translate chinese CeR2_AS3_lab_8b9aa066:

    # MC "(Hmm, maybe I should speak with Judy? She has been a good help so far.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:353
translate chinese CeR2_AS3_lab_75b6df21:

    # MC "(Even if her advice has been... unorthodox.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:356
translate chinese CeR2_AS3_lab_4d9dfefc:

    # MC "(At this point, an unorthodox solution might be exactly what I need.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:357
translate chinese CeR2_AS3_lab_c52a221a:

    # MC "(I’ll go and see Judy whenever she’s free.)"
    MC ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:360
translate chinese CeR2_AS3_lab_e20f9d64:

    # Celia "(Heh, I almost felt bad for him there. He didn’t even put up much of a fight.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:362
translate chinese CeR2_AS3_lab_b1f1fda4:

    # Celia "(That must be his spirit almost broken. He’ll be a perfect sex slave for me soon enough.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_AS3.rpy:364
translate chinese CeR2_AS3_lab_ef1ce0e6:

    # Celia "(He’s such a good little pussy eater. I’m going to enjoy using him every single day.)"
    Celia ""

