﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:39
translate chinese CeR2_MS2_lab_a9d45d92:

    # MC "Hi Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:40
translate chinese CeR2_MS2_lab_b607a1ae:

    # Celia "Hi, [player_name]. It’s good you’re here. I wanted to talk with you about something."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:41
translate chinese CeR2_MS2_lab_5a630605:

    # MC "Oh?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:42
translate chinese CeR2_MS2_lab_7c1f9a40:

    # Celia "Is there anything you would like to confess before we begin?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:45
translate chinese CeR2_MS2_lab_52ab216e:

    # MC "Begin what? What do you mean?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:47
translate chinese CeR2_MS2_lab_e5cfdeb2:

    # MC "(She can’t have worked out it’s me. Can she?)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:49
translate chinese CeR2_MS2_lab_d9b212ed:

    # MC "(Huh... This is an interesting turn of events. I wonder what direction she’s trying to take our little roleplay.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:55
translate chinese CeR2_MS2_lab_0e15247b:

    # Celia "Look, let’s cut this bullshit. We both know it was you."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:56
translate chinese CeR2_MS2_lab_24a5f086:

    # MC "We know what was me? "
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:57
translate chinese CeR2_MS2_lab_61453f21:

    # Celia "Fair enough. If you’re not going to admit to it, then I guess we’ll just have to go for some more drastic measures."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:60
translate chinese CeR2_MS2_lab_4b7145f6:

    # MC "What the hell are you talking about? Are you accusing me of something?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:61
translate chinese CeR2_MS2_lab_e6ac90e7:

    # MC "All I’ve done is try and help you, and what do I get in return? Spurious accusations that I might be the one blackmailing you?!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:62
translate chinese CeR2_MS2_lab_19cbab1c:

    # MC "You’re messed up!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:65
translate chinese CeR2_MS2_lab_ebeba8a5:

    # Celia "Alright, let’s cut the crap. I am not the kind of woman you want to mess with!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:66
translate chinese CeR2_MS2_lab_2f3df3de:

    # Celia "I can easily break you down and make your sorry little ass beg for mercy!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:69
translate chinese CeR2_MS2_lab_06b04608:

    # Celia "So, let’s sit down and talk about this. Shall we?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:71
translate chinese CeR2_MS2_lab_97aabd22:

    # MC "(It’ll look suspicious if I run away now. I better sit down.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:73
translate chinese CeR2_MS2_lab_acab162c:

    # MC "(Ahh, she wants to pretend as if she’s growing suspicious of me! Alright, I’ll play along!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:74
translate chinese CeR2_MS2_lab_2e2c016d:

    # MC "Alright."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:77
translate chinese CeR2_MS2_lab_925f6a5a:

    # Celia "So, [player_name], the funniest thing happened the other day. My blackmailer brought me to the toilet and made me suck their cock, or possibly one of their friends."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:78
translate chinese CeR2_MS2_lab_5a59d2de:

    # MC "Okay..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:82
translate chinese CeR2_MS2_lab_6a778a3c:

    # Celia "(Time for a little bit of bluffing. Let’s see if he was in the toilets at the time I was there. I can’t be certain, but I might be able to trick him into talking.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:84
translate chinese CeR2_MS2_lab_d559d0e7:

    # Celia "(I gotta give it to, [player_name]. He’s a quick-thinker when it comes to improvising. Let’s see if he’s willing to take our roleplay in a slightly different direction.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:85
translate chinese CeR2_MS2_lab_2e840588:

    # Celia "So, I waited outside the men’s toilets and the darndest thing happened..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:87
translate chinese CeR2_MS2_lab_ee03b2f7:

    # MC "(Oh fuck... She couldn’t have seen me, right?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:89
translate chinese CeR2_MS2_lab_1e511b0c:

    # MC "(Is she going to pretend that she saw me coming out?)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:92
translate chinese CeR2_MS2_lab_854fefbf:

    # Celia "You walked out of them."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:93
translate chinese CeR2_MS2_lab_13957471:

    # MC "Wait - A LOT of guys in college use those toilets."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:94
translate chinese CeR2_MS2_lab_f57381e0:

    # Celia "I never saw you go into them, which leads me to believe you were already in them."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:97
translate chinese CeR2_MS2_lab_0b77e2ae:

    # MC "I- I don’t know what you’re talking about."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:98
translate chinese CeR2_MS2_lab_a56eaf5e:

    # Celia "How did you end up in those toilets, [player_name]?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:99
translate chinese CeR2_MS2_lab_0f47a3de:

    # MC "I... I must have already been in them before you went in. The blackmailer must have left after I did."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:100
translate chinese CeR2_MS2_lab_6b34e4cd:

    # Celia "Oh yeah? And why did it take you so long before you came out of the toilet?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:101
translate chinese CeR2_MS2_lab_0f450c07:

    # MC "I was constipated!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:104
translate chinese CeR2_MS2_lab_e0c500a8:

    # Celia "That’s a load of shit!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:107
translate chinese CeR2_MS2_lab_5872181c:

    # MC "Quite the opposite, actually..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:110
translate chinese CeR2_MS2_lab_8d9d67e6:

    # Celia "Let’s assume you were constipated. Why didn’t you hear me sucking off my assailant?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:111
translate chinese CeR2_MS2_lab_0d8c67f6:

    # MC "I was... uhh..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:112
translate chinese CeR2_MS2_lab_30d4977a:

    # Celia "You must have heard some noises? Why didn’t you think to check what was going on in the stall beside you?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:117
translate chinese CeR2_MS2_lab_a74f167a:

    # MC "(Shit... Think, [player_name]! You can lie your way out of this one.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:119
translate chinese CeR2_MS2_lab_a4c8bca6:

    # MC "(Damn, she’s good! I’ll have to try and think up a better story. I don’t want to disappoint her when she’s enjoying this roleplay so much!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:120
translate chinese CeR2_MS2_lab_20f486bc:

    # MC "I was... listening to music with my earphones in! That must be why I never heard you."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:123
translate chinese CeR2_MS2_lab_d3505051:

    # Celia "BULL! FUCKING! SHIT!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:124
translate chinese CeR2_MS2_lab_bb102ffe:

    # Celia "You’re a liar, [player_name] - and I’ve caught you red-handed!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:127
translate chinese CeR2_MS2_lab_e94b8b66:

    # MC "Fuck you! I’m leaving! You’re on your own!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:128
translate chinese CeR2_MS2_lab_299a746a:

    # MC "I tried to help you out, but you’re fucking psychotic! You know that?!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:132
translate chinese CeR2_MS2_lab_5eb6cde0:

    # Celia "Ugh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:134
translate chinese CeR2_MS2_lab_54c6fb30:

    # Celia "Ugh! (I had a small hope that he would come up with some brilliant plan.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:135
translate chinese CeR2_MS2_lab_4087d4a1:

    # Celia "You know what? I gave you a chance to come clean about everything."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:138
translate chinese CeR2_MS2_lab_9a67ae10:

    # Celia "Where are you going?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:139
translate chinese CeR2_MS2_lab_3112e381:

    # MC "I’m leaving. I have classes to attend."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:142
translate chinese CeR2_MS2_lab_df8f9a6b:

    # MC "Whoa! Hey! What the hell are you doing?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:143
translate chinese CeR2_MS2_lab_bada9eaa:

    # Celia "Teaching you not to mess with the wrong woman!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:150
translate chinese CeR2_MS2_lab_a745e446:

    # Celia "I know it was you."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:151
translate chinese CeR2_MS2_lab_f19290cc:

    # MC "You’re insane! I’m the one who has been trying to HELP you!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:154
translate chinese CeR2_MS2_lab_10cf186a:

    # Celia "I don’t buy it. Not for a single second."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:155
translate chinese CeR2_MS2_lab_49ff25ea:

    # MC "How am I supposed to prove I’m innocent? If I were the blackmailer, why on Earth would I be trying to help you catch me?! It doesn’t make ANY sense!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:158
translate chinese CeR2_MS2_lab_f374c809:

    # MC "(Heh, I’ve got a really nice view of her panties, down here!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:159
translate chinese CeR2_MS2_lab_f469505e:

    # MC "(It’s a shame I’m not looking at them under more relaxed circumstances.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:162
translate chinese CeR2_MS2_lab_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:163
translate chinese CeR2_MS2_lab_545582f1:

    # MC "See? I was actually the ONLY person in this place trying to help you."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:166
translate chinese CeR2_MS2_lab_ba8475e6:

    # MC "We could have teamed up together to solve this!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:167
translate chinese CeR2_MS2_lab_a8262a0a:

    # MC "But now you’ve gone and pushed me away. You’re alone again."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:170
translate chinese CeR2_MS2_lab_06b4430a:

    # MC "I know you’re angry and frustrated. Guess what - so am I! "
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:171
translate chinese CeR2_MS2_lab_ae573220:

    # MC "We should have been handling this together. We were so close to catching the bastard who was behind this."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:173
translate chinese CeR2_MS2_lab_649bbbe5:

    # Celia "([player_name]...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:176
translate chinese CeR2_MS2_lab_fe96480f:

    # MC "I want nothing to do with you anymore."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:177
translate chinese CeR2_MS2_lab_5ef83ccb:

    # MC "Good luck with the blackmailer."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:180
translate chinese CeR2_MS2_lab_326855ef:

    # MC "Goodbye, Celia."
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:182
translate chinese CeR2_MS2_lab_62d1ad46:

    # Celia "(I’m still pretty sure he is the one behind all of this. I just need to get some more evidence to catch him.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:184
translate chinese CeR2_MS2_lab_41812377:

    # Celia "(Mmm... Stepping on his chest like that was fun. Now I REALLY want to turn the tables in our little game. Let’s see if I can spin things around.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:188
translate chinese CeR2_MS2_lab_9c2444df:

    # MC "(I hope that I was convincing enough there!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:189
translate chinese CeR2_MS2_lab_bf829991:

    # MC "(I’ll have to arrange to fuck her in the cubicle. This bitch needs to be brought down a peg or two!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:192
translate chinese CeR2_MS2_lab_8462bec1:

    # Celia "(You can say all you want, I’m gonna catch you, you piece of shit.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:193
translate chinese CeR2_MS2_lab_c806f184:

    # Celia "(Next time I’m told to meet in the toilet I’m gonna wait outside for as long as it takes. When I see you coming out of it, and I’m certain I will, I’ll catch you red-handed.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:195
translate chinese CeR2_MS2_lab_d1e7040b:

    # MC "(I think Celia’s getting a little bored with the current arrangement of our roleplay. I’m getting a feeling that she wants to be the dominant one for a change!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:196
translate chinese CeR2_MS2_lab_6275fec6:

    # MC "(I’ll arrange to fuck her through the glor yhole. I think that will serve as a nice final ‘humiliation’ before I let her start regaining some control in this little game of ours.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:198
translate chinese CeR2_MS2_lab_0be30f75:

    # Celia "(I wonder what he has planned for me next... God, I can’t wait to log on to my webcam tonight.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS2_lab.rpy:199
translate chinese CeR2_MS2_lab_77b4d95e:

    # Celia "(Next time I'm told to meet in the toilets, I’m gonna wait outside for as long as it takes. When I see him coming out of it, and I’m certain I will, I’m gonna catch him red-handed and flip the script!)"
    Celia ""

