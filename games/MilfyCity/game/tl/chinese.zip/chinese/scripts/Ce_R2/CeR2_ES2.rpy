﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_ES2.rpy:95
translate chinese MC_computer_lab_e78eccbc:

    # MC "(I can't use It now.)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:109
translate chinese CeR2_ES2_lab_0304391f:

    # MC "(What the fuck?! How did she get in here?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:110
translate chinese CeR2_ES2_lab_1b03da30:

    # MC "C-Celia?! How did- What are you doing here?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:113
translate chinese CeR2_ES2_lab_4982de16:

    # Celia "Oh, hello [player_name]. I was in the neighbourhood, so I thought I would drop by."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:114
translate chinese CeR2_ES2_lab_b91c86a0:

    # MC "How did you get in?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:115
translate chinese CeR2_ES2_lab_1c4b6634:

    # Celia "Linda opened the door for me. A very kind woman, you know. I just explained that I was one of your professors and that I had to talk to you about your progress."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:118
translate chinese CeR2_ES2_lab_2357841e:

    # MC "You really shouldn’t be at my home, you know that?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:119
translate chinese CeR2_ES2_lab_5a562b13:

    # Celia "On the contrary, [player_name]. This is EXACTLY where I need to be right now."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:120
translate chinese CeR2_ES2_lab_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:123
translate chinese CeR2_ES2_lab_c9f764de:

    # Celia "You see, I’ve been doing a little bit of my own research. It was taking you so long to find that blackmailer, after all."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:124
translate chinese CeR2_ES2_lab_4e929b1d:

    # Celia "I simply couldn’t wait for someone who was just so slow."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:125
translate chinese CeR2_ES2_lab_a570654c:

    # Celia "And then it occurred to me. All the little bits of evidence came together to form a rather interesting picture."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:126
translate chinese CeR2_ES2_lab_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:129
translate chinese CeR2_ES2_lab_285bd1ad:

    # Celia "It was you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:130
translate chinese CeR2_ES2_lab_87f7fa8a:

    # MC "I don’t know-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:131
translate chinese CeR2_ES2_lab_dc924f54:

    # Celia "Don’t bother trying to deny it. I’ve got you dead-to-rights, you piece of shit."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:134
translate chinese CeR2_ES2_lab_1acfa6e0:

    # MC "Celia, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:135
translate chinese CeR2_ES2_lab_3781ba2e:

    # Celia "Shut up. Don’t talk over me."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:136
translate chinese CeR2_ES2_lab_5fcc8bf6:

    # MC "You’ve come to the wrong conclusion!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:140
translate chinese CeR2_ES2_lab_5e1414c3:

    # Celia "Oh, have I?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:142
translate chinese CeR2_ES2_lab_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:144
translate chinese CeR2_ES2_lab_4be37e2b:

    # MC "(Oh fuck...)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:146
translate chinese CeR2_ES2_lab_6443cfbe:

    # MC "(Well, well! She’s turned the tables on me! I wonder what she has has planned for me...)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:149
translate chinese CeR2_ES2_lab_3e287af0:

    # MC "I, uh... How did that get there?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:150
translate chinese CeR2_ES2_lab_da7e6f3d:

    # Celia "It was you. From the very beginning, it was you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:151
translate chinese CeR2_ES2_lab_ad825399:

    # Celia "YOU were the one who has been making me strip for you on webcam!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:154
translate chinese CeR2_ES2_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:156
translate chinese CeR2_ES2_lab_10175f56:

    # MC "(I’m fucked.)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:158
translate chinese CeR2_ES2_lab_e104137f:

    # MC "(I wonder if she’s going to be as harsh on me as I was on her?)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:159
translate chinese CeR2_ES2_lab_2547122d:

    # Celia "You don’t have to say anything. I can already tell by that pathetic expression on your goddamn face."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:162
translate chinese CeR2_ES2_lab_e52b8c43:

    # MC "Sorry, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:163
translate chinese CeR2_ES2_lab_9396175f:

    # MC "*Hack*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:164
translate chinese CeR2_ES2_lab_4157835b:

    # Celia "Now, you and I are going to have a little chat."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:173
translate chinese CeR2_ES2_lab_933aa022:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:174
translate chinese CeR2_ES2_lab_324142f5:

    # MC "[Mom_name] is home! She’ll hear you if you-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:175
translate chinese CeR2_ES2_lab_2e22908e:

    # Celia "I said, shut up."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:178
translate chinese CeR2_ES2_lab_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:179
translate chinese CeR2_ES2_lab_64ecefe6:

    # MC "P-Please, Celia, I- I did it, but I’m sorry. I didn’t mean to-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:181
translate chinese CeR2_ES2_lab_0036fa1c:

    # Celia "God... You were like a lion when you were blackmailing me. So strong, so confident... Now you’re like a little worm. A pathetic little worm."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:183
translate chinese CeR2_ES2_lab_ac810a0b:

    # Celia "God... You were like a lion when you were in charge. So strong, so confident... Now you're like a little worm. A pathetic little worm."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:186
translate chinese CeR2_ES2_lab_5ef00a43:

    # Celia "You. Disgust. Me."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:187
translate chinese CeR2_ES2_lab_4c4c5a9c:

    # MC "S-Sorry! I understand if you hate me."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:188
translate chinese CeR2_ES2_lab_3c3c7de9:

    # Celia "I don’t hate you, [player_name]. I fucking loathe you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:189
translate chinese CeR2_ES2_lab_6e5b630a:

    # Celia "With every fibre of my being, every cell in my body, every thought going through my brain. I loathe you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:192
translate chinese CeR2_ES2_lab_049fbefc:

    # MC "*COUGH*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:193
translate chinese CeR2_ES2_lab_93523775:

    # MC "P-Please..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:194
translate chinese CeR2_ES2_lab_5ab512f7:

    # Celia "I wish I could just end you right now for what you did to me."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:197
translate chinese CeR2_ES2_lab_4639c4a2:

    # Celia "I hate you for all those times you made me suck and fuck your disgusting cock."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:199
translate chinese CeR2_ES2_lab_356b1ea7:

    # Celia "I hate you for that time you came inside me!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:201
translate chinese CeR2_ES2_lab_79e0ad5c:

    # Celia "I hate you for that time you came inside me! (Though it was kinda hot...)"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:202
translate chinese CeR2_ES2_lab_fc7f9667:

    # MC "*Cough* *Splutter*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:204
translate chinese CeR2_ES2_lab_086ec0de:

    # MC "(I can’t... breathe...)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:206
translate chinese CeR2_ES2_lab_4587b6b4:

    # MC "(She never gives up on this fantasy, does she?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:213
translate chinese CeR2_ES2_lab_a792ebb9:

    # "*BANG*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:214
translate chinese CeR2_ES2_lab_60ac03bf:

    # MC "*GASP*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:215
translate chinese CeR2_ES2_lab_ae2a7da3:

    # Celia "But, killing you really isn’t an option on the table. Is it?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:218
translate chinese CeR2_ES2_lab_354275f0:

    # Celia "You see, [player_name], I have much more ambitious plans for your future than putting you in a coffin."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:219
translate chinese CeR2_ES2_lab_4ef02b8f:

    # MC "*Gasp* *Pant*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:220
translate chinese CeR2_ES2_lab_9a340d1c:

    # Celia "You’re going to make a wonderful pet."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:223
translate chinese CeR2_ES2_lab_4dde94b1:

    # MC "*Gasp* P-Pet?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:224
translate chinese CeR2_ES2_lab_6eac88b7:

    # Celia "My own personal sex slave."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:225
translate chinese CeR2_ES2_lab_04bf345a:

    # Celia "Any time I want my pussy licked, or maybe my feet rubbed, you’ll be there."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:228
translate chinese CeR2_ES2_lab_c6e9d745:

    # Celia "And each time you ask, I expect to hear nothing come out of your mouth except, ‘Yes, Ma’am.’"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:229
translate chinese CeR2_ES2_lab_3ee09135:

    # Celia "Do I make myself clear?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:230
translate chinese CeR2_ES2_lab_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:231
translate chinese CeR2_ES2_lab_4d37fee2:

    # Celia "I said, do I make myself clear?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:232
translate chinese CeR2_ES2_lab_3ff32172:

    # MC "Y-Yes, Ma’am."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:235
translate chinese CeR2_ES2_lab_51b34031:

    # Celia "Heh, you’re a quick learner."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:236
translate chinese CeR2_ES2_lab_68cf88af:

    # Celia "But you’ve also been a very bad boy. And bad boys deserve punishment."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:237
translate chinese CeR2_ES2_lab_19570c32:

    # MC "What?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:240
translate chinese CeR2_ES2_lab_1acfa6e0_1:

    # MC "Celia, I-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:241
translate chinese CeR2_ES2_lab_5a49c95b:

    # Celia "Silence!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:246
translate chinese CeR2_ES2_lab_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:247
translate chinese CeR2_ES2_lab_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:250
translate chinese CeR2_ES2_lab_8a799876:

    # Celia "That was for everything you made me do on webcam."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:251
translate chinese CeR2_ES2_lab_76251dd0:

    # Celia "You humiliated me. And now I’m going to do the same to you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:254
translate chinese CeR2_ES2_lab_90ba0fe6:

    # MC "Please, don-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:255
translate chinese CeR2_ES2_lab_2ba205af:

    # Celia "Shut it!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:260
translate chinese CeR2_ES2_lab_4875f5be_1:

    # "*SLAP*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:261
translate chinese CeR2_ES2_lab_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:264
translate chinese CeR2_ES2_lab_192f4160:

    # Celia "THAT one was for all the times you made me use that DISGUSTING glory hole!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:265
translate chinese CeR2_ES2_lab_c12cbcc6:

    # MC "S-Sorry! I’m sorry!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:266
translate chinese CeR2_ES2_lab_6db40063:

    # Celia "Sorry isn’t going to butter my toast this time."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:269
translate chinese CeR2_ES2_lab_b925fe7c:

    # Celia "No amount of apologising, no quantity of grovelling, no whiny little whimpering, will get you out of this."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:270
translate chinese CeR2_ES2_lab_d05588f4:

    # Celia "I will never forgive you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:271
translate chinese CeR2_ES2_lab_c206a534:

    # Celia "As long as I have breath in my lungs and blood in my veins, I will make every day of your life a living hell."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:274
translate chinese CeR2_ES2_lab_e37d5cab:

    # Celia "I know you never paid much attention in Literature class, but may I suggest you read ‘No Exit’ by Sartre?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:275
translate chinese CeR2_ES2_lab_1f2aa214:

    # Celia "I don’t want to spoil the ending, but the hell I’m offering will pale in comparison to that. There will be no respite. The door to the exit will never open."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:276
translate chinese CeR2_ES2_lab_4b54fba3:

    # MC "Celia, please... Don’t do this! I can-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:283
translate chinese CeR2_ES2_lab_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:284
translate chinese CeR2_ES2_lab_46b8c40e:

    # MC "UGGGGHHH!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:287
translate chinese CeR2_ES2_lab_643fde9d:

    # MC "(Holy fuck... She’s really strong!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:288
translate chinese CeR2_ES2_lab_28e25343:

    # Celia "I bet you weren’t expecting to be hit that hard. A lot of men who try to fuck with me get that nasty surprise."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:289
translate chinese CeR2_ES2_lab_e096d8e5:

    # Celia "The last guy who groped my ass in a nightclub almost had his arm broken."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:292
translate chinese CeR2_ES2_lab_d7ae0149:

    # Celia "I’ve always been into my martial arts. My mother encouraged it from a young age. "
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:293
translate chinese CeR2_ES2_lab_a39de9f5:

    # Celia "It was the best thing she ever did for me - God rest her soul."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:294
translate chinese CeR2_ES2_lab_42a16ff7:

    # MC "*Cough* *Gasp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:297
translate chinese CeR2_ES2_lab_946ce4b3:

    # Celia "Stop acting so hurt. I just winded you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:298
translate chinese CeR2_ES2_lab_cecbadf8:

    # MC "Y-You’re... psychotic..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:300
translate chinese CeR2_ES2_lab_c29bf7d1:

    # Celia "Says the guy who blackmailed a girl, simply for turning him down. I’ve handled creeps like you all my life."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:302
translate chinese CeR2_ES2_lab_2f27883d:

    # Celia "Says the guy who blackmailed a girl, simply for turning him down. I’ve handled creeps like you all my life. (It amazes me he’s still into this roleplay... He’s much better than Gustav.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:305
translate chinese CeR2_ES2_lab_528631e9:

    # MC "Grr..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:307
translate chinese CeR2_ES2_lab_1a2b8eaa:

    # MC "(Fuck, how can I get out of this one?! Think, [player_name], think!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:309
translate chinese CeR2_ES2_lab_faa48481:

    # MC "(I’ll keep up my acting for the meantime and let her take control for a while. It seems like she’s enjoying the role reversal!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:312
translate chinese CeR2_ES2_lab_0ab77317:

    # Celia "So, while you were watching me on webcam, what were you doing?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:313
translate chinese CeR2_ES2_lab_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:314
translate chinese CeR2_ES2_lab_d6db9bcc:

    # Celia "I bet you were wanking yourself off."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:317
translate chinese CeR2_ES2_lab_977f69ee:

    # Celia "Rubbing your cock up and down while looking at my body."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:318
translate chinese CeR2_ES2_lab_08cbe4e8:

    # Celia "Haha! You couldn’t get close to a real woman without trickery and deception."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:321
translate chinese CeR2_ES2_lab_c0f06cf9:

    # MC "Ow..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:324
translate chinese CeR2_ES2_lab_f862b3f8:

    # MC "(God... my stomach fucking hurts!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:326
translate chinese CeR2_ES2_lab_c44f697e:

    # MC "(God... Even though she was acting, Celia still gives a pretty strong blow!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:329
translate chinese CeR2_ES2_lab_825c33d6:

    # Celia "So, were you jerking yourself off while you looked at me?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:330
translate chinese CeR2_ES2_lab_ec9b8cdc:

    # MC "...yes."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:331
translate chinese CeR2_ES2_lab_db0ebc97:

    # Celia "I knew it."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:334
translate chinese CeR2_ES2_lab_94c4b44b:

    # Celia "It’s hardly fair that you got to have all the pleasure while you were blackmailing me."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:335
translate chinese CeR2_ES2_lab_2f6536da:

    # Celia "I feel like I’m owed quite a lot."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:338
translate chinese CeR2_ES2_lab_08d98d9a:

    # Celia "And today is as good a day as any, for you to begin repaying your debt."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:339
translate chinese CeR2_ES2_lab_bff7bf80:

    # MC "W-What do you mean?"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:342
translate chinese CeR2_ES2_lab_3b826559:

    # Celia "We’ll begin with you eating me out."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:343
translate chinese CeR2_ES2_lab_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:344
translate chinese CeR2_ES2_lab_ce4e53ad:

    # Celia "Was I not clear? You’re going to be licking my pussy, and paying extra attention to my clitoris, until I tell you to stop."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:347
translate chinese CeR2_ES2_lab_47085d64:

    # Celia "I don’t care how tired your tongue gets. I don’t care if there are other people home right now who could potentially walk in on us."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:348
translate chinese CeR2_ES2_lab_b8530a52:

    # MC "B-But-"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:349
translate chinese CeR2_ES2_lab_577d3caa:

    # Celia "And you better do a good job. I’m sure Linda wouldn’t be too impressed with how you’ve been spending your free time blackmailing a professor."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:352
translate chinese CeR2_ES2_lab_67529b49:

    # Celia "Mmm, I’m really looking forward to this."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:353
translate chinese CeR2_ES2_lab_0816032b:

    # Celia "My husband has a peculiar quirk when it comes to giving head. It’s been far too long since someone actually went down on me."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:356
translate chinese CeR2_ES2_lab_a1cffbf2:

    # Celia "So, without further ado, let’s get to it."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:357
translate chinese CeR2_ES2_lab_4ab90a2e_2:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:360
translate chinese CeR2_ES2_lab_3ec3fd8c:

    # Celia "Come over here, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:361
translate chinese CeR2_ES2_lab_d3f0f9f1:

    # MC "Just *pant* let me catch my breath."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:363
translate chinese CeR2_ES2_lab_974d786f:

    # MC "(There has to be a way out of this!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:365
translate chinese CeR2_ES2_lab_68815b6f:

    # MC "(Well, I did have her suck my dick, so I guess this is a fair request!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:368
translate chinese CeR2_ES2_lab_78a32027:

    # Celia "Oh, come on! I didn’t knee you THAT hard!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:369
translate chinese CeR2_ES2_lab_2e76e4ef:

    # Celia "I’m not going to wait for you much longer. And I’m sure Linda is going to wonder why you’re spending so long with your professor in your bedroom."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:373
translate chinese CeR2_ES2_lab_8d48463a:

    # MC "(Fuck it. I really don’t have a choice right now. I’m going to have to lick her pussy.)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:375
translate chinese CeR2_ES2_lab_4c20469e:

    # MC "(Looks like I’m going to be eating her pussy tonight!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:376
translate chinese CeR2_ES2_lab_d52d2998:

    # Celia "Look, I’ll even sit down to make it easier for you."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:380
translate chinese CeR2_ES2_lab_db1d494a:

    # MC "(Gah, I’m not going down without a fight!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:382
translate chinese CeR2_ES2_lab_c992d2c4:

    # MC "(Hmm, I wonder if Celia would prefer me to pretend to put up a fight?)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:383
translate chinese CeR2_ES2_lab_88d1dc54:

    # MC "No way!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:384
translate chinese CeR2_ES2_lab_eed1522d:

    # Celia "Hmm?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:385
translate chinese CeR2_ES2_lab_5a02c586:

    # MC "I said, no way! I’m not putting my face down there!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:388
translate chinese CeR2_ES2_lab_ee444594:

    # Celia "How very foolish, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:389
translate chinese CeR2_ES2_lab_6489e55e:

    # Celia "I thought you’d already realised this, but I will spell it out for you if I have to."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:392
translate chinese CeR2_ES2_lab_4f0be952:

    # Celia "Defy me, and you’re dead meat."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:393
translate chinese CeR2_ES2_lab_130100c3:

    # Celia "That’s honestly all there is to it. I will do everything in my power to ruin your life, just like you did mine."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:394
translate chinese CeR2_ES2_lab_89d3fd6a:

    # Celia "If you think being my sex slave is the worst thing I could do to you, then you’re horribly mistaken."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:397
translate chinese CeR2_ES2_lab_de6094a2:

    # Celia "That girl who comes to college with you. Sara’s her name, right?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:398
translate chinese CeR2_ES2_lab_be34f01a:

    # Celia "I think she lives here as well."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:399
translate chinese CeR2_ES2_lab_c2b3e230:

    # Celia "It would be a shame if I was to dig up some dirt on her too. Maybe get her involved in this."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:400
translate chinese CeR2_ES2_lab_081a1137:

    # MC "No, don’t!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:403
translate chinese CeR2_ES2_lab_84453efb:

    # Celia "How do you think she’d enjoy licking my pussy every day?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:404
translate chinese CeR2_ES2_lab_29ec1c5b:

    # Celia "Or having me shove a big fat dildo into her tiny little virgin a-"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:405
translate chinese CeR2_ES2_lab_4836700e:

    # MC "Fine! I’ll do what you say - just leave Sara out of it!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:406
translate chinese CeR2_ES2_lab_3fcd3b03:

    # Celia "Good. Now stop wasting time, and get over here."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:409
translate chinese CeR2_ES2_lab_6eb95063:

    # Celia "That’s it... a bit closer."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:410
translate chinese CeR2_ES2_lab_7b44faa2:

    # Celia "(Hehe, I’m going to make the most of this.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:411
translate chinese CeR2_ES2_lab_8db12095:

    # Celia "Start licking, boy."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:414
translate chinese CeR2_ES2_lab_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:415
translate chinese CeR2_ES2_lab_0fad326d:

    # Celia "Ohh... Solid technique. Continue."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:418
translate chinese CeR2_ES2_lab_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:419
translate chinese CeR2_ES2_lab_8381282f:

    # MC "(God... This is so humiliating!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:420
translate chinese CeR2_ES2_lab_0a884fb0:

    # Celia "Ah... Yes..."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:423
translate chinese CeR2_ES2_lab_f232b05d:

    # Celia "Ohh... Fuck... "
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:424
translate chinese CeR2_ES2_lab_387b72ea:

    # MC "*Lick* *Shlurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:425
translate chinese CeR2_ES2_lab_00138d64:

    # Celia "Mmm, that’s good."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:428
translate chinese CeR2_ES2_lab_bd005120:

    # Celia "Oh, fuck... Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:429
translate chinese CeR2_ES2_lab_0b416c88:

    # Celia "*Pant* Whoa... Keep it up, boy."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:430
translate chinese CeR2_ES2_lab_73b98d33:

    # MC "*Slurp* *Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:433
translate chinese CeR2_ES2_lab_df483778:

    # Celia "Let’s speed things up a bit, now. Put that tongue to work!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:434
translate chinese CeR2_ES2_lab_d27930a6:

    # Celia "Unless, of course, you’d prefer me to bring Sara in here?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:435
translate chinese CeR2_ES2_lab_79380613:

    # MC "*LICK LICK LICK*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:438
translate chinese CeR2_ES2_lab_397c84b3:

    # Celia "Haha! Ohh! I suspected ah... that would motivate you! Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:440
translate chinese CeR2_ES2_lab_83357c3a:

    # Celia "Ohh! Fuck! Oh, yes!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:442
translate chinese CeR2_ES2_lab_99fb61cf:

    # MC "(Dammit! Why can’t she leave Sara out of this?! It has nothing to do with her!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:444
translate chinese CeR2_ES2_lab_70cd97e9:

    # MC "(I know I fucked her through a toilet glory hole, but threatening to bring Sara into this is a dirty move! Even for her!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:447
translate chinese CeR2_ES2_lab_e4536814:

    # MC "*LICK* *SLURP*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:450
translate chinese CeR2_ES2_lab_1e576280:

    # Celia "Ahhh... Oh my God! Mmm!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:453
translate chinese CeR2_ES2_lab_387b72ea_1:

    # MC "*Lick* *Shlurp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:455
translate chinese CeR2_ES2_lab_35485c82:

    # Celia "Ahh... I seem to have caught myself quite a prize! You’re not bad at eating pussy."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:456
translate chinese CeR2_ES2_lab_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:457
translate chinese CeR2_ES2_lab_134e3cde:

    # Celia "Ohh..."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:460
translate chinese CeR2_ES2_lab_7d0416d3:

    # Celia "Let’s bring your face in Mmm... even closer, shall we?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:461
translate chinese CeR2_ES2_lab_4b8d6185:

    # MC "Mppff!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:462
translate chinese CeR2_ES2_lab_a79ff2a8:

    # Celia "Ohhh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:465
translate chinese CeR2_ES2_lab_f9ea5a90:

    # Celia "Mmm! Ahh, that’s it! Focus on my fucking clit! Ahh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:466
translate chinese CeR2_ES2_lab_7f879ec5:

    # MC "*SLURP*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:467
translate chinese CeR2_ES2_lab_84016673:

    # Celia "(I’m getting so close to cumming!)"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:470
translate chinese CeR2_ES2_lab_65a58ca1:

    # Celia "Mmm! That’s it! Don’t stop! Ohh!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:471
translate chinese CeR2_ES2_lab_47efa6ca:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:472
translate chinese CeR2_ES2_lab_5c07f1b5:

    # Celia "Ah! AHH! AHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:475
translate chinese CeR2_ES2_lab_f6171b55:

    # Celia "Oh God! Yes! YES! AHHH!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:476
translate chinese CeR2_ES2_lab_e12cbfe6:

    # MC "(Damn it! I’m not going to make this arrogant bitch cum!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:479
translate chinese CeR2_ES2_lab_7c5be389:

    # Celia "Don’t ah... stop! I’m soooohhhh close!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:480
translate chinese CeR2_ES2_lab_f050ce10_1:

    # MC "*Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:483
translate chinese CeR2_ES2_lab_00830872:

    # Celia "Huh? Dammit! I was so close!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:484
translate chinese CeR2_ES2_lab_f0f133f4:

    # MC "I’m not licking your stupid cunt anymore."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:487
translate chinese CeR2_ES2_lab_5885c297:

    # Celia "Well, is that so?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:488
translate chinese CeR2_ES2_lab_36086fbc:

    # Celia "Let me show you what happens to disobedient pets."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:495
translate chinese CeR2_ES2_lab_933aa022_1:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:496
translate chinese CeR2_ES2_lab_e22b7fed:

    # MC "Ooofff!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:497
translate chinese CeR2_ES2_lab_8b7d0959:

    # MC "H-Hey! I’m sorry! Don’t hit me!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:500
translate chinese CeR2_ES2_lab_654c6943:

    # Celia "You’re gonna get what’s coming to you, [player_name]! Wanna play BDSM with ME!?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:501
translate chinese CeR2_ES2_lab_a761ca53:

    # MC "N-No, let go of me!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:504
translate chinese CeR2_ES2_lab_ba29a567:

    # Celia "I imagine this will leave quite a mark. I wonder how we’ll explain it to the Dean?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:505
translate chinese CeR2_ES2_lab_67c6ab31:

    # Celia "Perhaps you walked into the door by accident? That sounds like a good excuse."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:506
translate chinese CeR2_ES2_lab_cea225ce:

    # MC "N-No!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:509
translate chinese CeR2_ES2_lab_5ac48b80:

    # MC "P-Please! I’ll do anything! I’ll eat your pussy again!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:510
translate chinese CeR2_ES2_lab_8bb3cbf3:

    # MC "Just don’t punch me! (Fuck... I'm on the losing side today... I have no words...Judy was right from the beginning that she’s too experienced in that kind of thing.)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:511
translate chinese CeR2_ES2_lab_328502cf:

    # MC "I’ll eat your ass if you want me to!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:517
translate chinese CeR2_ES2_lab_933aa022_2:

    # "*THUD*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:518
translate chinese CeR2_ES2_lab_77a612f3:

    # MC "AHH!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:519
translate chinese CeR2_ES2_lab_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:522
translate chinese CeR2_ES2_lab_0e62c223:

    # Celia "I don’t want to bruise that pretty little face of yours. It looks far too good between my thighs."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:523
translate chinese CeR2_ES2_lab_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:524
translate chinese CeR2_ES2_lab_4f599552:

    # Celia "I hope you learned a very valuable lesson today. Pets don’t disobey their masters. Okay?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:527
translate chinese CeR2_ES2_lab_8077b1c0:

    # Celia "I said, okay?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:528
translate chinese CeR2_ES2_lab_a6fbf3fc:

    # MC "Y-Yes!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:529
translate chinese CeR2_ES2_lab_47000ecf:

    # Celia "Yes, what?"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:532
translate chinese CeR2_ES2_lab_cc76e025:

    # MC "Y-Yes, Ma’am!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:533
translate chinese CeR2_ES2_lab_4ab90a2e_3:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:534
translate chinese CeR2_ES2_lab_82214382:

    # Celia "Good. It’ll serve you well to not forget it again. Now, close your eyes."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:537
translate chinese CeR2_ES2_lab_388bb296:

    # MC "*Whimper*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:538
translate chinese CeR2_ES2_lab_39410c06:

    # Celia "Ahh... Punching your face would have been such a waste."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:541
translate chinese CeR2_ES2_lab_3c427cbd:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:542
translate chinese CeR2_ES2_lab_36793349:

    # MC "(She’s teasing me now. What the fuck does she want?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:545
translate chinese CeR2_ES2_lab_3c427cbd_1:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:546
translate chinese CeR2_ES2_lab_ba14338e:

    # Celia "(I think I’m going to enjoy having [player_name] as my personal toy.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:549
translate chinese CeR2_ES2_lab_6fa67b2e:

    # Celia "I have to leave now. Someone will be wondering why I've been in here for such a long time."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:550
translate chinese CeR2_ES2_lab_4ab90a2e_4:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:551
translate chinese CeR2_ES2_lab_ce43f2eb:

    # Celia "Now, where did I leave my skirt and panties."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:554
translate chinese CeR2_ES2_lab_34df74e5:

    # Celia "I’ll see you later, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:555
translate chinese CeR2_ES2_lab_4638c6c4:

    # Celia "Don’t forget, you’re mine forever. Anywhere, any place, and any time I ask."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:556
translate chinese CeR2_ES2_lab_2d204a49_3:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:557
translate chinese CeR2_ES2_lab_f7795790:

    # MC "Yes, Ma’am."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:560
translate chinese CeR2_ES2_lab_ce699557:

    # Linda "Oh! How did it go with, [player_name]?"
    Linda ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:561
translate chinese CeR2_ES2_lab_33598ecc:

    # Celia "I might have to come over a couple more times. He needs some extra tuition."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:562
translate chinese CeR2_ES2_lab_47709908:

    # Linda "I’m sorry to hear that. Hopefully it won’t be too taxing for you."
    Linda ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:563
translate chinese CeR2_ES2_lab_708cf638:

    # Celia "I don’t mind, it’s my job. Thank you for letting me into your home today. You’ve really got a lovely place."
    Celia ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:564
translate chinese CeR2_ES2_lab_0f5847f6:

    # Linda "You’re very kind, Professor Celia. I’ll show you to the front door."
    Linda ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:567
translate chinese CeR2_ES2_lab_56e95c7d:

    # MC "God. Dammit."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:569
translate chinese CeR2_ES2_lab_6af3b5a3:

    # MC "(I am completely and utterly fucked.)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:570
translate chinese CeR2_ES2_lab_d8e101e6:

    # MC "(She’s got me by the balls right now. I NEED to come up with a plan to escape from this. But how?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:572
translate chinese CeR2_ES2_lab_da46d111:

    # MC "(I can’t believe she actually came to my home! That said... I DID go to hers...)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:573
translate chinese CeR2_ES2_lab_096f68b0:

    # MC "(I wasn’t expecting her to become the dominant one. I wonder if Judy can give me any advice on how to regain some superiority here?)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:579
translate chinese CeR2_ES2_lab_3c726d8a_1:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:580
translate chinese CeR2_ES2_lab_e82436e1:

    # MC "ARRRGGGHHHH!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:581
translate chinese CeR2_ES2_lab_87c0a1d9:

    # MC "FUCK! SHIT!"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:586
translate chinese CeR2_ES2_lab_b4b0d056:

    # "*WHAM*"
    ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:589
translate chinese CeR2_ES2_lab_9c509c21:

    # MC "Ouch..."
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:590
translate chinese CeR2_ES2_lab_884065f9:

    # MC "(How the fuck did Celia punch the floor without batting an eyelid?)"
    MC ""

# game/scripts/Ce_R2/CeR2_ES2.rpy:591
translate chinese CeR2_ES2_lab_098763cf:

    # MC "(That bitch is strong.)"
    MC ""

