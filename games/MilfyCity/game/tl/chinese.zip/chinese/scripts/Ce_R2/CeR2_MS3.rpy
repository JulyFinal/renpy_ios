﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_MS3.rpy:40
translate chinese CeR2_MS3_lab_a9cd629e:

    # Celia "What do you want? I'll be waiting for you in the toilets in afternoon."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:53
translate chinese CeR2_MS3_lab_6fd705bb:

    # MC "I got your text message. What do you want from me?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:54
translate chinese CeR2_MS3_lab_01d358fd:

    # Celia "That’s hardly a good way to talk to your professor."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:55
translate chinese CeR2_MS3_lab_e3c7c221:

    # Celia "Especially when you were late to my class."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:57
translate chinese CeR2_MS3_lab_6f2e3592:

    # MC "Listen, I’m sorry about being late. I’ve got a lot of shit going on right-"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:58
translate chinese CeR2_MS3_lab_702e8268:

    # Celia "Hush, I’m not here to listen to your lame excuses."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:60
translate chinese CeR2_MS3_lab_c374529d:

    # Celia "Get down on your knees."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:61
translate chinese CeR2_MS3_lab_ce40cb08:

    # MC "What?! I’m not gonna do that!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:62
translate chinese CeR2_MS3_lab_2fdee9f6:

    # Celia "Kneel, boy! Or I’ll tell Sara everything that has happened."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:64
translate chinese CeR2_MS3_lab_528631e9:

    # MC "Grr..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:65
translate chinese CeR2_MS3_lab_fbbca020:

    # MC "What the hell are you expecting me to do right now? Lick your cunt again?"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:67
translate chinese CeR2_MS3_lab_60be1eff:

    # Celia "I wish I could. Unfortunately though, there are far too many people who could walk in and interrupt us."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:68
translate chinese CeR2_MS3_lab_9d845e01:

    # MC "Lucky for me."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:69
translate chinese CeR2_MS3_lab_ec25b479:

    # Celia "Oh, come on now, [player_name]. There’s no need for the sarcasm."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:71
translate chinese CeR2_MS3_lab_641455d4:

    # Celia "All you’re going to do today is lick my hand. It’s really that simple."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:72
translate chinese CeR2_MS3_lab_f4ac641b:

    # MC "Yeah, fuck that. It ain’t happening."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:74
translate chinese CeR2_MS3_lab_104cadc2:

    # Celia "*Sigh*"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:75
translate chinese CeR2_MS3_lab_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:79
translate chinese CeR2_MS3_lab_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:80
translate chinese CeR2_MS3_lab_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:82
translate chinese CeR2_MS3_lab_cfda7928:

    # Celia "That is just an appetiser of what’s to come if you refuse to obey me."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:83
translate chinese CeR2_MS3_lab_1bca1abf:

    # Celia "Have I made myself crystal clear?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:85
translate chinese CeR2_MS3_lab_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:86
translate chinese CeR2_MS3_lab_f306d629:

    # Celia "I said, have I made myself crystal clear?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:87
translate chinese CeR2_MS3_lab_f7795790:

    # MC "Yes, Ma’am."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:89
translate chinese CeR2_MS3_lab_14692f11:

    # Celia "There is only one person to blame for the situation you find yourself in right now."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:90
translate chinese CeR2_MS3_lab_ffc5ddd5:

    # Celia "That is you, and you alone."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:91
translate chinese CeR2_MS3_lab_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:93
translate chinese CeR2_MS3_lab_752c33e2:

    # Celia "Now, let’s stop wasting time. We both have places to be."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:94
translate chinese CeR2_MS3_lab_4116445b:

    # Celia "Get over here and lick my hand."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:97
translate chinese CeR2_MS3_lab_0f30515f:

    # MC "(Fuck, I don’t know what to do. I really don’t want to give in to this bitch.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:98
translate chinese CeR2_MS3_lab_cc50a2af:

    # MC "(But she’s already slapped me. I don’t want her to do anything worse...)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:100
translate chinese CeR2_MS3_lab_259a2ee4:

    # MC "(It’s a weird dynamic to suddenly being the one who has to give in. I can see why she enjoyed it!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:101
translate chinese CeR2_MS3_lab_bd289c18:

    # MC "(And it was kinda hot the way she slapped me like that...)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:102
translate chinese CeR2_MS3_lab_ffed7cf3:

    # Celia "I’m waiting, [player_name]."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:108
translate chinese CeR2_MS3_lab_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:109
translate chinese CeR2_MS3_lab_95e07bdf:

    # Celia "Come on, boy! I know you can do better than that!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:111
translate chinese CeR2_MS3_lab_a5ac1734:

    # Celia "Seriously? Is this the best you’ve got?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:112
translate chinese CeR2_MS3_lab_e3a38fc4:

    # Celia "I know how well you can lick a pussy. Put some effort into it!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:114
translate chinese CeR2_MS3_lab_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:115
translate chinese CeR2_MS3_lab_78b04950:

    # Celia "Mmmmm, yes! That is soooo much better!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:117
translate chinese CeR2_MS3_lab_165916da:

    # Celia "Hehe, such an obedient little pet. Aren’t you?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:119
translate chinese CeR2_MS3_lab_b0e7681b:

    # MC "(Grr... This is fucking humiliating!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:121
translate chinese CeR2_MS3_lab_dba8a01b:

    # MC "(Arrgh... This is so humiliating!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:122
translate chinese CeR2_MS3_lab_c9b30c1f:

    # Celia "Okay, you can leave now."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:124
translate chinese CeR2_MS3_lab_ab577f11:

    # Celia "Oh, be a darling and meet me in the cubicles this afternoon."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:125
translate chinese CeR2_MS3_lab_608997f9:

    # Celia "The same place you tried to blackmail me will be fine."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:126
translate chinese CeR2_MS3_lab_7ed7c056:

    # MC "(What the hell does she have planned?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:128
translate chinese CeR2_MS3_lab_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:129
translate chinese CeR2_MS3_lab_acbed9de:

    # Celia "(He doesn't taste half bad.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:131
translate chinese CeR2_MS3_lab_90f54d96:

    # Celia "(I’m looking forward to playing with him later on today.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:132
translate chinese CeR2_MS3_lab_d93605d3:

    # Celia "(If he only knew what I had in store for him.)"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:143
translate chinese CeR2_MS3_lab_2f5e6f20:

    # MC "If you think I’m going to do anything for you after you slapped me, then you must be out of your fucking mind."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:144
translate chinese CeR2_MS3_lab_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:146
translate chinese CeR2_MS3_lab_7d4af3be:

    # Celia "I shall give you one final chance, boy."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:147
translate chinese CeR2_MS3_lab_28ec5a7d:

    # Celia "Lick my hand, or you’ll face the consequences!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:148
translate chinese CeR2_MS3_lab_745374ee:

    # MC "No!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:150
translate chinese CeR2_MS3_lab_c73459c0:

    # Celia "Very well, it seems my disobedient pet needs to be disciplined."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:151
translate chinese CeR2_MS3_lab_60bf92e7:

    # MC "Fuck. You."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:153
translate chinese CeR2_MS3_lab_0a17d63f:

    # Celia "Such a grumpy and immature boy."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:154
translate chinese CeR2_MS3_lab_68b65bd6:

    # Celia "Oh well, you’ll come around."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:156
translate chinese CeR2_MS3_lab_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:157
translate chinese CeR2_MS3_lab_6a116380:

    # MC "(Here we go again.)"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:160
translate chinese CeR2_MS3_lab_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:161
translate chinese CeR2_MS3_lab_75c32cad:

    # MC "Aahh!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:163
translate chinese CeR2_MS3_lab_d2d2ed9e:

    # Celia "Today could have been so simple, [player_name]. All you had to do was bend the knee and lick my hand."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:164
translate chinese CeR2_MS3_lab_020adb17:

    # Celia "But no, you HAD to make things difficult for yourself. Didn’t you?"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:165
translate chinese CeR2_MS3_lab_1cd9bd8a:

    # MC "Wait-"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:172
translate chinese CeR2_MS3_lab_3c726d8a_1:

    # "*WHACK*"
    ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:173
translate chinese CeR2_MS3_lab_1b08a95a:

    # MC "Ooof!"
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:175
translate chinese CeR2_MS3_lab_ce177ca9:

    # MC "Ugh... Oww..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:176
translate chinese CeR2_MS3_lab_8ea26606:

    # Celia "Stand up. Pull yourself together and get the fuck out of my office."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:178
translate chinese CeR2_MS3_lab_fe54fda8:

    # MC "Ah... Ugh..."
    MC ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:179
translate chinese CeR2_MS3_lab_7a1fe859:

    # Celia "I said, get the fuck out of here. Do you want me to kick you again?!"
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:181
translate chinese CeR2_MS3_lab_6cde7167:

    # Celia "Oh, and I expect to see you in the cubicles this afternoon. The same one you attempted to blackmail me in."
    Celia ""

# game/scripts/Ce_R2/CeR2_MS3.rpy:182
translate chinese CeR2_MS3_lab_f3a90f10:

    # Celia "I’ve got more punishment to dish out to you."
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R2/CeR2_MS3.rpy:105
    old "Lick Celia's hand"
    new ""

    # game/scripts/Ce_R2/CeR2_MS3.rpy:105
    old "Refuse"
    new ""

