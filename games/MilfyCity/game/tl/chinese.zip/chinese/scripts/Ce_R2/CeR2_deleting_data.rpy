﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:24
translate chinese CeR2_del_data_084ff14d:

    # Celia "So... why is it they call you Big Jake?"
    Celia ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:25
translate chinese CeR2_del_data_5cb5e2dd:

    # B_J "I used to get bullied as a kid, I just sorta adopted it. *Wheeze* Made it my own."
    B_J ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:26
translate chinese CeR2_del_data_7d9d26a7:

    # Celia "Oh... so it’s not because you have a massive cock?"
    Celia ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:29
translate chinese CeR2_del_data_fb182c69:

    # B_J "No! I mean, yes! *Wheeze* I... um!"
    B_J ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:30
translate chinese CeR2_del_data_18b95d12:

    # MC "(Nicely done, Celia!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:31
translate chinese CeR2_del_data_29f5c9c2:

    # B_J "I mean, when I say ‘no’ it’s not like it’s below average or anything. *Wheeze*"
    B_J ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:35
translate chinese CeR2_del_data_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:37
translate chinese CeR2_del_data_8e6d7c1c:

    # MC "(And I’m in!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:38
translate chinese CeR2_del_data_70a6c570:

    # Celia "Whoa, haha! Calm down! You’re going to have a heart attack on me, buddy. I was just flirting with you."
    Celia ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:42
translate chinese CeR2_del_data_952f4922:

    # MC "(Bingo. Now, let’s try and find the video tapes. Once I get them deleted, I’ll be home free.)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:44
translate chinese CeR2_del_data_89073c86:

    # MC "(Alight! Hmm... I have to delete the video tapes. That would extend our BDSM fantasy even more! I think Celia will enjoy that twist!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:45
translate chinese CeR2_del_data_cb36dbb0:

    # MC "(She probably thought that this was a good move to change who's in charge!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:46
translate chinese CeR2_del_data_90d84ab1:

    # MC "(Hmm, where to begin...)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:49
translate chinese CeR2_del_data_439debda:

    # MC "(Okay... I guess the keyboard is as good a place to start as any.)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:50
translate chinese CeR2_del_data_fb78cd3a:

    # MC "(Let’s start searching for any security footage relating to the bathrooms.)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:54
translate chinese CeR2_del_data_02b16b2a:

    # "*Clack clack*"
    ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:56
translate chinese CeR2_del_data_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:57
translate chinese CeR2_del_data_b75b59f3:

    # MC "(Zero results? Dammit. I bet, that Big Jake doesn’t even know how to work this thing himself.)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:60
translate chinese CeR2_del_data_b3049ea9:

    # MC "(Let’s try searching for camera numbers...)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:62
translate chinese CeR2_del_data_5d370355:

    # "*Clack Clack*"
    ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:64
translate chinese CeR2_del_data_d1f5a7b9:

    # MC "(Nothing?! Fuck. I hope Celia can keep him occupied out there!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:67
translate chinese CeR2_del_data_9c6eef7f:

    # MC "(Think, [player_name], think! How can you handle this?!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:68
translate chinese CeR2_del_data_4ceb1b4b:

    # MC "Aha!"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:69
translate chinese CeR2_del_data_9a874667:

    # MC "(I’ll just wipe everything! No files, no problem!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:75
translate chinese CeR2_del_data_9671af78:

    # MC "(Hehe, you are one smart cookie!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:77
translate chinese CeR2_del_data_5d370355_1:

    # "*Clack Clack*"
    ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:79
translate chinese CeR2_del_data_9d92e235:

    # MC "(And... here we... go!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:80
translate chinese CeR2_del_data_fd34b5a3:

    # MC "(All files deleted.)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:84
translate chinese CeR2_del_data_89f15a99:

    # MC "(Good, now it’s guaranteed that I won’t be caught on camera.)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:86
translate chinese CeR2_del_data_a49e9a4c:

    # MC "(Good, now it’s guaranteed that I won’t lose with Celia! She can even come here and check it by herself! Hehe!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:87
translate chinese CeR2_del_data_9a27420d:

    # MC "(This couldn’t have panned out any better!)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:88
translate chinese CeR2_del_data_575edc5d:

    # MC "(It seems like Celia did a good job keeping Big Jake distracted. Hopefully he doesn’t develop an infatuation for her. That’d be awkward...)"
    MC ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:91
translate chinese CeR2_del_data_eb08e5df:

    # B_J "And that *Wheeze* is why smaller dicks can actually result in a more pleasurable experience for a woman."
    B_J ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:92
translate chinese CeR2_del_data_2b3a05fe:

    # Celia "Okay, I better go back to class."
    Celia ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:93
translate chinese CeR2_del_data_5908bb24:

    # B_J "Stop by *Wheeze* anytime - I still have to show you my extensive collection of hentai. We’ll do a binge *Wheeze* of Super Happy Tentacle Monster One to Twelve!"
    B_J ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:94
translate chinese CeR2_del_data_12c8ab1e:

    # Celia "There’s... twelve movies in your hentai series."
    Celia ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:95
translate chinese CeR2_del_data_3ec1299c:

    # B_J "The lore is surprisingly deep."
    B_J ""

# game/scripts/Ce_R2/CeR2_deleting_data.rpy:96
translate chinese CeR2_del_data_9f2a7bca:

    # Celia "Uh huh...I’m sure it is. I can barely contain my excitement."
    Celia ""

