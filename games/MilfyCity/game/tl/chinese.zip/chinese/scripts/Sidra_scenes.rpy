﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Sidra_scenes.rpy:60
translate chinese Si_S_6eb8662c:

    # MC "(I’ve seen a hot milf living in this house. I wonder if she finds me as attractive as Linda does?)"
    MC ""

# game/scripts/Sidra_scenes.rpy:62
translate chinese Si_S_d39b1ddc:

    # MC "(What the hell? It’s worth a shot, right?)"
    MC ""

# game/scripts/Sidra_scenes.rpy:72
translate chinese Si_S_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/Sidra_scenes.rpy:77
translate chinese Si_S_889264ee:

    # MC "Hey there."
    MC ""

# game/scripts/Sidra_scenes.rpy:79
translate chinese Si_S_abc78310:

    # Sidra "Can I help you?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:83
translate chinese Si_S_b82ee636:

    # MC "I’m [player_name]. I live across the road in Linda’s place."
    MC ""

# game/scripts/Sidra_scenes.rpy:85
translate chinese Si_S_cf3f690f:

    # Sidra "You’re one of her tenants?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:87
translate chinese Si_S_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/Sidra_scenes.rpy:91
translate chinese Si_S_2c95f8c0:

    # Sidra "Well, perhaps you can tell her that the Milfy Lane Homeowners’ Association has a strict limit of TWO tenants per household."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:93
translate chinese Si_S_1b951c0f:

    # MC "I uh... I’ll be sure to remind her."
    MC ""

# game/scripts/Sidra_scenes.rpy:95
translate chinese Si_S_d060632d:

    # Sidra "Honestly, that woman continues to show a flagrant disregard for the rules."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:100
translate chinese Si_S_8de36b5d:

    # MC "I... um... I actually came to introduce myself. I was hoping we could maybe grab a drink sometime or-"
    MC ""

# game/scripts/Sidra_scenes.rpy:102
translate chinese Si_S_8ca1b1d4:

    # Sidra "You don’t even know my name, do you?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:106
translate chinese Si_S_5e83955a:

    # MC "No... I mean, not yet! But I’d really like to!"
    MC ""

# game/scripts/Sidra_scenes.rpy:109
translate chinese Si_S_9ece7003:

    # Sidra "It’s Sidra."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:111
translate chinese Si_S_2fff832f:

    # MC "Well, it’s nice to meet you Sidra. As I said, I’m-"
    MC ""

# game/scripts/Sidra_scenes.rpy:113
translate chinese Si_S_6a99c2ff:

    # Sidra "Please get out."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:115
translate chinese Si_S_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/Sidra_scenes.rpy:117
translate chinese Si_S_4e30c8cf:

    # Sidra "I said leave."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:121
translate chinese Si_S_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Sidra_scenes.rpy:123
translate chinese Si_S_7bc2bb63:

    # MC "(I guess I’ll try another time.)"
    MC ""

# game/scripts/Sidra_scenes.rpy:143
translate chinese Si_S_bca3ac64_1:

    # "*Knock* *Knock*"
    ""

# game/scripts/Sidra_scenes.rpy:148
translate chinese Si_S_57ac936a:

    # MC "Hey again!"
    MC ""

# game/scripts/Sidra_scenes.rpy:150
translate chinese Si_S_250073f2:

    # Sidra "You’re back?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:154
translate chinese Si_S_6e8189fe:

    # MC "Of course! Did you really think I’d give up that easily?"
    MC ""

# game/scripts/Sidra_scenes.rpy:156
translate chinese Si_S_5bc69b50:

    # Sidra "Give up? Give up on what?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:158
translate chinese Si_S_bb6af11c:

    # MC "Asking you out for a drink, of course!"
    MC ""

# game/scripts/Sidra_scenes.rpy:162
translate chinese Si_S_c9a60882:

    # Sidra "Heh... You’re not my type, but I appreciate the confidence. Don’t lose that. It’ll take you far."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:164
translate chinese Si_S_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/Sidra_scenes.rpy:167
translate chinese Si_S_8498323b:

    # MC "Well, I’d been thinking about FAR more than just taking you out for a drink."
    MC ""

# game/scripts/Sidra_scenes.rpy:171
translate chinese Si_S_6059b93e:

    # Sidra "What? What is that supposed to mean?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:173
translate chinese Si_S_c540a601:

    # Sidra "Why are you staring at me like that?!"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:178
translate chinese Si_S_958a4fec:

    # MC "I’m just imagining how good your body looks without those clothes on."
    MC ""

# game/scripts/Sidra_scenes.rpy:180
translate chinese Si_S_b5c6b662:

    # Sidra "Excuse me?!"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:184
translate chinese Si_S_480ced6f:

    # MC "I bet your sexy milf pussy looks phenomenal. God, it would feel so good to plunge my dick deep inside-"
    MC ""

# game/scripts/Sidra_scenes.rpy:186
translate chinese Si_S_53716050:

    # Sidra "(Is he completely devoid of basic self awareness?!)"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:190
translate chinese Si_S_e7cee042:

    # MC "Not to mention your ass. It already looks so good with your clothes on! I imagine you’re ten times hotter naked."
    MC ""

# game/scripts/Sidra_scenes.rpy:192
translate chinese Si_S_fcbd377c:

    # Sidra "I know I said I admired your confidence, but you’re veering waaay off mark, here."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:196
translate chinese Si_S_ae2ebd8d:

    # MC "That dress you’re wearing is incredible. I can already see your cleavage, but I’d LOVE to be able to see the rest of your tits as well."
    MC ""

# game/scripts/Sidra_scenes.rpy:198
translate chinese Si_S_06baa7b8:

    # MC "You have no idea, the dirty things that I am planning to-"
    MC ""

# game/scripts/Sidra_scenes.rpy:202
translate chinese Si_S_d8076c88:

    # Sidra "Enough!"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:204
translate chinese Si_S_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Sidra_scenes.rpy:209
translate chinese Si_S_51507d3b:

    # Sidra "Perhaps I wasn’t clear when I said you weren’t my type. Let me rephrase."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:213
translate chinese Si_S_0d92c97f:

    # Sidra "I want someone mature. I’m not settling down with a jobless college student who is still renting a room."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:217
translate chinese Si_S_a5d2d954:

    # Sidra "You’re too young for me. You’re too inexperienced with women. You don’t respect basic boundaries."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:219
translate chinese Si_S_81724585:

    # MC "*Gulp* I-"
    MC ""

# game/scripts/Sidra_scenes.rpy:223
translate chinese Si_S_ce16cfa0:

    # Sidra "Now, I think I have made myself crystal clear. I would like you to leave."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:227
translate chinese Si_S_1a5083df:

    # MC "Y-Yeah, I got it."
    MC ""

# game/scripts/Sidra_scenes.rpy:229
translate chinese Si_S_4d090654:

    # Sidra "Thank you."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:233
translate chinese Si_S_62d207f7:

    # MC "(Geez, this woman is playing hard to get! I’ll try again another day. Maybe she’ll change her mind?)"
    MC ""

# game/scripts/Sidra_scenes.rpy:253
translate chinese Si_S_bca3ac64_2:

    # "*Knock* *Knock*"
    ""

# game/scripts/Sidra_scenes.rpy:258
translate chinese Si_S_1e967274:

    # Sidra "Hello? Oh... it's you."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:260
translate chinese Si_S_d500d914:

    # Sidra "*Sigh* What do you want?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:264
translate chinese Si_S_d59efe46:

    # MC "So, I was thinking about what you said last time."
    MC ""

# game/scripts/Sidra_scenes.rpy:266
translate chinese Si_S_ad41ee3c:

    # Sidra "Good."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:268
translate chinese Si_S_d0dde081:

    # MC "If I manage to get myself a job, buy my own house and-"
    MC ""

# game/scripts/Sidra_scenes.rpy:272
translate chinese Si_S_9676a4c8:

    # Sidra "Alright. I’m going to stop you there. You’re really not giving up on this, are you?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:274
translate chinese Si_S_0cdc39fc:

    # MC "Of course not!"
    MC ""

# game/scripts/Sidra_scenes.rpy:276
translate chinese Si_S_5800ab2f:

    # Sidra "*Sigh*"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:280
translate chinese Si_S_08f3091b:

    # Sidra "Alright, follow me."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:282
translate chinese Si_S_9e3f40b2:

    # MC "(Awesome! I can’t believe my persistence ACTUALLY worked!)"
    MC ""

# game/scripts/Sidra_scenes.rpy:296
translate chinese Si_S_080dd519:

    # MC "(I've already been in there.)"
    MC ""

# game/scripts/Sidra_scenes.rpy:306
translate chinese Si_S3_step_noleave_29c35c00:

    # MC "(Sidra is waiting for me in the Livingroom.)"
    MC ""

# game/scripts/Sidra_scenes.rpy:320
translate chinese Si_S3_step2_016125f2:

    # MC "So, are we doing this on the couch or-"
    MC ""

# game/scripts/Sidra_scenes.rpy:322
translate chinese Si_S3_step2_68f6fffc:

    # Sidra "Keep it in your pants. We’re going to have a chat first."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:326
translate chinese Si_S3_step2_7aeabc27:

    # MC "Uh okay?"
    MC ""

# game/scripts/Sidra_scenes.rpy:328
translate chinese Si_S3_step2_1ea74015:

    # Sidra "Take a seat. Tea or coffee?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:332
translate chinese Si_S3_step2_038e75e3:

    # MC "Coffee please."
    MC ""

# game/scripts/Sidra_scenes.rpy:334
translate chinese Si_S3_step2_27538361:

    # MC "(I suppose this is a good thing? It’s the furthest I’ve ever got with Sidra so far!)"
    MC ""

# game/scripts/Sidra_scenes.rpy:338
translate chinese Si_S3_step2_8ba0dcb2:

    # Sidra "I’ll be back shortly."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:340
translate chinese Si_S3_step2_5ad7e807:

    # MC "Okay! (She’s probably slipping into a sexier outfit for me.)"
    MC ""

# game/scripts/Sidra_scenes.rpy:344
translate chinese Si_S3_step2_d4d746a8:

    # Sidra "Oh, I almost forgot, do you take milk or sugar?"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:346
translate chinese Si_S3_step2_627b158e:

    # MC "Splash of milk, no sugar."
    MC ""

# game/scripts/Sidra_scenes.rpy:350
translate chinese Si_S3_step2_8c8336a1:

    # MC "(I can’t wait to slide those tights off her! She can keep her high heels on!)"
    MC ""

# game/scripts/Sidra_scenes.rpy:354
translate chinese Si_S3_step2_2579784b:

    # MC "Heh... (This is gonna be amazing!)"
    MC ""

# game/scripts/Sidra_scenes.rpy:356
translate chinese Si_S3_step2_fc8fb580:

    # MC "(I’ll have her suck my cock, and maybe ride me on this couch, and-)"
    MC ""

# game/scripts/Sidra_scenes.rpy:358
translate chinese Si_S3_step2_58b59eb6:

    # Sidra "Here you go."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:362
translate chinese Si_S3_step2_f66aa7e9:

    # MC "Oh, thanks!"
    MC ""

# game/scripts/Sidra_scenes.rpy:364
translate chinese Si_S3_step2_811c7488:

    # Sidra "No problem. Now, as I mentioned - you and I DO need to have a serious talk."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:368
translate chinese Si_S3_step2_f845638e:

    # MC "(I wonder what she’s going to talk with me about? I know she mentioned she wanted to be with a more mature person, but perhaps she’s finally starting to give in to me?)"
    MC ""

# game/scripts/Sidra_scenes.rpy:370
translate chinese Si_S3_step2_22f333ab:

    # MC "(I AM incredibly charming, after all! Linda certainly thinks so!)"
    MC ""

# game/scripts/Sidra_scenes.rpy:374
translate chinese Si_S3_step2_1498b531:

    # Sidra "You really need to learn how to take “no” for an answer. I turned you down twice already, and, yet again, you’ve shown up to my house trying to sleep with me."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:376
translate chinese Si_S3_step2_313f0776:

    # MC "Persistence is a virtue though, right?"
    MC ""

# game/scripts/Sidra_scenes.rpy:380
translate chinese Si_S3_step2_a8a44e3b:

    # Sidra "Not when the woman you’re trying to sleep with doesn’t like dicks."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:382
translate chinese Si_S3_step2_9b65b70b:

    # MC "I’m not a dick though! I swear, I’m a nice guy! Really!"
    MC ""

# game/scripts/Sidra_scenes.rpy:385
translate chinese Si_S3_step2_1ee1cf18:

    # Sidra "(Is he really so dense!? I’ll have to try and think of another way to put this...)"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:387
translate chinese Si_S3_step2_1770bc28:

    # "*Shlurp*"
    ""

# game/scripts/Sidra_scenes.rpy:391
translate chinese Si_S3_step2_8c788354:

    # MC "I get that you think a lot of guys my age are dicks. I mean, we can be!"
    MC ""

# game/scripts/Sidra_scenes.rpy:393
translate chinese Si_S3_step2_006765d5:

    # MC "But I promise you, I’m different!"
    MC ""

# game/scripts/Sidra_scenes.rpy:397
translate chinese Si_S3_step2_019fcb62:

    # Sidra "I don’t like cocks, [player_name]."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:399
translate chinese Si_S3_step2_1770bc28_1:

    # "*Shlurp*"
    ""

# game/scripts/Sidra_scenes.rpy:403
translate chinese Si_S3_step2_9efda666:

    # MC "That’s something we have in common! I don’t like cocks either!"
    MC ""

# game/scripts/Sidra_scenes.rpy:405
translate chinese Si_S3_step2_a260ad5d:

    # Sidra "*Sigh* I’m a lesbian, [player_name]."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:407
translate chinese Si_S3_step2_f6e4b451:

    # MC "Uh huh."
    MC ""

# game/scripts/Sidra_scenes.rpy:411
translate chinese Si_S3_step2_1894ae48:

    # Sidra "(He’s still not listening to me.)"
    Sidra ""

# game/scripts/Sidra_scenes.rpy:413
translate chinese Si_S3_step2_a4298267:

    # Sidra "I like pussy and tits, [player_name]. And you have neither."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:417
translate chinese Si_S3_step2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Sidra_scenes.rpy:419
translate chinese Si_S3_step2_c298f5f7:

    # MC "*Shlurp*"
    MC ""

# game/scripts/Sidra_scenes.rpy:423
translate chinese Si_S3_step2_0f033971:

    # MC "Oh... Right."
    MC ""

# game/scripts/Sidra_scenes.rpy:425
translate chinese Si_S3_step2_2bd16532:

    # MC "That makes a lot more sense. It seems like every other woman in this city finds me irresistible."
    MC ""

# game/scripts/Sidra_scenes.rpy:427
translate chinese Si_S3_step2_9ddd8fd8:

    # Sidra "Not me."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:430
translate chinese Si_S3_step2_91e842bd:

    # MC "You... uh... You don’t have a straight daughter or sister that I can date?"
    MC ""

# game/scripts/Sidra_scenes.rpy:432
translate chinese Si_S3_step2_d4da0f3e:

    # Sidra "Haha! I’m afraid not. If I did have a daughter I’d probably call her Isla. And you’d be welcome to ask her out."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:434
translate chinese Si_S3_step2_80ae0c3f:

    # Sidra "She’d probably say no though. You’re way too forward. You need to learn to give a girl some space."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:438
translate chinese Si_S3_step2_120e932d:

    # MC "Heh... Sorry. I’ll stop bothering you now"
    MC ""

# game/scripts/Sidra_scenes.rpy:440
translate chinese Si_S3_step2_ca49042d:

    # Sidra "Thank you, I appreciate it."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:442
translate chinese Si_S3_step2_5a74f389:

    # MC "I don’t suppose you’d let me watch, next time you have another woman over?"
    MC ""

# game/scripts/Sidra_scenes.rpy:444
translate chinese Si_S3_step2_ee27c8d9:

    # Sidra "Goodbye, [player_name]."
    Sidra ""

# game/scripts/Sidra_scenes.rpy:446
translate chinese Si_S3_step2_69275d7c:

    # MC "Ah, what the hell. It was worth a shot! Goodbye, Sidra!"
    MC ""

# game/scripts/Sidra_scenes.rpy:463
translate chinese Si_S3_step2_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

