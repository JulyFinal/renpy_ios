﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_ele/Ce_home/Entrance/M/Ce_entrance_M.rpy:49
translate chinese Ce_closed_aeb91391:

    # MC "(It's locked.)"
    MC ""

# game/scripts/Ce_ele/Ce_home/Entrance/M/Ce_entrance_M.rpy:51
translate chinese Ce_closed_40d69028:

    # MC "(It's not a good idea to go in there. Gustav might be inside.)"
    MC ""

