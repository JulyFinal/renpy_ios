﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:30
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_b2197f2e:

    # MC "I wonder what they're doing."
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:31
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_c3f3fb63:

    # MC "It's very quiet there today."
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:35
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_96751429:

    # "*Creeeaaaak*"
    ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:38
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_a8a028c7:

    # MC "Ah! It's only Dad."
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:40
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_41d9f40d:

    # MC "Ah! It's only Bob."
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:42
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_902e715f:

    # MC "I forgot! Mom is waiting for me in my bedroom!"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:44
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_5c98f7df:

    # MC "I forgot! Linda is waiting for me in my bedroom!"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:54
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_daf740fa:

    # MC "(I should leave them alone.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:64
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_f2dac146:

    # MC "(It's too risky. I should leave them alone.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:78
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_92b0f242:

    # Dad "Ugh! Yeah!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:81
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_646ec408:

    # MC "(Huh... Sounds like my parents are having sex.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:82
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_5f111572:

    # MC "(Maybe I could take this chance to sneak a peek at Mom!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:84
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_2b07372c:

    # MC "(Huh... Sounds like Linda and Bob are having sex.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:85
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_f75fb25a:

    # MC "(Maybe I could take this chance to sneak a peek at Linda!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:89
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_6d8f75de:

    # MC "(Shit... I hope they didn’t hear the door opening!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:90
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_4abe27b4:

    # Dad "Oh! Ahhh!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:91
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_dbf8f99b:

    # MC "(Apparently not!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:98
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_9e08fe91:

    # Dad "Oh yeah, that’s it!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:99
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_6d1e4741:

    # Dad "Aww, crap..."
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:101
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_73fe2ac0:

    # MC "(Huh, it’s only Dad moaning.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:103
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_b9f711ab:

    # MC "(Huh, it’s only Bob moaning.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:104
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_f28ce674:

    # Dad "Hang on, I’ll get my boner back. Just give me a minute and I’ll go in again!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:105
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_93561370:

    # Mom "Uh huh... No problem, Dear."
    Mom ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:109
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_a3d2f0d7:

    # MC "(It looks like Mom’s... bored?)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:111
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_a8b39bd8:

    # MC "(It looks like Linda’s... bored?)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:112
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_7c4f02db:

    # MC "(No way! Why would she be bored having sex?!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:113
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_da1a4465:

    # MC "(It doesn’t make sense...)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:118
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_033726a4:

    # MC "(Looks like Mom is more interested in her book. I wonder what it is?)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:119
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_d2fc4865:

    # MC "(Dad probably doesn’t even know or care right now.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:121
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_ca83048a:

    # MC "(Looks like Linda is more interested in her book. I wonder what it is?)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:122
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_bb372d7c:

    # MC "(Bob probably doesn’t even know or care right now.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:124
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_3522a74b:

    # Dad "Ahhh! Oh yeah, that’s it! Ugh!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:125
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_3be79133:

    # Dad "You feeling this, Honey?"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:126
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_ac3e98d4:

    # Mom "Mmm hmm... "
    Mom ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:127
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_af2d0170:

    # Mom "*Yawn!*"
    Mom ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:130
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_f616bad9:

    # MC "(That must be one, damn good book, if she’s managing to read it in the middle of sex!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:131
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_c1a6fb11:

    # MC "(I should check out what it is, later on.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:132
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_894f1c69:

    # MC "(Anyway, I better sneak away now, before I get caught!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:147
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_0cad8849:

    # MC "(I wonder if Mom’s gonna be reading again.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:149
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_ce913223:

    # MC "(I wonder if Linda’s gonna be reading again.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:150
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_51f2ff6d:

    # MC "(At the very least, I’ll get a good peek at her tits!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:154
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_b69f304c:

    # MC "(Damn! Fuck this door! Someone needs to oil those hinges!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:157
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_dd2c2de6:

    # Dad "Ooooh God! Ooooh yeah! That’s it!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:158
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_d3059485:

    # Dad "Take my cock! Ahh!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:159
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_b80f641e:

    # Mom "*Snoooooorrreee*"
    Mom ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:160
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_6f5ae189:

    # MC "(Is she... asleep?)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:164
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_f29ea89d:

    # MC "(Holy crap! Mom’s ACTUALLY fallen asleep during sex!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:166
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_21180b2b:

    # MC "(Holy crap! Linda’s ACTUALLY fallen asleep during sex!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:167
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_2abfded5:

    # MC "(And she hasn’t even gotten fully undressed either.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:168
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_7735a370:

    # MC "(Gee... I didn’t know she had such a terrible sex life.)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:169
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_2b2a3c7e:

    # Dad "Ahh! I’m cumming!"
    Dad ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:171
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_55a34240:

    # MC "(Uh oh! I better leg it out of here before Dad finishes!)"
    MC ""

# game/scripts/home/salon/night/scenes/ml_ml_and_f_bedroom_night_scene_v1.rpy:173
translate chinese ml_ml_and_f_bedroom_night_scene_v1_label_379468e9:

    # MC "(Uh oh! I better leg it out of here before Bob finishes!)"
    MC ""

