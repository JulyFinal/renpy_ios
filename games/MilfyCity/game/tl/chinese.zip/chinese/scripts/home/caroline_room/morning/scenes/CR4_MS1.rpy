﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:48
translate chinese CR4_MS1_label_a1ea0431:

    # Caroline "Not now, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:65
translate chinese CR4_MS1_label_05daeba0:

    # MC "(Holy shit! Those are the tightest booty shorts I’ve ever seen, in my life!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:66
translate chinese CR4_MS1_label_ea1c52db:

    # MC "(Her ass looks fucking incredible. I wonder if she realises that, herself.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:67
translate chinese CR4_MS1_label_621016fd:

    # MC "(She’s wearing a pair of high-heel shoes as well - she must have deliberately chosen to dress this sexily.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:71
translate chinese CR4_MS1_label_decfcb02:

    # MC "(And seeing that I’m the only guy around to see her - she’s probably chosen to dress nice for me!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:72
translate chinese CR4_MS1_label_fc9b0d38:

    # MC "(I wonder if she’s even wearing a bra beneath that tight white top?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:73
translate chinese CR4_MS1_label_c9d75c15:

    # MC "Hey, Caroline. Are you up to anything interesting? Just working on your makeup?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:77
translate chinese CR4_MS1_label_fb1f9246:

    # Caroline "Morning, [player_name]. Sorry, I didn’t hear you come in, there. I finished my makeup a few minutes ago. I WAS in the middle of tidying everything up, then I ended up getting distracted by this book. Haha!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:78
translate chinese CR4_MS1_label_b546e83e:

    # MC "Anything interesting?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:79
translate chinese CR4_MS1_label_b9b6ce0e:

    # Caroline "Investing for Dummies. I’m planning to reinvest my profits into the stock market. Or maybe open up another store in another city."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:80
translate chinese CR4_MS1_label_4fb6091c:

    # MC "Oh, that sounds really good! Have you thought about expanding overseas?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:84
translate chinese CR4_MS1_label_3e1a2644:

    # Caroline "I’ve toyed with the idea. Perhaps the UK or Ireland. I might just be safer opening up another one over here."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:85
translate chinese CR4_MS1_label_e97ddc96:

    # Caroline "What was it you wanted me for, by the way?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:86
translate chinese CR4_MS1_label_258895f3:

    # MC "I got your text about organising a date sometime. I was wondering if tonight suited you?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:90
translate chinese CR4_MS1_label_1e490079:

    # Caroline "Oh!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:91
translate chinese CR4_MS1_label_1634f9d7:

    # Caroline "(Shit! I was so engrossed in my work I completely forgot that I sent that text!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:92
translate chinese CR4_MS1_label_f885643f:

    # MC "Umm, you okay? I can come back later if now isn’t a good time."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:96
translate chinese CR4_MS1_label_34273620:

    # Caroline "No, now is fine."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:97
translate chinese CR4_MS1_label_83d8b7df:

    # Caroline "(Crap - I was so busy that I completely forgot to organise anything!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:98
translate chinese CR4_MS1_label_9839c35b:

    # MC "(Damn, she is so fucking hot!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:99
translate chinese CR4_MS1_label_98dc9ee8:

    # Caroline "Listen, I just need a little bit longer to finish planning our date. Are you free to meet up this afternoon?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:103
translate chinese CR4_MS1_label_0c9f51e5:

    # MC "Sure, not a problem. I’ll catch you then. Where do you want to meet?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:104
translate chinese CR4_MS1_label_5e29f483:

    # Caroline "I’m going to be at work, so would it be okay if you dropped by the store?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:105
translate chinese CR4_MS1_label_e60f987d:

    # MC "Of course. I’ll see you then."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:109
translate chinese CR4_MS1_label_77eed743:

    # MC "Do I need to bring anything with me?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:110
translate chinese CR4_MS1_label_c0775381:

    # Caroline "Don’t worry. You’ve been so good to me, I’ll take care of everything this time."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:111
translate chinese CR4_MS1_label_ef0cd9d6:

    # MC "Well, if you’re sure!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:115
translate chinese CR4_MS1_label_f32bc168:

    # Caroline "Say... before you go, would you like some... relief?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:116
translate chinese CR4_MS1_label_89405c8d:

    # MC "Relief? Oh! Do you mean like a-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:117
translate chinese CR4_MS1_label_4f758648:

    # Caroline "Yes, I’m talking about unzipping your pants and sucking your fat cock."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:126
translate chinese CR4_MS1_label_c51b5f18:

    # MC "Well, how could a guy ever say no to that?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:127
translate chinese CR4_MS1_label_06a6a513:

    # MC "(Especially when you’re dressed up like that!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:128
translate chinese CR4_MS1_label_5a042820:

    # Caroline "Hehe, that’s the spirit."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:132
translate chinese CR4_MS1_label_5b8315ae:

    # MC "Where do you want me to go?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:133
translate chinese CR4_MS1_label_eecfa723:

    # Caroline "Hmm... How about you lie back on my bed? We’ll take it from there."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:134
translate chinese CR4_MS1_label_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:142
translate chinese CR4_MS1_label_a6c1f3d0:

    # MC "No thanks, maybe later on though."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:143
translate chinese CR4_MS1_label_606d84d9:

    # Caroline "Are you sure?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:144
translate chinese CR4_MS1_label_bb65f9be:

    # MC "Yeah, I’m fine at the minute. How about you sit on my knee for a while?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:148
translate chinese CR4_MS1_label_734c2988:

    # Caroline "I’m not too heavy, am I? I don’t want to hurt your legs."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:149
translate chinese CR4_MS1_label_79440361:

    # MC "Relax! You’re as light as a feather."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:150
translate chinese CR4_MS1_label_2ae106d9:

    # Caroline "Haha, you and I both know that’s not true!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:154
translate chinese CR4_MS1_label_30180402:

    # MC "(Caroline seems to have become much more intimate since becoming my girlfriend.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:155
translate chinese CR4_MS1_label_e07f7d3a:

    # MC "(She’s warmer now - almost as if she’s finally letting her guard down. It certainly took her long enough, but with an ex-boyfriend like Charles I can understand why she put up so many barriers.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:156
translate chinese CR4_MS1_label_120bf2cf:

    # Caroline "Y’know... you don’t have to call me Caroline all the time. If you’d prefer, you could just..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:157
translate chinese CR4_MS1_label_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:158
translate chinese CR4_MS1_label_95742745:

    # Caroline "Nevermind, it’s silly."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:159
translate chinese CR4_MS1_label_b7401b05:

    # MC "No, go ahead. Please."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:163
translate chinese CR4_MS1_label_75b1edfc:

    # Caroline "You can refer to me as “your girl” if you want."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:164
translate chinese CR4_MS1_label_1af9ce47:

    # Caroline "Actually, forget that! It’s really cringey!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:165
translate chinese CR4_MS1_label_241b5b91:

    # MC "No, I like it. It’s really cute."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:169
translate chinese CR4_MS1_label_ebd01430:

    # MC "I’m glad I can finally call you ‘my girl.’"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:170
translate chinese CR4_MS1_label_2338451b:

    # MC "I love you, Caroline."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:172
translate chinese CR4_MS1_label_88520fcd:

    # Caroline "I love you too, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:185
translate chinese CR4_MS1_blow_2412b2ba:

    # Caroline "Oh wow! You are really, really hard right now!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:186
translate chinese CR4_MS1_blow_f33ccd6a:

    # MC "Well, that cute outfit you are wearing certainly helped!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:187
translate chinese CR4_MS1_blow_1b9caaf2:

    # Caroline "Well, if I’m the one that’s caused this problem, then it’s MY responsibility to fix it."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:191
translate chinese CR4_MS1_blow_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:193
translate chinese CR4_MS1_blow_6e3035ee:

    # MC "Mmm... "
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:194
translate chinese CR4_MS1_blow_bf6a0190:

    # MC "(Her lips are so warm and wet!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:198
translate chinese CR4_MS1_blow_4b3fb359:

    # MC "(I honestly can’t think of a better way to start the day!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:199
translate chinese CR4_MS1_blow_98a6b6ae:

    # Caroline "(I almost forgot how delicious his cock looks. I could suck on his thick dick all morning!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:203
translate chinese CR4_MS1_blow_052dbed6:

    # Caroline "(Time to blow [player_name]’s mind!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:204
translate chinese CR4_MS1_blow_eec57016:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:206
translate chinese CR4_MS1_blow_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:210
translate chinese CR4_MS1_blow_2e746551:

    # Caroline "Mmmpfff!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:211
translate chinese CR4_MS1_blow_f43f2205:

    # MC "Uggghh! Ahh..."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:212
translate chinese CR4_MS1_blow_eec57016_1:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:213
translate chinese CR4_MS1_blow_76cf17b4:

    # Caroline "(Sounds like he’s really enjoying this!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:217
translate chinese CR4_MS1_blow_79e429af:

    # MC "Oh yeah... Mmm! Just like that! Ugh! Don’t stop!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:218
translate chinese CR4_MS1_blow_54d3900c:

    # Caroline "*Suck* *Suck*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:219
translate chinese CR4_MS1_blow_d4844943:

    # MC "Can you go deeper? Ahh..."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:223
translate chinese CR4_MS1_blow_14b8c0c3:

    # Caroline "Mmm hmm!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:224
translate chinese CR4_MS1_blow_a46882ac:

    # MC "Uhh, I guess that means, ‘yes’?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:226
translate chinese CR4_MS1_blow_eec57016_2:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:230
translate chinese CR4_MS1_blow_1e7d28ed:

    # Caroline "*SHHLLLURRRRP*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:232
translate chinese CR4_MS1_blow_978eca9b:

    # MC "Oh yeah! Mmm! Deeper!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:233
translate chinese CR4_MS1_blow_23c6a712:

    # Caroline "(Maybe I should just let [player_name] take control this time? If he’s not satisfied with my technique, then he can manage it himself!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:237
translate chinese CR4_MS1_blow_9ec8acad:

    # Caroline "Y’know what? You’re in charge now, big guy."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:238
translate chinese CR4_MS1_blow_8e916436:

    # MC "Huh? What do you mean?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:239
translate chinese CR4_MS1_blow_465447ff:

    # Caroline "Just grab my hair and hold my head however you want it. Then thrust your hips and fuck my face."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:240
translate chinese CR4_MS1_blow_dac4a4e5:

    # MC "Seriously?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:241
translate chinese CR4_MS1_blow_cada94fb:

    # Caroline "That’s what you want, isn’t it? To feel your sensitive cock slide down my tight little throat? You can even talk dirty to me, if that’s what you’re into."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:242
translate chinese CR4_MS1_blow_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:243
translate chinese CR4_MS1_blow_bf5509d8:

    # Caroline "Then what are you waiting for? Man up and-"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:247
translate chinese CR4_MS1_blow_59eefd4b:

    # Caroline "GLLLUMPPFFF!!!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:248
translate chinese CR4_MS1_blow_6c36f123:

    # MC "Thanks, Caroline! This is gonna be awesome!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:250
translate chinese CR4_MS1_blow_d39f85da:

    # Caroline "(Jesus, [player_name]! Give a girl a warning! Or at least let her finish her sentence!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:254
translate chinese CR4_MS1_blow_5bfc67e3:

    # MC "Ugh! Ahh! Oh fuck!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:255
translate chinese CR4_MS1_blow_806b4ec1:

    # Caroline "MMPFF! GLMPPFF!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:256
translate chinese CR4_MS1_blow_7808d7e8:

    # Caroline "*SHLURP* *SUCK*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:258
translate chinese CR4_MS1_blow_8d7796cd:

    # MC "Mmm! Ahhhh! Yes! Ohhh!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:266
translate chinese CR4_MS1_blow_a9aa2c8e:

    # MC "Fuck, that’s it! Suck on my cock, you fucking slut!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:267
translate chinese CR4_MS1_blow_45164930:

    # Caroline "MPPLFFFF!!!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:268
translate chinese CR4_MS1_blow_8b69c07f:

    # MC "Ugh! Fuck! Ahh!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:274
translate chinese CR4_MS1_blow_45164930_1:

    # Caroline "MPPLFFFF!!!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:275
translate chinese CR4_MS1_blow_8b69c07f_1:

    # MC "Ugh! Fuck! Ahh!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:284
translate chinese CR4_MS1_blow_con1_9711b6d4:

    # MC "Oh yeah, just like that! Hnnnggg! Suck it, you whore!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:285
translate chinese CR4_MS1_blow_con1_aee4e290:

    # Caroline "(Hearing [player_name] talk so dirty is getting me all wet! Maybe this wasn’t such a good idea to do in the morning! I’m going to have to spend another hour with my dildo before I head out to work!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:294
translate chinese CR4_MS1_blow_con2_e2ca262b:

    # Caroline "*Shlluurrrp*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:298
translate chinese CR4_MS1_blow_con2_2224fedc:

    # MC "Oh shit! I’m cumming! Hnnnggg! Ugh!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:299
translate chinese CR4_MS1_blow_con2_e37e4656:

    # Caroline "(Holy crap! I can feel his shaft pulsating on my tongue - he’s about to blow his load in my mouth!)"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:300
translate chinese CR4_MS1_blow_con2_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:311
translate chinese CR4_MS1_blow_con2_95ab1a75:

    # MC "Aahhhhh!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:312
translate chinese CR4_MS1_blow_con2_bac0bb42:

    # Caroline "*GULP GULP*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:313
translate chinese CR4_MS1_blow_con2_50e05bbb:

    # MC "Ohhh... fuck... Mmm! Your mouth is incredible, Caroline."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:317
translate chinese CR4_MS1_blow_con2_1bae7db2:

    # Caroline "Well, it certainly felt like you enjoyed facefucking me!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:318
translate chinese CR4_MS1_blow_con2_09ce4eef:

    # MC "It was the best! *Pant* I’m still catching my breath! Haha!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:319
translate chinese CR4_MS1_blow_con2_ed3808b2:

    # Caroline "I’m glad you liked it. Don’t forget to drop by the shop later on today to discuss our date."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:320
translate chinese CR4_MS1_blow_con2_dee3e7a4:

    # MC "Oh yeah, I won’t. I’ll catch up with you in the afternoon."
    MC ""

translate chinese strings:

    # game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:121
    old "Yeah, definitely!"
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR4_MS1.rpy:121
    old "No thanks. But maybe later on."
    new ""

