﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:36
translate chinese CR3_NS2_label_73e0d529:

    # MC "(I should let her sleep.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:52
translate chinese CR3_NS2_label_a1e2a683:

    # Caroline "Ah... Ah! Ah! Ahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:53
translate chinese CR3_NS2_label_3ee080d3:

    # MC "Huh? (What’s that noise? Is someone screaming?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:54
translate chinese CR3_NS2_label_51f124d8:

    # MC "(It sounds like it’s coming from Caroline’s bedroom.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:58
translate chinese CR3_NS2_label_e8de81dc:

    # Caroline "Ohhh! Ahh! Ahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:61
translate chinese CR3_NS2_label_00f55b11:

    # MC "(I should probably check this out. If I’m lucky, I might catch my older sister masturbating!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:63
translate chinese CR3_NS2_label_9c767198:

    # MC "(I should probably check this out. If I’m lucky, I might catch her masturbating!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:65
translate chinese CR3_NS2_label_49d27a50:

    # MC "(Here we go... Hopefully her bedroom door isn’t too creaky.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:69
translate chinese CR3_NS2_label_cb80268c:

    # Caroline "Ah! Mmm! Oh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:70
translate chinese CR3_NS2_label_1482605d:

    # MC "(Oh yeah! Perfect timing! Just like I thought. She’s masturbating, when she thinks everyone is asleep!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:71
translate chinese CR3_NS2_label_a4d72713:

    # MC "(I’m surprised she hasn’t woken anybody with her screaming!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:75
translate chinese CR3_NS2_label_b34abcca:

    # MC "(I wonder what she’s fantasising about? Whatever it is, she’s far too deeply engrossed in it, to notice ME at the door.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:76
translate chinese CR3_NS2_label_4708bf0c:

    # Caroline "Mmm... fuck... Oh... God..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:78
translate chinese CR3_NS2_label_5cd0cd74:

    # "*Buzzz*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:83
translate chinese CR3_NS2_label_770cbd84:

    # MC "(It sounds like she’s got a vibrating dildo too!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:84
translate chinese CR3_NS2_label_1a028add:

    # MC "(No wonder she’s moaning, so loudly!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:85
translate chinese CR3_NS2_label_a063c075:

    # Caroline "Ah! AHHHHH!!!! Fuck... Oh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:89
translate chinese CR3_NS2_label_cbcbe64f:

    # "*Buzz Buzz*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:91
translate chinese CR3_NS2_label_d97b521e:

    # Caroline "Mmm... (The rain was pouring down outside and we were completely lost... My uniform had been soaked through to my skin.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:92
translate chinese CR3_NS2_label_6b7c1dbd:

    # Caroline "([player_name] and I were lucky to find that abandoned little cottage in the woods. We built a small fire, but there was no way either of us could sit - in our sodden clothes. We had to strip them off...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:97
translate chinese CR3_NS2_label_cbcbe64f_1:

    # "*Buzz Buzz*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:99
translate chinese CR3_NS2_label_e5c707e5:

    # Caroline "Ah... Oh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:100
translate chinese CR3_NS2_label_1ba7d532:

    # Caroline "(We were sitting at opposite sides of the small log cabin - basking in the glow of the fire.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:102
translate chinese CR3_NS2_label_90571755:

    # Caroline "(But I keep catching my brother, stealing glances at my naked body...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:104
translate chinese CR3_NS2_label_cd26fc38:

    # Caroline "(But I keep catching my best friend stealing glances at my naked body...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:108
translate chinese CR3_NS2_label_b29d6d90:

    # Caroline "Ugh, dammit..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:110
translate chinese CR3_NS2_label_4947ee58:

    # Caroline "(Why does my brother keep popping into my fantasies?! I have to change the character again. Okay, it’s Joey from college. Focus on Joey.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:112
translate chinese CR3_NS2_label_f183913d:

    # Caroline "(Why does he keep popping into my fantasies?! I have to change the character again. Okay, it’s Joey from college. Focus on Joey.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:113
translate chinese CR3_NS2_label_3853869e:

    # Caroline "(Dammit, I need to turn up the speed too.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:117
translate chinese CR3_NS2_label_cfb94cc1:

    # "*BUZZ BUZZ BUZZ*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:119
translate chinese CR3_NS2_label_d91a6261:

    # Caroline "Ohhhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:120
translate chinese CR3_NS2_label_9f6cd423:

    # Caroline "(Joey keeps stealing glances at my naked body, and I can’t help but notice his cock getting harder. God... it’s so fucking long.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:121
translate chinese CR3_NS2_label_20c5cad2:

    # Caroline "(He tells me, we need to conserve our heat, and that we should spoon to keep warm. I’m too naive to resist him, and scurry over into his arms.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:126
translate chinese CR3_NS2_label_ee70ad83:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:128
translate chinese CR3_NS2_label_bcc78d31:

    # Caroline "(The next thing I know, he has his arms wrapped around my body. His hands are groping my breasts, teasing my nipples, Fuck... His cock is pressing up against my vulva...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:129
translate chinese CR3_NS2_label_b256155c:

    # Caroline "Oh God... Yes..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:133
translate chinese CR3_NS2_label_a103f2cd:

    # Caroline "(I try to object, but he’s far too quick. [player_name]’s dick starts to slip inside me. Inch by inch, my brother penetrates me, forcing his thick meat, deep into my soaking wet pussy.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:135
translate chinese CR3_NS2_label_2340ecb4:

    # Caroline "(I try to object, but he’s far too quick. [player_name]’s dick starts to slip inside me. Inch by inch, my best friend penetrates me, forcing his thick meat, deep into my soaking wet pussy.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:136
translate chinese CR3_NS2_label_fe27090c:

    # Caroline "Ah! Ah! C-C-Cummmmiinng! Ahhhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:140
translate chinese CR3_NS2_label_cbcbe64f_2:

    # "*Buzz Buzz*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:142
translate chinese CR3_NS2_label_7ed91ba6:

    # Caroline "(He begins to fuck me faster and faster. His cock, thrusting in and out of my - tight little hole.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:144
translate chinese CR3_NS2_label_bbcc0233:

    # Caroline "(Oh God... And then he cums so hard. My brother thrusts his hips, in deep, filling me up with his thick, potent, hot cum! I feel it spray into my pussy, filling me up!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:146
translate chinese CR3_NS2_label_74a6ca34:

    # Caroline "(Oh God... and then he cums so hard. [player_name] thrusts his hips in deep, filling me up with his thick, potent, hot cum! I feel it spray into my pussy, filling me up!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:147
translate chinese CR3_NS2_label_d81cc489:

    # Caroline "AHHHHHH!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:151
translate chinese CR3_NS2_label_5724a059:

    # Caroline "Dammit..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:153
translate chinese CR3_NS2_label_76a25c6d:

    # Caroline "(Why the HELL did I start thinking about my brother AGAIN?! It’s SUPPOSED to be Joey!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:155
translate chinese CR3_NS2_label_4a07aa33:

    # Caroline "(Why the HELL did I start thinking about HIM AGAIN?! It’s SUPPOSED to be Joey!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:156
translate chinese CR3_NS2_label_c784b923:

    # Caroline "(Okay, let’s change everything. New position, new people, new fantasy. I can do this!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:160
translate chinese CR3_NS2_label_9e8cfa09:

    # Caroline "(I’m lying down on a beautiful sunny beach, The waves are lapping against the golden sand as I close my eyes, There’s nobody else - as far as the eye can see, so I’m wearing the skimpiest bikini I own.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:162
translate chinese CR3_NS2_label_b8a7b676:

    # Caroline "(Suddenly, I hear footsteps behind me... It’s Simon, an athletic, six foot tall blond guy, who looks NOTHING like my brother.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:164
translate chinese CR3_NS2_label_52fe27b3:

    # Caroline "(Suddenly, I hear footsteps behind me... it’s Simon, an athletic six foot tall blond guy who looks NOTHING like my best friend.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:165
translate chinese CR3_NS2_label_a99ed675:

    # Caroline "(He pounces on me without even asking, locking his lips with my own and kissing me so passionately.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:170
translate chinese CR3_NS2_label_cbcbe64f_3:

    # "*Buzz Buzz*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:172
translate chinese CR3_NS2_label_60827ef3:

    # MC "(Wow! What a show!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:173
translate chinese CR3_NS2_label_aeaaf2bf:

    # Caroline "(Simon slips his fingers under my - tiny bikini top. I feel his warm fingertips pinch and tease - my sensitive nipples - and I can’t bring myself to resist him.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:174
translate chinese CR3_NS2_label_fbf9a561:

    # Caroline "(His other hand slips down, across my belly and towards my bikini bottoms...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:178
translate chinese CR3_NS2_label_99be15b9:

    # Caroline "Ohh... Fuck... Yes..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:179
translate chinese CR3_NS2_label_21683907:

    # Caroline "(Suddenly, his fingers are inside me, pushing, deep into my pussy, and reaching for my g-spot. I buck them up and down, relishing - every last second.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:180
translate chinese CR3_NS2_label_8cec9e6b:

    # Caroline "(Before I realise it - [player_name] has removed his fingers, and has taken his cock out. He is pressing it, up against my bikini bottoms, poking into my pussy, through them.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:184
translate chinese CR3_NS2_label_0d4b0af8:

    # Caroline "Oh, my God... Ohh... Ah..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:186
translate chinese CR3_NS2_label_8a892ac9:

    # Caroline "(My brother is pushing his cock, deeper into my panties. The fabric is pushing itself, into my pussy. If he doesn’t stop, they’ll tear, and his cock will thrust - so fucking deep inside me.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:187
translate chinese CR3_NS2_label_5f0704d5:

    # Caroline "(Dammit! I’m back to thinking about my brother again! But I’m soooo fucking close to cumming...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:189
translate chinese CR3_NS2_label_d93b8491:

    # Caroline "([player_name] is pushing his cock deeper into my panties. The fabric is pushing itself into my pussy. If he doesn’t stop, they’ll tear, and his cock will thrust so fucking deep inside me.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:190
translate chinese CR3_NS2_label_144cb4a3:

    # Caroline "(Dammit! I’m back to thinking about HIM again! But I’m soooo fucking close to cumming...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:196
translate chinese CR3_NS2_label_0c0a8f1d:

    # Caroline "(Ugh! Fine! I’ll think about [player_name] - one last time. But I really need to control my fantasies, from now on!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:197
translate chinese CR3_NS2_label_814af415:

    # Caroline "Ah! AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:200
translate chinese CR3_NS2_label_ee70ad83_1:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:205
translate chinese CR3_NS2_label_285666a1:

    # Caroline "(With one final thrust, my brother plunges his cock, hard against my panties. They tear to shreds, as his cock forces its way through them, and into my sensitive hole.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:207
translate chinese CR3_NS2_label_03b6f864:

    # Caroline "(With one final thrust, my best friend plunges his cock hard against my panties. They tear to shreds, as his cock forces its way through them, and into my sensitive hole.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:209
translate chinese CR3_NS2_label_adfb4193:

    # Caroline "(I wrap my legs around his waist, and scream in pleasure. The sound of the waves, crash up against the shore, as he pummels my pussy, with his massive erection.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:210
translate chinese CR3_NS2_label_15a92a50:

    # Caroline "Yes! Yes! *Gasp* Oh! Fuck!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:214
translate chinese CR3_NS2_label_ee70ad83_2:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:216
translate chinese CR3_NS2_label_1b4d7211:

    # Caroline "(My whole body begins to twitch and shake, as he stirs up my pussy.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:217
translate chinese CR3_NS2_label_2ffc0182:

    # Caroline "AHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:221
translate chinese CR3_NS2_label_7859ef5d:

    # MC "(Holy shit! She is absolutely LOVING this! I don’t think I’ve ever seen Caroline - this horny - before!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:222
translate chinese CR3_NS2_label_c068850c:

    # Caroline "Ah! MMM! Oh fuck!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:226
translate chinese CR3_NS2_label_03d3d79a:

    # Caroline "(And then I feel him thrust in - really deep! He grunts loudly, as his balls begin to clench. And then, he shoots his cum, deep inside me. I tremble and shake, under him, powerless to stop him, as he fills me up.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:228
translate chinese CR3_NS2_label_ee70ad83_3:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:229
translate chinese CR3_NS2_label_17baf6ef:

    # Caroline "AAAHHHHHHH!! HNNNGGGGG!! OOHHHHH!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:233
translate chinese CR3_NS2_label_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:234
translate chinese CR3_NS2_label_a2fdd223:

    # MC "(Wow, she looks exhausted!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:235
translate chinese CR3_NS2_label_d146db5c:

    # MC "(I’d love to know what she was thinking about, while she was - getting herself off.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:239
translate chinese CR3_NS2_label_c958eee7:

    # Caroline "(Holy fuck... That was intense...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:240
translate chinese CR3_NS2_label_38f93f03:

    # Caroline "(Okay, I better put my dildo away, before I accidentally fall asleep - with it lying out.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:242
translate chinese CR3_NS2_label_32bc12b0:

    # Caroline "(I don’t want Mom or Dad walking in on me, in the morning - like this.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:244
translate chinese CR3_NS2_label_bbe9d55d:

    # Caroline "(I don’t want anyone walking in on me in the morning like this.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:248
translate chinese CR3_NS2_label_5db0876b:

    # Caroline "(Okay, let’s hide it under here again. That’ll keep it safe.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:249
translate chinese CR3_NS2_label_6e1a2632:

    # Caroline "(Right, I better get back to bed now. I’m up early again, tomorrow morning.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:253
translate chinese CR3_NS2_label_1d3c02c6:

    # MC "(Huh, so she hides her dildo under her bed. That’s good to know!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:255
translate chinese CR3_NS2_label_b48cfb6c:

    # MC "(I suppose it keeps it safe, when Mom cleans the room, or Sara goes looking for makeup to nick off her older sister.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS2.rpy:257
translate chinese CR3_NS2_label_0701c5be:

    # MC "(I suppose it keeps it safe when Linda cleans the room, or Sara goes hunting for makeup to “borrow”!)"
    MC ""

