﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:117
translate chinese ml_mc_room_night_scene3_v1_label_507d034a:

    # Mom "Hello there, [player_name]."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:118
translate chinese ml_mc_room_night_scene3_v1_label_70dce66b:

    # MC "Jesus! You scared the crap out of me!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:119
translate chinese ml_mc_room_night_scene3_v1_label_e0634cbb:

    # Mom "Aww, sorry, I just had to see you again."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:121
translate chinese ml_mc_room_night_scene3_v1_label_d1ea4eab:

    # MC "Wh-What if Dad catches you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:123
translate chinese ml_mc_room_night_scene3_v1_label_714c1743:

    # MC "Wh-What if Bob catches you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:126
translate chinese ml_mc_room_night_scene3_v1_label_37c0c30f:

    # Mom "Relax - he’s working late. He won’t be home for hours."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:127
translate chinese ml_mc_room_night_scene3_v1_label_23658f38:

    # Mom "Which gives us plenty of time to get more intimate with each other."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:128
translate chinese ml_mc_room_night_scene3_v1_label_0ae763dc:

    # MC "Y-You mean, like... without our underwear on?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:129
translate chinese ml_mc_room_night_scene3_v1_label_51e7d2c9:

    # Mom "Exactly. Sit back on the bed."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:132
translate chinese ml_mc_room_night_scene3_v1_label_9b864cf5:

    # MC "I didn’t realise you’d be wanting to do... more stuff, so soon."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:133
translate chinese ml_mc_room_night_scene3_v1_label_88859fe9:

    # Mom "Of course, I do. I’ve been waiting for a while for this moment."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:134
translate chinese ml_mc_room_night_scene3_v1_label_62d49dd0:

    # Mom "There’s no sense in me waiting any longer."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:137
translate chinese ml_mc_room_night_scene3_v1_label_cf628b9d:

    # MC "It’s... just going very fast.. What’s the plan?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:138
translate chinese ml_mc_room_night_scene3_v1_label_b70c55db:

    # Mom "Well, I’m going to start off by, slowly stripping for you."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:139
translate chinese ml_mc_room_night_scene3_v1_label_f919e5ac:

    # Mom "Then I’m going to pull down your boxer shorts and get another look at your, thick hard cock."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:142
translate chinese ml_mc_room_night_scene3_v1_label_c3ef2a43:

    # Mom "Sound good?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:143
translate chinese ml_mc_room_night_scene3_v1_label_a6fbf3fc:

    # MC "Y-Yes!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:144
translate chinese ml_mc_room_night_scene3_v1_label_5f5f47a3:

    # MC "(This is gonna be awesome!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:147
translate chinese ml_mc_room_night_scene3_v1_label_554d7daf:

    # Mom "You sound a little nervous. Try to relax."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:148
translate chinese ml_mc_room_night_scene3_v1_label_e9d09bed:

    # Mom "I hope you enjoy this. I want you to watch it all and see every moment."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:149
translate chinese ml_mc_room_night_scene3_v1_label_f048f925:

    # MC "I-I’m just a little surprised, is all."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:152
translate chinese ml_mc_room_night_scene3_v1_label_ab1047a4:

    # Mom "Just breathe slowly and relax."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:153
translate chinese ml_mc_room_night_scene3_v1_label_950420a5:

    # Mom "This is all for you."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:155
translate chinese ml_mc_room_night_scene3_v1_label_a9d168c8:

    # MC "(Oh, my God! I’m gonna see Mom’s pussy!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:157
translate chinese ml_mc_room_night_scene3_v1_label_5f550b50:

    # MC "(Oh, my God! I’m gonna see Linda’s pussy!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:160
translate chinese ml_mc_room_night_scene3_v1_label_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:161
translate chinese ml_mc_room_night_scene3_v1_label_73a6170a:

    # Mom "I’ve kept it, trimmed short for you. I figured you’d prefer that."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:162
translate chinese ml_mc_room_night_scene3_v1_label_e93905d8:

    # Mom "There’s so many things I want to do with you."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:165
translate chinese ml_mc_room_night_scene3_v1_label_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:167
translate chinese ml_mc_room_night_scene3_v1_label_2fb1a3bb:

    # MC "You’re beautiful, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:169
translate chinese ml_mc_room_night_scene3_v1_label_a5a9f88c:

    # MC "You’re beautiful, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:170
translate chinese ml_mc_room_night_scene3_v1_label_b8e5dfd7:

    # Mom "Aww... Thank you, Sweetie. I want to see YOUR body, now though."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:173
translate chinese ml_mc_room_night_scene3_v1_label_1745eac6:

    # Mom "Ever since I wanked you off, I haven’t been able to get your cock out of my head."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:175
translate chinese ml_mc_room_night_scene3_v1_label_513db096:

    # Mom "Any time I’m with your father, I’m imagining that it’s you - but even that’s not good enough."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:177
translate chinese ml_mc_room_night_scene3_v1_label_b90c3795:

    # Mom "Any time I’m with Bob, I’m imagining that it’s you - but even that’s not good enough."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:178
translate chinese ml_mc_room_night_scene3_v1_label_9dd998d2:

    # Mom "I need the real thing."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:181
translate chinese ml_mc_room_night_scene3_v1_label_b30de2f1:

    # Mom "Wow..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:182
translate chinese ml_mc_room_night_scene3_v1_label_2580cb12:

    # Mom "Mmm... I could suck on that for hours."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:184
translate chinese ml_mc_room_night_scene3_v1_label_47341759:

    # MC "M-Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:186
translate chinese ml_mc_room_night_scene3_v1_label_f2d3f25c:

    # MC "L-Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:187
translate chinese ml_mc_room_night_scene3_v1_label_231aeedb:

    # Mom "Oh, don’t be so shy."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:190
translate chinese ml_mc_room_night_scene3_v1_label_b34e16ff:

    # Mom "So - how would you like to begin?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:191
translate chinese ml_mc_room_night_scene3_v1_label_320c7bff:

    # Mom "I could live out my fantasy of, sucking you off till you cum, or I could rub your shaft with my feet."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:192
translate chinese ml_mc_room_night_scene3_v1_label_50c80466:

    # Mom "You certainly seemed to enjoy massaging them, the other other day."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:198
translate chinese ml_mc_room_night_scene3_v1_label_9d47c075:

    # Mom "Hello again, Sweetie."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:200
translate chinese ml_mc_room_night_scene3_v1_label_d93d69ae:

    # MC "Hey, Mom. I was half-expecting to see you in here tonight."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:202
translate chinese ml_mc_room_night_scene3_v1_label_d6565136:

    # MC "Hey, Linda. I was half-expecting to see you in here tonight."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:203
translate chinese ml_mc_room_night_scene3_v1_label_5cedfe3b:

    # Mom "I certainly hope, the novelty hasn’t worn off."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:204
translate chinese ml_mc_room_night_scene3_v1_label_535ea586:

    # MC "I don’t think that’ll happen for a long time."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:207
translate chinese ml_mc_room_night_scene3_v1_label_227b824e:

    # Mom "Well, let’s get down to business, shall we?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:210
translate chinese ml_mc_room_night_scene3_v1_label_f9f99e2c:

    # Mom "I must say, I’m looking forward to these, nightly sessions, becoming a regular thing."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:212
translate chinese ml_mc_room_night_scene3_v1_label_751b333a:

    # MC "Me too, Mom. I really enjoyed last time."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:214
translate chinese ml_mc_room_night_scene3_v1_label_c4e719dd:

    # MC "Me too, Linda. I really enjoyed last time."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:217
translate chinese ml_mc_room_night_scene3_v1_label_d276ed8e:

    # Mom "It’s been quite some time, since I had a man in my life, who actually turned me on."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:220
translate chinese ml_mc_room_night_scene3_v1_label_f5ade09e:

    # Mom "Now, what shall we do tonight?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:223
translate chinese ml_mc_room_night_scene3_v1_label_4a444209:

    # Mom "Would you like me to use my feet to get you off?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:224
translate chinese ml_mc_room_night_scene3_v1_label_ca2fe969:

    # Mom "Would you prefer it, if I sucked your cock with my mouth?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:269
translate chinese ML_NS_1_77602cfa:

    # MC "I want to feel your lips, wrapped around my dick, tonight."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:270
translate chinese ML_NS_1_3dd897e1:

    # Mom "Mmm... I like THAT choice."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:273
translate chinese ML_NS_1_2eee58de:

    # Mom "You just lie back and relax."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:274
translate chinese ML_NS_1_3df0bc88:

    # Mom "Let me work my magic, and blow your mind."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:275
translate chinese ML_NS_1_19ab962c:

    # Mom "Although, I highly doubt, you’ll last very long."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:279
translate chinese ML_NS_1_59acbc47:

    # MC "You seem a bit overconfident, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:281
translate chinese ML_NS_1_a3b83a1e:

    # MC "You seem a bit overconfident, Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:282
translate chinese ML_NS_1_b76f02fa:

    # MC "I highly doubt, that you’re THAT good."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:286
translate chinese ML_NS_1_51c5fdf8:

    # Mom "Let’s just see, shall we?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:289
translate chinese ML_NS_1_6aa203ed:

    # Mom "(Sniff!) Ahh..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:290
translate chinese ML_NS_1_09f67e23:

    # Mom "(God, he smells incredible! I would love to take my time, sucking him slowly, and dragging out his orgasm.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:291
translate chinese ML_NS_1_755fa872:

    # Mom "(But since he doesn’t believe I could make him cum THAT quickly, I’m just going to have to go all-out.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:295
translate chinese ML_NS_1_891bbd6f:

    # Mom "(There’ll be other opportunities to go slowly. Tonight, I’m gonna blow my boy’s mind.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:297
translate chinese ML_NS_1_255fd81a:

    # Mom "(There'll be other opportunities to go slowly. Tonight, I'm gonna blow his mind!))"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:298
translate chinese ML_NS_1_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:299
translate chinese ML_NS_1_14f99d3b:

    # Mom "(Sounds like he’s already moaning - and I haven’t even reached the tip yet.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:302
translate chinese ML_NS_1_abbfe561:

    # MC "(Damn, she wasn’t lying when she said she was good with her tongue, at work.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:306
translate chinese ML_NS_1_e2b820a7:

    # MC "(She’s wrapping and flicking her tongue across my cock, so well!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:309
translate chinese ML_NS_1_24563497:

    # MC "Ooohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:313
translate chinese ML_NS_1_63b552c8:

    # MC "(I can feel her hot breath, cascading over my glans.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:314
translate chinese ML_NS_1_c3928df8:

    # MC "(She’s about to put it in her mouth, any second now!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:317
translate chinese ML_NS_1_c551b40e:

    # Mom "*Suck Suck.*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:318
translate chinese ML_NS_1_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:319
translate chinese ML_NS_1_286ec1f0:

    # MC "(Wow! It’s so hot and wet in her mouth!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:322
translate chinese ML_NS_1_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:323
translate chinese ML_NS_1_b432b3d8:

    # MC "Mmmm! Ohhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:324
translate chinese ML_NS_1_7198271c:

    # Mom "(Hehe... It doesn't sound like he’s gonna last, terribly long!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:327
translate chinese ML_NS_1_4ee305fb:

    # Mom "(Shluuurrp)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:331
translate chinese ML_NS_1_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:332
translate chinese ML_NS_1_faf8883b:

    # Mom "(Mmm! His, thick cock, feels so good in my mouth!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:336
translate chinese ML_NS_1_ab130611:

    # Mom "(I hope he wants to finish inside, so I can taste his cum.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:339
translate chinese ML_NS_1_5e96c4cc:

    # Mom "*Suck. Shlurp. Suuuuck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:340
translate chinese ML_NS_1_ed62d1e4:

    # MC "Ah! Fuck! Ahhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:347
translate chinese ML_NS_1_4f5d4b33:

    # MC "Ugh! I’m gonna cum!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:348
translate chinese ML_NS_1_f6c198c8:

    # MC "Don’t stop sucking! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:352
translate chinese ML_NS_1_27490442:

    # Mom "(Yes! He wants to cum inside!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:355
translate chinese ML_NS_1_5789c71d:

    # MC "Oooh! Ahhhhhhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:356
translate chinese ML_NS_1_179b22db:

    # Mom "(Gulp! Gulp!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:357
translate chinese ML_NS_1_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:366
translate chinese ML_NS_1_97d0ba1b:

    # Mom "Aaahhh..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:367
translate chinese ML_NS_1_a53ca69d:

    # Mom "(Wow! He came so much! I had to swallow a little bit.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:369
translate chinese ML_NS_1_bb1d5a66:

    # MC "That was amazing, Mom... "
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:371
translate chinese ML_NS_1_f7f63283:

    # MC "That was amazing, Linda... "
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:374
translate chinese ML_NS_1_168ae694:

    # Mom "(Gulp!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:375
translate chinese ML_NS_1_34398479:

    # Mom "(It tastes quite salty - not bad though!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:376
translate chinese ML_NS_1_5345d619:

    # MC "(Wow! She just swallowed it all!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:380
translate chinese ML_NS_1_fd9aff8b:

    # MC "That was incredible, Mom! Thank you!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:382
translate chinese ML_NS_1_a13b824d:

    # MC "That was incredible, Linda! Thank you!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:383
translate chinese ML_NS_1_932be97b:

    # Mom "I did warn you that you wouldn’t last long, against one of my blowjobs."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:384
translate chinese ML_NS_1_70822b7a:

    # MC "Haha! I should have listened."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:386
translate chinese ML_NS_1_0c130ca1:

    # Mom "Okay, I better get back to bed, before your father finds me missing."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:388
translate chinese ML_NS_1_6ae54606:

    # Mom "Okay, I better get back to bed, before Bob finds me missing."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:389
translate chinese ML_NS_1_51e72689:

    # Mom "See you tomorrow."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:391
translate chinese ML_NS_1_8a149e07:

    # MC "See you tomorrow, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:393
translate chinese ML_NS_1_afd82f0f:

    # MC "See you tomorrow, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:399
translate chinese ML_NS_1_2ed72faa:

    # MC "I’m gonna cum! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:403
translate chinese ML_NS_1_3d26c017:

    # MC "Can I do it on your face?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:405
translate chinese ML_NS_1_e45d5ede:

    # Mom "(I would have preferred him, to cum in my mouth - but whatever makes my boy happier.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:407
translate chinese ML_NS_1_0ab8353d:

    # Mom "(I would have preferred him, to cum in my mouth - but whatever makes this boy happier.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:415
translate chinese ML_NS_1_5b2b3224:

    # MC "Oh fuck! Yes! Ahhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:416
translate chinese ML_NS_1_d0b78f7e:

    # Mom "(Mmm... feeling his warm sticky cum, over my face, isn’t as bad as I imagined it would be.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:417
translate chinese ML_NS_1_90f03e25:

    # MC "Ah... Phew..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:418
translate chinese ML_NS_1_1e1213d3:

    # Mom "Did you enjoy that, Sweetie?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:419
translate chinese ML_NS_1_b02dd2b8:

    # MC "Y-Yeah... That was amazing..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:420
translate chinese ML_NS_1_932be97b_1:

    # Mom "I did warn you that you wouldn’t last long, against one of my blowjobs."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:421
translate chinese ML_NS_1_70822b7a_1:

    # MC "Haha! I should have listened."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:423
translate chinese ML_NS_1_0c130ca1_1:

    # Mom "Okay, I better get back to bed, before your father finds me missing."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:425
translate chinese ML_NS_1_6ae54606_1:

    # Mom "Okay, I better get back to bed, before Bob finds me missing."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:426
translate chinese ML_NS_1_51e72689_1:

    # Mom "See you tomorrow."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:428
translate chinese ML_NS_1_8a149e07_1:

    # MC "See you tomorrow, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:430
translate chinese ML_NS_1_afd82f0f_1:

    # MC "See you tomorrow, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:437
translate chinese ML_NS_6_62135f75:

    # MC "C-Could you use your feet tonight, Mom?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:439
translate chinese ML_NS_6_24136ecd:

    # MC "C-Could you use your feet tonight, Linda?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:440
translate chinese ML_NS_6_11e2fd2e:

    # Mom "Feet? I didn’t expect t-tha..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:441
translate chinese ML_NS_6_793b41d3:

    # Mom "...Of course, Sweetie. Just sit back, against me and relax."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:443
translate chinese ML_NS_6_a9b3a965:

    # Mom "Let mommy take care of the rest."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:445
translate chinese ML_NS_6_18cb6299:

    # Mom "Let me take care of the rest."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:450
translate chinese ML_NS_6_e0dd4a62:

    # Mom "Are you comfortable?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:451
translate chinese ML_NS_6_e15546d2:

    # MC "Y-Yeah, I am."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:452
translate chinese ML_NS_6_95dd68f8:

    # Mom "Good. I’ll start now. I hope you enjoy this."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:455
translate chinese ML_NS_6_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:458
translate chinese ML_NS_6_5264e88c:

    # Mom "You really like my feet, don’t you, [player_name]?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:460
translate chinese ML_NS_6_e28ac1d9:

    # MC "Y-Yeah, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:462
translate chinese ML_NS_6_96f7d6d4:

    # MC "Y-Yeah, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:463
translate chinese ML_NS_6_4f430af0:

    # Mom "Haha! I guessed that."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:466
translate chinese ML_NS_6_3cac95d9:

    # Mom "Would you like me to go faster?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:468
translate chinese ML_NS_6_f9dcaec6:

    # MC "Just, whatever you think is best, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:470
translate chinese ML_NS_6_53494b6a:

    # MC "Just, whatever you think is best, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:473
translate chinese ML_NS_6_d887f077:

    # Mom "You’ve got such a sexy cock. I could play with it for hours."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:474
translate chinese ML_NS_6_f02c929a:

    # Mom "I’ll let you fuck my pussy someday. I can’t wait to feel you inside me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:475
translate chinese ML_NS_6_bd56844e:

    # Mom "You’ve gotten me so wet, just by sitting naked beside me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:478
translate chinese ML_NS_6_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:480
translate chinese ML_NS_6_f619a957:

    # MC "(I can feel Mom’s hot breath in my ear. She has such a seductive voice when she whispers.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:482
translate chinese ML_NS_6_9b30a341:

    # MC "(I can feel Linda’s hot breath in my ear. She has such a seductive voice when she whispers.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:483
translate chinese ML_NS_6_1852aad6:

    # Mom "(Alright, I’ve been doing this for a few minutes now. Time to up my game.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:486
translate chinese ML_NS_6_442a4d38:

    # Mom "(Let’s see how he likes it when I lick his neck.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:487
translate chinese ML_NS_6_7e7de820:

    # MC "Ooohh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:488
translate chinese ML_NS_6_dfc013ac:

    # Mom "(Mmm... he shivered! I think he’s rather sensitive there.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:492
translate chinese ML_NS_6_fb8bc6a6:

    # MC "Oh! Oh, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:493
translate chinese ML_NS_6_a49ee00c:

    # Mom "Are you enjoying, my feet, massaging your cock, Sweetie?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:494
translate chinese ML_NS_6_11e9409d:

    # MC "Y-Yes, Mom! Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:496
translate chinese ML_NS_6_29e94765:

    # MC "Oh! Oh, Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:497
translate chinese ML_NS_6_a49ee00c_1:

    # Mom "Are you enjoying, my feet, massaging your cock, Sweetie?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:498
translate chinese ML_NS_6_6c01300f:

    # MC "Y-Yes, Linda! Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:502
translate chinese ML_NS_6_d0bee6f8:

    # Mom "I want you to be a good boy, and cum for Mommy."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:504
translate chinese ML_NS_6_33a888e5:

    # Mom "Will you do that for me?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:505
translate chinese ML_NS_6_974472b5:

    # MC "Y-Yes, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:507
translate chinese ML_NS_6_15f1d2b0:

    # Mom "I want you to be a good boy, and cum for me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:509
translate chinese ML_NS_6_33a888e5_1:

    # Mom "Will you do that for me?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:510
translate chinese ML_NS_6_5a51f42e:

    # MC "Y-Yes, Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:513
translate chinese ML_NS_6_79ea0e66:

    # Mom "Be a good boy, and cum all over my feet."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:514
translate chinese ML_NS_6_cd69d752:

    # Mom "I want to feel your sticky, warm cum, between my toes."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:515
translate chinese ML_NS_6_db207a33:

    # MC "Ah! Ahhh! Ohhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:518
translate chinese ML_NS_6_d4de55d2:

    # MC "Fuck! I’m cumming! Ahh! Uggghhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:521
translate chinese ML_NS_6_2924f52b:

    # Mom "That’s it! Cum for Mommy!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:523
translate chinese ML_NS_6_dddb6f0a:

    # Mom "That’s it! Cum for me!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:525
translate chinese ML_NS_6_c3cd3372:

    # Mom "(It feels so good, making him cum. Hopefully he’ll want to repay the favour some day.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:533
translate chinese ML_NS_6_fd29b98e:

    # Mom "Wow... You came sooo much!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:534
translate chinese ML_NS_6_410ea644:

    # MC "*Gasp!* *Pant!*"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:535
translate chinese ML_NS_6_0d38bf41:

    # Mom "Aww... are you out of breath. Let’s lie down together, for a while."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:539
translate chinese ML_NS_6_e828b3db:

    # MC "Th-Thank you, Mom..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:540
translate chinese ML_NS_6_79aa00ce:

    # Mom "Shush... Just relax and catch your breath."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:541
translate chinese ML_NS_6_f435dd42:

    # Mom "I’ll cuddle you for a while, then head back into my own room."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:542
translate chinese ML_NS_6_fa2a6dbd:

    # MC "*Pant* You’re incredible, Mom..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:544
translate chinese ML_NS_6_de8829f0:

    # MC "Th-Thank you, Linda..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:545
translate chinese ML_NS_6_79aa00ce_1:

    # Mom "Shush... Just relax and catch your breath."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:546
translate chinese ML_NS_6_f435dd42_1:

    # Mom "I’ll cuddle you for a while, then head back into my own room."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:547
translate chinese ML_NS_6_5aa1141e:

    # MC "*Pant* You’re incredible, Linda..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:548
translate chinese ML_NS_6_d6782d89:

    # Mom "Shush - I know."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:549
translate chinese ML_NS_6_0839e2e8:

    # Mom "Sweet dreams, [player_name]."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:556
translate chinese ML_NS_2_488b154b:

    # MC "This time, I think I’d like to try a boobjob with you."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:557
translate chinese ML_NS_2_a836da08:

    # Mom "Oh really? Do you think you could handle that?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:558
translate chinese ML_NS_2_e40ae654:

    # MC "Sure, why not?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:562
translate chinese ML_NS_2_225b2f7f:

    # Mom "Okay, big boy. If you’re so sure."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:563
translate chinese ML_NS_2_021e23e1:

    # Mom "Go ahead and lie down on the bed. Then let me work my magic."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:564
translate chinese ML_NS_2_1868b745:

    # MC "Actually - this time I want to be on top."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:565
translate chinese ML_NS_2_943268d5:

    # Mom "Let’s see how you fare with that."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:569
translate chinese ML_NS_2_1a8adc78:

    # Mom "So, is this the kind of position you were thinking of?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:570
translate chinese ML_NS_2_078daaae:

    # MC "Yeah, this is perfect."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:571
translate chinese ML_NS_2_46fd6830:

    # Mom "Okay, I’ll hold my tits together for you. Then, you can thrust your hips and move your cock between them."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:575
translate chinese ML_NS_2_56172ec3:

    # MC "Mmm! That’s so good!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:578
translate chinese ML_NS_2_c4e444d2:

    # MC "Your breasts are amazing, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:580
translate chinese ML_NS_2_6db21719:

    # MC "Your breasts are amazing!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:581
translate chinese ML_NS_2_e4f87993:

    # Mom "Hehe! I know."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:585
translate chinese ML_NS_2_0059b63b:

    # MC "Ah... Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:586
translate chinese ML_NS_2_d1cacfd0:

    # MC "(I can feel her soft breasts, massaging every single inch of my cock! This is awesome!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:588
translate chinese ML_NS_2_43c2d7b7:

    # Mom "(It looks like my boy is REALLY enjoying this!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:590
translate chinese ML_NS_2_50ae9726:

    # Mom "(It looks like he is REALLY enjoying this!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:593
translate chinese ML_NS_2_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:594
translate chinese ML_NS_2_34f91aa8:

    # Mom "I hope you don’t cum too quickly on me, now!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:596
translate chinese ML_NS_2_67854489:

    # MC "I won’t! Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:600
translate chinese ML_NS_2_63809f5a:

    # Mom "So, how are you enjoying being on top?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:602
translate chinese ML_NS_2_174d6041:

    # MC "Mmm! It’s great, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:604
translate chinese ML_NS_2_95e57066:

    # MC "Mmm! It’s great, Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:605
translate chinese ML_NS_2_a23d967e:

    # Mom "Good to hear. I usually prefer being on top, myself. But I can always do bottom, for a change."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:609
translate chinese ML_NS_2_47523c1c:

    # Mom "If you want, you can push your hips forward a bit more and I can try sucking the tip of your cock, while you tit-fuck me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:610
translate chinese ML_NS_2_79692f42:

    # MC "Cool!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:611
translate chinese ML_NS_2_7d3e7089:

    # Mom "Okay, bring your dick a bit closer to my mouth."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:615
translate chinese ML_NS_2_f1020faf:

    # Mom "Good... Just another inch or two!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:616
translate chinese ML_NS_2_0bbfe921:

    # MC "(This is gonna feel incredible!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:620
translate chinese ML_NS_2_ae1f3bdf:

    # Mom "Shlurrrrp!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:621
translate chinese ML_NS_2_b3c8f02a:

    # MC "Ohhh! Fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:622
translate chinese ML_NS_2_f1e73f4a:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:626
translate chinese ML_NS_2_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:628
translate chinese ML_NS_2_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:629
translate chinese ML_NS_2_808db81a:

    # MC "(She’s pursing her lips and suckling so hard!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:630
translate chinese ML_NS_2_b04f0590:

    # MC "(It feels like she’s trying to drain the semen from my balls!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:635
translate chinese ML_NS_2_9f80f5b9:

    # MC "Shit! Mom, I’m cumming!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:637
translate chinese ML_NS_2_f04bde31:

    # MC "Shit! Linda, I’m cumming!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:639
translate chinese ML_NS_2_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:640
translate chinese ML_NS_2_1ee4d013:

    # MC "Ahh! Hnnnng! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:641
translate chinese ML_NS_2_6b1c58e2:

    # Mom "*Suck Shlurrrrp!*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:642
translate chinese ML_NS_2_25b637a3:

    # MC "AHHHHHH!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:645
translate chinese ML_NS_2_24169105:

    # MC "Wow... *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:646
translate chinese ML_NS_2_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:650
translate chinese ML_NS_2_47e07e66:

    # Mom "*Gulp!*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:651
translate chinese ML_NS_2_a23a104f:

    # MC "(Wow! She swallowed it all!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:652
translate chinese ML_NS_2_5f359eb2:

    # MC "You must really like the taste of cum!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:656
translate chinese ML_NS_2_9a7df899:

    # Mom "Only yours, Dear."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:658
translate chinese ML_NS_2_ae18b23b:

    # Mom "There’s something intensely erotic about swallowing your son’s cum."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:659
translate chinese ML_NS_2_99e35e67:

    # MC "I love you, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:661
translate chinese ML_NS_2_4926551c:

    # Mom "There’s something intensely erotic about swallowing the cum of a guy so much younger than I am."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:662
translate chinese ML_NS_2_e517d6c7:

    # MC "I love you, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:663
translate chinese ML_NS_2_2b4de539:

    # Mom "I love you too."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:668
translate chinese ML_NS_assjob_63fe1c9f:

    # MC "Can I grind my cock between your ass tonight, Mom?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:670
translate chinese ML_NS_assjob_ce74793c:

    # Mom "Of course, Sweetie."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:674
translate chinese ML_NS_assjob_bedb79fc:

    # Mom "That’s me ready when you are."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:676
translate chinese ML_NS_assjob_47eb5bed:

    # MC "Thanks, Mom! You look so hot right now!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:680
translate chinese ML_NS_assjob_1741fbb4:

    # Mom "Shush, keep your voice down. We don’t want to wake your sisters."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:682
translate chinese ML_NS_assjob_71b08184:

    # MC "*Whispered* Sorry, of course."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:686
translate chinese ML_NS_assjob_6819763f:

    # MC "Mmm... (I can’t wait to rub my dick between those thick cheeks.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:688
translate chinese ML_NS_assjob_5aab3a8c:

    # Mom "Well? What are you waiting for?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:692
translate chinese ML_NS_assjob_9b640c34:

    # MC "Ooohh... Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:694
translate chinese ML_NS_assjob_e152b7fa:

    # Mom "Hehe, it sounds like my boy’s enjoying that."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:698
translate chinese ML_NS_assjob_7740393a:

    # MC "Hnnng... Fuck... This feels so good, Mom. *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:700
translate chinese ML_NS_assjob_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:704
translate chinese ML_NS_assjob_ab8cc800:

    # MC "Ugh... Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:706
translate chinese ML_NS_assjob_d44995c0:

    # Mom "(Mmm, I love listening to his groans. It turns me on so much!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:710
translate chinese ML_NS_assjob_15d05c89:

    # MC "*Pant* *Pant* Ohh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:712
translate chinese ML_NS_assjob_0da9a9de:

    # Mom "That’s it. Keep sliding your thick dick between your Mommy’s asscheeks."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:714
translate chinese ML_NS_assjob_32fd9635:

    # MC "Hnnng! Oh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:721
translate chinese ML_NS_assjob_e2807814:

    # MC "Hnnng! F-Fuck! I’m gonna cum, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:723
translate chinese ML_NS_assjob_e4882d97:

    # Mom "That’s it. Cum all over your mommy’s back. Keep thrusting between your Mom’s ass until you cum!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:725
translate chinese ML_NS_assjob_f48b5ff6:

    # MC "*Pant* *Ah! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:735
translate chinese ML_NS_assjob_af9b81f2:

    # MC "Argghhh!! HNNGG!! Ohhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:737
translate chinese ML_NS_assjob_34760a24:

    # Mom "Mmm! That’s it! Cum for me, baby."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:739
translate chinese ML_NS_assjob_518079dc:

    # MC "Ohhh! Fuck... *Gasp* Hnnng..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:741
translate chinese ML_NS_assjob_f4cdf924:

    # MC "*Pant* That was amazing, Mom. Thank you."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:743
translate chinese ML_NS_assjob_83047e8d:

    # Mom "I’m glad you enjoyed it, Sweetie. I’ll see you tomorrow. Try and get some sleep."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:745
translate chinese ML_NS_assjob_a95fce8b:

    # MC "Goodnight, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:748
translate chinese ML_NS_assjob_817b3a55:

    # MC "Can I grind my cock between your ass tonight, Linda?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:750
translate chinese ML_NS_assjob_ce74793c_1:

    # Mom "Of course, Sweetie."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:754
translate chinese ML_NS_assjob_bedb79fc_1:

    # Mom "That’s me ready when you are."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:756
translate chinese ML_NS_assjob_c0201382:

    # MC "Thanks, Linda! You look so hot right now!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:760
translate chinese ML_NS_assjob_efc7d2c4:

    # Mom "Shush, keep your voice down. We don’t want to wake the girls."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:762
translate chinese ML_NS_assjob_71b08184_1:

    # MC "*Whispered* Sorry, of course."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:766
translate chinese ML_NS_assjob_6819763f_1:

    # MC "Mmm... (I can’t wait to rub my dick between those thick cheeks.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:768
translate chinese ML_NS_assjob_5aab3a8c_1:

    # Mom "Well? What are you waiting for?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:772
translate chinese ML_NS_assjob_9b640c34_1:

    # MC "Ooohh... Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:774
translate chinese ML_NS_assjob_99e35c04:

    # Mom "Hehe, it sounds like you’re enjoying that."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:778
translate chinese ML_NS_assjob_14fdf3d9:

    # MC "Hnnng... Fuck... This feels so good, Linda. *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:780
translate chinese ML_NS_assjob_f1b4eb1c_1:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:784
translate chinese ML_NS_assjob_ab8cc800_1:

    # MC "Ugh... Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:786
translate chinese ML_NS_assjob_d44995c0_1:

    # Mom "(Mmm, I love listening to his groans. It turns me on so much!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:790
translate chinese ML_NS_assjob_15d05c89_1:

    # MC "*Pant* *Pant* Ohh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:792
translate chinese ML_NS_assjob_331e310f:

    # Mom "That’s it. Keep sliding your thick dick between my asscheeks."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:794
translate chinese ML_NS_assjob_32fd9635_1:

    # MC "Hnnng! Oh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:800
translate chinese ML_NS_assjob_f5982746:

    # MC "Hnnng! F-Fuck! I’m gonna cum, Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:802
translate chinese ML_NS_assjob_e6c9772e:

    # Mom "That’s it. Cum all over my back. Keep thrusting between my asscheeks until you cum!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:804
translate chinese ML_NS_assjob_f48b5ff6_1:

    # MC "*Pant* *Ah! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:815
translate chinese ML_NS_assjob_af9b81f2_1:

    # MC "Argghhh!! HNNGG!! Ohhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:817
translate chinese ML_NS_assjob_34760a24_1:

    # Mom "Mmm! That’s it! Cum for me, baby."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:819
translate chinese ML_NS_assjob_518079dc_1:

    # MC "Ohhh! Fuck... *Gasp* Hnnng..."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:821
translate chinese ML_NS_assjob_644839b5:

    # MC "*Pant* That was amazing, Linda. Thank you."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:823
translate chinese ML_NS_assjob_83047e8d_1:

    # Mom "I’m glad you enjoyed it, Sweetie. I’ll see you tomorrow. Try and get some sleep."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:825
translate chinese ML_NS_assjob_7b9072a1:

    # MC "Goodnight, Linda."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:832
translate chinese ML_NS_anal_90787048:

    # MC "How about we try anal tonight?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:834
translate chinese ML_NS_anal_880bdd46:

    # Mom "Alright, if that’s what you want. Just give me a minute to prepare myself, Sweetie."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:836
translate chinese ML_NS_anal_71046e63:

    # MC "No problem, Mom. Take your time!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:840
translate chinese ML_NS_anal_ac38335c:

    # Mom "OoooOOooohhhhh!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:842
translate chinese ML_NS_anal_f2197cc8:

    # Mom "(God, he fucks me in a way that Bob never could!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:844
translate chinese ML_NS_anal_7daf2b66:

    # MC "Hnnng! Your ass is so tight, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:848
translate chinese ML_NS_anal_ca724af2:

    # Mom "Ah... Yesss!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:850
translate chinese ML_NS_anal_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:854
translate chinese ML_NS_anal_3a516501:

    # Mom "Ohhh... Just like that... Mmm... God, you’re so fucking big!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:856
translate chinese ML_NS_anal_0ba05ace:

    # MC "*Pant* Hnnng!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:862
translate chinese ML_NS_anal_b04cb5c2:

    # Mom "*Gasp* Ohhh! Oh my God! Yes! Yes!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:864
translate chinese ML_NS_anal_898cba78:

    # MC "*Pant* Your ass is sooo tight, Mom!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:870
translate chinese ML_NS_anal_5594c4a7:

    # Mom "Ah! I’m cumming! Don’t stop! Don’t you dare stop! Ah! AHHHH!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:872
translate chinese ML_NS_anal_6ab31951_1:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:878
translate chinese ML_NS_anal_70eac9f9:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:880
translate chinese ML_NS_anal_c9cfa7d3:

    # Mom "Ah! Ah! Yes! Ahhh! Ohhh! AYAAAHHHHHHHH!!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:886
translate chinese ML_NS_anal_61f43c69:

    # MC "HNNNGG! Arrghhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:888
translate chinese ML_NS_anal_16f9d72d:

    # Mom "*Gasp* Yes! Fill me up! Fill me with your cum! Aaahhhhhhh!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:898
translate chinese ML_NS_anal_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:900
translate chinese ML_NS_anal_5b39d610:

    # Mom "Wow... *Pant* That was intense!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:902
translate chinese ML_NS_anal_81bfda6a:

    # MC "Thanks, Mom. That was amazing!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:904
translate chinese ML_NS_anal_e3afa4cc:

    # Mom "I’m glad you enjoyed it, Sweetie. You better get some sleep now though. It’s VERY late."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:906
translate chinese ML_NS_anal_40daf911:

    # MC "I’ll see you tomorrow, Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:908
translate chinese ML_NS_anal_a9d8c89e:

    # Mom "Sweet dreams, Sweetie."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:910
translate chinese ML_NS_anal_90787048_1:

    # MC "How about we try anal tonight?"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:912
translate chinese ML_NS_anal_880bdd46_1:

    # Mom "Alright, if that’s what you want. Just give me a minute to prepare myself, Sweetie."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:914
translate chinese ML_NS_anal_848a18c3:

    # MC "No problem. Take your time!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:918
translate chinese ML_NS_anal_ac38335c_1:

    # Mom "OoooOOooohhhhh!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:920
translate chinese ML_NS_anal_f2197cc8_1:

    # Mom "(God, he fucks me in a way that Bob never could!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:922
translate chinese ML_NS_anal_5b629d32:

    # MC "Hnnng! Your ass is so tight, Linda!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:926
translate chinese ML_NS_anal_ca724af2_1:

    # Mom "Ah... Yesss!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:928
translate chinese ML_NS_anal_6ab31951_2:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:932
translate chinese ML_NS_anal_3a516501_1:

    # Mom "Ohhh... Just like that... Mmm... God, you’re so fucking big!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:934
translate chinese ML_NS_anal_0ba05ace_1:

    # MC "*Pant* Hnnng!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:940
translate chinese ML_NS_anal_b04cb5c2_1:

    # Mom "*Gasp* Ohhh! Oh my God! Yes! Yes!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:942
translate chinese ML_NS_anal_2a142374:

    # MC "*Pant* Your ass is sooo tight!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:948
translate chinese ML_NS_anal_5594c4a7_1:

    # Mom "Ah! I’m cumming! Don’t stop! Don’t you dare stop! Ah! AHHHH!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:950
translate chinese ML_NS_anal_6ab31951_3:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:956
translate chinese ML_NS_anal_70eac9f9_1:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:958
translate chinese ML_NS_anal_c9cfa7d3_1:

    # Mom "Ah! Ah! Yes! Ahhh! Ohhh! AYAAAHHHHHHHH!!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:964
translate chinese ML_NS_anal_61f43c69_1:

    # MC "HNNNGG! Arrghhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:967
translate chinese ML_NS_anal_16f9d72d_1:

    # Mom "*Gasp* Yes! Fill me up! Fill me with your cum! Aaahhhhhhh!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:977
translate chinese ML_NS_anal_34c6a48b_1:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:979
translate chinese ML_NS_anal_5b39d610_1:

    # Mom "Wow... *Pant* That was intense!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:981
translate chinese ML_NS_anal_46f0a3d3:

    # MC "Thanks, Linda. That was amazing!"
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:983
translate chinese ML_NS_anal_e3afa4cc_1:

    # Mom "I’m glad you enjoyed it, Sweetie. You better get some sleep now though. It’s VERY late."
    Mom ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:985
translate chinese ML_NS_anal_f6a9b7d1:

    # MC "I’ll see you tomorrow."
    MC ""

# game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:987
translate chinese ML_NS_anal_a9d8c89e_1:

    # Mom "Sweet dreams, Sweetie."
    Mom ""

translate chinese strings:

    # game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:342
    old "Cum inside her mouth."
    new ""

    # game/scripts/home/mc_room/night/scenes/ml_mc_room_night_scene3_v1.rpy:342
    old "Pull out and cum on her face."
    new ""

