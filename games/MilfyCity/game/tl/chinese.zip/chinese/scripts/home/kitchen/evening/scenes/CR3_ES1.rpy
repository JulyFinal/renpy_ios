﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:23
translate chinese CR3_ES1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:30
translate chinese CR3_ES1_label_010bea47_1:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:45
translate chinese CR3_ES1_label_ef80fabd:

    # MC "(What the heck is Caroline doing? I’ve never seen her sit and drink beer, by herself.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:46
translate chinese CR3_ES1_label_eea355bc:

    # MC "(She really rocks that outfit though! I love those super-tight denim shorts, she’s wearing!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:50
translate chinese CR3_ES1_label_4383885a:

    # MC "(And that crop top, clings around her breasts perfectly! Goddamn! She’s so sexy...)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:51
translate chinese CR3_ES1_label_a2801623:

    # MC "(I don’t think she’s heard me enter the kitchen yet - I should probably announce myself.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:52
translate chinese CR3_ES1_label_650afa35:

    # MC "H-Hey, Caroline... What’s up?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:56
translate chinese CR3_ES1_label_2159732a:

    # Caroline "Huh? Oh! Hey, [player_name]. Nothing much, just chilling out here."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:57
translate chinese CR3_ES1_label_c144bd9d:

    # MC "Why aren’t you in your bedroom?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:58
translate chinese CR3_ES1_label_0a805711:

    # Caroline "Ugh, I’d spent way too long cooped up in there working on the tax returns for my business. I needed a change of scenery - figured the kitchen would do fine."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:59
translate chinese CR3_ES1_label_67ff455f:

    # MC "Mind if I join you?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:60
translate chinese CR3_ES1_label_fc1e4efb:

    # Caroline "Sure - grab a seat."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:64
translate chinese CR3_ES1_label_411dadf5:

    # MC "Something on your mind?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:65
translate chinese CR3_ES1_label_9678ec2a:

    # Caroline " A lotta shit - But you don’t need to concern yourself with it. "
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:66
translate chinese CR3_ES1_label_2a6273f7:

    # MC "Are you gonna drink both of those, or can I have one?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:71
translate chinese CR3_ES1_label_197cdf71:

    # Caroline "Sure, go ahead. They were $2.50 each, or two for $4, at the store - and it seemed a waste to only buy one."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:72
translate chinese CR3_ES1_label_6f4a2338:

    # MC "Thanks."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:73
translate chinese CR3_ES1_label_53c2e141:

    # Caroline "No sweat."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:83
translate chinese CR3_ES1_menu_e62e5ea4:

    # MC "How about we - drink to something?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:84
translate chinese CR3_ES1_menu_b99df4e7:

    # Caroline "Sure! What do you want to drink to?"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:90
translate chinese CR3_ES1_menu_5a34dac2:

    # MC "Let’s drink to - the success of your business!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:94
translate chinese CR3_ES1_menu_d5b2538d:

    # Caroline "Now, that’s a drink I can - get behind!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:95
translate chinese CR3_ES1_menu_e259f9c7:

    # Caroline "Bottoms up!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:99
translate chinese CR3_ES1_menu_80ce5fc6:

    # "*GLUG GLUG GLUG*"
    ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:100
translate chinese CR3_ES1_menu_9470af01:

    # MC "(I think that was a - wise choice - to drink to. If I’d asked her about the deal, I might have - pissed her off - or upset her.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:106
translate chinese CR3_ES1_menu_f69e72bd:

    # MC "Let’s drink - to good health."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:110
translate chinese CR3_ES1_menu_28c97f7e:

    # Caroline "To good health? Haha! What age are you?! You’re talking like an old man!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:111
translate chinese CR3_ES1_menu_deda9636:

    # MC "It was the best I could think of!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:112
translate chinese CR3_ES1_menu_1d984b6f:

    # Caroline "Hehe... Fine! To good health!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:116
translate chinese CR3_ES1_menu_54f0cfd4:

    # "*GLUG GLUG*"
    ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:117
translate chinese CR3_ES1_menu_47158253:

    # MC "(Maybe I shouldn’t have chosen such a - vague, generic - thing, to drink to.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:125
translate chinese CR3_ES1_menu_439ff0b8:

    # MC "Let’s drink - in memory - of the great deal we had together."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:129
translate chinese CR3_ES1_menu_3040965c:

    # Caroline "P-Pardon?"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:130
translate chinese CR3_ES1_menu_d161d602:

    # MC "I said, we should drink - in memory - of the de-"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:131
translate chinese CR3_ES1_menu_9e42b0ff:

    # Caroline "I heard what you said - I just can’t believe you said it."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:135
translate chinese CR3_ES1_menu_f8171848:

    # Caroline "For fuck’s sake, [player_name]... Did you REALLY have to bring - that deal - up?"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:136
translate chinese CR3_ES1_menu_0ca2d796:

    # MC "I, uh... Sorry. Should we drink to something else..?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:137
translate chinese CR3_ES1_menu_b55a5ac7:

    # Caroline "Just forget it - and drink your damn beer..."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:141
translate chinese CR3_ES1_menu_eb06f909:

    # "*GLUG*"
    ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:143
translate chinese CR3_ES1_menu_4353d476:

    # MC "(Damn... Maybe bringing up the deal - wasn’t the best decision - I have ever made...)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:150
translate chinese CR3_ES1_menu_bcbec651:

    # MC "What have you got a towel for, there?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:151
translate chinese CR3_ES1_menu_b4ffe5fc:

    # Caroline "Huh? Oh! I wasn’t crying!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:152
translate chinese CR3_ES1_menu_7e4a556a:

    # MC "What? I never asked if you were crying..."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:156
translate chinese CR3_ES1_menu_ca506b1f:

    # Caroline "I... uh... Oops - I must have misheard you. What did you say?"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:157
translate chinese CR3_ES1_menu_edb4c810:

    # MC "I asked what the towel was for."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:158
translate chinese CR3_ES1_menu_db0ad6c1:

    # Caroline "Umm... Oh, I was using it to... get a grip on the bottles - to open them. They were difficult to unscrew."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:162
translate chinese CR3_ES1_menu_22cfaa49:

    # MC "(Weird... Her answer doesn’t make any sense. These AREN’T screw-top bottles.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:163
translate chinese CR3_ES1_menu_88fe278b:

    # MC "(What on earth - was she upset about enough, to cry over?)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:171
translate chinese CR3_ES1_menu_2ccf373e:

    # MC "You seem stressed. Is there anything I can help with?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:172
translate chinese CR3_ES1_menu_8f67d84d:

    # Caroline "Absolutely not... I’ll be fine, I can sort this all out myself. I just need to, take tonight, to clear my head and get my thoughts straight."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:173
translate chinese CR3_ES1_menu_3aa3b37d:

    # MC "Okay, but if you ever need me, you know I’m there, right?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:177
translate chinese CR3_ES1_menu_43839318:

    # Caroline "(I know you’re always there... but I can’t go to you, ever again. Not after what happened between us - with that fucking deal.)"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:178
translate chinese CR3_ES1_menu_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:186
translate chinese CR3_ES1_menu_ab6d4932:

    # MC "What’s got you feeling so down?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:187
translate chinese CR3_ES1_menu_e3db2679:

    # Caroline "(Damn, I was hoping he wouldn’t ask this. Now I’m gonna have to try and avoid his question.)"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:188
translate chinese CR3_ES1_menu_25d74639:

    # Caroline "Eh... Y’know - life in general."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:192
translate chinese CR3_ES1_menu_b9a52d5f:

    # Caroline "But don’t worry - I’m not depressed or anything. This is just a blip."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:193
translate chinese CR3_ES1_menu_4168e090:

    # MC "Are you sure? Is it about us?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:197
translate chinese CR3_ES1_menu_af3030f1:

    # Caroline "N-No! Absolutely not! It’s got nothing to do with - that damned deal!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:198
translate chinese CR3_ES1_menu_5ded970e:

    # MC "(Jesus, she can get VERY defensive - pretty damn fast!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:199
translate chinese CR3_ES1_menu_863845b5:

    # MC "O-Okay, no problem. If you ever want to talk - I’m there."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:207
translate chinese CR3_ES1_menu_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:208
translate chinese CR3_ES1_menu_45f33501:

    # Caroline "Yeah?"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:209
translate chinese CR3_ES1_menu_7e121aff:

    # MC "Why did you end our deal, so suddenly? What actually happened?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:213
translate chinese CR3_ES1_menu_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:214
translate chinese CR3_ES1_menu_99d617c0:

    # MC "It just seemed to come out of nowhere. I mean, one week things are going incredible, we’re both having fun, and then suddenly, the deal is dead."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:215
translate chinese CR3_ES1_menu_3d2f2c85:

    # MC "I mean, there was no warning or anything. I don’t understand. Did I do something wrong?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:219
translate chinese CR3_ES1_menu_102b9b2d:

    # Caroline "Jesus Christ, [player_name]! Will you - shut the fuck up - about that goddamned deal?!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:220
translate chinese CR3_ES1_menu_efa6144f:

    # Caroline "It wasn’t normal! And as far as I am concerned - it NEVER fucking happened!"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:221
translate chinese CR3_ES1_menu_f10c9048:

    # Caroline "Are we clear?"
    Caroline ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:222
translate chinese CR3_ES1_menu_70c23e4d:

    # MC "Y-Yeah... we’re clear."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:226
translate chinese CR3_ES1_menu_c2975567:

    # MC "(Holy shit! That’s a - raw nerve - if I’ve ever seen one!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:227
translate chinese CR3_ES1_menu_7916a432:

    # MC "(I’ve obviously done something wrong, but I don’t have the faintest idea what it is!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:228
translate chinese CR3_ES1_menu_54f0cfd4_1:

    # "*GLUG GLUG*"
    ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:236
translate chinese CR3_ES1_menu_d9baa652:

    # MC "Well, I guess I better go now. I’ll see you later, Caroline."
    MC ""

# game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:237
translate chinese CR3_ES1_menu_79140d40:

    # Caroline "Yeah... see you tomorrow."
    Caroline ""

translate chinese strings:

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:79
    old "How about we - drink to something?"
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:79
    old "What have you got a towel for, there?"
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:79
    old "You seem stressed. Is there anything I can help with?"
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:79
    old "What’s got you feeling so down?"
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:79
    old "Why did you end the deal so suddenly? What happened?"
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:86
    old "Let’s drink to - the success of your business!"
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:86
    old "Let’s drink - to good health."
    new ""

    # game/scripts/home/kitchen/evening/scenes/CR3_ES1.rpy:86
    old "Let’s drink in memory of the great deal we had together."
    new ""

