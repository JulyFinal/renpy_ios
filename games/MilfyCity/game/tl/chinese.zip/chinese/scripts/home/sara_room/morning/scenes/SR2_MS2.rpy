﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:17
translate chinese SR2_MS2_label_407c5ac6:

    # Mom "It’s no use lying to me, Sara. I saw the report card that you left lying on the kitchen table."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:18
translate chinese SR2_MS2_label_0bff4e90:

    # Sara "Wh-What?! You were READING my MAIL?!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:20
translate chinese SR2_MS2_label_a6ce413d:

    # MC "(Huh? It sounds like Mom and Sara are having an argument. I should check it out and see what’s going on.)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:22
translate chinese SR2_MS2_label_4b29f197:

    # MC "(Huh? It sounds like Linda and Sara are having an argument. I should check it out and see what’s going on.)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:30
translate chinese SR2_MS2_label_6ae7add9:

    # Mom "The whole reason I took you in as a tenant was because you were a straight A student. You got a safe, comfortable place to live, and I got peace of mind that your tuition grant would always come through."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:31
translate chinese SR2_MS2_label_55fd3b81:

    # Mom "Imagine my surprise to see a plethora of D’s, E’s, and even an F!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:33
translate chinese SR2_MS2_label_3a90a945:

    # Mom "I mean, seriously, if you don’t keep your grades up then you’re going to lose that tuition grant. When that happens, I stop getting paid rent."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:35
translate chinese SR2_MS2_label_b52b2f6e:

    # Mom "Listen, if you don't keep your grades up, you're going to lose your tuition grant. That means I'll stop getting paid rent from that, and I'll have to call your parents."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:37
translate chinese SR2_MS2_label_fff4817d:

    # Sara "Mom, I-"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:39
translate chinese SR2_MS2_label_f214af8c:

    # Sara "Linda, I-"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:43
translate chinese SR2_MS2_label_84281e54:

    # Mom "*Sigh* It goes beyond that too, Sara. You were a good student. I don’t want to see you throw your life away on some shitty job when you’re capable of so much more."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:44
translate chinese SR2_MS2_label_86f1c526:

    # Mom "You want to go to a good job, don’t you?"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:46
translate chinese SR2_MS2_label_ed2726bd:

    # Sara "Y-Yes, Mom."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:48
translate chinese SR2_MS2_label_95a56ffe:

    # Sara "Y-Yes, Linda."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:49
translate chinese SR2_MS2_label_19483786:

    # Mom "I am NOT going to have a tenant drop out of college and waste her life playing video games."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:52
translate chinese SR2_MS2_label_1107f280:

    # Mom "Perhaps you can offer me some kind of explanation for these utterly atrocious results?"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:53
translate chinese SR2_MS2_label_873238cb:

    # Sara "I... don’t know..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:54
translate chinese SR2_MS2_label_945a0b20:

    # Mom "How often have you been studying, these past few weeks?"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:55
translate chinese SR2_MS2_label_9934a4c6:

    # Sara "Same as alway-"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:56
translate chinese SR2_MS2_label_b72c066c:

    # Mom "Don’t lie to me, Sara!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:60
translate chinese SR2_MS2_label_625b9611:

    # Mom "I know what this is - you’ve been spending all your time playing that STUPID online game."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:63
translate chinese SR2_MS2_label_27d0b8fc:

    # Mom "Well, no more! As of moment, you this are GROUNDED."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:64
translate chinese SR2_MS2_label_f586a978:

    # Sara "Wh-What?!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:65
translate chinese SR2_MS2_label_8c9f0b21:

    # Mom "No computer games, no going out with friends, and no hanging out with your brother."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:67
translate chinese SR2_MS2_label_59bc6fe4:

    # Mom "No other luxuries. I'm only allowing you to stay in this room that you rent with your tuition grant - effective immediately!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:68
translate chinese SR2_MS2_label_06ea6848:

    # Sara "Wh-What?! You’re not serious?"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:69
translate chinese SR2_MS2_label_e73064be:

    # Mom "Serious!? I'M the one who pays the electricity bills. I'M the one who pays for our internet! No computer games, and hanging out with friends, or I'll call your parents and evict you. Focus on studying!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:70
translate chinese SR2_MS2_label_9d366a48:

    # Mom "You're eighteen! If you can't act like an adult, you won't be treated like an adult!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:75
translate chinese SR2_MS2_label_e91ab4c3:

    # Sara "*Sniff!*"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:77
translate chinese SR2_MS2_label_b116e9fe:

    # Mom "It’s no use crying, young lady. If you can’t be trusted to take care of your own education, then I’ll have to revoke your privileges."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:78
translate chinese SR2_MS2_label_2c92e979:

    # Mom "You are to remain in your bedroom and study. I’ll call you when it’s time for dinner. But after that, you will return to your room and study some more."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:80
translate chinese SR2_MS2_label_97703c51:

    # Mom "It’s no use crying, young lady. If you can’t be trusted to take care of your own education, then I’ll simply revoke some of the privileges that come with renting a room in my house. If you don’t like it, you can find somewhere else to rent."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:81
translate chinese SR2_MS2_label_270e088d:

    # Mom "I expect you to remain in your room and study. I’m not callous though. I’ll cook you dinner to give you some time to catch up on your work. This is tough love, Sara. I don’t want to see an intelligent young woman waste her life."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:82
translate chinese SR2_MS2_label_4c6b6a7d:

    # Sara "This isn’t fair! *Sob*"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:86
translate chinese SR2_MS2_label_9eb29cfb:

    # Mom "I don’t care if it takes you a week or ten weeks. You will be revising and resitting every single exam until you get, AT LEAST a B, in every single one."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:88
translate chinese SR2_MS2_label_36ca9661:

    # Mom "This is the way it has to be, Sara. I’m not having a failing student in my house. You will be revising and resitting every single exam until you get AT LEAST a B in every single one. That will secure you another year’s tuition grant."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:89
translate chinese SR2_MS2_label_76d1f577:

    # Mom "Is that clear?"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:90
translate chinese SR2_MS2_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:91
translate chinese SR2_MS2_label_51f5ffae:

    # Mom "I said, is that clear?!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:93
translate chinese SR2_MS2_label_fabfefb5:

    # Sara "*Sniff* Y-Yes, Mom."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:95
translate chinese SR2_MS2_label_1a45dfe1:

    # Sara "*Sniff* Y-Yes, Linda."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:96
translate chinese SR2_MS2_label_421b398b:

    # Mom "Let me be clear, if your grades do not improve I am going to be writing an email to your parents."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:99
translate chinese SR2_MS2_label_a858115b:

    # Mom "Oh, [player_name]! I didn’t see you standing there."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:100
translate chinese SR2_MS2_label_ebc8cb75:

    # MC "Is everything okay with Sara?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:101
translate chinese SR2_MS2_label_93b76bab:

    # Mom "She’ll be fine. She just chose to play video games, rather than study. She’s going to learn, a very valuable lesson, over the coming days."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:102
translate chinese SR2_MS2_label_5fb2ec7e:

    # MC "Maybe I could help her study?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:106
translate chinese SR2_MS2_label_0485c624:

    # Mom "Sorry, Sweetie. I know she really likes hanging out with you, but I can’t have her being distracted."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:108
translate chinese SR2_MS2_label_7eb4aaa7:

    # Mom "Until she gets, every subject back to AT LEAST a B, then she will be grounded to her room."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:110
translate chinese SR2_MS2_label_c371acd7:

    # Mom "Until she gets, every subject back to AT LEAST a B, I will treat her differently."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:111
translate chinese SR2_MS2_label_08bfe003:

    # MC "Can I go and talk with her, at least?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:112
translate chinese SR2_MS2_label_cbe37b46:

    # Mom "No, give her some space. You two can always chat at college."
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:114
translate chinese SR2_MS2_label_901685c0:

    # MC "(Gee... Mom’s being REALLY harsh on Sara, right now.)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:116
translate chinese SR2_MS2_label_603b9e9a:

    # MC "(Gee... Linda’s being REALLY harsh on Sara, right now.)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:117
translate chinese SR2_MS2_label_6cd74878:

    # MC "(Then again, Sara probably should have actually studied for her tests. She did bring most of this on herself.)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:146
translate chinese SR2_grounded_label_bfae111c:

    # MC "I can't go in. Mom asked me not to do it."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS2.rpy:148
translate chinese SR2_grounded_label_00d7a323:

    # MC "(Linda asked me to give her time to catch up at college. I shouldn't disturb her.)"
    MC ""

