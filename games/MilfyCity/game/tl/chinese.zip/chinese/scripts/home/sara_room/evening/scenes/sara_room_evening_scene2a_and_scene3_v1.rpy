﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:29
translate chinese SR1_E_inroom_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:46
translate chinese sis_nerdy_evening_scene2a_v1_label_a646901d:

    # Sara "Not now, [player_name]."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:54
translate chinese sis_nerdy_evening_scene2a_v1_label_8a56e2bb:

    # MC "Hi Sara, are you-"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:55
translate chinese sis_nerdy_evening_scene2a_v1_label_6b822454:

    # Sara "Oh hey! Just let me pause this."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:58
translate chinese sis_nerdy_evening_scene2a_v1_label_a5b5b942:

    # Sara "Are you looking for a rematch?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:59
translate chinese sis_nerdy_evening_scene2a_v1_label_2b786416:

    # Sara "Whaddya say? Same rules? Each time you die you lose a piece of clothing?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:60
translate chinese sis_nerdy_evening_scene2a_v1_label_6e9c1aa8:

    # MC "(If I accept, she’ll just kick my ass again... I need to find a way to guarantee that I win.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:61
translate chinese sis_nerdy_evening_scene2a_v1_label_718431ee:

    # MC "Nah, not today. Enjoy the rest of your match!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:64
translate chinese sis_nerdy_evening_scene2a_v1_label_3719c2bc:

    # Sara "Your loss! See ya later!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:82
translate chinese sis_nerdy_evening_scene2a_v1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:87
translate chinese sis_nerdy_evening_scene2a_v1_label_f0d5a635:

    # Sara "I said flank left! That’s the right flank, you dumbos!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:88
translate chinese sis_nerdy_evening_scene2a_v1_label_50a8fab3:

    # MC "(Wow, looks like Sara’s teammates aren’t up to scratch today!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:89
translate chinese sis_nerdy_evening_scene2a_v1_label_21d8d926:

    # Sara "Grr! We lost the match because of you guys! I’m off now. Chat later!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:92
translate chinese sis_nerdy_evening_scene2a_v1_label_2bdc730f:

    # Sara "Oh! Hey, [player_name]! Didn’t see you standing there. Do you fancy a rematch?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:93
translate chinese sis_nerdy_evening_scene2a_v1_label_3f09a547:

    # MC "(I’ve swapped the working controller for the cheap Chinese knock-off version! This should give me the edge I need to beat her!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:94
translate chinese sis_nerdy_evening_scene2a_v1_label_04d49041:

    # MC "Yeah, I’m ready whenever you are!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:97
translate chinese sis_nerdy_evening_scene2a_v1_label_7b300e92:

    # Sara "Sweet! Let me get it set up here."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:98
translate chinese sis_nerdy_evening_scene2a_v1_label_5085d648:

    # Sara "Do you want to play Street Brawler VII again? Or something else this time?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:99
translate chinese sis_nerdy_evening_scene2a_v1_label_24ad7585:

    # MC "Street Brawler works for me."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:100
translate chinese sis_nerdy_evening_scene2a_v1_label_5b8cc442:

    # Sara "Coolio!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:104
translate chinese sis_nerdy_evening_scene2a_v1_label_c6f291a3:

    # Sara "Hehe - you do know you’re gonna lose again, right?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:105
translate chinese sis_nerdy_evening_scene2a_v1_label_7519fdac:

    # MC "Perhaps."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:106
translate chinese sis_nerdy_evening_scene2a_v1_label_a7d8903f:

    # Sara "And you know the penalty for losing?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:107
translate chinese sis_nerdy_evening_scene2a_v1_label_aad7d578:

    # MC "I lose a piece of clothing."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:108
translate chinese sis_nerdy_evening_scene2a_v1_label_4bafe4d0:

    # Sara "Yup! Now let’s get started!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:113
translate chinese sis_nerdy_evening_scene2a_v1_label_23988fd5:

    # "(Three Minutes Later...)"
    ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:116
translate chinese sis_nerdy_evening_scene2a_v1_label_b20a4d5e:

    # Console "FATALITY!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:118
translate chinese sis_nerdy_evening_scene2a_v1_label_c85d189a:

    # Sara "Wh-What?! N-No way!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:119
translate chinese sis_nerdy_evening_scene2a_v1_label_a7d763b6:

    # MC "That’s one-nil, Sara! Time to lose a piece of clothing."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:122
translate chinese sis_nerdy_evening_scene2a_v1_label_0b574aa5:

    # Sara "B-But I’m n-not wearing a bra..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:123
translate chinese sis_nerdy_evening_scene2a_v1_label_a147add3:

    # MC "Then lose your denim shorts."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:124
translate chinese sis_nerdy_evening_scene2a_v1_label_2d05ade3:

    # Sara "I... I’m not w-wearing any... *ahem* either..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:125
translate chinese sis_nerdy_evening_scene2a_v1_label_e42b0e1c:

    # MC "You’re not wearing ANY underwear?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:126
translate chinese sis_nerdy_evening_scene2a_v1_label_c42736de:

    # Sara "Look away while I take my top off..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:129
translate chinese sis_nerdy_evening_scene2a_v1_label_438e3446:

    # MC "Fine."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:136
translate chinese sis_nerdy_evening_scene2a_v1_label_2ae1630e:

    # MC "(Holy shit! She’s so fucking hot!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:137
translate chinese sis_nerdy_evening_scene2a_v1_label_49b832c4:

    # Sara "(I can’t believe this... it’s so embarrassing!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:138
translate chinese sis_nerdy_evening_scene2a_v1_label_9191e321:

    # Sara "(Why didn’t I wear any underwear?! I was sooo confident that I was going to win again!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:139
translate chinese sis_nerdy_evening_scene2a_v1_label_dd9f3735:

    # MC "(Hehe - this broken controller is working like a charm! She doesn’t know what the hell is going on!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:145
translate chinese sis_nerdy_evening_scene2a_v1_label_2827d6d4:

    # MC "Fine, I won’t look."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:146
translate chinese sis_nerdy_evening_scene2a_v1_label_328ccbad:

    # Sara "Thank you..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:147
translate chinese sis_nerdy_evening_scene2a_v1_label_32d75f56:

    # MC "Are you done yet?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:148
translate chinese sis_nerdy_evening_scene2a_v1_label_614b8908:

    # Sara "Almost..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:154
translate chinese after_choice_sis_nerdy_evening_scene3_88fd38b5:

    # MC "(Her nipples are pretty stiff! She must be secretly enjoying this!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:155
translate chinese after_choice_sis_nerdy_evening_scene3_5d7a791e:

    # Console "ROUND 2! FIGHT!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:156
translate chinese after_choice_sis_nerdy_evening_scene3_eaea29be:

    # Sara "I’m gonna beat your ass this time!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:157
translate chinese after_choice_sis_nerdy_evening_scene3_b6dbd51b:

    # MC "Oh yeah? Do you really think so?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:158
translate chinese after_choice_sis_nerdy_evening_scene3_f71d40d4:

    # Sara "Dammit! I pressed X three times! Why didn’t it work?!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:159
translate chinese after_choice_sis_nerdy_evening_scene3_a0eb5595:

    # Console "C-C-COMBO BREAKER!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:162
translate chinese after_choice_sis_nerdy_evening_scene3_b6d8ff64:

    # Console "FATALITY! PLAYER 2 WINS AGAIN!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:163
translate chinese after_choice_sis_nerdy_evening_scene3_c6ee1b72:

    # Sara "NOOOOOOO!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:164
translate chinese after_choice_sis_nerdy_evening_scene3_d4e07eca:

    # MC "Yesss!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:165
translate chinese after_choice_sis_nerdy_evening_scene3_1088fe48:

    # Sara "N-No way! This c-can’t be happening!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:166
translate chinese after_choice_sis_nerdy_evening_scene3_5e74c6ee:

    # MC "You know the rules, Sara! Time to lose those denim shorts!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:167
translate chinese after_choice_sis_nerdy_evening_scene3_0c35ce1b:

    # MC "Or... you could just lose your shoes."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:170
translate chinese after_choice_sis_nerdy_evening_scene3_8bb0bafd:

    # MC "Actually! Let’s make a deal - one more round. Sudden death rules."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:171
translate chinese after_choice_sis_nerdy_evening_scene3_b51d1f81:

    # Sara "What do you mean?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:172
translate chinese after_choice_sis_nerdy_evening_scene3_39043f55:

    # MC "If you win, I take off EVERYTHING. If I win though... then you have to strip completely naked for me."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:173
translate chinese after_choice_sis_nerdy_evening_scene3_db6c1ccd:

    # MC "Deal?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:174
translate chinese after_choice_sis_nerdy_evening_scene3_b909d4fa:

    # Sara "... Deal."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:178
translate chinese after_choice_sis_nerdy_evening_scene3_9cc3d059:

    # "(Thirty seconds later...)"
    ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:183
translate chinese after_choice_sis_nerdy_evening_scene3_8a299e11:

    # Sara "AAAAAAHHHHHHH!!!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:184
translate chinese after_choice_sis_nerdy_evening_scene3_b6edd993:

    # Sara "(WHAT’S HAPPENING?! Why aren’t I good at video games anymore?!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:185
translate chinese after_choice_sis_nerdy_evening_scene3_98c1dc9e:

    # MC "You lost the deal, Sara. Time to strip off!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:188
translate chinese after_choice_sis_nerdy_evening_scene3_c9b0822c:

    # Sara "Ugh... Fine. I’ll do it on the bed."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:189
translate chinese after_choice_sis_nerdy_evening_scene3_7da89808:

    # Sara "N-No photos though!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:190
translate chinese after_choice_sis_nerdy_evening_scene3_860a84c7:

    # MC "That’s a bit hypocritical of you!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:191
translate chinese after_choice_sis_nerdy_evening_scene3_44eabcf0:

    # Sara "I... I don’t have that picture anymore. I... um... deleted it!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:192
translate chinese after_choice_sis_nerdy_evening_scene3_13ad020f:

    # MC "(She’s lying... She definitely still has that picture of my dick!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:195
translate chinese after_choice_sis_nerdy_evening_scene3_df7ad3d5:

    # MC "Fine, no photos. But I still want to see your whole body."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:196
translate chinese after_choice_sis_nerdy_evening_scene3_13fa39d0:

    # Sara "*Gulp* S-Sure."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:197
translate chinese after_choice_sis_nerdy_evening_scene3_17e2be64:

    # Sara "(I can’t believe I lost... I thought this would just be an easy way to see [player_name]’s cock again.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:198
translate chinese after_choice_sis_nerdy_evening_scene3_9b8971f0:

    # Sara "(God... what am I going to tell Lily if she asks what happend?!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:201
translate chinese after_choice_sis_nerdy_evening_scene3_99aac29f:

    # MC "(Wow! There’s her pussy! I can see the hood of her clitoris, poking out the top.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:202
translate chinese after_choice_sis_nerdy_evening_scene3_aa5a04b3:

    # MC "(She wasn’t lying when she said she wasn’t wearing any panties. Was she seriously THAT confident that she was going to win?! Haha!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:203
translate chinese after_choice_sis_nerdy_evening_scene3_da3ae82c:

    # Sara "W-Well? I-Is this enough?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:206
translate chinese after_choice_sis_nerdy_evening_scene3_86ccc17a:

    # MC "We did agree, completely naked - but this is a rather sexy view."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:207
translate chinese after_choice_sis_nerdy_evening_scene3_7d569a3f:

    # Sara "S-Sexy?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:208
translate chinese after_choice_sis_nerdy_evening_scene3_61bf95b5:

    # MC "I’m just teasing you."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:211
translate chinese after_choice_sis_nerdy_evening_scene3_fba1a468:

    # Sara "W-Wait - You can’t just s-say something like that and walk away..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:212
translate chinese after_choice_sis_nerdy_evening_scene3_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:213
translate chinese after_choice_sis_nerdy_evening_scene3_22fdb367:

    # Sara "D... Do... you think I’m pretty?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:216
translate chinese after_choice_sis_nerdy_evening_scene3_9509f862:

    # MC "Of course you’re pretty. I’d hardly be playing strip challenge games with you if you weren’t!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:217
translate chinese after_choice_sis_nerdy_evening_scene3_c8382607:

    # Sara "I... I guess..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:218
translate chinese after_choice_sis_nerdy_evening_scene3_3fb43207:

    # MC "Anyway, I’ll let you get dressed again. See you later, Sara."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:219
translate chinese after_choice_sis_nerdy_evening_scene3_3f5c0f9a:

    # MC "And for the record, you are very pretty."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:220
translate chinese after_choice_sis_nerdy_evening_scene3_0007fa15:

    # Sara "Th... Thank you..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:243
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_c7735688:

    # MC "(I can't do it while she's around.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:248
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_aca37dae:

    # MC "(That’s her controller. What should I do with it to win next time?)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:259
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_can_f0c25f85:

    # MC "(Gamepad changed.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:265
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_can_aca37dae:

    # MC "(That’s her controller. What should I do with it to win next time?)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:271
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_can_f0c25f85_1:

    # MC "(Gamepad changed.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:277
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_can_aca37dae_1:

    # MC "(That’s her controller. What should I do with it to win next time?)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:284
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_can_f0c25f85_2:

    # MC "(Gamepad changed.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene2a_and_scene3_v1.rpy:290
translate chinese sis_nerdy_evening_gamepad_change_scene3_v1_label_can_aca37dae_2:

    # MC "(That’s her controller. What should I do with it to win next time?)"
    MC ""

