﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/corridor/night/scenes/caroline_room_locked.rpy:6
translate chinese caroline_room_locked_label_c9399a43:

    # MC "(It’s locked... I think she has a spare key somewhere!)"
    MC ""

# game/scripts/home/corridor/night/scenes/caroline_room_locked.rpy:11
translate chinese caroline_room_locked_label_c9399a43_1:

    # MC "(It’s locked... I think she has a spare key somewhere!)"
    MC ""

# game/scripts/home/corridor/night/scenes/caroline_room_locked.rpy:14
translate chinese caroline_room_locked_label_1db4e7a0:

    # MC "(It’s locked just as before! As far as I remember, she should have her spare key in the shop!)"
    MC ""

