﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:25
translate chinese SR2_NS1_label_de383f73:

    # Sara "I hope you didn’t forget that I was coming to visit you tonight."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:26
translate chinese SR2_NS1_label_bee58f78:

    # MC "Of course not, Sara!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:27
translate chinese SR2_NS1_label_64fad7ae:

    # Sara "Hehe... I’m just teasing you."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:28
translate chinese SR2_NS1_label_c1cf27d8:

    # MC "What’s up?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:32
translate chinese SR2_NS1_label_c66fe668:

    # Sara "Actually... it’s a little... difficult to talk about."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:33
translate chinese SR2_NS1_label_43e0990a:

    # MC "Is something wrong?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:34
translate chinese SR2_NS1_label_259ecc92:

    # Sara "No! At least... I don’t think so. I hope not."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:36
translate chinese SR2_NS1_label_f82372b5:

    # Sara "Can you climb under the sheets with me? I REALLY don’t want Mom or Dad to overhear us."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:38
translate chinese SR2_NS1_label_87dfc818:

    # Sara "Can you climb under the sheets with me? I REALLY don’t want anyone overhearing us."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:39
translate chinese SR2_NS1_label_a2978dac:

    # MC "Sure, no problem."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:43
translate chinese SR2_NS1_label_62344bdd:

    # MC "What did you want to say?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:44
translate chinese SR2_NS1_label_a1d94f70:

    # Sara "It’s... I don’t know why it’s so difficult. I KNOW what I want to say, but I can’t make myself say the words."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:45
translate chinese SR2_NS1_label_b5fbd566:

    # Sara "Do you understand what I mean?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:49
translate chinese SR2_NS1_label_72821c66:

    # MC "I... I think so?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:50
translate chinese SR2_NS1_label_b4b745e5:

    # Sara "[player_name], we’ve done... stuff together. Like that time I gave you a blowjob."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:51
translate chinese SR2_NS1_label_b3f51fa1:

    # MC "Or that time we played strip videogaming?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:52
translate chinese SR2_NS1_label_a183e3e7:

    # Sara "That too..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:56
translate chinese SR2_NS1_label_c902c055:

    # Sara "And then you told me that you lik-... ...loved me..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:57
translate chinese SR2_NS1_label_dad06ba9:

    # Sara "I need to know... Am I your girlfriend now?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:58
translate chinese SR2_NS1_label_ecb33f85:

    # MC "(It sounds like she wants me to commit myself to her. If I’m fooling around with any other women - this could POTENTIALLY make things awkward...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:65
translate chinese SR2_NS1_label_25d6b2c2:

    # MC "I’ll tell you what, Sara. How about we commemorate the day you become my girlfriend with something special?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:66
translate chinese SR2_NS1_label_0dcb9374:

    # Sara "Wh-What do you mean?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:67
translate chinese SR2_NS1_label_ff84762c:

    # MC "I was thinking that you become my girlfriend the first time we have sex."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:71
translate chinese SR2_NS1_label_a65ba616:

    # Sara "S-Sex?!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:72
translate chinese SR2_NS1_label_68840842:

    # MC "(She looks pretty shocked by my suggestion.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:73
translate chinese SR2_NS1_label_fc30ea4a:

    # MC "Are you alright, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:77
translate chinese SR2_NS1_label_8955beee:

    # Sara "Y-Yeah, I’m fine. You just took me by surprise."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:78
translate chinese SR2_NS1_label_03a66d93:

    # MC "Sorry, my bad."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:79
translate chinese SR2_NS1_label_3ec5d566:

    # Sara "No, it’s not your fault. I just... I don’t think I’m ready to actually have sex yet."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:80
translate chinese SR2_NS1_label_82ad7208:

    # MC "Honestly, don’t worry about it, Sara. We can take our time."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:84
translate chinese SR2_NS1_label_8d8dd8c7:

    # Sara "Really?! Thank you so much, [player_name]."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:85
translate chinese SR2_NS1_label_26255b9a:

    # Sara "I DO want to do it with you... someday. I just need a little more time right now."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:86
translate chinese SR2_NS1_label_10b70b2b:

    # Sara "Maybe we could do some other stuff together, in the meantime?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:87
translate chinese SR2_NS1_label_a59f24a9:

    # MC "Sure. Whatever you’re comfortable with, Sara."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:88
translate chinese SR2_NS1_label_d34aa34d:

    # Sara "Thanks, [player_name]. You’re the best."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:94
translate chinese SR2_NS1_label_07701509:

    # MC "Can I give you an answer later? It feels like everything is happening really fast right now."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:95
translate chinese SR2_NS1_label_178068c4:

    # Sara "Oh..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:96
translate chinese SR2_NS1_label_b8bc7e67:

    # MC "I’m not saying 'no'. I just need some time to think about everything."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:100
translate chinese SR2_NS1_label_b4f53e43:

    # Sara "I was kinda hoping you’d say ‘yes’."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:101
translate chinese SR2_NS1_label_3f328dc6:

    # MC "Someday, Sara. Just... not right now. I need more time."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:102
translate chinese SR2_NS1_label_f3c93a7b:

    # Sara "Hmmph...."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:106
translate chinese SR2_NS1_label_e3f4a997:

    # MC "Aww, c’mon Sara. Don’t be like that!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:107
translate chinese SR2_NS1_label_8679ffc6:

    # MC "How would you feel, if I started pressuring you to have sex before you were ready? You’d feel stressed, right?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:111
translate chinese SR2_NS1_label_343f7e68:

    # Sara "Huh... I guess so."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:112
translate chinese SR2_NS1_label_47ddcbbc:

    # MC "Well, calling you my girlfriend before I’m ready, is kinda the same thing. I’d love to call you my other half, but I’m only gonna do it when I’m feeling truly ready."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:113
translate chinese SR2_NS1_label_8f062d6e:

    # MC "Do you understand?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:114
translate chinese SR2_NS1_label_5cf941bc:

    # Sara "Yeah, I guess so. I’m sorry, [player_name]."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:118
translate chinese SR2_NS1_label_b9302218:

    # MC "You don’t need to apologise, Sara. I really do love you."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:119
translate chinese SR2_NS1_label_16bededc:

    # Sara "I know."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:123
translate chinese SR2_NS1_label_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:124
translate chinese SR2_NS1_label_ecaf114b:

    # Sara "(Oh, my God! I just melt, every time he kisses me.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:130
translate chinese SR2_NS1_label_5028011a:

    # MC "Of course, Sara. I’d love to call you my girlfriend."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:131
translate chinese SR2_NS1_label_c1d4ab17:

    # Sara "Really?!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:132
translate chinese SR2_NS1_label_a47ac9dc:

    # MC "There’s just one little issue... We’re not actually doing what couples do."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:136
translate chinese SR2_NS1_label_4766bfbb:

    # Sara "Wh-What’s wrong? I don’t understand."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:137
translate chinese SR2_NS1_label_6d875173:

    # MC "Sara, we still haven’t had sex together. Sure, we’ve done some little things here and there, but we haven’t even come close to actually fucking each other."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:141
translate chinese SR2_NS1_label_178068c4_1:

    # Sara "Oh..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:142
translate chinese SR2_NS1_label_c48002e5:

    # Sara "I don’t... I don’t think I’m ready to do... that kinda stuff yet."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:146
translate chinese SR2_NS1_label_368d5ef1:

    # MC "Don’t worry, Sara. Take your time."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:147
translate chinese SR2_NS1_label_46518d8d:

    # MC "We can discuss this again, whenever some more time has past. I don’t want you being pressured into something you’re not entirely comfortable with."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:148
translate chinese SR2_NS1_label_4ce67672:

    # MC "Don’t forget, that I really DO love you."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:152
translate chinese SR2_NS1_label_7f0c53e5_1:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:159
translate chinese SR2_NS1_continue_bb30e2de:

    # Sara "Well... maybe we could try some other things, to help us build up towards sex?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:160
translate chinese SR2_NS1_continue_92ff129f:

    # MC "Sounds good to me. What are you thinking?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:161
translate chinese SR2_NS1_continue_07a3ee55:

    # Sara "I honestly don't know... Me... You... It's progressing very fast... Maybe tell me your idea? Okay?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:165
translate chinese SR2_NS1_continue_6431d539:

    # MC "That’s okay. Let me think... Hmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:166
translate chinese SR2_NS1_continue_0ed7be51:

    # MC "How about I get you a vibrator? You can use it and think of me and also gain some confidence with your own body."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:167
translate chinese SR2_NS1_continue_6623cd6e:

    # Sara "Umm... Well... Sur... Sorry, I’m a little nervous."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:168
translate chinese SR2_NS1_continue_a6f765ea:

    # MC "That's okay. I'll tell you what - I'll go and buy you one. You can just keep it in your room. I'll also not be mad if you use it and think of someone..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:172
translate chinese SR2_NS1_continue_9a121dd1:

    # Sara "Yeah... That doesn’t sound too bad!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:173
translate chinese SR2_NS1_continue_208d5928:

    # Sara "Swing by college after you buy it. I'll finish my studies earlier that day and will come to your bedroom again to collect it."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:174
translate chinese SR2_NS1_continue_23ed3d43:

    # MC "No problem, Sara. I’ll let you know."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:175
translate chinese SR2_NS1_continue_d9a17d0f:

    # Sara "Okay, I better get back to bed now. I’ll see you later, [player_name]. Goodnight!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:176
translate chinese SR2_NS1_continue_0fda9f58:

    # MC "Sweet dreams, Sara."
    MC ""

translate chinese strings:

    # game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:61
    old "You’ll become my girlfriend after we have sex."
    new ""

    # game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:61
    old "Can I answer later? Everything is happening very fast right now."
    new ""

    # game/scripts/home/mc_room/night/scenes/SR2_NS1.rpy:61
    old "Yes, but... we’re still not doing what couples do."
    new ""

