﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:18
translate chinese scene1_v1_8d5599a7:

    # MC "(Sara’s engrossed in one of her video games again!)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:19
translate chinese scene1_v1_68c42c68:

    # MC "(If she doesn’t hurry up and get ready, she’s gonna be late for her first lecture.)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:20
translate chinese scene1_v1_c421843f:

    # MC "Hey, are you almost ready to go?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:24
translate chinese scene1_v1_8feb1a45:

    # MC "(Huh, I don’t think she heard me, with the headphones on.)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:25
translate chinese scene1_v1_8d75f99e:

    # MC "Hey! Sara!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:26
translate chinese scene1_v1_d3f1f2dd:

    # Sara "Huh?! Oh! Hey, [player_name]!"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:27
translate chinese scene1_v1_85cd05cd:

    # MC "You’re shouting!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:28
translate chinese scene1_v1_d30cef7b:

    # Sara "What’s up?"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:29
translate chinese scene1_v1_00329929:

    # MC "We need to leave for college in five minutes!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:32
translate chinese scene1_v1_59d7d5fd:

    # Sara "It’s okay, I’ll be done in like... a couple of minutes."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:33
translate chinese scene1_v1_5451e7e6:

    # MC "We both know that’s not true."
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:34
translate chinese scene1_v1_df6c8c04:

    # MC "I can CLEARLY see, you’ve only just started the round!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:38
translate chinese scene1_v1_d2bd76e3:

    # Sara "Aww, c’mon [player_name]! You’re not my Dad! Hehe!"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:40
translate chinese scene1_v1_427689fc:

    # Sara "Aww, c’mon [player_name]! You’re not Bob! Hehe!"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:41
translate chinese scene1_v1_133675db:

    # Sara "Why do you care if I’m a little bit late to college? I’m almost top of the class, anyway."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:42
translate chinese scene1_v1_c363e785:

    # MC "Almost top? Weren’t you THE top, two years ago? You’re slipping, Sara."
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:45
translate chinese scene1_v1_96e846f6:

    # Sara "Grr... Fine! I’ll log off."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:46
translate chinese scene1_v1_bde51a34:

    # Sara "Say... About Ms. Celia, the other day..."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:49
translate chinese scene1_v1_02dec4ab:

    # MC "I’d rather not talk about it."
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:50
translate chinese scene1_v1_5bca799e:

    # Sara "Oh... sorry. I understand."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:51
translate chinese scene1_v1_8b0bceea:

    # MC "Nah, you don’t need to apologise. You were right - I should have listened to your advice."
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:52
translate chinese scene1_v1_c3ab6f55:

    # MC "I’ll try to do that more in future, I promise."
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:55
translate chinese scene1_v1_a0dab638:

    # Sara "Want to walk to college together?"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:56
translate chinese scene1_v1_7a6fba63:

    # MC "You’ll need to hurry your ass up! I’ve been ready to leave for the past ten minutes!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:72
translate chinese after_sis_nerdy_scene1_v1_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:85
translate chinese next_day_after_sis_nerdy_scene1_v1_deeb4e27:

    # MC "*Sigh* (Computer games again?!)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:86
translate chinese next_day_after_sis_nerdy_scene1_v1_72fed5c2:

    # MC "(Her grades are going to keep dipping if she doesn’t apply herself.)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:87
translate chinese next_day_after_sis_nerdy_scene1_v1_6eccd838:

    # MC "(And even if she does get good grades, what kind of employer is going to want a lazy worker who’s always late?)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:90
translate chinese next_day_after_sis_nerdy_scene1_v1_c8f56395:

    # MC "Sara! You’re going to be late AGAIN!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:91
translate chinese next_day_after_sis_nerdy_scene1_v1_475e6ab3:

    # Sara "Just... five more minutes. I’ve almost earned my daily loot crate!"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:92
translate chinese next_day_after_sis_nerdy_scene1_v1_9e98db7d:

    # MC "Can you not do this when you get home, after college?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:93
translate chinese next_day_after_sis_nerdy_scene1_v1_b3fd3a18:

    # Sara "Umm..."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:96
translate chinese next_day_after_sis_nerdy_scene1_v1_3db16035:

    # Sara "But if I don’t open the loot crate now, I’ll be wondering what’s in it ALL DAY!"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:97
translate chinese next_day_after_sis_nerdy_scene1_v1_ad2d5c69:

    # Sara "I’m going to be so distracted that I’ll not learn anything! So I REALLY need to get this out of the way BEFORE I go to college. Right?"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:98
translate chinese next_day_after_sis_nerdy_scene1_v1_0515afc2:

    # MC "That’s... a terrible excuse. You know that?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:99
translate chinese next_day_after_sis_nerdy_scene1_v1_da9173b2:

    # Sara "Hehe, yeah..."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:109
translate chinese scene1_v1q1_c5628875:

    # MC "Have you at least done your coursework?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:110
translate chinese scene1_v1q1_67bb2f58:

    # Sara "Yeah! Most of it..."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:111
translate chinese scene1_v1q1_fd4230f8:

    # MC "What do you mean, most of it?!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:112
translate chinese scene1_v1q1_d7a4c261:

    # Sara "Relax! I can finish it off in the library, over lunch."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:118
translate chinese scene1_v1q1_11d16c42:

    # MC "What time did you go to bed last night?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:119
translate chinese scene1_v1q1_864ddd32:

    # Sara "Umm... Let’s see... I did three matches... then two more capture the flag games..."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:120
translate chinese scene1_v1q1_b9dfa534:

    # Sara "Uhh... Maybe... 2AM?"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:121
translate chinese scene1_v1q1_e5b1b1e0:

    # MC "2AM?! On a college night?!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:122
translate chinese scene1_v1q1_46f7da6b:

    # Sara "Hehe, yeah. I’m a little tired..."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:123
translate chinese scene1_v1q1_910b8272:

    # MC "(She really needs to go to bed earlier.)"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:129
translate chinese scene1_v1q1_418c8a12:

    # MC "Are you up to anything exciting today?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:130
translate chinese scene1_v1q1_5b324c37:

    # Sara "No, nothing interesting planned. I’ll probably just be hanging out with Lily."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:131
translate chinese scene1_v1q1_512470db:

    # Sara "How about you?"
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:132
translate chinese scene1_v1q1_b07d31b8:

    # MC "Aside from slowly trying to regain some self-esteem and get my life back on track?"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:133
translate chinese scene1_v1q1_f3e00219:

    # Sara "You’re overdramatic."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:134
translate chinese scene1_v1q1_336e53a3:

    # MC "It’s melodramatic actually."
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:135
translate chinese scene1_v1q1_19abbd88:

    # Sara "Really? Geez... maybe I shouldn’t be skipping English Literature."
    Sara ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:136
translate chinese scene1_v1q1_6125a53e:

    # MC "You’re skipping literature?!"
    MC ""

# game/scripts/home/sara_room/morning/scene1(v1)label.rpy:146
translate chinese after_scene1_v1q1_76118716:

    # Sara " Oops! Look at the time - I better get dressed quickly! I’m gonna be late!"
    Sara ""

translate chinese strings:

    # game/scripts/home/sara_room/morning/scene1(v1)label.rpy:106
    old "Have you done your coursework?"
    new ""

    # game/scripts/home/sara_room/morning/scene1(v1)label.rpy:106
    old "What time did you go to bed at last night?"
    new ""

    # game/scripts/home/sara_room/morning/scene1(v1)label.rpy:106
    old "{color=#00ff00}Up to anything exciting today?{/color}"
    new ""

