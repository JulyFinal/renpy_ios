﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:14
translate chinese CR2_NS3_label_52398625:

    # MC "Gosh.. (She was still drinking, even after that SMS. I see she really needed to clear her mind completely.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:15
translate chinese CR2_NS3_label_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:16
translate chinese CR2_NS3_label_201d3062:

    # MC "(Huh? Is she awake?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:18
translate chinese CR2_NS3_label_d41d3543:

    # Caroline "Mhmm... W-wh-... [player_name].. "
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:19
translate chinese CR2_NS3_label_dfc0474f:

    # MC "(My name? Is she talking in her sleep?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:20
translate chinese CR2_NS3_label_3c9a0f84:

    # MC "Gulp (I can see her nipple.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:21
translate chinese CR2_NS3_label_cb24bba8:

    # Caroline "You..-re... swe... best..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:22
translate chinese CR2_NS3_label_4ac0ac64:

    # MC "(I don't understand a thing... I only hope she’s having a nice dream with me.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR2_NS3.rpy:32
translate chinese CR2_NS3_label_758191e1:

    # MC "She's drunk. There's no point in waking her up."
    MC ""

