﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:13
translate chinese CR2_MS3a_label_eaa4b237:

    # MC "What’s up? You’re looking glum again."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:14
translate chinese CR2_MS3a_label_b311fc45:

    # Caroline "Things aren’t... I’m sorry, I should go."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:15
translate chinese CR2_MS3a_label_2c491e96:

    # MC "Wait- what’s wrong?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:19
translate chinese CR2_MS3a_label_2d6c9507:

    # Caroline "Things aren’t picking up at the shop as quickly as I originally thought they would."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:20
translate chinese CR2_MS3a_label_53eb3bd4:

    # MC "Oh no... Is everything okay?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:21
translate chinese CR2_MS3a_label_66893900:

    # Caroline "N-Not really... I owe a hundred and fifty in rent, for the shop this time."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:22
translate chinese CR2_MS3a_label_752041bc:

    # Caroline "I was wondering if..."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:26
translate chinese CR2_MS3a_label_fe9a2cfe:

    # MC "You were wondering if you could borrow it from me?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:27
translate chinese CR2_MS3a_label_724b4c26:

    # Caroline "I’m so sorry, [player_name]. I don’t want to be a burden."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:37
translate chinese CR2_MS3a_label_d641df52:

    # MC "It was a hundred and fifty dollars, right?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:38
translate chinese CR2_MS3a_label_0b5bdef2:

    # Caroline "Yeah."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:39
translate chinese CR2_MS3a_label_69719ff6:

    # MC "Luckily for you, I have that right here."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:40
translate chinese CR2_MS3a_label_1e99462b:

    # Caroline "R-Really?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:44
translate chinese CR2_MS3a_label_51b1bec8:

    # Caroline "Are you sure I can just have this?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:46
translate chinese CR2_MS3a_label_fcad106c:

    # MC "Absolutely! I said it last time, and I’ll say it again - you’re my sister. We have to take care of each other."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:48
translate chinese CR2_MS3a_label_8ad81560:

    # MC "Absolutely! I said it last time, and I’ll say it again - you’re my friend. We need to look out for each other."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:49
translate chinese CR2_MS3a_label_e0fba72c:

    # Caroline "Thank you so much!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:53
translate chinese CR2_MS3a_label_2ead2ec5:

    # Caroline "I never knew you cared about me this much. It’s really sweet of you to do this."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:54
translate chinese CR2_MS3a_label_eeef75b4:

    # MC "Please, don’t think anything of it."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:58
translate chinese CR2_MS3a_label_09148675:

    # Caroline "I’m a really lucky girl. You know that?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:59
translate chinese CR2_MS3a_label_ee801444:

    # Caroline "*Mwah!*"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:60
translate chinese CR2_MS3a_label_d5b240a6:

    # MC "(She actually kissed me! Caroline hasn’t done that in... never!)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:64
translate chinese CR2_MS3a_label_7872cb78:

    # Caroline "Actually, before I go... just one quick question."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:65
translate chinese CR2_MS3a_label_0654b1f3:

    # MC "Yes?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:66
translate chinese CR2_MS3a_label_b83610d9:

    # Caroline "Are you giving me this money because..."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:67
translate chinese CR2_MS3a_label_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:71
translate chinese CR2_MS3a_label_081be285:

    # MC "Because what, Caroline?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:72
translate chinese CR2_MS3a_label_1d9314ba:

    # Caroline "Nevermind. Meet me outside the front of our house, and we can talk about it."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:73
translate chinese CR2_MS3a_label_ac9b84d6:

    # MC "Okay, I’ll see you there."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:74
translate chinese CR2_MS3a_label_87d023ca:

    # Caroline "Thanks again, [player_name]."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:91
translate chinese CR2_MS3a_label_0f2d8d8d:

    # MC "I’m so sorry, Caroline. I don’t have that kinda money right now."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:92
translate chinese CR2_MS3a_label_690ceca7:

    # Caroline "I-It’s okay, I can push things back for a few days."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:93
translate chinese CR2_MS3a_label_ccb32c7d:

    # MC "I’m really sorry."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:94
translate chinese CR2_MS3a_label_7ca6456a:

    # Caroline "Don’t apologise. This isn’t your fault."
    Caroline ""

translate chinese strings:

    # game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:29
    old "Yeah, I have $150 here. There you go. (disabled)"
    new ""

    # game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:29
    old "{color=#00ff00}Yeah, I have $150 here. There you go.{/color}"
    new ""

    # game/scripts/home/mc_room/morning/scenes/CR2_MS3a.rpy:29
    old "Sorry, I don’t have $150 on me right now."
    new ""

