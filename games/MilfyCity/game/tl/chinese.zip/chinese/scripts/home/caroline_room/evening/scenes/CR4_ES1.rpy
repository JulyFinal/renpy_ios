﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:64
translate chinese CR4_ES1_label_d894c63d:

    # MC "(Looks like Caroline is kicking back and relaxing, for a change!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:65
translate chinese CR4_ES1_label_ae99b44d:

    # MC "(It’s certainly better than her, constantly being uptight all the time.)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:66
translate chinese CR4_ES1_label_e08cf1b3:

    # MC "Hey there, Caroline. How are things?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:69
translate chinese CR4_ES1_label_78d3ec17:

    # Caroline "Oh hey, come on in! Make yourself comfortable."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:70
translate chinese CR4_ES1_label_6f4a2338:

    # MC "Thanks."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:71
translate chinese CR4_ES1_label_d9e64280:

    # Caroline "I’m not too bad. What’s up? Grab yourself a beer!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:74
translate chinese CR4_ES1_label_13a42b0e:

    # MC "Nothing much, I just dropped by to say hi."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:75
translate chinese CR4_ES1_label_6b5d30c0:

    # Caroline "Well, ‘hi’ then. Hehe!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:86
translate chinese CR4_ES1_label_08728b1a:

    # MC "I've already talked to her."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:100
translate chinese CR4_ES1_menu_23b8a8d9:

    # MC "How’s business going?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:101
translate chinese CR4_ES1_menu_84cc6536:

    # Caroline "It’s on the up and up! I can barely keep stock on the shelves right now."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:102
translate chinese CR4_ES1_menu_a7120225:

    # MC "Cheers to that!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:105
translate chinese CR4_ES1_menu_c2b47dff:

    # Caroline "Yeah, cheers!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:106
translate chinese CR4_ES1_menu_e85b6ab8:

    # Caroline "Thanks again for all your help, [player_name]. I couldn’t have done this without you."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:107
translate chinese CR4_ES1_menu_67bcda00:

    # MC "It’s my pleasure, Caroline."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:110
translate chinese CR4_ES1_menu_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:111
translate chinese CR4_ES1_menu_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:119
translate chinese CR4_ES1_menu_89a3fd28:

    # MC "Have you spoken with Sara lately?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:120
translate chinese CR4_ES1_menu_2d16c931:

    # Caroline "No, why?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:123
translate chinese CR4_ES1_menu_8f21db26:

    # MC "She got grounded by, [Mom_name]! Didn’t you hear?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:124
translate chinese CR4_ES1_menu_1befec45:

    # Caroline "Oh! Of course. Yeah, I remember. It’s her own fault really. She spends far too much time playing video games."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:127
translate chinese CR4_ES1_menu_172b47e7:

    # Caroline "It’s kinda sad. She has so much potential. She just needs a kick up the ass!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:128
translate chinese CR4_ES1_menu_3391f4da:

    # MC "Haha, I know, I know."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:136
translate chinese CR4_ES1_menu_74c026eb:

    # MC "Did you enjoy our date the other night?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:137
translate chinese CR4_ES1_menu_e8170857:

    # Caroline "How could I not? It was amazing."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:138
translate chinese CR4_ES1_menu_f1c7fbe3:

    # MC "Yeah, it was one of the best nights of my entire life!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:141
translate chinese CR4_ES1_menu_59d81dc2:

    # Caroline "Really? Even better than your birthday a few years back, when you got that stupid computer?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:142
translate chinese CR4_ES1_menu_9f125011:

    # MC "Hey! That was a top-of-the-line gaming machine!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:145
translate chinese CR4_ES1_menu_8519a534:

    # MC "But no. Our date was much better."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:146
translate chinese CR4_ES1_menu_28a5f34b:

    # Caroline "And that, is the correct answer. Hehe!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:154
translate chinese CR4_ES1_menu_ca2bf297:

    # MC "Yazmin is self employed too, you know?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:155
translate chinese CR4_ES1_menu_13b00e9d:

    # Caroline "Oh yeah?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:156
translate chinese CR4_ES1_menu_890618da:

    # MC "I think she’s a model or something."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:159
translate chinese CR4_ES1_menu_5ba64047:

    # MC "Perhaps you two should get in touch? Share some business tips with each other."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:160
translate chinese CR4_ES1_menu_b2c0f762:

    # Caroline "Huh, that’s not a bad idea actually. I might actually take you up on that offer."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:163
translate chinese CR4_ES1_menu_665788ed:

    # Caroline "God... it’s so relaxing just lying back like this."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:164
translate chinese CR4_ES1_menu_edd1998f:

    # Caroline "Yazmin probably feels it too, the sheer exhaustion of working your ass off."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:165
translate chinese CR4_ES1_menu_87c46138_1:

    # MC "*Glug*"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:173
translate chinese CR4_ES1_menu_a4f55ba3_1:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:174
translate chinese CR4_ES1_menu_463a2278:

    # MC "I... uh... I’m sorry again about Charles stealing your necklace."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:175
translate chinese CR4_ES1_menu_40d6b48a:

    # Caroline "*COUGH*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:178
translate chinese CR4_ES1_menu_29d43590:

    # MC "I know it meant an awful lot to you."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:179
translate chinese CR4_ES1_menu_58d740cd:

    # MC "And if there was a way I could snap my fingers and get it back where it belongs, I would."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:182
translate chinese CR4_ES1_menu_f2cb7c49:

    # Caroline "Sorry, *cough* you took me by surprise there."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:183
translate chinese CR4_ES1_menu_a15131af:

    # Caroline "Listen... I’m slowly working my way through the stages of grief. I just want to blitzkrieg my way to acceptance as quickly as possible."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:184
translate chinese CR4_ES1_menu_a9a8de88:

    # MC "I understand that. If there’s anything I can do, please let me know."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:185
translate chinese CR4_ES1_menu_13b18d49:

    # Caroline "... I will."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:193
translate chinese CR4_ES1_menu_c9ce6929:

    # MC "Why did you even date that asshole?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:194
translate chinese CR4_ES1_menu_8b0f9248:

    # Caroline "Charles?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:195
translate chinese CR4_ES1_menu_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:199
translate chinese CR4_ES1_menu_83ac944a:

    # Caroline "I uh... I wasn’t in a great place after Grandma passed away."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:201
translate chinese CR4_ES1_menu_214e55ce:

    # Caroline "I uh... I wasn’t in a great place after my grandma passed away."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:202
translate chinese CR4_ES1_menu_a9015848:

    # Caroline "Believe it or not, he actually seemed... nice. At that particular time, at least."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:203
translate chinese CR4_ES1_menu_7e49bca0:

    # Caroline "Of course, he quickly changed. He became... nasty."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:206
translate chinese CR4_ES1_menu_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:207
translate chinese CR4_ES1_menu_1ee79caf:

    # Caroline "That’s when the shouting and the hitting began..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:210
translate chinese CR4_ES1_menu_c5761f69:

    # MC "Christ... I’m sorry for bringing this up."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:211
translate chinese CR4_ES1_menu_b0e9580c:

    # Caroline "*Glug Glug*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:214
translate chinese CR4_ES1_menu_48c8cbb2:

    # Caroline "When you’re on the outside, seeing a relationship like that- it’s easy to say, “just walk away!”"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:215
translate chinese CR4_ES1_menu_139440c5:

    # Caroline "But then you’re in it and... you just can’t escape those things. It’s like... fucking quicksand."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:218
translate chinese CR4_ES1_menu_a6ca74af:

    # Caroline "But - hey! I’m here now. A free woman! Hehe!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:219
translate chinese CR4_ES1_menu_0749d053:

    # MC "I’m just glad you made it out of that. It sounds like a living hell."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:222
translate chinese CR4_ES1_menu_71ae69de:

    # Caroline "For a while, sure. But it really makes you appreciate a good relationship when you open yourself up to one."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:223
translate chinese CR4_ES1_menu_0234b508:

    # Caroline "Do you know what I mean?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:226
translate chinese CR4_ES1_menu_6da37e5e:

    # MC "I think so."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:229
translate chinese CR4_ES1_menu_87c46138_2:

    # MC "*Glug*"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:230
translate chinese CR4_ES1_menu_a4f55ba3_2:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:238
translate chinese CR4_ES1_menu_d963669f:

    # MC "So, where do you see things going?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:239
translate chinese CR4_ES1_menu_7bb5ffc1:

    # Caroline "In my business? The global economy? "
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:240
translate chinese CR4_ES1_menu_5017cea4:

    # MC "No, haha! Between us! Our relationship. Where do you think it’s headed?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:243
translate chinese CR4_ES1_menu_7163e661:

    # Caroline "Hehe, I knew what you were talking about. I just couldn’t resist teasing you."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:244
translate chinese CR4_ES1_menu_8e5c2eab:

    # MC "You’re terrible."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:245
translate chinese CR4_ES1_menu_02806075:

    # Caroline "Hehe, I know!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:248
translate chinese CR4_ES1_menu_a81bb8e1:

    # MC "So..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:249
translate chinese CR4_ES1_menu_0b7d9281:

    # Caroline "Can we just take things one day at a time?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:250
translate chinese CR4_ES1_menu_a2eb4170:

    # Caroline "I’m enjoying this, I really am. Well, a lot more than just “enjoying” it."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:251
translate chinese CR4_ES1_menu_570fe15c:

    # Caroline "I’m happy with you, [player_name]. I think this could be... the start of a really healthy relationship. Let’s just let it grow naturally, and see where we end up?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:274
translate chinese CR4_ES1_kiss_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:275
translate chinese CR4_ES1_kiss_f02f0a48:

    # Caroline "Hehe... I’m... *Hic* getting a little bit drunk now."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:278
translate chinese CR4_ES1_kiss_ae0a2be7:

    # Caroline "I think I might have *Hic* had a bit too much..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:279
translate chinese CR4_ES1_kiss_f5ec2fe1:

    # MC "Haha, me too."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:282
translate chinese CR4_ES1_kiss_d059123d:

    # Caroline "Say... how about we have another round right now?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:283
translate chinese CR4_ES1_kiss_d51b254c:

    # MC "You mean, fuck again?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:284
translate chinese CR4_ES1_kiss_b7f9c464:

    # Caroline "Hehe, uh huh!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:287
translate chinese CR4_ES1_kiss_859ec537:

    # Caroline "Fuck it, let’s do it!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:288
translate chinese CR4_ES1_kiss_d3656abb:

    # MC "B-But, Caroline-"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:289
translate chinese CR4_ES1_kiss_6b68a2c8:

    # Caroline "Thinking about what we did down by the lake has got me all horny and wet. I can’t take it any longer!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:292
translate chinese CR4_ES1_kiss_190e1917:

    # Caroline "I need to feel your cock inside me again!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:293
translate chinese CR4_ES1_kiss_f4e7b7e6:

    # MC "(Shit, she’s drunk and horny! This is NOT a good combo!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:296
translate chinese CR4_ES1_kiss_d388463c:

    # MC "Caroline, can we wait until tonight?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:297
translate chinese CR4_ES1_kiss_6da0c7a6:

    # Caroline "Hehe, why wait?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:298
translate chinese CR4_ES1_kiss_3a185ad7:

    # MC "Everyone else is at home right now. Literally anyone, could walk in on us!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:299
translate chinese CR4_ES1_kiss_a010e6fb:

    # MC "How would you explain this to Sara or [Mom_name]?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:302
translate chinese CR4_ES1_kiss_4b8d6185:

    # MC "Mppff!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:304
translate chinese CR4_ES1_kiss_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:307
translate chinese CR4_ES1_kiss_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:309
translate chinese CR4_ES1_kiss_1039ef8b:

    # MC "(Oh God, she is so fucking hot when she gets aggressive like this!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:312
translate chinese CR4_ES1_kiss_91f13080:

    # Caroline "(Fuck, I’m so wet right now...)"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:313
translate chinese CR4_ES1_kiss_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:315
translate chinese CR4_ES1_kiss_07933a90:

    # Caroline "(He’s right though. If anyone caught us right now, it would fuck everything up!)"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:318
translate chinese CR4_ES1_kiss_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:319
translate chinese CR4_ES1_kiss_57d32970:

    # Caroline "(Just a little bit of fun won’t hurt though!)"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:320
translate chinese CR4_ES1_kiss_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:323
translate chinese CR4_ES1_kiss_951cc58a:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:324
translate chinese CR4_ES1_kiss_a9a7aa9a:

    # MC "(Fuck... it feels so good, having her lick my nipples like that! I never imagined they would be THIS sensitive!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:325
translate chinese CR4_ES1_kiss_e4a57eb6:

    # Caroline "Hehe, are you enjoying this?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:328
translate chinese CR4_ES1_kiss_007f5079:

    # MC "Mmm! Uh huh! Ohhh..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:329
translate chinese CR4_ES1_kiss_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:330
translate chinese CR4_ES1_kiss_941a0785:

    # MC "Ahh.."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:333
translate chinese CR4_ES1_kiss_7a33d634:

    # Caroline "How about I go even lower now?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:334
translate chinese CR4_ES1_kiss_b92d0937:

    # Caroline "Would you like me to wrap my lips around your hard cock?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:336
translate chinese CR4_ES1_kiss_1a704369:

    # MC "Mmm... (Damn, she’s so hard to resist. But this is a TERRIBLE idea, with all our family home!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:338
translate chinese CR4_ES1_kiss_51ac2cbf:

    # MC "Mmm... (Damn, she’s so hard to resist. But this is a TERRIBLE idea, with all of our roommates home!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:339
translate chinese CR4_ES1_kiss_7a18a717:

    # Caroline "I would suck it so hard... just like this!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:342
translate chinese CR4_ES1_kiss_e0cee18c:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:343
translate chinese CR4_ES1_kiss_e1ac8696:

    # MC "Oh fuck! Ahhh..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:344
translate chinese CR4_ES1_kiss_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:347
translate chinese CR4_ES1_kiss_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:348
translate chinese CR4_ES1_kiss_0c1e08a4:

    # MC "Oh God... Ohh..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:349
translate chinese CR4_ES1_kiss_90d8df38:

    # Caroline "Hehe, you’re so hard!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:352
translate chinese CR4_ES1_kiss_098efd6c:

    # MC "W-Wait, stop!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:353
translate chinese CR4_ES1_kiss_347429bd:

    # Caroline "Huh?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:354
translate chinese CR4_ES1_kiss_58fa325e:

    # MC "Can we wait until everyone falls asleep?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:357
translate chinese CR4_ES1_kiss_470970f9:

    # Caroline "But I’m gonna leave you unsatisfied..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:358
translate chinese CR4_ES1_kiss_c8d01b82:

    # Caroline "Will you come back quickly?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:366
translate chinese CR4_ES1_kiss_b5ed4285:

    # MC "Yes, I’ll be back as soon as possible."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:367
translate chinese CR4_ES1_kiss_5392fc7e:

    # Caroline "Don’t keep a girl waiting."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:379
translate chinese CR4_ES1_kiss_d603c228:

    # MC "Sorry Caroline, I can’t do tonight. We both need our sleep."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:380
translate chinese CR4_ES1_kiss_b467572d:

    # Caroline "Okay... I understand..."
    Caroline ""

translate chinese strings:

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "How’s business going?"
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "Have you spoken with Sara lately? "
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "Did you enjoy our date the other night?"
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "Yazmin is self employed too. Perhaps you two should get in touch?"
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "I’m sorry about your necklace. "
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "Why did you even date that asshole Charles?"
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "Where do you see things going between us?"
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:96
    old "{color=#00ff00}Continue{/color}"
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:364
    old "Yes, I’ll be back as soon as possible."
    new ""

    # game/scripts/home/caroline_room/evening/scenes/CR4_ES1.rpy:364
    old "No, not tonight. We both need our sleep."
    new ""

