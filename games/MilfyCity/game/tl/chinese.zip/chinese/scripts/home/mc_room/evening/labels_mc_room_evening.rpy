﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/evening/labels_mc_room_evening.rpy:10
translate chinese mc_room_evening1_cf77105c:

    # MC "Time to get up!"
    MC ""

