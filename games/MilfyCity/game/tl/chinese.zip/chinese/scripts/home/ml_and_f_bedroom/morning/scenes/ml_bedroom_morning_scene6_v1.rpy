﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:39
translate chinese ml_bedroom_morning_scene6_v1_label_04f9bbef:

    # Linda "I'm a bit busy right now."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:53
translate chinese ml_bedroom_morning_scene6_v1_label_4f6ae36d:

    # MC "Hey, Mom. I’m here to talk to you about... the thing that happened between us the last time..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:55
translate chinese ml_bedroom_morning_scene6_v1_label_50713cad:

    # MC "Hey, Linda. I'm here to talk to you about... the thing that happened between us the last time..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:56
translate chinese ml_bedroom_morning_scene6_v1_label_5e7a2c2c:

    # Mom "*Gulp* Y-Yes?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:57
translate chinese ml_bedroom_morning_scene6_v1_label_05d58f7e:

    # MC "Is now a good time for you? Or do you want me to come back later?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:58
translate chinese ml_bedroom_morning_scene6_v1_label_ab8e121e:

    # Mom "I... I’m going to work soon, but I have a few minutes."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:64
translate chinese ml_bedroom_morning_scene6_v1_label_ee8efdf8:

    # MC "Mom, I... I love you too."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:65
translate chinese ml_bedroom_morning_scene6_v1_label_40cd20d3:

    # MC "And not just in the way a son normally loves his Mom. I mean, I really love you."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:67
translate chinese ml_bedroom_morning_scene6_v1_label_66b99089:

    # MC "Linda, I... I love you too."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:68
translate chinese ml_bedroom_morning_scene6_v1_label_ef97be22:

    # MC "I understand that you're much more experienced than I am, and you have a husband, but I genuinely love you. Since the day I moved here and became your tenant, I've noticed how much you've cared about me."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:73
translate chinese ml_bedroom_morning_scene6_v1_label_b5315db6:

    # MC "After, all you said the last time, and the way you've acted around me... I think..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:74
translate chinese ml_bedroom_morning_scene6_v1_label_bf944fd1:

    # MC "I think I want the same thing that you do."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:79
translate chinese ml_bedroom_morning_scene6_v1_label_69c8b3f6:

    # MC "Mom... You really should have told me sooner."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:81
translate chinese ml_bedroom_morning_scene6_v1_label_b6cd3ca5:

    # MC "Linda... You really should have told me sooner."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:82
translate chinese ml_bedroom_morning_scene6_v1_label_bdf782c7:

    # MC "You said that you’ve always felt this way. If I’d known, then I would have been able to understand, why you were acting the way you were."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:83
translate chinese ml_bedroom_morning_scene6_v1_label_76fc7e11:

    # MC "Everything would have made sense."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:90
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_8dc8bc4e:

    # MC "Anyway, I should go now. But... I really do love you, Mom. "
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:91
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_6a93b26f:

    # MC "And I might be interested in... doing some of the... um.... stuff... that..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:93
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_9b18281b:

    # MC "Anyway, I should go now. Bob could be here any time soon. "
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:94
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_7fbd81bf:

    # MC "And I might be interested in... doing some stuff... with you... regardless that you have a husband... um..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:96
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_fd215a4e:

    # MC "Sorry, I’m getting all nervous and stumbling over my words. I should just go."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:99
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_dc99bc46:

    # Mom "Don’t go! Please!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:100
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:101
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_be8d4764:

    # Mom "S-Sorry, I didn’t mean to frighten you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:103
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_4201f689:

    # Mom "I was... just, so sure that you were going to tell me, that you only loved me like a mother."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:104
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_f2d1ccb3:

    # Mom "I was scared that I might have pushed you away, with those silly games I made you play."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:106
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_1690e764:

    # Mom "I was... just so certain that you were going to tell me that you only loved me like a very caring landlady. Besides, I'm older than you and I have a husband."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:107
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_a2ec5f9b:

    # Mom "I was afraid of that, and I thought you might also prefer younger women. That's why I wanted to engage in those silly games with you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:108
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_392831e4:

    # Mom "I know everything’s moving quite fast... but if you want, we could be intimate together, in our underwear. How does that sound?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:109
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_aa6573dc:

    # MC "*Gulp* R-Really? Right now?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:110
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_49dfee50:

    # Mom "Sit down on the sofa at the end of my bed."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:115
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_a253b8eb:

    # Mom "I want you to see this."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:116
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_fb7b98e2:

    # Mom "I want you to look at my body and enjoy watching it."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:118
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_c48a05af:

    # Mom "This is just for you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:120
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_a245ca6d:

    # Mom "This is just for you. Bob shouldn’t come here soon."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:123
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:124
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_886030e9:

    # Mom "(I hope he likes my body... I know I’m not THAT young anymore...)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:126
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_3bcccc8b:

    # MC "Wow... You’re stunning, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:128
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_e729dde0:

    # MC "Wow... You’re stunning, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:131
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_d88d9d4b:

    # Mom "You really think so?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:132
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_6c0fe967:

    # MC "Yeah - your body is incredible! And that lingerie you’re wearing, fits you perfectly!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:133
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_f6b7be7a:

    # Mom "I’m glad you like it."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:136
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_3def29be:

    # Mom "How about you strip off now too?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:137
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_e841d04b:

    # Mom "I’ve shown you what I’ve got - it’s only fair that you show me yours."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:138
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_ed5b4f21:

    # MC "Okay, hang on..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:141
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_2b2d1b6a:

    # MC "Well? Is it as good as you imagined?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:142
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_0c1b14bb:

    # Mom "Mmm... Almost. The part I spent, most time fantasising about, is still covered up right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:145
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_2fd82f9f:

    # Mom "It’s going to feel so good, to finally kiss you without feeling like a creep."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:146
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_8ef78f54:

    # MC "You did have me wondering what was going on, for a few days there."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:147
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_e27a46bd:

    # Mom "Hehe... I’m sorry. I just couldn’t resist you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:150
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:151
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_c977372b:

    # Mom "(How can something so wrong, feel so right?)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:153
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_7210687d:

    # Mom "(It’s like... my dreams are finally beginning to come true.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:154
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_301a9559:

    # Mom "(Whenever I kiss [player_name], there’s butterflies in my tummy... I’ve never felt this way, when I’ve kissed anyone else, in my life.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:157
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_54e1f274:

    # Mom "Lie down on the bed. Just like that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:158
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_545ec595:

    # Mom "(I can see how hard he already is... but I have to feel it with my own hand.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:161
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_13d4ced8:

    # Mom "Do you mind if I... touch you with my hand?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:162
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_76b251f4:

    # MC "S-Sure... I don’t mind."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:165
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_e00edddb:

    # Mom "(Wow... He’s huge...)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:166
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_9cb4c089:

    # Mom "(If only he wasn’t wearing these boxer shorts...)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:167
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_24219d84:

    # Mom "(I’d love to take his cock in my mouth right now, and suck on it until he came.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:171
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_f13cb6dc:

    # MC "Ahh... M-Mom..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:173
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_2aec94d1:

    # MC "Ahh... L-Linda..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:174
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_802bcddc:

    # MC "(She’s being so gentle with her tongue...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:177
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_f375d839:

    # MC "Ah! Ahh..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:178
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_3e8d2ee8:

    # Mom "(It sounds like his nipples are especially sensitive.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:179
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_4985a879:

    # Mom "(He’s clearly enjoying me flicking my tongue over them.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:183
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_dedafdec:

    # MC "(I’m so hard right now... I can’t believe, Mom was this attracted to me for so long.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:185
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_de3b11ea:

    # MC "(I’m so hard right now... I can’t believe, Linda was this attracted to me for so long.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:186
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_5213554d:

    # MC "(I wonder if this was one of the fantasies she had, about me and her?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:190
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_cd78d7a2:

    # MC "Ooh... Oh, Mom!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:192
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_46e0c493:

    # MC "Ooh... Oh, Linda!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:193
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_d624ed52:

    # Mom "Do you like it when I kiss your neck like this?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:194
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_a1206890:

    # MC "Yes..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:197
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_753c01e0:

    # Mom "You can do whatever you want now. I’ve had my fun - it’s time for you to have some too."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:198
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:199
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_22a0cfd0:

    # Mom "I’ll lie back, on the bed. The rest is up to you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:206
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_c8e867dc:

    # MC "You’ve got beautiful feet."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:207
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_d01a4ad5:

    # Mom "Hehe... Thanks. Have you got a bit of a foot fetish, then?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:208
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_87d764a2:

    # MC "W-What?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:211
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_f7a807e6:

    # Mom "Relax - I’m just teasing you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:212
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_fa5cfed3:

    # Mom "Mmm... It’s nice when you massage them like that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:213
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_2c78f826:

    # MC "You like that? I’ll do the soles too, then."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:216
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_c1c1d3d9:

    # Mom "Ahh... Your father never does ANYTHING like this, for me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:217
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_24719c88:

    # Mom "God... your fingers are amazing."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:223
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_c8e867dc_1:

    # MC "You’ve got beautiful feet."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:224
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_d01a4ad5_1:

    # Mom "Hehe... Thanks. Have you got a bit of a foot fetish, then?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:225
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_87d764a2_1:

    # MC "W-What?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:228
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_f7a807e6_1:

    # Mom "Relax - I’m just teasing you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:229
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_fa5cfed3_1:

    # Mom "Mmm... It’s nice when you massage them like that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:230
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_2c78f826_1:

    # MC "You like that? I’ll do the soles too, then."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:233
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_9c162345:

    # Mom "Ahh... Bob never does ANYTHING like this, for me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:234
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch_24719c88_1:

    # Mom "God... your fingers are amazing."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:245
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_ff17e220:

    # MC "Can you spread your legs a little more, Mom?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:247
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_a18f2681:

    # MC "Can you spread your legs a little more, Linda?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:248
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_3c3139d5:

    # Mom "Of course. Like this?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:249
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_75715e4e:

    # MC "Perfect."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:252
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_95583728:

    # Mom "Ooh..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:253
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_4c1e9741:

    # Mom "(His fingers are so close to my pussy... I wish he’d go a little bit closer, and just slip them inside me.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:254
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_60097e86:

    # MC "Your skin’s so soft."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:257
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_771c4edc:

    # Mom "The trick is, an exfoliating scrub and moisturiser, twice a day."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:258
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_c99e9ed8:

    # MC "Are you okay if I touch your breasts?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:259
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_f57c338c:

    # Mom "Please, go ahead."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:262
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:263
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_6cbd7aea:

    # Mom "You can give them a squeeze, if you want."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:264
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_de892c19:

    # Mom "Just don’t be too rough, okay?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:267
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:268
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_83068f48:

    # MC "(This is freaking awesome!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:269
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_3ad38725:

    # MC "(I hope I get to play with them, without the bra, soon!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:272
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_ffa2753c:

    # Mom "If we weren’t wearing our underwear, I would just pull you inside me, right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:273
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_dac3f703:

    # Mom "Mmm... I’d love to feel your cock, thrusting, deep into my wet pussy."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:276
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_838b5fd1:

    # Mom "I can already feel your hard cock, pressing against my black panties."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:277
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_28d866db:

    # Mom "Sadly, I have to go. If I spend, another minute in bed, I’ll be late for work."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:278
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_775c12a5:

    # Mom "I’ll see you tonight, Sweetie."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:280
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_99e35e67:

    # MC "I love you, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:282
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_e517d6c7:

    # MC "I love you, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:283
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch2_2b4de539:

    # Mom "I love you too."
    Mom ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:202
    old "Start with Mom’s hips, and work up her body."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene6_v1.rpy:202
    old "Start with Linda’s Hips, and work up her body."
    new ""

