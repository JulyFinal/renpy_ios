﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_money.rpy:14
translate chinese ml_bedroom_morning_money_label_d8293799:

    # MC "Nice! +[money]$"
    MC ""

