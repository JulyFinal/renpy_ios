﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:21
translate chinese SR3_MS1_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:23
translate chinese SR3_MS1_04ec2d6d:

    # MC "Hey, Sara, I just wanted to check how you were doing."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:25
translate chinese SR3_MS1_4a0fe5ab:

    # MC "(Is that a photo of Lily on the wall? What on Earth is she doing?)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:26
translate chinese SR3_MS1_51c4ce02:

    # MC "Umm... Sara?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:28
translate chinese SR3_MS1_0368d173:

    # Sara "She’s not gonna do it."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:29
translate chinese SR3_MS1_df2163cf:

    # MC "Pardon?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:30
translate chinese SR3_MS1_7039047b:

    # Sara "She’s NOT going to do it!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:32
translate chinese SR3_MS1_01cab26e:

    # MC "Sara, what are you talking about?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:33
translate chinese SR3_MS1_f7e90c4a:

    # Sara "She wants to take you from me! She wants you just for herself! I saw it that day when we played spin the bottle in my bedroom."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:37
translate chinese SR3_MS1_571e70cc:

    # Sara "I saw the way she kissed you in my bedroom!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:39
translate chinese SR3_MS1_2352e154:

    # MC "Sara... I think you need to take a step back and take a deep breath."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:40
translate chinese SR3_MS1_6a631891:

    # Sara "And you... you said ‘yes’ to going on a date with me. You built my hopes up!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:41
translate chinese SR3_MS1_2b1461f5:

    # Sara "You made me believe that I was the only one for you!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:43
translate chinese SR3_MS1_3631fcdf:

    # MC "Sara, you are! I had NOTHING to do with what Lily is trying to do right now!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:44
translate chinese SR3_MS1_4e29c190:

    # Sara "I gave up my virginity for you! *Sob*"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:45
translate chinese SR3_MS1_8a278ab6:

    # Sara "Lily was ALWAYS on your mind, wasn’t she?! *Sob*"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:48
translate chinese SR3_MS1_d4eeee49:

    # MC "Sara, that’s not-"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:52
translate chinese SR3_MS1_3cf484a6:

    # Sara "I saw the way she kissed you."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:54
translate chinese SR3_MS1_2352e154_1:

    # MC "Sara... I think you need to take a step back and take a deep breath."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:55
translate chinese SR3_MS1_7306b73c:

    # Sara "I should have KNOWN that you had your eyes on someone else, [player_name]."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:56
translate chinese SR3_MS1_565c7afc:

    # Sara "You were the one who wanted our date to be a big secret!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:59
translate chinese SR3_MS1_c8c1f718:

    # MC "Sara, I was ONLY worried about people noticing us as brother and sister!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:61
translate chinese SR3_MS1_1677657f:

    # MC "Sara! I was ONLY worried about us! Everything was happening so fast... I wasn't cheating on you!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:62
translate chinese SR3_MS1_738048f3:

    # Sara "You’re... a fucking liar! It was Lily, wasn’t it?!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:65
translate chinese SR3_MS1_51e06123:

    # Sara "It’s ALWAYS been Lily!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:69
translate chinese SR3_MS1_117d5dd4:

    # Sara "AAAHHHHH!!!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:70
translate chinese SR3_MS1_697830c9:

    # Sara "FUCKING BITCH! She’s trying to ruin my life!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:72
translate chinese SR3_MS1_af8eee35:

    # MC "Jesus Christ... "
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:73
translate chinese SR3_MS1_47a551dc:

    # MC "(I need to back off until she cools down. Maybe I should speak with someone from college?)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:75
translate chinese SR3_MS1_e059e60c:

    # Sara "Fuck you, Lily! FUCK YOU!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:76
translate chinese SR3_MS1_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR3_MS1.rpy:77
translate chinese SR3_MS1_4ef95442:

    # Sara "YOU MAN STEALING WHORE! I HATE YOU!"
    Sara ""

