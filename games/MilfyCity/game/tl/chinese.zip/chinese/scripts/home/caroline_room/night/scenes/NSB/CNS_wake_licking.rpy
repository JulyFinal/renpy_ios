﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:26
translate chinese CNS_wake_licking_label_1ede3798:

    # MC "How about we switch things up, tonight - and I help get YOU off?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:27
translate chinese CNS_wake_licking_label_6c602b6f:

    # Caroline "Get... ME off?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:28
translate chinese CNS_wake_licking_label_27115d9c:

    # MC "Yeah, it’s only fair, right? I don’t want to be the dickhead who never reciprocates."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:32
translate chinese CNS_wake_licking_label_cf390bba:

    # Caroline "Umm... I guess it would be kinda nice, for a change. What are you thinking of?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:33
translate chinese CNS_wake_licking_label_e543e3c1:

    # MC "I was thinking of burying my face between your thighs, and licking your pussy till you scream my name."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:34
translate chinese CNS_wake_licking_label_23678f69:

    # Caroline "Oh my! That does sound rather fun..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:35
translate chinese CNS_wake_licking_label_33c5ca10:

    # MC "Take your underwear off and climb up on the bed."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:39
translate chinese CNS_wake_licking_label_145da06c:

    # Caroline "How’s this?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:40
translate chinese CNS_wake_licking_label_b18965f2:

    # MC "Fucking perfect! You look amazing, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:41
translate chinese CNS_wake_licking_label_d31c05c6:

    # Caroline "Hehe, thanks."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:45
translate chinese CNS_wake_licking_label_0f209c0e:

    # Caroline "Let me just get my girl wet for you. A couple of seconds of attention from my fingers, and she’ll be all yours."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:46
translate chinese CNS_wake_licking_label_5a9cb2e1:

    # MC "(Damn, it looks so fucking hot when she’s fingering herself like that.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:47
translate chinese CNS_wake_licking_label_cbe9cf64:

    # Caroline "Ah... O-Okay, that should do it."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:51
translate chinese CNS_wake_licking_label_ddd99bb0:

    # MC "*Kiss*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:52
translate chinese CNS_wake_licking_label_f5d54000:

    # Caroline "Oh! Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:53
translate chinese CNS_wake_licking_label_a1993164:

    # Caroline "(Wow, it’s so exciting, feeling him go down on me like that!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:57
translate chinese CNS_wake_licking_label_ce8a98e9:

    # Caroline "(My ex always refused to even try it!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:59
translate chinese CNS_wake_licking_label_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:60
translate chinese CNS_wake_licking_label_e05e8f36:

    # Caroline "Ah! Ahhh! Yes, right there..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:64
translate chinese CNS_wake_licking_label_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:65
translate chinese CNS_wake_licking_label_f283f5e8:

    # MC "(Mmm, she tastes delicious. I love listening to her moan with each lap of my tongue!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:66
translate chinese CNS_wake_licking_label_286b8da4:

    # Caroline "Ahh... Ahh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:70
translate chinese CNS_wake_licking_label_0465d3b6:

    # Caroline "[player_name], do you think you could ahh suck on my clitty?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:71
translate chinese CNS_wake_licking_label_2ef4cbf5:

    # MC "Mmm hmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:72
translate chinese CNS_wake_licking_label_5b86eab6:

    # Caroline "Mmm! Thank you, ohhh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:76
translate chinese CNS_wake_licking_label_1060eba7:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:77
translate chinese CNS_wake_licking_label_5622c3c0:

    # Caroline "AH! AHHH! MMM! YES!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:78
translate chinese CNS_wake_licking_label_b0824d5d:

    # MC "*SHLURRRP*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:82
translate chinese CNS_wake_licking_label_aa0dcc9c:

    # Caroline "Oh God... Oh God... Mmm! It’s sooo gooood!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:84
translate chinese CNS_wake_licking_label_1060eba7_1:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:86
translate chinese CNS_wake_licking_label_bbb40e4f:

    # Caroline "(I forgot how good it feels to have a guy eat out your pussy like this.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:88
translate chinese CNS_wake_licking_label_6c5aa11e:

    # Caroline "(Oh God... Mmm! This feels so good!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:92
translate chinese CNS_wake_licking_label_b990ffee:

    # MC "(I think I’ll go back to licking, to vary things up a bit!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:93
translate chinese CNS_wake_licking_label_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:94
translate chinese CNS_wake_licking_label_a80a89ac:

    # Caroline "Oh. Ohhh... Ohhhh...."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:98
translate chinese CNS_wake_licking_label_c03f228a:

    # Caroline "Yes, [player_name]! Right there! Ahh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:99
translate chinese CNS_wake_licking_label_93af83bd:

    # Caroline "Oh God, don’t stop! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:100
translate chinese CNS_wake_licking_label_afa80320:

    # Caroline "(My mind’s melting, right now! He knows all the spots to run his tongue across!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:104
translate chinese CNS_wake_licking_label_8ad46f06:

    # MC "(Let’s try diving my tongue inside her pussy now, to see how she enjoys that!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:106
translate chinese CNS_wake_licking_label_0167ec39:

    # Caroline "Mmm! Ahhh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:107
translate chinese CNS_wake_licking_label_4ecebe59:

    # Caroline "(Dammit, his tongue is sooo close to going inside me... I can’t resist any longer!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:112
translate chinese CNS_wake_licking_label_8ea12c48:

    # MC "Mmmpfff?!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:113
translate chinese CNS_wake_licking_label_8ddbd9f4:

    # MC "(Holy crap! She just grabbed my head and pulled it down, onto her pussy!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:114
translate chinese CNS_wake_licking_label_71a6affe:

    # Caroline "Hnnnggg!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:118
translate chinese CNS_wake_licking_label_b01e9d3b:

    # Caroline "Ahhh! I’m cumming! Don’t stop! Don’t stop!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:119
translate chinese CNS_wake_licking_label_47efa6ca:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:120
translate chinese CNS_wake_licking_label_ec9a9217:

    # Caroline "Oh! OH!!!! AHHHHHHH!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:121
translate chinese CNS_wake_licking_label_8a7831b6:

    # MC "*SHLURP SHLURP*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:122
translate chinese CNS_wake_licking_label_8c04bcf4:

    # Caroline "YEEEESSS! Oh, [player_name]! Yes! Lick my pussy!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:126
translate chinese CNS_wake_licking_label_c9b5fa53:

    # Caroline "*Pant* W-Wow..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:127
translate chinese CNS_wake_licking_label_b4f18c15:

    # Caroline "O-Okay, you can stop now... haha... *Phew*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:128
translate chinese CNS_wake_licking_label_aa074b8b:

    # MC "I take it you enjoyed that?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:132
translate chinese CNS_wake_licking_label_9a14c9e3:

    # Caroline "Enjoyed it?! I fucking loved it..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:133
translate chinese CNS_wake_licking_label_e552c051:

    # Caroline "You’re incredible with that tongue of yours. Have you had much practice?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:134
translate chinese CNS_wake_licking_label_f5b493e7:

    # MC "Honestly? Not really."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_licking.rpy:135
translate chinese CNS_wake_licking_label_e93ad10b:

    # Caroline "You’re just a natural, then. I’m a lucky gal."
    Caroline ""

