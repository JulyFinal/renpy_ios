﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:22
translate chinese scene3_v1drawer_aa25adcd:

    # MC "(Huh, no sign of Sara. I wonder where she is.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:23
translate chinese scene3_v1drawer_8e6265a6:

    # MC "(Come to think of it... if she’s not around, I could take a nosy in her cupboards. Maybe she has something interesting hidden away?)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:38
translate chinese sis_nerdy_scene3_1_v1_96cc2d0e:

    # MC "(Let’s see what could be hidden in here.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:39
translate chinese sis_nerdy_scene3_1_v1_bb4d920f:

    # MC "(Most of the girls in college have started drinking alcohol now. She might have some stashed away in here.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:44
translate chinese sis_nerdy_scene3_1_v1_84092e46:

    # MC "(Boring... Junk... Garbage...)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:45
translate chinese sis_nerdy_scene3_1_v1_45dbd53d:

    # MC "(How much makeup does one girl need?!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:46
translate chinese sis_nerdy_scene3_1_v1_77303c99:

    # MC "(Whoa! Hold up!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:49
translate chinese sis_nerdy_scene3_1_v1_a1d03105:

    # MC "(A pair of Sara’s panties?)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:50
translate chinese sis_nerdy_scene3_1_v1_aeb7e580:

    # MC "(I could sneak these back to my room before she returns.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:51
translate chinese sis_nerdy_scene3_1_v1_6f42e504:

    # MC "(Wait - why am I even thinking of doing something like that?! That stupid therapist is puting perverted ideas into my head!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:52
translate chinese sis_nerdy_scene3_1_v1_e2761878:

    # MC "(I should probably just put them back and-)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:57
translate chinese sis_nerdy_scene3_1_v1_cffe01a5:

    # Sara "AHEM!"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:58
translate chinese sis_nerdy_scene3_1_v1_129f44b2:

    # Sara "[player_name]? What are you doing in my underwear drawer?"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:59
translate chinese sis_nerdy_scene3_1_v1_a70c5cab:

    # MC "(FUCK!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:60
translate chinese sis_nerdy_scene3_1_v1_d9c50ba8:

    # MC "(I’m gonna need to come up with a plan to get out of this one...)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:66
translate chinese sis_nerdy_scene3_1_v1_7596147d:

    # MC "(The less that I say the better. Maybe if I act like nothing weird is going on, then Sara will think I was just cleaning or putting away laundry?)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:67
translate chinese sis_nerdy_scene3_1_v1_5dbe91fe:

    # MC "(Yeah, that’s the best way to handle this.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:68
translate chinese sis_nerdy_scene3_1_v1_0651ac04:

    # Sara "[player_name]! What are you doing with my-"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:71
translate chinese sis_nerdy_scene3_1_v1_35b52e6b:

    # Sara "Huh?!"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:72
translate chinese sis_nerdy_scene3_1_v1_7be6f05c:

    # Sara "(Wh-What?! He just dropped my panties and left?)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:73
translate chinese sis_nerdy_scene3_1_v1_ec2b2428:

    # MC "(Haha! Nailed it! Now she thinks I was just putting away the laundry!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:74
translate chinese sis_nerdy_scene3_1_v1_171a8a42:

    # Sara "(Was that supposed to be a bluff that he was doing the laundry?)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:75
translate chinese sis_nerdy_scene3_1_v1_8e918c04:

    # MC "(There’s no way she’ll ever think that I was about to steal her panties and jerk off into them!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:76
translate chinese sis_nerdy_scene3_1_v1_acda6d70:

    # Sara "(Damn... the thought of him stealing my panties and jerking off into them is pretty fucking hot.)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:79
translate chinese sis_nerdy_scene3_1_v1_ebd53ce6:

    # Sara "Really... really... hot..."
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:80
translate chinese sis_nerdy_scene3_1_v1_e499d2ab:

    # Sara "(He must have really liked those panties if he took them out of the drawer first.)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:81
translate chinese sis_nerdy_scene3_1_v1_7b0be7cc:

    # Sara "(I wonder if I could surprise him with them.)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:82
translate chinese sis_nerdy_scene3_1_v1_3d41600d:

    # Sara "(Just the thought alone is getting me all wet... I believe I need a quick shower...)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:83
translate chinese sis_nerdy_scene3_1_v1_b335f5c5:

    # Sara "(I hope nobody is using a bathroom at the moment.)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:89
translate chinese sis_nerdy_scene3_1_v1_8810bc97:

    # MC "(I just have to tell her that I came into her room and found her panties lying on the floor.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:90
translate chinese sis_nerdy_scene3_1_v1_175b8a87:

    # MC "(You can do this, [player_name]. Practice in your head, then turn around, and confidently explain what happened.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:91
translate chinese sis_nerdy_scene3_1_v1_27f81ad3:

    # MC "(Sara, I came into your room, saw your panties lying on the floor, and picked them up.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:92
translate chinese sis_nerdy_scene3_1_v1_b6484a1c:

    # Sara "[player_name]?"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:93
translate chinese sis_nerdy_scene3_1_v1_d9c290dc:

    # MC "(Sara, I came into your room, saw your panties lying on the floor.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:94
translate chinese sis_nerdy_scene3_1_v1_ae7609a7:

    # Sara "[player_name]! What the heck are you doing?!"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:95
translate chinese sis_nerdy_scene3_1_v1_44c42a1d:

    # MC "(Sara, I came into your room, saw your panties lying on the-)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:96
translate chinese sis_nerdy_scene3_1_v1_3271eb41:

    # Sara "[player_name]!!!! Answer me!!!"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:99
translate chinese sis_nerdy_scene3_1_v1_1ecdb2a3:

    # MC "S-Sara, I lay in your room and came in your panties!"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:100
translate chinese sis_nerdy_scene3_1_v1_aa1722d2:

    # Sara "WHAT?!"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:101
translate chinese sis_nerdy_scene3_1_v1_3fa2d3eb:

    # MC "N-No! I came in your panties - I mean, I came on your floor!"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:102
translate chinese sis_nerdy_scene3_1_v1_0ae11476:

    # Sara "Wh-What?! Eww!"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:103
translate chinese sis_nerdy_scene3_1_v1_d4fd9591:

    # MC "(Oh fuck! I’m screwing this up! I need to take a deep breath and start again.)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:104
translate chinese sis_nerdy_scene3_1_v1_d67a00a9:

    # MC "I came into your... room. I saw your panties lying on the floor. Then I picked them up to put back in the drawer."
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:105
translate chinese sis_nerdy_scene3_1_v1_109ea359:

    # MC "Here, take them back!"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:108
translate chinese sis_nerdy_scene3_1_v1_6a4b1deb:

    # MC "(Jesus Christ! That was almost as bad as my experience with Ms. Celia!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:109
translate chinese sis_nerdy_scene3_1_v1_556b5fa3:

    # MC "(Why can’t I just socialise with people properly!)"
    MC ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:112
translate chinese sis_nerdy_scene3_1_v1_55b1775d:

    # Sara "(Hehe! It was REALLY funny seeing him get flustered like that.)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:113
translate chinese sis_nerdy_scene3_1_v1_7fff3578:

    # Sara "(I gotta admit though - the thought of him using my panties and cumming in them is really hot.)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:114
translate chinese sis_nerdy_scene3_1_v1_3d41600d_1:

    # Sara "(Just the thought alone is getting me all wet... I believe I need a quick shower...)"
    Sara ""

# game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:115
translate chinese sis_nerdy_scene3_1_v1_b335f5c5_1:

    # Sara "(I hope nobody is using a bathroom at the moment.)"
    Sara ""

translate chinese strings:

    # game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:62
    old "Drop the panties in the drawer and walk away without saying a word."
    new ""

    # game/scripts/home/sara_room/morning/scene3(v1)morning.rpy:62
    old "Lie and state that you found them lying on the floor."
    new ""

