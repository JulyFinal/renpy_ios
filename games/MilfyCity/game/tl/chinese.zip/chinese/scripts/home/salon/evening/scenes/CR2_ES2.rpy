﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:36
translate chinese CR2_ES2_label_73dcaed4:

    # MC "(I shouldn't bother her. She wants to be alone.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:49
translate chinese CR2_ES2_label_04bde0f3:

    # MC "(Caroline is looking very downhearted there. Maybe I should go over and see how she’s doing.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:50
translate chinese CR2_ES2_label_c225d450:

    # MC "(I know I’d be devastated if I owned a business that got robbed.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:54
translate chinese CR2_ES2_label_8463bb9d:

    # MC "(She didn’t even seem to notice me walking over. She must be REALLY deep in thought.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:55
translate chinese CR2_ES2_label_cf561d1d:

    # MC "(I’ll just approach this gently. I don’t want to upset her, any more than she already is.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:59
translate chinese CR2_ES2_label_534f9cc3:

    # MC "Hey Caroline, how are you holding up?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:60
translate chinese CR2_ES2_label_e0d970dc:

    # Caroline "Oh hey, [player_name]. I’m good! Don’t you worry."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:61
translate chinese CR2_ES2_label_9416fb6c:

    # MC "Promise?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:65
translate chinese CR2_ES2_label_3f9e6e88:

    # Caroline "Honestly. I’m fine."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:66
translate chinese CR2_ES2_label_59fb1576:

    # Caroline "C’mon over and take a seat beside me."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:67
translate chinese CR2_ES2_label_615eedc7:

    # MC "Okay."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:73
translate chinese CR2_ES2_label_4f0d26dc:

    # MC "(Caroline’s on the couch with hot chocolate again.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:74
translate chinese CR2_ES2_label_3434f9f8:

    # MC "(I should probably check up on her, to make sure she isn’t feeling too depressed.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:78
translate chinese CR2_ES2_label_06333156:

    # MC "Hey, it’s just me again."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:79
translate chinese CR2_ES2_label_2da45d3b:

    # MC "I thought I’d go in just to see how you’re feeling."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:83
translate chinese CR2_ES2_label_50a528f2:

    # Caroline "Hi..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:84
translate chinese CR2_ES2_label_0dd5989f:

    # MC "Are you okay if I sit down beside you? Or would you rather spend some time alone?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:85
translate chinese CR2_ES2_label_5bdcbd94:

    # Caroline "Honestly? I’d rather be alone right now. But feel free to sit with me for a few minutes, if you want."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:95
translate chinese CR2_ES2_label_07a471f5:

    # MC "(She’s still moping around the house with a hot chocolate.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:96
translate chinese CR2_ES2_label_63459b74:

    # MC "(It seems like this robbery seriously affected her.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:100
translate chinese CR2_ES2_label_54da4456:

    # MC "Hey, Caroline. How are you today?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:104
translate chinese CR2_ES2_label_d40e9c02:

    # Caroline "Oh, hi..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:105
translate chinese CR2_ES2_label_6b7f83e0:

    # MC "Have you been outside, at all?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:106
translate chinese CR2_ES2_label_408d6276:

    # Caroline "Nah, I’m comfy in here."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:107
translate chinese CR2_ES2_label_cc10b33a:

    # MC "(Caroline needs to find some closure on this robbery situation. She’s evidently not moving on with her life right now.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:123
translate chinese CR2_ES2_menu_1569e0d1:

    # MC "Do you know where I’d be able to find Violet?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:127
translate chinese CR2_ES2_menu_599082d4:

    # Caroline "Hmm... I know she usually hangs out around that old dark alley, in the city."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:128
translate chinese CR2_ES2_menu_fda6b1d3:

    # Caroline "You’d need to be careful around that area though."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:132
translate chinese CR2_ES2_menu_881b4fca:

    # Caroline "Why do you want to find her, by the way? You can’t seriously be interested in pursuing a relationship with her?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:133
translate chinese CR2_ES2_menu_3a411498:

    # MC "Uh... She... left some of her makeup behind, by accident. I just wanted to return it."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:137
translate chinese CR2_ES2_menu_fac1701d:

    # Caroline "Ohh, that’s very nice of you. Tell her I say hello! I haven’t heard from her in a few days."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:138
translate chinese CR2_ES2_menu_558500c1:

    # MC "(Caroline hasn’t heard from Violet? That makes sense. Violet is probably feeling guilty after robbing her friend.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:139
translate chinese CR2_ES2_menu_ac6b64d7:

    # MC "Will do."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:155
translate chinese CR2_ES2_menu_d8659007:

    # MC "I didn’t know you liked coffee, Caroline."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:157
translate chinese CR2_ES2_menu_21f62ffc:

    # MC "Whenever we went out as a family, you always used to order something cold, like pineapple juice."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:159
translate chinese CR2_ES2_menu_18ee5524:

    # MC "Whenever we went out you always used to order something cold like pineapple juice."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:163
translate chinese CR2_ES2_menu_2d6e6a69:

    # Caroline "That’s because this isn’t coffee. But very well remembered!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:164
translate chinese CR2_ES2_menu_ea35c550:

    # Caroline "I made myself some hot chocolate. Would you like some?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:165
translate chinese CR2_ES2_menu_d1c39269:

    # MC "Sure, I’ll have a sip."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:169
translate chinese CR2_ES2_menu_10f478c5:

    # Caroline "I’m a little disappointed that there were no marshmallows in the house."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:170
translate chinese CR2_ES2_menu_62bcc123:

    # Caroline "I love the way the mallows go all gooey and start to melt."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:171
translate chinese CR2_ES2_menu_72ff4e0f:

    # MC "Yeah, I know what you mean."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:175
translate chinese CR2_ES2_menu_c2b5c9a5:

    # MC "Shlurp!"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:176
translate chinese CR2_ES2_menu_9f711fe4:

    # Caroline "I should really buy some cream as well, to go on top."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:177
translate chinese CR2_ES2_menu_f6d1e608:

    # Caroline "That would be perfect..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:181
translate chinese CR2_ES2_menu_abc4df04:

    # MC "That tastes great! Thanks, Caroline."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:182
translate chinese CR2_ES2_menu_fc34f2e0:

    # Caroline "You’re very welcome, [player_name]."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:190
translate chinese CR2_ES2_menu_5a46360b:

    # MC "Are you feeling okay? You looked a bit sad when I entered the room."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:194
translate chinese CR2_ES2_menu_8e53382d:

    # Caroline "I’m great! Honestly - nothing wrong at all."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:195
translate chinese CR2_ES2_menu_6d545f5d:

    # MC "You’re not telling me the truth, Caroline."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:199
translate chinese CR2_ES2_menu_e80dd242:

    # Caroline "I’m not a great liar, am I?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:200
translate chinese CR2_ES2_menu_5289e673:

    # MC "No, you’re not. Tell me what’s bothering you though. It’s about the robbery, isn’t it?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:201
translate chinese CR2_ES2_menu_312e6386:

    # Caroline "*Sigh* It is."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:205
translate chinese CR2_ES2_menu_a547acfb:

    # Caroline "I spent sooo long working to prepare my shop for opening."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:206
translate chinese CR2_ES2_menu_5231ef3c:

    # Caroline "I was pulling twelve hour shifts ordering stock, planning the store layout, liaising with suppliers, and a hundred other things - JUST to get it up and running!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:207
translate chinese CR2_ES2_menu_f0af58db:

    # Caroline "And now, some STUPID burglar has gone and screwed it all up on me!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:211
translate chinese CR2_ES2_menu_5f56ef6e:

    # MC "It’s okay, Caroline. I understand how you feel. We’ll get through it, together."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:212
translate chinese CR2_ES2_menu_e38fd291:

    # Caroline "*Sniff* Thanks, [player_name]. I really don’t know how I’m going to get through this though..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:220
translate chinese CR2_ES2_menu_829b9a4f:

    # MC "Have you got any plans for today?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:224
translate chinese CR2_ES2_menu_959aced1:

    # Caroline "Err... not really. I was just going to spend the day at home, relaxing."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:225
translate chinese CR2_ES2_menu_24033676:

    # MC "You don’t feel like visiting the salon to take your mind off things?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:229
translate chinese CR2_ES2_menu_5fe88201:

    # Caroline "I don’t even have the money to afford a bus right now."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:230
translate chinese CR2_ES2_menu_6ab271c1:

    # Caroline "I can’t even afford to buy myself marshmallows and cream for this hot chocolate."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:231
translate chinese CR2_ES2_menu_c86341a5:

    # MC "Don’t worry, Caroline. We’ll get your life back on track."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:235
translate chinese CR2_ES2_menu_40195ebf:

    # Caroline "Thanks, [player_name]. I really hope so."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:243
translate chinese CR2_ES2_menu_429a314b:

    # MC "Have you heard back from the police yet, about the robbery?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:244
translate chinese CR2_ES2_menu_eec57016:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:248
translate chinese CR2_ES2_menu_441416cb:

    # Caroline "Nothing good."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:249
translate chinese CR2_ES2_menu_dcd62e34:

    # MC "Crap."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:250
translate chinese CR2_ES2_menu_00bce758:

    # Caroline "They told me that this wasn’t an urgent case for them."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:251
translate chinese CR2_ES2_menu_f12dec29:

    # Caroline "I rang up this morning, and they told me that it’s been too long since the incident, for them to investigate."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:252
translate chinese CR2_ES2_menu_f5a0ec3f:

    # Caroline "Apparently, any evidence that existed, could have been tampered with or lost."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:256
translate chinese CR2_ES2_menu_1b1e0c8d:

    # Caroline "They said they’d keep my case file open, but it isn't going to go anywhere unless I can name a suspect."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:257
translate chinese CR2_ES2_menu_55c681b5:

    # Caroline "I mean - why am I being expected to do the police’s job?!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:258
translate chinese CR2_ES2_menu_fd94baff:

    # MC "Shit, I’m sorry to hear that."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:265
translate chinese CR2_ES2_menu_3318cee5:

    # MC "When are you thinking of going back to work?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:266
translate chinese CR2_ES2_menu_a10c94f0:

    # Caroline "I’m kinda stuck between a rock and a hard place, right now."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:267
translate chinese CR2_ES2_menu_76d1e59d:

    # Caroline "I can’t stock my shop without money - and I can’t get money from the bank, unless I can provide evidence that I have a good cash flow."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:271
translate chinese CR2_ES2_menu_d8f63bb7:

    # Caroline "So, to put things mildly - I’m fucked."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:272
translate chinese CR2_ES2_menu_372bfe64:

    # MC "Shit. I’m sorry to hear that."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:273
translate chinese CR2_ES2_menu_40a69c11:

    # Caroline "I’ll get back on my feet - but it’s gonna take me a lot of time to get there."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:288
translate chinese CR2_ES2_menu_892c3547:

    # MC "Are you feeling any better today?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:289
translate chinese CR2_ES2_menu_ba61c90d:

    # Caroline "I... think so."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:290
translate chinese CR2_ES2_menu_54d87efe:

    # Caroline "I’m not feeling as depressed as I was, a couple of days ago."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:294
translate chinese CR2_ES2_menu_7683acf3:

    # Caroline "I think this is what they call, the acceptance stage? Although, I’ve never studied a day of psychology in my life - so I’m just guessing."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:295
translate chinese CR2_ES2_menu_b8d9cca7:

    # MC "(I hate seeing Caroline like this. A few days ago she was all excited about expanding her business and opening new stores.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:296
translate chinese CR2_ES2_menu_a3e6f74c:

    # MC "(Now she’s been reduced to, moping around on a sofa. Whoever robbed her deserves to pay for what they did!)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:300
translate chinese CR2_ES2_menu_9d6a5abd:

    # MC "If you ever want someone to talk to, you know I’m always free to listen."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:301
translate chinese CR2_ES2_menu_313f0125:

    # Caroline "I know that. Thanks, [player_name]."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:314
translate chinese CR2_ES2_bye_b9e20dd0:

    # Caroline "I think I’d rather spend some time alone now. I just need some time to try and clear my head."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:315
translate chinese CR2_ES2_bye_9ccb25ef:

    # Caroline "Is that okay?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:319
translate chinese CR2_ES2_bye_dfe548e6:

    # MC "Of course. If you need anything just call for me. Okay?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:320
translate chinese CR2_ES2_bye_e69333ee:

    # Caroline "I will. See you later, [player_name]."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:330
translate chinese CR2_ES2_bye_8d0e591a:

    # Caroline "I think I’d rather be alone again right now."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:331
translate chinese CR2_ES2_bye_76824f2e:

    # Caroline "I’ll talk to you later, okay?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:332
translate chinese CR2_ES2_bye_659e4993:

    # MC "No problem, Caroline. See you later."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:341
translate chinese CR2_ES2_bye_65a1a6d7:

    # Caroline "Are you okay if I spend a little bit of time alone?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:342
translate chinese CR2_ES2_bye_8a2dd911:

    # MC "Yeah, that’s not a problem."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:343
translate chinese CR2_ES2_bye_3f359d26:

    # Caroline "Sorry, I just have a lot of things in my head I need to think about right now."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:344
translate chinese CR2_ES2_bye_8c8621b6:

    # MC "It’s okay, I understand. I’ll see you later, Caroline."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:355
translate chinese CR2_ES2_bobtalk_d425db33:

    # MC "Have you told Mom or Dad about the robbery yet?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:357
translate chinese CR2_ES2_bobtalk_8626f3cf:

    # MC "Have you told Linda or Bob about the robbery yet?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:358
translate chinese CR2_ES2_bobtalk_260c7259:

    # Caroline "No! Absolutely not."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:359
translate chinese CR2_ES2_bobtalk_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:363
translate chinese CR2_ES2_bobtalk_115d04ca:

    # Caroline "I’m supposed to be the independent successful daugther."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:364
translate chinese CR2_ES2_bobtalk_10a776dd:

    # Caroline "I was the first born, and they both have high hopes for me."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:366
translate chinese CR2_ES2_bobtalk_125608f9:

    # Caroline "I took a major risk opening up a new business. Linda knew this and still supported me. She stands to lose out on thousands of dollars in rent if this business fails."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:367
translate chinese CR2_ES2_bobtalk_c657a9ed:

    # Caroline "I was the first tenant she ever had. I’ve lived here a long time. I’ve been reliable, trustworthy, and we’ve built up a good relationship. Linda has high hopes for me. I’d feel like shit if I admitted that I let her down."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:371
translate chinese CR2_ES2_bobtalk_bcc68669:

    # MC "Have they not asked why you’re off work at the minute?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:375
translate chinese CR2_ES2_bobtalk_5696cd58:

    # Caroline "Mom asked me, this morning..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:377
translate chinese CR2_ES2_bobtalk_ad575d98:

    # Caroline "Linda asked me, this morning..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:378
translate chinese CR2_ES2_bobtalk_c6a2cb6f:

    # MC "What did you tell her?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:379
translate chinese CR2_ES2_bobtalk_df209cd1:

    # Caroline "I said that business was going so well, that I could afford to take a few days off..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:383
translate chinese CR2_ES2_bobtalk_10580abc:

    # MC "Shit..."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:384
translate chinese CR2_ES2_bobtalk_142f58b3:

    # Caroline "Yeah, I shouldn’t have lied like that."
    Caroline ""

translate chinese strings:

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "{color=#00ff00}Do you know where I can find Violet?{/color}"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "I didn’t know you liked coffee."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "Are you sure you’re feeling okay? You looked a bit sad when I came in."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "Have you any plans for today?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "Have you heard from the police yet?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "When are you thinking of going back to work?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "Have you spoken to Mom or Dad about this robbery yet?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "Have you spoken to Linda or Bob about this robbery yet?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES2.rpy:118
    old "Are you feeling any better today?"
    new ""

