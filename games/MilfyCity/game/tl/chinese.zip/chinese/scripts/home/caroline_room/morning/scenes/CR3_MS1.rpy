﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:26
translate chinese CR3_MS1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:34
translate chinese CR3_MS1_label_010bea47_1:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:49
translate chinese CR3_MS1_label_05212dfe:

    # MC "(There’s Caroline, working away again. She never seems to stop or rest!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:50
translate chinese CR3_MS1_label_2531cd11:

    # MC "(Well, here we go. Let’s see if, I can break the ice and get our deal, back up and running.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:51
translate chinese CR3_MS1_label_b801c8fd:

    # MC "Morning, Caroline!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:55
translate chinese CR3_MS1_label_d973e800:

    # Caroline "Morning, [player_name]! Did you sleep well?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:57
translate chinese CR3_MS1_label_34a76121:

    # MC "Yeah - like a log!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:58
translate chinese CR3_MS1_label_4fed3562:

    # Caroline "Good to hear! What can I do for you?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:59
translate chinese CR3_MS1_label_0a2c945c:

    # MC "Nothing much - I just came to chat."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:71
translate chinese CR3_MS1_menu_76abc0bd:

    # MC "When you were young, did you always want to run your own business?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:75
translate chinese CR3_MS1_menu_a7763205:

    # Caroline "Heh... When - I was young - I wanted to be a princess."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:76
translate chinese CR3_MS1_menu_302cd56c:

    # MC "Haha! Seriously?!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:77
translate chinese CR3_MS1_menu_999ea639:

    # Caroline "Of course! Princesses are - insanely rich - and they’re powerful enough to - do whatever they want. They’re beholden to no one."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:81
translate chinese CR3_MS1_menu_fe877b3b:

    # MC "I see. So you grew out of your - princess fantasy - and matured, then started your own business."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:85
translate chinese CR3_MS1_menu_af4e1606:

    # Caroline "Why do you think I grew out of it? As far as I’m concerned, I’m closer to being a princess than I’ve - ever been - in my life."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:86
translate chinese CR3_MS1_menu_81d6e8fb:

    # MC "I’m not following you... What do you mean?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:90
translate chinese CR3_MS1_menu_4b493e5c:

    # Caroline "Just think about it – I’m independent, to run my own business and - do as I please. There’s no boss above me, dictating what I can and cannot do."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:92
translate chinese CR3_MS1_menu_eccb0abe:

    # Caroline "Now that I’ve got a steady stream of income. I’m not even worried about having to borrow money, from Mom and Dad."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:94
translate chinese CR3_MS1_menu_0f146e0c:

    # Caroline "Just think about it – I’m independent to run my own business and do as I please. There’s no boss above me dictating what I can and cannot do."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:95
translate chinese CR3_MS1_menu_8989f887:

    # Caroline "Now that I’ve got a steady stream of income I’m not even worried about having to ask for money."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:96
translate chinese CR3_MS1_menu_9620095a:

    # MC "Huh... I guess you’re right."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:100
translate chinese CR3_MS1_menu_423b9575:

    # Caroline "Of course I am – I’m the mother-fucking princess! Hehe!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:109
translate chinese CR3_MS1_menu_2c77ad86:

    # MC "Are you planning to expand your business, any time soon?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:110
translate chinese CR3_MS1_menu_83d80ebe:

    # Caroline "Not in the near future. The first two years of a private company, are always the toughest. I mean, just look how bad things were - a couple of weeks back. I was in a really bad place."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:114
translate chinese CR3_MS1_menu_25278432:

    # Caroline "The best thing for me to do right now, is play it safe and focus on my online sales. At the minute - the high streets are dying. If I open another store and the trend continues, I could - very quickly - find myself in the red."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:118
translate chinese CR3_MS1_menu_f863568f:

    # Caroline "Whereas, if I focus on online sales, I don’t need to concern myself with additional rent costs – I can operate entirely as a distributor."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:119
translate chinese CR3_MS1_menu_b70f07cc:

    # Caroline "I mean, in an age where people can simply log-on and order anything they want - with a few clicks, what could possibly entice people, to visit a brick and mortar store?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:120
translate chinese CR3_MS1_menu_45d3e047:

    # MC "Yeah, I see where you’re coming from. It sounds like you’re acting very sensibly."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:130
translate chinese CR3_MS1_menu_65c1bb71:

    # MC "Have you thought any more about our deal? I know the old one is gone - but perhaps we could... make a new one?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:131
translate chinese CR3_MS1_menu_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:132
translate chinese CR3_MS1_menu_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:136
translate chinese CR3_MS1_menu_19346abe:

    # Caroline "*Sigh* I thought I was PRETTY clear, the last time we talked. The deal is over, [player_name]. You’re just gonna have to - try to accept it - and move on."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:137
translate chinese CR3_MS1_menu_6e7d4f36:

    # MC "Wait, what if-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:141
translate chinese CR3_MS1_menu_1ea47cfc:

    # Caroline "No ‘ifs’ or ‘buts’, please, [player_name]. Don’t make this - any harder - than it needs to be."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:142
translate chinese CR3_MS1_menu_b4d441e0:

    # MC "Please, just hear me out. This doesn’t need to be over... If we just-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:146
translate chinese CR3_MS1_menu_92e006a5:

    # Caroline "If you keep pushing the topic, I’m going to have to put some distance between us."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:147
translate chinese CR3_MS1_menu_5b2bfd1d:

    # MC "Huh? What do you mean?!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:148
translate chinese CR3_MS1_menu_6f7b64e2:

    # Caroline "I’ll have to block your phone number and move out. I’m not sure where I’ll go, but I think I have a few friends I can - shack up with. This obsession you have, with our deal, is just... unhealthy. It’s over - and you NEED to move on."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:149
translate chinese CR3_MS1_menu_246cc65a:

    # MC "(Shit... Something - really has gotten to her. Did I come on too strong when we were fooling around together?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:166
translate chinese CR3_MS1_menu_e0c0841e:

    # MC "Have you thought any more about hiring a part-time employee?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:170
translate chinese CR3_MS1_menu_a434a74b:

    # Caroline "Yeah, it’s happening, and sorry, but before you ask – I can’t hire you."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:171
translate chinese CR3_MS1_menu_791e2c4d:

    # MC "Yeah, I guessed that. Have you got someone in mind?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:172
translate chinese CR3_MS1_menu_34c53f9d:

    # Caroline "I’ve got a couple of potential candidates. I need someone I can trust, though - so I’m being very cautious, before I commit myself to anyone, in particular."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:173
translate chinese CR3_MS1_menu_2b579d95:

    # MC "Well, if you ever need a volunteer, you know I’m always happy to-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:177
translate chinese CR3_MS1_menu_8a94e465:

    # Caroline "Absolutely not... I don’t think it would be appropriate, in the slightest - after everything that happened between us."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:178
translate chinese CR3_MS1_menu_33795da0:

    # MC "*Sigh* Yeah, I know."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:185
translate chinese CR3_MS1_menu_94b98a81:

    # MC "If you’re looking for someone to help out with your business, perhaps you could speak to Sara."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:189
translate chinese CR3_MS1_menu_7414288d:

    # Caroline "Seriously? She’s FAR too immature, and she has no proper work experience! Besides, she’s busy at college right now. I don’t want her working a job AND trying to keep her grades good!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:191
translate chinese CR3_MS1_menu_8a7b58db:

    # Caroline "Seriously? She's FAR too nerdy, and she has no proper work experience! Besides, she's busy at college right now. I don't want her working a job AND trying to keep her grades good!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:192
translate chinese CR3_MS1_menu_63ff1ecb:

    # MC "Yeah, I guess you’re right."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:200
translate chinese CR3_MS1_menu_bfe9e40f:

    # MC "Would you like to hang out sometime? Maybe dinner or a movie?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:204
translate chinese CR3_MS1_menu_d97d88ab:

    # Caroline "*Sigh* I know what you’re trying to do. I already told you - the deal is off."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:205
translate chinese CR3_MS1_menu_60eff775:

    # MC "What makes you think I was trying to get our deal back on?!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:208
translate chinese CR3_MS1_menu_e3f11a7b:

    # Caroline "Oh please... You’re a guy! I see through you, like a glass window."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:210
translate chinese CR3_MS1_menu_ea0f8004:

    # MC "(Damn! Am I really that easy to read?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:218
translate chinese CR3_MS1_menu_0281ed95:

    # MC "Okay, I better head on, here. Lots of things to do."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:219
translate chinese CR3_MS1_menu_d9abcf55:

    # Caroline "No problem, [player_name]. I’ll see you around."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:220
translate chinese CR3_MS1_menu_17259d01:

    # MC "Are you gonna be working on - this crap - all morning?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:224
translate chinese CR3_MS1_menu_decc2c59:

    # Caroline "Yeah - unfortunately. Tax returns are a fucking nightmare! I swear to God, I’ve been at this since six AM!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:225
translate chinese CR3_MS1_menu_5a01989d:

    # MC "Ugh! Best of luck with that!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:229
translate chinese CR3_MS1_menu_b82e5e31:

    # Caroline "See ya later, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:230
translate chinese CR3_MS1_menu_656127c7:

    # MC "Bye, Caroline!"
    MC ""

translate chinese strings:

    # game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:67
    old "When you were young, did you always want to run your own business?"
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:67
    old "Are you planning to expand your business, any time soon?"
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:67
    old "{color=#00ff00}Have you thought any more about our deal? Maybe we could make a new one?{/color}"
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:67
    old "Have you thought any more about hiring a part-time employee?"
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:67
    old "If you’re looking someone to help you out with your business, perhaps you could speak to Sara."
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR3_MS1.rpy:67
    old "Would you like to hang out sometime? Maybe dinner or a movie?"
    new ""

