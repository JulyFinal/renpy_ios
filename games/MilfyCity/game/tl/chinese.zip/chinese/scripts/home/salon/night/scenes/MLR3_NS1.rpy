﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:19
translate chinese MLR3_NS1_a4d1c8fd:

    # MC "(Let’s see what [Mom_name] and [Dad_name] are up to now. I can’t hear anything, so they’re probably both asleep anyway.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:26
translate chinese MLR3_NS1_10f7a572:

    # Dad "Zzz..."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:27
translate chinese MLR3_NS1_fda7bc81:

    # Mom "*Heavy Breathing*"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:28
translate chinese MLR3_NS1_a8c11f1d:

    # Mom "(Why do I feel so damn hot right now? I can’t get [player_name] out of my head."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:32
translate chinese MLR3_NS1_5baf3980:

    # Mom "(And every single time I close my eyes, I think back to that night in the beach house.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:33
translate chinese MLR3_NS1_5f7f741a:

    # Mom "(His raw hard cock, felt so good, deep inside me. It’s like a damn addiction. I need to feel it again. I NEED to be fucked by [player_name] again.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:34
translate chinese MLR3_NS1_fda7bc81_1:

    # Mom "*Heavy Breathing*"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:37
translate chinese MLR3_NS1_fbb3e5f5:

    # MC "([Mom_name]’s breathing really loudly. I wonder if she’s alright.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:41
translate chinese MLR3_NS1_427759a3:

    # Mom "(Fuck... I loved it when I felt his thick shaft, pushing up against my pussy for the first time.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:42
translate chinese MLR3_NS1_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:43
translate chinese MLR3_NS1_a395f2d8:

    # MC "(Is [Mom_name] masturbating?!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:47
translate chinese MLR3_NS1_dc1eee29:

    # Mom "Ah..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:48
translate chinese MLR3_NS1_b570d5eb:

    # MC "(She’s moaning, right now! There’s no doubt about it - she’s fingering herself while [Dad_name] sleeps.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:49
translate chinese MLR3_NS1_5a7f0a7c:

    # Mom "(Oh God... I need to book another night away with [player_name]. It needs to be longer next time though.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:53
translate chinese MLR3_NS1_f35839e7:

    # Mom "(One night wasn’t enough. I don’t want to feel rushed into leaving, when I wake up the next day.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:54
translate chinese MLR3_NS1_86b43224:

    # Mom "(I want to be able to hold him and cuddle beside him without stressing about having to come back to Bob.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:55
translate chinese MLR3_NS1_8b0d872c:

    # Mom "Ah... Ohh... Yes..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:59
translate chinese MLR3_NS1_17ac4e16:

    # Mom "(I can just imagine him, thrusting his thick cock, deep into me. No condom, just his hard dick, plunging again and again, into my soaking wet pussy.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:61
translate chinese MLR3_NS1_a7d22198:

    # Mom "Ah! Ahhh!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:62
translate chinese MLR3_NS1_459c3de1:

    # MC "(Wow! She’s really getting loud now!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:66
translate chinese MLR3_NS1_e0a8c3fd:

    # Mom "Oh! AH! AHHH!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:67
translate chinese MLR3_NS1_30287ffe:

    # MC "(It’s weird that [Dad_name] hasn’t woken up yet! Caroline and Sara can probably hear her, from the other side of the house!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:68
translate chinese MLR3_NS1_8edc9bf7:

    # Dad "Hmm..."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:72
translate chinese MLR3_NS1_9c1ef1f5:

    # Mom "AH! AHHH! OHH FUCK!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:73
translate chinese MLR3_NS1_ae0baad1:

    # Dad "Huh? What the..."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:74
translate chinese MLR3_NS1_76dd25c1:

    # Dad "(Is she... masturbating in the middle of the night?!)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:79
translate chinese MLR3_NS1_1c0e0cad:

    # Mom "(I can’t wait until I can feel his, steaming hot cum, flowing into my pussy again. The warmth spreading, deep inside me, as my boy fills me up.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:81
translate chinese MLR3_NS1_153168dd:

    # Mom "(I can’t wait until I can feel his steaming hot cum, flowing into my pussy again. The warmth spreading, deep inside me as [player_name] fills me up.)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:83
translate chinese MLR3_NS1_54d149c3:

    # Mom "Ah! AHHHHHH! Mmmmmmm! OHHHHH!!!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:84
translate chinese MLR3_NS1_c89f7710:

    # MC "(Uh oh... It looks like she’s woken up [Dad_name]!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:91
translate chinese MLR3_NS1_aafd0738:

    # Dad "Christ, Linda... What in God’s name are you doing? It’s the middle of the night."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:92
translate chinese MLR3_NS1_650f1e9a:

    # Dad "I don’t know about you, but I’m exhausted from my job - and if I can’t have sex in this bed, then for the love of God, at least let me have a good night’s sleep in it!"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:93
translate chinese MLR3_NS1_b40f0669:

    # Dad "I mean, seriously, Linda. You don’t want to have sex with me, but you’re creaming yourself, at 2am in the bloody morning!"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:97
translate chinese MLR3_NS1_fe1b5f2b:

    # Mom "Shit... Sorry for waking you. My bad."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:98
translate chinese MLR3_NS1_709b46d3:

    # Dad "My bad? Is that all you have to say about this?"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:99
translate chinese MLR3_NS1_70ba2273:

    # Mom "Yeah, I was too loud. My fault. Sorry."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:103
translate chinese MLR3_NS1_e80eab16:

    # Dad "Linda... I know this relationship is headed the way of the Titanic, but can we at least TRY to resolve our issues."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:104
translate chinese MLR3_NS1_dd3e0e53:

    # Dad "The only thing I want right now, is for you to open up and actually talk to me."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:105
translate chinese MLR3_NS1_570b132b:

    # Dad "Please... "
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:109
translate chinese MLR3_NS1_72daaeaf:

    # Mom " ..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:110
translate chinese MLR3_NS1_46abe98b:

    # Mom "I’m tired, Bob. I’m going to go to sleep now."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:111
translate chinese MLR3_NS1_d91ab79c:

    # Dad "*Sigh*"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:112
translate chinese MLR3_NS1_2af8d1e3:

    # Mom "I’m sorry for waking you up."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:113
translate chinese MLR3_NS1_b403152c:

    # Dad "Goodnight, Linda. Sorry I shouted, there. I love you."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR3_NS1.rpy:115
translate chinese MLR3_NS1_49ffb530:

    # MC "(Jesus Christ, they’re getting worse with each passing day. I wonder if I am the only cause of this. Maybe they were already on the rocks, before [Mom_name] and me hit it off?)"
    MC ""

