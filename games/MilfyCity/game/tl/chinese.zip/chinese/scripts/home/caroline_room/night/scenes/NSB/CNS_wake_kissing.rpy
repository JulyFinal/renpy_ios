﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:23
translate chinese CNS_wake_kissing_label_2ef1fc5f:

    # MC "Do you fancy making out tonight?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:24
translate chinese CNS_wake_kissing_label_a895566d:

    # Caroline "Here on the bed?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:25
translate chinese CNS_wake_kissing_label_f9b4c40f:

    # MC "Of course! Where else did you think we could go? Haha!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:29
translate chinese CNS_wake_kissing_label_f035dcc9:

    # Caroline "Hehe, sure. Let’s do it. I only have one request."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:30
translate chinese CNS_wake_kissing_label_940e8a8c:

    # MC "What is it?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:31
translate chinese CNS_wake_kissing_label_c34d7d49:

    # Caroline "Let me lead, this time."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:35
translate chinese CNS_wake_kissing_label_d60cf234:

    # MC "Be my guest, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:36
translate chinese CNS_wake_kissing_label_01b22400:

    # Caroline "Mmm... just like that. Perfect."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:40
translate chinese CNS_wake_kissing_label_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:41
translate chinese CNS_wake_kissing_label_6f4a657f:

    # MC "(Wow! She’s a better kisser than I imagined she would be!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:42
translate chinese CNS_wake_kissing_label_637bd755:

    # MC "(I love the way she’s running her fingers through my hair while she makes out with me.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:46
translate chinese CNS_wake_kissing_label_9d56d81d:

    # Caroline "(A couple of months ago, the very thought of this happening with him would have been a nightmare.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:47
translate chinese CNS_wake_kissing_label_002d690e:

    # Caroline "(Now it’s a wet dream come true...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:49
translate chinese CNS_wake_kissing_label_6c3be597:

    # Caroline "(I know he’s my brother and that it’s wrong, but there’s just something different when I kiss him. It’s not like any of the other guys I’ve been with before.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:51
translate chinese CNS_wake_kissing_label_f242b0b1:

    # Caroline "(I know he’s my best friend and that it’s wrong, but there’s just something different when I kiss him. It’s not at all like my ex! Is it really worth me risking our friendship for this?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:56
translate chinese CNS_wake_kissing_label_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:58
translate chinese CNS_wake_kissing_label_b0761b6b:

    # Caroline "(Sure my first ever kiss was exciting. It gave me a few butterflies in my stomach as we snuck behind the college bike shed.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:59
translate chinese CNS_wake_kissing_label_2554a0f6:

    # Caroline "(And the first time I ever kissed a guy while having sex, was amazing too. It was this nervous thrill.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:63
translate chinese CNS_wake_kissing_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:64
translate chinese CNS_wake_kissing_label_64a8e148:

    # Caroline "(But those butterflies never came back after the first kiss, and the sex was emotionless.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:65
translate chinese CNS_wake_kissing_label_2d371c69:

    # Caroline "(There’s something different about the time I spend with, [player_name].)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:70
translate chinese CNS_wake_kissing_label_8110dc64:

    # Caroline "Wow... That was... something else!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:71
translate chinese CNS_wake_kissing_label_5002b2a0:

    # MC "Heh, I’m glad you enjoyed it as much as I did!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:72
translate chinese CNS_wake_kissing_label_615c559c:

    # Caroline "We’re not finished yet!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:76
translate chinese CNS_wake_kissing_label_80d2b7b4:

    # Caroline "Down you go!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:77
translate chinese CNS_wake_kissing_label_a0d5a004:

    # MC "Wow! Oof!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:78
translate chinese CNS_wake_kissing_label_49c512e8:

    # Caroline "Hehe, gotcha!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:82
translate chinese CNS_wake_kissing_label_9dde8055:

    # MC "You have to keep your voice down. [Linda_name] might hear us!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:83
translate chinese CNS_wake_kissing_label_6d0ffb66:

    # Caroline "Screw them all! I’m here to enjoy myself!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:84
translate chinese CNS_wake_kissing_label_c2081040:

    # MC "That’s really not a wise-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:88
translate chinese CNS_wake_kissing_label_61faeaa5:

    # Caroline "Shut up and let me kiss you."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:89
translate chinese CNS_wake_kissing_label_459607f2:

    # MC "(Wow, it’s not like Caroline to throw caution to the wind. She must be insanely horny right now!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:93
translate chinese CNS_wake_kissing_label_206c0a31:

    # Caroline "(Every other guy I have ever dated, pales in comparison to the one guy I can’t date.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:94
translate chinese CNS_wake_kissing_label_bbbed34a:

    # Caroline "(With them, the butterflies in my stomach never came back after the first kiss.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:95
translate chinese CNS_wake_kissing_label_250454b7:

    # Caroline "(But with, [player_name], they never left.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:99
translate chinese CNS_wake_kissing_label_609432c2_1:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:101
translate chinese CNS_wake_kissing_label_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:102
translate chinese CNS_wake_kissing_label_e61f38fd:

    # Caroline "(Every single kiss is as thrilling and exciting as our first! Each one sets my heart racing. My whole body feels weightless when he wraps his arms around me.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:106
translate chinese CNS_wake_kissing_label_79174ef0:

    # Caroline "(It’s perfect - except for the fact he’s one guy in my age range that I’m not allowed to date.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:107
translate chinese CNS_wake_kissing_label_044fa551:

    # Caroline "(If anyone ever found out how I truly felt about him I would be shunned and despised.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:108
translate chinese CNS_wake_kissing_label_aba0f23d:

    # Caroline "(Why does the best relationship I’ve ever had, have to be a clandestine affair with my own brother?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:110
translate chinese CNS_wake_kissing_label_f9026f31:

    # Caroline "(It’s perfect - except for the fact he’s my best friend. If this relationship fails, then I lose far more than just a boyfriend.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:111
translate chinese CNS_wake_kissing_label_d897ed4b:

    # Caroline "(Why does the best potential relationship I’ve ever had, have to be so complicated?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:115
translate chinese CNS_wake_kissing_label_45469580:

    # Caroline "(Why couldn’t my heart just choose a nice single guy my age?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:116
translate chinese CNS_wake_kissing_label_d158f92a:

    # Caroline "(With each passing day I find myself growing more and more attracted to him. Wanting to do more intense things together.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:117
translate chinese CNS_wake_kissing_label_c2b748f8:

    # Caroline "(If this continues, could things extend beyond a simple deal?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:121
translate chinese CNS_wake_kissing_label_2cc70eb5:

    # Caroline "*Sigh*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:122
translate chinese CNS_wake_kissing_label_06127660:

    # MC "What’s wrong, Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_kissing.rpy:123
translate chinese CNS_wake_kissing_label_8cb6c56e:

    # Caroline "Nothing at all, [player_name]. I just need to stop overthinking things and live in the moment with you."
    Caroline ""

