﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:34
translate chinese CR2_ES1_label_73dcaed4:

    # MC "(I shouldn't bother her. She wants to be alone.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:48
translate chinese CR2_ES1_label_2d5e9ba3:

    # MC "(There’s Caroline! It looks like she’s spending the day relaxing in front of the TV.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:49
translate chinese CR2_ES1_label_0bce0f1c:

    # MC "(Let’s see how she’s doing.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:53
translate chinese CR2_ES1_label_bfb8a867:

    # MC "Hey, Caroline! What’s up?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:54
translate chinese CR2_ES1_label_0369ab6a:

    # Caroline "Oh! Hey, [player_name]. Nothing much. I’m just treating myself now that I’ve finally got some disposable income."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:55
translate chinese CR2_ES1_label_2124f99e:

    # MC "Awesome! The job must be really working out for you."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:59
translate chinese CR2_ES1_label_8a182709:

    # Caroline "It really is!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:60
translate chinese CR2_ES1_label_e067bbb1:

    # Caroline "What can I do for you?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:65
translate chinese CR2_ES1_label_1ab986bd:

    # MC "(Just like she said - she’s still hanging out in the Living Room in her free time.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:66
translate chinese CR2_ES1_label_6507b25f:

    # MC "(I may as well drop by and say hello.)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:70
translate chinese CR2_ES1_label_57ac936a:

    # MC "Hey again!"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:71
translate chinese CR2_ES1_label_ac755efb:

    # Caroline "Hi, [player_name]."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:82
translate chinese CR2_ES1_label_d7502d3b:

    # MC "(I think this must be Caroline's favourite thing to do after work!)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:83
translate chinese CR2_ES1_label_c9261959:

    # MC "(Does she ever go anywhere, apart from here and work?!)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:87
translate chinese CR2_ES1_label_ad3922b1:

    # MC "Here again?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:88
translate chinese CR2_ES1_label_81ee8bfd:

    # Caroline "Haha! Just putting my feet up, after work."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:93
translate chinese CR2_ES1_label_45894bd7:

    # Caroline "So, what brings you here?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:109
translate chinese CR2_ES1_menu_f3216001:

    # MC "I was looking for you."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:113
translate chinese CR2_ES1_menu_4e71bf60:

    # Caroline "Oh yeah? And what did you need me for?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:123
translate chinese CR2_ES1_menu_d7136fc8:

    # MC "How’s everything at work?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:124
translate chinese CR2_ES1_menu_1254df6e:

    # Caroline "Sales are booming. In fact, the biggest problem I’m having right now, is getting stock delivered to ME fast enough."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:125
translate chinese CR2_ES1_menu_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:129
translate chinese CR2_ES1_menu_7f753fbc:

    # Caroline "Seriously - I order in a bunch of clothes - and before I can even display them, they’ve been purchased online!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:130
translate chinese CR2_ES1_menu_e8e5746a:

    # MC "That’s amazing, Caroline! Congratulations!"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:135
translate chinese CR2_ES1_menu_9023d543:

    # Caroline "Haha! It’s high-stress though."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:136
translate chinese CR2_ES1_menu_8a1f3148:

    # Caroline "I swear - these lazy days are the only thing keeping me sane right now!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:137
translate chinese CR2_ES1_menu_54b50844:

    # MC "Don’t push yourself too hard!"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:145
translate chinese CR2_ES1_menu_d0356c5c:

    # MC "Have you spoken with Sara, lately?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:149
translate chinese CR2_ES1_menu_c49ab925:

    # Caroline "It’s... a bit sad. Sara and I have never really shared any common interests."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:150
translate chinese CR2_ES1_menu_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:151
translate chinese CR2_ES1_menu_11c36475:

    # Caroline "I don’t really like video games, and I’m not into the nerdy stuff that she is."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:152
translate chinese CR2_ES1_menu_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:156
translate chinese CR2_ES1_menu_f2334fd9:

    # Caroline "I mean, we still say hello to each other. But it’s not like we’d have a deep conversation like you and I do."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:157
translate chinese CR2_ES1_menu_72ff4e0f:

    # MC "Yeah, I know what you mean."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:166
translate chinese CR2_ES1_menu_dbb931c7:

    # MC "What are your plans for your business, going forward?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:167
translate chinese CR2_ES1_menu_c68b0237:

    # Caroline "I’m not sure."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:171
translate chinese CR2_ES1_menu_42e480a7:

    # Caroline "Honestly, I’m a bit overwhelmed right now. I am still the ONLY employee!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:172
translate chinese CR2_ES1_menu_fc5f624a:

    # Caroline "Maybe someday, I’d look into designing my own clothing line? Or opening up a chain of stores."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:176
translate chinese CR2_ES1_menu_df058054:

    # Caroline "Right now though, I’m content to focus on ensuring that my current store stays profitable."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:184
translate chinese CR2_ES1_menu_b429fb06:

    # MC "I wanted to talk about the deal we made."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:185
translate chinese CR2_ES1_menu_e70e05d2:

    # Caroline "What?!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:186
translate chinese CR2_ES1_menu_ad328bc7:

    # MC "The deal where-"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:190
translate chinese CR2_ES1_menu_4ee6bb05:

    # Caroline "Shush! Not in public."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:191
translate chinese CR2_ES1_menu_ebf40be5:

    # MC "Oh, come on! There’s nobody around to hear us."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:192
translate chinese CR2_ES1_menu_ae291c1a:

    # Caroline "I am NOT talking about this with you in the middle of the living room!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:193
translate chinese CR2_ES1_menu_f373c466:

    # MC "Fine! We’ll chat later."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:206
translate chinese CR2_ES1_menu_9cf2998b:

    # MC "Caroline, I was wondering - do you have any advice for finding a girlfriend?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:207
translate chinese CR2_ES1_menu_cc7cc9b9:

    # Caroline "Sure. What part are you having trouble with?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:208
translate chinese CR2_ES1_menu_9cbfc5f1:

    # MC "All of it."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:212
translate chinese CR2_ES1_menu_831d2607:

    # Caroline "Haha! Okay then!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:213
translate chinese CR2_ES1_menu_871851e0:

    # Caroline "Let’s start with the basics."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:217
translate chinese CR2_ES1_menu_8a3187db:

    # Caroline "Make sure you wash, wear clean clothes, and take care of your appearance."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:218
translate chinese CR2_ES1_menu_8c496061:

    # Caroline "After that, you can work on your personality. People like confidence."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:222
translate chinese CR2_ES1_menu_23066912:

    # Caroline "Just go up to a girl that you like, put your hand on her shoulder and ask if you can buy her a coffee."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:223
translate chinese CR2_ES1_menu_20504e7b:

    # Caroline "It’s that easy."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:227
translate chinese CR2_ES1_menu_ce18c1ce:

    # MC "It didn't work that way with Ms. Celia."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:228
translate chinese CR2_ES1_menu_d6a49e17:

    # Caroline "That’s because she was your professor! There’s certain boundaries you shouldn’t cross."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:232
translate chinese CR2_ES1_menu_3aa34e05:

    # Caroline "Don’t stress about all this too much. It’ll come to you eventually."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:233
translate chinese CR2_ES1_menu_ae44b462:

    # Caroline "For the meantime, just focus on doing what you enjoy. Develop your hobbies and interests."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:242
translate chinese CR2_ES1_menu_58ede5af:

    # Caroline "So, what about you and Sara? I’ve seen you two hanging out together, more than usual."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:248
translate chinese CR2_ES1_menu_660c765f:

    # MC "Sara and I have always been fairly close. "
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:249
translate chinese CR2_ES1_menu_f5851052:

    # Caroline "Yeah, you’re lucky to have that connection with her!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:256
translate chinese CR2_ES1_menu_d8d00232:

    # MC "I don’t really feel connected to Sara."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:257
translate chinese CR2_ES1_menu_07b16737:

    # MC "I don’t know if it’s an age thing perhaps, but we don’t seem to have that much in common."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:258
translate chinese CR2_ES1_menu_11919ade:

    # Caroline "Aww, I’m sorry to hear that. Hopefully she’ll mature more, in the coming years."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:259
translate chinese CR2_ES1_menu_23723689:

    # MC "Yeah, I hope so too."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:266
translate chinese CR2_ES1_menu_2cf22947:

    # MC "Yeah, Sara and I have been having an incestuous relationship."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:267
translate chinese CR2_ES1_menu_1b226785:

    # Caroline "[player_name]!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:271
translate chinese CR2_ES1_menu_407a539d:

    # Caroline "Haha! You have a SICK sense of humour!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:272
translate chinese CR2_ES1_menu_32621a68:

    # MC "(If only she knew the truth!)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:279
translate chinese CR2_ES1_menu_9065120e:

    # MC "Yeah, Sara and I have been fucking for a while now."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:280
translate chinese CR2_ES1_menu_1b226785_1:

    # Caroline "[player_name]!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:284
translate chinese CR2_ES1_menu_d49835ff:

    # Caroline " Haha! You have a twisted sense of humour!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:285
translate chinese CR2_ES1_menu_32621a68_1:

    # MC "(If only she knew the truth!)"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:297
translate chinese CR2_ES1_menu_cancel_0bf1e9cd:

    # Caroline "Let me finish watching my program. I’ll see you later on."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:301
translate chinese CR2_ES1_menu_cancel_cad0fb05:

    # Caroline "Be good, okay?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:302
translate chinese CR2_ES1_menu_cancel_288ca8e8:

    # MC "Don’t worry, I will! See you later, Caroline!"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:311
translate chinese CR2_ES1_menu_cancel_421c866f:

    # Caroline "Time for me to rest my feet. I’ll see you later, [player_name]."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:312
translate chinese CR2_ES1_menu_cancel_656127c7:

    # MC "Bye, Caroline!"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:320
translate chinese CR2_ES1_menu_cancel_8e2f8fc7:

    # Caroline "Let me finish watching my TV series. I’ll see you later on."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:321
translate chinese CR2_ES1_menu_cancel_133c4cb9:

    # MC "Bye, Caroline."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:331
translate chinese CR2_ES1_menu_bobfight_94a2a4eb:

    # MC "Are Mom and Dad fighting at the minute?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:333
translate chinese CR2_ES1_menu_bobfight_4255a9c7:

    # MC "Are Linda and Bob fighting at the minute?"
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:334
translate chinese CR2_ES1_menu_bobfight_056deb70:

    # Caroline "What makes you think that?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:335
translate chinese CR2_ES1_menu_bobfight_2cc93c19:

    # MC "Things have just seemed... tense between them."
    MC ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:336
translate chinese CR2_ES1_menu_bobfight_9ea1690f:

    # Caroline "They go through ups and downs."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:340
translate chinese CR2_ES1_menu_bobfight_b4cae366:

    # Caroline "For as long as I can remember, those two have always had their good moments and their bad moments."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:341
translate chinese CR2_ES1_menu_bobfight_97e134af:

    # Caroline "At the end of the day, they’ve always pulled through. I don’t see any reason why this bad moment should be any different."
    Caroline ""

# game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:342
translate chinese CR2_ES1_menu_bobfight_566d8ee8:

    # MC "Yeah, hopefully you’re right."
    MC ""

translate chinese strings:

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "I was looking for you."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "How’s work going?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "Have you spoken with Sara, lately?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "What are your plans for the business, going forward?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "I wanted to talk about the deal we made."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "Are Mom and Dad fighting?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "Are Linda and Bob fighting?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:105
    old "Have you any advice for finding a girlfriend?"
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:244
    old "We’re fairly close."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:244
    old "I don’t really feel connected to her."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:244
    old "Sara and I are having an incestuous relationship."
    new ""

    # game/scripts/home/salon/evening/scenes/CR2_ES1.rpy:244
    old "Sara and I are fucking."
    new ""

