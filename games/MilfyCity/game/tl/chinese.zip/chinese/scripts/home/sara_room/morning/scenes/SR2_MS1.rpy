﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:16
translate chinese SR2_MS1_label_2178f9d0:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:17
translate chinese SR2_MS1_label_4a772e70:

    # MC "(It's better not to wake her up at the moment.)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:26
translate chinese SR2_MS1_label_3e5bee0d:

    # MC "Sara, it’s almost time to go to college. Are you ready?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:27
translate chinese SR2_MS1_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:28
translate chinese SR2_MS1_label_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:36
translate chinese SR2_MS1_label_c8b18188_1:

    # MC "Sara?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:37
translate chinese SR2_MS1_label_2178f9d0_1:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:38
translate chinese SR2_MS1_label_83c37788:

    # MC "(Has she just fallen asleep at her desk?)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:42
translate chinese SR2_MS1_label_9c7c2306:

    # MC "Hey Sara... You’ve got five minutes until we have to leave for college."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:43
translate chinese SR2_MS1_label_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:44
translate chinese SR2_MS1_label_6fdb1ce5:

    # MC "Sara, you have to wake up!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:48
translate chinese SR2_MS1_label_2c04d20e:

    # Sara "Hmm?"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:49
translate chinese SR2_MS1_label_8f8fe70e:

    # MC "(Jesus, she looks exhausted! Is she sick or something?)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:50
translate chinese SR2_MS1_label_ecda2f31:

    # MC "Are you okay, Sara? You don’t look well."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:51
translate chinese SR2_MS1_label_4aae9075:

    # Sara "N-No... I’m fine. I’m good. Don’t worry."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:55
translate chinese SR2_MS1_label_1132f3c8:

    # MC "Are you sure? You look completely exhausted!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:56
translate chinese SR2_MS1_label_48347387:

    # Sara "I... don’t think I went to bed last night. Last thing I remember was grinding online with my clan... I must have dozed off during a raid."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:57
translate chinese SR2_MS1_label_80ac88c0:

    # MC "Ahh, that explains it, then. "
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:58
translate chinese SR2_MS1_label_a9573b8b:

    # Sara "Ugh, do I have to go to college today?"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:60
translate chinese SR2_MS1_label_a353046f:

    # MC "If you miss class, Mom’s gonna freak out."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:62
translate chinese SR2_MS1_label_8d4746d5:

    # MC "If you miss class, Linda is going to call your parents! Do you think they want an unemployed NEET in their house?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:66
translate chinese SR2_MS1_label_5a339490:

    # Sara "*Sigh* You’re right."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:67
translate chinese SR2_MS1_label_f04128ac:

    # MC "Go and take a shower. I’ll see you in college."
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:68
translate chinese SR2_MS1_label_ce392f38:

    # Sara "Okay... *YAWN!* See you there, [player_name]."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:72
translate chinese SR2_MS1_label_1708a83e:

    # MC "Sara, watch out for the doo-"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:74
translate chinese SR2_MS1_label_933aa022:

    # "*THUD*"
    ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:75
translate chinese SR2_MS1_label_0f0522a6:

    # Sara "Oww!"
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:76
translate chinese SR2_MS1_label_0c87399c:

    # MC "(Well, I guess that’s one way to wake someone up!)"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:80
translate chinese SR2_MS1_label_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:81
translate chinese SR2_MS1_label_b4e5789a:

    # Sara "Y-Yeah, my nose isn’t bleeding. I’m okay."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:82
translate chinese SR2_MS1_label_35d7ee9a:

    # MC "You’ve still got your headphones on too - make sure you don’t go into the shower with them on!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:86
translate chinese SR2_MS1_label_72a92388:

    # Mom "ARE YOU TWO ALMOST READY? YOU’RE GOING TO BE LATE FOR YOUR COURSES!"
    Mom ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:88
translate chinese SR2_MS1_label_58a29698:

    # Sara "*Yawn* Y-Yeah, Mom! I’m almost ready..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:90
translate chinese SR2_MS1_label_20df6446:

    # Sara "*Yawn* Y-Yeah, Linda! I’m almost ready..."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:91
translate chinese SR2_MS1_label_793881dc:

    # Sara "Okay, I’m gonna take a quick shower. I might be a few minutes late to my lecture. You head on, first."
    Sara ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:92
translate chinese SR2_MS1_label_d9a46118:

    # MC "Catch you later, Sara!"
    MC ""

# game/scripts/home/sara_room/morning/scenes/SR2_MS1.rpy:93
translate chinese SR2_MS1_label_018a7803:

    # MC "(I hope these all-nighters that she’s pulling don’t impact her grades too much...)"
    MC ""

