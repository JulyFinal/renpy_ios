﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:41
translate chinese mc_sara_night_scene1_v1_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:42
translate chinese mc_sara_night_scene1_v1_label_9ff988d7:

    # Sara "(I wonder if he’s definitely asleep.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:43
translate chinese mc_sara_night_scene1_v1_label_b9e173d1:

    # Sara "[player_name]? Are you awake?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:44
translate chinese mc_sara_night_scene1_v1_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:47
translate chinese mc_sara_night_scene1_v1_label_8a0e30e9:

    # Sara "(Okay, you can do this, Sara. Be brave!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:48
translate chinese mc_sara_night_scene1_v1_label_f4e84a75:

    # Sara "(You have to get this picture of his cock, for Lily.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:49
translate chinese mc_sara_night_scene1_v1_label_dcd9cf27:

    # Sara "(Then you can prove that you’re cool, and not just a nerdy virgin!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:52
translate chinese mc_sara_night_scene1_v1_label_e0bbdb0b:

    # Sara "(Hey, this is easier than I thought it would be! He’s only in his boxer shorts!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:53
translate chinese mc_sara_night_scene1_v1_label_04dca295:

    # Sara "(I just need to strip these off him, then start moving his cock until it gets, all stiff and hard...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:54
translate chinese mc_sara_night_scene1_v1_label_fd55ac23:

    # Sara "(...like that time in my bedroom, when he pressed it up against my belly.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:57
translate chinese mc_sara_night_scene1_v1_label_77fb772d:

    # Sara "(Wow... It always takes my breath away, each time I see it!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:58
translate chinese mc_sara_night_scene1_v1_label_b45590d9:

    # Sara "(It feels like there’s a hundred tiny butterflies in my belly right now!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:59
translate chinese mc_sara_night_scene1_v1_label_3f5aa6a2:

    # Sara "(I don’t think I even need to move his cock at all... it’s already quite stiff!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:62
translate chinese mc_sara_night_scene1_v1_label_254234d1:

    # Sara "(I’ll just take a quick picture of it, then sneak out of his bedroom.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:63
translate chinese mc_sara_night_scene1_v1_label_b8b30cfa:

    # Sara "([player_name] won’t even know I was in here! Haha! Perfect!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:64
translate chinese mc_sara_night_scene1_v1_label_85b8a1e4:

    # Sara "(On the other hand... maybe I could touch his cock, just a little bit...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:67
translate chinese mc_sara_night_scene1_v1_label_d9d5f159:

    # Sara "(Yeah, I should rub it a bit - just to get a better picture, of course.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:68
translate chinese mc_sara_night_scene1_v1_label_e317ff00:

    # Sara "(Wow... it’s getting so much bigger and harder!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:69
translate chinese mc_sara_night_scene1_v1_label_15a1eb0e:

    # Sara "(I wonder how long I should do this for?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:73
translate chinese mc_sara_night_scene1_v1_label_2bcec930:

    # MC "Boo!"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:77
translate chinese mc_sara_night_scene1_v1_label_689da9c4:

    # Sara "EEEKKK!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:78
translate chinese mc_sara_night_scene1_v1_label_c409b2fa:

    # Sara "(AHHH! He woke up!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:81
translate chinese mc_sara_night_scene1_v1_label_350dc75b:

    # Sara "I- I- *Sniff* I’m s-so sorry!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:82
translate chinese mc_sara_night_scene1_v1_label_075b7b0d:

    # MC "What were you doing?"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:83
translate chinese mc_sara_night_scene1_v1_label_f4559248:

    # Sara "I was... I was... *sob* t-trying to take a... picture..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:84
translate chinese mc_sara_night_scene1_v1_label_19249ffd:

    # MC "Don’t you already have one on your phone?"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:87
translate chinese mc_sara_night_scene1_v1_label_91330c36:

    # Sara "I... wanted another..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:88
translate chinese mc_sara_night_scene1_v1_label_f4d4e06e:

    # Sara "Please forgive me. I’m sooo sorry! *Sob*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:90
translate chinese mc_sara_night_scene1_v1_label_39f8e28f:

    # Sara "I’ll- I’ll do anything! Just don’t tell Dad!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:93
translate chinese mc_sara_night_scene1_v1_label_02015110:

    # MC "Hey - relax. I won’t tell Dad."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:95
translate chinese mc_sara_night_scene1_v1_label_a02a44b6:

    # Sara "I’ll- I’ll do anything! Just don’t tell Bob!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:98
translate chinese mc_sara_night_scene1_v1_label_97002589:

    # MC "Hey - relax. I won’t tell Bob."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:99
translate chinese mc_sara_night_scene1_v1_label_87bd0b39:

    # Sara "Th-Thank you. *Sniff* I’ll do anything for you."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:100
translate chinese mc_sara_night_scene1_v1_label_8dbf01a8:

    # Sara "O-Or to you!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:103
translate chinese mc_sara_night_scene1_v1_label_971d0c08:

    # MC "Come on into bed and sleep beside me tonight."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:104
translate chinese mc_sara_night_scene1_v1_label_984d1307:

    # Sara "Th...that’s all?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:105
translate chinese mc_sara_night_scene1_v1_label_2de90f31:

    # MC "Yeah, climb in beside me. It’s warm under the covers."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:108
translate chinese mc_sara_night_scene1_v1_label_d01d807c:

    # Sara "Th...thank you... I’m so sorry. *Sniff*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:109
translate chinese mc_sara_night_scene1_v1_label_204e07d7:

    # MC "Hey - it’s alright. Dry your eyes. Try to breathe."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:110
translate chinese mc_sara_night_scene1_v1_label_39d6aa09:

    # MC "If you were THAT desperate for a picture of my junk, you could have just asked."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:113
translate chinese mc_sara_night_scene1_v1_label_8abc9110:

    # Sara "Hehe... You always make me laugh so easily..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:114
translate chinese mc_sara_night_scene1_v1_label_76a23dad:

    # MC "That’s better. Let’s get rid of those tears."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:115
translate chinese mc_sara_night_scene1_v1_label_fe6106c0:

    # MC "I’ll shuffle over here, so there’s room for you."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:118
translate chinese mc_sara_night_scene1_v1_label_81a3db98:

    # Sara "Thanks, [player_name]..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:119
translate chinese mc_sara_night_scene1_v1_label_c4dc94fb:

    # MC "You still look a little stressed. Is everything alright?"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:120
translate chinese mc_sara_night_scene1_v1_label_42e6c5dc:

    # Sara "Actually... I wanted to ask you something..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:125
translate chinese mc_sara_night_scene1_v1_label_a889ea1b:

    # Sara "D...Do you... like me?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:126
translate chinese mc_sara_night_scene1_v1_label_f4964229:

    # Sara "B-Because after everything that happened - with the videogames, Lily, you.. and me..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:127
translate chinese mc_sara_night_scene1_v1_label_8abe0961:

    # Sara "Y-you said.. I’m nice.. s-sexy..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:128
translate chinese mc_sara_night_scene1_v1_label_59ccb7d7:

    # Sara "I... I just need to know..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:133
translate chinese mc_sara_night_scene1_v1_label_4e7f78b1:

    # Sara "(Please say yes...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:134
translate chinese mc_sara_night_scene1_v1_label_1693b99d:

    # MC "Yes, Sara. I really like you."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:136
translate chinese mc_sara_night_scene1_v1_label_f615a575:

    # MC "Honestly, I thought it would have been pretty obvious."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:137
translate chinese mc_sara_night_scene1_v1_label_78d374f4:

    # Sara "(Oh, my God!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:142
translate chinese mc_sara_night_scene1_v1_label_554dca11:

    # Sara "I- I- I can’t believe I just asked you that. G-Go back to sleep."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:143
translate chinese mc_sara_night_scene1_v1_label_fe9284ca:

    # Sara "Forget what I just said!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:145
translate chinese mc_sara_night_scene1_v1_label_58732214:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?! And he’s your brother!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:147
translate chinese mc_sara_night_scene1_v1_label_82c1da2a:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:148
translate chinese mc_sara_night_scene1_v1_label_928adda7:

    # MC "(Huh?! Women are strange...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:157
translate chinese mc_sara_night_scene1_v1_label_dc741cc8:

    # Sara "Because I think I like you... more than a brother..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:159
translate chinese mc_sara_night_scene1_v1_label_fdec6962:

    # Sara "Because I think I like you... more than a friend..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:160
translate chinese mc_sara_night_scene1_v1_label_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:161
translate chinese mc_sara_night_scene1_v1_label_4e7f78b1_1:

    # Sara "(Please say yes...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:162
translate chinese mc_sara_night_scene1_v1_label_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:163
translate chinese mc_sara_night_scene1_v1_label_54152fe9:

    # Sara "(Please, [player_name]... say anything...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:164
translate chinese mc_sara_night_scene1_v1_label_2d204a49_3:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:168
translate chinese mc_sara_night_scene1_v1_label_13ca058f:

    # Sara "N-Nevermind! I- Forget I asked you about it!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:170
translate chinese mc_sara_night_scene1_v1_label_58732214_1:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?! And he’s your brother!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:172
translate chinese mc_sara_night_scene1_v1_label_82c1da2a_1:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:173
translate chinese mc_sara_night_scene1_v1_label_e7bf0527:

    # Sara "(You shouldn’t have put him in that position! You could ruin your relationship with him!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:174
translate chinese mc_sara_night_scene1_v1_label_71418457:

    # MC "Are you okay, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:175
translate chinese mc_sara_night_scene1_v1_label_e6b63ba6:

    # Sara "J-Just go to sleep, you b-big dumbo!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:183
translate chinese after_mc_sara_night_scene1_v1_choice_01d1f46d:

    # MC "*YAWN!*"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:184
translate chinese after_mc_sara_night_scene1_v1_choice_037ecab5:

    # MC "(Looks like Sara left during the night. I wonder when she snuck out. I’ll probably see her around college today anyway.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/mc_sara_night_scene1_v1.rpy:185
translate chinese after_mc_sara_night_scene1_v1_choice_813b79bf:

    # MC "(I’ve never seen her that emotional before.)"
    MC ""

