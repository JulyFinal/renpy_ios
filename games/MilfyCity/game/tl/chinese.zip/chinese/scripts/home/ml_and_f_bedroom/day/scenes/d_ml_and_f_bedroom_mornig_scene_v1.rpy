﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:29
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_4ac4c319:

    # Dad "Not now, [player_name]."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:34
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_4ac4c319_1:

    # Dad "Not now, [player_name]."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:47
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_872c173d:

    # MC "Uhh... Hey Dad, you busy right now?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:49
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_60515191:

    # MC "Uhh... Hey Bob, you busy right now?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:50
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_66e0a412:

    # Dad "Hmm?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:53
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_501a1847:

    # Dad "Oh! Hello, champ! What’s kickin’?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:54
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:55
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_a53c90e2:

    # Dad "What’s kickin’? That's what you boys says nowadays, ain't it?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:56
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_be2be073:

    # MC "Um... Sure."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:59
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_f7832447:

    # Dad "What did you want, then?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:66
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_4b4d0951:

    # MC "Hey, Dad!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:68
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_be8f25fd:

    # MC "Hey, Bob!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:70
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_99c1e8c1:

    # Dad "Hey there, champ. What’s up?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:79
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_df3b5752:

    # MC "Hi, Dad!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:81
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_15fbc0e7:

    # MC "Hi, Bob!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:82
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_d6436b81:

    # Dad "Hey, champ!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:84
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_5bcadb10:

    # Dad "What can I do for you?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:90
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_74a9ac04:

    # MC "Could I borrow some more money?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:92
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_4ad345fa:

    # Dad "Huh? Again?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:93
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_4bd5be1b:

    # Dad "You should try finding a way to earn an honest living. It’s not good to just beg and beg."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:96
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_8b16535f:

    # Dad "I think your mother is always looking for extra help. I’m sure she’d be happy to pay you for your time."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:98
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_f1c3a0a6:

    # Dad "I think Linda is always looking for extra help. I’m sure she’d be happy to pay you for your time."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:99
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_a20fcc70:

    # MC "Aww, okay. Thanks anyway."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:101
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_7578c2c5:

    # Dad "Don’t look so down, champ! A little hard work never killed anybody!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:102
translate chinese d_ml_and_f_bedroom_mornig_scene_v1_label_5f6c3e63:

    # MC "(I’m not quite sure that’s completely true...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:125
translate chinese Bob_menu_money_ask1_a05aa16f:

    # MC "I’m actually a bit short on cash, Dad. Could you maybe lend me some?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:127
translate chinese Bob_menu_money_ask1_4a69f7e9:

    # MC "I’m actually a bit short on cash, Bob. Could you maybe lend me some?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:128
translate chinese Bob_menu_money_ask1_9befaf53:

    # Dad "Haha! You’ve spent all your money chasing girls, haven’t you?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:129
translate chinese Bob_menu_money_ask1_817fc382:

    # Dad "Let me take a look in my wallet..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:131
translate chinese Bob_menu_money_ask1_7ee5227f:

    # Dad "Alright, here you go. Don’t spend it all in one place, now!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:133
translate chinese Bob_menu_money_ask1_7b6bd3ac:

    # MC "Thanks, Dad!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:135
translate chinese Bob_menu_money_ask1_93295ed4:

    # MC "Thanks, Bob!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:138
translate chinese Bob_menu_money_ask1_075412a7:

    # "+15$"
    ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:150
translate chinese Bob_menu_money_ask1_42206229:

    # MC "How are things at work?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:152
translate chinese Bob_menu_money_ask1_0d38fe66:

    # Dad "Aww, jeez. Where to begin?!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:153
translate chinese Bob_menu_money_ask1_40fe592b:

    # Dad "Emily, from human resources, has just been sacked for selling private medical data."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:154
translate chinese Bob_menu_money_ask1_02fe1d21:

    # Dad "So now, I have to carry out a whole risk assessment on the company’s entire Eastern Branch!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:155
translate chinese Bob_menu_money_ask1_f7435608:

    # MC "Ugh, sounds rough!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:156
translate chinese Bob_menu_money_ask1_c2fbfdb8:

    # MC "(I have no idea what he even works as...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:167
translate chinese Bob_menu_money_ask1_d6bab4b7:

    # MC "Have you got anything fun planned for today, then?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:169
translate chinese Bob_menu_money_ask1_c78d2dd8:

    # Dad "Nothing much today. I’ll probably help your mom vacuum, later on."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:171
translate chinese Bob_menu_money_ask1_99c52d98:

    # Dad "Nothing much today. I’ll probably help Linda vacuum, later on."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:172
translate chinese Bob_menu_money_ask1_89a108c3:

    # Dad "Tomorrow though, I’m gonna go to a lecture on fly fishing at the local library."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:173
translate chinese Bob_menu_money_ask1_5a198278:

    # MC "Err... Wow! Sounds... exciting."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:174
translate chinese Bob_menu_money_ask1_a7844e2a:

    # Dad "I know, right? In fact, did you know that there are seven different species of salmon in the Pacific Ocean alone? SEVEN! Can you believe that?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:175
translate chinese Bob_menu_money_ask1_71281850:

    # MC "Fascinating. (God, I better get out of here or change the subject, before he starts another one of his fishing rants.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:189
translate chinese Bob_menu_money_ask2_e6cc99a0:

    # MC "I just realised that I don’t actually know what you work as."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:190
translate chinese Bob_menu_money_ask2_97abdf61:

    # Dad "Really? I’m a company risk assessor."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:192
translate chinese Bob_menu_money_ask2_41f4eedd:

    # Dad "It’s my job to travel to our various sites and take steps to minimise risk."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:193
translate chinese Bob_menu_money_ask2_0ad8881d:

    # Dad "I’m also in charge of managing our insurance policies for the Eastern Business Centres."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:194
translate chinese Bob_menu_money_ask2_f133e676:

    # MC "(Damn... I’m sorry I asked.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:206
translate chinese Bob_menu_money_ask2_f5d9d6f5:

    # MC "Could I borrow some more money, Dad?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:208
translate chinese Bob_menu_money_ask2_4ab06c69:

    # MC "Could I borrow some more money, Bob?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:209
translate chinese Bob_menu_money_ask2_2d6d9fb5:

    # Dad "What happened to the money I just lent you?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:210
translate chinese Bob_menu_money_ask2_1982fd3e:

    # MC "Err... I had to spend it on... essential college stuff."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:211
translate chinese Bob_menu_money_ask2_d19f00a7:

    # Dad "Damn, colleges are getting expensive nowadays!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:213
translate chinese Bob_menu_money_ask2_8099e5f8:

    # Dad "I haven’t had a chance to go to an ATM - so this is all I have on me right now."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:215
translate chinese Bob_menu_money_ask2_778843c5:

    # MC "Thanks, Dad."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:217
translate chinese Bob_menu_money_ask2_94a28d90:

    # MC "Thanks, Bob."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:218
translate chinese Bob_menu_money_ask2_29b0bad8:

    # Dad "No problem, champ."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:219
translate chinese Bob_menu_money_ask2_87951679:

    # "+30$"
    ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:233
translate chinese Bob_menu_money_ask2_7062e410:

    # MC "So, how was the fly fishing lecture?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:235
translate chinese Bob_menu_money_ask2_b26676ee:

    # Dad "You should have been there! It was INCREDIBLE!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:236
translate chinese Bob_menu_money_ask2_78877325:

    # MC "(Oh God... I’ve set him off again.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:237
translate chinese Bob_menu_money_ask2_57e51f5d:

    # "(Fifteen Minutes Later...)"
    ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:241
translate chinese Bob_menu_money_ask2_0a121ba9:

    # Dad "And THAT was just the guest speaker!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:242
translate chinese Bob_menu_money_ask2_be412d4a:

    # MC "(Now’s my chance to finally change the conversation topic!)"
    MC ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:85
    old "{color=#00ff00}Could I borrow some more money?{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:119
    old "{color=#00ff00}Can you give me some money?{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:119
    old "How are things at work?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:119
    old "Have you got anything fun planned?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:185
    old "What do you actually work as?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:185
    old "{color=#00ff00}Can I borrow some more money?{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/d_ml_and_f_bedroom_mornig_scene_v1.rpy:185
    old "How was that fly fishing lecture?"
    new ""

