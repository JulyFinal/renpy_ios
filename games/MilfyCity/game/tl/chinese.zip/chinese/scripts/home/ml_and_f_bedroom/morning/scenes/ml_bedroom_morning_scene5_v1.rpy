﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:42
translate chinese ml_bedroom_morning_scene5_v1_label_65070606:

    # MC "(I think Mom’s changing now. If I’m quick I might be able to sneak a peek!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:44
translate chinese ml_bedroom_morning_scene5_v1_label_ff1f9210:

    # MC "(I think Linda’s changing now. If I’m quick I might be able to sneak a peek!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:46
translate chinese ml_bedroom_morning_scene5_v1_label_c9001286:

    # MC "(Perfect timing!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:47
translate chinese ml_bedroom_morning_scene5_v1_label_0bfa772c:

    # MC "(Damn! She’s got an incredible ass. And she looks so sexy in those black high heels.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:50
translate chinese ml_bedroom_morning_scene5_v1_label_510fdae1:

    # MC "(No! She’s walking out of sight!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:51
translate chinese ml_bedroom_morning_scene5_v1_label_6a107e0d:

    # MC "(I’m gonna have to creep in further, or I’ll miss it!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:52
translate chinese ml_bedroom_morning_scene5_v1_label_c798eec2:

    # MC "(Wait... Should I go for it? Lately, because of her peculiar behavior, she's starting to seem more sexually attractive to me.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:54
translate chinese ml_bedroom_morning_scene5_v1_label_7dc12eea:

    # MC "(Aww - looks like she’s putting her panties back on.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:55
translate chinese ml_bedroom_morning_scene5_v1_label_d488aeb5:

    # MC "(I was hoping I’d catch a glimpse of her pussy.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:58
translate chinese ml_bedroom_morning_scene5_v1_label_5e056924:

    # MC "(This isn’t bad though! I could fap to the mental image of her ass for a week!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:59
translate chinese ml_bedroom_morning_scene5_v1_label_85d4b001:

    # MC "(I probably shouldn’t hang around much longer. She’s almost finished dressing.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:62
translate chinese ml_bedroom_morning_scene5_v1_label_f831dc9e:

    # MC "(She’s so stunningly beautiful though.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:63
translate chinese ml_bedroom_morning_scene5_v1_label_87c16ea5:

    # MC "(Looks like she’s grabbing a dress from her closet.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:66
translate chinese ml_bedroom_morning_scene5_v1_label_8ce5545a:

    # MC "(Okay, that’s her almost finished getting dressed - I better bolt before she notices I’ve been peeping at her.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:82
translate chinese ml_bedroom_morning_scene5_v1_label2_d2272221:

    # MC "(Actually - instead of leaving, I could take this chance to talk with Mom about getting a job.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:83
translate chinese ml_bedroom_morning_scene5_v1_label2_9fc53ae5:

    # MC "Hey, Mom!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:85
translate chinese ml_bedroom_morning_scene5_v1_label2_b1455a0a:

    # MC "(Actually - instead of leaving, I could take this chance to talk with Linda about getting a job.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:86
translate chinese ml_bedroom_morning_scene5_v1_label2_176421a1:

    # MC "Hey, Linda!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:90
translate chinese ml_bedroom_morning_scene5_v1_label2_0c837c6d:

    # Mom "Hi, Sweetie. I didn’t see you there. What’s up?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:92
translate chinese ml_bedroom_morning_scene5_v1_label2_ab950672:

    # MC "I had been talking with Dad, and he thought it would be a good idea for me to start earning money now."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:94
translate chinese ml_bedroom_morning_scene5_v1_label2_2cd3bc41:

    # MC "I had been talking with Bob and he thought it would be a good idea for me to start earning money now."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:95
translate chinese ml_bedroom_morning_scene5_v1_label2_2b735a83:

    # MC "He said you might have some work for me?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:98
translate chinese ml_bedroom_morning_scene5_v1_label2_ced9bb08:

    # Mom "Hmm... I’m not sure. I can’t think of any work I need done right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:99
translate chinese ml_bedroom_morning_scene5_v1_label2_6e484a1a:

    # MC "How about in your office building?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:100
translate chinese ml_bedroom_morning_scene5_v1_label2_1f38ceef:

    # Mom "I’m not sure."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:102
translate chinese ml_bedroom_morning_scene5_v1_label2_f14179b1:

    # MC "Please, Mom! I really need the money. I can’t just keep begging Dad for spare change!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:104
translate chinese ml_bedroom_morning_scene5_v1_label2_de447367:

    # MC "Please, Linda! I'm really in need of some extra money. I know your husband is a good person, but I shouldn't just keep asking him for pocket change!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:107
translate chinese ml_bedroom_morning_scene5_v1_label2_0012b5b8:

    # Mom "Well... Maybe."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:108
translate chinese ml_bedroom_morning_scene5_v1_label2_e89b55ee:

    # Mom "There’s a small possibility that I could give you a job."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:109
translate chinese ml_bedroom_morning_scene5_v1_label2_d752b8d1:

    # Mom "It comes with a condition though."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:112
translate chinese ml_bedroom_morning_scene5_v1_label2_fa4a1823:

    # MC "Awesome! What’s the condition?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:113
translate chinese ml_bedroom_morning_scene5_v1_label2_6bf339b2:

    # Mom "I’ll tell you later. In the meantime, just follow me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:114
translate chinese ml_bedroom_morning_scene5_v1_label2_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:121
translate chinese ml_bedroom_morning_scene5_v1_label2_1249263a:

    # MC "Where are we going, Mom?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:123
translate chinese ml_bedroom_morning_scene5_v1_label2_10a37034:

    # MC "Where are we going, Linda?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:124
translate chinese ml_bedroom_morning_scene5_v1_label2_7098a76a:

    # Mom "Just one more turn and then we’ll be there. "
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:125
translate chinese ml_bedroom_morning_scene5_v1_label2_a3e90852:

    # Mom "This is one of the car parks, near where I work."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:126
translate chinese ml_bedroom_morning_scene5_v1_label2_0526541d:

    # MC "Oh, right."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:129
translate chinese ml_bedroom_morning_scene5_v1_label2_ee7a954d:

    # MC "It looks pretty desolate."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:130
translate chinese ml_bedroom_morning_scene5_v1_label2_3603b0e6:

    # Mom "Yeah - nobody ever comes into here apart from me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:131
translate chinese ml_bedroom_morning_scene5_v1_label2_60388d7d:

    # Mom "(And having no people around, is essential for what I’m about to try next.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:134
translate chinese ml_bedroom_morning_scene5_v1_label2_a661f156:

    # MC "So? What’s this condition?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:135
translate chinese ml_bedroom_morning_scene5_v1_label2_41790746:

    # Mom "Just wait a minute. I need to plan it first."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:136
translate chinese ml_bedroom_morning_scene5_v1_label2_0ea7ba75:

    # Mom "(Okay, you can do this. You’ve rehearsed it in your mind a hundred times!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:140
translate chinese ml_bedroom_morning_scene5_v1_label2_35846984:

    # MC "Is everything okay, Mom? You’re looking a little nervous."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:142
translate chinese ml_bedroom_morning_scene5_v1_label2_c5a90a02:

    # MC "Is everything okay, Linda? You’re looking a little nervous."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:143
translate chinese ml_bedroom_morning_scene5_v1_label2_c1797313:

    # Mom "I’m fine. Okay, here’s what’s going to happen."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:146
translate chinese ml_bedroom_morning_scene5_v1_label2_7eb1a280:

    # Mom "The condition is, that you sit completely still for one full minute. Close your eyes and act like a doll."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:147
translate chinese ml_bedroom_morning_scene5_v1_label2_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:148
translate chinese ml_bedroom_morning_scene5_v1_label2_b372f2f3:

    # Mom "You aren’t allowed to react. And you aren’t allowed to talk about it later on."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:161
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_36a1542e:

    # MC "Why? I don’t understand why I’d have to do this to get a job."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:162
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_6e9ecb6d:

    # Mom "I’m not asking you to understand - it’s simply the condition I’ve laid out."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:171
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_2cb8b061:

    # MC "What happens if I open my eyes or move?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:173
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_45772fcc:

    # Mom "Then the condition is forfeit, and you won’t get the job."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:174
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_13a21dc9:

    # MC "Alright..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:183
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_29445b45:

    # MC "What if I have questions after the minute is up?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:185
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_0aef79b6:

    # Mom "You’ll just have to contain your curiosity - because if you ask me ANY questions about what happens, you won’t be getting that job."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:187
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_1cf32e45:

    # MC "(Gee... Mom’s pretty serious about this.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:189
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_ae172ab9:

    # MC "(Gee... Linda’s pretty serious about this.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:200
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_fd4320d4:

    # MC "Okay - that’s me ready."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:201
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_5940c34c:

    # Mom "The minute starts now. Remember, no talking, moving, or asking questions after."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:204
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_41842b5d:

    # MC "(One... Two... Three...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:205
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_866e5e7d:

    # MC "(She’s just put her hand on my shoulder. Nothing too strange yet...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:206
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_fadcc304:

    # MC "(Seven... Eight... Nine...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:209
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_ed156946:

    # Mom "(God... He’s so handsome. Not like Bob...)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:210
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_2f69c360:

    # Mom "(I have to kiss him. This could be my only chance.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:212
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_76fc9c58:

    # Mom "(I hope he doesn’t say anything to his father about this.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:214
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_bdc1e3ed:

    # Mom "(I hope he doesn’t say anything to Bob about this.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:217
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_738a41cb:

    # Mom "(Here we go... Now or never!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:218
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_c7f81aa5:

    # MC "(Thirteen... Fourteen... Fifteen...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:219
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_62649637:

    # MC "(What’s she doing?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:222
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_16abe6fa:

    # MC "(OH MY GOD!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:225
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_98631e66:

    # MC "(Mom’s full-on making out with me!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:227
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_a0ca595c:

    # MC "(Linda’s full-on making out with me!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:228
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_726cb244:

    # MC "(I can feel her tongue in my mouth, and everything!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:231
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_a16aba57:

    # MC "(I... I’ve lost count. Was I on twenty or thirty?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:233
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_0eaa2daa:

    # Mom "(Why did I only say a minute? I could have said two or three...)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:234
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_50388008:

    # Mom "(I wish this moment would last forever. It’s like a dream come true, right now.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:238
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_1c3c5565:

    # Mom "(If I think about this when his father fucks tonight, I might even climax, for a change.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:240
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_a9c221ba:

    # Mom "(If I think about this when Bob fucks me tonight, I might even climax, for a change.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:241
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_c457ac27:

    # Mom "(I have to contain myself... but right now, I could just rip [player_name]’s clothes off and ride him in the car seat.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:244
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_7a44925c:

    # Mom "(I have to know if he’s hard. I have to know if he’s enjoying this as much as I am...)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:245
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_f36f1f05:

    # Mom "(I’ll just move my hand down quickly, then take it away.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:248
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_8ae24b57:

    # Mom "(He’s hard! There’s no question about it.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:249
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_2b7aa98d:

    # Mom "(It also feels like he’s got a pretty sizeable member.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:250
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_0d4f7622:

    # Mom "(If only I could feel it, hard and throbbing, deep inside my pussy!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:251
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_ef6b677c:

    # MC "(Holy shit! Did she just grab my crotch? Is she planning to betray Bob with me? Does she have feelings for me, or is she playing some sort of game?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:255
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_40f28d71:

    # Mom "O-Okay, that’s a minute up now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:256
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_a163313b:

    # Mom "(Wow... That was... something else.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:257
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_73ec652c:

    # MC "C-Can I talk now?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:258
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_2768e4fe:

    # Mom "Yes, but you can’t speak about what happened."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:261
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_6d09eecd:

    # MC "Oh... O-Okay... (Fuck! I have so many questions!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:263
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_a8702841:

    # MC "(Why would she do that? I don’t understand it... She’s my mother.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:265
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_15384f02:

    # MC "(Why would she do that? I don't understand it... Is Bob not enough for her? Couldn't she have just asked me?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:266
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_00c2dab9:

    # MC "(I mean... Maybe she has some weird fetish... Or she has a crush on me? N-No! She's married! I should not have such thoughts.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:268
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_2a501319:

    # MC "(If Ms. Celia didn’t want to date me, how could my own mom be interested?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:270
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_f3339e94:

    # MC "(I mean... if Ms. Celia didn't want to date me, how could she even be interested in me? Maybe she made a bet with Liza or something?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:271
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_bc6d6f0a:

    # MC "(Perhaps it's just Celia who feels this way? Other mature women might be interested in me! If I recall correctly, we have an attractive neighbor living close by. Maybe I should consider approaching her as well?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:274
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_5191f149:

    # Mom "Ahem... I work in the building, just round the front of this carpark."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:275
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_551145f9:

    # Mom "If you drop by tomorrow afternoon, I’ll set you up with a job."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:277
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_393174ee:

    # MC "Th-Thanks, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_morning_scene5_v1.rpy:279
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after_e9aea860:

    # MC "Th-Thanks, Linda."
    MC ""

