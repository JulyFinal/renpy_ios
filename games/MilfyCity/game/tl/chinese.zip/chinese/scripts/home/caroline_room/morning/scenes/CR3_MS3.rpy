﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:15
translate chinese CR3_MS3_label_04bd3f44:

    # MC "(She asked me to leave her alone.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:28
translate chinese CR3_MS3_label_c2d9e398:

    # Caroline "Twenty, forty, sixty, eighty..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:29
translate chinese CR3_MS3_label_c5bd090e:

    # MC "(What’s she doing with all that money on her bed?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:30
translate chinese CR3_MS3_label_cfdb2eb0:

    # MC "Holy crap, Caroline! Did you win big, on a scratchcard?!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:34
translate chinese CR3_MS3_label_5ac01ebe:

    # Caroline "Haha! Not quite! This is today’s takings from the cosplay shop."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:35
translate chinese CR3_MS3_label_cd74357d:

    # MC "Wow... How much is there?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:36
translate chinese CR3_MS3_label_b157a90b:

    # Caroline "Well, before you interrupted me, I’d counted to $780."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:37
translate chinese CR3_MS3_label_4cb1cd1b:

    # MC "HOLY SHIT!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:41
translate chinese CR3_MS3_label_e926ddcb:

    # Caroline "It sounds a lot - but you have to remember, I probably spent $350, buying the outfits. I then have to pay, tax, rent, insurance, and put money into my pension."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:42
translate chinese CR3_MS3_label_bb091d6d:

    # MC "Ugh... That sounds rough. How much do you reckon you’ll be left with?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:43
translate chinese CR3_MS3_label_ebe3620b:

    # Caroline "Maybe $150 -ish. It isn’t too bad. Multiply that out, and I’m pulling home $750, in profit each week. "
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:47
translate chinese CR3_MS3_label_7a3ad0e1:

    # Caroline "Not too bad for a girl in her early twenties, is it?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:48
translate chinese CR3_MS3_label_429ee13d:

    # MC "That’s amazing! Well done."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:49
translate chinese CR3_MS3_label_112c5332:

    # Caroline "I know! And it keeps growing, each week!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:53
translate chinese CR3_MS3_label_77433601:

    # MC "Out of interest - why have you got it, all over your bed? I’ve never seen you waving around money before."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:54
translate chinese CR3_MS3_label_147a7b1f:

    # Caroline "Honestly? I used to store everything at the shop. After the robbery, I just don’t feel safe, leaving my valuables there anymore."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:55
translate chinese CR3_MS3_label_8b0f4e35:

    # MC "Yeah, I get that. It makes sense. What are you planning to do with it now?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:56
translate chinese CR3_MS3_label_34cf1504:

    # Caroline "I’m putting some in the bank, but the rest, I’m stashing away in my room."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:60
translate chinese CR3_MS3_label_629e0488:

    # MC "Why aren’t you putting it all in the bank?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:61
translate chinese CR3_MS3_label_951d63d8:

    # Caroline "Haha! I have a couple of reasons. Firstly, if my business ever goes bankrupt, then I can hide some assets from them. Did you know that thirty percent of new businesses, fail during their first two years?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:62
translate chinese CR3_MS3_label_bbf7e8eb:

    # MC "Wow! I didn’t know that."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:63
translate chinese CR3_MS3_label_ca0c7a44:

    # Caroline "Almost half fail in the first five years. Keeping cash as a liquid asset makes sense. Even if it isn’t generating interest I’ve got a nest egg that I can fall back on."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:67
translate chinese CR3_MS3_label_3de62437:

    # MC "So, what are you doing with that all, now?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:68
translate chinese CR3_MS3_label_41a6dee5:

    # Caroline "I’m about to look for a new hiding place. So, I’m gonna need you to do something for me."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:69
translate chinese CR3_MS3_label_58339f54:

    # MC "Sure! Anything!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:73
translate chinese CR3_MS3_label_19c65535:

    # Caroline "Turn around and leave my room, so I can hide my money! Haha!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:74
translate chinese CR3_MS3_label_bbafe640:

    # MC "Aww... Fine!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR3_MS3.rpy:75
translate chinese CR3_MS3_label_6d160d9e:

    # Caroline "Haha! See you later, [player_name]!"
    Caroline ""

