﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:4
translate chinese SR2_NSwake_label_757f2b4b:

    # MC "(I don’t know what I’m so worried about! I’ve already caught Sara, trying to take pictures of my cock while I’m asleep.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:5
translate chinese SR2_NSwake_label_4612ee03:

    # MC "(What’s the worst that could happen?)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:6
translate chinese SR2_NSwake_label_6f1692c9:

    # MC "(Alright, here goes nothing...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:8
translate chinese SR2_NSwake_label_a5fe2aff:

    # MC "(Let's stop this roleplay...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:9
translate chinese SR2_NSwake_label_b6b0baa5:

    # MC "(I want today to have normal sex with her)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:10
translate chinese SR2_NSwake_label_9803d591:

    # MC "(I hope she’s not gonna be mad that I changed my mind so quickly!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:11
translate chinese SR2_NSwake_label_0e18a7a5:

    # MC "Psst... Sara..."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:12
translate chinese SR2_NSwake_label_2178f9d0:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:13
translate chinese SR2_NSwake_label_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:14
translate chinese SR2_NSwake_label_2c04d20e:

    # Sara "Hmm?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:18
translate chinese SR2_NSwake_label_ce9fe596:

    # Sara "Yawwwnn!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:20
translate chinese SR2_NSwake_label_c9b75f40:

    # Sara "Huh? [player_name]?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:22
translate chinese SR2_NSwake_label_d50fba1a:

    # Sara "Ugh... What time is it?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:23
translate chinese SR2_NSwake_label_c9faf37a:

    # MC "It’s the middle of the night."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:27
translate chinese SR2_NSwake_label_633abd96:

    # Sara "Why’d you wake me up? What’s wrong?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:29
translate chinese SR2_NSwake_label_effdeadb:

    # Sara "Em... I didn't screw up our roleplay, did I?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:30
translate chinese SR2_NSwake_label_88a5582e:

    # MC "Nope, I changed my mind. "
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:34
translate chinese SR2_NSwake_label_267f61b3:

    # Sara "So, no roleplay... What’s wrong?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:35
translate chinese SR2_NSwake_label_463aa4d9:

    # MC "Nothing’s wrong."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:36
translate chinese SR2_NSwake_label_04d4fd72:

    # Sara "And why is my duvet all crumpled up at the bottom of my bed?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:37
translate chinese SR2_NSwake_label_20aff9aa:

    # MC "Err... You must have wriggled out of it while you were sleeping."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:38
translate chinese SR2_NSwake_label_eae7ca38:

    # Sara "Huh..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:39
translate chinese SR2_NSwake_label_3daadb1c:

    # MC "Anyway, I just had to see you again. I couldn’t get what we did, off my mind. I was wondering if we could do it again."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:43
translate chinese SR2_NSwake_label_e8af7928:

    # Sara "(He wants another blowjob?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:44
translate chinese SR2_NSwake_label_f9f536eb:

    # Sara "(I guess it WAS pretty fun.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:53
translate chinese SNS_wake_5_b98b2ae7:

    # Sara "Sure, why not."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:54
translate chinese SNS_wake_5_cd9a218b:

    # MC "Awesome! Could you bend over?"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:56
translate chinese SNS_wake_5_c204b96d:

    # MC "Make sure to keep your voice down, by the way. I don’t want to wake up Mom and Dad."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:58
translate chinese SNS_wake_5_f5e803b1:

    # MC "Make sure to keep your voice down, by the way. I don’t want to wake up the others."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:62
translate chinese SNS_wake_5_2fef71de:

    # Sara "Suur- Wait? Bend over? Like... sex? I- I’m not ready for that!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:63
translate chinese SNS_wake_5_f34dac91:

    # MC "Relax. I promise I won’t do anything that you’re not ready for."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:64
translate chinese SNS_wake_5_158f1c75:

    # Sara "D-Do you still need me to bend over?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:65
translate chinese SNS_wake_5_efed4266:

    # MC "Yeah - just get on all fours."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:66
translate chinese SNS_wake_5_ce2223a2:

    # Sara "Promise you won’t fuck me yet? It’s just a bit... fast for me."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:67
translate chinese SNS_wake_5_07be9c9f:

    # MC "I promise. I just want to use your thighs."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:68
translate chinese SNS_wake_5_c0f9a610:

    # Sara "O-Okay..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:72
translate chinese SNS_wake_5_d857e144:

    # Sara "J-Just like this?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:73
translate chinese SNS_wake_5_5e95dd96:

    # Sara "(My heart is pounding so fast right now! I know this isn’t sex, but it feels like it’s getting really close to it.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:74
translate chinese SNS_wake_5_6502c229:

    # MC "That’s perfect, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:78
translate chinese SNS_wake_5_ef3f4705:

    # MC "Just hold still, and let ME do all the work."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:79
translate chinese SNS_wake_5_16d178f1:

    # Sara "O-Okay, [player_name]..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:80
translate chinese SNS_wake_5_50a5879b:

    # MC "(She looks so cute in her little pink underwear.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:84
translate chinese SNS_wake_5_98c41eee:

    # MC "I’m going to push my cock forward now, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:85
translate chinese SNS_wake_5_39b3c976:

    # Sara "Mmm hmm..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:86
translate chinese SNS_wake_5_06b24bb3:

    # Sara "(Why am I so nervous? I wasn't like that when I was giving him a blowjob!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:87
translate chinese SNS_wake_5_d789b2d9:

    # Sara "(Perhaps it’s just how close his cock is, to my pussy.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:91
translate chinese SNS_wake_5_6d0f9875:

    # Sara "Ooh...."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:92
translate chinese SNS_wake_5_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:95
translate chinese SNS_wake_5_ba4c36c3:

    # Sara "Y-Yeah... It just rubbed against my clitoris through my panties..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:96
translate chinese SNS_wake_5_32b0f5bb:

    # MC "Sorry."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:97
translate chinese SNS_wake_5_7e2b8826:

    # Sara "Don’t apologise... It was nice."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:101
translate chinese SNS_wake_5_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:102
translate chinese SNS_wake_5_e36b733f:

    # MC "(Her warm thighs are wrapped, either side of my cock. This feels incredible!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:103
translate chinese SNS_wake_5_14c78364:

    # MC "(I can’t wait to fuck her pussy, some day.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:104
translate chinese SNS_wake_5_786efd74:

    # Sara "Ohh... Ah.... Mmm..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:105
translate chinese SNS_wake_5_5238d761:

    # Sara "(I never imagined, dry humping could be this good!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:109
translate chinese SNS_wake_5_be8cf88d:

    # MC "Ugh! Are you enjoying this, Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:110
translate chinese SNS_wake_5_b1f036ee:

    # Sara "Ah! Ahh! It’s sooo good..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:111
translate chinese SNS_wake_5_95183162:

    # Sara "F-Faster!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:115
translate chinese SNS_wake_5_a206b313:

    # Sara "Oh... yes! Yes! Oooohhhhh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:116
translate chinese SNS_wake_5_9434a70c:

    # MC "(Wow, she’s really getting into this!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:117
translate chinese SNS_wake_5_58556015:

    # MC "Ahh... "
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:118
translate chinese SNS_wake_5_a1337c80:

    # MC "I’m not gonna last much longer, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:122
translate chinese SNS_wake_5_a45d7308:

    # Sara "Ahh! It’s okay! Ugh! Ohhh! C-Cum wherever you want!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:126
translate chinese SNS_wake_5_0db11aa1:

    # MC "(She’s getting pretty loud. I hope Mom and Dad don’t hear this!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:128
translate chinese SNS_wake_5_dcf0f73f:

    # MC "(She's getting pretty loud... She’s enjoying it too...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:134
translate chinese SNS_wake_5_c85f40c6:

    # MC "Oh God... yes... Ugh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:135
translate chinese SNS_wake_5_c861ba6c:

    # MC "Ahhhh...."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:136
translate chinese SNS_wake_5_ecd07d06:

    # Sara "(Damn... I wish he’d finished in my mouth again...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:137
translate chinese SNS_wake_5_b5282d3d:

    # Sara "(I actually kinda liked how warm it was, and the salty taste wasn’t that bad.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:147
translate chinese SNS_wake_5_0d5f1178:

    # MC "Hnnnnnggg! Gaaaahhh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:148
translate chinese SNS_wake_5_8be63803:

    # MC "Ugh! Yes!"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:149
translate chinese SNS_wake_5_1a452c67:

    # MC "Phew... That was amazing, Sara. Thank you, so much."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:150
translate chinese SNS_wake_5_b9697afa:

    # Sara "No problem, [player_name]."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:151
translate chinese SNS_wake_5_a52a3370:

    # Sara "Umm... could you get me some tissues before you go back to bed? I have some cleaning to do."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:152
translate chinese SNS_wake_5_ed9f738e:

    # MC "Err... sure. Sorry about that. Haha!"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:163
translate chinese SNS_wake_5_3b5890b0:

    # MC "Open wide, Sara. I’ll finish in your mouth."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:164
translate chinese SNS_wake_5_1bf0128c:

    # Sara "(YAY!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:165
translate chinese SNS_wake_5_1769fb83:

    # Sara "Ahhh...."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:175
translate chinese SNS_wake_5_db7eef9f:

    # MC "Hnnng! Oh God! Yes!"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:176
translate chinese SNS_wake_5_1ec113a0:

    # MC "(Her mouth is so warm and wet, around the tip of my cock!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:177
translate chinese SNS_wake_5_762c49c0:

    # Sara "(Gulp Gulp!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:178
translate chinese SNS_wake_5_af1d864a:

    # MC "Ahhhh.... Fuck...."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:182
translate chinese SNS_wake_5_34db6755:

    # MC "Phew... That was amazing. Thank you, so much."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:183
translate chinese SNS_wake_5_3393fb48:

    # Sara "You’re welcome, [player_name]. Goodnight."
    Sara ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:184
translate chinese SNS_wake_5_72cfea76:

    # MC "Sleep tight, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:185
translate chinese SNS_wake_5_98791869:

    # Sara "You too, [player_name]."
    Sara ""

translate chinese strings:

    # game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:130
    old "Cum on her back."
    new ""

    # game/scripts/home/sara_room/night/scenes/S_NS_wake.rpy:130
    old "Finish in her mouth."
    new ""

