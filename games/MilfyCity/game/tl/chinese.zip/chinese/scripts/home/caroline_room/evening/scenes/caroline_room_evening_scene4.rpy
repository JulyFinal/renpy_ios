﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:15
translate chinese caroline_room_evening_scene4_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:25
translate chinese caroline_room_evening_scene4_label_5e919483:

    # Caroline "Haha! I can’t believe it!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:26
translate chinese caroline_room_evening_scene4_label_e05e570d:

    # MC "(It makes for a nice change to finally see her happy.)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:27
translate chinese caroline_room_evening_scene4_label_5d1d7287:

    # MC "Hey, Caroline! What’s so funny?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:30
translate chinese caroline_room_evening_scene4_label_a60b8717:

    # Caroline "Oh! Hiii! I didn’t see you come in there."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:31
translate chinese caroline_room_evening_scene4_label_7e377bba:

    # Caroline "Nothing’s funny - I’m just... You need to see this."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:32
translate chinese caroline_room_evening_scene4_label_c1eeae28:

    # Caroline "Here - take a seat beside me! Quick! This is amazing!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:35
translate chinese caroline_room_evening_scene4_label_ff3748e0:

    # MC "Okay... what am I looking at?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:36
translate chinese caroline_room_evening_scene4_label_c7abb692:

    # Caroline "These are my profit/loss accounts for the past year!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:37
translate chinese caroline_room_evening_scene4_label_41a26e25:

    # MC "What are all those red numbers?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:38
translate chinese caroline_room_evening_scene4_label_817b9d31:

    # Caroline "Those are months where I lost money - but look at the last one!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:39
translate chinese caroline_room_evening_scene4_label_1899ca0f:

    # MC "Huh? It’s black there."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:40
translate chinese caroline_room_evening_scene4_label_9e23a729:

    # Caroline "That means I turned a profit! And look! It’s almost enough to pay off the past four months' debt!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:41
translate chinese caroline_room_evening_scene4_label_6b34c7f8:

    # Caroline "Most of it ended up coming from online sales."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:44
translate chinese caroline_room_evening_scene4_label_2835182d:

    # MC "Ahh, so what you’re really saying, is that you couldn’t have done it without ME?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:45
translate chinese caroline_room_evening_scene4_label_6450c2bd:

    # Caroline "I never said that."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:46
translate chinese caroline_room_evening_scene4_label_0244fae7:

    # MC "Who took all those pictures, for your website and store?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:49
translate chinese caroline_room_evening_scene4_label_bf7166ad:

    # Caroline "Haha! I’m grateful that you took the pictures, but remember - I was the one who spent MONTHS setting up business accounts, organising shipping, and finding a location to set up my shop."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:50
translate chinese caroline_room_evening_scene4_label_cf96c8de:

    # Caroline "You certainly helped - but I still did the LION’S share of the work."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:51
translate chinese caroline_room_evening_scene4_label_6b9afb05:

    # MC "Fine! Fine! I get it! Haha!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:52
translate chinese caroline_room_evening_scene4_label_90d3f3ad:

    # MC "Say - you remember that thing that happened, during the last cosplay?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:55
translate chinese caroline_room_evening_scene4_label_80fe1a40:

    # MC "I’d really like to do that again."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:56
translate chinese caroline_room_evening_scene4_label_6f66cf96:

    # Caroline "Wh-What?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:57
translate chinese caroline_room_evening_scene4_label_e0b00dc3:

    # MC "You know - when you rubbed yourself against my cock?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:58
translate chinese caroline_room_evening_scene4_label_ea5adae9:

    # MC "Don’t you want to do it again too?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:61
translate chinese caroline_room_evening_scene4_label_c64f9297:

    # Caroline "[player_name]... That was just us having a bit of fun."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:62
translate chinese caroline_room_evening_scene4_label_5e7783de:

    # Caroline "We were just blowing off some steam."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:63
translate chinese caroline_room_evening_scene4_label_e4fd32a4:

    # MC "But, I’m really attracted to you."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:65
translate chinese caroline_room_evening_scene4_label_9401b35c:

    # Caroline "I’m sorry... I don’t feel that way. You’re my brother. We had fun together, and did something we shouldn’t have. Let’s not talk about this again. Please..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:67
translate chinese caroline_room_evening_scene4_label_761155fb:

    # Caroline "I’m sorry... I don’t feel that way. You’re my friend, nothing more. We had fun together and did something we shouldn’t have. Let’s not talk about this again. Please."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:68
translate chinese caroline_room_evening_scene4_label_82421903:

    # MC "I’m sorry... I just thought... Maybe you enjoyed it too?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:69
translate chinese caroline_room_evening_scene4_label_725891ac:

    # Caroline "*Sigh* Give me some time alone to think."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:70
translate chinese caroline_room_evening_scene4_label_6832f3e7:

    # MC "Okay... I’ll see you later, Caroline."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:73
translate chinese caroline_room_evening_scene4_label_9195eca7:

    # Caroline "(What have I done? Was he already attracted to me? Or have I caused it, by posing in those sexy outfits?)"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/caroline_room_evening_scene4.rpy:74
translate chinese caroline_room_evening_scene4_label_71bd4903:

    # Caroline "(I can’t believe what I’ve gotten myself into...)"
    Caroline ""

