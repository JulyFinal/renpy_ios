﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:84
translate chinese MLR2_ES3_cantleave_label_1f79e13e:

    # MC "I can't leave now."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:95
translate chinese MLR2_ES3_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:96
translate chinese MLR2_ES3_label_33986a1c:

    # MC "Now, as I think about it.. I should wear something better.."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:97
translate chinese MLR2_ES3_label_869e6bf2:

    # MC "Yeah. I should quickly go change!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:110
translate chinese MLR2_ES3_label_fbe44d5a:

    # MC "(Okay? Date night with Mom. What should I wear?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:112
translate chinese MLR2_ES3_label_cc25ffad:

    # MC "(Okay? Date night with Linda. What should I wear?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:113
translate chinese MLR2_ES3_label_53d77bdf:

    # MC "(I don’t want to look TOO formal.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:114
translate chinese MLR2_ES3_label_5b4d1e6d:

    # MC "(But I have to dress up, smarter than usual.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:119
translate chinese MLR2_ES3_label_bec58e7e:

    # MC "(Yeah, this is looking good.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:120
translate chinese MLR2_ES3_label_cc756812:

    # MC "(It’s only dinner anyway.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:122
translate chinese MLR2_ES3_label_2c24535f:

    # MC "(Okay - time to meet Mom in the garage.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:124
translate chinese MLR2_ES3_label_6bce348f:

    # MC "(Okay - time to meet Linda in the garage.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:133
translate chinese MLR2_ES3_label_467ce4c5:

    # MC "(I’ve been waiting in the garage for ten minutes now. I wonder if Mom has forgotten about our date.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:135
translate chinese MLR2_ES3_label_aaddeca4:

    # MC "(I’ve been waiting in the garage for ten minutes now. I wonder if Linda has forgotten about our date.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:136
translate chinese MLR2_ES3_label_57cad0c9:

    # MC "(Then again, she’s a woman - and they can take FOREVER, getting ready to go out.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:137
translate chinese MLR2_ES3_label_b555ad05:

    # MC "(I’ll give her another five minutes before I search for her.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:141
translate chinese MLR2_ES3_label_eb2e3391:

    # Mom "Hi, Sweetie. Sorry to keep you waiting!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:142
translate chinese MLR2_ES3_label_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:143
translate chinese MLR2_ES3_label_1ec0bcd7:

    # Mom "What do you think? Like my dress?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:144
translate chinese MLR2_ES3_label_a06d8140:

    # MC "Hell yeah! It’s amazing!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:149
translate chinese MLR2_ES3_label_172c9f84:

    # Mom "I haven’t worn this little number, in almost ten years. I just never felt sexy enough to wear it while I was with your father."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:151
translate chinese MLR2_ES3_label_d4572ec8:

    # Mom "I haven’t worn this little number, in almost ten years. I just never felt sexy enough to wear it while I was with Bob."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:152
translate chinese MLR2_ES3_label_de28d6fb:

    # Mom "What do you think? Is it too short to go out in?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:153
translate chinese MLR2_ES3_label_b126cfad:

    # MC "Maybe a little bit."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:154
translate chinese MLR2_ES3_label_84f75a15:

    # Mom "Good. That’s what I was aiming for."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:158
translate chinese MLR2_ES3_label_bfbd07f5:

    # MC "You ARE looking great tonight, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:160
translate chinese MLR2_ES3_label_c5bf9fac:

    # MC "You ARE looking great tonight, Linda."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:161
translate chinese MLR2_ES3_label_23954c99:

    # Mom "Thanks! I actually had to climb into the attic to find this dress. It was packed away."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:165
translate chinese MLR2_ES3_label_40f9011c:

    # Mom "Now, hop in the car. I’ll drive us to the restaurant."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:166
translate chinese MLR2_ES3_label_b10b1135:

    # Mom "We’re already a little bit late!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:167
translate chinese MLR2_ES3_label_84b168f7:

    # MC "Okay, let’s go!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:177
translate chinese MLR2_ES3_label_e9948b3e:

    # MC "(I wonder if I’ll get to fuck Mom tonight?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:179
translate chinese MLR2_ES3_label_6d8d3ad2:

    # MC "(I wonder if I’ll get to fuck Linda tonight?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:180
translate chinese MLR2_ES3_label_f8e6172c:

    # MC "(That’s what happens after a guy and girl come back from a date, right?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:181
translate chinese MLR2_ES3_label_ee1a2cab:

    # MC "(I should probably try and bring her back to my bedroom, after we get home.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:182
translate chinese MLR2_ES3_label_936b3a03:

    # MC "(God, I’m getting so nervous. Is this even a date? Should I have brought her some flowers?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:186
translate chinese MLR2_ES3_label_ba95dc2a:

    # Mom "You okay there, Sweetie? You’ve been awfully quiet."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:187
translate chinese MLR2_ES3_label_0b95aa28:

    # MC "Y-Yeah, I’m fine."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:188
translate chinese MLR2_ES3_label_09354e90:

    # Mom "Are you sure? You can tell me anything at all."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:192
translate chinese MLR2_ES3_label_c3f6b0eb:

    # MC "Well... I was kind of nervous about tonight."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:193
translate chinese MLR2_ES3_label_82071df9:

    # MC "I didn’t bring you any flowers or chocolates - and to be honest I’m not even sure if this is a date or not. Or maybe just-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:194
translate chinese MLR2_ES3_label_63599895:

    # Mom "[player_name], just relax and don’t think too much about it, okay?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:195
translate chinese MLR2_ES3_label_a4ab5b20:

    # MC "But...-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:198
translate chinese MLR2_ES3_label_1b5a710a:

    # Mom "-Haha! You’re adorable. Just focus on enjoying yourself tonight, okay?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:200
translate chinese MLR2_ES3_label_c9298cb6:

    # MC "Alright. Thanks, Mom. Sorry I was so nervous."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:202
translate chinese MLR2_ES3_label_c3852580:

    # MC "Alright. Thanks, Linda. Sorry I was so nervous."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:203
translate chinese MLR2_ES3_label_cbf41a5d:

    # Mom "It’s alright, Sweetie. Just let me lead the way."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:213
translate chinese MLR2_ES3_label_30e9c214:

    # Mom "Here we go - you’ll absolutely LOVE the food."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:214
translate chinese MLR2_ES3_label_75ed9a5a:

    # MC "Uhh... Where are we sitting? It looks like they’re really busy tonight."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:215
translate chinese MLR2_ES3_label_1f74e095:

    # Mom "How about you go and find us an empty table?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:219
translate chinese MLR2_ES3_label_8d422881:

    # Mom "I’ll pop off to the ladies’ room, and join you in a couple of minutes."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:221
translate chinese MLR2_ES3_label_20d20b0d:

    # MC "No problem, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:223
translate chinese MLR2_ES3_label_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:256
translate chinese resteurant_table_label_4e9ddd63:

    # Mom "Good find! This is a nice little booth."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:257
translate chinese resteurant_table_label_cd3e3ffb:

    # MC "(That dress is so short, I can see her panties!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:259
translate chinese resteurant_table_label_55cfdb74:

    # MC "Thanks, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:261
translate chinese resteurant_table_label_c0a111cf:

    # MC "Thanks, Linda."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:265
translate chinese resteurant_table_label_1b708302:

    # Mom "How about you choose the dish tonight?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:266
translate chinese resteurant_table_label_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:267
translate chinese resteurant_table_label_187a5fcd:

    # Mom "Everything is really great here. You can’t go wrong, I promise."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:268
translate chinese resteurant_table_label_ec32c7a9:

    # MC "Are there any foods you don’t like?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:269
translate chinese resteurant_table_label_51585735:

    # Mom "Red onion and anchovies. I’ll eat anything else."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:340
translate chinese MLR2_ES3_continue_label_f1bcfff0:

    # Mom "So, while we’re waiting for our meal to come, I’ve got a question I really wanted to know."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:341
translate chinese MLR2_ES3_continue_label_2d25befd:

    # MC "Uh huh?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:342
translate chinese MLR2_ES3_continue_label_d8299759:

    # Mom "I was wondering. Are you still looking for a girlfriend? Maybe one at your age?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:351
translate chinese MLR2_ES3_continue_label_59334f39:

    # MC "Not right now. I’m still the laughing stock of the college, because of that Celia incident."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:352
translate chinese MLR2_ES3_continue_label_000874ba:

    # Mom "Ahh, of course. Well, that’s perfectly understandable."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:356
translate chinese MLR2_ES3_continue_label_5c148e4a:

    # Mom "Just return to dating in your own time, whenever you feel comfortable."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:357
translate chinese MLR2_ES3_continue_label_4b53bcfe:

    # Mom "And, as always, I’m always here if you need me."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:359
translate chinese MLR2_ES3_continue_label_5727cbc0:

    # MC "Thanks, Mom. You’re the best."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:361
translate chinese MLR2_ES3_continue_label_e2f9424e:

    # MC "Thanks, Linda. You’re the best."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:367
translate chinese MLR2_ES3_continue_label_67459acc:

    # MC "Yeah, Mom. I'm still searching... (How can I name that secret relationship with you...)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:369
translate chinese MLR2_ES3_continue_label_3669e25f:

    # MC "Yeah, Linda. I'm still searching... (How can I name that secret relationship with you...)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:370
translate chinese MLR2_ES3_continue_label_80c242d7:

    # Mom "Oh? Are you suggesting that both of us are still searching as well?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:374
translate chinese MLR2_ES3_continue_label_efefda80:

    # Mom "Is there... someone specific you have in mind? (I believe my other half is very close right now.)"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:375
translate chinese MLR2_ES3_continue_label_c1bf35e6:

    # MC "A few hot girls, here and there."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:376
translate chinese MLR2_ES3_continue_label_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:377
translate chinese MLR2_ES3_continue_label_14820c87:

    # Mom "I don’t think it’s a good idea for you to rush into a relationship again, so soon after what happened last time with your professor."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:378
translate chinese MLR2_ES3_continue_label_c27c6cee:

    # MC "Umm... I’ll keep that in mind."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:384
translate chinese MLR2_ES3_continue_label_55867cd3:

    # MC "I’m not sure, right now."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:386
translate chinese MLR2_ES3_continue_label_e23ab283:

    # Mom "That’s okay. You know, both your sisters are single. Maybe you could pick up one of them!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:387
translate chinese MLR2_ES3_continue_label_2d4e7d96:

    # MC "MOM!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:389
translate chinese MLR2_ES3_continue_label_bccaf564:

    # Mom "That’s okay. You know, both your friends are single. Maybe you could pick up one of them!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:390
translate chinese MLR2_ES3_continue_label_c8dc7952:

    # MC "LINDA!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:395
translate chinese MLR2_ES3_continue_label_b54f571a:

    # Mom "Hahaha! I’m just teasing! I know you’re close with Sara and Caroline."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:396
translate chinese MLR2_ES3_continue_label_5b65e14e:

    # MC "Heh... I guess so."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:407
translate chinese after_menu_MLR2_ES3_continue_label_4b573baf:

    # Mom "Mmm... Roasted salmon with sweet potato. Good choice."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:408
translate chinese after_menu_MLR2_ES3_continue_label_31111016:

    # Mom "I always loved how they both melt in your mouth, when slow-cooked."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:412
translate chinese after_menu_MLR2_ES3_continue_label_fa813b43:

    # Mom "Well, let’s dig in, shall we?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:413
translate chinese after_menu_MLR2_ES3_continue_label_232ccba0:

    # MC "Sounds good to me! Want any salt or pepper?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:414
translate chinese after_menu_MLR2_ES3_continue_label_8690c1db:

    # Mom "Just a little pepper, please. Too much salt, and you’ll ruin the salmon."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:419
translate chinese after_menu_MLR2_ES3_continue_label_126a82cf:

    # Mom "Tomato and pesto linguine. Very nice."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:420
translate chinese after_menu_MLR2_ES3_continue_label_488669a6:

    # Mom "I can’t remember the last time I had a proper pasta dish - it must have been three years ago, when I last visited Italy."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:421
translate chinese after_menu_MLR2_ES3_continue_label_f7579f8f:

    # MC "Was the food good, over there?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:422
translate chinese after_menu_MLR2_ES3_continue_label_f473fdc1:

    # Mom "It was incredible! Completely out of this world!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:426
translate chinese after_menu_MLR2_ES3_continue_label_0930f8e2:

    # MC "What about Dad? Did he enjoy the food in Italy?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:428
translate chinese after_menu_MLR2_ES3_continue_label_a2754554:

    # MC "What about Bob, did he enjoy the food in Italy?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:429
translate chinese after_menu_MLR2_ES3_continue_label_fa044d30:

    # Mom "Mmm... Absolutely not. He didn’t even come with me. I went by myself - ended up having dinner with a lovely young Italian lady named Viviana."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:430
translate chinese after_menu_MLR2_ES3_continue_label_a90cc1e4:

    # Mom "Last time I heard from her, I think she was looking to immigrate here for work."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:435
translate chinese after_menu_MLR2_ES3_continue_label_82ad2484:

    # Mom "Hmm... Sausages and potatoes..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:436
translate chinese after_menu_MLR2_ES3_continue_label_b6271b65:

    # Mom "You sure know how to treat a girl!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:437
translate chinese after_menu_MLR2_ES3_continue_label_301a078d:

    # MC "(Uh oh... Maybe I should have picked something more... upmarket.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:441
translate chinese after_menu_MLR2_ES3_continue_label_fd9c95cd:

    # Mom "At least it tastes pretty good."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:442
translate chinese after_menu_MLR2_ES3_continue_label_d9d24266:

    # MC "(Phew!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:444
translate chinese after_menu_MLR2_ES3_continue_label_c04cddf9:

    # MC "(I think I’m off the hook, at least. I should definitely consider a fancier dish, if I ever take Mom out for dinner again!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:446
translate chinese after_menu_MLR2_ES3_continue_label_495162e9:

    # MC "(I think I’m off the hook, at least. I should definitely consider a fancier dish, if I ever take Linda out for dinner again!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:451
translate chinese after_menu_MLR2_ES3_continue_label_f4338f8d:

    # Mom "I must admit. I’ve never actually tried seafood salad before."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:452
translate chinese after_menu_MLR2_ES3_continue_label_93e789c7:

    # Mom "My loathing of anchovies has made me somewhat anxious when it comes to trying new seafoods."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:453
translate chinese after_menu_MLR2_ES3_continue_label_fa6c0517:

    # MC "Give it a go - you’ll probably like it!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:454
translate chinese after_menu_MLR2_ES3_continue_label_c55f82e0:

    # MC "If it turns out you don’t we can just order another dish - I’ll pay."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:458
translate chinese after_menu_MLR2_ES3_continue_label_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:459
translate chinese after_menu_MLR2_ES3_continue_label_1c934c68:

    # MC "Not a fan?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:460
translate chinese after_menu_MLR2_ES3_continue_label_e9240966:

    # Mom "It’s... just alright. A nice pasta would have probably gone down better."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:461
translate chinese after_menu_MLR2_ES3_continue_label_ae475621:

    # MC "Ahh, I’ll remember that for future."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:462
translate chinese after_menu_MLR2_ES3_continue_label_e28dcb74:

    # Mom "Don’t worry - it’s nice to be pushed out of my comfort zone every now and then."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:467
translate chinese after_menu_MLR2_ES3_continue_label_f84d6ae1:

    # Mom "Thank you for joining me tonight, [player_name]."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:469
translate chinese after_menu_MLR2_ES3_continue_label_7a5d07c8:

    # MC "You don't’ need to thank me, Mom. I’m having a great time!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:471
translate chinese after_menu_MLR2_ES3_continue_label_d2dd3822:

    # MC "You don't need to thank me. I’m having a great time!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:472
translate chinese after_menu_MLR2_ES3_continue_label_3acaa154:

    # Mom "How about a wine, then? Red or white?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:473
translate chinese after_menu_MLR2_ES3_continue_label_ba75e92d:

    # MC "Uhh..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:474
translate chinese after_menu_MLR2_ES3_continue_label_2dafe954:

    # Mom "You’re clearly not a wine connoisseur. We’ll go for a red."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:479
translate chinese after_menu_MLR2_ES3_continue_label_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:480
translate chinese after_menu_MLR2_ES3_continue_label_a7a55e9c:

    # MC "It’s... uh... fruity?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:481
translate chinese after_menu_MLR2_ES3_continue_label_5d02c4b9:

    # Mom "Someone more experienced would probably describe this as: floral, with strong undertones of red grape, garnished with a crisp afterbite."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:482
translate chinese after_menu_MLR2_ES3_continue_label_66dc0fbb:

    # Mom "But, yes, I suppose “fruity” works too."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:486
translate chinese after_menu_MLR2_ES3_continue_label_260ac126:

    # MC "Sorry, it’s my first time ever drinking such an expensive wine, so I’m not very experienced with the terminologies."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:487
translate chinese after_menu_MLR2_ES3_continue_label_db2c98a4:

    # Mom "Relax - it’s cute."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:489
translate chinese after_menu_MLR2_ES3_continue_label_d50fe088:

    # MC "Uh... Mom? Is that you?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:491
translate chinese after_menu_MLR2_ES3_continue_label_69553a8b:

    # MC "Uh... Linda? Is that you?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:492
translate chinese after_menu_MLR2_ES3_continue_label_d6ea4baa:

    # Mom "What do you mean?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:496
translate chinese after_menu_MLR2_ES3_continue_label_1b8a891b:

    # MC "(I KNEW it was her!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:497
translate chinese after_menu_MLR2_ES3_continue_label_2de7e191:

    # MC "Your foot... it’s on my..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:498
translate chinese after_menu_MLR2_ES3_continue_label_edbfacd6:

    # Mom "On your what, Dear?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:502
translate chinese after_menu_MLR2_ES3_continue_label_55a2215d:

    # MC "We’re in public, Mom..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:504
translate chinese after_menu_MLR2_ES3_continue_label_bc341ea8:

    # MC "We’re in public..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:505
translate chinese after_menu_MLR2_ES3_continue_label_1d56bf81:

    # MC "There’s shit-loads of people! This place is packed out tonight!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:506
translate chinese after_menu_MLR2_ES3_continue_label_840c6aa3:

    # Mom "Hmm, we better not get caught then. That would be rather embarrassing for you."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:510
translate chinese after_menu_MLR2_ES3_continue_label_a87bed8b:

    # MC "Oh, my God - you’re not seriously going to go through with this, right?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:511
translate chinese after_menu_MLR2_ES3_continue_label_75d0b430:

    # Mom "Mmm... I most certainly am, Dear."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:512
translate chinese after_menu_MLR2_ES3_continue_label_280a0f69:

    # MC "(Fuck! Should I try to stop her?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:537
translate chinese MLR2_ES3_footjob_label_bb475a85:

    # MC "(I guess it wouldn’t hurt to let her continue. We just have to be very careful.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:542
translate chinese MLR2_ES3_footjob_label_d0e2f324:

    # "*Zzzzzziiiiiipppp*"
    ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:547
translate chinese MLR2_ES3_footjob_label_b8bc3254:

    # MC "(She just undid my zipper with her toes and pulled my boxer shorts down!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:549
translate chinese MLR2_ES3_footjob_label_298206f3:

    # MC "Mom-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:551
translate chinese MLR2_ES3_footjob_label_0690d7b1:

    # MC "Linda-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:552
translate chinese MLR2_ES3_footjob_label_9fb54e62:

    # Mom "Shush. The trick is, to avoid reacting. You don’t want to alert any other diners, as to what is going on."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:556
translate chinese MLR2_ES3_footjob_label_2d969cca:

    # Mom "Besides - Don’t tell me that you’re not enjoying this?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:557
translate chinese MLR2_ES3_footjob_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:558
translate chinese MLR2_ES3_footjob_label_9ffd99fa:

    # Mom "I thought so."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:559
translate chinese MLR2_ES3_footjob_label_88c2c0ee:

    # Mom "Now, let me slip my other shoe off, so I can get both feet working on your cock."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:563
translate chinese MLR2_ES3_footjob_label_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:566
translate chinese MLR2_ES3_footjob_label_01b60380:

    # Mom "Sounds like my big boy’s enjoying having Mommy’s feet, rubbing over his thick hard cock."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:568
translate chinese MLR2_ES3_footjob_label_d2e7a803:

    # Mom "Sounds like you’re enjoying having my bare feet rubbing over his thick, hard cock."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:569
translate chinese MLR2_ES3_footjob_label_18585998:

    # MC "(Fuck, this feels so good...)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:573
translate chinese MLR2_ES3_footjob_label_62c12589:

    # Mom "What’s wrong? You’re looking a little flustered, Sweetie."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:574
translate chinese MLR2_ES3_footjob_label_5cbc71e0:

    # Mom "Did you drink too much wine?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:575
translate chinese MLR2_ES3_footjob_label_397260c1:

    # MC "S-Stop teasing me! Someone could ahh... see us!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:579
translate chinese MLR2_ES3_footjob_label_4a4e7c24:

    # Mom "You worry too much. You need to learn to relax and enjoy the simple things in life..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:581
translate chinese MLR2_ES3_footjob_label_b92ffb49:

    # Mom "...like your mother massaging your cock with her feet, in the middle of a public restaurant."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:583
translate chinese MLR2_ES3_footjob_label_4187f12c:

    # Mom "...like your landlady massaging your cock with her feet, in the middle of a public restaurant."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:584
translate chinese MLR2_ES3_footjob_label_ed1a6441:

    # MC "Ah... Oohh..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:585
translate chinese MLR2_ES3_footjob_label_daeb6b1f:

    # MC "(She’s got a twisted definition of “simple things in life.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:589
translate chinese MLR2_ES3_footjob_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:590
translate chinese MLR2_ES3_footjob_label_5c82260a:

    # MC "(She’s getting faster!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:591
translate chinese MLR2_ES3_footjob_label_3054de58:

    # Mom "You’re acting rather strange - is everything okay, Sweetie?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:595
translate chinese MLR2_ES3_footjob_label_afa56578:

    # MC "Shit! Someone LITERALLY just walked right by us!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:596
translate chinese MLR2_ES3_footjob_label_9df4234e:

    # MC "If they spot us, they might call the police! We're in a public place!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:597
translate chinese MLR2_ES3_footjob_label_32b6856e:

    # Mom "Well, you better hurry up and cum, then. Because this isn’t ending until you do."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:601
translate chinese MLR2_ES3_footjob_label_7467115c:

    # MC "Ahhh... Fuck..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:604
translate chinese MLR2_ES3_footjob_label_c9ee389e:

    # Mom "Oh, is my big boy close?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:605
translate chinese MLR2_ES3_footjob_label_75db9c3e:

    # Mom "Cum for me. Cum all over your mommy’s feet."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:607
translate chinese MLR2_ES3_footjob_label_d0011020:

    # Mom "Oh, are you close?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:608
translate chinese MLR2_ES3_footjob_label_20cf9b78:

    # Mom "Cum for me. Cum all over my feet."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:609
translate chinese MLR2_ES3_footjob_label_29adf468:

    # MC "(Dammit, I have to try and suppress my moaning, in public.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:618
translate chinese MLR2_ES3_footjob_label_90a08020:

    # MC "Hnnnggg.... Ah..... Ugh...."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:620
translate chinese MLR2_ES3_footjob_label_2cdac345:

    # Mom "That’s it! Good boy!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:622
translate chinese MLR2_ES3_footjob_label_4ce033b6:

    # Mom "That’s it. Mmm... Good..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:623
translate chinese MLR2_ES3_footjob_label_1396af60:

    # MC "Fuck... Ah.... Ohhh..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:627
translate chinese MLR2_ES3_footjob_label_ebadc1bb:

    # Mom "Wow - so much cum! You must have been REALLY horny!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:628
translate chinese MLR2_ES3_footjob_label_a7847152:

    # MC "Q-Quiet. Here, take my napkin. Clean your feet quickly, before someone sees!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:629
translate chinese MLR2_ES3_footjob_label_1d546320:

    # MC "(I think that has to be the most dangerous sex I’ve EVER had.)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:630
translate chinese MLR2_ES3_footjob_label_88505f38:

    # Mom "Finish off your wine, if you want. Then we can head home."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:631
translate chinese MLR2_ES3_footjob_label_10d1e5fd:

    # MC "You’ve barely touched YOUR wine."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:632
translate chinese MLR2_ES3_footjob_label_800566a8:

    # Mom "That’s because I’m driving - Safety first, Dear."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:640
translate chinese MLR2_ES3_blowjob_label_ab8e0172:

    # MC "Mom, you’ve got to stop! We’re in public!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:642
translate chinese MLR2_ES3_blowjob_label_04b8a65e:

    # MC "Linda, you’ve got to stop! We’re in public!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:643
translate chinese MLR2_ES3_blowjob_label_07eb54ca:

    # Mom "Aww... Why?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:644
translate chinese MLR2_ES3_blowjob_label_1e8a931d:

    # MC "If a waiter catches us right now, we’ll both be screwed!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:645
translate chinese MLR2_ES3_blowjob_label_a9151642:

    # Mom "*Sigh* If you insist."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:646
translate chinese MLR2_ES3_blowjob_label_55952d17:

    # MC "Thank you."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:647
translate chinese MLR2_ES3_blowjob_label_459ccb13:

    # Mom "At the very least, can I come over and give you a hug?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:648
translate chinese MLR2_ES3_blowjob_label_6cd5d7d5:

    # MC "Sure, that’s perfectly fine."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:652
translate chinese MLR2_ES3_blowjob_label_d84286d4:

    # Mom "See? This is nice."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:653
translate chinese MLR2_ES3_blowjob_label_e463807b:

    # MC "Yeah, it is."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:655
translate chinese MLR2_ES3_blowjob_label_66cbb36a:

    # MC "Thanks for bringing me out tonight, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:657
translate chinese MLR2_ES3_blowjob_label_b3bfa574:

    # MC "Thanks for bringing me out tonight, Linda."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:661
translate chinese MLR2_ES3_blowjob_label_79d71771:

    # Mom "Well, I’d say the pleasure is all mine. But you seem to be enjoying yourself too."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:662
translate chinese MLR2_ES3_blowjob_label_9a2cf3b7:

    # Mom "Do you like looking at my breasts?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:663
translate chinese MLR2_ES3_blowjob_label_38244daa:

    # MC "What- I wasn’t-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:664
translate chinese MLR2_ES3_blowjob_label_88a16011:

    # Mom "Of course you are!"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:670
translate chinese MLR2_ES3_blowjob_label_7a63b9f8:

    # Mom "I mean, what other reason could you POSSIBLY have, for being THIS hard?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:672
translate chinese MLR2_ES3_blowjob_label_cc9d5ceb:

    # MC "Mom! Public!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:674
translate chinese MLR2_ES3_blowjob_label_bbfac1a8:

    # MC "Linda! Public!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:675
translate chinese MLR2_ES3_blowjob_label_63b32175:

    # MC "You can’t just start giving me a handjob in a place like this!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:676
translate chinese MLR2_ES3_blowjob_label_bbf930e7:

    # Mom "Haha! Who said anything about a handjob?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:680
translate chinese MLR2_ES3_blowjob_label_e24f02c2:

    # Mom "*Shlurrrrp!*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:681
translate chinese MLR2_ES3_blowjob_label_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:682
translate chinese MLR2_ES3_blowjob_label_a1146007:

    # Waiter "Is everything alright, Sir?"
    Waiter ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:683
translate chinese MLR2_ES3_blowjob_label_5273b3e7:

    # MC "Y-Yeah, she just -ah- dropped her contact lens!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:687
translate chinese MLR2_ES3_blowjob_label_04340fd0:

    # Waiter "No problem. If you need anything else, give me a shout."
    Waiter ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:688
translate chinese MLR2_ES3_blowjob_label_54ac9d55:

    # Mom "*SUCK! SUCK!*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:690
translate chinese MLR2_ES3_blowjob_label_9c9667c1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:694
translate chinese MLR2_ES3_blowjob_label_f7afa1b7:

    # MC "(I can’t believe she’s doing this right now! What the hell has gotten into her?!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:695
translate chinese MLR2_ES3_blowjob_label_7b68aa61:

    # Mom "*Shlurrrp*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:697
translate chinese MLR2_ES3_blowjob_label_69fc58b8:

    # MC "Ohh... fuck! She's speeded up!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:698
translate chinese MLR2_ES3_blowjob_label_fac134a4:

    # Mom "(I just can’t hold myself back, around him! I need him to cum in my mouth!)"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:702
translate chinese MLR2_ES3_blowjob_label_312847cd:

    # MC "Mmm...."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:704
translate chinese MLR2_ES3_blowjob_label_0d2cef16:

    # MC "(Damn! This feels so good! Mom gives phenomenal blowjobs!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:706
translate chinese MLR2_ES3_blowjob_label_26c479c8:

    # MC "(Damn! This feels so good! Linda gives phenomenal blowjobs!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:707
translate chinese MLR2_ES3_blowjob_label_c984db8c:

    # MC "(There’s so many people around though - I’m lucky we haven’t been spotted yet!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:711
translate chinese MLR2_ES3_blowjob_label_05621810:

    # Mom "*SUCK SUCK SUCK*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:713
translate chinese MLR2_ES3_blowjob_label_d1eeb2c7:

    # MC "Ohhh... Ohhh..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:714
translate chinese MLR2_ES3_blowjob_label_2b87d913:

    # Mom "(I can’t wait for [player_name] to spew his hot cum in my wet mouth!)"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:718
translate chinese MLR2_ES3_blowjob_label_f9f3e033:

    # MC "Ahh... I’m gonna cum soon, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:720
translate chinese MLR2_ES3_blowjob_label_8a3d4a63:

    # MC "Ahh... I’m gonna cum soon, Linda."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:721
translate chinese MLR2_ES3_blowjob_label_65f7466a:

    # Mom "*Lick! Shlurp!*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:723
translate chinese MLR2_ES3_blowjob_label_89296ee4:

    # MC "God..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:727
translate chinese MLR2_ES3_blowjob_label_e678d521:

    # MC "*Pant! Pant!*"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:728
translate chinese MLR2_ES3_blowjob_label_643276e2:

    # Mom "(His cock’s beginning to throb between my lips! Time for the grand finale!)"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:729
translate chinese MLR2_ES3_blowjob_label_6e4121b3:

    # MC "(Any seconds now! Yes!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:733
translate chinese MLR2_ES3_blowjob_label_a560a239:

    # MC "Huh? (Why did she take it out of her mouth?)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:734
translate chinese MLR2_ES3_blowjob_label_d45d17bc:

    # Mom "Aaah..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:736
translate chinese MLR2_ES3_blowjob_label_5243850e:

    # MC "M-Mom? Why did you stop? Is everything-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:738
translate chinese MLR2_ES3_blowjob_label_30a93c63:

    # MC "L-Linda? Why did you stop? Is everything-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:742
translate chinese MLR2_ES3_blowjob_label_5e84f7bf:

    # Mom "*SHLLURRRRRRRRRPPP!!!*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:743
translate chinese MLR2_ES3_blowjob_label_273777b7:

    # MC "OH God! Ahhh! Ahhhh!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:744
translate chinese MLR2_ES3_blowjob_label_ed3a9079:

    # MC "Fuck! I’m cumming... Shit! Hnnnng!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:752
translate chinese MLR2_ES3_blowjob_label_d1ca9a37:

    # Mom "*Gulp! Gulp!*"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:753
translate chinese MLR2_ES3_blowjob_label_e2f4c749:

    # MC "(Holy fuck! She’s swallowing it all as I spray it into her mouth!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:757
translate chinese MLR2_ES3_blowjob_label_38c0e9dc:

    # MC "Holy shit... Phew..."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:758
translate chinese MLR2_ES3_blowjob_label_7c206a9d:

    # MC "That was fucking incredible!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:759
translate chinese MLR2_ES3_blowjob_label_332e204b:

    # Mom "I’m glad you enjoyed it, Sweetie."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:760
translate chinese MLR2_ES3_blowjob_label_12124d8f:

    # MC "Were you not afraid of getting caught?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:761
translate chinese MLR2_ES3_blowjob_label_88a34243:

    # Mom "Honestly - that just makes it even hotter for me."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:772
translate chinese MLR2_ES3_end_label_a15179e5:

    # MC "Thanks again for taking me out for dinner. I had a really good time, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:774
translate chinese MLR2_ES3_end_label_234aa1c5:

    # MC "Thanks again for taking me out for dinner. I had a really good time, Linda."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:775
translate chinese MLR2_ES3_end_label_a1736ca2:

    # Mom "Me too, Sweetie. I can’t wait to do it again."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:776
translate chinese MLR2_ES3_end_label_38c00572:

    # MC "So, are we going home now or-"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:780
translate chinese MLR2_ES3_end_label_aea6b299:

    # MC "Mom, what’s wrong? Are you alright?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:782
translate chinese MLR2_ES3_end_label_949c4c70:

    # MC "Linda, what’s wrong? Are you alright?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:783
translate chinese MLR2_ES3_end_label_eeecef80:

    # Mom "I- I’m fine..."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:784
translate chinese MLR2_ES3_end_label_9a872aa9:

    # MC "You suddenly looked sad there."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:788
translate chinese MLR2_ES3_end_label_be79ab75:

    # MC "W-Was it something I said?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:789
translate chinese MLR2_ES3_end_label_00d55ada:

    # Mom "No."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:790
translate chinese MLR2_ES3_end_label_29a28e16:

    # MC "Did- Is this about me not bringing flowers or chocolates? I swear to God, I didn't know if this was supposed to be a date or not."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:795
translate chinese MLR2_ES3_end_label_922d3921:

    # Mom "It’s not that."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:797
translate chinese MLR2_ES3_end_label_af310fc2:

    # Mom "Your father is at home right now. The date ends as soon as we get home."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:799
translate chinese MLR2_ES3_end_label_0ddb7420:

    # Mom "My husband is at home right now. The date ends as soon as we get home."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:800
translate chinese MLR2_ES3_end_label_9deb2831:

    # MC "(So it WAS a date!)"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:801
translate chinese MLR2_ES3_end_label_e4454a55:

    # MC "Hey, that’s okay."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:805
translate chinese MLR2_ES3_end_label_7bb1ad78:

    # MC "We’ll have loads more dates together, in the future."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:807
translate chinese MLR2_ES3_end_label_c8b77e93:

    # MC "And we can hang out together when Dad goes on his business trips. Okay?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:809
translate chinese MLR2_ES3_end_label_42874bc4:

    # MC "And we can hang out together when Bob goes on his business trips. Okay?"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:811
translate chinese MLR2_ES3_end_label_3463417b:

    # Mom "*Sniff* Promise?"
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:813
translate chinese MLR2_ES3_end_label_0e92612e:

    # MC "I promise, Mom."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:815
translate chinese MLR2_ES3_end_label_2f3a36e0:

    # MC "I promise, Linda."
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:821
translate chinese MLR2_ES3_end_label_8a22ce72:

    # Mom "Thank you so much, [player_name]. I couldn’t have asked for a kinder boy."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:822
translate chinese MLR2_ES3_end_label_585b20f0:

    # Mom "Let’s get home before your father starts to wonder where we both are."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:823
translate chinese MLR2_ES3_end_label_861d35e0:

    # MC "Okay, Mom. Love you!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:825
translate chinese MLR2_ES3_end_label_c4b77b95:

    # Mom "Thank you so much, [player_name]. You’re so kind."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:826
translate chinese MLR2_ES3_end_label_4a6133ff:

    # Mom "Let’s get home before Bob starts to wonder where we both are."
    Mom ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:827
translate chinese MLR2_ES3_end_label_f169098f:

    # MC "Okay, Linda. Love you!"
    MC ""

# game/scripts/home/garage/evening/scenes/MLR2_ES3_label.rpy:828
translate chinese MLR2_ES3_end_label_c6f945cd:

    # Mom "Love you too, Sweetie."
    Mom ""

