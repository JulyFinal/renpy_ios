﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:22
translate chinese ml_bedroom_book_scene_v1_label_f03f78e7:

    # MC "(Ahh, this looks like the book Mom was reading when she was fucking Dad the other night!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:24
translate chinese ml_bedroom_book_scene_v1_label_22e431b6:

    # MC "(Ahh, this looks like the book Linda was reading when she was fucking Bob the other night!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:25
translate chinese ml_bedroom_book_scene_v1_label_31898fef:

    # MC "(I wonder what could possibly be more interesting than having sex?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:26
translate chinese ml_bedroom_book_scene_v1_label_dfa67d37:

    # MC "(Let’s turn this over...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:29
translate chinese ml_bedroom_book_scene_v1_label_bb861e24:

    # MC "Dating your... son?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:30
translate chinese ml_bedroom_book_scene_v1_label_ee1c5b04:

    # MC "How to tell if he... is SEXUALLY ATTRACTED to you?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:32
translate chinese ml_bedroom_book_scene_v1_label_1b831d2f:

    # MC "“Cougar: The Milf’s Guide to Dating a Younger Man.”"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:33
translate chinese ml_bedroom_book_scene_v1_label_44a1bea0:

    # MC "“How to tell if a younger man is attracted to you?!”"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:35
translate chinese ml_bedroom_book_scene_v1_label_edd01079:

    # MC "Holy moly!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:36
translate chinese ml_bedroom_book_scene_v1_label_c0a2b8f1:

    # MC "(Wait... Wait... Is this written by Judy?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:37
translate chinese ml_bedroom_book_scene_v1_label_9dfe9f81:

    # MC "(This Judy? My therapist?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:38
translate chinese ml_bedroom_book_scene_v1_label_799f9d34:

    # MC "(I should talk with her.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:39
translate chinese ml_bedroom_book_scene_v1_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:40
translate chinese ml_bedroom_book_scene_v1_label_1d1cd181:

    # MC "(Is Linda just reading this for fun?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:41
translate chinese ml_bedroom_book_scene_v1_label_6f870855:

    # MC "(No... she must be serious.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:42
translate chinese ml_bedroom_book_scene_v1_label_eaba67b2:

    # MC "(The way she kissed me, so intensely that morning, and the weird way she’s been acting around me.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:44
translate chinese ml_bedroom_book_scene_v1_label_74d89ee5:

    # MC "(Is she thinking about fucking me when she’s with Dad?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:46
translate chinese ml_bedroom_book_scene_v1_label_006e8987:

    # MC "(Is she thinking about fucking me when she’s with Bob? Married?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:48
translate chinese ml_bedroom_book_scene_v1_label_de383788:

    # MC "Fuck... It all makes sense now."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:50
translate chinese ml_bedroom_book_scene_v1_label_ff86af97:

    # MC "(My own mother wants to fuck me!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:51
translate chinese ml_bedroom_book_scene_v1_label_71a09627:

    # MC "(How the heck am I even supposed to respond to this?!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:52
translate chinese ml_bedroom_book_scene_v1_label_d570fa34:

    # MC "(God... I’ll never be able to look her straight, in the eyes again!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:53
translate chinese ml_bedroom_book_scene_v1_label_68dda312:

    # MC "(Mom’s lucky that Dad isn’t paying attention to the books she reads! If he caught her with this, he’d be furious!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:55
translate chinese ml_bedroom_book_scene_v1_label_1fa1bbc7:

    # MC "(Linda wants to fuck me!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:56
translate chinese ml_bedroom_book_scene_v1_label_71a09627_1:

    # MC "(How the heck am I even supposed to respond to this?!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:57
translate chinese ml_bedroom_book_scene_v1_label_d570fa34_1:

    # MC "(God... I’ll never be able to look her straight, in the eyes again!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:58
translate chinese ml_bedroom_book_scene_v1_label_b7eebf7d:

    # MC "(Linda’s lucky that Bob isn’t paying attention to the books she reads! If he caught her with this, he’d be furious!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:81
translate chinese ml_bedroom_book_scene_v1_label_5226ac19:

    # MC "(I've already checked that book.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/ml_bedroom_book_scene_v1.rpy:83
translate chinese ml_bedroom_book_scene_v1_label_043edaf0:

    # MC "(It's better not to touch that book when someone is in the room...)"
    MC ""

