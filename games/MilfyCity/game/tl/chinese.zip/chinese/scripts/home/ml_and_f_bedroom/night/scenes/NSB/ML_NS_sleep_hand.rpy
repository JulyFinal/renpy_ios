﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:21
translate chinese ML_NS_sleep_hand_label_ffbfdcb3:

    # Mom "I’m going to take the lead tonight. Go ahead and lie back on the bed."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:22
translate chinese ML_NS_sleep_hand_label_34b36f2b:

    # MC "What about [Dad_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:26
translate chinese ML_NS_sleep_hand_label_c537d12b:

    # Mom "Relax. Your father isn’t going to wake up. As long as you don’t wriggle about too much, or make a lot of noise, you’ll be fine."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:28
translate chinese ML_NS_sleep_hand_label_06ef8a0b:

    # Mom "Relax. Bob isn’t going to wake up. As long as you don’t wriggle about too much, or make a lot of noise, you’ll be fine."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:29
translate chinese ML_NS_sleep_hand_label_9608ebd3:

    # MC "If you’re sure..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:30
translate chinese ML_NS_sleep_hand_label_467fc930:

    # Mom "I’m certain. I’ve spent YEARS lying beside that fat oaf. I know exactly what it takes to rouse him."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:34
translate chinese ML_NS_sleep_hand_label_36d6c6e9:

    # Mom "Now, onto the important part. I’m going to give you the best handjob you’ll ever have."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:35
translate chinese ML_NS_sleep_hand_label_cb48119e:

    # MC "That’s quite a bold claim to make!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:36
translate chinese ML_NS_sleep_hand_label_a9d05cac:

    # Mom "Why? Have other girls been giving you handjobs to compare it to?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:37
translate chinese ML_NS_sleep_hand_label_bbfed4a1:

    # MC "Err... N-No!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:41
translate chinese ML_NS_sleep_hand_label_3be37acc:

    # MC "Sorry, I’m just really nervous, lying so close to [Dad_name], here."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:43
translate chinese ML_NS_sleep_hand_label_7076dadf:

    # Mom "I already told you, your father’s not going to wake up. Heaven help us all if a burglar broke into our house. They’d be able to nick everything except the bed he was sleeping on."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:45
translate chinese ML_NS_sleep_hand_label_640f29cc:

    # Mom "I already told you, Bob’s not going to wake up. Heaven help us all if a burglar broke into our house. They’d be able to nick everything except the bed Bob was sleeping on."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:49
translate chinese ML_NS_sleep_hand_label_70669a46:

    # Mom "You’re nice and hard for me already - that’s good. I love it when I don’t have to help a guy get it up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:51
translate chinese ML_NS_sleep_hand_label_00c94a90:

    # MC "Heh, I’m almost always hard when I’m around you, [Mom_name]. Especially when you’re dressed like this."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:52
translate chinese ML_NS_sleep_hand_label_d6bdde29:

    # MC "You look so damn sexy in that skimpy bra."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:56
translate chinese ML_NS_sleep_hand_label_e44c1ee7:

    # Mom "It’s nice to be appreciated. How does this feel?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:57
translate chinese ML_NS_sleep_hand_label_36e29de0:

    # MC "Mmm... It’s so good, [Mom_name]. Don’t stop."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:58
translate chinese ML_NS_sleep_hand_label_aae536f7:

    # Mom "Oh, I’m not planning on stopping, anytime soon."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:62
translate chinese ML_NS_sleep_hand_label_33816539:

    # MC "(She’s so skilled with her hand. I thought she might not have been as good with her left, but she’s doing great!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:65
translate chinese ML_NS_sleep_hand_label_2b443cfc:

    # MC "Ah... Keep doing that, [Mom_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:66
translate chinese ML_NS_sleep_hand_label_475681ed:

    # Mom "You love my hand so much? What if I stop?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:67
translate chinese ML_NS_sleep_hand_label_b4b1d83c:

    # MC "No... Continue..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:68
translate chinese ML_NS_sleep_hand_label_14199df3:

    # Mom "You have to ask for it nicely..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:69
translate chinese ML_NS_sleep_hand_label_64df182c:

    # MC "Please... Do not stop, [Mom_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:73
translate chinese ML_NS_sleep_hand_label_07de6ebb:

    # Mom "Sure, Sweetie. I’ll get back to focusing on rubbing your cock now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:74
translate chinese ML_NS_sleep_hand_label_024f32aa:

    # Dad "Zzz...."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:78
translate chinese ML_NS_sleep_hand_label_953606d7:

    # MC "Mmm... That’s good..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:79
translate chinese ML_NS_sleep_hand_label_e7debdfa:

    # MC "I’m gonna cum pretty soon if you keep focusing on the tip, like that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:80
translate chinese ML_NS_sleep_hand_label_8260b87c:

    # Mom "You mean, if I keep doing this?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:84
translate chinese ML_NS_sleep_hand_label_bc0dac99:

    # MC "Hnnng... Yes, that!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:85
translate chinese ML_NS_sleep_hand_label_3f90ae59:

    # Mom "It must be REALLY sensitive when I rub it like this, here. I bet you it feels sooo good, right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:94
translate chinese ML_NS_sleep_hand_label_3d53ada4:

    # MC "Oh fuck... Hnnng... ugh! I’m cumming!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:99
translate chinese ML_NS_sleep_hand_label_0d343745:

    # Mom "Wow! You really must have enjoyed that. Sorry again, for scaring you with the sorority joke. I picked up my handjob skills from months of not wanting to fuck your father."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:101
translate chinese ML_NS_sleep_hand_label_5297adcf:

    # Mom "Wow! You really must have enjoyed that. Sorry again for scaring you with the sorority joke. I picked up my handjob skills from months of not wanting to fuck my husband."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:103
translate chinese ML_NS_sleep_hand_label_aec993dd:

    # MC "Ahh... that makes sense."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:104
translate chinese ML_NS_sleep_hand_label_4bca5780:

    # Mom "I love you so much, [player_name]. Thanks for taking the time to come and visit me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:108
translate chinese ML_NS_sleep_hand_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:109
translate chinese ML_NS_sleep_hand_label_a839d6f3:

    # Mom "Mwah..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:113
translate chinese ML_NS_sleep_hand_label_edf721c8:

    # Mom "You better sneak back into your room now. We’ve gotten away with a lot tonight - and there’s no sense, tempting fate any more than we have."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_hand.rpy:114
translate chinese ML_NS_sleep_hand_label_e6de4668:

    # MC "Good call. I’ll see you tomorrow, [Mom_name]."
    MC ""

