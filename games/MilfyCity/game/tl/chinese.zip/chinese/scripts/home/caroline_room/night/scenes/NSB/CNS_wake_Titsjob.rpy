﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:20
translate chinese CNS_wake_Titsjob_label_fd45bd3b:

    # MC "Are you up for giving me a boobjob tonight?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:21
translate chinese CNS_wake_Titsjob_label_d99f1719:

    # Caroline "Hehe, sure. You’re still thinking about that time I gave you a boobjob in my cosplay outfit, aren’t you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:22
translate chinese CNS_wake_Titsjob_label_b08f46a5:

    # MC "Of course I am! That was one of the sexiest things you’ve ever done for me!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:26
translate chinese CNS_wake_Titsjob_label_70e7a719:

    # Caroline "Well, let’s see if we can top that tonight. I’m gonna give you the BEST boobjob of your life."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:27
translate chinese CNS_wake_Titsjob_label_7fd25fd1:

    # MC "Oh really? You sound pretty confident about that!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:28
translate chinese CNS_wake_Titsjob_label_4d5d873f:

    # Caroline "Of course I am!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:32
translate chinese CNS_wake_Titsjob_label_86704939:

    # Caroline "They’re kinda my specialty."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:33
translate chinese CNS_wake_Titsjob_label_5790f007:

    # Caroline "You probably don’t realise it yet - but you’re in for a real treat."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:34
translate chinese CNS_wake_Titsjob_label_5789afc7:

    # MC "Haha, I’m looking forward to this!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:38
translate chinese CNS_wake_Titsjob_label_9c9b76a1:

    # Caroline "The trick to giving a good boobjob is knowing to apply, just the right amount of pressure."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:39
translate chinese CNS_wake_Titsjob_label_c4ea4a4f:

    # Caroline "Breasts are a lot softer than hands, so you’ve got to really hold them together to get the same kind of effect as a handjob would give."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:40
translate chinese CNS_wake_Titsjob_label_88815ebe:

    # MC "Mmm... uh huh."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:41
translate chinese CNS_wake_Titsjob_label_eb436581:

    # Caroline "On the other hand, there is a lot of surface area to play with. You can really massage the entire cock every time you move up and down."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:42
translate chinese CNS_wake_Titsjob_label_1cfbeb87:

    # Caroline "If I do this, I can completely envelop your cock between them. Feels good, right?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:43
translate chinese CNS_wake_Titsjob_label_9ba5c4c9:

    # MC " Mmm, so good!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:47
translate chinese CNS_wake_Titsjob_label_c5943ad7:

    # Caroline "Just lie back and enjoy this. Let me take care of your hard cock."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:48
translate chinese CNS_wake_Titsjob_label_7cb5691f:

    # MC "Ah... Ugh... Oh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:49
translate chinese CNS_wake_Titsjob_label_6b759a80:

    # MC "(Fuck, this feels amazing!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:50
translate chinese CNS_wake_Titsjob_label_2d53dc53:

    # Caroline "Wow, you’re REALLY hard right now. You must be loving the feel of my tits against your cock."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:51
translate chinese CNS_wake_Titsjob_label_523bd922:

    # MC "The view helps too!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:52
translate chinese CNS_wake_Titsjob_label_cea570d3:

    # Caroline "Hehe, I’m sure it does."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:56
translate chinese CNS_wake_Titsjob_label_8b5c6aeb:

    # MC "Ah! Ah.... Oh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:57
translate chinese CNS_wake_Titsjob_label_fc4997f3:

    # Caroline "Okay, that’s me in a rhythm now. Let’s see how long you can last, with me doing this."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:58
translate chinese CNS_wake_Titsjob_label_585ba011:

    # MC "Ah Oh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:62
translate chinese CNS_wake_Titsjob_label_d5ebe505:

    # Caroline "There’s one way that I could make this feel even better for you."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:63
translate chinese CNS_wake_Titsjob_label_a028288a:

    # MC "Ah... oh yeah?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:65
translate chinese CNS_wake_Titsjob_label_bbdb6ea6:

    # Caroline "Unfortunately, I can’t do it right now. But let me tell you about it."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:66
translate chinese CNS_wake_Titsjob_label_e2532732:

    # Caroline "I’d take your cock between my tits, just like this."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:67
translate chinese CNS_wake_Titsjob_label_259316b1:

    # Caroline "Except, when you thrust up, I’d open my mouth and engulf the tip of your cock."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:68
translate chinese CNS_wake_Titsjob_label_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:72
translate chinese CNS_wake_Titsjob_label_8a0c08ba:

    # Caroline "Each time your dick reached my lips, I would suck it in and twirl my tongue around the tip, bringing you closer and closer to a climax with each thrust."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:73
translate chinese CNS_wake_Titsjob_label_269d2049:

    # Caroline "Maybe I’d even start sucking on it, bobbing my head up and down."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:74
translate chinese CNS_wake_Titsjob_label_7aba33dc:

    # Caroline "It sounds good, right?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:78
translate chinese CNS_wake_Titsjob_label_2fba821f:

    # MC "Hnnng... so good..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:79
translate chinese CNS_wake_Titsjob_label_176a6f7a:

    # Caroline "And then, when it looked like you were about to cum, I would start moving my tits up and down even quicker."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:80
translate chinese CNS_wake_Titsjob_label_7a91f919:

    # MC "Ah! Ah! Ahhh...."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:82
translate chinese CNS_wake_Titsjob_label_a8d17f07:

    # Caroline "Then, when you least expect it, I’d release your cock from my tits and deepthroat it."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:83
translate chinese CNS_wake_Titsjob_label_f7509ec2:

    # Caroline "I’d wrap my lips around your shaft and suck so, so hard. The vacuum sensation would send shivers down your spine and make your balls clench up."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:84
translate chinese CNS_wake_Titsjob_label_4b2f047b:

    # Caroline "Are you thinking about this as I describe it to you, [player_name]?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:85
translate chinese CNS_wake_Titsjob_label_8c2da12d:

    # MC "Y-Yeah..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:89
translate chinese CNS_wake_Titsjob_label_d4d362cf:

    # Caroline "I want you to imagine yourself having the semen sucked from your cock as you are forced to cum in my mouth."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:90
translate chinese CNS_wake_Titsjob_label_e72e64d5:

    # MC "Hnnnnggg!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:92
translate chinese CNS_wake_Titsjob_label_33efed2c:

    # Caroline "You’d quiver and moan and shake. You’d cry that it’s too sensitive. But I’m a good sister, and I just wouldn’t stop sucking until I was certain that I’d drained every last droplet of cum from your body."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:94
translate chinese CNS_wake_Titsjob_label_fd86b2f7:

    # Caroline "You’d quiver and moan and shake. You’d cry that it’s too sensitive. But I’m a good girl, and I just wouldn’t stop sucking until I was certain that I’d drained every last droplet of cum from your body."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:97
translate chinese CNS_wake_Titsjob_label_726c63d4:

    # MC "HNNNGGG!!! AHHHH! Fuck! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:98
translate chinese CNS_wake_Titsjob_label_86e4fbe1:

    # Caroline "That’s it! Blow your hot load over my tits."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:99
translate chinese CNS_wake_Titsjob_label_4c937c1d:

    # MC "Ah! Fuck! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:111
translate chinese CNS_wake_Titsjob_label_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:112
translate chinese CNS_wake_Titsjob_label_08b1d5c6:

    # Caroline "Well? Best titjob you’ve ever had?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_Titsjob.rpy:113
translate chinese CNS_wake_Titsjob_label_d8a74ae1:

    # MC "Hell yeah, there’s no competition..."
    MC ""

