﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:25
translate chinese CR3_ES2_label_08728b1a:

    # MC "I've already talked to her."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:39
translate chinese CR3_ES2_label_d8f79971:

    # MC "(Heh... I always walk in at the best moments. Just look at that view!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:40
translate chinese CR3_ES2_label_2d25ab5c:

    # MC "(I can see all the way up to her panties. God, I’d love to just - tear them off her - right now!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:44
translate chinese CR3_ES2_label_9b70e4ce:

    # MC "Hey Caroline, what’s up?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:45
translate chinese CR3_ES2_label_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:46
translate chinese CR3_ES2_label_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:50
translate chinese CR3_ES2_label_30764a60:

    # Caroline "Hmm? Oh! Sorry, I’m just in the middle of something, here. Give me two seconds, and I’ll be with you."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:51
translate chinese CR3_ES2_label_8df3e8f6:

    # MC "No problem. Take your time."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:52
translate chinese CR3_ES2_label_b7ddf9cd:

    # MC "(It must be something really engrossing! I was standing right beside her, and it was like, she didn't even see me!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:56
translate chinese CR3_ES2_label_e66e99a7:

    # Caroline "Sorry about that. What’s up?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:57
translate chinese CR3_ES2_label_ed14b2cf:

    # MC "Well, I just wanted to try out our - new and improved - deal."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:58
translate chinese CR3_ES2_label_c34df95e:

    # Caroline "Oh yeah? What were you thinking of doing?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:62
translate chinese CR3_ES2_label_9b128b63:

    # MC "I was hoping to kiss you on the lips - for a change. They’re included in the package now, right?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:63
translate chinese CR3_ES2_label_7c8217a0:

    # Caroline "Hehe - that’s such an ugly way to put it. Yes, my lips are included in our new deal."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:64
translate chinese CR3_ES2_label_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:68
translate chinese CR3_ES2_label_7341d606:

    # Caroline "So, what do you want to do to me? Lie down beside me, on the bed and make out?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:69
translate chinese CR3_ES2_label_f38d0f89:

    # Caroline "Or would you prefer to - pin me - against my bedroom wall and ravage my neck?"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:70
translate chinese CR3_ES2_label_ab0e464e:

    # Caroline "Or perhaps..."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:74
translate chinese CR3_ES2_label_ca130ef3:

    # Caroline "...you’d like me to seize the initiative - and go on top."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:75
translate chinese CR3_ES2_label_bd90e4e5:

    # MC "Mmm... I’d like that very much."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:76
translate chinese CR3_ES2_label_499a59e8:

    # Caroline "I hope you enjoy this new deal, as much as I do."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:80
translate chinese CR3_ES2_label_1e959b08:

    # Caroline "*Whispered* You really have no idea how lucky a guy you are."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:82
translate chinese CR3_ES2_label_b19f16fa:

    # MC "(That probably says a lot more about Caroline’s taste in men, than it does about her!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:86
translate chinese CR3_ES2_label_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:87
translate chinese CR3_ES2_label_f42cbe12:

    # MC "(Oh wow! She’s an amazing kisser!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:88
translate chinese CR3_ES2_label_1ab2a350:

    # MC "(Why couldn’t THIS have been included in the original deal? I missed out on weeks of - great making out!)"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:92
translate chinese CR3_ES2_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:93
translate chinese CR3_ES2_label_0fc43a94:

    # Caroline "(Hehe. I love hearing a guy moan, when I kiss him. It’s just-)"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:95
translate chinese CR3_ES2_label_7b151263:

    # "*Bzzt Bzzt*"
    ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:99
translate chinese CR3_ES2_label_a9882b3f:

    # MC "Huh? What’s that noise?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:100
translate chinese CR3_ES2_label_c5deb1e8:

    # Caroline "Gah! Ignore it. It’s my stupid phone."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:102
translate chinese CR3_ES2_label_0abb44c3:

    # "*Bzzt Bzzt Bzzt*"
    ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:103
translate chinese CR3_ES2_label_fc508f45:

    # MC "Geez! Aren’t you going to answer it?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:104
translate chinese CR3_ES2_label_6b26e3c8:

    # Caroline "No - wait!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:105
translate chinese CR3_ES2_label_89eb87ce:

    # MC "Huh? They hung up anyway."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:110
translate chinese CR3_ES2_label_223a8c5a:

    # MC "Wait..."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:111
translate chinese CR3_ES2_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:113
translate chinese CR3_ES2_label_51973d44:

    # MC "Jesus Christ! Who the hell is that, Sis?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:115
translate chinese CR3_ES2_label_f2b67875:

    # MC "Jesus Christ! Who the hell is that, Caroline?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:119
translate chinese CR3_ES2_label_0a2ed3e1:

    # Caroline "I- Uh- It’s nothing!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:120
translate chinese CR3_ES2_label_52f0a79a:

    # MC "What kind of dickhead is calling you - and sending creepy messages?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:121
translate chinese CR3_ES2_label_6e18b6ef:

    # Caroline "It’s no one - seriously!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:125
translate chinese CR3_ES2_label_02d945a1:

    # MC "You clearly know them. Who is it? Are they bullying you?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:126
translate chinese CR3_ES2_label_3d83100a:

    # Caroline "*Sigh* It’s my ex. He’s a dickhead. He’s been spamming me with calls and texts since that night out."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:127
translate chinese CR3_ES2_label_d0c24a70:

    # MC "Jesus! You should really block his number."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:131
translate chinese CR3_ES2_label_08a693f1:

    # Caroline "I thought about doing that - but then, if he ever does something to hurt me, I won’t have the evidence."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:132
translate chinese CR3_ES2_label_6c85be32:

    # Caroline "At least this way, I’ll have a string of text messages I can always take to the police, if required."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:133
translate chinese CR3_ES2_label_c7bc2ae8:

    # MC "That makes sense, good call. Do you need me to help in any way?"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:137
translate chinese CR3_ES2_label_9aaee13a:

    # Caroline "Haha! You? Help me? Hahaha!"
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:138
translate chinese CR3_ES2_label_c42ad36b:

    # MC "Oof!"
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:139
translate chinese CR3_ES2_label_734b8e2b:

    # Caroline "You couldn’t even beat ME in a fight, let alone my ex."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:143
translate chinese CR3_ES2_label_55f726fd:

    # Caroline "Thanks for the offer, though. Don’t worry about me - I’ll handle this one."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:144
translate chinese CR3_ES2_label_707a6ac4:

    # MC "Okay. As long as you’re absolutely sure."
    MC ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:145
translate chinese CR3_ES2_label_d7fb0627:

    # Caroline "I’ll be fine. Catch you later on, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/evening/scenes/CR3_ES2.rpy:146
translate chinese CR3_ES2_label_14a710e8:

    # MC "See ya, Caroline."
    MC ""

