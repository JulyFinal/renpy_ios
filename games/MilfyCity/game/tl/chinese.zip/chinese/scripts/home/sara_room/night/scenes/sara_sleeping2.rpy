﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:97
translate chinese sara_room_night_sleeping2_label_03a9441e:

    # MC "(I've already been near her bed. I don't want to wake her up.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:107
translate chinese sara_room_night_sleeping2_label_00a7070e:

    # MC "Hey, Sara? Are you awake?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:109
translate chinese sara_room_night_sleeping2_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:111
translate chinese sara_room_night_sleeping2_label_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:115
translate chinese sara_room_night_sleeping2_label_fd258848:

    # Sara "Go away, [player_name]. I don't want to talk to you right now."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:119
translate chinese sara_room_night_sleeping2_label_9e64bfcf:

    # MC "Oh, c'mon Sara. You always love it when I come to visit you at-"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:123
translate chinese sara_room_night_sleeping2_label_7123c280:

    # Sara "Go away. I'm sick to my stomach thinking about you and that bitch, Lily."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:125
translate chinese sara_room_night_sleeping2_label_cf4e28e2:

    # MC "Sara, I-"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:127
translate chinese sara_room_night_sleeping2_label_16855da4:

    # Sara "Please... Just go."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:131
translate chinese sara_room_night_sleeping2_label_bb015ea1:

    # MC "Gulp I'm sorry, Sara..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:133
translate chinese sara_room_night_sleeping2_label_4676d717:

    # MC "(I should try and resolve things with Lily first.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:145
translate chinese sara_room_night_sleeping2_label_2178f9d0:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:146
translate chinese sara_room_night_sleeping2_label_84a95f96:

    # MC "Psst, Sara! Are you awake?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:147
translate chinese sara_room_night_sleeping2_label_2c04d20e:

    # Sara "Hmm?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:150
translate chinese sara_room_night_sleeping2_label_7fd5852d:

    # Sara "[player_name]? It’s not time for college yet, is it?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:151
translate chinese sara_room_night_sleeping2_label_390de3b9:

    # MC "Haha, no. It’s the middle of the night. I actually came in to see if you wanted to mess around."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:152
translate chinese sara_room_night_sleeping2_label_91c2eead:

    # Sara "Mess around?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:155
translate chinese sara_room_night_sleeping2_label_13c1d45e:

    # MC "Yeah, I was thinking that you could pretend to be asleep, and I would play with your body."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:156
translate chinese sara_room_night_sleeping2_label_8cb8710c:

    # MC "So, what do you think?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:159
translate chinese sara_room_night_sleeping2_label_62ec64dd:

    # Sara "Mmm, that sounds kinda fun..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:160
translate chinese sara_room_night_sleeping2_label_7739382c:

    # MC "Are we good to try it now then?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:161
translate chinese sara_room_night_sleeping2_label_0e09a129:

    # Sara "Yeah, let’s give it a go."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:164
translate chinese sara_room_night_sleeping2_label_642d93a4:

    # MC "Great, just let me know what you’re comfortable with."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:165
translate chinese sara_room_night_sleeping2_label_34e03f9e:

    # Sara "Cool, will do!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:169
translate chinese sara_room_night_sleeping2_label_29c857f9:

    # MC "(She’s pretending to be asleep. Let’s see how she enjoys me exploring her body.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:170
translate chinese sara_room_night_sleeping2_label_d68be153:

    # MC "(Hmm, should I make her touch my cock? Or maybe I should fuck her mouth? Or, I could rub my cock between her thighs?)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:171
translate chinese sara_room_night_sleeping2_label_7a9bae74:

    # MC "(Alternatively, I could pull her panties aside and finger her.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:181
translate chinese sara_room_night_sleeping2_label_8765e1c5:

    # MC "(Quietly does it... Let’s see how far I can get without waking her.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:182
translate chinese sara_room_night_sleeping2_label_8944ae0d:

    # MC "(She’s gorgeous when she’s asleep. If only she was that peaceful when she was awake!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:183
translate chinese sara_room_night_sleeping2_label_5c625c40:

    # Sara "Zzzz...."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:184
translate chinese sara_room_night_sleeping2_label_a250fd92:

    # MC "(Let’s see if I can carefully pull down the bedsheets again. I’ve been getting a LOT of practice doing this lately!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:190
translate chinese sara_room_night_sleeping2_label_8c78ee22:

    # MC "(There we go.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:191
translate chinese sara_room_night_sleeping2_label_17f155f9:

    # MC "(Damn, she’s really sexy. I wonder how she’d react, if I woke her up?)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:201
translate chinese sara_room_night_sleeping2_label_f04c6187:

    # MC "(She’s fast asleep. This gives me a good opportunity to explore her body.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:202
translate chinese sara_room_night_sleeping2_label_56e2565a:

    # MC "(Hmm, should I make her touch my cock? Or maybe I should fuck her mouth? Or I could rub my cock between her thighs?)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:203
translate chinese sara_room_night_sleeping2_label_7a9bae74_1:

    # MC "(Alternatively, I could pull her panties aside and finger her.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:248
translate chinese SNS_4_aef86fc6:

    # MC "(Let’s get a look at her cute little pussy again.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:249
translate chinese SNS_4_ebf40bb1:

    # MC "(Easy does it... Almost there.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:250
translate chinese SNS_4_7230c499:

    # MC "Wow... (Her skin is so smooth down there.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:252
translate chinese SNS_4_6e8dad7f:

    # MC "(Sara looks so fucking tight. I bet, fucking her would be the closest thing to, heaven on Earth!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:255
translate chinese SNS_4_8ed92dc4:

    # MC "(I simply HAVE to put a finger in and feel inside.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:259
translate chinese SNS_4_1c960d4e:

    # MC "(It looks like she’s already a bit wet, from me touching her.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:261
translate chinese SNS_4_9df99630:

    # Sara "(Ahh... He’s good with his fingers...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:262
translate chinese SNS_4_1526e373:

    # MC "(It should be easy for me to slide my finger in.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:265
translate chinese SNS_4_adeabe97:

    # MC "(Mmm, it feels so warm inside her!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:266
translate chinese SNS_4_ebb66cc8:

    # MC "(My cock would fit perfectly, in there.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:267
translate chinese SNS_4_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:271
translate chinese SNS_4_8bd80290:

    # MC "(It sounds like Sara’s enjoying this, even if she is sleeping.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:273
translate chinese SNS_4_ae4f9a74:

    # MC "(It sounds like Sara is definitely enjoying this sleep roleplay!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:274
translate chinese SNS_4_8a7e11b6:

    # MC "(I can probably get away with going a bit deeper.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:277
translate chinese SNS_4_2b253959:

    # Sara "Ah..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:280
translate chinese SNS_4_5b835e05:

    # Sara "(Wow, this feels amazing!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:282
translate chinese SNS_4_bdcbe20b:

    # MC "(Her breathing is growing heavier now.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:287
translate chinese SNS_4_5c3e8866:

    # Sara "(It’s starting to get a bit too intense. I think I’ll pretend to wake up now.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:289
translate chinese SNS_4_8cee1a27:

    # Sara "Hmm... Mmm..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:291
translate chinese SNS_4_570c6e0c:

    # MC "(Uh oh, she’s started shifting. I think that’s her waking up now!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:292
translate chinese SNS_4_3e419856:

    # MC "(Let’s creep out of here before she notices me.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:295
translate chinese SNS_4_354645e4:

    # Sara "(Uh... What time is it?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:296
translate chinese SNS_4_77c5e0aa:

    # Sara "(Why is my vagina all wet? And why am I feeling so horny?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:299
translate chinese SNS_4_85a93602:

    # MC "(She’s started shifting in the bed, I think that’s time for me to stop now.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:302
translate chinese SNS_4_f889625a:

    # Sara "(Mmm... That was fun!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:303
translate chinese SNS_4_5c27f397:

    # Sara "(God, I’m so wet right now. [player_name] is really good with his fingers!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:317
translate chinese SNS_5_05df0c5c:

    # MC "(Sara’s already in a good position for me to fuck her thigh. I can make the most of this!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:319
translate chinese SNS_5_80564582:

    # MC "(Here we go...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:321
translate chinese SNS_5_af9d545a:

    # MC "(Alright, here we go... Let’s see if she enjoys this.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:324
translate chinese SNS_5_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:329
translate chinese SNS_5_b0580c77:

    # MC "(That’s good... I’m hoping that she doesn’t wake up though. The back of the knee can be quite sensitive - and I know that Sara is VERY ticklish!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:331
translate chinese SNS_5_83fa5d46:

    # MC "(My cock feels so good between her thighs... I’m hoping she enjoys this too!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:332
translate chinese SNS_5_93493300:

    # Sara "(I didn’t know, [player_name] likes it. It’s kindy funny.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:334
translate chinese SNS_5_991d6a53:

    # MC "Ah... Ohh..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:336
translate chinese SNS_5_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:337
translate chinese SNS_5_36e6d205:

    # MC "(Sounds like she’s a deep sleeper. I might actually get to cum!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:339
translate chinese SNS_5_24c0f79e:

    # Sara "(Mmm... This is really hot! I wonder if I should pretend to snore in order to sell it?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:342
translate chinese SNS_5_a040c89c:

    # MC "(I’m gonna thrust a bit deeper now.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:343
translate chinese SNS_5_5c625c40:

    # Sara "Zzzz...."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:346
translate chinese SNS_5_dcfb2dc2:

    # Sara "(I wonder if he’s going to cum between my legs?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:349
translate chinese SNS_5_3ccf412b:

    # MC "Oooh... That’s good..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:352
translate chinese SNS_5_ea81b834:

    # MC "Mmm... (I’m gonna cum soon.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:353
translate chinese SNS_5_dedaefc0:

    # MC "(Where should I finish though?)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:356
translate chinese SNS_5_534b555e:

    # MC "(Aha! I’ll cum over her feet before I leave.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:359
translate chinese SNS_5_f9f674c1:

    # MC "(Hopefully she’ll take a shower before she notices my cum in the morning!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:361
translate chinese SNS_5_76f606c2:

    # Sara "(Huh? He pulled back?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:363
translate chinese SNS_5_9c31ca3c:

    # MC "Ahh... Yes... Ugh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:373
translate chinese SNS_5_54359774:

    # Sara "(Of course he decided to cum over my feet! I should have known he had a foot fetish.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:374
translate chinese SNS_5_35e76d57:

    # MC "Phew... (That was good.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:378
translate chinese SNS_5_495b8e6d:

    # MC "(Time to go back to my room now. At least I got to cum this time without waking her up!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:380
translate chinese SNS_5_466bcc80:

    # MC "(Time to go back to my room now. At least I got to cum this time! Hehe!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:391
translate chinese SNS_1_8c3f32b0:

    # MC "(Okay, let’s do something risky and try to make Sara give me a blowjob while she sleeps.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:392
translate chinese SNS_1_85ba8597:

    # MC "(I reckon there’s a high chance she’ll wake up - so I’ll have to be ready to run at the slightest twitch.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:394
translate chinese SNS_1_237887c9:

    # MC "(Okay, let’s up the ante a bit. I think Sara will enjoy giving me a blowjob while she pretends to be asleep.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:395
translate chinese SNS_1_2608a4f9:

    # Sara "(I wonder what [player_name] is going to do with me tonight... I’m getting so excited just thinking about it!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:398
translate chinese SNS_1_df1ea6f9:

    # MC "(There’s a good girl... Just open up a little wider for me...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:401
translate chinese SNS_1_5c625c40:

    # Sara "Zzzz...."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:404
translate chinese SNS_1_309a795a:

    # MC "Ooh..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:405
translate chinese SNS_1_51848881:

    # MC "(Her lips are wrapping around my glans!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:408
translate chinese SNS_1_f431ab42:

    # Sara "(Mmm... I’m getting so horny right now at the thought of him just using me like this.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:410
translate chinese SNS_1_a6fca97b:

    # MC "(Damn, this feels good. Time to get another inch or two in.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:413
translate chinese SNS_1_b166885a:

    # MC "Fuck... That’s good..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:414
translate chinese SNS_1_bc8eff8f:

    # MC "(It’s so fucking sexy, seeing my cock bulge out her cheek like that.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:417
translate chinese SNS_1_75525fdb:

    # Sara "(Snoooore)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:419
translate chinese SNS_1_1cb75114:

    # Sara "*Shlurrrp*"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:420
translate chinese SNS_1_22adba9e:

    # MC "Hnngg..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:424
translate chinese SNS_1_5182be05:

    # MC "(I wish I could just facefuck her like this and cum in her mouth while she’s asleep.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:426
translate chinese SNS_1_91b5baac:

    # MC "(I’d love to cum in her mouth right now, but it’s probably not fair if she isn’t expecting it.) "
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:431
translate chinese SNS_1_652dee2d:

    # MC "(There’s NO way she’d sleep through that though.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:432
translate chinese SNS_1_f2813819:

    # MC "(At least this gives me a great mental image to masturbate to!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:434
translate chinese SNS_1_8c3600c7:

    # MC "(At least I’ve got a great mental image to masturbate to when I get back to my room!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:439
translate chinese SNS_1_b4c44002:

    # Sara "Zzzz.... (Cough!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:441
translate chinese SNS_1_9c363fd7:

    # Sara "*Suck*"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:447
translate chinese SNS_1_ccd9e965:

    # MC "Shit... (She’s waking up! I need to get out of here fast!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:448
translate chinese SNS_1_f0cadaf9:

    # MC "(Sara really likes me, but I don’t think that she’d take too kindly to finding me, molesting her while she slept!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:450
translate chinese SNS_1_ae0d4d36:

    # MC "Shit... (I’m getting way too close to cumming!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:451
translate chinese SNS_1_650c0d7e:

    # MC "(I need to stop now before I accidentally cum in her mouth!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:456
translate chinese SNS_1_4b1273aa:

    # Sara "Hmm... Yuck... Why have I been drooling?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:457
translate chinese SNS_1_90b3ef2e:

    # Sara "(I’ve never drooled in my sleep before...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:458
translate chinese SNS_1_79438293:

    # Sara "(There’s a funny taste in my mouth too.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:459
translate chinese SNS_1_b10cfafd:

    # Sara "(Probably something I ate...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:460
translate chinese SNS_1_2178f9d0:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:462
translate chinese SNS_1_24c5f592:

    # Sara "*Yawn*"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:463
translate chinese SNS_1_ef866451:

    # Sara "(Aww... I was enjoying that...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:464
translate chinese SNS_1_43f2fba0:

    # Sara "(I was really hoping [player_name] would stay a while longer...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:465
translate chinese SNS_1_63c56f63:

    # Sara "*Sigh* Oh well... Maybe another night."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:469
translate chinese SNS_1_4dbe0504:

    # MC "(Time to go back to my room now.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:481
translate chinese SNS_3_ac4ac233:

    # MC "(Alright, let’s make Sara wank me off while she sleeps.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:483
translate chinese SNS_3_23fc40a1:

    # MC "(Okay, let’s see if Sara enjoys wanking me off while she pretends to sleep.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:485
translate chinese SNS_3_ed83c979:

    # MC "(C’mon, Sara. Give me your arm.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:486
translate chinese SNS_3_0a33dcee:

    # MC "(There we go...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:491
translate chinese SNS_3_5abf191a:

    # MC "Ahh... (Perfect!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:492
translate chinese SNS_3_a1f3a8d1:

    # MC "(She hasn’t really got a grip on my cock, but at least it still feels nice with her soft fingers touching it.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:493
translate chinese SNS_3_3bf21fba:

    # MC "(Let’s see if I can get away with thrusting my hips a bit.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:495
translate chinese SNS_3_5abf191a_1:

    # MC "Ahh... (Perfect!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:496
translate chinese SNS_3_9c3b2fb2:

    # Sara "(Should I grip more tightly onto his shaft? Or would that just break the immersion for him?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:497
translate chinese SNS_3_a1f3a8d1_1:

    # MC "(She hasn’t really got a grip on my cock, but at least it still feels nice with her soft fingers touching it.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:498
translate chinese SNS_3_a24ddcd0:

    # Sara "(I’ll just leave it. He seems to be enjoying it just like this.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:499
translate chinese SNS_3_76b0575e:

    # MC "(Time to start thrusting my hips.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:503
translate chinese SNS_3_61596a2b:

    # MC "Mmm... Ah..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:509
translate chinese SNS_3_0877835c:

    # Sara "Zzzz..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:511
translate chinese SNS_3_2e4d4c5d:

    # Sara "(It sounds like he’s really enjoying this!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:513
translate chinese SNS_3_d9f56d61:

    # MC "(Maybe I can go a little bit quicker.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:516
translate chinese SNS_3_0059b63b:

    # MC "Ah... Ah..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:520
translate chinese SNS_3_5974a055:

    # MC "(Shit! I’m getting close to cumming... If Linda notices cum stains on the bedsheets she’ll kill me!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:522
translate chinese SNS_3_db6ac926:

    # MC "(Shit! I’m getting close to cumming... Sara will be probably mad If I leave cum stains on the bed sheets!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:525
translate chinese SNS_3_b5650823:

    # Sara "Yaaaaawwn!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:526
translate chinese SNS_3_4d10e937:

    # MC "(Uh oh! Time to bail!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:528
translate chinese SNS_3_11ce9d17:

    # MC "(I’ll finish off in my room where I can clean up afterwards.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:532
translate chinese SNS_3_42c4db72:

    # Sara "Huh? Is someone there?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:533
translate chinese SNS_3_06f0d35c:

    # Sara "Daddy?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:534
translate chinese SNS_3_666a2d5c:

    # Sara "(No... I must have been dreaming.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:535
translate chinese SNS_3_0a6651d7:

    # Sara "Yaaaawn... Zzzzz....."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:538
translate chinese SNS_3_7488ac48:

    # MC "(Time to go back to my room now!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:541
translate chinese SNS_3_fb72c1ac:

    # Sara "(Aww, looks like he left again.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:542
translate chinese SNS_3_eda655dc:

    # Sara "(I was really getting into it as well...)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:543
translate chinese SNS_3_58d6f88c:

    # Sara "Oh well... I better get some sleep for real now. Yaaaawn... Zzzzz....."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:554
translate chinese S_NS_wake_feet_e2618a0d:

    # MC "Can you give me a footjob tonight?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:556
translate chinese S_NS_wake_feet_7b248185:

    # Sara "Hehe! Pervert!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:558
translate chinese S_NS_wake_feet_7e04a06c:

    # MC "Why are you laughing?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:560
translate chinese S_NS_wake_feet_56120e95:

    # Sara "It’s just funny that you’re attracted to feet. Haha! I don’t mind though. How do you want to start?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:562
translate chinese S_NS_wake_feet_9b91bf44:

    # MC "Just lie back and put your feet up. I’ll guide you."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:566
translate chinese S_NS_wake_feet_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:568
translate chinese S_NS_wake_feet_098a2923:

    # Sara "Hehe! Sorry, sorry! It tickles!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:572
translate chinese S_NS_wake_feet_4c1bc51d:

    # MC "*Mwah* *Mwah*"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:574
translate chinese S_NS_wake_feet_7df1f6f3:

    # Sara "Hehehe! Do you HAVE to kiss the toes?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:578
translate chinese S_NS_wake_feet_ce9acc58:

    # Sara "Oh wow... You’re SO hard right now! I guess feet really do turn you on, huh?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:580
translate chinese S_NS_wake_feet_7f0c53e5_1:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:582
translate chinese S_NS_wake_feet_ec358156:

    # MC "Alright, I’m going to stand up. Can you rub my cock between your soles?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:586
translate chinese S_NS_wake_feet_90752f7c:

    # Sara "Sure, bro! Like this?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:588
translate chinese S_NS_wake_feet_469ccfee:

    # MC "Mmm... That’s perfect, sis."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:595
translate chinese S_NS_wake_feet_178f9190:

    # MC "Hnnng... Ohhh..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:597
translate chinese S_NS_wake_feet_e674afe9:

    # Sara "(I can feel his dick throbbing!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:603
translate chinese S_NS_wake_feet_7077a720:

    # Sara "Hehe! You’re loving this, aren't you, bro?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:605
translate chinese S_NS_wake_feet_ae24591d:

    # MC "Mmm! It feels so fucking good!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:609
translate chinese S_NS_wake_feet_c5fdaea0:

    # Sara "Are you going to cum soon?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:611
translate chinese S_NS_wake_feet_b9b3464c:

    # MC "*Pant* Yeah, mmm!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:615
translate chinese S_NS_wake_feet_508e4d5d:

    # Sara "Go on! Do it! Cum all over my feet!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:617
translate chinese S_NS_wake_feet_c53418e6:

    # MC "*Pant* Hnnngg!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:619
translate chinese S_NS_wake_feet_f99ef611:

    # Sara "Cum for me! Cum for me, bro! Blow your load all over my soles!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:629
translate chinese S_NS_wake_feet_fbeb0daf:

    # MC "Hnnnggg! Arrghhh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:631
translate chinese S_NS_wake_feet_1600735e:

    # Sara "Haha! WOW! That was a LOT of cum!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:633
translate chinese S_NS_wake_feet_e84ce8a9:

    # MC "*Pant* Thanks Sara. Your feet are incredible."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:635
translate chinese S_NS_wake_feet_546a29dd:

    # Sara "Hehe, I’m glad you enjoyed it! It was more fun than I thought it was going to be."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:637
translate chinese S_NS_wake_feet_568ccb90:

    # MC "We better get back to bed before Mum or Dad catches us."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:639
translate chinese S_NS_wake_feet_93e9f24a:

    # Sara "Good call. See you tomorrow, bro."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:641
translate chinese S_NS_wake_feet_3d55c5a3:

    # MC "Night, sis!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:644
translate chinese S_NS_wake_feet_e2618a0d_1:

    # MC "Can you give me a footjob tonight?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:646
translate chinese S_NS_wake_feet_7b248185_1:

    # Sara "Hehe! Pervert!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:648
translate chinese S_NS_wake_feet_7e04a06c_1:

    # MC "Why are you laughing?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:650
translate chinese S_NS_wake_feet_56120e95_1:

    # Sara "It’s just funny that you’re attracted to feet. Haha! I don’t mind though. How do you want to start?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:652
translate chinese S_NS_wake_feet_9b539fb1:

    # MC "Just lie back and put your feet up."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:656
translate chinese S_NS_wake_feet_7f0c53e5_2:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:659
translate chinese S_NS_wake_feet_098a2923_1:

    # Sara "Hehe! Sorry, sorry! It tickles!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:663
translate chinese S_NS_wake_feet_4c1bc51d_1:

    # MC "*Mwah* *Mwah*"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:665
translate chinese S_NS_wake_feet_7df1f6f3_1:

    # Sara "Hehehe! Do you HAVE to kiss the toes?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:669
translate chinese S_NS_wake_feet_ce9acc58_1:

    # Sara "Oh wow... You’re SO hard right now! I guess feet really do turn you on, huh?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:671
translate chinese S_NS_wake_feet_7f0c53e5_3:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:673
translate chinese S_NS_wake_feet_ec358156_1:

    # MC "Alright, I’m going to stand up. Can you rub my cock between your soles?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:677
translate chinese S_NS_wake_feet_f14af4b8:

    # Sara "Sure, [player_name]! Like this?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:679
translate chinese S_NS_wake_feet_5516759e:

    # MC "Mmm... That’s perfect, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:686
translate chinese S_NS_wake_feet_178f9190_1:

    # MC "Hnnng... Ohhh..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:688
translate chinese S_NS_wake_feet_e674afe9_1:

    # Sara "(I can feel his dick throbbing!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:695
translate chinese S_NS_wake_feet_dae38696:

    # Sara "Hehe! You’re loving this, aren't you, [player_name]?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:697
translate chinese S_NS_wake_feet_ae24591d_1:

    # MC "Mmm! It feels so fucking good!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:701
translate chinese S_NS_wake_feet_c5fdaea0_1:

    # Sara "Are you going to cum soon?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:703
translate chinese S_NS_wake_feet_b9b3464c_1:

    # MC "*Pant* Yeah, mmm!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:707
translate chinese S_NS_wake_feet_508e4d5d_1:

    # Sara "Go on! Do it! Cum all over my feet!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:709
translate chinese S_NS_wake_feet_c53418e6_1:

    # MC "*Pant* Hnnngg!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:711
translate chinese S_NS_wake_feet_d618c99f:

    # Sara "Cum for me! Cum for me, [player_name]! Blow your load all over my soles!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:722
translate chinese S_NS_wake_feet_fbeb0daf_1:

    # MC "Hnnnggg! Arrghhh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:724
translate chinese S_NS_wake_feet_1600735e_1:

    # Sara "Haha! WOW! That was a LOT of cum!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:726
translate chinese S_NS_wake_feet_e84ce8a9_1:

    # MC "*Pant* Thanks Sara. Your feet are incredible."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:728
translate chinese S_NS_wake_feet_546a29dd_1:

    # Sara "Hehe, I’m glad you enjoyed it! It was more fun than I thought it was going to be."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:730
translate chinese S_NS_wake_feet_78d6d495:

    # MC "Thanks for the fun, Sara. I'll go back to my room."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:732
translate chinese S_NS_wake_feet_c777c081:

    # Sara "Good call. See you tomorrow, [player_name]."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:734
translate chinese S_NS_wake_feet_c27d6dde:

    # MC "Night, Sara!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:748
translate chinese S_NS_wake_anal_532231b3:

    # MC "You’ve gotten pretty good at anal. Do you want to practice again tonight?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:750
translate chinese S_NS_wake_anal_2a22810f:

    # Sara "Uh, sure, why not? Do you have lube?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:752
translate chinese S_NS_wake_anal_ef526456:

    # MC "I’m afraid not. I won’t thrust in deep."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:754
translate chinese S_NS_wake_anal_85226968:

    # Sara "*Gulp* Alright."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:758
translate chinese S_NS_wake_anal_87ccebe9:

    # Sara "Ohh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:760
translate chinese S_NS_wake_anal_38d60328:

    # MC "You okay, sis?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:762
translate chinese S_NS_wake_anal_4087db63:

    # Sara "*Gasp* It’s s-so big! Ow!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:766
translate chinese S_NS_wake_anal_11ae7632:

    # MC "Am I hurting you?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:768
translate chinese S_NS_wake_anal_bd4a0e42:

    # Sara "*Pant* Just... Just a little bit slower."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:770
translate chinese S_NS_wake_anal_69f234df:

    # MC "Oops, sorry, Sara. How’s that now?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:774
translate chinese S_NS_wake_anal_15516168:

    # Sara "*Pant* M-Much better. Just keep going slow. It’s a lot harder to endure it when *Gasp* your dick isn’t lubed up."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:776
translate chinese S_NS_wake_anal_56e323c4:

    # MC "Understood, sis."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:780
translate chinese S_NS_wake_anal_d9b51e4b:

    # Sara "Ah... *Pant* Ah..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:782
translate chinese S_NS_wake_anal_c25941c4:

    # MC "Mmm... Your ass feels really good, Sara. You know that?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:784
translate chinese S_NS_wake_anal_b0b674c3:

    # Sara "*Pant* It does?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:786
translate chinese S_NS_wake_anal_23d11468:

    # MC "Oh yeah, it’s so fucking tight."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:792
translate chinese S_NS_wake_anal_a1300afe:

    # Sara "*Gasp* Ah... Ahmmm..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:794
translate chinese S_NS_wake_anal_5ddd7f61:

    # MC "Hnnnggg..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:801
translate chinese S_NS_wake_anal_343f8690:

    # Sara "*Gasp* B-Bro! It’s- ahh... so intense! *GASP* Oh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:803
translate chinese S_NS_wake_anal_91eb34da:

    # MC "Hnnng! *Pant* I’m about to finish, sis! Just another few seconds! Hnnngggg!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:809
translate chinese S_NS_wake_anal_13d932a5:

    # Sara "Ah... Yesss!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:810
translate chinese S_NS_wake_anal_c18e44be:

    # MC "Arrghhhh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:813
translate chinese S_NS_wake_anal_151329ce:

    # Sara "*GASP* Aahhhh! OooooOOOoooooohhhh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:814
translate chinese S_NS_wake_anal_37e783ab:

    # MC "Hnnng! F-Fuck! I’m gonna cum."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:823
translate chinese S_NS_wake_anal_ad43d115:

    # MC "*Pant* That was amazing, sis. Thank you."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:825
translate chinese S_NS_wake_anal_a1f2e016:

    # Sara "Really? You actually enjoyed it? You’re not just lying to make me happy?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:827
translate chinese S_NS_wake_anal_42825363:

    # MC "I really did. You’re getting so much better at taking my dick up your butt."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:829
translate chinese S_NS_wake_anal_b98384a1:

    # Sara "Yay! I’m so happy to hear that!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:831
translate chinese S_NS_wake_anal_c75ebd35:

    # MC "We better get some sleep, sis."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:833
translate chinese S_NS_wake_anal_0482cc4a:

    # Sara "Yeah, you’re right. I’ll see you tomorrow, bro."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:835
translate chinese S_NS_wake_anal_6652fdf4:

    # MC "Goodnight, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:840
translate chinese S_NS_wake_anal_532231b3_1:

    # MC "You’ve gotten pretty good at anal. Do you want to practice again tonight?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:842
translate chinese S_NS_wake_anal_2a22810f_1:

    # Sara "Uh, sure, why not? Do you have lube?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:844
translate chinese S_NS_wake_anal_ef526456_1:

    # MC "I’m afraid not. I won’t thrust in deep."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:846
translate chinese S_NS_wake_anal_85226968_1:

    # Sara "*Gulp* Alright."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:850
translate chinese S_NS_wake_anal_87ccebe9_1:

    # Sara "Ohh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:852
translate chinese S_NS_wake_anal_704746ea:

    # MC "You okay, Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:854
translate chinese S_NS_wake_anal_4087db63_1:

    # Sara "*Gasp* It’s s-so big! Ow!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:858
translate chinese S_NS_wake_anal_be46928b:

    # MC "Do you want to want to me stop or go faster?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:860
translate chinese S_NS_wake_anal_bd4a0e42_1:

    # Sara "*Pant* Just... Just a little bit slower."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:862
translate chinese S_NS_wake_anal_69f234df_1:

    # MC "Oops, sorry, Sara. How’s that now?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:866
translate chinese S_NS_wake_anal_15516168_1:

    # Sara "*Pant* M-Much better. Just keep going slow. It’s a lot harder to endure it when *Gasp* your dick isn’t lubed up."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:868
translate chinese S_NS_wake_anal_45d3b35e:

    # MC "Understood."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:872
translate chinese S_NS_wake_anal_d9b51e4b_1:

    # Sara "Ah... *Pant* Ah..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:874
translate chinese S_NS_wake_anal_c25941c4_1:

    # MC "Mmm... Your ass feels really good, Sara. You know that?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:876
translate chinese S_NS_wake_anal_b0b674c3_1:

    # Sara "*Pant* It does?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:878
translate chinese S_NS_wake_anal_23d11468_1:

    # MC "Oh yeah, it’s so fucking tight."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:885
translate chinese S_NS_wake_anal_a1300afe_1:

    # Sara "*Gasp* Ah... Ahmmm..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:887
translate chinese S_NS_wake_anal_5ddd7f61_1:

    # MC "Hnnnggg..."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:894
translate chinese S_NS_wake_anal_1355d5ca:

    # Sara "*Gasp* [player_name]! It’s- ahh... so intense! *GASP* Oh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:896
translate chinese S_NS_wake_anal_068b9fc8:

    # MC "Hnnng! *Pant* I’m about to finish, Sara! Just another few seconds! Hnnngggg!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:902
translate chinese S_NS_wake_anal_13d932a5_1:

    # Sara "Ah... Yesss!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:903
translate chinese S_NS_wake_anal_c18e44be_1:

    # MC "Arrghhhh!"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:907
translate chinese S_NS_wake_anal_151329ce_1:

    # Sara "*GASP* Aahhhh! OooooOOOoooooohhhh!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:908
translate chinese S_NS_wake_anal_37e783ab_1:

    # MC "Hnnng! F-Fuck! I’m gonna cum."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:917
translate chinese S_NS_wake_anal_317de79a:

    # MC "*Pant* That was amazing, Sara. Thank you."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:919
translate chinese S_NS_wake_anal_a1f2e016_1:

    # Sara "Really? You actually enjoyed it? You’re not just lying to make me happy?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:921
translate chinese S_NS_wake_anal_42825363_1:

    # MC "I really did. You’re getting so much better at taking my dick up your butt."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:923
translate chinese S_NS_wake_anal_b98384a1_1:

    # Sara "Yay! I’m so happy to hear that!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:925
translate chinese S_NS_wake_anal_624135ac:

    # MC "We better get some sleep, Sara."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:927
translate chinese S_NS_wake_anal_728a650c:

    # Sara "Yeah, you’re right. I’ll see you tomorrow, [player_name]."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_sleeping2.rpy:929
translate chinese S_NS_wake_anal_6652fdf4_1:

    # MC "Goodnight, Sara."
    MC ""

