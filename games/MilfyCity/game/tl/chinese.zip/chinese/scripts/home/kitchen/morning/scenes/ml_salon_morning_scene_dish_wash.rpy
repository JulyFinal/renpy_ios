﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:17
translate chinese ml_salon_morning_scene_dish_wash_label_c81791ba:

    # MC "(There we go... That’s most of them.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:18
translate chinese ml_salon_morning_scene_dish_wash_label_16925b63:

    # MC "(They must have been left-over from last night’s dinner.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:22
translate chinese ml_salon_morning_scene_dish_wash_label_49197b8d:

    # MC "(I wonder why Mom didn’t just stick them in the dishwasher.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:24
translate chinese ml_salon_morning_scene_dish_wash_label_a42f64c0:

    # MC "(I wonder why Linda didn’t just stick them in the dishwasher.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:25
translate chinese ml_salon_morning_scene_dish_wash_label_88bb6bdc:

    # MC "(Anyway, this is the last one.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:26
translate chinese ml_salon_morning_scene_dish_wash_label_ff43b1d3:

    # MC "(It’s a good thing too - any more and I would have been late for college!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:29
translate chinese ml_salon_morning_scene_dish_wash_label_38f607ca:

    # Mom "Thank you so much for doing those for me!"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:30
translate chinese ml_salon_morning_scene_dish_wash_label_bd87c7fb:

    # Mom "You have no idea how grateful I am to have you helping me around the house."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:32
translate chinese ml_salon_morning_scene_dish_wash_label_39f1430b:

    # MC "Yeah, it’s no problem. Happy to help, Mom."
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:34
translate chinese ml_salon_morning_scene_dish_wash_label_41a6b03f:

    # MC "Yeah, it’s no problem. Happy to help, Linda."
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:38
translate chinese ml_salon_morning_scene_dish_wash_label_6bc9202c:

    # Mom "Your father is terrible when it comes to chores."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:40
translate chinese ml_salon_morning_scene_dish_wash_label_da12c358:

    # Mom "Bob is terrible when it comes to chores."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:41
translate chinese ml_salon_morning_scene_dish_wash_label_cd5f832f:

    # Mom "Never puts his clothes in the wash. Never scrapes his plate clean after meals."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:42
translate chinese ml_salon_morning_scene_dish_wash_label_211d56c6:

    # Mom "You’re a real man."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:45
translate chinese ml_salon_morning_scene_dish_wash_label_04fb0ea7:

    # MC "(A real man?!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:47
translate chinese ml_salon_morning_scene_dish_wash_label_7442d974:

    # MC "(Mom’s acting very... intimate again.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:49
translate chinese ml_salon_morning_scene_dish_wash_label_4591241c:

    # MC "(Linda’s acting very... intimate again.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:50
translate chinese ml_salon_morning_scene_dish_wash_label_5a816be3:

    # MC "(Maybe it’s got something to do with her hormones or something?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:51
translate chinese ml_salon_morning_scene_dish_wash_label_3e20636c:

    # MC "(Girls are weird...)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:54
translate chinese ml_salon_morning_scene_dish_wash_label_72ff2ce9:

    # Mom "(Sniff...)"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:55
translate chinese ml_salon_morning_scene_dish_wash_label_2fb301e7:

    # Mom "(Mmm... God... he smells so good.)"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:56
translate chinese ml_salon_morning_scene_dish_wash_label_6a05b243:

    # Mom "(I’d love to just, lie naked beside him and cuddle him all night-)"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:57
translate chinese ml_salon_morning_scene_dish_wash_label_7f53a311:

    # Mom "(Shit! I’m getting far too involved in these fantasies again.)"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:61
translate chinese ml_salon_morning_scene_dish_wash_label_e2570671:

    # Mom "You better go to college! Hurry up! Get a move on!"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:62
translate chinese ml_salon_morning_scene_dish_wash_label_3f8ee3a1:

    # MC "Yeah, I’ll just dry the plates-"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:63
translate chinese ml_salon_morning_scene_dish_wash_label_c86e7379:

    # Mom "No time! Chop chop!"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_salon_morning_scene_dish_wash.rpy:64
translate chinese ml_salon_morning_scene_dish_wash_label_e956b2c2:

    # MC "Okay, I’m going! (Geez, what got into her?)"
    MC ""

