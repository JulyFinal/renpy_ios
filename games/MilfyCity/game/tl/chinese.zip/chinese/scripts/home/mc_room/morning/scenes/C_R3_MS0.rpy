﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:29
translate chinese CR3_MS0_label_c2da6100:

    # MC "Morning, Caroline! Are you okay? Should you not be heading to work already?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:30
translate chinese CR3_MS0_label_eca776c3:

    # Caroline "Morning. I... *sigh*"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:31
translate chinese CR3_MS0_label_a3cda866:

    # MC "Huh? Is something wrong? You look really worried, right now."
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:35
translate chinese CR3_MS0_label_a2a3886c:

    # Caroline "Yeah, something’s wrong. Listen - I made a huge mistake."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:36
translate chinese CR3_MS0_label_2e415ef0:

    # MC "I can help! Do you need more money for your business or-"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:37
translate chinese CR3_MS0_label_99f66d4a:

    # Caroline "It’s not a mistake that money can fix. I’ve REALLY fucked things up. You see... Pandora’s box has been opened, and I don’t think I can - ever fully close it again."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:38
translate chinese CR3_MS0_label_8bf0bc86:

    # MC "I’m not following you - What’s going on?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:39
translate chinese CR3_MS0_label_90e80031:

    # Caroline "This... deal that you and I made? It’s... over."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:41
translate chinese CR3_MS0_label_8735d640:

    # Caroline "I’ll hold my hands up and acknowledge, tha I played my part in causing this chaos, so I have a responsibility, to try and stop it. You’re my brother, for Christ’s sake! I shouldn’t have led you on, like I did."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:43
translate chinese CR3_MS0_label_70f4932d:

    # Caroline "I’ll hold my hands up and acknowledge that I played my part in causing this chaos, so I have a responsibility to try and stop it. You’re my best friend for Christ’s sake! I shouldn’t have led you on like I did."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:52
translate chinese CR3_MS0_label_2d374782:

    # MC "Wh-What? Why? This doesn’t make any sense!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:54
translate chinese CR3_MS0_label_2c6e2b1d:

    # Caroline "It does. The only thing that DIDN’T make sense, was the fact that a sister was fooling around with her brother! I thought I could do this without any- Ugh, nevermind."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:56
translate chinese CR3_MS0_label_3e061117:

    # Caroline "It does. The only thing that DIDN’T make sense was the fact that I was messing around with my best friend! I thought I could do this without any- Ugh, nevermind."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:57
translate chinese CR3_MS0_label_1c47195d:

    # MC "Please! Can’t we talk about this? I thought we might evolve into - something more than just a deal!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:64
translate chinese CR3_MS0_label_d5f5a310:

    # MC "Y-You can’t do this, Caroline! We had a deal!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:65
translate chinese CR3_MS0_label_fbf5aece:

    # Caroline "Not anymore, [player_name]."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:66
translate chinese CR3_MS0_label_2a435a58:

    # MC "I thought we could be - more than just a deal! You can’t just tear that away from me!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:73
translate chinese CR3_MS0_continue_617f7054:

    # Caroline "*Sigh* We were never going to be - more than - just two people, fooling around."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:74
translate chinese CR3_MS0_continue_509eaa5f:

    # Caroline "I don’t need you to take pictures for me, anymore. I’ll be employing a part-time member of staff - as of tomorrow."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:75
translate chinese CR3_MS0_continue_5199f594:

    # MC "W-Wait..! Please, don’t do this!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:76
translate chinese CR3_MS0_continue_d41df34a:

    # MC "(Fuck! I’m feeling sick...)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:80
translate chinese CR3_MS0_continue_53d655fb:

    # Caroline "Please don’t make this any harder than it has to be, [player_name]."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:81
translate chinese CR3_MS0_continue_219c6412:

    # Caroline "We both had some fun, while it lasted, but there was no way we could have - realistically - made this a long-term thing. You must have known that?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:82
translate chinese CR3_MS0_continue_d322ba8e:

    # MC "(This can’t be happening...)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:86
translate chinese CR3_MS0_continue_21e2a7fa:

    # MC "Please! I’ll do anything! We can slow things down!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:87
translate chinese CR3_MS0_continue_176362c4:

    # Caroline "There was nothing to slow down, [player_name]. We were never dating."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:88
translate chinese CR3_MS0_continue_50155f8e:

    # Caroline "I accept - full responsibility - for this. I really AM sorry - I never meant to hurt you, I was selfish and greedy. I should have just hired another member of staff, to help me run my business."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:92
translate chinese CR3_MS0_continue_6938b8df:

    # MC "Caroline! Wait! Please!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:93
translate chinese CR3_MS0_continue_2e4d4866:

    # Caroline "Goodbye, [player_name]..."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:94
translate chinese CR3_MS0_continue_a4a8e7a7:

    # MC "(Oh fuck... Does this mean that I’ll never, be able to be with her again? It can’t, seriously be over, can it?!)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:95
translate chinese CR3_MS0_continue_0ddb3b99:

    # MC "(If I’d known that it was all going to end I would have cherished - every last second - with her. Now I’ve lost her forever...)"
    MC ""

translate chinese strings:

    # game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:48
    old "Wh-What? Why? This doesn’t make any sense!"
    new ""

    # game/scripts/home/mc_room/morning/scenes/C_R3_MS0.rpy:48
    old "Y-You can’t do this! We had a deal!"
    new ""

