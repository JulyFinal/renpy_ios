﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:130
translate chinese CR4_NS3_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:131
translate chinese CR4_NS3_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:134
translate chinese CR4_NS3_1f46dde7:

    # Caroline "Well, how do you want to fuck? Doggy style or cowgirl?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:135
translate chinese CR4_NS3_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:144
translate chinese CR4_NS3_0db2c94b:

    # MC "(Caroline said to come over at night... but I can’t see her anywhere.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:145
translate chinese CR4_NS3_b0d02782:

    # MC "(Maybe she skipped out to the bathroom?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:146
translate chinese CR4_NS3_bad969e2:

    # MC "(I guess I should just wait here for her.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:149
translate chinese CR4_NS3_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:150
translate chinese CR4_NS3_1989d79d:

    # MC "Hey, Caroline? Are you in here?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:153
translate chinese CR4_NS3_cf61a31c:

    # MC "(That’s weird. Her bed is still made up. She wouldn’t have tidied it up if she was just going to the bathroom.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:154
translate chinese CR4_NS3_88d81e24:

    # MC "(Maybe she got held up at work?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:160
translate chinese CR4_NS3_492b35ab:

    # Caroline "Boo!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:161
translate chinese CR4_NS3_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:162
translate chinese CR4_NS3_0d61074e:

    # Caroline "Hehe, sorry for scaring you. I couldn’t resist."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:165
translate chinese CR4_NS3_5fe7b15a:

    # MC "Jesus, you nearly gave me a heart attack!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:166
translate chinese CR4_NS3_2b17f18c:

    # Caroline "Haha, don’t be so melodramatic."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:169
translate chinese CR4_NS3_4f2adfae:

    # Caroline "I’ve been really excited to see you tonight. I’ve not been able to think about anything else all day."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:170
translate chinese CR4_NS3_50196686:

    # MC "Mmm, really?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:171
translate chinese CR4_NS3_82200d72:

    # Caroline "Oh yeah."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:174
translate chinese CR4_NS3_e642e5b4:

    # Caroline "I’ve been busy thinking about all the dirty things I’m going to do with you."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:175
translate chinese CR4_NS3_65475339:

    # Caroline "And it’s left me hot and wet, all damn day."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:176
translate chinese CR4_NS3_37a4dddc:

    # MC "Well, that certainly sounds like something I can help out with."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:179
translate chinese CR4_NS3_9e7c1527:

    # Caroline "Mmm, hard already."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:180
translate chinese CR4_NS3_63e05589:

    # MC "What have you got planned for tonight, then?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:181
translate chinese CR4_NS3_8ec95531:

    # Caroline "Well, I was thinking..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:184
translate chinese CR4_NS3_632621e5:

    # Caroline "...perhaps we could begin with me getting down on my hands and my knees."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:185
translate chinese CR4_NS3_0d1ca2ab:

    # MC "Okay, I’m liking where this is going so far!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:186
translate chinese CR4_NS3_68d69c25:

    # Caroline "And then I’ll spread my asscheeks for you."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:189
translate chinese CR4_NS3_6616b473:

    # Caroline "Then you are going to have to make a decision."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:190
translate chinese CR4_NS3_44a3a4b7:

    # MC "I am?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:191
translate chinese CR4_NS3_2d65728d:

    # Caroline "Will you fuck me in the pussy? Or in the ass?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:194
translate chinese CR4_NS3_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:195
translate chinese CR4_NS3_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:196
translate chinese CR4_NS3_b6e665ab:

    # Caroline "*Whispered* Take your time and think about it."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:199
translate chinese CR4_NS3_c1170cce_1:

    # MC "Ah..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:201
translate chinese CR4_NS3_7d191740_2:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:204
translate chinese CR4_NS3_1f46dde7_1:

    # Caroline "Well, how do you want to fuck? Doggy style or cowgirl?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:205
translate chinese CR4_NS3_a6c50e0e_1:

    # MC "Hmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:217
translate chinese CR4_NS3_menu_f4ba85cf:

    # MC "Let’s try doggy style tonight."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:218
translate chinese CR4_NS3_menu_c80575a5:

    # Caroline "Okay, let me get up on the bed."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:221
translate chinese CR4_NS3_menu_215a7ac4:

    # Caroline "How’s that? Is my ass high enough?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:222
translate chinese CR4_NS3_menu_cff20e98:

    # MC "Perfect height. I’ll be able to fuck you, no problem."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:225
translate chinese CR4_NS3_menu_ebdadda1:

    # Caroline "So, which hole do you want to fuck tonight? My pussy? Or my ass?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:226
translate chinese CR4_NS3_menu_0d8931f6:

    # MC "Will we need lube for your ass?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:227
translate chinese CR4_NS3_menu_524fdbfa:

    # Caroline "I’m way ahead of you there - I’ve already applied some. So you should be able to slip your cock right in."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:230
translate chinese CR4_NS3_menu_9f9a5550:

    # MC "It’s a tough decision... but I think I’m gonna fuck your..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:235
translate chinese CR4_NS3_menu_db64895a:

    # MC "...pussy tonight."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:236
translate chinese CR4_NS3_menu_0cd9a67c:

    # Caroline "Mmm, I like the sound of that."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:239
translate chinese CR4_NS3_menu_0acd861d:

    # Caroline "Ahh... Fuck... Put it in, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:240
translate chinese CR4_NS3_menu_4cb54052:

    # MC "Mmm, I am... Ahh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:243
translate chinese CR4_NS3_menu_357446ea:

    # Caroline "Oh God... Mmm! You’re so thick!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:244
translate chinese CR4_NS3_menu_dcb94e5a:

    # MC "Ah... I’m gonna fuck you so hard now."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:247
translate chinese CR4_NS3_menu_efe990dd:

    # Caroline "Mmm! Yes, please! Fuck me hard, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:248
translate chinese CR4_NS3_menu_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:249
translate chinese CR4_NS3_menu_8b3d3c7c:

    # Caroline "Oh! Ahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:252
translate chinese CR4_NS3_menu_916b78c3:

    # Caroline "Ahh! Yes! YES! Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:253
translate chinese CR4_NS3_menu_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:254
translate chinese CR4_NS3_menu_26c4aed2:

    # Caroline "Harder! Harder!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:257
translate chinese CR4_NS3_menu_2341697f:

    # MC "How’s that, Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:258
translate chinese CR4_NS3_menu_bb9e6e25:

    # Caroline "Mmm! Yes! It’s so good, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:260
translate chinese CR4_NS3_menu_8260bd1f:

    # MC "Ahh... Hnng!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:263
translate chinese CR4_NS3_menu_afb590ba:

    # Caroline "Ah! Harder!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:264
translate chinese CR4_NS3_menu_a504ab55:

    # MC "I can’t go any harder!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:265
translate chinese CR4_NS3_menu_5117ca27:

    # Caroline "Then just ahh... spank me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:268
translate chinese CR4_NS3_menu_f82c4b5b:

    # MC "Ugh! A-Are you sure?!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:269
translate chinese CR4_NS3_menu_006b864a:

    # Caroline "YES! Spank me hard, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:272
translate chinese CR4_NS3_menu_cf2e2c2d:

    # MC "(I hope she’s sure about what she’s asking me to do right now!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:273
translate chinese CR4_NS3_menu_baf18882:

    # Caroline "Ahh ahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:274
translate chinese CR4_NS3_menu_d5d521f6:

    # MC "*Gulp* (Here goes nothing!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:278
translate chinese CR4_NS3_menu_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:279
translate chinese CR4_NS3_menu_9a1d6a7e:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:280
translate chinese CR4_NS3_menu_3225a933:

    # MC "Sorr-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:281
translate chinese CR4_NS3_menu_439aba68:

    # Caroline "AGAIN! More!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:284
translate chinese CR4_NS3_menu_4875f5be_1:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:287
translate chinese CR4_NS3_menu_078482b1:

    # Caroline "MMMM! Yesss.... Spank me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:288
translate chinese CR4_NS3_menu_c601269a:

    # Caroline "I’m been such a bad girl, spank me harder!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:289
translate chinese CR4_NS3_menu_9e0f3e29:

    # MC "(Huh, I never guessed Caroline would have been into this kind of thing!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:293
translate chinese CR4_NS3_menu_4875f5be_2:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:294
translate chinese CR4_NS3_menu_1aa93675:

    # Caroline "Eek!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:297
translate chinese CR4_NS3_menu_4875f5be_3:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:298
translate chinese CR4_NS3_menu_5a30efe2:

    # Caroline "Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:301
translate chinese CR4_NS3_menu_4875f5be_4:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:303
translate chinese CR4_NS3_menu_53701a34:

    # Caroline "Ahhhh! Fuck! Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:306
translate chinese CR4_NS3_menu_7ed4fb4e:

    # Caroline "Don’t *gasp* stop fucking *gasp* me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:309
translate chinese CR4_NS3_menu_4875f5be_5:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:310
translate chinese CR4_NS3_menu_ca43676c:

    # Caroline "AHHH! I’m cumming! AYAAAHH!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:314
translate chinese CR4_NS3_menu_4875f5be_6:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:315
translate chinese CR4_NS3_menu_299bbbdf:

    # Caroline "AHHH! YES! I’m cummmmmmiiinnng!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:316
translate chinese CR4_NS3_menu_2d9840d5_1:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:319
translate chinese CR4_NS3_menu_2313ccf5:

    # Caroline "P-Pull my hair too!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:320
translate chinese CR4_NS3_menu_3f1e201e:

    # MC "Are you-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:321
translate chinese CR4_NS3_menu_5dc9ba3e:

    # Caroline "Please! Just do it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:324
translate chinese CR4_NS3_menu_2422b2e2:

    # Caroline "AHHH! OHHH FUCK! YES!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:325
translate chinese CR4_NS3_menu_3dcb7635:

    # MC "(Holy shit, I never knew she was into rough sex like this!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:327
translate chinese CR4_NS3_menu_814af415:

    # Caroline "Ah! AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:330
translate chinese CR4_NS3_menu_686d4459:

    # MC "Hnnnggg! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:331
translate chinese CR4_NS3_menu_2bf6842c:

    # MC "Take my cock, you stupid slut!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:332
translate chinese CR4_NS3_menu_f2b8c2c4:

    # Caroline "Oh fuck! Yes! Talk dirty to me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:335
translate chinese CR4_NS3_menu_1d63bea3:

    # MC "UGH!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:336
translate chinese CR4_NS3_menu_9a1d6a7e_1:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:338
translate chinese CR4_NS3_menu_9ca36bd4:

    # MC "I’m going to destroy your pussy right now!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:341
translate chinese CR4_NS3_menu_19feb73f:

    # Caroline "Ohhh! Oh, my God! *GASP* Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:343
translate chinese CR4_NS3_menu_a8cfe4a7:

    # Caroline "Destroy my slutty little pussy! YES! Ahhhhhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:344
translate chinese CR4_NS3_menu_6f91780c:

    # Caroline "I’m cummmmmiiing! I’m cumming again! AHHH"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:347
translate chinese CR4_NS3_menu_c6d907b8:

    # MC "Hnnnggg... I’m cumming too! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:348
translate chinese CR4_NS3_menu_9a3f195b:

    # Caroline "Yes! Cum inside me, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:351
translate chinese CR4_NS3_menu_5cbd1a10:

    # Caroline "AHHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:353
translate chinese CR4_NS3_menu_2b40314c:

    # MC "Faster! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:355
translate chinese CR4_NS3_menu_9a1d6a7e_2:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:359
translate chinese CR4_NS3_menu_936e314d:

    # MC "I’m cumming inside you, Caroline!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:360
translate chinese CR4_NS3_menu_7d521558:

    # MC "I’m gonna fill you up!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:361
translate chinese CR4_NS3_menu_eac920c9:

    # Caroline "AAAYAAAHHHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:364
translate chinese CR4_NS3_menu_c8e7efd3:

    # MC "Hnnnnnnggg! Ugh! Ahhh! Ohhh fuck! Mmm!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:376
translate chinese CR4_NS3_menu_13477376:

    # Caroline "*Pant* Oh W-wow... That was... fucking amazing. *Gasp*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:378
translate chinese CR4_NS3_menu_b32b827c:

    # MC "Sorry, Caroline. I hope I didn’t go too hard, there with the slapping and hair pulling."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:380
translate chinese CR4_NS3_menu_474f8af3:

    # Caroline "N-No... it was *pant* perfect... You’re the best brother, I could ever ask for..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:382
translate chinese CR4_NS3_menu_0c71be68:

    # Caroline "N-No... it was *pant* perfect... You’re the best boyfriend, I could ever ask for..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:393
translate chinese CR4_NS3_menu_c43827f1:

    # MC "Hnnngg... I’m gonna cum!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:394
translate chinese CR4_NS3_menu_9acc449d:

    # MC "(I better play it safe, and pull out. No sense in cumming inside her without a condom on!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:395
translate chinese CR4_NS3_menu_44d86a11:

    # Caroline "Ah ahhh! Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:398
translate chinese CR4_NS3_menu_e343e5af:

    # MC "Hnnnggg! Ugh! Ahh"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:408
translate chinese CR4_NS3_menu_e6ca5d23:

    # Caroline "Ohh... *Pant* *Pant*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:410
translate chinese CR4_NS3_menu_28212750:

    # MC "Fuck... That was incredible."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:411
translate chinese CR4_NS3_menu_d2a8a825:

    # Caroline "Y-Yeah, that was *pant* fucking amazing... You were great!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:421
translate chinese CR4_NS3_menu_579aa9bf:

    # MC "...tight little asshole tonight."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:422
translate chinese CR4_NS3_menu_b2e394c3:

    # Caroline "A-Are you sure?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:425
translate chinese CR4_NS3_menu_743afdcc:

    # MC "It’ll be fine. I’ll go slow at first."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:426
translate chinese CR4_NS3_menu_dce15a12:

    # Caroline "*Gulp* O-Okay..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:427
translate chinese CR4_NS3_menu_d0eb59b9:

    # MC "Mmm... Oh fuck...."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:430
translate chinese CR4_NS3_menu_f4ca41e8:

    # Caroline "Holy shit! Ahh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:431
translate chinese CR4_NS3_menu_16c70088:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:432
translate chinese CR4_NS3_menu_4fda47a1:

    # Caroline "N-No, you’re just really ohh... thick!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:435
translate chinese CR4_NS3_menu_93e81e75:

    # MC "Damn, your asshole is really fucking tight, Caroline!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:436
translate chinese CR4_NS3_menu_03a171e7:

    # Caroline "Ahh... I’ll take that as a compliment, I guess! Haha!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:437
translate chinese CR4_NS3_menu_890d50aa:

    # MC "Ugh! Ohh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:438
translate chinese CR4_NS3_menu_8b3d3c7c_1:

    # Caroline "Oh! Ahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:441
translate chinese CR4_NS3_menu_fa176c3c:

    # Caroline "Ahh! Yes! Mmm! Fuck me..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:442
translate chinese CR4_NS3_menu_06f44a62:

    # MC "(It sounds like she’s enjoying anal more now! I just had to get her over the initial shock!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:443
translate chinese CR4_NS3_menu_2d9840d5_2:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:444
translate chinese CR4_NS3_menu_26c4aed2_1:

    # Caroline "Harder! Harder!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:447
translate chinese CR4_NS3_menu_2341697f_1:

    # MC "How’s that, Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:449
translate chinese CR4_NS3_menu_783ddcd8:

    # Caroline "Mmm! Yes! Don’t stop!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:450
translate chinese CR4_NS3_menu_d5478f05:

    # Caroline "Oh fuck! It’s so good, [player_name]! Keep pounding my ass with your massive cock!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:451
translate chinese CR4_NS3_menu_8260bd1f_1:

    # MC "Ahh... Hnng!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:454
translate chinese CR4_NS3_menu_724937b8:

    # Caroline "Faster, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:455
translate chinese CR4_NS3_menu_4d210704:

    # MC "I can’t go any faster!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:456
translate chinese CR4_NS3_menu_038eab02:

    # Caroline "Then just ahh... spank me while you fuck my ass!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:459
translate chinese CR4_NS3_menu_f82c4b5b_1:

    # MC "Ugh! A-Are you sure?!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:460
translate chinese CR4_NS3_menu_006b864a_1:

    # Caroline "YES! Spank me hard, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:461
translate chinese CR4_NS3_menu_e5644f3a:

    # Caroline "Spank me so hard, you feel the vibrations while you’re fucking my butt!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:464
translate chinese CR4_NS3_menu_cf2e2c2d_1:

    # MC "(I hope she’s sure about what she’s asking me to do right now!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:465
translate chinese CR4_NS3_menu_baf18882_1:

    # Caroline "Ahh ahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:466
translate chinese CR4_NS3_menu_d5d521f6_1:

    # MC "*Gulp* (Here goes nothing!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:471
translate chinese CR4_NS3_menu_4875f5be_7:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:472
translate chinese CR4_NS3_menu_9a1d6a7e_3:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:473
translate chinese CR4_NS3_menu_3225a933_1:

    # MC "Sorr-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:474
translate chinese CR4_NS3_menu_72509c8a:

    # Caroline "AGAIN! More! HARDER!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:477
translate chinese CR4_NS3_menu_4875f5be_8:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:480
translate chinese CR4_NS3_menu_078482b1_1:

    # Caroline "MMMM! Yesss.... Spank me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:481
translate chinese CR4_NS3_menu_f9550138:

    # Caroline "I’m a naughty little slut! Punish me! Spank me harder!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:482
translate chinese CR4_NS3_menu_9e0f3e29_1:

    # MC "(Huh, I never guessed Caroline would have been into this kind of thing!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:486
translate chinese CR4_NS3_menu_4875f5be_9:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:487
translate chinese CR4_NS3_menu_1aa93675_1:

    # Caroline "Eek!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:490
translate chinese CR4_NS3_menu_4875f5be_10:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:491
translate chinese CR4_NS3_menu_5a30efe2_1:

    # Caroline "Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:494
translate chinese CR4_NS3_menu_4875f5be_11:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:496
translate chinese CR4_NS3_menu_53701a34_1:

    # Caroline "Ahhhh! Fuck! Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:499
translate chinese CR4_NS3_menu_6c4e0b2a:

    # Caroline "Don’t *gasp* stop fucking *gasp* my *GASP* ass!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:502
translate chinese CR4_NS3_menu_4875f5be_12:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:503
translate chinese CR4_NS3_menu_ca43676c_1:

    # Caroline "AHHH! I’m cumming! AYAAAHH!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:507
translate chinese CR4_NS3_menu_4875f5be_13:

    # "*SLAP*"
    ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:508
translate chinese CR4_NS3_menu_299bbbdf_1:

    # Caroline "AHHH! YES! I’m cummmmmmiiinnng!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:509
translate chinese CR4_NS3_menu_2d9840d5_3:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:512
translate chinese CR4_NS3_menu_2313ccf5_1:

    # Caroline "P-Pull my hair too!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:513
translate chinese CR4_NS3_menu_3f1e201e_1:

    # MC "Are you-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:514
translate chinese CR4_NS3_menu_5dc9ba3e_1:

    # Caroline "Please! Just do it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:517
translate chinese CR4_NS3_menu_2422b2e2_1:

    # Caroline "AHHH! OHHH FUCK! YES!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:518
translate chinese CR4_NS3_menu_3dcb7635_1:

    # MC "(Holy shit, I never knew she was into rough sex like this!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:520
translate chinese CR4_NS3_menu_814af415_1:

    # Caroline "Ah! AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:523
translate chinese CR4_NS3_menu_686d4459_1:

    # MC "Hnnnggg! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:524
translate chinese CR4_NS3_menu_2bf6842c_1:

    # MC "Take my cock, you stupid slut!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:525
translate chinese CR4_NS3_menu_f2b8c2c4_1:

    # Caroline "Oh fuck! Yes! Talk dirty to me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:528
translate chinese CR4_NS3_menu_1d63bea3_1:

    # MC "UGH!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:529
translate chinese CR4_NS3_menu_9a1d6a7e_4:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:531
translate chinese CR4_NS3_menu_2759f0b8:

    # MC "I’m going to destroy this tight asshole of yours. I’m gonna fuck you so hard and pump all my cum, deep inside you!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:534
translate chinese CR4_NS3_menu_19feb73f_1:

    # Caroline "Ohhh! Oh, my God! *GASP* Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:536
translate chinese CR4_NS3_menu_80012427:

    # Caroline "Fuck my ass! Fuck my silly! YES! Ahhhhhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:537
translate chinese CR4_NS3_menu_68140395:

    # Caroline "I’m cummmmmiiing! I’m cumming again! AHHH "
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:540
translate chinese CR4_NS3_menu_c6d907b8_1:

    # MC "Hnnnggg... I’m cumming too! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:541
translate chinese CR4_NS3_menu_19509a20:

    # Caroline "Yes! Cum inside me, [player_name]! Fill my ass!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:544
translate chinese CR4_NS3_menu_5cbd1a10_1:

    # Caroline "AHHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:546
translate chinese CR4_NS3_menu_2b40314c_1:

    # MC "Faster! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:548
translate chinese CR4_NS3_menu_9a1d6a7e_5:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:553
translate chinese CR4_NS3_menu_936e314d_1:

    # MC "I’m cumming inside you, Caroline!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:554
translate chinese CR4_NS3_menu_7d521558_1:

    # MC "I’m gonna fill you up!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:557
translate chinese CR4_NS3_menu_eac920c9_1:

    # Caroline "AAAYAAAHHHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:558
translate chinese CR4_NS3_menu_3cf5d2cd:

    # Caroline "FUCKING FILL ME UP! OHHH! YESSS!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:561
translate chinese CR4_NS3_menu_c8e7efd3_1:

    # MC "Hnnnnnnggg! Ugh! Ahhh! Ohhh fuck! Mmm!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:571
translate chinese CR4_NS3_menu_13477376_1:

    # Caroline "*Pant* Oh W-wow... That was... fucking amazing. *Gasp*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:574
translate chinese CR4_NS3_menu_30da628e:

    # MC "How’s your ass, after all that?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:575
translate chinese CR4_NS3_menu_020a3934:

    # Caroline "*Pant* A little bit sensitive... but it was *Pant* really fucking intense... I loved it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:586
translate chinese CR4_NS3_menu_c43827f1_1:

    # MC "Hnnngg... I’m gonna cum!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:587
translate chinese CR4_NS3_menu_44d86a11_1:

    # Caroline "Ah ahhh! Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:591
translate chinese CR4_NS3_menu_e343e5af_1:

    # MC "Hnnnggg! Ugh! Ahh"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:601
translate chinese CR4_NS3_menu_e6ca5d23_1:

    # Caroline "Ohh... *Pant* *Pant*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:602
translate chinese CR4_NS3_menu_28212750_1:

    # MC "Fuck... That was incredible."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:604
translate chinese CR4_NS3_menu_d2a8a825_1:

    # Caroline "Y-Yeah, that was *pant* fucking amazing... You were great!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:618
translate chinese CR4_NS3_menu_bafd573f:

    # MC "How about we try cowgirl tonight?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:619
translate chinese CR4_NS3_menu_ac209ad4:

    # Caroline "What about reverse cowgirl?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:620
translate chinese CR4_NS3_menu_3ed720c0:

    # MC " Which one is that again?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:623
translate chinese CR4_NS3_menu_2a77b0fb:

    # Caroline "Let me show you!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:624
translate chinese CR4_NS3_menu_902a850c:

    # MC "Oh nice!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:625
translate chinese CR4_NS3_menu_104a2133:

    # Caroline "Go ahead and slip your cock inside me. Pussy or ass. Your choice."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:631
translate chinese CR4_NS3_menu_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:632
translate chinese CR4_NS3_menu_86d81d1e:

    # Caroline "Oh fuck, that’s the spot! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:633
translate chinese CR4_NS3_menu_a05a09a3:

    # Caroline "Ah, go ahead and fuck me, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:636
translate chinese CR4_NS3_menu_665d1551:

    # Caroline "Ah! Yes! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:637
translate chinese CR4_NS3_menu_aec7d681:

    # Caroline "How does that feel for you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:640
translate chinese CR4_NS3_menu_165b4b63:

    # MC "Mmm! It’s so good."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:641
translate chinese CR4_NS3_menu_48746a35:

    # Caroline "Do you want me to start moving my hips?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:642
translate chinese CR4_NS3_menu_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:645
translate chinese CR4_NS3_menu_1d6b72c9:

    # Caroline "Ah! Ahh! Ohh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:646
translate chinese CR4_NS3_menu_3cbbd539:

    # MC "Mmmm! Fuck! That’s good!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:647
translate chinese CR4_NS3_menu_29a77369:

    # Caroline "Oh, my God! Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:650
translate chinese CR4_NS3_menu_cebc36da:

    # MC "Ride my cock, Caroline! Yes!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:652
translate chinese CR4_NS3_menu_89dacc01:

    # Caroline "Ah! Ahh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:654
translate chinese CR4_NS3_menu_f0c13720:

    # MC "Mmmm! Faster!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:656
translate chinese CR4_NS3_menu_cb044fb7:

    # Caroline "Ooohhh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:657
translate chinese CR4_NS3_menu_8e74e1fc:

    # Caroline "(Holy fuck, his cock went so deep inside me... I’m so wet right now!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:658
translate chinese CR4_NS3_menu_b7dd77bc:

    # MC "Don’t stop! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:661
translate chinese CR4_NS3_menu_0b1188e0:

    # MC "Ah...Ohhhh... Wow..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:662
translate chinese CR4_NS3_menu_5ce9e729:

    # Caroline "Would you *gasp* like me to go faster?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:663
translate chinese CR4_NS3_menu_8dd7f9fa:

    # MC "Yes, please!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:666
translate chinese CR4_NS3_menu_4f067e1e:

    # MC "Oh! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:667
translate chinese CR4_NS3_menu_fcb49e6b:

    # Caroline "Hnnng... MMMM!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:670
translate chinese CR4_NS3_menu_f81e6c91:

    # Caroline "Your cock is so damn thick! Ugh! Ohh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:671
translate chinese CR4_NS3_menu_8a96add5:

    # MC "Keep riding me, Caroline! Ah! I love it!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:672
translate chinese CR4_NS3_menu_9a2d713f:

    # MC "Mmm! Hnnngg..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:675
translate chinese CR4_NS3_menu_2fbf5885:

    # Caroline "I hope you’re Ahh... not going to cum on me yet!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:677
translate chinese CR4_NS3_menu_73eb2535:

    # Caroline "I’m not finished ohh... riding you! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:679
translate chinese CR4_NS3_menu_ea51c392:

    # MC "Faster! Caroline!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:681
translate chinese CR4_NS3_menu_ff9b5571:

    # MC "Ah...Ohhhh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:683
translate chinese CR4_NS3_menu_361fb6a7:

    # MC "Faster! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:685
translate chinese CR4_NS3_menu_a96a7af9:

    # Caroline "Ahhhh! AYAYAAAAHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:686
translate chinese CR4_NS3_menu_01076d68:

    # MC "(Fuck, that was loud! I hope nobody else in the house heard us!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:687
translate chinese CR4_NS3_menu_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:690
translate chinese CR4_NS3_menu_b810e8f1:

    # Caroline "Shit ah... sorry, I was too loud there, wasn’t I?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:691
translate chinese CR4_NS3_menu_04438941:

    # MC "Just a little bit, haha!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:692
translate chinese CR4_NS3_menu_83c24480:

    # Caroline "I’ll try and dial it down a notch. Let’s do regular cowgirl now."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:695
translate chinese CR4_NS3_menu_59da1b43:

    # Caroline "Mmm, you look so hot right there. I can’t wait to plant myself down on your fat cock."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:696
translate chinese CR4_NS3_menu_5f0b7527:

    # Caroline "I’m going to make you squirm beneath me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:699
translate chinese CR4_NS3_menu_81279dbf:

    # Caroline "Hehe, you’re going to love the next few minutes."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:700
translate chinese CR4_NS3_menu_a9e1ff9e:

    # MC "Oh, I’m sure I will."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:701
translate chinese CR4_NS3_menu_0d6fdd07:

    # Caroline "God, you’re so handsome."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:704
translate chinese CR4_NS3_menu_5580b6c9:

    # Caroline "Ah... Okay... Here we go!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:705
translate chinese CR4_NS3_menu_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:706
translate chinese CR4_NS3_menu_abb50074:

    # MC "(I can feel her vulva, wrapped around the tip of my cock.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:709
translate chinese CR4_NS3_menu_92e5645f:

    # MC "OOOHHH!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:710
translate chinese CR4_NS3_menu_edce70ef:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:711
translate chinese CR4_NS3_menu_febea908:

    # Caroline "Ah... T-Try to keep your voice down, hehe!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:714
translate chinese CR4_NS3_menu_b8c783cc:

    # Caroline "I... ah... oh... don’t want anyone interrupting mmm... us now!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:715
translate chinese CR4_NS3_menu_bfe279c7:

    # MC "Uh huh, sure, Caroline! Ahh.... Your pussy feels so fucking good."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:718
translate chinese CR4_NS3_menu_ca073a0c:

    # MC "Ugh! Just like that, Caroline! Keep bouncing on my cock!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:719
translate chinese CR4_NS3_menu_a77dbc2d:

    # Caroline "Ah! Ahh! Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:722
translate chinese CR4_NS3_menu_c8023017:

    # MC "Ooohh! Fuck, I’m getting close!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:723
translate chinese CR4_NS3_menu_7028a503:

    # Caroline "Mmm! Where do you want to cum, [player_name]?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:729
translate chinese CR4_NS3_menu_971f5355:

    # MC "Don’t stop bouncing, Caroline! I want to cum inside you!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:730
translate chinese CR4_NS3_menu_9c10fa5b:

    # Caroline "Uh huh! Cum inside me! Fill me up, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:731
translate chinese CR4_NS3_menu_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:734
translate chinese CR4_NS3_menu_12fff763:

    # Caroline "Ayaaahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:735
translate chinese CR4_NS3_menu_b204a169:

    # MC "Hnnnngg!!! UGH!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:737
translate chinese CR4_NS3_menu_9ccb3f7a:

    # Caroline "Cum inside your sister’s slutty pussy! Do it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:739
translate chinese CR4_NS3_menu_6af7ba75:

    # Caroline "Cum inside your girlfriend’s slutty pussy! Do it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:740
translate chinese CR4_NS3_menu_043fe09a:

    # MC "AAHAHHHHH! OHHHH!! FUCK!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:750
translate chinese CR4_NS3_menu_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:751
translate chinese CR4_NS3_menu_212ccf36:

    # Caroline "Hehe, did you enjoy that?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:752
translate chinese CR4_NS3_menu_a9cfe6fe:

    # MC "*Gasp* Y-Yeah, that was amazing, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:764
translate chinese CR4_NS3_menu_15e43593:

    # MC "Get on your knees. I’ll cum over your face."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:765
translate chinese CR4_NS3_menu_186fb669:

    # Caroline "Okay, two seconds."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:768
translate chinese CR4_NS3_menu_dba9ac4c:

    # Caroline "Ready!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:769
translate chinese CR4_NS3_menu_87aa9cff:

    # MC "Ugh! Ahh... Ohh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:779
translate chinese CR4_NS3_menu_16f751f8:

    # MC "Hnnnnggg! UGH! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:780
translate chinese CR4_NS3_menu_907508e7:

    # Caroline "Oh wow! Almost got me in the eye, there! Hehe!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:781
translate chinese CR4_NS3_menu_82ebae89:

    # MC "Oh... *Phew* That was amazing, Caroline. Thank you."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:793
translate chinese CR4_NS3_menu_6827cf7d:

    # MC "Mmm... I’ll fuck your ass tonight."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:795
translate chinese CR4_NS3_menu_b9c3643d:

    # Caroline "Oh fuck, that’s so tight!! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:796
translate chinese CR4_NS3_menu_64db08d1:

    # Caroline "Just be slow ah... at first."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:799
translate chinese CR4_NS3_menu_a6a0f037:

    # Caroline "Ohh... *Pant*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:800
translate chinese CR4_NS3_menu_aec7d681_1:

    # Caroline "How does that feel for you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:803
translate chinese CR4_NS3_menu_a15ecf96:

    # MC "Mmm! It’s so good, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:804
translate chinese CR4_NS3_menu_5ad88110:

    # Caroline "Do you want me to stop moving my hips?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:805
translate chinese CR4_NS3_menu_5da849b6_1:

    # MC "Yeah!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:808
translate chinese CR4_NS3_menu_1d6b72c9_1:

    # Caroline "Ah! Ahh! Ohh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:809
translate chinese CR4_NS3_menu_3cbbd539_1:

    # MC "Mmmm! Fuck! That’s good!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:810
translate chinese CR4_NS3_menu_29a77369_1:

    # Caroline "Oh, my God! Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:813
translate chinese CR4_NS3_menu_cebc36da_1:

    # MC "Ride my cock, Caroline! Yes!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:814
translate chinese CR4_NS3_menu_89dacc01_1:

    # Caroline "Ah! Ahh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:817
translate chinese CR4_NS3_menu_cb044fb7_1:

    # Caroline "Ooohhh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:818
translate chinese CR4_NS3_menu_dd8f6abd:

    # Caroline "(Holy fuck, his cock went so deep inside my ass... That feels... strangely pleasurable.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:819
translate chinese CR4_NS3_menu_d594c161:

    # MC "Don’t stop! Hnng!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:822
translate chinese CR4_NS3_menu_0b1188e0_1:

    # MC "Ah...Ohhhh... Wow..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:823
translate chinese CR4_NS3_menu_5ce9e729_1:

    # Caroline "Would you *gasp* like me to go faster?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:824
translate chinese CR4_NS3_menu_8dd7f9fa_1:

    # MC "Yes, please!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:827
translate chinese CR4_NS3_menu_4f067e1e_1:

    # MC "Oh! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:828
translate chinese CR4_NS3_menu_fcb49e6b_1:

    # Caroline "Hnnng... MMMM!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:831
translate chinese CR4_NS3_menu_f81e6c91_1:

    # Caroline "Your cock is so damn thick! Ugh! Ohh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:832
translate chinese CR4_NS3_menu_c407976a:

    # MC "Hnng! And your ass is soooo fucking tight, right now! Don’t stop riding me!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:833
translate chinese CR4_NS3_menu_9a2d713f_1:

    # MC "Mmm! Hnnngg..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:836
translate chinese CR4_NS3_menu_2fbf5885_1:

    # Caroline "I hope you’re Ahh... not going to cum on me yet!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:838
translate chinese CR4_NS3_menu_73eb2535_1:

    # Caroline "I’m not finished ohh... riding you! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:840
translate chinese CR4_NS3_menu_ea51c392_1:

    # MC "Faster! Caroline!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:842
translate chinese CR4_NS3_menu_ff9b5571_1:

    # MC "Ah...Ohhhh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:844
translate chinese CR4_NS3_menu_361fb6a7_1:

    # MC "Faster! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:846
translate chinese CR4_NS3_menu_a96a7af9_1:

    # Caroline "Ahhhh! AYAYAAAAHHHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:847
translate chinese CR4_NS3_menu_01076d68_1:

    # MC "(Fuck, that was loud! I hope nobody else in the house heard us!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:848
translate chinese CR4_NS3_menu_43b8826f_2:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:851
translate chinese CR4_NS3_menu_b810e8f1_1:

    # Caroline "Shit ah... sorry, I was too loud there, wasn’t I?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:852
translate chinese CR4_NS3_menu_04438941_1:

    # MC "Just a little bit, haha!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:853
translate chinese CR4_NS3_menu_83c24480_1:

    # Caroline "I’ll try and dial it down a notch. Let’s do regular cowgirl now."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:856
translate chinese CR4_NS3_menu_59da1b43_1:

    # Caroline "Mmm, you look so hot right there. I can’t wait to plant myself down on your fat cock."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:857
translate chinese CR4_NS3_menu_5f0b7527_1:

    # Caroline "I’m going to make you squirm beneath me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:860
translate chinese CR4_NS3_menu_81279dbf_1:

    # Caroline "Hehe, you’re going to love the next few minutes."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:861
translate chinese CR4_NS3_menu_a9e1ff9e_1:

    # MC "Oh, I’m sure I will."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:862
translate chinese CR4_NS3_menu_0d6fdd07_1:

    # Caroline "God, you’re so handsome."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:865
translate chinese CR4_NS3_menu_5580b6c9_1:

    # Caroline "Ah... Okay... Here we go!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:866
translate chinese CR4_NS3_menu_ac6d5d68_1:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:867
translate chinese CR4_NS3_menu_3ebd709b:

    # MC "(Her asshole is so damn tight! I don’t think I can last much longer! She’ll milk me dry!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:870
translate chinese CR4_NS3_menu_92e5645f_1:

    # MC "OOOHHH!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:871
translate chinese CR4_NS3_menu_edce70ef_1:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:872
translate chinese CR4_NS3_menu_febea908_1:

    # Caroline "Ah... T-Try to keep your voice down, hehe!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:875
translate chinese CR4_NS3_menu_69fc131e:

    # Caroline "I... ah... oh... don’t want anyone interrupting - mmm - us now!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:876
translate chinese CR4_NS3_menu_7cf5d8d8:

    # MC "Uh huh, sure! Ahh.... Your ass feels so good. I’m not hurting you, am I?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:877
translate chinese CR4_NS3_menu_af8e4fbc:

    # Caroline "Ah, n-no. This is alright!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:880
translate chinese CR4_NS3_menu_ca073a0c_1:

    # MC "Ugh! Just like that, Caroline! Keep bouncing on my cock!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:881
translate chinese CR4_NS3_menu_a77dbc2d_1:

    # Caroline "Ah! Ahh! Yes!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:884
translate chinese CR4_NS3_menu_c8023017_1:

    # MC "Ooohh! Fuck, I’m getting close!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:885
translate chinese CR4_NS3_menu_0bfe3f7d:

    # Caroline "Mmm! Where do you want to cum, [player_name]"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:891
translate chinese CR4_NS3_menu_da811175:

    # MC "Don’t stop bouncing, Caroline! I want to cum inside your ass!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:892
translate chinese CR4_NS3_menu_9c10fa5b_1:

    # Caroline "Uh huh! Cum inside me! Fill me up, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:893
translate chinese CR4_NS3_menu_d174ea9d_1:

    # MC "Hnnng..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:896
translate chinese CR4_NS3_menu_12fff763_1:

    # Caroline "Ayaaahhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:897
translate chinese CR4_NS3_menu_b204a169_1:

    # MC "Hnnnngg!!! UGH!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:899
translate chinese CR4_NS3_menu_063f678f:

    # Caroline "Cum inside your sister’s slutty ass! Do it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:901
translate chinese CR4_NS3_menu_448da1bf:

    # Caroline "Cum inside your girlfriend’s slutty ass! Do it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:902
translate chinese CR4_NS3_menu_043fe09a_1:

    # MC "AAHAHHHHH! OHHHH!! FUCK!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:912
translate chinese CR4_NS3_menu_2f7b3b4b_1:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:913
translate chinese CR4_NS3_menu_212ccf36_1:

    # Caroline "Hehe, did you enjoy that?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:914
translate chinese CR4_NS3_menu_a9cfe6fe_1:

    # MC "*Gasp* Y-Yeah, that was amazing, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:926
translate chinese CR4_NS3_menu_15e43593_1:

    # MC "Get on your knees. I’ll cum over your face."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:927
translate chinese CR4_NS3_menu_186fb669_1:

    # Caroline "Okay, two seconds."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:930
translate chinese CR4_NS3_menu_dba9ac4c_1:

    # Caroline "Ready!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:931
translate chinese CR4_NS3_menu_87aa9cff_1:

    # MC "Ugh! Ahh... Ohh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:942
translate chinese CR4_NS3_menu_16f751f8_1:

    # MC "Hnnnnggg! UGH! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:943
translate chinese CR4_NS3_menu_907508e7_1:

    # Caroline "Oh wow! Almost got me in the eye, there! Hehe!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:944
translate chinese CR4_NS3_menu_82ebae89_1:

    # MC "Oh... *Phew* That was amazing, Caroline. Thank you."
    MC ""

translate chinese strings:

    # game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:214
    old "Doggy Style"
    new ""

    # game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:214
    old "Cowgirl (disabled)"
    new ""

    # game/scripts/home/caroline_room/night/scenes/CR4_NS3.rpy:214
    old "Cowgirl"
    new ""

