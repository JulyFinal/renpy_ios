﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:35
translate chinese SR3_ES1_label_a646901d:

    # Sara "Not now, [player_name]."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:51
translate chinese SR3_ES1_label_6ce2694c:

    # MC "(Sara said she wasn’t grounded any longer. I’m lucky that she finally got her act together and improved her grades.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:52
translate chinese SR3_ES1_label_eb778de1:

    # MC "(I wonder how she’s been doing locked up in her room. [Mom_name] has been constantly checking to make sure she isn’t slacking off playing video games. I guess all she needed was some tough love.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:54
translate chinese SR3_ES1_label_61c94188:

    # MC "(Sara said she now has a lot of free time for me. I’m lucky that she finally got her act together and improved her grades.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:55
translate chinese SR3_ES1_label_99c82448:

    # MC "(I wonder how she's been all that time in her room. It was probably hard for her to stop playing video games and focus on learning. Maybe she did it only for me?)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:58
translate chinese SR3_ES1_label_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:60
translate chinese SR3_ES1_label_d6c8c02e:

    # Sara "Who is it?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:61
translate chinese SR3_ES1_label_7ccb5922:

    # MC "Just me, Sara."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:63
translate chinese SR3_ES1_label_ac5b53f9:

    # Sara "The door’s unlocked! C’mon in!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:65
translate chinese SR3_ES1_label_09d06ab8:

    # "*Click*"
    ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:69
translate chinese SR3_ES1_label_6d6a37fd:

    # MC "Hey, little sis. How’ve you been?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:70
translate chinese SR3_ES1_label_1d06acb1:

    # Sara "I hope you aren’t referring to my tits."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:72
translate chinese SR3_ES1_label_4ebae5b8:

    # MC "Hey Sara. How’ve you been? You’re looking a little bit down today."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:73
translate chinese SR3_ES1_label_873109c2:

    # Sara "A “little” bit? I hope you aren’t referring to my tits."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:76
translate chinese SR3_ES1_label_bcc3afc5:

    # MC "Wh-What? I wasn’t- You’re my- and you’re younger th-"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:78
translate chinese SR3_ES1_label_f90c71d0:

    # MC "Wh-What? I wasn’t- You’re- I- I didn’t- "
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:79
translate chinese SR3_ES1_label_ee3801da:

    # Sara "Hmmp! Calling me “little.” Not everyone can have a massive pair of boobs like Caroline or [Mom_name]!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:80
translate chinese SR3_ES1_label_14e50cfe:

    # MC "I- That isn’t what I meant by-"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:82
translate chinese SR3_ES1_label_7435af02:

    # Sara "Hehe... Hahaha! YOUR FACE! Gotcha!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:83
translate chinese SR3_ES1_label_67b59127:

    # MC "*Sigh* I legitimately thought you were pissed off at me there."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:84
translate chinese SR3_ES1_label_12557d3b:

    # Sara "Ahahaha! Sorry, I couldn’t resist. I missed you."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:86
translate chinese SR3_ES1_label_38256a5e:

    # MC "I missed you too, Sara. So, Mom says you’re not grounded anymore?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:88
translate chinese SR3_ES1_label_663e0986:

    # MC "I missed you too, Sara. So, you now have a lof of free time for us?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:90
translate chinese SR3_ES1_label_eec3b2b1:

    # Sara "Yup, I’m a free woman! Take a seat."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:91
translate chinese SR3_ES1_label_4acd11b0:

    # MC "Linda is not going to give you any more problems now?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:92
translate chinese SR3_ES1_label_a2d65614:

    # Sara "Nope! Haha! I came home one day with an A from the English module in college. [Mom_name] was, like, super proud when she saw it and that my tuition grant is safe."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:94
translate chinese SR3_ES1_label_50d2223e:

    # MC "Cool, what book were you studying?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:96
translate chinese SR3_ES1_label_c7d96bcf:

    # Sara "No book, it was creative writing. Mr. Stewart asked us to try our hand writing dystopian stories, so I spent ages thinking of the most dystopian things I could. In the end I decided to draw off my real life experience of being stuck in my room while grounded."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:98
translate chinese SR3_ES1_label_b0ffe84a:

    # Sara "No book, it was creative writing. Mr. Stewart asked us to try our hand at writing dystopian stories, so I spent ages thinking of the most dystopian things I could. In the end, I decided to draw off my real-life experience of being stuck in my room with books."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:99
translate chinese SR3_ES1_label_5e5a3f51:

    # MC "Huh, interesting. What was your story about, then?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:101
translate chinese SR3_ES1_label_2284b69c:

    # Sara "So, hear me out... think of me being grounded and stuck inside all day, okay?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:103
translate chinese SR3_ES1_label_8bfd758f:

    # Sara "So, hear me out... think of me being theoretically grounded and stuck inside all day, okay?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:104
translate chinese SR3_ES1_label_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:106
translate chinese SR3_ES1_label_8513e113:

    # Sara "Now, imagine the WHOLE WORLD was grounded!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:107
translate chinese SR3_ES1_label_19570c32:

    # MC "What?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:108
translate chinese SR3_ES1_label_6774b4d2:

    # Sara "There’s like this super deadly virus and everyone has to stay indoors to hide from it for a full year or it spreads and kills people!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:109
translate chinese SR3_ES1_label_66a7f15f:

    # MC "Geez, that sounds horrible."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:110
translate chinese SR3_ES1_label_17d3bd3c:

    # Sara "I know, right? Anyway, Mr. Stewart said something like, “Prose and dramatic tension were akin to Sartre’s No Exit, even if the premise was a little unrealistic.” But hey - I got an A, and found a passion for writing."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:111
translate chinese SR3_ES1_label_5751a3cd:

    # MC "I’m glad to hear that, Sara."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:114
translate chinese SR3_ES1_label_76b42e92:

    # Sara "Me too. You’ve got NO idea what it’s like! [Mom_name] ended up taking away the power cable for my computer. I couldn’t even do any gaming."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:116
translate chinese SR3_ES1_label_f7d37720:

    # Sara "Me too. You’ve got NO idea what it’s like! I once suspected that Linda once plug off the internet cable at home just so I couldn't do any gaming! But, that's just a guess! Haha!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:117
translate chinese SR3_ES1_label_772fe0c0:

    # MC "Well, it worked, didn’t it?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:118
translate chinese SR3_ES1_label_14f73222:

    # Sara "Yeah, I suppose."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:119
translate chinese SR3_ES1_label_23cc3247:

    # MC "Did [Dad_name] say anything?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:122
translate chinese SR3_ES1_label_907e037f:

    # Sara "When has [Dad_name] EVER tried to discipline us? He just rides along with whatever [Mom_name] decides. She’s the one who wears the pants in this house."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:124
translate chinese SR3_ES1_label_702b6d95:

    # Sara "When has Bob EVER tried to discipline us? I mean, I know he’s very old but he just rides along with whatever his wife decides. She’s the one who wears the pants in the house."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:126
translate chinese SR3_ES1_label_da9445c6:

    # MC "You aren’t wrong there. I’ve always had a soft spot for Dad."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:128
translate chinese SR3_ES1_label_9ee6dfca:

    # MC "You aren’t wrong there. I’ve always had a soft spot for him."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:129
translate chinese SR3_ES1_label_30cbae5a:

    # Sara "Me too."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:131
translate chinese SR3_ES1_label_44db2ef6:

    # MC "(I don’t think Sara’s wearing a bra today! I can see the outline of her nipples through her tank top!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:132
translate chinese SR3_ES1_label_e9ea406d:

    # MC "(It’s been so long since I last saw her tits. Hopefully I’ll get another opportunity soon.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:133
translate chinese SR3_ES1_label_e3111447:

    # MC "(Hmm, I wonder why she’s keeping her phone facing away from me.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:139
translate chinese SR3_ES1_label_a3ebafb1:

    # MC "What are you reading on your phone, there?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:140
translate chinese SR3_ES1_label_34cf5de5:

    # Sara "N-Nothing!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:142
translate chinese SR3_ES1_label_0030c4b7:

    # MC "Uh huh, I remember using that excuse when Mom almost caught me watching porn."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:144
translate chinese SR3_ES1_label_22ebb316:

    # MC "Uh huh, I remember using that excuse when somebody was almost caught watching porn!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:146
translate chinese SR3_ES1_label_ef075ff8:

    # Sara "Eww! I’m not like you! I wasn’t watching porn!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:147
translate chinese SR3_ES1_label_927003c4:

    # MC "Well, if it’s not porn, what are you acting so cagey for?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:148
translate chinese SR3_ES1_label_4b2c8b94:

    # Sara "I- It’s nothing. It’s private."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:150
translate chinese SR3_ES1_label_28768983:

    # MC "You’ve already sent me nudes! What could POSSIBLY be more private than that? Let me see!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:151
translate chinese SR3_ES1_label_c754d43a:

    # Sara "I... I... Umm..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:152
translate chinese SR3_ES1_label_8d494c45:

    # MC "C’mon Sara, it can’t be that bad?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:154
translate chinese SR3_ES1_label_c7a18168:

    # Sara "W-Wait! Don’t!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:155
translate chinese SR3_ES1_label_387b2631:

    # Sara "D-Do you remember me... um... texting you earlier about the..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:157
translate chinese SR3_ES1_label_a4648247:

    # MC "When you said you wanted us to go to the mall together for ice cream?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:158
translate chinese SR3_ES1_label_0a3100a3:

    # Sara "Y-Yeah, but... I was thinking... Maybe we... I..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:159
translate chinese SR3_ES1_label_40cdd346:

    # MC "(What on Earth has gotten into Sara? She’s acting so anxious right now.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:161
translate chinese SR3_ES1_label_1169e48a:

    # Sara "S-Sorry, don’t go anywhere, [player_name]. I just need a minute."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:162
translate chinese SR3_ES1_label_0f7d432b:

    # MC "Uhh, okay. Take your time."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:163
translate chinese SR3_ES1_label_a0ebaefa:

    # Sara "I... wanted to go... to the mall with you, but..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:165
translate chinese SR3_ES1_label_8fc38c76:

    # Sara "(C’mon Sara! Be brave! You can do this!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:166
translate chinese SR3_ES1_label_499f050e:

    # Sara "(Alright... I just have to tell [player_name] that this isn’t us going out for an ice cream and some shopping.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:167
translate chinese SR3_ES1_label_96f8b644:

    # Sara "(I have to explain that I want this to be an ACTUAL date like we’re boyfriend and girlfriend. I want people to KNOW that we’re a couple now.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:168
translate chinese SR3_ES1_label_1080e365:

    # Sara "(Okay... Deep breaths, Sara. You can do this! Just ask him out. What’s the worst that could happen?)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:170
translate chinese SR3_ES1_label_9839c5eb:

    # MC "You okay there, Sara?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:171
translate chinese SR3_ES1_label_8c7e59ef:

    # Sara "Y-Yeah, j-just a minute!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:173
translate chinese SR3_ES1_label_e4d27216:

    # Sara "(If he says ‘no’ then it means he’s not actually interested in me romantically.. It would mean he was just using me for sex.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:175
translate chinese SR3_ES1_label_43907daf:

    # Sara "(On the other hand, if he agrees to make it a date, then I’ll have my first ever boyfriend! Oh my God, I’m so nervous right now.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:176
translate chinese SR3_ES1_label_830a8322:

    # MC "Your hands are shaking, Sara. Should I get [Mom_name]?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:178
translate chinese SR3_ES1_label_83a4d87c:

    # Sara "(On the other hand, if he agrees to make it a date, then I’ll have my first true, real, romantic, sexy, handsome boyfriend! Oh my God! I’m so nervous right now.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:179
translate chinese SR3_ES1_label_5b4a8cd7:

    # MC "Your hands are shaking, Sara. Should I call an ambulance? Haha!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:180
translate chinese SR3_ES1_label_c14cca3f:

    # Sara "N-No!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:182
translate chinese SR3_ES1_label_6caa91ae:

    # Sara "I was w-wondering if y-you would... *gulp* ...want to... make our trip to the... mall... a... umm... date?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:183
translate chinese SR3_ES1_label_faad9324:

    # MC "A date, huh?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:184
translate chinese SR3_ES1_label_e2a2ba09:

    # Sara "Y-Yeah, if that’s... cool... with you..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:189
translate chinese SR3_ES1_label_c10795db:

    # MC "Of course, Sara! It’s a date."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:190
translate chinese SR3_ES1_label_231de335:

    # Sara "R-Really?!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:191
translate chinese SR3_ES1_label_150c5e22:

    # MC "Yup! Just you and me!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:193
translate chinese SR3_ES1_label_2a53d525:

    # MC "I’m going to head on and get ready for the mall."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:194
translate chinese SR3_ES1_label_77e829d2:

    # Sara "(That was a LOT less stressful than I imagined it would be. I don’t know what I was getting so worried about!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:196
translate chinese SR3_ES1_label_31f73f85:

    # Sara "Hold up, where should I meet you?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:198
translate chinese SR3_ES1_label_462620d5:

    # MC "Tell you what, I’ll meet you at the mall on the weekend. How does that sound?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:199
translate chinese SR3_ES1_label_0533d4ae:

    # Sara "Great! I’ll catch you there."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:201
translate chinese SR3_ES1_label_67598e57:

    # Sara "Oh, I should mention - I bought a special outfit, [player_name]. I think you’re reaaaaalllly gonna like it."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:202
translate chinese SR3_ES1_label_a75c5280:

    # MC "Mmm, I’m looking forward to seeing it. Catch you later, Sara."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:203
translate chinese SR3_ES1_label_171ea06c:

    # Sara "See you at the mall."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:209
translate chinese SR3_ES1_label_86ecc577:

    # MC "(Crap! I’ve already got other women in my life that I’m growing close too. If any of them catch Sara and me openly dating, things could get VERY awkward VERY quickly.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:210
translate chinese SR3_ES1_label_06e3f68f:

    # MC "I... uh... Listen, Sara. Hmm... God... this is difficult."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:211
translate chinese SR3_ES1_label_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:212
translate chinese SR3_ES1_label_17e69ebd:

    # MC "I’ll go out with you to the mall, but I don’t think we should publicly date each other. We can keep seeing each other as fuck buddies - we’ve got a great thing going on here."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:214
translate chinese SR3_ES1_label_f36978e9:

    # MC "Just... Just try to see this from an outsider’s perspective. Imagine someone from our college sees us kissing in public? What would they say, knowing that you’re my sister?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:216
translate chinese SR3_ES1_label_fddab2ff:

    # MC "Just... Just try to see this from an outsider’s perspective... I know it’s hard to explain..."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:217
translate chinese SR3_ES1_label_06337168:

    # Sara "I... I understand..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:219
translate chinese SR3_ES1_label_c257937e:

    # MC "I’ll go and get myself ready. We’ll meet at the mall on the weekend."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:220
translate chinese SR3_ES1_label_69341d7e:

    # MC "Tell you what - ice cream is on me."
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:221
translate chinese SR3_ES1_label_9fb34b5b:

    # Sara "*Sigh* Thanks..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:223
translate chinese SR3_ES1_label_08c4cfb9:

    # MC "Don’t look so down, Sara. You can think of it as a date in your mind. It’s just not something we can make obvious in public. Okay?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:225
translate chinese SR3_ES1_label_479b32e4:

    # Sara "Yeah... I get it."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:226
translate chinese SR3_ES1_label_167cad12:

    # MC "Cool. Catch you at the mall, Sara!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:228
translate chinese SR3_ES1_label_eab3178e:

    # Sara "(I was excited for [player_name] to say yes, and prepared for him to tell me no. What I never expected was that he would leave me in some kind of romantic limbo.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:229
translate chinese SR3_ES1_label_2f4b41c9:

    # Sara "(What the heck am I supposed to do now? Does he even like me? Is there some other girl that he’s got his sights on?)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:230
translate chinese SR3_ES1_label_47e59b44:

    # Sara "(Am I just some side chick to you, [player_name]? I gave you my anal virginity... was that not enough?)"
    Sara ""

translate chinese strings:

    # game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:186
    old "{color=#00ff00}Of course, Sara! It’s a date.{/color}"
    new ""

    # game/scripts/home/sara_room/evening/scenes/SR3_ES1.rpy:186
    old "{color=#f00}(I’m already in a relationship with someone else. I’m screwed if they catch me and Sara in public together! This date has to be kept on the down low for the meantime.){/color}"
    new ""

