﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:40
translate chinese ML_NS_wake_label_6a9ca6c3:

    # MC "*Whispered* [Linda_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:41
translate chinese ML_NS_wake_label_d465b029:

    # Mom "Zzz..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:42
translate chinese ML_NS_wake_label_a42ced4f:

    # MC "(If I touch her lips, she might wake up?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:46
translate chinese ML_NS_wake_label_75497e89:

    # Mom "Hmm? What time is it..?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:47
translate chinese ML_NS_wake_label_26dae162:

    # MC "*Whispered* Shush - it’s me."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:48
translate chinese ML_NS_wake_label_837d7835:

    # Mom "Huh?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:52
translate chinese ML_NS_wake_label_bfdb92e7:

    # Mom "*Whispered* [player_name], what are you doing here? It’s the middle of the night?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:54
translate chinese ML_NS_wake_label_655188fe:

    # MC "*Whispered* I wanted to spend some time with you. C’mon back to my bedroom with me. We’ll sneak out before Dad wakes up."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:56
translate chinese ML_NS_wake_label_5db24e58:

    # MC "*Whispered* I wanted to spend some time with you. C’mon back to my bedroom with me. We’ll sneak out before Bob wakes up."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:57
translate chinese ML_NS_wake_label_1c6b2636:

    # Mom "*Whispered* And what if he wakes up, and finds me missing?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:58
translate chinese ML_NS_wake_label_e828f715:

    # MC "*Whispered* Just tell him you went to the bathroom - when you get back."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:62
translate chinese ML_NS_wake_label_97cbf899:

    # Mom "*Whispered* I don’t think so..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:63
translate chinese ML_NS_wake_label_88c2b5bf:

    # Mom "*Whispered* I want to have you in MY bedroom tonight."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:65
translate chinese ML_NS_wake_label_7bef36cc:

    # MC "*Whispered* Are you crazy?! Dad’s LITERALLY right there?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:67
translate chinese ML_NS_wake_label_dc1eff86:

    # MC "*Whispered* Are you crazy?! Your husband is LITERALLY right there?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:71
translate chinese ML_NS_wake_label_10f7a572:

    # Dad "Zzz..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:72
translate chinese ML_NS_wake_label_736e5cbb:

    # Mom "*Whispered* Please... That old coot, could sleep through a car crash! I’ve seen him fall asleep with the TV blaring, on full volume."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:73
translate chinese ML_NS_wake_label_13e42a51:

    # MC "*Whispered* Are you sure?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_wake.rpy:74
translate chinese ML_NS_wake_label_3aa24c94:

    # Mom "*Whispered* Yeah - don’t worry about waking him up."
    Mom ""

