﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:27
translate chinese MLR2_ES1_label_391d9f8e:

    # MC "(Looks like Mom’s doing some cleaning. She probably hasn’t noticed I’m in the kitchen yet.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:29
translate chinese MLR2_ES1_label_925dec69:

    # MC "(Looks like Linda’s doing some cleaning. She probably hasn’t noticed I’m in the kitchen yet.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:30
translate chinese MLR2_ES1_label_65436c18:

    # MC "(Hmm... This could be my chance to prove how confident and forward I can be with her.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:31
translate chinese MLR2_ES1_label_6f5b6f49:

    # MC "(Should I maybe grab her ass? Maybe that’s too much.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:32
translate chinese MLR2_ES1_label_38931852:

    # MC "(I suppose I could just hold her waist?)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:52
translate chinese MLR2_ES1_grab_ass_fbeb99dc:

    # MC "(Well... here goes nothing! Hopefully she’ll enjoy, me grabbing her ass!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:53
translate chinese MLR2_ES1_grab_ass_07bb49e6:

    # MC "(Firm, as always! She’s got a great butt!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:54
translate chinese MLR2_ES1_grab_ass_4aa34cde:

    # MC "(Hmm... she doesn’t seem to be reacting...)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:58
translate chinese MLR2_ES1_grab_ass_ff9e6c3c:

    # Mom "Not NOW. I’m NOT in the mood for this."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:59
translate chinese MLR2_ES1_grab_ass_d9ed4175:

    # Mom "Besides, I told you earlier how busy I am!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:60
translate chinese MLR2_ES1_grab_ass_13f70f15:

    # Mom "Don’t you have work you should be getting on with?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:61
translate chinese MLR2_ES1_grab_ass_9a613e54:

    # MC "Uh- S-Sorry! My bad!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:65
translate chinese MLR2_ES1_grab_ass_2f83814b:

    # Mom "Huh?! Oh shit!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:67
translate chinese MLR2_ES1_grab_ass_65725387:

    # Mom "Sorry, I thought that was your father!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:68
translate chinese MLR2_ES1_grab_ass_c2bad5e1:

    # MC "Sorry, Mom. I-"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:70
translate chinese MLR2_ES1_grab_ass_d45df978:

    # Mom "Sorry, I thought you were my husband!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:71
translate chinese MLR2_ES1_grab_ass_7d3b56d7:

    # MC "Sorry, Linda. I-"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:72
translate chinese MLR2_ES1_grab_ass_de89f45d:

    # Mom "No, don’t apologise! You didn’t do anything wrong!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:73
translate chinese MLR2_ES1_grab_ass_3de09ef0:

    # Mom "Sorry. That bastard is just, ALWAYS looking for sex when he hasn’t even finished the housework I gave him to do!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:80
translate chinese MLR2_ES1_waist_297b15fa:

    # MC "(I think I’ll wrap my hands around her waist instead. It’s a little more romantic than just randomly grabbing her ass, out of the blue!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:81
translate chinese MLR2_ES1_waist_964a9ff8:

    # MC "(Let’s see how this goes...)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:85
translate chinese MLR2_ES1_waist_ff9e6c3c:

    # Mom "Not NOW. I’m NOT in the mood for this."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:86
translate chinese MLR2_ES1_waist_d9ed4175:

    # Mom "Besides, I told you earlier how busy I am!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:87
translate chinese MLR2_ES1_waist_13f70f15:

    # Mom "Don’t you have work you should be getting on with?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:88
translate chinese MLR2_ES1_waist_9a613e54:

    # MC "Uh- S-Sorry! My bad!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:92
translate chinese MLR2_ES1_waist_2f83814b:

    # Mom "Huh?! Oh shit!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:94
translate chinese MLR2_ES1_waist_65725387:

    # Mom "Sorry, I thought that was your father!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:95
translate chinese MLR2_ES1_waist_c2bad5e1:

    # MC "Sorry, Mom. I-"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:97
translate chinese MLR2_ES1_waist_d45df978:

    # Mom "Sorry, I thought you were my husband!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:98
translate chinese MLR2_ES1_waist_98c02735:

    # MC "Sorry Linda. I-"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:99
translate chinese MLR2_ES1_waist_de89f45d:

    # Mom "No, don’t apologise! You didn’t do anything wrong!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:100
translate chinese MLR2_ES1_waist_697fce4a:

    # Mom "Sorry, that bastard is just ALWAYS looking for sex when he hasn’t even finished the housework I gave him to do!"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:108
translate chinese after_menu_MLR2_ES1_label_e61e656b:

    # Mom "Listen, I’m really really sorry, [player_name]."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:109
translate chinese after_menu_MLR2_ES1_label_f3043468:

    # Mom "Can we just continue where we left off before I shouted?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:110
translate chinese after_menu_MLR2_ES1_label_500d1129:

    # MC "Uh... sure."
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:114
translate chinese after_menu_MLR2_ES1_label_f9303754:

    # Mom "Now, if I remember, I was bent over like, this here."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:115
translate chinese after_menu_MLR2_ES1_label_bba4ade4:

    # Mom "Go ahead and play with my ass. You’re allowed to."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:117
translate chinese after_menu_MLR2_ES1_label_58844155:

    # MC "Thanks, Mom!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:119
translate chinese after_menu_MLR2_ES1_label_bc6f5a79:

    # MC "Thanks, Linda!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:120
translate chinese after_menu_MLR2_ES1_label_265e369a:

    # MC "(Wow, she’s got a great ass!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:124
translate chinese after_menu_MLR2_ES1_label_6edfccd9:

    # Mom "Mmm... That’s it. You can squeeze a little harder if you like."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:125
translate chinese after_menu_MLR2_ES1_label_2221e656:

    # MC "(Damn, she looks great in these tight jeans!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:129
translate chinese after_menu_MLR2_ES1_label_9e92dbf1:

    # Mom "Ahh... You’re enjoying that, aren’t you, [player_name]?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:130
translate chinese after_menu_MLR2_ES1_label_04d32733:

    # MC "Of course! Haha!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:131
translate chinese after_menu_MLR2_ES1_label_333a7193:

    # Mom "Well, if you’re enjoying it that much, then maybe we should set down some rules."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:135
translate chinese after_menu_MLR2_ES1_label_2912010f:

    # MC "Rules? Like what?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:136
translate chinese after_menu_MLR2_ES1_label_b0c2f660:

    # Mom "Let me think... Hmm..."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:137
translate chinese after_menu_MLR2_ES1_label_7841e363:

    # Mom "Well, you clearly enjoy touching my body. So, how about we make a deal?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:141
translate chinese after_menu_MLR2_ES1_label_42edcec2:

    # MC "A deal?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:142
translate chinese after_menu_MLR2_ES1_label_0cd1c240:

    # Mom "You can touch my body as much as you like and WHENEVER you want."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:143
translate chinese after_menu_MLR2_ES1_label_55dad2d8:

    # MC "I like the sound of that A LOT!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:147
translate chinese after_menu_MLR2_ES1_label_e66e2fca:

    # Mom "And in return, I get to touch you whenever I want, for as long as I want to."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:148
translate chinese after_menu_MLR2_ES1_label_90748884:

    # Mom "Does that sound like a good deal?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:149
translate chinese after_menu_MLR2_ES1_label_0c473fa3:

    # MC "Oh yeah. I’m looking forward to this!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:150
translate chinese after_menu_MLR2_ES1_label_9e5f44f0:

    # Mom "Mmm... Me too."
    Mom ""

translate chinese strings:

    # game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:35
    old "Grab Mom’s ass."
    new ""

    # game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:35
    old "Grab Linda’s ass."
    new ""

    # game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:35
    old "Wrap your hands around Mom’s waist."
    new ""

    # game/scripts/home/kitchen/evening/scenes/MLR2_ES1.rpy:35
    old "Wrap your hands around Linda’s waist."
    new ""

