﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:103
translate chinese SR2_NS2_label_423a0870:

    # MC "Hey, Sara! I’m glad you came."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:104
translate chinese SR2_NS2_label_8855f4c4:

    # Sara "Yeah... I’m not gonna lie... I’ve been a bit nervous since you told me about the vibrator."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:105
translate chinese SR2_NS2_label_1be2c7e6:

    # MC "Oh, have you changed your mind?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:106
translate chinese SR2_NS2_label_50837a62:

    # Sara "I... I’m not sure... Maybe? I'm just imagining that you bought me some MASSIVE, black or purple, thick, scary thing..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:110
translate chinese SR2_NS2_label_97353aaa:

    # MC "How about this?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:111
translate chinese SR2_NS2_label_658cebd7:

    # Sara "Oh, my God! He’s so cute! And it’s pink! "
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:112
translate chinese SR2_NS2_label_fb294c47:

    # MC "He?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:113
translate chinese SR2_NS2_label_cf9b0733:

    # Sara "It’s a ‘he’ now!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:114
translate chinese SR2_NS2_label_4e0e60a5:

    # MC "Well? How about you try ‘him’ out now?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:118
translate chinese SR2_NS2_label_11086434:

    # Sara "Can I do you first? I need to get myself ‘warmed up’."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:119
translate chinese SR2_NS2_label_64d70477:

    # Sara "Helping you get off, will DEFINITELY do the trick for me."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:120
translate chinese SR2_NS2_label_ef0cd9d6:

    # MC "Well, if you’re sure!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:124
translate chinese SR2_NS2_label_fdc92fc5:

    # Sara "Help me get my bra off now."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:125
translate chinese SR2_NS2_label_d9bcce83:

    # MC "(Oh shit... These things are a bloody nightmare to get unclasped!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:126
translate chinese SR2_NS2_label_ffb6c97f:

    # MC "(Maybe I could just slip it off her shoulders?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:130
translate chinese SR2_NS2_label_e60db7c2:

    # MC "(Aha! It’s working! I was worried I might have to spend ages, fiddling with that bloody clasp!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:131
translate chinese SR2_NS2_label_6462b638:

    # Sara "(Why isn’t he unhooking it? Does he not know how to remove a bra?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:132
translate chinese SR2_NS2_label_b6484a1c:

    # Sara "[player_name]?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:136
translate chinese SR2_NS2_label_52a14a98:

    # MC "Yeah, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:137
translate chinese SR2_NS2_label_671e9fb1:

    # Sara "Why are you taking my bra off like that? You CAN unhook a bra, right?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:138
translate chinese SR2_NS2_label_6f2ba128:

    # MC "(Fuck, she’s onto me!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:139
translate chinese SR2_NS2_label_d11e198c:

    # MC "Y-Yeah! I thought it would be... um... sexier this way!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:144
translate chinese SR2_NS2_label_26a0df45:

    # Sara "Aww, that’s sweet. Hehe..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:145
translate chinese SR2_NS2_label_904bc586:

    # Sara "So, you choose first, [player_name]. What would you like me to do?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:146
translate chinese SR2_NS2_label_87df04cc:

    # Sara "I can use my mouth again to suck you off, or I could do something else, if you have any ideas?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:147
translate chinese SR2_NS2_label_9881d691:

    # Sara "I’m still not feeling ready to use my pussy yet."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:156
translate chinese SR2_NS2_label_a07b977c:

    # MC "You give REALLY good blowjobs. Could I maybe get you to give me another one?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:157
translate chinese SR2_NS2_label_a6f6bcb3:

    # Sara "Sure! Lie back on the bed!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:161
translate chinese SR2_NS2_label_2dbd26be:

    # Sara "I’m gonna try even harder this time!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:162
translate chinese SR2_NS2_label_24ffa1d3:

    # MC "(This is gonna be great!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:163
translate chinese SR2_NS2_label_4b17d542:

    # Sara "I hope you’re ready!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:168
translate chinese SR2_NS2_label_8623c3b2:

    # Sara "Ooh..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:169
translate chinese SR2_NS2_label_cbc9fb3c:

    # Sara "(Wow! He’s already so hard...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:170
translate chinese SR2_NS2_label_053f3a58:

    # Sara "(I forgot how thick and large his cock was...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:174
translate chinese SR2_NS2_label_b1855829:

    # MC "See something you like there, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:175
translate chinese SR2_NS2_label_8b1f2dfe:

    # Sara "Ah... It’s so... big. And you’re already hard!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:176
translate chinese SR2_NS2_label_bb080f88:

    # MC "Of course I am! I got to see your tits, after all!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:180
translate chinese SR2_NS2_label_41a50fb2:

    # Sara "Huh, I guess so."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:181
translate chinese SR2_NS2_label_da2f9667:

    # Sara "How does it feel when I touch the tip, with my finger, like this?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:182
translate chinese SR2_NS2_label_b95a1bb9:

    # MC "Mmm... It’s really intense and sensitive."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:183
translate chinese SR2_NS2_label_bc38314a:

    # Sara "In a good way?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:184
translate chinese SR2_NS2_label_3b3e5e28:

    # MC "Yeah, in a good way."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:185
translate chinese SR2_NS2_label_2ecdc6fa:

    # Sara "So, it would be REALLY good if I used my tongue to lick the tip?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:186
translate chinese SR2_NS2_label_b2d271a6:

    # MC "Ooooh, yeah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:190
translate chinese SR2_NS2_label_fa162b4b:

    # Sara "*Lick*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:191
translate chinese SR2_NS2_label_bc18cec7:

    # MC "Ah... That’s good, Sara. Just like that."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:192
translate chinese SR2_NS2_label_39405adb:

    # MC "(Damn, that feels incredible. She’s dragging her tongue so slowly across my glans.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:196
translate chinese SR2_NS2_label_41829f32:

    # Sara "(I can feel his cock twitching under my tongue. He must be enjoying this!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:197
translate chinese SR2_NS2_label_f0113c94:

    # Sara "(And it tastes like, some precum is already leaking out.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:198
translate chinese SR2_NS2_label_b7df96f1:

    # Sara "(I wonder how long I can lick his cock, before he begs me to start sucking on it?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:199
translate chinese SR2_NS2_label_a6b14193:

    # Sara "*Lick Lick*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:200
translate chinese SR2_NS2_label_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:204
translate chinese SR2_NS2_label_7325117e:

    # MC "(Damn, she’s teasing me with that tongue of hers!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:205
translate chinese SR2_NS2_label_14c0fb23:

    # Sara "*Lick Lick Lick*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:206
translate chinese SR2_NS2_label_db075c33:

    # MC "Fuck... Mmm! Can you start sucking?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:210
translate chinese SR2_NS2_label_0db585d9:

    # Sara "(Hehe! Not long, it seems!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:211
translate chinese SR2_NS2_label_aeae41f2:

    # Sara "*Shlluuurrrrp*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:212
translate chinese SR2_NS2_label_d41cbd9a:

    # MC "Ahh... God..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:213
translate chinese SR2_NS2_label_151de0f7:

    # MC "(Her mouth is so hot and wet, around my cock!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:217
translate chinese SR2_NS2_label_c4cc7adf:

    # MC "That was amazing, Sara. Can we switch positions though?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:218
translate chinese SR2_NS2_label_e63b8dda:

    # Sara "Where do you want me to go?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:219
translate chinese SR2_NS2_label_b6c87807:

    # MC "You just lie, face-down, on the bed. I’ll stand at the end."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:220
translate chinese SR2_NS2_label_eaecc795:

    # Sara "Okay."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:224
translate chinese SR2_NS2_label_d870eda2:

    # Sara "Like this?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:225
translate chinese SR2_NS2_label_13b47032:

    # MC "That’s perfect."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:226
translate chinese SR2_NS2_label_3bf5ed17:

    # Sara "Why did you want to swap around?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:230
translate chinese SR2_NS2_label_723085c0:

    # MC "From this angle, I can thrust my hips forward into your mouth."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:231
translate chinese SR2_NS2_label_da6ff1e4:

    # Sara "Okay, if you like this position more... Just don't do it harshly."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:232
translate chinese SR2_NS2_label_d4a79109:

    # MC "Don't worry, I won't. I promise."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:233
translate chinese SR2_NS2_label_04d7b16c:

    # Sara "Then put him ins-"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:237
translate chinese SR2_NS2_label_034608ce:

    # Sara "Mppfff!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:239
translate chinese SR2_NS2_label_500185e9:

    # MC "Ohhh, that’s good."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:240
translate chinese SR2_NS2_label_b09b2211:

    # Sara "(His cock, is so thick and long! There’s no way I’ll be able to take more than half of it in my mouth!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:244
translate chinese SR2_NS2_label_bf59c8f0:

    # MC "Mmm...Fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:245
translate chinese SR2_NS2_label_817b7bc5:

    # Sara "*Shluurrrrp*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:246
translate chinese SR2_NS2_label_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:250
translate chinese SR2_NS2_label_c49a1914:

    # Sara "Mppffff!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:251
translate chinese SR2_NS2_label_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:253
translate chinese SR2_NS2_label_bd764ef6:

    # MC "(The feeling of her lips wrapped around my cock is unbelievably good!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:257
translate chinese SR2_NS2_label_f760525c:

    # MC "(I can’t stand it any longer! I have to feel it go deeper!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:258
translate chinese SR2_NS2_label_45ff41b1:

    # MC "(I hope she won’t mind if I put my hands on her head and push my dick, further into her mouth...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:259
translate chinese SR2_NS2_label_c50ac75f:

    # Sara "Hmm?!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:263
translate chinese SR2_NS2_label_a4ed4202:

    # Sara "Mmmpfff..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:265
translate chinese SR2_NS2_label_03c84f36:

    # Sara "(What’s he DOING with his hands on my head?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:266
translate chinese SR2_NS2_label_69f605a4:

    # Sara "(Surely he’s not going to-)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:270
translate chinese SR2_NS2_label_da149c55:

    # Sara "MPPFF!!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:271
translate chinese SR2_NS2_label_5062c951:

    # Sara "*SHLURRRRRP!*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:272
translate chinese SR2_NS2_label_9029b9da:

    # MC "Ahhhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:273
translate chinese SR2_NS2_label_af0d2e4a:

    # MC "(I can feel the first couple of inches of my cock, slipping down her wet throat!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:277
translate chinese SR2_NS2_label_9f837a7b:

    # MC "(Fuck, this is amazing! I have to do that again.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:279
translate chinese SR2_NS2_label_efde2cd1:

    # Sara "*GAG!*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:280
translate chinese SR2_NS2_label_9dd98805:

    # Sara "*Suck suck*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:284
translate chinese SR2_NS2_label_efde2cd1_1:

    # Sara "*GAG!*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:285
translate chinese SR2_NS2_label_5062c951_1:

    # Sara "*SHLURRRRRP!*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:287
translate chinese SR2_NS2_label_b067cce8:

    # MC "(Her throat is so fucking tight! I can feel it grasping at my dick each time her gag reflex kicks in!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:288
translate chinese SR2_NS2_label_8b68eda4:

    # MC "Hnnng! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:289
translate chinese SR2_NS2_label_00a9a5c2:

    # Sara "(Wait - is he going to cum inside my mouth again!?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:298
translate chinese SR2_NS2_label_c422e9da:

    # MC "Hnnng! Oh yeah! Fuck! Ahhh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:299
translate chinese SR2_NS2_label_80e79660:

    # MC "Right there! Yes! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:300
translate chinese SR2_NS2_label_ee66c4f7:

    # Sara "(There’s so much! I can taste his salty semen, flooding over my tongue!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:304
translate chinese SR2_NS2_label_8769f689:

    # MC "That was amazing, Sara... *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:305
translate chinese SR2_NS2_label_98cb2d89:

    # Sara "(Should I swallow it again, like last time?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:306
translate chinese SR2_NS2_label_f21628b5:

    # Sara "(I guess that would really make him happy.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:310
translate chinese SR2_NS2_label_0c92c745:

    # MC "Are you okay there, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:311
translate chinese SR2_NS2_label_b068b0c8:

    # MC "Oh! Do you need me to get you a tissue, to spit it out in?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:312
translate chinese SR2_NS2_label_51190ce8:

    # Sara "(There’s so much... but it will make him so happy if I can swallow it.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:316
translate chinese SR2_NS2_label_a022173a:

    # MC "Sara, you don’t have to try and swallow it. Let me get your a tissue and you can-"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:317
translate chinese SR2_NS2_label_152e3a83:

    # Sara "*GULP*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:318
translate chinese SR2_NS2_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:322
translate chinese SR2_NS2_label_442fb9b2:

    # Sara "Aaaah...."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:323
translate chinese SR2_NS2_label_16b20f73:

    # Sara "All gone. Hehe..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:324
translate chinese SR2_NS2_label_670e5753:

    # Sara "Sorry, there was so much that it was really difficult to swallow. You know the way you sometimes take too big a drink and it gets stuck in your mouth?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:325
translate chinese SR2_NS2_label_a5c4ffdb:

    # MC "Haha, I know. Thanks, Sara. That blowjob was incredible."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:326
translate chinese SR2_NS2_label_9ca4b36f:

    # Sara "I’m glad you liked it."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:332
translate chinese SR2_NS2_label_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:333
translate chinese SR2_NS2_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:334
translate chinese SR2_NS2_label_002ba9e3:

    # Sara "(I love you so much, [player_name]... You’re the best thing to ever happen to me, in my life.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:345
translate chinese SR2_NS2_label_cf150844:

    # MC "How about we try a footjob? Did try it before with anyone?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:346
translate chinese SR2_NS2_label_16ae4295:

    # Sara "A footjob? In porn, women used only their feet right? I didn't know you like that."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:347
translate chinese SR2_NS2_label_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:348
translate chinese SR2_NS2_label_d8d4cbc0:

    # Sara " I... think I can work it out, but could you maybe give me some pointers to get me started?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:349
translate chinese SR2_NS2_label_33bf2d96:

    # MC "Sure. Lie face-up, on the bed with your legs spread."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:353
translate chinese SR2_NS2_label_d870eda2_1:

    # Sara "Like this?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:354
translate chinese SR2_NS2_label_ced3ea5e:

    # MC "That’s perfect, Sara. I’ll show you what to do next."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:355
translate chinese SR2_NS2_label_12a1fba7:

    # MC "(Her breasts are fucking perfect! Plus, I’ve got a great angle to view them when she’s lying down like this.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:359
translate chinese SR2_NS2_label_33cb8ad6:

    # MC "Okay, bring your feet up to my cock and try to massage it."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:360
translate chinese SR2_NS2_label_e7a84572:

    # Sara "Okay... Got it!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:362
translate chinese SR2_NS2_label_1f230ba5:

    # MC "Try not to use too much force, or you might hurt me."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:363
translate chinese SR2_NS2_label_d45d466f:

    # Sara "I’ll be careful!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:367
translate chinese SR2_NS2_label_0e0dd0d6:

    # Sara "How’s this? Am I being gentle enough?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:368
translate chinese SR2_NS2_label_9987ed5f:

    # MC "Yeah, that’s really good, Sara. You’re doing great."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:369
translate chinese SR2_NS2_label_a497d6bb:

    # MC "(Her feet are so cute!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:370
translate chinese SR2_NS2_label_65f49b92:

    # MC "Can you place your feet, either side of my cock and move them back and forth?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:374
translate chinese SR2_NS2_label_2229efde:

    # Sara "Just like this?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:376
translate chinese SR2_NS2_label_a64d101c:

    # MC "Yeah, like that. Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:377
translate chinese SR2_NS2_label_90ee3a1b:

    # Sara "How does that feel?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:381
translate chinese SR2_NS2_label_fdb98d2c:

    # MC "Ahh... It’s... kind of like a handjob, but if you’re really into feet, like I am, then it’s sooo much more erotic."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:382
translate chinese SR2_NS2_label_648f2c40:

    # Sara "Really? Wow..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:383
translate chinese SR2_NS2_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:384
translate chinese SR2_NS2_label_4188d866:

    # Sara "Do I need to go faster?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:388
translate chinese SR2_NS2_label_65149a2a:

    # MC "That’s perfect, just like that."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:389
translate chinese SR2_NS2_label_ebfe8a82:

    # Sara "It feels kinda strange, but I’m glad you like it."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:390
translate chinese SR2_NS2_label_ca9c5ce1:

    # Sara "How about if I try something like... this!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:394
translate chinese SR2_NS2_label_da7a2c09:

    # MC "Ohhh! Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:396
translate chinese SR2_NS2_label_584910da:

    # Sara "Hehe! That sounds like it worked well!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:397
translate chinese SR2_NS2_label_352e5e46:

    # Sara "(His cock is twitching against the sole of my foot! It must be REALLY sensitive when I do this!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:401
translate chinese SR2_NS2_label_1459637d:

    # MC "Ugh! Ahh... Fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:402
translate chinese SR2_NS2_label_32c9440d:

    # MC "(Damn, this is making me soooo horny! I wish I could just rip her panties off and fuck her RIGHT NOW!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:406
translate chinese SR2_NS2_label_39ceb7f6:

    # MC "(I’d just lean forward, grab the elastic waistband, and tear them off.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:407
translate chinese SR2_NS2_label_baf03df0:

    # MC "(Then, I’d thrust my hips down and plunge my cock into her wet pussy.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:408
translate chinese SR2_NS2_label_e589f1c5:

    # MC "(She wouldn’t be able to resist the pleasure, once my cock was buried deep inside her.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:412
translate chinese SR2_NS2_label_7e0b55ad:

    # MC "(It looks so inviting... but I have to hold myself back. She said she wasn’t ready for that yet...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:413
translate chinese SR2_NS2_label_a4e84f9b:

    # Sara "Are you okay, [player_name]? You’ve gone quiet?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:414
translate chinese SR2_NS2_label_774fc5c4:

    # MC "Y-Yeah, I’m just enjoying how good it feels."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:418
translate chinese SR2_NS2_label_793716b7:

    # Sara "A-Are you looking at my panties?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:419
translate chinese SR2_NS2_label_17946bf8:

    # Sara "You really want to fuck me... don’t you?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:420
translate chinese SR2_NS2_label_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:424
translate chinese SR2_NS2_label_43bb6aea:

    # Sara "[player_name]? Are you thinking about trying to fuck me?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:425
translate chinese SR2_NS2_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:426
translate chinese SR2_NS2_label_9c125eb0:

    # MC "(Dammit! I can’t resist much longer. I’m gonna have to cum quickly!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:430
translate chinese SR2_NS2_label_1207ee4a:

    # Sara "Eek!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:431
translate chinese SR2_NS2_label_c9b49bc5:

    # MC "Move your feet faster, Sara! Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:433
translate chinese SR2_NS2_label_a919febb:

    # MC "Rub my cock as quickly as you can! Ah! Ooohh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:437
translate chinese SR2_NS2_label_5ce79554:

    # Sara "*Pant* I am! Ah... Ah..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:438
translate chinese SR2_NS2_label_7e88aaca:

    # MC "Mmm! Yes! Just like that! Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:439
translate chinese SR2_NS2_label_a2b51f0a:

    # MC "(Dammit, I want to feel my dick inside her body, so badly right now.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:443
translate chinese SR2_NS2_label_e48ea915:

    # MC "Yes! Ugh! AHH! Fuck!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:444
translate chinese SR2_NS2_label_8c4668ae:

    # MC "I’m gonna cum soon, Sara!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:445
translate chinese SR2_NS2_label_2bc94467:

    # Sara "*Pant Pant*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:449
translate chinese SR2_NS2_label_0ea90eb0:

    # MC "Hnnnggggg! GAHHHHH!!!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:450
translate chinese SR2_NS2_label_80e3a37a:

    # MC "Ugh! Hnng!!!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:458
translate chinese SR2_NS2_label_17e9d1b0:

    # Sara "(Wow! He’s cumming so hard right now!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:462
translate chinese SR2_NS2_label_d2e5f241:

    # MC "Phew... That was... fucking amazing, Sara..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:463
translate chinese SR2_NS2_label_bf578e54:

    # Sara "Hehe... You enjoyed it, then?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:464
translate chinese SR2_NS2_label_2d15ae24:

    # MC "It was incredible..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:465
translate chinese SR2_NS2_label_8af2c762:

    # MC "You haven’t had an orgasm yet, though. Let me grab the vibrator and we’ll get started on your turn."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:474
translate chinese SR2_NS2_continue_f5c81c18:

    # MC "Thank you so much, Sara. That felt absolutely amazing."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:475
translate chinese SR2_NS2_continue_66f17d2b:

    # Sara "I’m really happy you enjoyed it."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:476
translate chinese SR2_NS2_continue_22f5740e:

    # MC "It’s your turn now though. Let's see if I can make you as happy as you made me."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:480
translate chinese SR2_NS2_continue_53d2a19e:

    # MC "I’ll just have to slip your panties off, first here."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:481
translate chinese SR2_NS2_continue_5b233742:

    # Sara "O-Okay... *Gulp*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:482
translate chinese SR2_NS2_continue_3826250f:

    # MC "(She still sounds a little nervous. Perhaps she’s just shy?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:486
translate chinese SR2_NS2_continue_2c563c91:

    # MC "Here we go..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:487
translate chinese SR2_NS2_continue_7320c8d5:

    # MC "If you’re uncomfortable with this, at all, Sara. Just let me know, okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:488
translate chinese SR2_NS2_continue_6bb0cf3e:

    # Sara "I will..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:492
translate chinese SR2_NS2_continue_11517c50:

    # MC "(Her breathing is getting much quicker. I’ll have to be careful not to drag this out for too long. I don’t want her getting shy, and backing out.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:493
translate chinese SR2_NS2_continue_9d67c09a:

    # Sara "(He’s gonna see my pussy again... I wonder what’s it going to feel with that new vibrator up to it?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:494
translate chinese SR2_NS2_continue_6a7e33ce:

    # Sara "(I usually shake and tremble, as he does... I hope he will like to see it.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:498
translate chinese SR2_NS2_continue_6df383f0:

    # Sara "(I hope I don’t moan as loudly as [player_name] does. It would be sooo embarrassing...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:499
translate chinese SR2_NS2_continue_58186086:

    # MC "There we go."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:500
translate chinese SR2_NS2_continue_771611be:

    # MC "Your pussy looks so beautiful, Sara."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:504
translate chinese SR2_NS2_continue_73859138:

    # Sara "Ahhh... Don’t stare at it!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:505
translate chinese SR2_NS2_continue_36104fe2:

    # MC "Oh c’mon. It’s gorgeous. What are you shy about?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:506
translate chinese SR2_NS2_continue_d1befd92:

    # Sara "It’s embarrassing when you look at it!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:510
translate chinese SR2_NS2_continue_d6f57df4:

    # MC "Sara, relax. There’s nothing to be shy about. You’ve got one of the sexiest bodies I’ve ever seen."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:511
translate chinese SR2_NS2_continue_0a5ef609:

    # Sara "P-Promise? You really mean that?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:512
translate chinese SR2_NS2_continue_6fd9d1c6:

    # MC "I do. Now lie back - it’s my turn to make you feel good."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:516
translate chinese SR2_NS2_continue_d98e715b:

    # MC "I’m gonna need you to spread your legs a little bit, so I can get the vibrator nice and close."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:517
translate chinese SR2_NS2_continue_54668e28:

    # Sara "O-Oh, sorry. I’ll do that now."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:521
translate chinese SR2_NS2_continue_21bdac43:

    # Sara "I-Is that okay?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:522
translate chinese SR2_NS2_continue_6a5147a6:

    # MC "That’s perfect. Just lie back, relax, and enjoy this. Okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:523
translate chinese SR2_NS2_continue_c0f9a610:

    # Sara "O-Okay..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:527
translate chinese SR2_NS2_continue_544e3cec:

    # MC "I’m gonna begin by lightly massaging your vulva. If it is too sensitive, or hurts at all, just let me know, and I’ll stop immediately. Okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:528
translate chinese SR2_NS2_continue_8cedc5d8:

    # Sara "O-Okay, [player_name]."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:529
translate chinese SR2_NS2_continue_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:533
translate chinese SR2_NS2_continue_2b253959:

    # Sara "Ah..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:534
translate chinese SR2_NS2_continue_7ff12af2:

    # Sara "(He can see inside me right now!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:535
translate chinese SR2_NS2_continue_2f1e5600:

    # Sara "(What if he doesn’t like how I look, and he doesn’t want to ‘date’ me anymore....)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:536
translate chinese SR2_NS2_continue_842a0530:

    # MC "You’re beautiful, Sara."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:540
translate chinese SR2_NS2_continue_ceb46acb:

    # Sara "Ooohh..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:541
translate chinese SR2_NS2_continue_cdf5bf74:

    # MC "I’m just using my fingers to check if you’re wet enough."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:542
translate chinese SR2_NS2_continue_0d962296:

    # Sara "Ahhh.... Mm hmm..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:546
translate chinese SR2_NS2_continue_05148c33:

    # MC "Okay, that’s perfect. I’ll turn the vibrator on now and start using it."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:547
translate chinese SR2_NS2_continue_81bfe500:

    # MC "If you want me to stop, just let me know, okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:548
translate chinese SR2_NS2_continue_37044cfb:

    # Sara "I... I will, [player_name]."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:552
translate chinese SR2_NS2_continue_43355176:

    # MC "I love you so much. I’m not going to do anything that will hurt you. I promise."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:553
translate chinese SR2_NS2_continue_4d30e8d9:

    # Sara "*Gulp* Thanks.. Sorry I’m so... nervous right now."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:554
translate chinese SR2_NS2_continue_8066a71e:

    # MC "You don't need to apologise."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:558
translate chinese SR2_NS2_continue_e111cfb1:

    # MC "Here we go. I’ll just push the small button here and..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:560
translate chinese SR2_NS2_continue_424ee770:

    # "*Buzzzzz*"
    ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:561
translate chinese SR2_NS2_continue_1207ee4a:

    # Sara "Eek!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:562
translate chinese SR2_NS2_continue_0faba641:

    # MC "It’s supposed to make that noise, don't worry."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:566
translate chinese SR2_NS2_continue_4f37c14f:

    # Sara "Mmm! Ah... Ohh...."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:567
translate chinese SR2_NS2_continue_bf82834c:

    # MC "(Well, it sounds like she’s enjoying it!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:568
translate chinese SR2_NS2_continue_6c6f88f6:

    # MC "(I hope the sales assistant was correct, when she told me to purchase the most powerful vibrator they had in store!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:572
translate chinese SR2_NS2_continue_0810f16f:

    # Sara "Oh... OOOHHH!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:573
translate chinese SR2_NS2_continue_8beb7353:

    # Sara "(This feels so... strange! It’s like my clitoris is burning! Ahh...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:574
translate chinese SR2_NS2_continue_60920b31:

    # Sara "Ahh! Ahhh!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:576
translate chinese SR2_NS2_continue_1a483428:

    # "*BUZZ*"
    ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:580
translate chinese SR2_NS2_continue_6661ce43:

    # MC "How is it, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:581
translate chinese SR2_NS2_continue_b9c7b28e:

    # Sara "It’s- ahh... s-sooo intense!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:582
translate chinese SR2_NS2_continue_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:583
translate chinese SR2_NS2_continue_a040be57:

    # Sara "I ahhh... d-don’t knoooohhhh!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:587
translate chinese SR2_NS2_continue_a1641d4a:

    # Sara "AHHH! AHHH! MMMMM! OOOHHHHH!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:588
translate chinese SR2_NS2_continue_c9daeffd:

    # Sara "S-Stop! OHH! STOP!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:589
translate chinese SR2_NS2_continue_77e28e52:

    # MC "(Uh oh, is something wrong?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:593
translate chinese SR2_NS2_continue_fc30ea4a:

    # MC "Are you alright, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:594
translate chinese SR2_NS2_continue_f01bb54c:

    # Sara "Y-Yeah... *Pant* It was just... so intense... *Gasp*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:595
translate chinese SR2_NS2_continue_1b350dae:

    # MC "Did you cum?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:596
translate chinese SR2_NS2_continue_107474bc:

    # Sara "Yes... But that was really powerful... I never used something that strong before."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:597
translate chinese SR2_NS2_continue_d3a14657:

    # MC "Would you like me to continue one more time?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:598
translate chinese SR2_NS2_continue_cde6ff2b:

    # Sara "Could we just cuddle instead?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:602
translate chinese SR2_NS2_continue_d75b0317:

    # MC "Of course we can. Rest your head on my chest here."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:603
translate chinese SR2_NS2_continue_93ab3e0c:

    # Sara "Thanks, [player_name]. I’m not used to something that strong... but that orgasm was really good."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:604
translate chinese SR2_NS2_continue_aad9d50b:

    # MC "You’re perfect, Sara. It’ll just take some time for you to get used to all this."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:608
translate chinese SR2_NS2_continue_b69d9b50:

    # MC "I’ll leave the vibrator with you. You can use it anytime you want."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:609
translate chinese SR2_NS2_continue_57c204a7:

    # MC "Just take things at your own pace, with what you’re comfortable with."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:610
translate chinese SR2_NS2_continue_804b11f8:

    # Sara "Are you sure?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:614
translate chinese SR2_NS2_continue_86bf3460:

    # MC "Of course, Sara. You keep the vibrator."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:616
translate chinese SR2_NS2_continue_d665ef11:

    # Sara "Thank you so much, [player_name]. I’m so lucky to have you as a brother."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:618
translate chinese SR2_NS2_continue_bf823162:

    # Sara "Thank you so much, [player_name]. I’m so lucky to have you in my life."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:619
translate chinese SR2_NS2_continue_6652fdf4:

    # MC "Goodnight, Sara."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:621
translate chinese SR2_NS2_continue_f9bf3479:

    # Sara "I love you, [player_name]. I better sneak back to my room before I fall asleep, and Mom catches me in the morning!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:623
translate chinese SR2_NS2_continue_43e83217:

    # Sara "I love you. I better go back to my room. I have something to study in the morning."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS2.rpy:624
translate chinese SR2_NS2_continue_ee9cf9a2:

    # MC "I love you too, Sara. I’ll see you tomorrow."
    MC ""

