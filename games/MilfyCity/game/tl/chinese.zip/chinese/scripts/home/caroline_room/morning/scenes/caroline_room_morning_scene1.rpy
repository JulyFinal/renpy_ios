﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:13
translate chinese caroline_room_morning_scene1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:23
translate chinese caroline_room_morning_scene1_label_950012d0:

    # MC "(Caroline’s always been a caring sister.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:25
translate chinese caroline_room_morning_scene1_label_ba2e88db:

    # MC "(Caroline’s always been a caring friend.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:26
translate chinese caroline_room_morning_scene1_label_7346d193:

    # MC "(We’ve known each other for YEARS! Caroline was the one who recommended I move in when Linda had another room available for renting. In fact, one of my earliest memories of her was when I was getting bullied back in the elementary school we both went to.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:27
translate chinese caroline_room_morning_scene1_label_7c7dffda:

    # MC "(A duo of pricks named Tom and Samson had decided to steal my lunch money - just a couple of dollars, but I refused to give it up.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:28
translate chinese caroline_room_morning_scene1_label_1f48fda4:

    # MC "(I remember looking up at them as I was curled up on the gravel. The cruel sound of their laughter echoing above me.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:29
translate chinese caroline_room_morning_scene1_label_2fb5721e:

    # MC "(Caroline was four years ahead of me in school. The bullies outnumbered her two-to-one that day, but it didn’t deter her from charging them down with her bare fists.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:30
translate chinese caroline_room_morning_scene1_label_054725b2:

    # MC "(For her trouble, she got two sets of bruised knuckles and a three week suspension.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:31
translate chinese caroline_room_morning_scene1_label_998b8bb2:

    # MC "(Tom and Samson got a three week suspension too. However, they spent their “break” in the hospital.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:35
translate chinese caroline_room_morning_scene1_label_24083200:

    # MC "Caroline, I-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:36
translate chinese caroline_room_morning_scene1_label_ee717312:

    # MC "(Holy shit! Look at that ass! Talk about a bubble butt!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:37
translate chinese caroline_room_morning_scene1_label_6ff38454:

    # MC "S-Sorry! I didn’t know you were changing! I should have knocked!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:40
translate chinese caroline_room_morning_scene1_label_4f47e339:

    # Caroline "Hiiiii, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:41
translate chinese caroline_room_morning_scene1_label_9a0c4dc2:

    # Caroline "Don’t sweat it, I’ve known you for years. It’s not like you’re one of those creepy guys from my college days who was just trying to get in my pants."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:42
translate chinese caroline_room_morning_scene1_label_2c3a1235:

    # MC "Uhh, yeah..."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:43
translate chinese caroline_room_morning_scene1_label_7946d612:

    # MC "(I thought her ass was good, but her breasts might even be better!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:44
translate chinese caroline_room_morning_scene1_label_2ce5db06:

    # Caroline "So, what’s up?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:45
translate chinese caroline_room_morning_scene1_label_41b63507:

    # MC "Nothing much - just came by to say hello."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:48
translate chinese caroline_room_morning_scene1_label_d033e318:

    # Caroline "Oh! Before I forget, what happened in college the other day?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:50
translate chinese caroline_room_morning_scene1_label_9b43032c:

    # Caroline "I’ve only picked up fragments of the story from Sara and Mom?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:52
translate chinese caroline_room_morning_scene1_label_abb638e0:

    # Caroline "I’ve only picked up fragments of the story from Sara and Linda."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:55
translate chinese caroline_room_morning_scene1_label_ee5c31ea:

    # MC "Eh... It wasn’t good. I asked out Ms. Celia, and got rejected."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:56
translate chinese caroline_room_morning_scene1_label_6f2f98ca:

    # Caroline "Ouch, that sounds rough. I know all too well how painful a broken heart can feel."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:57
translate chinese caroline_room_morning_scene1_label_a53b9b42:

    # MC "Oh! It’s not the broken heart that’s the bad part - she humiliated me in the middle of a busy corridor."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:58
translate chinese caroline_room_morning_scene1_label_21b7b00e:

    # Caroline "Oh God... [player_name]... I’m so sorry."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:61
translate chinese caroline_room_morning_scene1_label_888a27b0:

    # MC "Relax - it was nothing."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:62
translate chinese caroline_room_morning_scene1_label_b00479f8:

    # Caroline "Are you sure? I heard something about you getting humiliated in public?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:63
translate chinese caroline_room_morning_scene1_label_d549d063:

    # MC "Really! It wasn’t a big deal. I asked Ms. Celia out, but nothing came of it."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:64
translate chinese caroline_room_morning_scene1_label_15e50e4c:

    # Caroline "Hmm... A lot of men tend to withhold their feelings, rather than talking about their problems."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:65
translate chinese caroline_room_morning_scene1_label_edadf5ea:

    # Caroline "Make sure you take care of yourself - and if you do ever want to talk, you know my door is always open."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:68
translate chinese caroline_room_morning_scene1_label_ca93352a:

    # MC "Yeah... I’d rather not talk about this."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:69
translate chinese caroline_room_morning_scene1_label_7b1ea3a8:

    # Caroline "Oh! I’m sorry!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:70
translate chinese caroline_room_morning_scene1_label_a0f62679:

    # MC "No, it’s not your fault. You don’t need to apologise."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:71
translate chinese caroline_room_morning_scene1_label_6634bf10:

    # Caroline "Okay, just promise to take care of yourself? I heard something about Ms. Celia and you in a corridor, but I didn’t get the full details."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:72
translate chinese caroline_room_morning_scene1_label_3dfe5863:

    # MC "I... Sorry, I’d rather not think about it."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:73
translate chinese caroline_room_morning_scene1_label_d83c5754:

    # Caroline "That’s okay. If you ever change your mind, you know I’m always here to chat."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:74
translate chinese caroline_room_morning_scene1_label_ddd61152:

    # MC "Thanks, Caroline."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:79
translate chinese caroline_room_morning_scene1_after_menu_4398853d:

    # Caroline "Oh, before you go I want you to promise me something."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:80
translate chinese caroline_room_morning_scene1_after_menu_0654b1f3:

    # MC "Yes?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:81
translate chinese caroline_room_morning_scene1_after_menu_acd1a2f5:

    # Caroline "Promise you’ll come to me if you’re ever feeling stressed or down about this, won’t you?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:82
translate chinese caroline_room_morning_scene1_after_menu_fe3862fb:

    # MC "I’m gonna be fine."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:85
translate chinese caroline_room_morning_scene1_after_menu_3906ad06:

    # Caroline "I didn’t ask if you were going to be fine."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:86
translate chinese caroline_room_morning_scene1_after_menu_09ec6871:

    # Caroline "I asked you to promise me that you’ll come to me if you are feeling down."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:87
translate chinese caroline_room_morning_scene1_after_menu_8429136e:

    # MC "Fine... I promise."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:88
translate chinese caroline_room_morning_scene1_after_menu_2a4945d2:

    # Caroline "Thank you."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:91
translate chinese caroline_room_morning_scene1_after_menu_b8c84258:

    # Caroline "Catch you later, [player_name]. I need to finish getting my makeup on."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:92
translate chinese caroline_room_morning_scene1_after_menu_14a710e8:

    # MC "See ya, Caroline."
    MC ""

translate chinese strings:

    # game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:53
    old "Tell her the full truth."
    new ""

    # game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:53
    old "Play it cool."
    new ""

    # game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene1.rpy:53
    old "I’d rather not talk about it."
    new ""

