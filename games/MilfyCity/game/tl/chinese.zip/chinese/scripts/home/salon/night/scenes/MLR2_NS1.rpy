﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:39
translate chinese MLR2_NS1_label_b2197f2e:

    # MC "I wonder what they're doing."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:40
translate chinese MLR2_NS1_label_c3f3fb63:

    # MC "It's very quiet there today."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:44
translate chinese MLR2_NS1_label_96751429:

    # "*Creeeaaaak*"
    ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:46
translate chinese MLR2_NS1_label_831e2be4:

    # MC "Hmm.. They're sleeping..."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:47
translate chinese MLR2_NS1_label_18d42d10:

    # MC "I should leave. I don't want to wake up them."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:56
translate chinese MLR2_NS1_label_b2197f2e_1:

    # MC "I wonder what they're doing."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:57
translate chinese MLR2_NS1_label_c3f3fb63_1:

    # MC "It's very quiet there today."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:61
translate chinese MLR2_NS1_label_96751429_1:

    # "*Creeeaaaak*"
    ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:64
translate chinese MLR2_NS1_label_a8a028c7:

    # MC "Ah! It's only Dad."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:66
translate chinese MLR2_NS1_label_41d9f40d:

    # MC "Ah! It's only Bob."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:68
translate chinese MLR2_NS1_label_902e715f:

    # MC "I forgot! Mom is waiting for me in my bedroom!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:70
translate chinese MLR2_NS1_label_5c98f7df:

    # MC "I forgot! Linda is waiting for me in my bedroom!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:78
translate chinese MLR2_NS1_label_b2197f2e_2:

    # MC "I wonder what they're doing."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:79
translate chinese MLR2_NS1_label_c3f3fb63_2:

    # MC "It's very quiet there today."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:83
translate chinese MLR2_NS1_label_96751429_2:

    # "*Creeeaaaak*"
    ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:85
translate chinese MLR2_NS1_label_831e2be4_1:

    # MC "Hmm.. They're sleeping..."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:86
translate chinese MLR2_NS1_label_18d42d10_1:

    # MC "I should leave. I don't want to wake up them."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:99
translate chinese MLR2_NS1_label_b6463d5c:

    # MC "(I think I can hear Mom having sex. It’s fairly faint though.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:101
translate chinese MLR2_NS1_label_2dbed742:

    # MC "(I think I can hear Linda having sex. It’s fairly faint though.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:102
translate chinese MLR2_NS1_label_5ffb3fca:

    # MC "(I could risk opening the door to check.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:107
translate chinese MLR2_NS1_label_96751429_3:

    # "*Creeeaaaak*"
    ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:109
translate chinese MLR2_NS1_label_15d842c5:

    # Mom "Ohh... Ah... Ahhh..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:110
translate chinese MLR2_NS1_label_e3007f11:

    # MC "(Yeah, she’s definitely having sex right now!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:116
translate chinese MLR2_NS1_label_bce63ee5:

    # Mom "AH! Ahhh! Ahhh!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:117
translate chinese MLR2_NS1_label_34ff80e9:

    # Dad "Ugh! That’s it! I’m glad you’re enjoying this, for a change!"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:119
translate chinese MLR2_NS1_label_12f5827a:

    # MC "(For a change? Mom mustn’t enjoy sex with Dad, that much.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:121
translate chinese MLR2_NS1_label_2bf9dbae:

    # MC "(For a change? Linda mustn’t enjoy sex with Bob that much.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:125
translate chinese MLR2_NS1_label_29269ca9:

    # Mom "Ah! Ah! Yes!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:126
translate chinese MLR2_NS1_label_710c5ee1:

    # MC "(I wonder if she’s faking it?)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:127
translate chinese MLR2_NS1_label_23293ee8:

    # Mom "Harder! Faster!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:128
translate chinese MLR2_NS1_label_e8bff4ad:

    # Dad "I’m going as fast as I can right now!"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:129
translate chinese MLR2_NS1_label_af789b9f:

    # Mom "Fuck me harder, [player_name]!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:130
translate chinese MLR2_NS1_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:131
translate chinese MLR2_NS1_label_d9a1fc52:

    # MC "(Oh shit!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:135
translate chinese MLR2_NS1_label_227cbee2:

    # Dad "Wait... what?"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:136
translate chinese MLR2_NS1_label_da6d2b72:

    # Dad "Did you just call me [player_name]?"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:138
translate chinese MLR2_NS1_label_28446d0e:

    # MC "(Oh fuck... if he finds out that I’ve done stuff with Mom, he’ll kill me!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:140
translate chinese MLR2_NS1_label_adb600fa:

    # MC "(Oh fuck... if he finds out that I’ve done stuff with Linda, he’ll kill me!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:143
translate chinese MLR2_NS1_label_09082339:

    # Mom "Ugh! Why did you stop?"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:144
translate chinese MLR2_NS1_label_09c4bf15:

    # Dad "You just said-"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:145
translate chinese MLR2_NS1_label_5d466bc5:

    # Mom "God! You’re useless! I’m going to sleep now! Goodnight!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:146
translate chinese MLR2_NS1_label_e79e9422:

    # Dad "B-But I haven’t cum yet."
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:150
translate chinese MLR2_NS1_label_1eaaa7e3:

    # Mom "It’s late, and I have work to do tomorrow."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:151
translate chinese MLR2_NS1_label_7ea64848:

    # Dad "But-"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:152
translate chinese MLR2_NS1_label_a2b97f88:

    # Mom "Go and watch some porn."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:153
translate chinese MLR2_NS1_label_786ce7d9:

    # Dad "(Sigh...)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:157
translate chinese MLR2_NS1_label_1dd825f2:

    # Dad "(I could have sworn she called me [player_name].)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:159
translate chinese MLR2_NS1_label_9624e0b5:

    # Dad "(Why the heck would she be thinking about our son when we’re having sex?)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:161
translate chinese MLR2_NS1_label_10ff2075:

    # Dad "(Why the heck would she be thinking about our tenant when we’re having sex?)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:162
translate chinese MLR2_NS1_label_30e99f79:

    # Dad "(And why has she been so grumpy lately?)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS1.rpy:164
translate chinese MLR2_NS1_label_63bfb7d6:

    # Dad "(Ah well, time to boot up the laptop and search for some good old femdom hentai!)"
    Dad ""

