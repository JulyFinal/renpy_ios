﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:50
translate chinese MLR2_NS2_label_1635f365:

    # MC "*Gulp...*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:52
translate chinese MLR2_NS2_label_d8c2bb68:

    # MC "(Well, there’s Dad. I wonder where Mom is, though.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:54
translate chinese MLR2_NS2_label_f0302f28:

    # MC "(Well, there’s Bob. I wonder where Linda is, though.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:55
translate chinese MLR2_NS2_label_669b06ec:

    # MC "(Jesus, my heart’s racing right now. If he wakes up and catches me - I’m sooo dead.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:62
translate chinese MLR2_NS2_label_a273bc10:

    # Mom "Hello, Sweetie!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:63
translate chinese MLR2_NS2_label_7f4d8697:

    # MC "Ah-"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:64
translate chinese MLR2_NS2_label_2689a93f:

    # Mom "Shush! Quiet! "
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:68
translate chinese MLR2_NS2_label_f9c2077a:

    # Mom "You have to be quiet, or we’ll wake up my husband."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:69
translate chinese MLR2_NS2_label_a264fef9:

    # MC "O-Okay. You scared the shit out of me there, though!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:70
translate chinese MLR2_NS2_label_94c21d29:

    # MC "Could you not have just lied on the bed, waiting for me? "
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:74
translate chinese MLR2_NS2_label_bc13d24c:

    # Mom "I didn’t want to risk, falling asleep and missing your visit."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:76
translate chinese MLR2_NS2_label_f4b5b47f:

    # Mom "Besides, If I got into bed, your father would have wanted to have sex with me again."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:78
translate chinese MLR2_NS2_label_8699478f:

    # Mom "Besides, if I got into bed my husband would have wanted to have sex with me again."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:79
translate chinese MLR2_NS2_label_f46b288f:

    # Mom "I just wasted time, sorting out my clothes, until he drifted off to sleep."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:83
translate chinese MLR2_NS2_label_3cf98474:

    # MC "Ahh, I see. Just one thing - Maybe next time you could tap on my shoulder or whisper my name?"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:84
translate chinese MLR2_NS2_label_335c3e4d:

    # Mom "Aww, where’s the fun in that?"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:85
translate chinese MLR2_NS2_label_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:86
translate chinese MLR2_NS2_label_2d77fa7f:

    # Mom "Now... about that promise I made..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:90
translate chinese MLR2_NS2_label_1efbec24:

    # Mom "I DID tell you that I would keep my boring husband off your back and make sure no harm ever came to you."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:92
translate chinese MLR2_NS2_label_b180f91a:

    # Mom "I DID tell you that I would keep Bob off your back and make sure no harm ever came to you."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:93
translate chinese MLR2_NS2_label_7e8db8cd:

    # Mom "HOWEVER - I want something in return."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:95
translate chinese MLR2_NS2_label_695e36bc:

    # MC "S-Sure, Mom. What are you thinking of?"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:98
translate chinese MLR2_NS2_label_515adb9f:

    # MC "S-Sure, Linda. What are you thinking of?"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:102
translate chinese MLR2_NS2_label_d4c6276c:

    # Mom "I want you to pleasure me, like my husband never could."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:103
translate chinese MLR2_NS2_label_5282eb3d:

    # Mom "You can do whatever you want - but focus on MY pleasure, not yours."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:104
translate chinese MLR2_NS2_label_4aa1c22b:

    # Mom "Do you understand?"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:106
translate chinese MLR2_NS2_label_ffd35e1f:

    # MC "Yeah, no problem, Mom."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:108
translate chinese MLR2_NS2_label_7a6223f6:

    # MC "Yeah, no problem."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:109
translate chinese MLR2_NS2_label_e0d253b6:

    # Mom "Great! Let me just get undressed here."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:114
translate chinese MLR2_NS2_label_5fceac4c:

    # MC "(Wow! She’s so fucking hot!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:115
translate chinese MLR2_NS2_label_c0211add:

    # Mom "There we go."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:116
translate chinese MLR2_NS2_label_438c8961:

    # MC "Umm... are we sneaking into MY room now?"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:117
translate chinese MLR2_NS2_label_12902d33:

    # Mom "Why would we do that?"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:119
translate chinese MLR2_NS2_label_9ed562ed:

    # MC "Because Dad is LITERALLY sleeping, right beside you."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:121
translate chinese MLR2_NS2_label_9fcdd1ee:

    # MC "Bob is LITERALLY sleeping right beside you."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:122
translate chinese MLR2_NS2_label_88731e23:

    # Dad "*Snooooreeee*"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:123
translate chinese MLR2_NS2_label_ff6f4cee:

    # Mom "But that’s HALF the fun, Sweetie!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:127
translate chinese MLR2_NS2_label_569ac33a:

    # Mom "Now, how about you get over here and start playing with my tits, before I end up falling asleep too."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:129
translate chinese MLR2_NS2_label_a730a18b:

    # MC "(I guess Mom had a little bit of an exhibitionist streak in her!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:130
translate chinese MLR2_NS2_label_5aefc8d6:

    # MC "Sure, Mom!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:132
translate chinese MLR2_NS2_label_b6af5245:

    # MC "(I guess Linda had a little bit of an exhibitionist streak in her!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:133
translate chinese MLR2_NS2_label_dec05245:

    # MC "Sure, Linda!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:137
translate chinese MLR2_NS2_label_2e259b32:

    # MC "*Mwah!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:138
translate chinese MLR2_NS2_label_6d21a26b:

    # Mom "Oooohhh...."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:140
translate chinese MLR2_NS2_label_cd7f6e60:

    # MC "*Suck Suck*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:141
translate chinese MLR2_NS2_label_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:145
translate chinese MLR2_NS2_label_375da4db:

    # Mom "Mmm... harder... yes!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:146
translate chinese MLR2_NS2_label_d732edc7:

    # MC "*SUCK SUCK!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:148
translate chinese MLR2_NS2_label_9318227b:

    # Mom "MMMM!!!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:149
translate chinese MLR2_NS2_label_daafc5cf:

    # Dad "*Snooorrreeee*"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:153
translate chinese MLR2_NS2_label_86d0df00:

    # Mom "Eeek...."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:154
translate chinese MLR2_NS2_label_47833a80:

    # Mom "Ah... Ah... AH..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:155
translate chinese MLR2_NS2_label_caaf27ab:

    # Mom "Don’t stop. Don’t stop..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:156
translate chinese MLR2_NS2_label_4d23c013:

    # Mom "Fuck, that’s good."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:160
translate chinese MLR2_NS2_label_3d1e8d2f:

    # Mom "Phew... Okay... That’s enough."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:164
translate chinese MLR2_NS2_label_ffe73db8:

    # Mom "Change of plans..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:165
translate chinese MLR2_NS2_label_718fd13a:

    # Mom "I need you down at my pussy, RIGHT NOW."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:169
translate chinese MLR2_NS2_label_66fdeac0:

    # Mom "Mmm... here we go. Hurry up!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:170
translate chinese MLR2_NS2_label_2068f6f0:

    # Mom "I’m so wet right now, I need to feel your tongue inside me!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:172
translate chinese MLR2_NS2_label_720b90d4:

    # MC "Shush - careful you don’t wake Dad!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:174
translate chinese MLR2_NS2_label_6eb80dfc:

    # MC "Shush - careful you don’t wake Bob!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:175
translate chinese MLR2_NS2_label_29bef8d4:

    # Mom "Mmm... Fuck him!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:179
translate chinese MLR2_NS2_label_8ca5f841:

    # Mom "God, I’m so hot right now. Please, start sucking on my clit. I need to feel, your hot wet mouth, clamped over it NOW!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:180
translate chinese MLR2_NS2_label_dfc1280c:

    # MC "(Wow, she really can’t hold herself back!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:181
translate chinese MLR2_NS2_label_49fe76d2:

    # MC "Okay, hold still! Just try to keep your voice down."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:185
translate chinese MLR2_NS2_label_a95c0769:

    # MC "(Let’s begin by spreading her vulva.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:187
translate chinese MLR2_NS2_label_4cb1d63d:

    # MC "(There’s her clitoris at the top there. I can either focus on that, or plunge a finger inside and go for her g-spot.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:188
translate chinese MLR2_NS2_label_102867af:

    # MC "(Let’s start with the g-spot.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:192
translate chinese MLR2_NS2_label_dc94f028:

    # Mom "Oooh..... Mmm!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:194
translate chinese MLR2_NS2_label_a3a635a2:

    # Mom "Yes... Yes, [player_name]. I love you!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:195
translate chinese MLR2_NS2_label_ffc8e3fb:

    # MC "(Sounds like I made a good choice - She’s really enjoying this!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:196
translate chinese MLR2_NS2_label_bf0171e8:

    # Mom "Deeper!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:200
translate chinese MLR2_NS2_label_152a45c2:

    # Mom "OOOHHHH!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:201
translate chinese MLR2_NS2_label_62f1feb2:

    # MC "Shush! You’re gonna wake-"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:202
translate chinese MLR2_NS2_label_e4e54e75:

    # Mom "Stir up my slutty little pussy! Ahhh! AHHHH!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:203
translate chinese MLR2_NS2_label_82f61160:

    # MC "(Damn, she’s so loud right now!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:207
translate chinese MLR2_NS2_label_3e78837f:

    # Mom "Oh yeah! Make me cum!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:208
translate chinese MLR2_NS2_label_19a65732:

    # Dad "(Snore...)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:210
translate chinese MLR2_NS2_label_f1f4c52e:

    # MC "(Thank God, Dad’s a deep sleeper!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:212
translate chinese MLR2_NS2_label_331d0b87:

    # MC "(Thank God that my Bob’s a deep sleeper!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:213
translate chinese MLR2_NS2_label_84dafd3f:

    # Dad "YAWN!"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:217
translate chinese MLR2_NS2_label_652f8bb3:

    # MC "Oh shit..."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:218
translate chinese MLR2_NS2_label_2cfbe32f:

    # Mom "(Fuck...)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:219
translate chinese MLR2_NS2_label_7c24069c:

    # Dad "(Snoooree...)"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:220
translate chinese MLR2_NS2_label_db1fd57c:

    # MC "Phew..."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:221
translate chinese MLR2_NS2_label_39f9cec1:

    # Mom "(I thought he was gonna wake up, there!)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:225
translate chinese MLR2_NS2_label_b9cd5384:

    # Mom "Did I not tell you to use your tongue?"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:226
translate chinese MLR2_NS2_label_4fb80981:

    # MC "Yeah, but-"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:227
translate chinese MLR2_NS2_label_5c25772b:

    # Mom "Get your face, pressed between my thighs, RIGHT NOW!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:231
translate chinese MLR2_NS2_label_e18bb05d:

    # Mom "Hurry! I’m so close to cumming!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:233
translate chinese MLR2_NS2_label_5d690a2e:

    # Mom "I need to feel my son’s tongue writhing and flicking deep inside my pussy!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:234
translate chinese MLR2_NS2_label_196f7126:

    # MC "(Here we go... Let’s give Mom the best cunnilingus she’s ever had!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:236
translate chinese MLR2_NS2_label_6e9959fc:

    # Mom " I need to feel your tongue writhing and flicking deep inside my pussy!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:237
translate chinese MLR2_NS2_label_289843ef:

    # MC "(Here we go... Let’s give Linda the best cunnilingus she’s ever had!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:241
translate chinese MLR2_NS2_label_08dac948:

    # Mom "Ahh! Yes!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:243
translate chinese MLR2_NS2_label_1c40ba1b:

    # MC "*Lick! Slurp!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:245
translate chinese MLR2_NS2_label_67f21d80:

    # Mom "Right there! Don’t stop! Ah!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:249
translate chinese MLR2_NS2_label_233ff878:

    # MC "*Suck! Lick! Shlurp!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:250
translate chinese MLR2_NS2_label_174e0fa7:

    # Mom "AHHH! Holy fuck! Ahhh! Mmmm!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:251
translate chinese MLR2_NS2_label_ffe13ab3:

    # Mom "Oh God! Oh God! Yes! Don’t stop!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:255
translate chinese MLR2_NS2_label_95b1dc34:

    # Mom "Deeper! Harder!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:256
translate chinese MLR2_NS2_label_1d3370e0:

    # Dad "*Snoooore...*"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:257
translate chinese MLR2_NS2_label_40a672d9:

    # MC "(She’s pulling my head in, right now!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:262
translate chinese MLR2_NS2_label_77346719:

    # Mom "Oh! Oh! Oh!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:263
translate chinese MLR2_NS2_label_d3acac58:

    # MC "(Her breathing has become REALLY quick and rapid! It sounds like she’s on the verge of a climax!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:264
translate chinese MLR2_NS2_label_867181d8:

    # MC "*Lick! Lick! Lick!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:268
translate chinese MLR2_NS2_label_d8aea037:

    # Mom "Ohhhhh yeeeeessssss! C-Cuummmmmiiiinnng! Eeeeeekkk!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:269
translate chinese MLR2_NS2_label_02b4da1b:

    # Mom "Ahhhhhhh! Oooohhhhh!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:271
translate chinese MLR2_NS2_label_737c79a9:

    # Mom "(My son’s hot wet tongue is making me cum!)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:273
translate chinese MLR2_NS2_label_0156d288:

    # Mom "([player_name]’s hot wet tongue is making me cum!)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:274
translate chinese MLR2_NS2_label_2767597b:

    # Mom "Hnnnnnngggggg!!! Aaaahhhh!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:278
translate chinese MLR2_NS2_label_c2e41871:

    # Mom "*Pant...*"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:279
translate chinese MLR2_NS2_label_63eba0ae:

    # Mom "*Gasp...*"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:280
translate chinese MLR2_NS2_label_73839d03:

    # Dad "*Snooorreeee...*"
    Dad ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:281
translate chinese MLR2_NS2_label_8008bb1f:

    # MC "*Lick!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:282
translate chinese MLR2_NS2_label_174e833d:

    # Mom "W-Wait... I’ve already... ahhh... cum!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:283
translate chinese MLR2_NS2_label_95f1358e:

    # MC "*Lick Lick Lick!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:287
translate chinese MLR2_NS2_label_66be4b50:

    # Mom "(Oh God! It’s soooo sensitive! Why isn’t he stopping?!)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:289
translate chinese MLR2_NS2_label_4b896cc0:

    # Mom "MMMMMM!!!!!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:290
translate chinese MLR2_NS2_label_786ce35e:

    # Mom "(It feels sooooo fucking good!)"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:294
translate chinese MLR2_NS2_label_382a8db6:

    # Mom "MMMM! MMMMMPPFFFFFF!!!"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:295
translate chinese MLR2_NS2_label_38656094:

    # MC "*LICK LICK LICK!*"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:300
translate chinese MLR2_NS2_label_7afb98bb:

    # MC "(I think I made her cum, a second time!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:302
translate chinese MLR2_NS2_label_17897f52:

    # MC "(Damn, she’s writhing and thrashing all over the bed! I’m surprised Dad hasn’t woken up!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:304
translate chinese MLR2_NS2_label_25b7e257:

    # MC "(Damn, she’s writhing and thrashing all over the bed! I’m surprised Bob hasn’t woken up!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:309
translate chinese MLR2_NS2_label_41714ad4:

    # Mom "Holy shit... that was amazing."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:310
translate chinese MLR2_NS2_label_f8b79541:

    # Mom "Where did you learn to do that?"
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:311
translate chinese MLR2_NS2_label_a87941d5:

    # MC "Honestly? This is the first time I’ve ever given cunnilingus to a girl."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:315
translate chinese MLR2_NS2_label_75ec659b:

    # Mom "Mmm... You’re a natural, then."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:316
translate chinese MLR2_NS2_label_1293240d:

    # MC "Heh! I guess so."
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:317
translate chinese MLR2_NS2_label_3a932b18:

    # Mom "That second one was the best orgasm I have ever had in my life."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:318
translate chinese MLR2_NS2_label_4541baa7:

    # Mom "I love you."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:322
translate chinese MLR2_NS2_label_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:323
translate chinese MLR2_NS2_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:327
translate chinese MLR2_NS2_label_c81a085f:

    # MC "(Was I really THAT good at giving oral sex? I never realised!)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:328
translate chinese MLR2_NS2_label_f29f1366:

    # MC "(I’ll have to remember that, in future, for other girls.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:329
translate chinese MLR2_NS2_label_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:331
translate chinese MLR2_NS2_label_bff17d01:

    # MC "(I hope I get to fuck Mom, someday soon. I can’t wait for that.)"
    MC ""

# game/scripts/home/salon/night/scenes/MLR2_NS2.rpy:333
translate chinese MLR2_NS2_label_1dc7a71f:

    # MC "(I hope I get to fuck Linda, someday soon. I can’t wait for that.)"
    MC ""

