﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:12
translate chinese CR2_MS2_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:24
translate chinese CR2_MS2_label_5cf9138b:

    # Caroline "No, you don’t understand - I NEED the money to pay the rent!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:25
translate chinese CR2_MS2_label_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:26
translate chinese CR2_MS2_label_cf0ce8dc:

    # Caroline "I can’t wait two months for an approval. I need this right now!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:27
translate chinese CR2_MS2_label_45d43dfd:

    # MC "(Shit... Sounds like things aren’t going well for Caroline, with the bank.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:31
translate chinese CR2_MS2_label_dd30d718:

    # Caroline "How can you call it a crisis loan, if it takes two months to get approved?!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:32
translate chinese CR2_MS2_label_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:33
translate chinese CR2_MS2_label_f559f81a:

    # Caroline "Ugh, fine... I don’t know how I’m going to keep my business afloat in the meantime though."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:34
translate chinese CR2_MS2_label_8743b633_2:

    # Caroline "..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:35
translate chinese CR2_MS2_label_6a7399b4:

    # MC "(She looks properly depressed right now. I should probably intervene.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:36
translate chinese CR2_MS2_label_2df5ea6b:

    # Caroline "Okay... Thanks for your time... Will you call me if anything changes?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:37
translate chinese CR2_MS2_label_0f251495:

    # Caroline "Thanks..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:41
translate chinese CR2_MS2_label_5f195c19:

    # MC "Hey Caroline, I couldn’t help overhearing the end of your conversation there.."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:42
translate chinese CR2_MS2_label_02569322:

    # Caroline "This isn’t something you need to concern yourself with."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:43
translate chinese CR2_MS2_label_92b6352c:

    # MC "I just want you to know that I’m here to help, if you need me."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:47
translate chinese CR2_MS2_label_525dbcdf:

    # Caroline "My rent is due, I have no cash on hand, and it’ll be months before the bank can approve a crisis loan! How can you possibly help?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:48
translate chinese CR2_MS2_label_f67aa33e:

    # MC "I could give you a loan myself - or even GIVE you some money, to help you get back on your feet."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:49
translate chinese CR2_MS2_label_d3aaedf8:

    # Caroline "I... uh..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:53
translate chinese CR2_MS2_label_0e1ce8c5:

    # Caroline "No. I can’t. I’m an adult now. I have to start standing on my own two feet, and fighting my own battles for a change."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:54
translate chinese CR2_MS2_label_e77a8e15:

    # MC "But, Carol-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:55
translate chinese CR2_MS2_label_617799fd:

    # Caroline "No buts about it. I have to sort this shit out on my own."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS2.rpy:59
translate chinese CR2_MS2_label_cb50874f:

    # Caroline "Thanks for your concern though. It means a lot to me."
    Caroline ""

