﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:21
translate chinese CR2_MS3_label_3012b40b:

    # MC "What’s up, Caroline? You’re looking a little worried. Is there something stressing you out?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:22
translate chinese CR2_MS3_label_5d14df2d:

    # Caroline "No - I mean, yes. There is."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:23
translate chinese CR2_MS3_label_790f09f8:

    # MC "Do you want to take a seat and we’ll talk about it?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:27
translate chinese CR2_MS3_label_c097f5b9:

    # Caroline "No, I... Do you remember that offer you made me? To give me money for my business."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:28
translate chinese CR2_MS3_label_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:30
translate chinese CR2_MS3_label_ec15df71:

    # Caroline "Does that offer still... stand? I really need two hundred, to pay rent to Mom."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:32
translate chinese CR2_MS3_label_26c2837c:

    # Caroline "Does that offer still... stand? I really need two hundred, to pay rent to Linda."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:36
translate chinese CR2_MS3_label_2f86a56f:

    # Caroline "I’m sure she wouldn’t mind me missing one month’s rent... but I don’t want her to know that my business is failing."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:43
translate chinese CR2_MS3_label_cd4c9341:

    # MC "Of course, Caroline! I have two hundred here. And don’t worry, I won’t say a word to Mom about this."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:45
translate chinese CR2_MS3_label_0fc5e1c5:

    # MC "Of course, Caroline! I have two hundred here. And don’t worry, I won’t say a word to Linda about this."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:46
translate chinese CR2_MS3_label_7fab72fd:

    # Caroline "Seriously? Y-You don’t have to do this, you know."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:48
translate chinese CR2_MS3_label_1c1e382d:

    # MC "Relax. I’m happy to help."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:50
translate chinese CR2_MS3_label_817e243f:

    # MC "Relax, you’re my best friend. I’m happy to help. "
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:54
translate chinese CR2_MS3_label_489dd1e8:

    # Caroline "Thank you so much. You have no idea, how much this means to me right now."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:55
translate chinese CR2_MS3_label_7f1531b3:

    # Caroline "I’ll be back on my feet soon. I just need a little help, to get my finances back on track."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:56
translate chinese CR2_MS3_label_7229dfe7:

    # Caroline "You’re a lifesaver, [player_name]. I mean that."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:61
translate chinese CR2_MS3_label_3f32b856:

    # MC "It’s nothing! You’d do the same for me."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:62
translate chinese CR2_MS3_label_d910f937:

    # Caroline "Thanks again! I’ll pay you back someday. I promise."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:80
translate chinese CR2_MS3_label_18f6bfe6:

    # MC "I’m so sorry, Caroline. I don’t have two hundred on me right now."
    MC ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:81
translate chinese CR2_MS3_label_7da35edd:

    # Caroline "Oh! Right... I’m so so sorry that I brought it up."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:82
translate chinese CR2_MS3_label_2b838608:

    # Caroline "I... I have to go now."
    Caroline ""

translate chinese strings:

    # game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:38
    old "{color=#00ff00}Of course! I have two hundred here.{/color}"
    new ""

    # game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:38
    old "Of course, I have two hundred here. (disabled)"
    new ""

    # game/scripts/home/mc_room/morning/scenes/CR2_MS3.rpy:38
    old "Sorry, Caroline. I’m really short on money too right now."
    new ""

