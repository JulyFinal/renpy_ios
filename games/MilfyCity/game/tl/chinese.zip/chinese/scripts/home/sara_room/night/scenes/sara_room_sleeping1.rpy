﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:17
translate chinese SR3_no_night_visit_398a94df:

    # MC "(Sara don't want to talk to me right now.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:18
translate chinese SR3_no_night_visit_4676d717:

    # MC "(I should try and resolve things with Lily first.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:28
translate chinese SR2_room_vibrator_loc_1a483428:

    # "*BUZZ*"
    ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:29
translate chinese SR2_room_vibrator_loc_5faa731b:

    # MC "(It looks like Sara is having a good time with her toy.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:49
translate chinese sis_nerdy_night_sleeping1_v1_label_ec563f31:

    # MC "Whispered Hey, Sara? Are you awake?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:51
translate chinese sis_nerdy_night_sleeping1_v1_label_2178f9d0:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:53
translate chinese sis_nerdy_night_sleeping1_v1_label_a2ec2939:

    # MC "Psst! Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:57
translate chinese sis_nerdy_night_sleeping1_v1_label_3127e802:

    # Sara "Hmm? yawn [player_name]? What time is it?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:61
translate chinese sis_nerdy_night_sleeping1_v1_label_e87cd7b0:

    # MC "It's late. I was just wondering if you hanging out. Maybe watch some TV or something?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:64
translate chinese sis_nerdy_night_sleeping1_v1_label_be649a13:

    # Sara "Hanging out?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:66
translate chinese sis_nerdy_night_sleeping1_v1_label_76dfbd77:

    # MC "Yeah! Just chilling."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:68
translate chinese sis_nerdy_night_sleeping1_v1_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:70
translate chinese sis_nerdy_night_sleeping1_v1_label_be28da94:

    # Sara "It's the middle of the night... Can we do this some other time?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:73
translate chinese sis_nerdy_night_sleeping1_v1_label_796033ab:

    # MC "Oh, sure. No problem. I'll let you get some sleep. Sorry for waking you."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:75
translate chinese sis_nerdy_night_sleeping1_v1_label_9ae376cc:

    # Sara "*Yawn* G'night, [player_name]."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:90
translate chinese sis_nerdy_night_sleeping1_v1_label_2178f9d0_1:

    # Sara "Zzz..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:91
translate chinese sis_nerdy_night_sleeping1_v1_label_84a95f96:

    # MC "Psst, Sara! Are you awake?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:92
translate chinese sis_nerdy_night_sleeping1_v1_label_2c04d20e:

    # Sara "Hmm?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:95
translate chinese sis_nerdy_night_sleeping1_v1_label_7fd5852d:

    # Sara "[player_name]? It’s not time for college yet, is it?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:96
translate chinese sis_nerdy_night_sleeping1_v1_label_390de3b9:

    # MC "Haha, no. It’s the middle of the night. I actually came in to see if you wanted to mess around."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:97
translate chinese sis_nerdy_night_sleeping1_v1_label_91c2eead:

    # Sara "Mess around?"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:100
translate chinese sis_nerdy_night_sleeping1_v1_label_13c1d45e:

    # MC "Yeah, I was thinking that you could pretend to be asleep, and I would play with your body."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:101
translate chinese sis_nerdy_night_sleeping1_v1_label_8cb8710c:

    # MC "So, what do you think?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:104
translate chinese sis_nerdy_night_sleeping1_v1_label_62ec64dd:

    # Sara "Mmm, that sounds kinda fun..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:105
translate chinese sis_nerdy_night_sleeping1_v1_label_7739382c:

    # MC "Are we good to try it now then?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:106
translate chinese sis_nerdy_night_sleeping1_v1_label_0e09a129:

    # Sara "Yeah, let’s give it a go."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:109
translate chinese sis_nerdy_night_sleeping1_v1_label_642d93a4:

    # MC "Great, just let me know what you’re comfortable with."
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:110
translate chinese sis_nerdy_night_sleeping1_v1_label_34e03f9e:

    # Sara "Cool, will do!"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:116
translate chinese sis_nerdy_night_sleeping1_v1_label_8e41974c:

    # MC "(Sara mentioned she was interested in trying out some sleep roleplay. Let’s give it a go and see if she enjoys it. I won’t go too far tonight since it’s the first time.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:117
translate chinese sis_nerdy_night_sleeping1_v1_label_3150425b:

    # MC "*Whispered* Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:118
translate chinese sis_nerdy_night_sleeping1_v1_label_5034a625:

    # Sara "(This is so exciting! I’ll lie still and let him do what he wants.)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:121
translate chinese sis_nerdy_night_sleeping1_v1_label_2e7d05c6:

    # MC "(Carefully does it... I just have to get these blankets off her first.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:122
translate chinese sis_nerdy_night_sleeping1_v1_label_7d68afd4:

    # MC "(Perfect! Wow, I thought she’d be wearing pyjamas. This makes things easier!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:123
translate chinese sis_nerdy_night_sleeping1_v1_label_cf25acd1:

    # Sara "(I knew it would be easier for him if I took my pyjamas off - I bet he wasn’t expecting that!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:124
translate chinese sis_nerdy_night_sleeping1_v1_label_302708bd:

    # MC "(Next step is getting rid of that bra!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:127
translate chinese sis_nerdy_night_sleeping1_v1_label_c7e27c79:

    # MC "(Okay, here we go.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:128
translate chinese sis_nerdy_night_sleeping1_v1_label_81e35bda:

    # Sara "*Gulp* (I don’t know if I’m ready for [player_name] to see me fully naked yet... Maybe I should give him the signal to let him know?)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:129
translate chinese sis_nerdy_night_sleeping1_v1_label_fe536815:

    # Sara "*Snore*"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:130
translate chinese sis_nerdy_night_sleeping1_v1_label_9aeb3232:

    # MC "(Uh oh... It sounds like she isn’t too comfortable with me taking her bra off.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:133
translate chinese sis_nerdy_night_sleeping1_v1_label_f3d10231:

    # MC "(At least I got to see her in her underwear! I’ll come back another time when Sara is feeling more comfortable.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:138
translate chinese sis_nerdy_night_sleeping1_v1_label_3150425b_1:

    # MC "*Whispered* Sara?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:139
translate chinese sis_nerdy_night_sleeping1_v1_label_abd287a1_1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:140
translate chinese sis_nerdy_night_sleeping1_v1_label_919f88e3:

    # MC "*Whispered* Are you asleep?"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:141
translate chinese sis_nerdy_night_sleeping1_v1_label_2e70c0e5:

    # MC "(Sounds like she’s completely asleep. If I’m careful I might be able to touch her without waking her up.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:144
translate chinese sis_nerdy_night_sleeping1_v1_label_2e7d05c6_1:

    # MC "(Carefully does it... I just have to get these blankets off her first.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:145
translate chinese sis_nerdy_night_sleeping1_v1_label_7d68afd4_1:

    # MC "(Perfect! Wow, I thought she’d be wearing pyjamas. This makes things easier!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:146
translate chinese sis_nerdy_night_sleeping1_v1_label_88403958:

    # MC "(Next step is taking off that bra!)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:149
translate chinese sis_nerdy_night_sleeping1_v1_label_c7e27c79_1:

    # MC "(Okay, here we go.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:150
translate chinese sis_nerdy_night_sleeping1_v1_label_fe536815_1:

    # Sara "*Snore*"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:151
translate chinese sis_nerdy_night_sleeping1_v1_label_1292b001:

    # MC "(Uh oh...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:152
translate chinese sis_nerdy_night_sleeping1_v1_label_49cbcc35:

    # MC "(Don’t wake up, don’t wake up...)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:155
translate chinese sis_nerdy_night_sleeping1_v1_label_90f27c26:

    # Sara "(Yawn!)"
    Sara ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:156
translate chinese sis_nerdy_night_sleeping1_v1_label_dda5b786:

    # MC "(Crap! She’s starting to come to. I better get out of here.)"
    MC ""

# game/scripts/home/sara_room/night/scenes/sara_room_sleeping1.rpy:157
translate chinese sis_nerdy_night_sleeping1_v1_label_41c34cb2:

    # MC "(At least I got to see her in her underwear!)"
    MC ""

