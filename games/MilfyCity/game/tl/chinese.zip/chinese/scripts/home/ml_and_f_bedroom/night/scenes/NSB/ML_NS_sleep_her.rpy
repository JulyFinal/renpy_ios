﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:7
translate chinese ML_NS_sleep_her_label_128e6454:

    # Mom "*Whispered* Stay there. I’m going to strip out of this lingerie."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:8
translate chinese ML_NS_sleep_her_label_0ee67630:

    # MC " *Whispered* Wait - we’re actually going to fool around in here, while he’s asleep?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:9
translate chinese ML_NS_sleep_her_label_d7058450:

    # Mom " *Whispered* Of course. You’re not a chicken, are you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:13
translate chinese ML_NS_sleep_her_label_7dc7c4f3:

    # MC "N-No, but-"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:14
translate chinese ML_NS_sleep_her_label_64ef25c2:

    # Mom " *Whispered* Then take your boxer shorts off - and follow me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:15
translate chinese ML_NS_sleep_her_label_3ccd78dd:

    # MC "(Fuck, this is such a risky idea... I should NOT have come here tonight.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:19
translate chinese ML_NS_sleep_her_label_f5d8e847:

    # MC "(Where the heck is she going now?!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:20
translate chinese ML_NS_sleep_her_label_053c5636:

    # MC " *Whispered* [Linda_name]? Get back, round here! He’ll see you!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:21
translate chinese ML_NS_sleep_her_label_7d0974cd:

    # Mom " *Whispered* Relax - he’s dead to the world."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:25
translate chinese ML_NS_sleep_her_label_685e605e:

    # Mom "*Whispered* Climb out of bed and get 'round here. We’re going to have some fun - on this side - tonight."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:26
translate chinese ML_NS_sleep_her_label_6c370d90:

    # MC "*Whispered* You want to do it IN FRONT of him?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:27
translate chinese ML_NS_sleep_her_label_e871c597:

    # Dad "*Snore*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:31
translate chinese ML_NS_sleep_her_label_0bd50621:

    # Mom "*Whispered* Yeah, I do. Just try to keep your voice down. That includes, any moaning you do. You’re a - noisy one - when you’re having fun."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:32
translate chinese ML_NS_sleep_her_label_1d1cf615:

    # MC "*Whispered* I am not!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:34
translate chinese ML_NS_sleep_her_label_c906a9c2:

    # Mom "*Whispered* Haha! I should record you some time! “Oh! Ah! Yes! Faster, Mommy!”"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:36
translate chinese ML_NS_sleep_her_label_1518c161:

    # Mom "*Whispered* Haha! I should record you some time! “Oh! Ah! Yes! Faster, Linda!”"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:37
translate chinese ML_NS_sleep_her_label_44a1299e:

    # Mom "*Whispered* Hehe... sorry - I’m just teasing you. Hurry up and take those boxer shorts off."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:41
translate chinese ML_NS_sleep_her_label_9814d223:

    # Mom "*Whispered* Wow... I keep forgetting how - big and hard - he is."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:42
translate chinese ML_NS_sleep_her_label_57491701:

    # MC "*Whispered* What are we going to do?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:43
translate chinese ML_NS_sleep_her_label_4d94b6fb:

    # Mom "*Whispered* I’m gonna suck your cock tonight. That way, only one of us needs to concentrate on being silent!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:47
translate chinese ML_NS_sleep_her_label_6a681f3a:

    # Mom "*Whispered* Oh - and I should probably mention - we obviously can’t leave, any trace of evidence, that you’ve been here."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:48
translate chinese ML_NS_sleep_her_label_bd6f25ca:

    # Mom "*Whispered* That means I’m going to have to swallow your cum. Every... single... drop..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:49
translate chinese ML_NS_sleep_her_label_7ac5e258:

    # MC "(Fuck... [Linda_name] is REALLY good at - this dirty talk.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:53
translate chinese ML_NS_sleep_her_label_8c20f667:

    # Mom "*Lick*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:54
translate chinese ML_NS_sleep_her_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:55
translate chinese ML_NS_sleep_her_label_4431b393:

    # MC "(She’s good with her tongue too! It’s gonna be a struggle, keeping my voice down, once she really gets to work.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:59
translate chinese ML_NS_sleep_her_label_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:61
translate chinese ML_NS_sleep_her_label_041f8780:

    # MC "(I wonder why she wanted to do it in front of Dad. I can think of two possible reasons?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:63
translate chinese ML_NS_sleep_her_label_451423b5:

    # MC "(I wonder why she wanted to do it in front of Bob. I can think of two possible reasons?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:64
translate chinese ML_NS_sleep_her_label_337dce13:

    # MC "(The first is, that she REALLY - gets off - on the thrill of getting caught. This one, kinda has a precedent.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:68
translate chinese ML_NS_sleep_her_label_dccabb6a:

    # MC "(There was that time when we were on a date in the restaurant, and she insisted on playing with me, under the table. We could have been noticed by, any waiter or customer who walked by.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:70
translate chinese ML_NS_sleep_her_label_7f8ce96d:

    # MC "(But that’s only one of the possibilities. The second is that, she actually despises Dad. I’m not sure why she would? He doesn't seem like a bad guy, at all.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:72
translate chinese ML_NS_sleep_her_label_6e350a05:

    # MC "(But that’s only one of the possibilities, the second is that she actually despises her husband. I’m not sure why she would. He doesn't seem like a bad guy at all.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:73
translate chinese ML_NS_sleep_her_label_f1e73f4a:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:77
translate chinese ML_NS_sleep_her_label_69d2b82b:

    # MC "(If the second reason is true, then she must be doing it, to spite or humiliate him.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:79
translate chinese ML_NS_sleep_her_label_52fc7327:

    # MC "(If things are actually that bad, then the two of them should either split up or get divorced.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:80
translate chinese ML_NS_sleep_her_label_e6f20ec0:

    # MC "(I don’t think I could ever do something like this, to someone I really loved. Which probably means - she isn’t actually in love with him anymore.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:84
translate chinese ML_NS_sleep_her_label_1440de02:

    # MC "(Damn, this is some - pretty heavy stuff - to think about, when you’re getting your cock sucked.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:86
translate chinese ML_NS_sleep_her_label_a5868d30:

    # Mom "*Shlurp*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:87
translate chinese ML_NS_sleep_her_label_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:91
translate chinese ML_NS_sleep_her_label_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:92
translate chinese ML_NS_sleep_her_label_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:93
translate chinese ML_NS_sleep_her_label_7252045e:

    # MC "(She’s bobbing her head, quicker now! It’s growing harder to keep my voice down.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:97
translate chinese ML_NS_sleep_her_label_f609ed65:

    # Mom "(Damn, I’m so fucking wet, right now. If I had any panties on, they would be drenched.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:100
translate chinese ML_NS_sleep_her_label_d4080874:

    # Mom "(If that fat oaf wasn’t in the bed tonight, I could just pin my son down, and fuck him for hours!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:102
translate chinese ML_NS_sleep_her_label_db555bc4:

    # Mom "(If that fat oaf wasn’t in the bed tonight, I could just pin [player_name] down, and fuck him for hours!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:104
translate chinese ML_NS_sleep_her_label_83afaf42:

    # Mom "*Shllluuuurrrp*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:108
translate chinese ML_NS_sleep_her_label_e871c597_1:

    # Dad "*Snore*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:110
translate chinese ML_NS_sleep_her_label_d9e17c94:

    # Mom "(Ohh... The thought of my boy’s thick cock penetrating me and filling me up, is heavenly.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:112
translate chinese ML_NS_sleep_her_label_6d697a7a:

    # Mom "(Ohh... The thought of this boy’s thick cock penetrating me and filling me up, is heavenly.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:113
translate chinese ML_NS_sleep_her_label_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:117
translate chinese ML_NS_sleep_her_label_4048d43d:

    # Mom "(There’s a small part of me that hopes, he wakes up and sees his wife, sucking another man’s- NO - A REAL man’s cock.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:119
translate chinese ML_NS_sleep_her_label_c52179c8:

    # MC "Ah... (Damn, I’m getting close...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:120
translate chinese ML_NS_sleep_her_label_bf8f3f63:

    # MC "(I hope she won’t mind, me grabbing her head, and pulling it onto my dick!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:124
translate chinese ML_NS_sleep_her_label_20933219:

    # MC "Oh yeah..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:125
translate chinese ML_NS_sleep_her_label_f65177ef:

    # Mom "Mpppffff! *Gag!*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:126
translate chinese ML_NS_sleep_her_label_365851c9:

    # MC "(Fuck, that’s good! I can feel my cock, slipping down - her tight throat!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:130
translate chinese ML_NS_sleep_her_label_f1213d25:

    # Mom "*GAG* *SPLUTTER*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:132
translate chinese ML_NS_sleep_her_label_d2a54f6a:

    # MC "Ahh... Ugh! Ohh!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:133
translate chinese ML_NS_sleep_her_label_10f7a572:

    # Dad "Zzz..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:137
translate chinese ML_NS_sleep_her_label_dee71b78:

    # MC "Fuck... I’m cumming!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:139
translate chinese ML_NS_sleep_her_label_d230d187:

    # Dad "Hmm... I don’t want to go to work yet... Zzz..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:141
translate chinese ML_NS_sleep_her_label_bb93ced6:

    # Mom "(OH, MY GOD! He’s being sooo dominant with me! This is EXACTLY what I missed, with my husband!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:143
translate chinese ML_NS_sleep_her_label_f2109fd6:

    # Mom "(OH, MY GOD! He’s being sooo dominant with me! This is EXACTLY what I missed, with Bob!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:147
translate chinese ML_NS_sleep_her_label_499bf77a:

    # MC "Hnnng! Ugh! Aaahh....."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:148
translate chinese ML_NS_sleep_her_label_523cf011:

    # Mom "*Gulp Gulp*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:149
translate chinese ML_NS_sleep_her_label_af97da5f:

    # MC "(Holy fuck... I shot it, straight down her throat!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:161
translate chinese ML_NS_sleep_her_label_597a0286:

    # Mom "*Gasp*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:162
translate chinese ML_NS_sleep_her_label_5645b9ce:

    # Mom "*Whispered* Mmm... delicious..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:163
translate chinese ML_NS_sleep_her_label_cdfaef38:

    # MC "*Whispered* Sorry. Was I too rough, there?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:167
translate chinese ML_NS_sleep_her_label_1c2e067b:

    # Mom "*Whispered* No, that was perfect. It’s been FAR too long since a guy, properly did that to me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:168
translate chinese ML_NS_sleep_her_label_ed111803:

    # MC "*Whispered* Y-You actually liked that?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:169
translate chinese ML_NS_sleep_her_label_edebded9:

    # Mom "*Whispered* Oh yeah... The thrill of not being able to breathe, the feeling of your cock, stuffed deep into my mouth, the sensation of it, pulsating against my tongue, as you climax."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:170
translate chinese ML_NS_sleep_her_label_19805076:

    # Mom "*Whispered* I’ve always loved giving deepthroats."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:175
translate chinese ML_NS_sleep_her_label_5707f568:

    # Mom "*Whispered* I hate to say it, but you better head back into your room now in case your father wakes up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:177
translate chinese ML_NS_sleep_her_label_061189a3:

    # Mom "*Whispered* I hate to say it, but you better head back into your room now, in case my husband wakes up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:178
translate chinese ML_NS_sleep_her_label_67e92333:

    # MC "*Whispered* Yeah, I suppose I should. I’ll see you tomorrow, [Linda_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_her.rpy:179
translate chinese ML_NS_sleep_her_label_8fc74fa9:

    # Mom "*Whispered* See you then, Sweetie. I love you."
    Mom ""

