﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:24
translate chinese ml_evening_bathroom_scene_v1_label_cc8ea887:

    # MC "(I already know who's there.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:36
translate chinese ml_evening_bathroom_scene_v1_label_3f984e53:

    # MC "(Just in time! It looks like Mom’s about to take a bath!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:38
translate chinese ml_evening_bathroom_scene_v1_label_19a78d69:

    # MC "(Just in time! It looks like Linda’s about to take a bath!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:39
translate chinese ml_evening_bathroom_scene_v1_label_f821f858:

    # MC "(Damn... She’s got the best pair of thighs I’ve ever seen on a woman.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:40
translate chinese ml_evening_bathroom_scene_v1_label_af09c9c5:

    # MC "(No girl in my college even comes close to that!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:44
translate chinese ml_evening_bathroom_scene_v1_label_a3a845f3:

    # MC "(I can’t help but feel this is wrong... She’s my mother and I shouldn’t be thinking these things about her.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:46
translate chinese ml_evening_bathroom_scene_v1_label_03de4843:

    # MC "(I can’t help but feel this is wrong... She’s my landlady and I shouldn’t be thinking these things about her.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:47
translate chinese ml_evening_bathroom_scene_v1_label_95052f20:

    # MC "(On the other hand, just look at that ass. It’s fucking perfect!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:48
translate chinese ml_evening_bathroom_scene_v1_label_2e961b3a:

    # MC "(I can almost see her vulva, with that tight g-string she’s wearing!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:49
translate chinese ml_evening_bathroom_scene_v1_label_8393317a:

    # MC "(Maybe tomorrow there will be a better view!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:63
translate chinese ml_evening_bathroom_scene_v1_label_bd21e2ce:

    # MC "(I’m a little late today - I hope I haven’t missed Mom getting washed!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:65
translate chinese ml_evening_bathroom_scene_v1_label_b188db31:

    # MC "(I’m a little late today - I hope I haven’t missed Linda getting washed!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:68
translate chinese ml_evening_bathroom_scene_v1_label_e6040ed7:

    # MC "(Phew! Just in time!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:69
translate chinese ml_evening_bathroom_scene_v1_label_daf64b2d:

    # MC "(And she’s naked too! Awesome!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:70
translate chinese ml_evening_bathroom_scene_v1_label_e268a361:

    # MC "(I wonder how often she works out, to get a body THAT fit.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:74
translate chinese ml_evening_bathroom_scene_v1_label_11754cb4:

    # MC "(I’d give my right arm if the girls at my college had tits like Mom’s! Those puppies are amazing!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:76
translate chinese ml_evening_bathroom_scene_v1_label_7958bc50:

    # MC "(I’d give my right arm if the girls at my college had tits like Linda’s! Those puppies are amazing!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:77
translate chinese ml_evening_bathroom_scene_v1_label_fc74f0b1:

    # MC "(I’d be so distracted in class that I’d never learn anything though. Haha!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:78
translate chinese ml_evening_bathroom_scene_v1_label_6cef5bbe:

    # MC "(Right, I better head on out of here before I get caught...)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:95
translate chinese ml_evening_bathroom_locked_scene_v1_label_cc8ea887:

    # MC "(I already know who's there.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:102
translate chinese ml_evening_bathroom_locked_scene_v1_label_19b58612:

    # MC "It’s locked! I wonder who is there...?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/ml_evening_bathroom_scene1_v1.rpy:103
translate chinese ml_evening_bathroom_locked_scene_v1_label_b6fb1a40:

    # MC "If I only had some spy camera I could use it to see through the door!"
    MC ""

