﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:66
translate chinese MLR2_MS1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:77
translate chinese MLR2_MS1_label_af0ebb08:

    # Mom "Hello again! Thanks for dropping by again, Sweetie. It’s nice to be visited by a REAL man in the morning."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:79
translate chinese MLR2_MS1_label_e1835e93:

    # Mom "Your father just rolls out of bed and goes to work. He’s probably not a morning person, but it just doesn’t feel like he’s making the effort."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:81
translate chinese MLR2_MS1_label_3b033a34:

    # Mom "My husband just rolls out of bed and goes to work. He’s probably not a morning person, but it just doesn’t feel like he’s making the effort."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:82
translate chinese MLR2_MS1_label_7ac3af11:

    # MC "Morning [Mom_name]. I’m sure Bob isn’t doing it maliciously. He’s probably just tired and dreading the thought of having to go to another day at work."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:83
translate chinese MLR2_MS1_label_ffec6614:

    # Mom "Eh, perhaps."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:87
translate chinese MLR2_MS1_label_1938f7c7:

    # MC "Are you free for a few minutes to chat?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:88
translate chinese MLR2_MS1_label_c724804a:

    # Mom "*Slurp*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:89
translate chinese MLR2_MS1_label_be858a49:

    # Mom "Uh huh!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:97
translate chinese MLR2_MS1_label_75e32846:

    # MC "Hi [Mom_name], what you up to?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:101
translate chinese MLR2_MS1_label_30f6661b:

    # Mom "Not much, just reading the morning news. What’s got you out of bed so early?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:102
translate chinese MLR2_MS1_label_80e711f0:

    # MC "I just thought I’d make a head start on the day!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:103
translate chinese MLR2_MS1_label_488b2537:

    # MC "Are you free for a chat at the minute?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:104
translate chinese MLR2_MS1_label_01b90012:

    # Mom "Sure."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:115
translate chinese MLR2_MS1_label_fd262706:

    # Mom "Good morning, Sweetie. What’s up?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:127
translate chinese MLR2_MS1_label_d76ddcf3:

    # MC "(Damn, Mom looks hot in that black lingerie.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:128
translate chinese MLR2_MS1_label_66e19db1:

    # MC "Morning, Mom! Looking good there!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:131
translate chinese MLR2_MS1_label_c54c4501:

    # MC "(Damn, Linda looks hot in that black lingerie.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:132
translate chinese MLR2_MS1_label_bbd1ac17:

    # MC "Morning, Linda! Looking good there!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:138
translate chinese MLR2_MS1_label_fd262706_1:

    # Mom "Good morning, Sweetie. What’s up?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:212
translate chinese MLR2_MS1_talk_label_cd8b282b:

    # MC "Nothing much, Mom. I just dropped by to say hello."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:214
translate chinese MLR2_MS1_talk_label_78b7f1b7:

    # MC "Nothing much. I just dropped by to say hello."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:215
translate chinese MLR2_MS1_talk_label_ba37c49e:

    # Mom "Aww, that’s kind of you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:216
translate chinese MLR2_MS1_talk_label_7bc81e89:

    # Mom "Would you like some coffee? I think there’s still some in the kettle."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:220
translate chinese MLR2_MS1_talk_label_7d6272e7:

    # MC "Nah, I’m good."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:221
translate chinese MLR2_MS1_talk_label_1b018451:

    # Mom "How are things with Sara? Are you two getting up to any adventures together?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:226
translate chinese MLR2_MS1_talk_label_e3b6593d:

    # MC "(Oh shit! There’s no way she knows that Sara and I have been dating... right?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:227
translate chinese MLR2_MS1_talk_label_3eff50ea:

    # MC "(I’ve got to think up an excuse quickly.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:228
translate chinese MLR2_MS1_talk_label_208d519c:

    # MC "Uhh... yeah, we’ve been hanging out together. I realised I didn’t really spend a whole lot of time with Sara when I was younger - so I’m trying to make up for that now."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:232
translate chinese MLR2_MS1_talk_label_90ec989b:

    # Mom "Aww, that’s sweet. I’m glad you two are getting along well."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:235
translate chinese MLR2_MS1_talk_label_d2de6b6a:

    # MC "Adventures? I wish."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:236
translate chinese MLR2_MS1_talk_label_34f5ee3c:

    # MC "It’s just been constant work in college, for both of us."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:240
translate chinese MLR2_MS1_talk_label_8f1d6de5:

    # Mom "You should think about spending more time with your younger sister. She really looks up to you, you know that?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:241
translate chinese MLR2_MS1_talk_label_14e9c043:

    # MC "I know, I know. I’m just super busy, with everything right now, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:243
translate chinese MLR2_MS1_talk_label_16d350d8:

    # Mom "You should think about spending more time with Sara. She really looks up to you, you know that?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:244
translate chinese MLR2_MS1_talk_label_993290c2:

    # MC "I know, I know. I’m just super busy, with everything right now, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:252
translate chinese MLR2_MS1_talk_label_5088591b:

    # MC "Busy, as usual, Mom?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:254
translate chinese MLR2_MS1_talk_label_efde7b18:

    # MC "Busy as usual, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:255
translate chinese MLR2_MS1_talk_label_006df4f5:

    # MC "Working from bed today, I see?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:259
translate chinese MLR2_MS1_talk_label_55b92499:

    # Mom "Haha! You caught me. Yeah, I’m just checking over our European accounts."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:260
translate chinese MLR2_MS1_talk_label_b546e83e:

    # MC "Anything interesting?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:264
translate chinese MLR2_MS1_talk_label_54dc6b09:

    # Mom "Not unless you’re fascinated by European Union internal market regulations."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:265
translate chinese MLR2_MS1_talk_label_a8f8c6f0:

    # MC "Uh... No, I can’t say I am."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:269
translate chinese MLR2_MS1_talk_label_9b18e075:

    # Mom "Speaking of being busy with work - Caroline seems up to her eyes in that store she’s opened."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:270
translate chinese MLR2_MS1_talk_label_dcbbe79a:

    # Mom "I hope you’re not distracting her too much when you visit her shop."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:273
translate chinese MLR2_MS1_talk_label_35a9ccb5:

    # MC "(Uh oh... I hope she hasn’t worked out, I’ve gotten freaky with Caroline too!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:274
translate chinese MLR2_MS1_talk_label_7cb502d2:

    # MC "I... Uh... No! No, I’m not distracting her."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:275
translate chinese MLR2_MS1_talk_label_b51b0ed0:

    # MC "If anything, she’s the one distracting me!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:279
translate chinese MLR2_MS1_talk_label_ebec889c:

    # Mom "Huh? What does that mean?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:280
translate chinese MLR2_MS1_talk_label_e470a966:

    # MC "(Fuck!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:281
translate chinese MLR2_MS1_talk_label_f2c0acb7:

    # MC "I... uh... I mean... she’s a distracting... inspiration for me, to start my... own business."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:285
translate chinese MLR2_MS1_talk_label_30ceab73:

    # Mom "Ooookay then..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:286
translate chinese MLR2_MS1_talk_label_3a1de509:

    # Mom "I guess that’s alright, as long as you aren’t bothering her too much."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:287
translate chinese MLR2_MS1_talk_label_bf2ddbc7:

    # MC "(Phew! Dodged a bullet there!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:291
translate chinese MLR2_MS1_talk_label_1cbfbb9a:

    # MC "Honestly? I’ve been too busy to really help her out that much."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:292
translate chinese MLR2_MS1_talk_label_c59840d8:

    # Mom "That’s understandable. Your studies do come first after all."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:293
translate chinese MLR2_MS1_talk_label_bb9b82a0:

    # MC "Yeah, that’s true."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:297
translate chinese MLR2_MS1_talk_label_04451da2:

    # Mom "I know you’re both busy, but do try to make time for each other."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:298
translate chinese MLR2_MS1_talk_label_3ead8965:

    # Mom "The friends you make in college will be there for you all your life."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:300
translate chinese MLR2_MS1_talk_label_724fcca3:

    # MC "Okay, Mom. I’ll keep that in mind."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:302
translate chinese MLR2_MS1_talk_label_9a0deeb6:

    # MC "Okay, Linda. I’ll keep that in mind."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:311
translate chinese MLR2_MS1_talk_label_561a7530:

    # MC "Eh, I’m alright. A little worried about Dad, to be honest."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:313
translate chinese MLR2_MS1_talk_label_163637e5:

    # MC "Eh, I’m alright. A little worried about Bob, to be honest."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:316
translate chinese MLR2_MS1_talk_label_35ff1351:

    # Mom "Worried? Did something happen? Did he say something to you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:317
translate chinese MLR2_MS1_talk_label_d308d75c:

    # MC "No! No! Not yet... I’m just worried about getting caught."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:318
translate chinese MLR2_MS1_talk_label_7b5ba90e:

    # Mom "Well, I don’t think you’ve got anything to be worried about right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:319
translate chinese MLR2_MS1_talk_label_796d9b90:

    # Mom "If we-"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:321
translate chinese MLR2_MS1_talk_label_f5f1d939:

    # "(BING! One New Email!)"
    ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:325
translate chinese MLR2_MS1_talk_label_b5b3f4d0:

    # Mom "Sorry, that’s mine. Can we talk about this later?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:327
translate chinese MLR2_MS1_talk_label_a7970906:

    # MC "Sure, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:329
translate chinese MLR2_MS1_talk_label_8d8db7f7:

    # MC "Sure, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:337
translate chinese MLR2_MS1_kiss_label_c2c11486:

    # MC "Could I kiss you, Mom?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:338
translate chinese MLR2_MS1_kiss_label_317ae84b:

    # Mom "Of course, Sweetie. You don’t have to ask, you know that?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:340
translate chinese MLR2_MS1_kiss_label_8603f553:

    # MC "Could I kiss you, Linda?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:341
translate chinese MLR2_MS1_kiss_label_7e363044:

    # Mom "Of course, honey. You don’t have to ask. You know that?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:344
translate chinese MLR2_MS1_kiss_label_69fed47a:

    # MC "I don’t?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:345
translate chinese MLR2_MS1_kiss_label_8eb2080b:

    # Mom "Not at all. I want you to kiss me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:346
translate chinese MLR2_MS1_kiss_label_ce6f282c:

    # Mom "You can do ANYTHING you want to me. If you want to touch my ass or grab my tits, just go ahead."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:347
translate chinese MLR2_MS1_kiss_label_eaec4c08:

    # Mom "Be confident and forward. I love that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:348
translate chinese MLR2_MS1_kiss_label_032a86c9:

    # MC "S-Should I not ask for permission first?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:349
translate chinese MLR2_MS1_kiss_label_1115c63c:

    # Mom "Of course you should. This is me giving you permission right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:353
translate chinese MLR2_MS1_kiss_label_0b09626f:

    # Mom "Now, shut up and kiss me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:355
translate chinese MLR2_MS1_kiss_label_a0fef378:

    # MC "(Okay, it sounds like, Mom really wants me to act more dominant in this relationship.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:357
translate chinese MLR2_MS1_kiss_label_14c75082:

    # MC "(Okay, it sounds like Linda really wants me to act more dominant in this relationship.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:359
translate chinese MLR2_MS1_kiss_label_d02cb4a5:

    # MC "(Or maybe just more confident? I've never properly dated an older woman before.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:365
translate chinese MLR2_MS1_kiss_label_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:366
translate chinese MLR2_MS1_kiss_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:367
translate chinese MLR2_MS1_kiss_label_6aa3a35b:

    # MC "(I wonder if I should be more forward, right now, and try to grab her tits or ass while we’re kissing?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:373
translate chinese MLR2_MS1_kiss_label_e6c4e30e:

    # MC "(I’ll give Mom’s tits a squeeze and see how she enjoys it.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:375
translate chinese MLR2_MS1_kiss_label_15e428e7:

    # MC "(I’ll give Linda’s tits a squeeze and see how she enjoys it.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:377
translate chinese MLR2_MS1_kiss_label_069c82bb:

    # MC "(She’s got great breasts - my poor sister Sara never inherited those genes though!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:379
translate chinese MLR2_MS1_kiss_label_5148a67b:

    # MC "(She’s got great breasts - they’re much bigger than Lily or Sara’s!!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:383
translate chinese MLR2_MS1_kiss_label_4caef33d:

    # MC "(That’s my hands resting on her breasts now. Time to give them a firm squeeze.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:385
translate chinese MLR2_MS1_kiss_label_48f4281c:

    # MC "(I’ve heard that girls have really sensitive breasts - I wonder if Mom will feel pleasure if I squeeze them while I make out with her?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:387
translate chinese MLR2_MS1_kiss_label_ec2fd585:

    # MC "(I’ve heard that girls have really sensitive breasts - I wonder if Linda will feel pleasure if I squeeze them while I make out with her?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:391
translate chinese MLR2_MS1_kiss_label_53032118:

    # Mom "Mmmmmm!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:392
translate chinese MLR2_MS1_kiss_label_cc569064:

    # MC "(Well, that answers that question!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:393
translate chinese MLR2_MS1_kiss_label_64c48d1c:

    # Mom "(Yes! It looks like he’s finally gaining a bit of confidence!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:399
translate chinese MLR2_MS1_kiss_label_0c695dff:

    # MC "(Let’s grab her ass and see how she reacts.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:400
translate chinese MLR2_MS1_kiss_label_701f439a:

    # MC "(She’s not wearing any pyjama bottoms, so I’ve got a great opportunity to feel around down there.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:404
translate chinese MLR2_MS1_kiss_label_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:405
translate chinese MLR2_MS1_kiss_label_37dc77d3:

    # MC "(Sounds like she’s enjoying that! Let’s give it a harder squeeze!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:406
translate chinese MLR2_MS1_kiss_label_4b91ba7a:

    # Mom "(Yes! It looks like he’s finally starting to understand how to treat a woman!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:410
translate chinese MLR2_MS1_kiss_label_821139db:

    # Mom "Ooohhhmmmmm!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:411
translate chinese MLR2_MS1_kiss_label_98985d81:

    # MC "(Yeah, I was bang on the money there! Grabbing her ass was the right way to go!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:417
translate chinese after_menu_MLR2_MS1_kiss_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:418
translate chinese after_menu_MLR2_MS1_kiss_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:419
translate chinese after_menu_MLR2_MS1_kiss_e6325802:

    # Mom "(Oh God... If I keep this up, I’ll lose my whole morning!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:423
translate chinese after_menu_MLR2_MS1_kiss_b5d61187:

    # Mom "O-Okay, time to stop now. Haha! I have work to do."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:424
translate chinese after_menu_MLR2_MS1_kiss_96d7ef87:

    # Mom "You can be VERY distracting, you know that?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:425
translate chinese after_menu_MLR2_MS1_kiss_ec9724a0:

    # MC "Sorry. My bad. Haha!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:426
translate chinese after_menu_MLR2_MS1_kiss_f0504c15:

    # Mom "Remember what I said, okay? You have permission to be more forward and confident with me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:427
translate chinese after_menu_MLR2_MS1_kiss_044df532:

    # Mom "Do what you want - and if you’re unsure, please ask. Healthy sexual relationships are built on openness and honesty."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:429
translate chinese after_menu_MLR2_MS1_kiss_0996df45:

    # Mom "(Some great advice from friend right there!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:431
translate chinese after_menu_MLR2_MS1_kiss_23ebf2e7:

    # Mom "(Some great great friendly advice!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:433
translate chinese after_menu_MLR2_MS1_kiss_8a4948c2:

    # MC "Okay, Mom. Thanks for letting me know."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:435
translate chinese after_menu_MLR2_MS1_kiss_61b66fdb:

    # MC "Okay, Linda. Thanks for informing me... (Did she just contradict herself? I'm pretty sure she didn't reveal anything to Bob...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:439
translate chinese after_menu_MLR2_MS1_kiss_f174ca0e:

    # Mom "By the way, could you swing by my workplace in the afternoon? There is more cleaning work for you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:440
translate chinese after_menu_MLR2_MS1_kiss_886ea994:

    # MC "Of course, I'm currently in need of money."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:456
translate chinese MLR2_MS1_Bob_label_4b73b2fd:

    # MC "Can we talk about Dad?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:458
translate chinese MLR2_MS1_Bob_label_61e9c225:

    # MC "Can we talk about Bob?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:459
translate chinese MLR2_MS1_Bob_label_d842efc0:

    # Mom "Hmm? Sure, what about him?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:460
translate chinese MLR2_MS1_Bob_label_20706adc:

    # MC "It’s about the two of you... having sex each night."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:463
translate chinese MLR2_MS1_Bob_label_b187e4e4:

    # Mom "Oh... right..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:464
translate chinese MLR2_MS1_Bob_label_1a233f72:

    # Mom "Is it making you jealous that I’m still sleeping with him?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:473
translate chinese MLR2_MS1_Bob_label_2fd42747:

    # MC "Honestly, it doesn’t bother me at all."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:477
translate chinese MLR2_MS1_Bob_label_948214f1:

    # Mom "So... it doesn’t bother you that I have sex with my husband... but you wanted to talk about it?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:479
translate chinese MLR2_MS1_Bob_label_1918224a:

    # Mom "So... it doesn’t bother you that I have sex with Bob... but you wanted to talk about it?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:480
translate chinese MLR2_MS1_Bob_label_ba75e92d:

    # MC "Uhh..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:481
translate chinese MLR2_MS1_Bob_label_a34d3c69:

    # Mom "Can you see where I’m coming from?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:482
translate chinese MLR2_MS1_Bob_label_596d224d:

    # MC "Kinda..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:486
translate chinese MLR2_MS1_Bob_label_79ab267e:

    # Mom "Anyway, you say it doesn’t bother you - but I’m not planning to have sex with him again, anytime soon."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:487
translate chinese MLR2_MS1_Bob_label_cb4a112d:

    # Mom "I don’t know if that will put your mind at ease."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:488
translate chinese MLR2_MS1_Bob_label_1f56319f:

    # MC "Really? Why?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:489
translate chinese MLR2_MS1_Bob_label_733a54af:

    # Mom "We just aren’t connecting like we used to."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:496
translate chinese MLR2_MS1_Bob_label_ad344427:

    # MC "Yeah, it’s really making me feel... I don’t know."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:497
translate chinese MLR2_MS1_Bob_label_7e336721:

    # Mom "Jealous?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:498
translate chinese MLR2_MS1_Bob_label_7930fa34:

    # MC "Yeah, I guess so."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:502
translate chinese MLR2_MS1_Bob_label_0b48d9e7:

    # Mom "Well, in that case, I can promise not to do anything for a while."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:503
translate chinese MLR2_MS1_Bob_label_e916a684:

    # Mom "But we can’t leave this as an unresolved issue forever."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:504
translate chinese MLR2_MS1_Bob_label_c9422600:

    # MC "Yeah, I understand that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:505
translate chinese MLR2_MS1_Bob_label_e1e6a1f6:

    # Mom "Good - that shows real maturity, on your part."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:511
translate chinese MLR2_MS1_Bob_label_fb3d9147:

    # MC "Honestly? It doesn’t bother me too much."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:515
translate chinese MLR2_MS1_Bob_label_35741d97:

    # Mom "Really?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:516
translate chinese MLR2_MS1_Bob_label_1ab46523:

    # MC "Maybe a little bit - but not enough to upset me, or anything."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:517
translate chinese MLR2_MS1_Bob_label_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:521
translate chinese MLR2_MS1_Bob_label_203b852e:

    # Mom "I could give you a trial run of not having sex with him, and see how you feel."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:522
translate chinese MLR2_MS1_Bob_label_06eb3328:

    # Mom "Obviously that can’t go on forever, and we’ll need to revisit it. But it might help you make up your mind about what you want."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:524
translate chinese MLR2_MS1_Bob_label_55cfdb74:

    # MC "Thanks, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:526
translate chinese MLR2_MS1_Bob_label_c0a111cf:

    # MC "Thanks, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:532
translate chinese after_menu_MLR2_MS1_Bob_label_2be57219:

    # Mom "And one last thing..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:534
translate chinese after_menu_MLR2_MS1_Bob_label_5dd91b2b:

    # Mom "How did you know I was still having sex with your father? Our relationship hasn’t been that great lately."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:536
translate chinese after_menu_MLR2_MS1_Bob_label_29ab24a2:

    # Mom "How did you know I was still having sex with Bob? Our relationship hasn’t been that great lately."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:537
translate chinese after_menu_MLR2_MS1_Bob_label_4f497db3:

    # MC "I... uh..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:538
translate chinese after_menu_MLR2_MS1_Bob_label_3f1f8f2e:

    # Mom "You haven’t been SPYING on us, have you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:539
translate chinese after_menu_MLR2_MS1_Bob_label_42f69832:

    # MC "Ah... I... um... Just an educated guess!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:543
translate chinese after_menu_MLR2_MS1_Bob_label_a882caa5:

    # Mom "Uh huh. Sure."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:553
translate chinese MLR2_MS1_Bob_Trip_label_5505843e:

    # MC "Do you remember what we talked about in the car?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:554
translate chinese MLR2_MS1_Bob_Trip_label_d315d831:

    # Mom "We talked about A LOT of things."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:557
translate chinese MLR2_MS1_Bob_Trip_label_33021b2f:

    # MC "About us spending more romantic time together, but Dad being around too much."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:559
translate chinese MLR2_MS1_Bob_Trip_label_bc44e0e9:

    # MC "About us spending more romantic time together, but Bob being around too much."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:560
translate chinese MLR2_MS1_Bob_Trip_label_1f197ba9:

    # MC "Also in that night.. Where you caught me in your room, and we did... some... things..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:561
translate chinese MLR2_MS1_Bob_Trip_label_643d6226:

    # Mom "I know... He was always around... Stopping us."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:565
translate chinese MLR2_MS1_Bob_Trip_label_d58c2ef1:

    # Mom "Come to think of it... I have an idea. Would you be able to sneak into your Dad’s workplace and check his calendar?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:567
translate chinese MLR2_MS1_Bob_Trip_label_dd45795e:

    # Mom "Come to think of it... I have an idea. Would you be able to sneak into Bob’s workplace and check his calendar?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:568
translate chinese MLR2_MS1_Bob_Trip_label_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:569
translate chinese MLR2_MS1_Bob_Trip_label_888b28f0:

    # Mom "We can find out when he goes on another of his business trips."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:570
translate chinese MLR2_MS1_Bob_Trip_label_abd42a81:

    # MC "Ahh! And then we’ll have the house to ourselves!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:574
translate chinese MLR2_MS1_Bob_Trip_label_615342ca:

    # Mom "Bingo!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:575
translate chinese MLR2_MS1_Bob_Trip_label_43b56f7c:

    # MC "Why can’t you do it?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:577
translate chinese MLR2_MS1_Bob_Trip_label_e1516892:

    # Mom "He’ll just get suspicious. When a marriage is slowly failing - things like checking your partner’s schedule become warning signs."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:579
translate chinese MLR2_MS1_Bob_Trip_label_00e244df:

    # Mom "He’ll just get suspicious. When a relationship is slowly failing - things like checking your partner’s schedule become warning signs."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:580
translate chinese MLR2_MS1_Bob_Trip_label_6c53c8c0:

    # Mom "And then, when he’s away, we’ll have this wonderful double bed to ourselves."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:581
translate chinese MLR2_MS1_Bob_Trip_label_73578dea:

    # Mom "So will you do it, Sweetie?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:582
translate chinese MLR2_MS1_Bob_Trip_label_9c4d6185:

    # MC "Of course!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:583
translate chinese MLR2_MS1_Bob_Trip_label_c9e9c7bf:

    # Mom "Perfect! Do you remember where he works?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:584
translate chinese MLR2_MS1_Bob_Trip_label_9650b822:

    # MC "That big building below the beach?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:585
translate chinese MLR2_MS1_Bob_Trip_label_8d3e3a1c:

    # Mom "Yes."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:586
translate chinese MLR2_MS1_Bob_Trip_label_f92d9af3:

    # MC "I'll take care of that. I promise."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:590
translate chinese MLR2_MS1_Bob_Trip_label_590f7250:

    # MC "(Wow! That came out of nowhere!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:591
translate chinese MLR2_MS1_Bob_Trip_label_e8321a81:

    # Mom "Mwah!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:595
translate chinese MLR2_MS1_Bob_Trip_label_f295f8d6:

    # Mom "Okay, I have to calm down and concentrate. I have work to do."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:596
translate chinese MLR2_MS1_Bob_Trip_label_2a47a374:

    # MC "I won’t distract you, then!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:597
translate chinese MLR2_MS1_Bob_Trip_label_6011118d:

    # Mom "Haha! You ALWAYS distract me, Sweetie."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:607
translate chinese MLR2_MS1_Bob_Trip2_label_0fb6ec80:

    # MC "Mom! Good news! Dad goes on a business trip soon!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:609
translate chinese MLR2_MS1_Bob_Trip2_label_83e94bfd:

    # MC "Linda! Good news! Bob goes on a business trip soon!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:610
translate chinese MLR2_MS1_Bob_Trip2_label_8f50bfc7:

    # Mom "Great! How soon?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:611
translate chinese MLR2_MS1_Bob_Trip2_label_a52ff1d9:

    # MC "This weekend!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:615
translate chinese MLR2_MS1_Bob_Trip2_label_ac33c8f8:

    # Mom "That’s brilliant! I can’t wait!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:616
translate chinese MLR2_MS1_Bob_Trip2_label_fd291e86:

    # Mom "Okay - so here’s the plan. You’re going to come around to my bedroom as soon as he leaves."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:617
translate chinese MLR2_MS1_Bob_Trip2_label_501ef1f7:

    # Mom "Then we’ll spend the night, making love in my bed!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:618
translate chinese MLR2_MS1_Bob_Trip2_label_f7ef62a6:

    # Mom "I haven’t felt this excited since I was a teenager!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:622
translate chinese MLR2_MS1_Bob_Trip2_label_6b2e7d2c:

    # MC "Should I bring you a present or a gift?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:623
translate chinese MLR2_MS1_Bob_Trip2_label_4c6b6eae:

    # Mom "Just some red wine. That would be perfect."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:627
translate chinese MLR2_MS1_Bob_Trip2_label_1b3bfa23:

    # MC "Okay, Mom. I’ll make sure to do that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:629
translate chinese MLR2_MS1_Bob_Trip2_label_8f53a81a:

    # MC "Okay, Linda. I’ll make sure to do that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:630
translate chinese MLR2_MS1_Bob_Trip2_label_6c6db5f7:

    # Mom "Yay! This is going to be the best night of my life!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:631
translate chinese MLR2_MS1_Bob_Trip2_label_f7286098:

    # MC "(Wow! I’ve never seen anyone this excited about something before! She’s like a child at Christmas!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:643
translate chinese MLR2_MS1_Cancel_label_dc67382d:

    # Mom "So, would you like me to come to your room tonight?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:649
translate chinese MLR2_MS1_Cancel_label_8dd7f9fa:

    # MC "Yes, please!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:651
translate chinese MLR2_MS1_Cancel_label_74658ac7:

    # Mom "Okay, I’ll see you tonight, Dear."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:653
translate chinese MLR2_MS1_Cancel_label_71b09cb4:

    # Mom "Okay, I’ll see you tonight, honey. "
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:665
translate chinese MLR2_MS1_Cancel_label_d16a9aed:

    # MC "Not today. I’m a bit tired, Mom."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:667
translate chinese MLR2_MS1_Cancel_label_f0fd54af:

    # MC "Not today. I’m a bit tired, Linda."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:668
translate chinese MLR2_MS1_Cancel_label_04050859:

    # Mom "Aww, that’s okay. I understand. I hope, tommorow you'll change your mind."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:679
translate chinese MLR2_R3_MS1_q1_c22cd1cd:

    # MC "Are you missing our holiday at the beach, [Mom_name]? I know I am."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:680
translate chinese MLR2_R3_MS1_q1_e48be1ab:

    # Mom "Of course I am, Sweetie. It was honestly one of the best days of my life."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:681
translate chinese MLR2_R3_MS1_q1_d2b4eef8:

    # Mom "I’d give anything to relive those memories again. Everything was just so... perfect with you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:685
translate chinese MLR2_R3_MS1_q1_88dc5437:

    # Mom "I may as well have been in Heaven, as I lay back on that golden sand."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:686
translate chinese MLR2_R3_MS1_q1_0f98fbaa:

    # Mom "It’s a strange thing to say... but I think I could have died happy, back then. I was completely content, and I’ve never felt that way in my life, before."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:687
translate chinese MLR2_R3_MS1_q1_d033a467:

    # Mom "I want to be with you, [player_name]. I want to be with you - and only you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:691
translate chinese MLR2_R3_MS1_q1_a2aa9be5:

    # MC "I wish that could be true..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:692
translate chinese MLR2_R3_MS1_q1_d6ea4baa:

    # Mom "What do you mean?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:693
translate chinese MLR2_R3_MS1_q1_adfc7f13:

    # MC "[Dad_name]’s still here. Isn’t he? You’re not gonna divorce him, I might not be as mature as you guys are, but even I can see that you’ll pick him, over me. It’s the smart choice."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:697
translate chinese MLR2_R3_MS1_q1_2015fa64:

    # Mom "[player_name], what are you talking about?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:699
translate chinese MLR2_R3_MS1_q1_1c23f58c:

    # MC "Think about it logically, [Mom_name]. He’s the breadwinner in this house, if you divorce him you’re gonna need to find a way to double your income, if we want to keep living here."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:701
translate chinese MLR2_R3_MS1_q1_3759bd2c:

    # MC "Think about it logically, Linda. He's the breadwinner in this house. If you divorce him you're gonna need to find a way to replace his income. I don't think rent from three tenants is gonna close that gap."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:702
translate chinese MLR2_R3_MS1_q1_c374d5dc:

    # MC "I mean, how close are you to even paying off the mortgage on this place?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:703
translate chinese MLR2_R3_MS1_q1_adb9ad26:

    # MC "And then there’s Sara and Caroline - they’re going to despise you if you kick [Dad_name] out. Then, when they find out I AM the reason why, they’re gonna hate my guts too."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:707
translate chinese MLR2_R3_MS1_q1_a51ff7c1:

    # Mom "[player_name], relax. We’ve almost paid off the mortgage. I think we’ve only got ten thousand dollars or something left. It’ll be gone by the end of the year."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:708
translate chinese MLR2_R3_MS1_q1_46cfc143:

    # Mom "And as for Sara and Caroline, leave that to me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:710
translate chinese MLR2_R3_MS1_q1_0e907995:

    # Mom "Besides, I haven’t ever said I’m going to divorce or kick out your father. I might not be in love with him anymore, but I wouldn’t kick him to the curb either."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:712
translate chinese MLR2_R3_MS1_q1_a0ce50f5:

    # Mom "Besides, I haven’t ever said I’m going to divorce or kick out my husband. I might not be in love with him anymore, but I wouldn’t kick him to the curb either."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:716
translate chinese MLR2_R3_MS1_q1_cb7bf6e7:

    # Mom "Try to relax, [player_name]. I’m just as nervous as you are - and truth be told, I don’t know what the future holds for any of us."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:717
translate chinese MLR2_R3_MS1_q1_1c4a53b9:

    # Mom "All I know for certain, is that my life has gotten ten times better, with you as a romantic partner. I know I’m treading on fragile ice, but I’m not willing to give you up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:718
translate chinese MLR2_R3_MS1_q1_05accc4e:

    # MC "Thanks, [Mom_name]. I love you."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:722
translate chinese MLR2_R3_MS1_q1_64b76b36:

    # Mom "That night we spent together at the beach, has played over and over in my head, on repeat."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:724
translate chinese MLR2_R3_MS1_q1_a4ec11c1:

    # Mom "I want us to be able to relax together, without having to constantly worry about your father, butting his big head in."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:726
translate chinese MLR2_R3_MS1_q1_9fd8bfd9:

    # Mom "I want us to be able to relax together, without having to constantly worry about Bob, butting his big head in."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:727
translate chinese MLR2_R3_MS1_q1_c6ccc0b7:

    # MC "Yeah, that time you threw me off the bed was a real boner killer."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:731
translate chinese MLR2_R3_MS1_q1_60b7a45e:

    # MC "I don’t remember everything that happened, since I was a little dazed, at you chucking me off the bed. I vaguely recall you tossing a pillow at [Dad_name] though. Did that happen?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:732
translate chinese MLR2_R3_MS1_q1_ca08d606:

    # Mom "Yeah, it was a panicked response. Kinda stupid, in hindsight. But it scared him off, long enough for you to get away."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:733
translate chinese MLR2_R3_MS1_q1_05aa3403:

    # MC "True."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:737
translate chinese MLR2_R3_MS1_q1_4652ef42:

    # MC "Y’know, that door has a keyhole on it. Why don’t we just lock it, in future?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:739
translate chinese MLR2_R3_MS1_q1_cbc6c627:

    # Mom "Your father has his own copy. Besides, it would only create suspicion if I started locking myself in here, by myself. Your father would probably think I’m preparing divorce papers, in secret."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:741
translate chinese MLR2_R3_MS1_q1_f444cec2:

    # Mom "Bob has his own copy. Besides, it would only create suspicion if I started locking myself in here, by myself. Bob would probably think I’m preparing divorce papers, in secret."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:742
translate chinese MLR2_R3_MS1_q1_7ee47ff7:

    # MC "Yeah... you’re right. Getting away to the beach house was definitely safer."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:746
translate chinese MLR2_R3_MS1_q1_c2b2a770:

    # Mom "I know you’re stressed about what’s going to happen to this family. All I can say is... try not to worry."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:748
translate chinese MLR2_R3_MS1_q1_d06004f3:

    # Mom "I know you’re stressed about what’s going to happen to everyone. All I can say is... try not to worry."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:749
translate chinese MLR2_R3_MS1_q1_52b1aca0:

    # Mom "Nobody can predict the future, and all we can do is try to mitigate the damages, when bad things happen."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:751
translate chinese MLR2_R3_MS1_q1_ebff3f39:

    # Mom "I have my own business, and my relationship with your father is on the rocks anyway. If he leaves, we’ll struggle in the short term. I’m like a cat, I always land on my feet."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:753
translate chinese MLR2_R3_MS1_q1_01e6c6cb:

    # Mom "I have my own business, and my relationship with Bob is on the rocks anyway. If he leaves, we’ll struggle in the short term. I’m like a cat, I always land on my feet."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:754
translate chinese MLR2_R3_MS1_q1_21b8ee7d:

    # MC "Okay, I think that’s what I needed to hear. I was kinda freaking out about this, but I’m feeling a little better now."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:755
translate chinese MLR2_R3_MS1_q1_c60be175:

    # Mom "We’ll do our best to keep our relationship hidden from everyone else, for the meantime."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:756
translate chinese MLR2_R3_MS1_q1_78bca4d6:

    # MC "Just... uh... if our goal is to keep things low-key, maybe don’t try to make me cum in a restaurant again."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:757
translate chinese MLR2_R3_MS1_q1_31821e3c:

    # Mom "Haha! Point taken... But, to be honest, your face was really sweet in that moment..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:769
translate chinese MLR2_R3_MS1_q2_f7fed9b1:

    # MC "Listen, [Mom_name]. I’m... God, this is a tough question to ask... I’m a... I’m a little worried about accidentally getting you pregnant."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:770
translate chinese MLR2_R3_MS1_q2_f01f7eaf:

    # Mom "Goodness me, that’s a heavy question for the morning."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:771
translate chinese MLR2_R3_MS1_q2_8c4ce437:

    # MC "Heh, I know. Sorry to drop that on you. There really wasn’t an easy way to raise the subject."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:772
translate chinese MLR2_R3_MS1_q2_b7679a9f:

    # MC "I was just thinking, what if we do it, some day, and... the protection doesn’t work."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:776
translate chinese MLR2_R3_MS1_q2_3a51ee02:

    # Mom "Put that out of your head, for the meantime. We’ll cross that bridge IF we come to it."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:777
translate chinese MLR2_R3_MS1_q2_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:781
translate chinese MLR2_R3_MS1_q2_ba243dfb:

    # Mom "Honey, if I don’t look worried about this topic, then you don’t need to be. Okay?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:782
translate chinese MLR2_R3_MS1_q2_5bf668f5:

    # MC "Alright, [Mom_name]. If you’re sure."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:789
translate chinese MLR2_R3_MS1_q3_a7f683a9:

    # MC "Hypothetically speaking, how would you feel about me dating another girl?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:790
translate chinese MLR2_R3_MS1_q3_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:791
translate chinese MLR2_R3_MS1_q3_a6b106f7:

    # Mom "Are you dating someone?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:792
translate chinese MLR2_R3_MS1_q3_15efa558:

    # MC "It was a hypothetical question!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:796
translate chinese MLR2_R3_MS1_q3_f1bbc178:

    # Mom "Honestly? Not too pleased at all."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:797
translate chinese MLR2_R3_MS1_q3_dd6ede8f:

    # MC "Oh, right..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:798
translate chinese MLR2_R3_MS1_q3_0b16d2d3:

    # Mom "I mean, am I not enough for you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:799
translate chinese MLR2_R3_MS1_q3_9827ae03:

    # MC "Of course you are, [Mom_name]! Sorry, it was just a hypothetical."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:807
translate chinese MLR2_R3_MS1_q4_edd1ab3d:

    # MC "When did you first develop a crush on me, [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:808
translate chinese MLR2_R3_MS1_q4_09bf53d7:

    # Mom "The first time? Hmm..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:812
translate chinese MLR2_R3_MS1_q4_39f2e98f:

    # Mom "It was probably some time ago, though I can't pinpoint the exact moment, when I began experiencing desires for you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:813
translate chinese MLR2_R3_MS1_q4_cbca6d10:

    # Mom "The romantic attraction came much later."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:814
translate chinese MLR2_R3_MS1_q4_61d3dd31:

    # MC "That must have been around the time I started renting the room from you."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:817
translate chinese MLR2_R3_MS1_q4_c3155e43:

    # Mom "At first, I spent a long time beating myself up over it. It’s hard to describe, in full, just how guilty I felt."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:819
translate chinese MLR2_R3_MS1_q4_ceebfbee:

    # Mom "I mean, what kind of mother has THOSE feelings for her own son? Do you know what I mean?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:821
translate chinese MLR2_R3_MS1_q4_0805c110:

    # Mom "I mean, I’m more than a decade older than you are. What kind of woman has THOSE kind of feelings for a man so much younger than her? Do you know what I mean?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:822
translate chinese MLR2_R3_MS1_q4_0adafcde:

    # MC "Yeah, I understand, [Mom_name]. I’m sorry you had to go through that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:826
translate chinese MLR2_R3_MS1_q4_4c7ac4d8:

    # Mom "I’m okay now! I went to a professional, back when things were bad. She helped me work through it."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:827
translate chinese MLR2_R3_MS1_q4_3745b13a:

    # MC "That’s good to hear. Are you still in therapy? If you don’t mind me asking."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:828
translate chinese MLR2_R3_MS1_q4_224bfeb2:

    # Mom "Very infrequent sessions. They used to be weekly. The guilt has almost completely gone now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:829
translate chinese MLR2_R3_MS1_q4_434b7475:

    # MC "That’s good to hear. I’m sorry I never realised this before, [Mom_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:833
translate chinese MLR2_R3_MS1_q4_cf7f3d97:

    # Mom "Shush. You don’t need to be sorry, Sweetie. It wasn’t appropriate for me to involve you in my silly romantic interests."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:834
translate chinese MLR2_R3_MS1_q4_0c8d9739:

    # Mom "Besides, I’m all better now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:838
translate chinese MLR2_R3_MS1_q4_57479e21:

    # Mom "Would you mind if we changed the topic?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:839
translate chinese MLR2_R3_MS1_q4_2bdd75a6:

    # MC "Sorry, yeah, let’s do that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:845
translate chinese MLR2_R3_MS1_q5_4e910fca:

    # MC "Okay, I’ve got another hypothetical question for you. How would you feel about me dating Sara or Caroline?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:848
translate chinese MLR2_R3_MS1_q5_511b0a3e:

    # Mom "You mean your sisters, Sara and Caroline? Not some other girls at your school named Sara or Caroline?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:849
translate chinese MLR2_R3_MS1_q5_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:852
translate chinese MLR2_R3_MS1_q5_4e4deeb6:

    # Mom "I, uh... What a weird question in the morning..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:853
translate chinese MLR2_R3_MS1_q5_3539b0a7:

    # Mom "Hmm... Maybe let’s leave that question for another occasion."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:854
translate chinese MLR2_R3_MS1_q5_3910b33b:

    # MC "Does that mean, you would be mad?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:858
translate chinese MLR2_R3_MS1_q5_ad645bc0:

    # Mom "Mad? No... More like hap- I mean, it’s not the best time to talk about it, first thing in the morning."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:859
translate chinese MLR2_R3_MS1_q5_35afa872:

    # MC "Okay. We can talk about it some other time."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:861
translate chinese MLR2_R3_MS1_q5_053111a7:

    # Mom "You mean your roommates? Not some other girls at the college named Sara or Caroline?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:862
translate chinese MLR2_R3_MS1_q5_c6707b2b:

    # MC "Yeah, my roommates."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:865
translate chinese MLR2_R3_MS1_q5_52c21848:

    # Mom "Oh, as long as it’s one of your roommates I’ve got no problem with that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:866
translate chinese MLR2_R3_MS1_q5_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:867
translate chinese MLR2_R3_MS1_q5_cfff162b:

    # Mom "Caroline and Sara are both beautiful girls. They’ve both rented from me for a few years now. They’re both good people and deserve to be with someone who appreciates them."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:868
translate chinese MLR2_R3_MS1_q5_1665d017:

    # Mom "I frequently worry about Caroline’s taste in men. I don’t know if you’re aware, but she had a rather... abusive ex."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:869
translate chinese MLR2_R3_MS1_q5_b28081e8:

    # Mom "If she was dating you, then I’d know for certain that she’d be safe at least."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:877
translate chinese MLR2_R3_MS1_q6_1796e10e:

    # MC "Umm, if you don’t mind me asking. Have you ever cheated on [Dad_name] before?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:878
translate chinese MLR2_R3_MS1_q6_3bf348e6:

    # Mom "Oh goodness, no!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:880
translate chinese MLR2_R3_MS1_q6_3afad9a4:

    # Mom "You were the first time I ever thought about cheating on your father."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:882
translate chinese MLR2_R3_MS1_q6_6c1ec4d3:

    # Mom "You were the first time I ever thought about cheating on Bob."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:883
translate chinese MLR2_R3_MS1_q6_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:887
translate chinese MLR2_R3_MS1_q6_e722562a:

    # Mom "Don't look so surprised! It took me a long time to build up to, finally attempting to kiss you!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:888
translate chinese MLR2_R3_MS1_q6_098adcd9:

    # Mom "I was holding back my emotions while living under the same roof as you. I think I did a pretty damn fine job, no?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:889
translate chinese MLR2_R3_MS1_q6_e66df5d1:

    # MC "I guess you’re right."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:896
translate chinese MLR2_R3_MS1_q7_4b76245e:

    # MC "So, what’s your favourite sex position, [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:897
translate chinese MLR2_R3_MS1_q7_b5d235e9:

    # Mom "Oh, that’s easy. Almost all of them. I like to switch things up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:898
translate chinese MLR2_R3_MS1_q7_ac474832:

    # Mom "If you ABSOLUTELY FORCED me to choose though, I think I’d have to settle for..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:902
translate chinese MLR2_R3_MS1_q7_0f3cae64:

    # Mom "...cowgirl."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:903
translate chinese MLR2_R3_MS1_q7_c3c521be:

    # Mom "I just love the sensation of being in control."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:904
translate chinese MLR2_R3_MS1_q7_4da1338f:

    # MC "Cowgirl? I think that was our first position at the beach."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:905
translate chinese MLR2_R3_MS1_q7_407385db:

    # Mom "I know, Sweetie. That’s why it was even more amazing."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:911
translate chinese MLR2_R3_MS1_q8_efde3678:

    # MC "Have you ever done anal before, [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:912
translate chinese MLR2_R3_MS1_q8_8855e0b2:

    # Mom "Haha, why do you want to know? Have you been thinking about fucking me in the ass?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:913
translate chinese MLR2_R3_MS1_q8_30535931:

    # MC "Maybe, a bit."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:917
translate chinese MLR2_R3_MS1_q8_c69bc6b5:

    # Mom "I think I’ll keep that secret a little longer."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:918
translate chinese MLR2_R3_MS1_q8_812df744:

    # Mom "Someday you’ll get to find out if I’m a “virgin” back there, but not today."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:919
translate chinese MLR2_R3_MS1_q8_0b8c0fc3:

    # MC "Aww..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:923
translate chinese MLR2_R3_MS1_q8_3f1a655f:

    # Mom "Haha! Don’t look so downhearted. It’s not like you’ll have to wait MONTHS before we advance to the next stage in our relationship."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:924
translate chinese MLR2_R3_MS1_q8_4f697225:

    # MC "Haha, true. I’d hate to have to wait months, between dates with a girl."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:925
translate chinese MLR2_R3_MS1_q8_fc36a1f7:

    # MC "Anyway, we’ve gotten off topic!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:931
translate chinese MLR2_R3_MS1_q9_bb0e3f35:

    # MC "[Mom_name], why did you lift up Sara’s skirt in the kitchen?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:935
translate chinese MLR2_R3_MS1_q9_1afd58e5:

    # Mom "Hehe, I think the question that needs to be asked here, is why were YOU looking up Sara’s skirt?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:936
translate chinese MLR2_R3_MS1_q9_dc694987:

    # MC "I... uh... I wasn’t!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:937
translate chinese MLR2_R3_MS1_q9_0d595e3a:

    # Mom "Haha! Of course you were! Nobody takes that long to pick up a can!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:941
translate chinese MLR2_R3_MS1_q9_a6922b34:

    # Mom "And... as for why I did it? Did you not enjoy the show?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:942
translate chinese MLR2_R3_MS1_q9_781545f7:

    # MC "Heh, yeah, I guess I did... but-"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:943
translate chinese MLR2_R3_MS1_q9_d170eb0d:

    # Mom "See? Everything worked out perfectly, then."
    Mom ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk with Mom.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Talk with Linda."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Ask for a kiss. {/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Ask for a kiss."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk about Dad.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk about Bob.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk about Dad.{/color} "
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk about Bob.{/color} "
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Talk about Dad. (disabled)"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Talk about Bob. (disabled)"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Are you missing our holiday at the beach? I know I am."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "What happens if I accidentally get you pregnant?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Hypothetically... how would you feel about me dating another girl?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "When did you first develop a crush on me?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "How would you feel about me dating Sara or Caroline?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Umm, if you don’t mind me asking. Have you ever cheated on [Dad_name] before?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "What’s your favourite sex position?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Have you ever done anal, [Mom_name]?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "[Mom_name], why did you lift up Sara’s skirt in the kitchen?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk about Dad trip.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "{color=#00ff00}Talk about Bob trip.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:146
    old "Bye. "
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:369
    old "Grab her tits."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:369
    old "Grab her ass."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:467
    old "No, not at all."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:467
    old "Yeah, it really does."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:467
    old "It doesn’t bother me too much."
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR2_MS1.rpy:646
    old "Not today."
    new ""

