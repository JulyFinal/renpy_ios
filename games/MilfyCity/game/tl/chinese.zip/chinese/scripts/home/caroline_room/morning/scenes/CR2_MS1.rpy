﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:18
translate chinese CR2_MS1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:31
translate chinese CR2_MS1_label_ce869105:

    # MC "(There’s Caroline with her nose buried in a book again!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:32
translate chinese CR2_MS1_label_066b9d77:

    # MC "(She always was one of the brainiest people I ever knew!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:33
translate chinese CR2_MS1_label_bfb8a867:

    # MC "Hey, Caroline! What’s up?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:37
translate chinese CR2_MS1_label_cabb22ea:

    # Caroline "Oh! Hey there, [player_name]. I didn’t hear you come in there."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:38
translate chinese CR2_MS1_label_4aefcd26:

    # MC "Haha, sorry - I’m not interrupting you, am I?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:39
translate chinese CR2_MS1_label_819ea029:

    # Caroline "Not at all. I’m just taking a break from work. Now that I’m actually turning a profit I REALLY should think about reporting my earnings to the government."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:40
translate chinese CR2_MS1_label_574a5772:

    # MC "Ugh, sounds boring!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:41
translate chinese CR2_MS1_label_aa8b0254:

    # Caroline "It REALLY is! Which is why I’m taking a well-deserved rest."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:45
translate chinese CR2_MS1_label_9335624c:

    # MC "What’s the book?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:46
translate chinese CR2_MS1_label_ff969cd2:

    # Caroline "It’s a romance novel. A girl comes to work in a factory in Detroit, but soon finds herself seduced by the muscular supervisor."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:47
translate chinese CR2_MS1_label_11c4f08e:

    # MC "It sounds like a real piece of poignant literature!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:52
translate chinese CR2_MS1_label_01910ed4:

    # Caroline "I can hear the sarcasm in your voice. It’s typical mass-produced trash, but it keeps me entertained."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:53
translate chinese CR2_MS1_label_3e64375f:

    # MC "Is there much sex it in?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:56
translate chinese CR2_MS1_label_a97dbf1b:

    # Caroline "Hehe... Trust you to ask a question like that."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:57
translate chinese CR2_MS1_label_31c055ab:

    # MC "Hey- I’m serious!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:58
translate chinese CR2_MS1_label_6855c1e8:

    # Caroline "Of course there is! It’s a romance novel after all."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:62
translate chinese CR2_MS1_label_4c1c1ddd:

    # Caroline "It even has the “Not for Children” warning on the back."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:63
translate chinese CR2_MS1_label_f2352d90:

    # Caroline "I mean, I’m on chapter eight and I’ve already seen the main character get screwed like five times."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:64
translate chinese CR2_MS1_label_e7df0fb4:

    # Caroline "And TWO of those times involved it going in her ass!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:65
translate chinese CR2_MS1_label_4b6effed:

    # MC "I never imagined chick literature was so filthy..."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:69
translate chinese CR2_MS1_label_4f1deafa:

    # Caroline "You should pick up a couple of chick-lit books some time. You might enjoy the cheap smut."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:76
translate chinese CR2_MS1_label_1fd09382:

    # MC "(I think I’ll grope her ass now. We did make that deal and Caroline owes me BIG time for all the help I gave getting her company up and running!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:77
translate chinese CR2_MS1_label_6be65b66:

    # MC "(I’m sure she won’t mind a quick squeeze. What’s the worst that could happen?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:78
translate chinese CR2_MS1_label_fb002da4:

    # MC "(Plus, she’s sitting there in her panties. She’s probably expecting it to happen... right?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:82
translate chinese CR2_MS1_label_efedbd54:

    # MC "(Soft and warm! Exactly like I imagined it would be!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:83
translate chinese CR2_MS1_label_00651386:

    # Caroline "H-Hey! What are you doing?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:84
translate chinese CR2_MS1_label_83a3a6e9:

    # MC "Remember the deal?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:88
translate chinese CR2_MS1_label_0e3a4179:

    # Caroline "Yeah, but what if Mom walks in right now."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:89
translate chinese CR2_MS1_label_613a24ff:

    # Caroline "Or, heaven forbid, Sara! What would she think if she saw her brother GROPING her sister’s ass?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:91
translate chinese CR2_MS1_label_83885e28:

    # Caroline "Yeah, but what if Linda walks in right now."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:92
translate chinese CR2_MS1_label_beac32db:

    # Caroline "Or, heaven forbid, Sara! What would she think if she saw you GROPING my ass?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:93
translate chinese CR2_MS1_label_e48d3e4d:

    # MC "But-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:97
translate chinese CR2_MS1_label_e995a44a:

    # Caroline "We can fool around in my work, but anything in Linda’s house is far too risky."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:99
translate chinese CR2_MS1_label_bf2c76a0:

    # Caroline "I’m not welching on our deal - we’ve got a good thing going. Let’s not risk blowing it, by Mom or Dad finding out. Okay?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:101
translate chinese CR2_MS1_label_d9cc7e24:

    # Caroline "I’m not welching on our deal - we’ve got a good thing going. Let’s not risk blowing it up by Linda or Bob finding out. Okay? I don’t imagine they want their tenants fucking each other."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:102
translate chinese CR2_MS1_label_6bc9a5bf:

    # MC "Yeah, I guess you’re right, Caroline."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:103
translate chinese CR2_MS1_label_68c51cb3:

    # Caroline "Good. Let’s just pretend this never happened, okay?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:104
translate chinese CR2_MS1_label_0a846b18:

    # MC "I understand."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:114
translate chinese CR2_MS1_label_4bd3b93f:

    # MC "(It isn’t worth the risk, grabbing her ass right now.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:116
translate chinese CR2_MS1_label_dfc03f7e:

    # MC "(It might piss her off - plus Mom or Dad or Sara could walk in!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:117
translate chinese CR2_MS1_label_d204ae84:

    # MC " (It would be embarrassing if any of them caught me groping Caroline’s bum. We should probably restrict our schmoozing to her workplace where we have some privacy.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:119
translate chinese CR2_MS1_label_d6027b47:

    # MC "(It might piss her off - plus Linda, Bob, or Sara could walk in!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:120
translate chinese CR2_MS1_label_d204ae84_1:

    # MC " (It would be embarrassing if any of them caught me groping Caroline’s bum. We should probably restrict our schmoozing to her workplace where we have some privacy.)"
    MC ""

translate chinese strings:

    # game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:72
    old "Grab Caroline’s ass."
    new ""

    # game/scripts/home/caroline_room/morning/scenes/CR2_MS1.rpy:72
    old "Don’t risk grabbing Caroline’s ass."
    new ""

