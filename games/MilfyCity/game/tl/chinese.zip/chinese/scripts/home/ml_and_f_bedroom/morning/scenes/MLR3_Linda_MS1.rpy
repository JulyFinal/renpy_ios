﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:22
translate chinese MLR3_Linda_MS1_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:37
translate chinese MLR3_Linda_MS1_3d143450:

    # MC "(I love it when she wears low-cut tops like that.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:38
translate chinese MLR3_Linda_MS1_0451c603:

    # MC "(I always get a great view when I’m standing over her like this.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:42
translate chinese MLR3_Linda_MS1_ce0c20a4:

    # Mom "Need something?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:43
translate chinese MLR3_Linda_MS1_16ae929e:

    # MC "I - uh... Just wanted to say... hi!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:44
translate chinese MLR3_Linda_MS1_6577e24e:

    # Mom "(Haha! I knew exactly what he was up to there. Does he not think I can tell when he’s looking down my top?)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:45
translate chinese MLR3_Linda_MS1_4a35708d:

    # Mom "Sit down beside me. I’m taking a break to enjoy my coffee."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:58
translate chinese MLR3_Linda_MS1_menu_e3df573a:

    # MC "What’s going on between you and [Dad_name]? Are you fighting?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:62
translate chinese MLR3_Linda_MS1_menu_d6e3f060:

    # Mom "*Sigh* It’s a little rough right now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:63
translate chinese MLR3_Linda_MS1_menu_e49bb605:

    # Mom "I wouldn’t say we’re fighting... but things haven’t been too hot lately."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:64
translate chinese MLR3_Linda_MS1_menu_b6277605:

    # Mom "That said, there’s nothing new there."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:68
translate chinese MLR3_Linda_MS1_menu_86283299:

    # Mom "The fires of our love burnt out years ago. It’s just embers now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:69
translate chinese MLR3_Linda_MS1_menu_4cb272f5:

    # MC "Are you not worried he’ll hear you?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:70
translate chinese MLR3_Linda_MS1_menu_dc33bc56:

    # Mom "Not over the sound of that vacuum cleaner."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:72
translate chinese MLR3_Linda_MS1_menu_7e7a67a0:

    # "*VROOOOM*"
    ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:83
translate chinese MLR3_Linda_MS1_menu_7fb73cbb:

    # MC "It’s good to see [Dad_name] helping more around the house. It gives you a chance to relax and do other things around the house, for a change."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:87
translate chinese MLR3_Linda_MS1_menu_d7c874b7:

    # Mom "Mmm, that’s true."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:88
translate chinese MLR3_Linda_MS1_menu_a5868d30:

    # Mom "*Shlurp*"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:94
translate chinese MLR3_Linda_MS1_menu_6b453def:

    # Mom "Hey, [player_name], before you go. Do you know what I’d really like to do around the house?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:95
translate chinese MLR3_Linda_MS1_menu_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:99
translate chinese MLR3_Linda_MS1_menu_fad20c0a:

    # Mom "You."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:100
translate chinese MLR3_Linda_MS1_menu_0cb445b7:

    # MC "*Whispered* [Mom_name]! He’s right over there!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:101
translate chinese MLR3_Linda_MS1_menu_7e981aa7:

    # Mom "So what? He won’t hear us."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:105
translate chinese MLR3_Linda_MS1_menu_f45325a5:

    # Mom "I would love to do you, all over this house."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:106
translate chinese MLR3_Linda_MS1_menu_a97f1ca8:

    # Mom "In the shower... in the bedroom..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:107
translate chinese MLR3_Linda_MS1_menu_7f9e70c6:

    # Mom "Maybe even on the kitchen table."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:108
translate chinese MLR3_Linda_MS1_menu_5ae3b49e:

    # Mom "God, if I had a weekend with you, with no one else around, I would fuck you silly."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:109
translate chinese MLR3_Linda_MS1_menu_41b1dfab:

    # MC "(Wow! She’s getting VERY brazen lately!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:113
translate chinese MLR3_Linda_MS1_menu_d59fa571:

    # Dad "*Phew* Okay, that’s the hoovering almost finished."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:114
translate chinese MLR3_Linda_MS1_menu_c66f5dfd:

    # Mom "That’s good to hear, Bob. I think you missed a few spots though."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:117
translate chinese MLR3_Linda_MS1_menu_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:129
translate chinese MLR3_Linda_MS1_menu_d772f687:

    # MC "How did you and [Dad_name] first meet?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:130
translate chinese MLR3_Linda_MS1_menu_30e251cd:

    # Mom "Oh wow... I haven’t thought about that in a LONG time..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:131
translate chinese MLR3_Linda_MS1_menu_b3b55b63:

    # Mom "God... it must have been... Venice, I think?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:135
translate chinese MLR3_Linda_MS1_menu_438ef25c:

    # Mom "I think we were on a business trip to Venice together. I don’t remember when we first spoke to each other though."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:136
translate chinese MLR3_Linda_MS1_menu_e562bd1d:

    # MC "Huh, it sounds quite nice! Did you go on the gondolas together?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:137
translate chinese MLR3_Linda_MS1_menu_27f77ddc:

    # Mom "Wait - there were no gondolas. Maybe it wasn’t Venice?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:141
translate chinese MLR3_Linda_MS1_menu_4c200517:

    # MC "(She doesn’t seem to remember this very well. Or maybe she just doesn’t care enough to?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:142
translate chinese MLR3_Linda_MS1_menu_d6850d86_1:

    # Mom "..."
    Mom ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:53
    old "What’s going on between you and [Dad_name]? Are you fighting?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:53
    old "{color=#00ff00}It’s good to see [Dad_name] helping more around the house.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Linda_MS1.rpy:53
    old "How did you and [Dad_name] first meet?"
    new ""

