﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/bathroom/morning/scenes/bath_event.rpy:60
translate chinese bath_event_label_33f90443:

    # MC "It’s too late to take a bath."
    MC ""

translate chinese strings:

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:46
    old "Take a bath"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:75
    old "Finish the bath"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:75
    old "Masturbate and think about someone"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Mom"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Linda"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Judy"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Celia"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Aunt"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Liza"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Violet"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Lily"
    new ""

    # game/scripts/home/bathroom/morning/scenes/bath_event.rpy:93
    old "Zuri and Suri "
    new ""

