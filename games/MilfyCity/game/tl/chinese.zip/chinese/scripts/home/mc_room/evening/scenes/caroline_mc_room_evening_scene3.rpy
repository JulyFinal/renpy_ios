﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:43
translate chinese caroline_mc_room_evening_scene3_label_7df4ad07:

    # MC "Oh! Hey, Caroline. What are you doing in my room?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:44
translate chinese caroline_mc_room_evening_scene3_label_c98c4453:

    # MC "And who’s this?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:45
translate chinese caroline_mc_room_evening_scene3_label_435d42ef:

    # Caroline "Hiii, [player_name]! I want you to meet Violet!"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:46
translate chinese caroline_mc_room_evening_scene3_label_369f194c:

    # Violet "Hey there."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:47
translate chinese caroline_mc_room_evening_scene3_label_75a91ab5:

    # Caroline "I promised you a surprise - so Violet’s going to help you relieve some of that stress you’ve built up."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:50
translate chinese caroline_mc_room_evening_scene3_label_a5f6e8df:

    # MC "You brought a prostitute to my bedroom!?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:51
translate chinese caroline_mc_room_evening_scene3_label_6069cd87:

    # Violet "WHAT?!"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:52
translate chinese caroline_mc_room_evening_scene3_label_781e97ef:

    # Caroline "Ahahaha! Oh, my God! I’m so sorry, Violet!"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:55
translate chinese caroline_mc_room_evening_scene3_label_54ae8849:

    # Violet "Fuck you! I’m not some whore!"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:56
translate chinese caroline_mc_room_evening_scene3_label_b3163b44:

    # Violet "Caroline made a deal with me - she owes me a favour if I help you relax."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:57
translate chinese caroline_mc_room_evening_scene3_label_d634feb6:

    # MC "Huh? Like a massage?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:60
translate chinese caroline_mc_room_evening_scene3_label_ab6d0afa:

    # Caroline "She’s not a prostitute. She’s one of my friends."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:61
translate chinese caroline_mc_room_evening_scene3_label_8f04cd5e:

    # Caroline "I’ve made a deal with her - I owe her a favour now, but in exchange she’s going to do something for you."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:62
translate chinese caroline_mc_room_evening_scene3_label_e13c98ce:

    # MC "Do something?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:65
translate chinese caroline_mc_room_evening_scene3_label_156ef6a8:

    # Caroline "Are you seriously THAT dense? She’s going to get you off!"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:66
translate chinese caroline_mc_room_evening_scene3_label_e5093ef0:

    # MC "OH!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:67
translate chinese caroline_mc_room_evening_scene3_label_a63cc2e2:

    # MC "Sorry, Violet! I didn’t realise."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:68
translate chinese caroline_mc_room_evening_scene3_label_1b27cdf6:

    # Caroline "I’m gonna leave you two alone now. Have fun!"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:71
translate chinese caroline_mc_room_evening_scene3_label_d07f9764:

    # Violet "See you later, Caroline. Follow me, [player_name]."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:72
translate chinese caroline_mc_room_evening_scene3_label_442788eb:

    # MC "What are we going to do, then?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:73
translate chinese caroline_mc_room_evening_scene3_label_4f693c88:

    # MC "Like... sex? Or anal?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:76
translate chinese caroline_mc_room_evening_scene3_label_804b98d6:

    # Violet "We’re going to get this over with, quickly."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:77
translate chinese caroline_mc_room_evening_scene3_label_d127f103:

    # Violet "I’ll lie back on the bed and let you fuck my mouth."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:78
translate chinese caroline_mc_room_evening_scene3_label_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:81
translate chinese caroline_mc_room_evening_scene3_label_114b70ec:

    # Violet "Well? Are you ready? I have places to be."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:82
translate chinese caroline_mc_room_evening_scene3_label_4e7044c1:

    # MC "S-Sure!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:84
translate chinese caroline_mc_room_evening_scene3_label_03979f50:

    # MC "What deal did you make with my sister, by the way?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:86
translate chinese caroline_mc_room_evening_scene3_label_0209ebf5:

    # MC "What deal did you make with Caroline, by the way?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:87
translate chinese caroline_mc_room_evening_scene3_label_2568ebcf:

    # Violet "She owes me one. I’ll probably end up making her suck off one of my male friends, just to even the score."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:90
translate chinese caroline_mc_room_evening_scene3_label_a45c5b4d:

    # Violet "Okay - let’s get this party started."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:91
translate chinese caroline_mc_room_evening_scene3_label_07ec537a:

    # Violet "First things first - we need to get you hard."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:92
translate chinese caroline_mc_room_evening_scene3_label_ec5eb49c:

    # MC "(She’s REALLY sexy! Caroline has good taste in friends!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:93
translate chinese caroline_mc_room_evening_scene3_label_e37c34fe:

    # MC "(Let’s see if she’s as slutty as she looks!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:96
translate chinese caroline_mc_room_evening_scene3_label_9617ae6b:

    # Violet "Ahh...."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:97
translate chinese caroline_mc_room_evening_scene3_label_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:98
translate chinese caroline_mc_room_evening_scene3_label_3fa5d3e7:

    # MC "(I can feel her tongue, licking the tip of my cock.)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:99
translate chinese caroline_mc_room_evening_scene3_label_25aed3ce:

    # MC "(She’s swirling it around - she’s clearly done this A LOT of times before.)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:102
translate chinese caroline_mc_room_evening_scene3_label_b405566c:

    # MC "(Taking pictures for Caroline, has gotta be one of the best decisions I’ve made all year!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:104
translate chinese caroline_mc_room_evening_scene3_label_f09c71e8:

    # MC "(I never imagined it would end up, with me getting a blowjob from a cocksucking slut!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:106
translate chinese caroline_mc_room_evening_scene3_label_1e18d554:

    # MC "(I never imagined it would end up with me getting my cock sucked by her slutty friend!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:110
translate chinese caroline_mc_room_evening_scene3_label_6764e270:

    # Violet "Ah, there we go. Now we can properly begin."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:111
translate chinese caroline_mc_room_evening_scene3_label_0b702f6b:

    # MC "I know you said a quick blowjob, but can I use your tits too?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:112
translate chinese caroline_mc_room_evening_scene3_label_69c23a62:

    # Violet "*Sigh* Fine."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:115
translate chinese caroline_mc_room_evening_scene3_label_224508ec:

    # MC "Awesome! "
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:116
translate chinese caroline_mc_room_evening_scene3_label_496df01c:

    # Violet "Do you need me to hold my breasts together?"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:117
translate chinese caroline_mc_room_evening_scene3_label_5fa4e903:

    # MC "Could you?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:118
translate chinese caroline_mc_room_evening_scene3_label_7c2f5a1b:

    # Violet "Sure."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:121
translate chinese caroline_mc_room_evening_scene3_label_d8f5acb0:

    # Violet "How’s that?"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:122
translate chinese caroline_mc_room_evening_scene3_label_041648e4:

    # MC "Much better!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:125
translate chinese caroline_mc_room_evening_scene3_label_df859db7:

    # MC "(I can feel her warm breasts, wrapped around my cock!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:128
translate chinese caroline_mc_room_evening_scene3_label_1e3c558b:

    # Violet "(Ugh! How long is this little twerp gonna take to cum?)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:129
translate chinese caroline_mc_room_evening_scene3_label_ec08e087:

    # Violet "(I thought my boobs would be enough, but maybe I should give him a helping hand?)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:132
translate chinese caroline_mc_room_evening_scene3_label_e206ed83:

    # MC "OOOHHH!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:133
translate chinese caroline_mc_room_evening_scene3_label_5da3d66d:

    # MC "(Holy shit! She’s licking my ass! I never imagined it would be so sensitive there!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:134
translate chinese caroline_mc_room_evening_scene3_label_9a898dff:

    # MC "(Crap! If she keeps that up, I’ll cum before, I even get a blowjob from her!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:137
translate chinese caroline_mc_room_evening_scene3_label_d757dfd9:

    # MC "(I’ll try to endure it for a while - it feels amazing!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:138
translate chinese caroline_mc_room_evening_scene3_label_d229a396:

    # Violet "(Time to hold my breasts a little closer together. Let’s see if we can make him cum, before I have to go through with a blowjob.)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:139
translate chinese caroline_mc_room_evening_scene3_label_061b6594:

    # MC "Ahh... Ohh..."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:142
translate chinese caroline_mc_room_evening_scene3_label_52c83cd2:

    # MC "God, yes! Ahh... Fuck!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:143
translate chinese caroline_mc_room_evening_scene3_label_1b383315:

    # Violet "(Time to twist and flick my tongue even faster.)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:144
translate chinese caroline_mc_room_evening_scene3_label_6769d89e:

    # MC "AHhhhh! OH! OH OH!!!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:147
translate chinese caroline_mc_room_evening_scene3_label_2db08e16:

    # MC "(Between her breasts and her tongue, licking my ass, I feel like I’m about to cum!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:148
translate chinese caroline_mc_room_evening_scene3_label_a786ee93:

    # MC "(I better stop this and get my blowjob, to finish things off!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:149
translate chinese caroline_mc_room_evening_scene3_label_51a29a6e:

    # MC "Okay, ahh- that’s enough. I want you to use your mouth now."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:150
translate chinese caroline_mc_room_evening_scene3_label_8368e32e:

    # Violet "Ugh! Fine."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:153
translate chinese caroline_mc_room_evening_scene3_label_9dbd5014:

    # Violet "*Suck Suck*"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:154
translate chinese caroline_mc_room_evening_scene3_label_7304a397:

    # MC "Ooohh - that’s the spot!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:155
translate chinese caroline_mc_room_evening_scene3_label_53cb3258:

    # MC "(I can’t hold back anymore. I REALLY HAVE TO fuck her face!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:158
translate chinese caroline_mc_room_evening_scene3_label_caf68afa:

    # Violet "MMPFFFFF!"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:160
translate chinese caroline_mc_room_evening_scene3_label_dd7f674d:

    # Violet "(Fuck! I wasn’t expecting him to thrust his cock into my mouth like that!)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:161
translate chinese caroline_mc_room_evening_scene3_label_a1a1fd1d:

    # MC "Oooh yeah!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:164
translate chinese caroline_mc_room_evening_scene3_label_9bb8e373:

    # MC "Damn, you’re a great cocksucker. You know that?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:165
translate chinese caroline_mc_room_evening_scene3_label_17fd1251:

    # Violet "(Smooth... That’s just the kind of compliment a girl wants to hear, from a guy she just met...)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:166
translate chinese caroline_mc_room_evening_scene3_label_e4c56a5e:

    # Violet "Mmpfff mmmm...."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:169
translate chinese caroline_mc_room_evening_scene3_label_9654d4b0:

    # MC "Ahh, fuck... I’m gonna cum soon!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:170
translate chinese caroline_mc_room_evening_scene3_label_17c63f15:

    # Violet "(At least he gave me a warning. That’s more than I can say for any of my exes.)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:173
translate chinese caroline_mc_room_evening_scene3_label_1f85237b:

    # MC "Ah! Ugh! Yes!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:174
translate chinese caroline_mc_room_evening_scene3_label_432b631e:

    # Violet "*Shlurrrp*"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:176
translate chinese caroline_mc_room_evening_scene3_label_934e7966:

    # Violet "*Suck Suck Suck*"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:177
translate chinese caroline_mc_room_evening_scene3_label_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:180
translate chinese caroline_mc_room_evening_scene3_label_49e51dfc:

    # MC "Open wide!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:181
translate chinese caroline_mc_room_evening_scene3_label_563b0d5b:

    # MC "Ahhh! Yes!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:182
translate chinese caroline_mc_room_evening_scene3_label_c7ecf997:

    # Violet "(That favour Caroline owes me better be worth it...)"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:192
translate chinese caroline_mc_room_evening_scene3_label_8e6949d2:

    # MC "UGH! Ahhhhhh!"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:193
translate chinese caroline_mc_room_evening_scene3_label_89c3e729:

    # MC "*Pant...* Ooohh...."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:194
translate chinese caroline_mc_room_evening_scene3_label_5c15efa7:

    # MC "Do you need me to get you a tissue or anything, to spit it-"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:195
translate chinese caroline_mc_room_evening_scene3_label_413e144f:

    # Violet "*Gulp!*"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:196
translate chinese caroline_mc_room_evening_scene3_label_cfda8a59:

    # MC "Or you could just do that."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:199
translate chinese caroline_mc_room_evening_scene3_label_1f5fb641:

    # Violet "So, Caroline was telling me, you got a boner while looking at her. Is that true?"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:200
translate chinese caroline_mc_room_evening_scene3_label_22c08df1:

    # MC "Uh... Yeah, but it’s not the full story."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:201
translate chinese caroline_mc_room_evening_scene3_label_14cb8666:

    # Violet "What’s the story, then?"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:202
translate chinese caroline_mc_room_evening_scene3_label_b97353f5:

    # MC "She was dressed up in a sexy costume. A guy doesn’t really have any control over his cock, in a situation like that. So you can’t really say it’s my fault."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:203
translate chinese caroline_mc_room_evening_scene3_label_909073f0:

    # Violet "Eh... fair enough."
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:204
translate chinese caroline_mc_room_evening_scene3_label_2f3d144d:

    # Violet "Just one more question - do you prefer me or Caroline?"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:208
translate chinese caroline_mc_room_evening_scene3_label_7cde3286:

    # MC "Come on - I can’t answer that. She’s my sister."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:210
translate chinese caroline_mc_room_evening_scene3_label_5f31e0ce:

    # MC "Come on - I can't answer that. You might reveal my response to her."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:211
translate chinese caroline_mc_room_evening_scene3_label_92f2a645:

    # Violet "Sure you can!"
    Violet ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:212
translate chinese caroline_mc_room_evening_scene3_label_438a7437:

    # MC "*Sigh* You’re hot, but... Caroline’s more my type. She’s really gorgeous."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:215
translate chinese caroline_mc_room_evening_scene3_label_4c225a54:

    # Caroline "*Gasp!*"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:217
translate chinese caroline_mc_room_evening_scene3_label_f76ad3be:

    # Caroline "([player_name] is actually... attracted to me. It wasn’t just the costume I was wearing.)"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:219
translate chinese caroline_mc_room_evening_scene3_label_a5e1e515:

    # Caroline "(He’s actually attracted to... me? It wasn’t just the costume I was wearing.)"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene3.rpy:220
translate chinese caroline_mc_room_evening_scene3_label_feb61845:

    # Caroline "(What the Hell am I supposed to do now? Is it even fair of me, to let him keep taking pictures of me? Or is that just torturing him?)"
    Caroline ""

