﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:11
translate chinese caroline_room_morning_scene2_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:21
translate chinese caroline_room_morning_scene2_label_71495fac:

    # MC "(Caroline did say I could come and talk with her any time.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:22
translate chinese caroline_room_morning_scene2_label_9e452549:

    # MC "(I guess it wouldn’t hurt to chat with someone other than my therapist. It might be easier to open up to someone I’ve known for years.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:23
translate chinese caroline_room_morning_scene2_label_5a48d87a:

    # MC "(Plus, Caroline tends to hang around in her underwear when she’s in her bedroom. I might get another chance to see her in her lingerie.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:26
translate chinese caroline_room_morning_scene2_label_2549cbc6:

    # MC "Uh, hey Caroline. Remember you said that I could come and chat-"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:27
translate chinese caroline_room_morning_scene2_label_ed2ec35b:

    # Caroline "I’m sorry, [player_name]. I know I promised, but... "
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:28
translate chinese caroline_room_morning_scene2_label_e11db265:

    # Caroline "...I just can’t handle it right now."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:29
translate chinese caroline_room_morning_scene2_label_07a4d523:

    # MC "Is everything okay?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:32
translate chinese caroline_room_morning_scene2_label_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:33
translate chinese caroline_room_morning_scene2_label_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:34
translate chinese caroline_room_morning_scene2_label_41e62cab:

    # MC "(She might not be free to chat, but at least I get to check out her ass.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:37
translate chinese caroline_room_morning_scene2_label_a4eb88de:

    # Caroline "I’m sorry, [player_name]. I’m under a LOT of pressure right now."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:38
translate chinese caroline_room_morning_scene2_label_d1e43cca:

    # MC "Are you behind on those heavy business textbooks you read?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:39
translate chinese caroline_room_morning_scene2_label_b9ef08cb:

    # Caroline "No, it’s my shop. I... I can’t balance my budget. No matter what I do it just won’t..."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:40
translate chinese caroline_room_morning_scene2_label_2cc70eb5:

    # Caroline "*Sigh*"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:41
translate chinese caroline_room_morning_scene2_label_7f5b4c87:

    # Caroline "Listen, would you mind leaving me alone for a while?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:42
translate chinese caroline_room_morning_scene2_label_4c9ed4dc:

    # Caroline "I know I promised you that I’d be here to chat if you ever needed someone to talk to, but I’m in no fit state right now."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene2.rpy:43
translate chinese caroline_room_morning_scene2_label_394a215d:

    # MC "Sorry, Caroline. I’ll give you some space."
    MC ""

