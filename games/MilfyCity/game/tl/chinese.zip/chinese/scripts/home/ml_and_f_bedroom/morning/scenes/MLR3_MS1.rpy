﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:29
translate chinese MLR3_MS1_3dd78a80:

    # MC "(I should probably leave them alone.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:43
translate chinese MLR3_MS1_169d713c:

    # Bob "Aww, c’mon, Linda, I need you to open up to me. Can’t we just talk about this?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:44
translate chinese MLR3_MS1_22cbf542:

    # Linda "There’s NOTHING to talk about!"
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:46
translate chinese MLR3_MS1_e885cce6:

    # MC "(Huh? It sounds like Mom and Dad are having an argument. I wonder what’s going on...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:48
translate chinese MLR3_MS1_448dc44f:

    # MC "(Huh? It sounds like Linda and Bob are having an argument. I wonder what’s going on...)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:55
translate chinese MLR3_MS1_eb94dee7:

    # Bob "Relationships are built on communication, Linda. I know you’re angry or maybe frustrated, right now, but if you don’t tell me why, I can’t fix whatever the problem is."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:56
translate chinese MLR3_MS1_b02c9097:

    # Linda "*Shlurp*"
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:57
translate chinese MLR3_MS1_7aef08d8:

    # Bob "*Sigh*"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:58
translate chinese MLR3_MS1_9549356e:

    # Bob "Linda, you’re killing me right now. Please, throw me a bone here!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:62
translate chinese MLR3_MS1_6d5072f7:

    # Bob "I’ve done everything I can - I’ve helped out around the house. I’ve been working my ass off in overtime to help pay our bills. I mean, what more do you want from me?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:63
translate chinese MLR3_MS1_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:64
translate chinese MLR3_MS1_6509fbcd:

    # Bob "Please don’t give me the silent treatment, Dear. You’re better than that. This isn’t going to help us address these problems."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:68
translate chinese MLR3_MS1_43546a3f:

    # Linda "You’re blowing this WAY out of proportion, Bob. Seriously, you need to calm the fuck down."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:69
translate chinese MLR3_MS1_d7444ce0:

    # Bob "But, I-"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:70
translate chinese MLR3_MS1_b27e9f5a:

    # Linda "There are NO problems in this relationship."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:76
translate chinese MLR3_MS1_139046af:

    # Bob "Forgive my french, Linda - but you and I both know that is complete bullcrap."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:77
translate chinese MLR3_MS1_dcb032b4:

    # Bob "Things haven’t been normal between you and me, for a while now. But it seems in the past few weeks, things have taken a REAL nosedive between us."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:78
translate chinese MLR3_MS1_fed19a8c:

    # Bob "I’m willing to go to therapy with you if that’s what you need. You’ve got that friend who’s a therapist, right? What’s her name again? Celia? Judy? Something like that?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:82
translate chinese MLR3_MS1_04b7f28c:

    # Linda "Ugh! I am NOT bringing my friends into our marital issues."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:83
translate chinese MLR3_MS1_ee93f42c:

    # Bob "Aha! So you admit it, we ARE having issues!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:84
translate chinese MLR3_MS1_6c1ca0ec:

    # Linda "I said ‘issues’, Bob, not ‘problems’."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:85
translate chinese MLR3_MS1_93f05e0e:

    # Bob "They’re the same damn thing!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:86
translate chinese MLR3_MS1_868e7d7f:

    # Bob "*Sigh* Sorry for raising my voice at you there. Listen, we need to talk about-"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:87
translate chinese MLR3_MS1_3e659289:

    # Linda "There’s nothing to talk about, Bob."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:91
translate chinese MLR3_MS1_0c83f16c:

    # Bob "YOU’RE TEARING ME APART, LINDA!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:92
translate chinese MLR3_MS1_7e0e8d49:

    # Bob "Do you know how I feel right now?! Do you have any idea?!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:93
translate chinese MLR3_MS1_a6809c15:

    # Bob "I spend every single day, dealing with problems and issues at work. I can FIX problems and resolve issues. What I can’t deal with, is this silent treatment!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:94
translate chinese MLR3_MS1_85d4cdc0:

    # Bob "It leaves me feeling physically sick... this horrible sensation of not knowing what is wrong. It’s like you’re slipping between my fingers and I can’t hold onto you - and I don’t know why!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:98
translate chinese MLR3_MS1_23939bad:

    # Linda "For God’s sake, pull yourself together, Bob! You’re a forty eight year old man. Act like one!"
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:99
translate chinese MLR3_MS1_a576d7a0:

    # Linda "And don’t you DARE raise your voice to me again. "
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:103
translate chinese MLR3_MS1_51c2a4a1:

    # Bob "*Sigh* I’m sorry, I’m just..."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:104
translate chinese MLR3_MS1_fe58caff:

    # Bob "I’ve just been stressed with work lately. There’s a lot of pressure to post record profits before the next shareholders meeting."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:105
translate chinese MLR3_MS1_98a99c05:

    # Bob "I shouldn’t be taking that stress out on you, but I can’t spend all day busting my ass at work and then come home to a wife who... who..."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:106
translate chinese MLR3_MS1_7bf4f623:

    # Linda "Yes, Bob..?"
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:107
translate chinese MLR3_MS1_d966fc4d:

    # Bob "...who may not even love me."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:111
translate chinese MLR3_MS1_9e6c35fe:

    # Bob "I know it sounds pathetic. But, when was the last time we had sex?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:112
translate chinese MLR3_MS1_f01426fb:

    # Linda "We did it last we-"
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:113
translate chinese MLR3_MS1_05ba7532:

    # Bob "No, we didn’t. I fucked YOU last week. You just lay there and took it, while you read your book."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:114
translate chinese MLR3_MS1_b0f257c7:

    # Linda "That was sex."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:115
translate chinese MLR3_MS1_d69a45d5:

    # Bob "It wasn’t. You know as well as I do, that we haven’t had real proper sex in a long time."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:119
translate chinese MLR3_MS1_8a1c1dc5:

    # Bob "Remember the first time we got to third base? I picked you up in my old red cadillac. Your father was glaring at me from the porch. I was terrified he was gonna shoot me that night."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:120
translate chinese MLR3_MS1_cf511e0e:

    # Bob "We drove along those winding roads, up Wilridge Mountain. The government didn’t have barriers on the roadside back in those days. You could lean out the window and see a four hundred foot drop off the mountain edge."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:121
translate chinese MLR3_MS1_29ae2f12:

    # Bob "It was dangerous and stupid - but we were teenagers, and the view was to die for. Do you remember that night, Linda?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:122
translate chinese MLR3_MS1_c43b46a9_1:

    # Linda "..."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:126
translate chinese MLR3_MS1_0fbc11ca:

    # Bob "You wore that purple miniskirt with no panties underneath. We sixty-nined in the back seats, under the starlight."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:127
translate chinese MLR3_MS1_10ad8a1d:

    # Bob "We were loud back then, Linda. We were loud, and we were frisky, and we were... honest with each other."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:128
translate chinese MLR3_MS1_2c97ec73:

    # Bob "*Sniff* We fooled around so much, we steamed the damn windows up. That was real sex."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:129
translate chinese MLR3_MS1_40bfd6c6:

    # Linda "That was decades ago. Nothing lasts forever, Bob."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:130
translate chinese MLR3_MS1_e79c5354:

    # Bob "*Sob* You threw a fucking pillow at me when I came into the room. You looked at me like I DISGUSTED you."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:132
translate chinese MLR3_MS1_06331d14:

    # Bob "*Sniff* This isn’t just about me, Linda. For Christ’s sake... think of our kids."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:133
translate chinese MLR3_MS1_4a2cd2af:

    # Bob "Think of Sara - she probably sees more than you know, and her parents fighting is going to break her little heart."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:135
translate chinese MLR3_MS1_6bb6fdd8:

    # Bob "*Sniff* This isn’t just about me, Linda. For Christ’s sake... what are the tenants going to think of us if they see us fighting all the time?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:136
translate chinese MLR3_MS1_b885a1ec:

    # Bob "Consider their feelings – they likely see more than you realize, and if we continue to argue, it's going to hurt them deeply. They've known us for quite some time now!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS1.rpy:137
translate chinese MLR3_MS1_0fb1256b:

    # MC "(Fuck... This is too tough to listen to. I gotta go.)"
    MC ""

