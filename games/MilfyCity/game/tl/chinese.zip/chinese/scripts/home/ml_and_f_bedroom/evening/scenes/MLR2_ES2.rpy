﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:23
translate chinese MLR2_ES2_label_764ce0ef:

    # Mom "Boo!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:24
translate chinese MLR2_ES2_label_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:26
translate chinese MLR2_ES2_label_99886939:

    # MC "Jesus, you scared me there, Mom!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:28
translate chinese MLR2_ES2_label_2779c4b0:

    # MC "Jesus, you scared me there, Linda!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:32
translate chinese MLR2_ES2_label_d88831e2:

    # Mom "Well... YOU are the one sneaking into MY room!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:33
translate chinese MLR2_ES2_label_d6cdb139:

    # MC "Err... I suppose so."
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:34
translate chinese MLR2_ES2_label_efef9cf6:

    # Mom "You must already be missing me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:38
translate chinese MLR2_ES2_label_1e46d52f:

    # MC "Haha! Of course I do, Mom. I love spending time with you."
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:40
translate chinese MLR2_ES2_label_bef6b505:

    # MC "Haha! of course I do, Linda. I love spending time with you."
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:41
translate chinese MLR2_ES2_label_d6c1bd1e:

    # Mom "You’re such a sweetheart."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:42
translate chinese MLR2_ES2_label_aa343453:

    # Mom "I could just push you back on the bed, right now. Strip off your jeans and-"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:44
translate chinese MLR2_ES2_label_16be8525:

    # "RING RING! RING RING!"
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:48
translate chinese MLR2_ES2_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:50
translate chinese MLR2_ES2_label_16be8525_1:

    # "RING RING! RING RING!"
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:52
translate chinese MLR2_ES2_label_844b9bde:

    # Mom "Crap - that’s my phone. Hang on. I’ll only be two minutes."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:56
translate chinese MLR2_ES2_label_bde99060:

    # Mom "Actually... can you leave? It’s a work call. I’m sorry."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:57
translate chinese MLR2_ES2_label_573996e6:

    # Mom "Come to my workplace in the afternoon. There will be more work for you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:59
translate chinese MLR2_ES2_label_22cbca0b:

    # MC "Sure, Mom. No problem."
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:61
translate chinese MLR2_ES2_label_fedc0a93:

    # MC "Sure, Linda. No problem."
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:62
translate chinese MLR2_ES2_label_b95ddda9:

    # MC "(Huh? I wonder what made her change her mind so quickly.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:66
translate chinese MLR2_ES2_label_c1be8744:

    # Mom "Hello, Judy. What’s up?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:67
translate chinese MLR2_ES2_label_a20cefa7:

    # "..."
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:68
translate chinese MLR2_ES2_label_5a0a1fec:

    # Mom "Uh huh. Now’s not a great time."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:75
translate chinese MLR2_ES2_label_b58f8c8d:

    # MC "(Judy? I wonder if it’s the same Judy that’s my therapist.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:76
translate chinese MLR2_ES2_label_9ffdafd0:

    # Mom "Yes, of course. The deal is still on."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:77
translate chinese MLR2_ES2_label_5f9b772e:

    # "...."
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:78
translate chinese MLR2_ES2_label_e45a5597:

    # Mom "Sure, we can meet up again for a coffee soon."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:82
translate chinese MLR2_ES2_label_881ca091:

    # Mom "How about you? Is the book coming along well?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:83
translate chinese MLR2_ES2_label_5f9b772e_1:

    # "...."
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:84
translate chinese MLR2_ES2_label_e1e975c8:

    # Mom "Writer’s block? I’m sorry to hear that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:85
translate chinese MLR2_ES2_label_a20cefa7_1:

    # "..."
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:89
translate chinese MLR2_ES2_label_0df8c300:

    # Mom "Of course. I did promise I would help you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:90
translate chinese MLR2_ES2_label_ce29aa64:

    # Mom "Don’t you worry, Judy. I’ll give you some ideas, as soon as I can."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:91
translate chinese MLR2_ES2_label_5f9b772e_2:

    # "...."
    ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:92
translate chinese MLR2_ES2_label_653e5e7a:

    # Mom "Chat later!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/evening/scenes/MLR2_ES2.rpy:93
translate chinese MLR2_ES2_label_6080456f:

    # MC "(Crap, she’s almost finished. I better go, so she doesn’t think I’ve been eavesdropping on her!)"
    MC ""

