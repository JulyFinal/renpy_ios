﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:23
translate chinese CR3_NS1_label_2d4df14a:

    # MC "(It's not a good idea, to wake her up.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:29
translate chinese CR3_NS1_label_0ce629ba:

    # MC "(It's not a good idea, to wake her up again. She was mad the last time - so now she will probably be furious...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:38
translate chinese CR3_NS1_label_18532e33:

    # MC "*Whispered* Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:39
translate chinese CR3_NS1_label_7af033e3:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:40
translate chinese CR3_NS1_label_fad01af2:

    # MC "(She’s asleep. Hopefully she won’t mind, me waking her up.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:44
translate chinese CR3_NS1_label_bbb30d54:

    # MC "(I know, the deal between us is off, but I can’t get her out of my head. If I’m never going to be with her again, then I want our last time together to be - something special and memorable.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:45
translate chinese CR3_NS1_label_20ec461e:

    # MC "(I was hoping that what we had would - develop into something more - that maybe, one day, she would start to feel attracted to me, and love me.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:46
translate chinese CR3_NS1_label_33d4777b:

    # MC "(Perhaps, that just wasn’t supposed to happen.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:50
translate chinese CR3_NS1_label_3848c370:

    # MC "*Whispered* Hey, Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:51
translate chinese CR3_NS1_label_4fd4f095:

    # Caroline "*Snore*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:52
translate chinese CR3_NS1_label_6b4ee69e:

    # MC "(She’s fast asleep. I don’t want to shake her awake - I guess I could try and pull the covers back. Maybe that will wake her up.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:56
translate chinese CR3_NS1_label_456ce8b0:

    # MC "(There we go. I’ll just fold them, over here for her.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:57
translate chinese CR3_NS1_label_f4b77232:

    # MC "*Whispered* Caroline? Wake up, it’s just me."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:58
translate chinese CR3_NS1_label_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:62
translate chinese CR3_NS1_label_0c008add:

    # MC "*Whispered* Hey there."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:63
translate chinese CR3_NS1_label_b056212f:

    # Caroline "Huh? [player_name]? What are you doing in my room? What time is it?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:64
translate chinese CR3_NS1_label_f6b36fee:

    # MC "It’s... quite late."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:69
translate chinese CR3_NS1_label_189fd798:

    # Caroline "Ugh... I’ve got to get up, early in the morning. What did you wake me for?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:70
translate chinese CR3_NS1_label_7b1e8f98:

    # MC "I’m sorry, I just..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:71
translate chinese CR3_NS1_label_0f3acf5d:

    # Caroline "Just what..?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:75
translate chinese CR3_NS1_label_d8ee7d92:

    # MC "I just wanted... to know..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:76
translate chinese CR3_NS1_label_e116161f:

    # MC "I can’t stop thinking about - what we had together, all the fun of that deal, how happy it, made BOTH of us."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:77
translate chinese CR3_NS1_label_d621e3e7:

    # MC "And don’t tell me that you didn’t enjoy it too - I KNOW you did. You were always smiling, when we were together."
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:81
translate chinese CR3_NS1_label_14f269b9:

    # MC "Please, Caroline... I know it’s over now, but can we, at least, just mark it with one final night between the two of us?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:82
translate chinese CR3_NS1_label_c32bf2b7:

    # Caroline "[player_name]..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:83
translate chinese CR3_NS1_label_91aa6fa8:

    # MC "Please... I never had any closure. This all ended so suddenly - and to be honest, I’m not even certain why!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:87
translate chinese CR3_NS1_label_093e6f40:

    # Caroline "[player_name], you have to leave..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:89
translate chinese CR3_NS1_label_b8530a52:

    # MC "B-But-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:90
translate chinese CR3_NS1_label_9736495c:

    # Caroline "No buts! Please don’t make this, any harder for yourself. You need to move on."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:91
translate chinese CR3_NS1_label_7f578860:

    # MC "Don’t you want - one last-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:93
translate chinese CR3_NS1_label_b99a7828:

    # Caroline "No, I don’t. You’re my brother, [player_name]. Anything that we did together, was completely wrong. Go back to bed."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:95
translate chinese CR3_NS1_label_ef42dba4:

    # Caroline "No, I don’t. You’re my best friend, [player_name]. Anything that we did together, was completely wrong. Go back to bed!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:99
translate chinese CR3_NS1_label_8dc292fb:

    # MC "(I can’t believe it... It’s really over.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:100
translate chinese CR3_NS1_label_6c95114b:

    # MC "(I’m never going to be with her again.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:101
translate chinese CR3_NS1_label_90d9d60f:

    # MC "(Jesus Christ... I don’t even know what I did, to fuck this up! It’s like a switch was suddenly flicked and now she hates me!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:105
translate chinese CR3_NS1_label_79da9db5:

    # Caroline "*Sniff*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:106
translate chinese CR3_NS1_label_c750600a:

    # MC "(Is she crying? Fuck! Now I’ve gone and upset her too.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS1.rpy:107
translate chinese CR3_NS1_label_5f6b8054:

    # MC "(How the fuck did I make this - awful situation - any worse than it already was?)"
    MC ""

