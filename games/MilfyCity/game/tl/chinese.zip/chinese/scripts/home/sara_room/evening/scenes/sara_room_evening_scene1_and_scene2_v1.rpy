﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:36
translate chinese sis_nerdy_evening_scene1_v1_l_dbc91206:

    # MC "Hey Sara, are you free to-"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:37
translate chinese sis_nerdy_evening_scene1_v1_l_9bd7a7ba:

    # Sara "Sorry, [player_name]. I’m in the middle of a league final right now! If I win this match I’m through to next season!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:38
translate chinese sis_nerdy_evening_scene1_v1_l_0f268726:

    # Sara "I’ll catch you later!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:39
translate chinese sis_nerdy_evening_scene1_v1_l_06a28090:

    # MC "(She takes her gaming waaaay too seriously.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:40
translate chinese sis_nerdy_evening_scene1_v1_l_f16147dd:

    # MC "Alright, see you later, Sara."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:47
translate chinese sis_nerdy_evening_scene1_v1_l_08728b1a:

    # MC "I've already talked to her."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:57
translate chinese sis_nerdy_evening_scene1_v1_l_97c6b23d:

    # MC "Hey Sara, are you still busy with your league game?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:58
translate chinese sis_nerdy_evening_scene1_v1_l_22a7fa4d:

    # Sara "Give me two seconds... this match is almost over."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:59
translate chinese sis_nerdy_evening_scene1_v1_l_b418f6f9:

    # Sara "Aaaaand I’m done!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:62
translate chinese sis_nerdy_evening_scene1_v1_l_6b0e2eaf:

    # Sara "Say, do you fancy gaming together? I can boot up the XSwitch4!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:63
translate chinese sis_nerdy_evening_scene1_v1_l_d8aeb7cc:

    # MC "Great! What game do you want to play?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:64
translate chinese sis_nerdy_evening_scene1_v1_l_0576259e:

    # Sara "Let me have a look and see what multiplayer games I have."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:67
translate chinese sis_nerdy_evening_scene1_v1_l_1fc03e58:

    # Sara "Hmm... Medal of Duty? Call of Honour?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:68
translate chinese sis_nerdy_evening_scene1_v1_l_ab426d4d:

    # Sara "Oh! I have Street Brawler VII!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:69
translate chinese sis_nerdy_evening_scene1_v1_l_fbcb1d27:

    # MC "Anything works for me."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:70
translate chinese sis_nerdy_evening_scene1_v1_l_b6060e98:

    # Sara "Let’s do Street Brawler VII then. One vs one deathmatch!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:71
translate chinese sis_nerdy_evening_scene1_v1_l_0b369ff9:

    # MC "Sounds fun!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:74
translate chinese sis_nerdy_evening_scene1_v1_l_70d0a843:

    # Sara "Okay, there’s your controller. You’ve played before, right?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:75
translate chinese sis_nerdy_evening_scene1_v1_l_2e3c7a80:

    # MC "Thanks. Yeah, and I’m pretty damn good at it - so you better watch your back!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:76
translate chinese sis_nerdy_evening_scene1_v1_l_eda302b6:

    # Sara "Well, since you’re that confident, how about we change up the rules a bit?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:77
translate chinese sis_nerdy_evening_scene1_v1_l_3ec55d34:

    # MC "What are you thinking? Betting some money?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:80
translate chinese sis_nerdy_evening_scene1_v1_l_cce2ff7a:

    # Sara "The loser has to.... take off... a piece of clothing, each time they die."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:81
translate chinese sis_nerdy_evening_scene1_v1_l_ee6b7632:

    # Sara "(This is my revenge for trying to steal my panties!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:82
translate chinese sis_nerdy_evening_scene1_v1_l_608842ae:

    # MC "(Wait? WHAT?!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:83
translate chinese sis_nerdy_evening_scene1_v1_l_df0f7dbd:

    # MC "S-Sorry, I didn’t hear you right, there. What did you say?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:84
translate chinese sis_nerdy_evening_scene1_v1_l_c6cef2b8:

    # Sara "Each time your character dies in-game, you have to lose a piece of clothing. Deal?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:87
translate chinese sis_nerdy_evening_scene1_v1_l_6191a341:

    # MC "(Holy shit! I must be dreaming! This can’t actually be happening!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:88
translate chinese sis_nerdy_evening_scene1_v1_l_8dd28609:

    # MC "Hell yeah, that’s a deal."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:89
translate chinese sis_nerdy_evening_scene1_v1_l_f2b7c94f:

    # MC "You do realise that this means you’re about to be stripped naked? When it comes to the Street Brawler series - I’m a freakin’ pro."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:92
translate chinese sis_nerdy_evening_scene1_v1_l_81738234:

    # Sara "Uh huh, I’m sure you are."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:93
translate chinese sis_nerdy_evening_scene1_v1_l_59504933:

    # Sara "Take a good look right now - because this is the closest you’re gonna get to seeing my tits today."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:94
translate chinese sis_nerdy_evening_scene1_v1_l_9c22175e:

    # MC "(Damn, I can’t wait to see her boobs today. There’s no way I’m losing to a girl! I’ve been playing the Street Brawler series since I was in kindergarden!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:97
translate chinese sis_nerdy_evening_scene1_v1_l_87f4eb3d:

    # Console "READY! SET! FIGHT!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:98
translate chinese sis_nerdy_evening_scene1_v1_l_1ca5d425:

    # MC "(Damn! She’s quick!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:99
translate chinese sis_nerdy_evening_scene1_v1_l_992ad77b:

    # Sara "What’s the matter? You’re looking a bit stressed!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:100
translate chinese sis_nerdy_evening_scene1_v1_l_4164c8e0:

    # Sara "Hehe... Why haven’t you hit me yet?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:101
translate chinese sis_nerdy_evening_scene1_v1_l_e2af5310:

    # MC "Because you aren’t giving me a chance to-"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:102
translate chinese sis_nerdy_evening_scene1_v1_l_e1593d27:

    # Console "Player 2 has been defeated!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:103
translate chinese sis_nerdy_evening_scene1_v1_l_12b382be:

    # MC "Dammit!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:107
translate chinese sis_nerdy_evening_scene1_v1_l_57e51f5d:

    # "(Fifteen Minutes Later...)"
    ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:112
translate chinese sis_nerdy_evening_scene1_v1_l_3a362944:

    # Sara "Hehe! Are you sure you want to go for one more round? You’ve only got your boxers left!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:114
translate chinese sis_nerdy_evening_scene1_v1_l_f19fc50d:

    # MC "It isn’t over yet! I was just going easy on you because you’re my sister."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:116
translate chinese sis_nerdy_evening_scene1_v1_l_83ffbad8:

    # MC "It isn’t over yet! I was just going easy on you because we’re friends!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:117
translate chinese sis_nerdy_evening_scene1_v1_l_d145ac12:

    # Sara "Suuuuure!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:120
translate chinese sis_nerdy_evening_scene1_v1_l_0360c9bf:

    # "(Five Minutes Later...)"
    ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:123
translate chinese sis_nerdy_evening_scene1_v1_l_e1593d27_1:

    # Console "Player 2 has been defeated!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:124
translate chinese sis_nerdy_evening_scene1_v1_l_a236be8f:

    # Console "Player 1 has broken a new killstreak record!"
    Console ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:125
translate chinese sis_nerdy_evening_scene1_v1_l_0ec0d862:

    # Sara "Woohoo!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:128
translate chinese sis_nerdy_evening_scene1_v1_l_27b50ef5:

    # Sara "Don’t worry, [player_name]. You don’t have to take your underwear off too."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:129
translate chinese sis_nerdy_evening_scene1_v1_l_fbfa7781:

    # Sara "I think you’ve already been humiliated enough! Hehe!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:130
translate chinese sis_nerdy_evening_scene1_v1_l_1e383710:

    # MC "Fair is fair, we agreed to the rules before we started."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:131
translate chinese sis_nerdy_evening_scene1_v1_l_84962fa8:

    # Sara "Wait - you're not seriously going to-"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:137
translate chinese sis_nerdy_evening_scene1_v1_l_d2461f9e:

    # Sara "Oh, my God! You’re hard!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:138
translate chinese sis_nerdy_evening_scene1_v1_l_946ff154:

    # Sara "Wh-Why is it so hard?!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:139
translate chinese sis_nerdy_evening_scene1_v1_l_2d3893c5:

    # MC "(Maybe because I want to, fuck you silly?)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:140
translate chinese sis_nerdy_evening_scene1_v1_l_f8d7ba9d:

    # MC "It’s because you’re looking at it right now. Cocks tend to get hard when they’re given attention."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:143
translate chinese sis_nerdy_evening_scene1_v1_l_0b87f0f1:

    # MC "Right - what happens now then?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:144
translate chinese sis_nerdy_evening_scene1_v1_l_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:145
translate chinese sis_nerdy_evening_scene1_v1_l_16d8373f:

    # MC "Is it one more round to decide the winner? Or have you won, since I’m naked?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:148
translate chinese sis_nerdy_evening_scene1_v1_l_340cdc9f:

    # MC "(She’s not listening to me anymore... She’s just staring at my cock.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:149
translate chinese sis_nerdy_evening_scene1_v1_l_336d31cf:

    # MC "(I wonder if it is the first time she’s ever seen one. She seems to be extremely interested in it!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:150
translate chinese sis_nerdy_evening_scene1_v1_l_ef449047:

    # Sara "(Wow... It’s so big and hard... I don’t know why, but I really want to touch it.)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:153
translate chinese sis_nerdy_evening_scene1_v1_l_f5db47cb:

    # MC "So... uhh... I’m gonna go and get dressed now."
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:155
translate chinese sis_nerdy_evening_scene1_v1_l_9d1e8d68:

    # MC "last thing we want is, Mom or Dad, walking in on us right now!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:157
translate chinese sis_nerdy_evening_scene1_v1_l_0219f28b:

    # MC "Last thing we want is, Linda or Bob, walking in on us right now!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:161
translate chinese sis_nerdy_evening_scene1_v1_l_09d06ab8:

    # "*Click*"
    ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:168
translate chinese sis_nerdy_evening_scene1_v1_l_c108ecce:

    # Sara "(Got it! I couldn’t let this just be a memory!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:169
translate chinese sis_nerdy_evening_scene1_v1_l_08b0b6b0:

    # MC "What the hell, Sara! Did you just take a picture of my dick?"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:170
translate chinese sis_nerdy_evening_scene1_v1_l_cc17959a:

    # Sara "N-No?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:171
translate chinese sis_nerdy_evening_scene1_v1_l_93e93001:

    # MC "Yes you did! I can see you taking a photo right now! Delete it!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:175
translate chinese sis_nerdy_evening_scene1_v1_l_d72f993c:

    # Sara "You’re gonna have to catch me first! Hehe!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:176
translate chinese sis_nerdy_evening_scene1_v1_l_b3d1ccc2:

    # MC "Come back here!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:177
translate chinese sis_nerdy_evening_scene1_v1_l_bb781fb4:

    # MC "Seriously, Sara! Give me your phone!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:179
translate chinese sis_nerdy_evening_scene1_v1_l_51453c5a:

    # Sara "I-If you don’t stop chasing me, I’ll call Mom!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:181
translate chinese sis_nerdy_evening_scene1_v1_l_2efb84c9:

    # Sara "I-If you don’t stop chasing me, I’ll call Linda!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:183
translate chinese sis_nerdy_evening_scene1_v1_l_a3af909b:

    # MC "Gotcha!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:184
translate chinese sis_nerdy_evening_scene1_v1_l_537b1751:

    # Sara "[player_name], stop! Seriously!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:185
translate chinese sis_nerdy_evening_scene1_v1_l_1eb039b8:

    # MC "Delete that picture from your phone!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:186
translate chinese sis_nerdy_evening_scene1_v1_l_24fc059b:

    # Sara "I’m not talking about this with you!"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:187
translate chinese sis_nerdy_evening_scene1_v1_l_b16ad2d1:

    # MC "Well, maybe I’ll just have to-"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:188
translate chinese sis_nerdy_evening_scene1_v1_l_f7786052:

    # Sara "Umm... [player_name]?"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:191
translate chinese sis_nerdy_evening_scene1_v1_l_74d5de99:

    # MC "(Oh shit! My cock pressed right up against her bare belly. It feels so warm against the tip of my cock.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:192
translate chinese sis_nerdy_evening_scene1_v1_l_7a90e016:

    # Sara "(Oh, my God! His cock is touching me!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:193
translate chinese sis_nerdy_evening_scene1_v1_l_a1cff58b:

    # MC "I- I- I’m sorry... I’ll go now!"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:196
translate chinese sis_nerdy_evening_scene1_v1_l_047a29ad:

    # MC "(Crap, that got weird, REALLY fast.)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:197
translate chinese sis_nerdy_evening_scene1_v1_l_6afb1e15:

    # MC "(I hope she’s not too angry at me for pushing my cock against her. I didn’t mean to!)"
    MC ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:198
translate chinese sis_nerdy_evening_scene1_v1_l_95f748cf:

    # Sara "(That was intense... I have to check this picture out again when he leaves!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:201
translate chinese sis_nerdy_evening_scene1_v1_l_aded0c65:

    # Sara "(Wow... It’s sooo big!)"
    Sara ""

# game/scripts/home/sara_room/evening/scenes/sara_room_evening_scene1_and_scene2_v1.rpy:202
translate chinese sis_nerdy_evening_scene1_v1_l_80a46c68:

    # Sara "(I have to show Lily! She won’t believe this!)"
    Sara ""

