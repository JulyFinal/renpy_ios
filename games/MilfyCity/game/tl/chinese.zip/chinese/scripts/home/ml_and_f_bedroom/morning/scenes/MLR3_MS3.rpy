﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:21
translate chinese MLR3_MS3_126ca4a7:

    # MC "(That’s [Mom_name]’s suitcase. The last time I saw that bag was when she went to a conference in Toronto.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:22
translate chinese MLR3_MS3_a72ad773:

    # MC "(I wonder if she’s going on another business trip.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:23
translate chinese MLR3_MS3_cdb85123:

    # MC "Hey, [Mom_name] - are you going somewhere with work?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:27
translate chinese MLR3_MS3_0092babf:

    # Mom "Heh, thankfully not! I’ve had enough of that damned place for a while. Besides, those conferences are basically excuses to have an expenses-paid holiday."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:28
translate chinese MLR3_MS3_3143a3ce:

    # MC "What’s in the bag, then?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:29
translate chinese MLR3_MS3_e596b694:

    # Mom "Clothes, shower gel, towels. Just the essentials."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:33
translate chinese MLR3_MS3_725d6209:

    # MC "Are you going on holiday?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:34
translate chinese MLR3_MS3_10c4c307:

    # Mom "... Yeah, I guess you could say that."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:35
translate chinese MLR3_MS3_b7d92adf:

    # MC "(Wait a minute... [Mom_name] and [Dad_name] have been arguing a lot, lately. Could it be that [Mom_name] is moving out?!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:36
translate chinese MLR3_MS3_65a2735a:

    # MC "Where are you headed?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:40
translate chinese MLR3_MS3_5bc001aa:

    # Mom "That’s a secret right now - but don’t you worry: when the time comes you’ll know what’s happening."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:41
translate chinese MLR3_MS3_0a25959d:

    # MC "(Fuck... I think she’s leaving. This is gonna destroy [Dad_name] when he finds out. He’s still madly in love with her.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:42
translate chinese MLR3_MS3_2332a911:

    # Mom "Aww, don’t look so worried. This will be a good surprise, I promise!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:46
translate chinese MLR3_MS3_ee616421:

    # MC "How much stuff have you got in there?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:47
translate chinese MLR3_MS3_68d57610:

    # Mom "Mostly just the essentials for a couple of days."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:48
translate chinese MLR3_MS3_7c6967c9:

    # MC "When are you leaving?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:52
translate chinese MLR3_MS3_f7f4c13e:

    # Mom "You ask A LOT of questions, don’t you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:53
translate chinese MLR3_MS3_68b124f0:

    # Mom "You’ll find out when the time comes. Right now, all you need to know is that I’m packing a bag for myself."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:54
translate chinese MLR3_MS3_9368a412:

    # MC "(Should I tell [Dad_name] about this? Is she going to talk to him before she goes? Or will she just disappear one day?)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:58
translate chinese MLR3_MS3_c399a4f8:

    # Mom "Oh, and before you think of asking your sisters or father about this... don’t."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:60
translate chinese MLR3_MS3_cd360d00:

    # Mom "Oh, and before you think of asking Sara or Caroline or Bob about this... don’t."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:62
translate chinese MLR3_MS3_9516ee91:

    # Mom "This is a secret between you and me. Got it? You weren’t even supposed to see me packing."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:63
translate chinese MLR3_MS3_197d4544:

    # MC "But I-"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:64
translate chinese MLR3_MS3_d69f4ac8:

    # Mom "I’m serious, [player_name]: not a word to Sara or Caroline. Nobody, okay? Promise me."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:65
translate chinese MLR3_MS3_ac8bd90f:

    # MC "Fine, I promise. I won’t tell anyone."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:66
translate chinese MLR3_MS3_cb2d58f9:

    # Mom "Good... You won’t have to keep this secret for long, I promise."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS3.rpy:67
translate chinese MLR3_MS3_efaf347e:

    # MC "(She clearly doesn't want to talk about it at home. Maybe tomorrow I should visit her at her workplace?)"
    MC ""

