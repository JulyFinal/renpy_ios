﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:11
translate chinese caroline_salon_evening_scene1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:21
translate chinese caroline_salon_evening_scene1_label_3b6891ac:

    # MC "Hey, Caroline!"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:22
translate chinese caroline_salon_evening_scene1_label_afa261ac:

    # Caroline "Hiiii!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:23
translate chinese caroline_salon_evening_scene1_label_1f73859d:

    # MC "Are you not getting dressed?"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:24
translate chinese caroline_salon_evening_scene1_label_b4011129:

    # Caroline "What do you mean? I’m wearing a top."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:25
translate chinese caroline_salon_evening_scene1_label_7156f610:

    # MC "(Huh, I guess she considers a pair of panties “casual clothes”.)"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:26
translate chinese caroline_salon_evening_scene1_label_2dc6af1c:

    # MC "Nevermind - How’re you doing?"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:27
translate chinese caroline_salon_evening_scene1_label_031299cb:

    # Caroline "I’ve got a few things on my mind - but they’re not worth complaining about."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:28
translate chinese caroline_salon_evening_scene1_label_635a9960:

    # Caroline "How about you? What’re you doing at home at this hour? A guy your age should be out partying."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:33
translate chinese caroline_salon_evening_scene1_label_65a0dac0:

    # MC "I just came home to see the best sister in the world."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:34
translate chinese caroline_salon_evening_scene1_label_fa21b678:

    # Caroline "Oh really? How sweet."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:35
translate chinese caroline_salon_evening_scene1_label_188d9c1e:

    # MC "Yeah, I still haven’t found Sara yet though. Haha!"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:38
translate chinese caroline_salon_evening_scene1_label_7378ca0d:

    # Caroline "Ahh, you bastard! Haha!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:39
translate chinese caroline_salon_evening_scene1_label_3b043047:

    # MC "Sorry, Caroline. Couldn’t resist."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:47
translate chinese caroline_salon_evening_scene1_label_9ca1ffa9:

    # MC "I just came home to see my best friend in the world."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:48
translate chinese caroline_salon_evening_scene1_label_fa21b678_1:

    # Caroline "Oh really? How sweet."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:49
translate chinese caroline_salon_evening_scene1_label_188d9c1e_1:

    # MC "Yeah, I still haven’t found Sara yet though. Haha!"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:52
translate chinese caroline_salon_evening_scene1_label_7378ca0d_1:

    # Caroline "Ahh, you bastard! Haha!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:53
translate chinese caroline_salon_evening_scene1_label_3b043047_1:

    # MC "Sorry, Caroline. Couldn’t resist."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:61
translate chinese caroline_salon_evening_scene1_label_82e42237:

    # MC "Yeah... I’m not really getting invited out to any parties recently."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:62
translate chinese caroline_salon_evening_scene1_label_f1ed7a69:

    # MC "Probably has to do with that Ms. Celia fiasco."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:63
translate chinese caroline_salon_evening_scene1_label_443abfdd:

    # Caroline "Oh God... I’m sorry to hear that."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:66
translate chinese caroline_salon_evening_scene1_label_ca194aee:

    # Caroline "I wish I could give you some advice that would fix this."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:67
translate chinese caroline_salon_evening_scene1_label_d0d988ac:

    # Caroline "But... honestly, don’t even know where to begin."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:68
translate chinese caroline_salon_evening_scene1_label_00010612:

    # MC "It’s okay, Caroline. Thanks anyway."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:76
translate chinese caroline_salon_evening_scene1_label_99dbd5e1:

    # MC "I just came home to chill and relax for a while."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:77
translate chinese caroline_salon_evening_scene1_label_d35d682d:

    # Caroline "Coooool. Have fun with that."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:78
translate chinese caroline_salon_evening_scene1_label_484567d6:

    # MC "Thanks Caroline. Are you up to much?"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:81
translate chinese caroline_salon_evening_scene1_label_3b46a2ab:

    # Caroline "Just researching marketing ideas. Strategic placement of adverts, best signage, online banner ads etc."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:82
translate chinese caroline_salon_evening_scene1_label_f3184a6e:

    # Caroline "Y’know [player_name], I have to tell you..."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:85
translate chinese caroline_salon_evening_scene1_label_03d74fc3:

    # Caroline "I never thought running a business would be this hard!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:86
translate chinese caroline_salon_evening_scene1_label_ab8b134a:

    # Caroline "I wish there was some easy way to crowdfund a business. Perhaps with a monthly subscription for users, y’know? Like a website!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:87
translate chinese caroline_salon_evening_scene1_label_8c5974d8:

    # Caroline "Heck - such a system could even be used to fund, small indie games developers and artists!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:90
translate chinese caroline_salon_evening_scene1_label_22164e31:

    # Caroline "Am I being crazy, [player_name]? Or does this sound like a good idea?"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:93
translate chinese caroline_salon_evening_scene1_label_189dc93a:

    # Caroline "Actually, don’t answer that! It would just be another bad financial investment from me!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:94
translate chinese caroline_salon_evening_scene1_label_503f3864:

    # MC "Don’t be too harsh on yourself, Caroline!"
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:95
translate chinese caroline_salon_evening_scene1_label_91c2db0b:

    # MC " It sounds like a good idea - but you’d probably have a LOT of work on your hands moderating such a large website."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:96
translate chinese caroline_salon_evening_scene1_label_ae7ec26c:

    # Caroline "True. Plus, it would probably get flooded with perverts making dirty sex games."
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:97
translate chinese caroline_salon_evening_scene1_label_55bbc48e:

    # MC "You’re better off just sticking with your clothes shop."
    MC ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:100
translate chinese caroline_salon_evening_scene1_label_5e18fa46:

    # Caroline "Yeah, you’re right, [player_name]. Thanks!"
    Caroline ""

# game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:101
translate chinese caroline_salon_evening_scene1_label_8e7816d6:

    # MC "Cool. See you later, Caroline!"
    MC ""

translate chinese strings:

    # game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:30
    old "I came home to see the best sister in the world."
    new ""

    # game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:30
    old "I came home to see my best friend in the world."
    new ""

    # game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:30
    old "Nah, no one’s inviting me out to any parties after that fiasco with Ms. Celia."
    new ""

    # game/scripts/home/salon/evening/scenes/caroline_salon_evening_scene1.rpy:30
    old "I just came home to chill."
    new ""

