﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:137
translate chinese MLR3_NS2_acdce1cd:

    # MC "Zzz..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:138
translate chinese MLR3_NS2_9588797f:

    # MC "*Snore*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:142
translate chinese MLR3_NS2_79e038e5:

    # MC "Zzz...."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:144
translate chinese MLR3_NS2_48c1e588:

    # "*Creak*"
    ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:149
translate chinese MLR3_NS2_14803739:

    # Mom "(Why are these damn floorboards so creaky? It was difficult enough creeping in here, without waking Sara or Caroline!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:150
translate chinese MLR3_NS2_1dd27504:

    # MC "Zzz... *Snore*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:154
translate chinese MLR3_NS2_bea3b2c4:

    # Mom "(God... I’m so damn horny... I hope he doesn't mind me waking him up, like this.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:155
translate chinese MLR3_NS2_fb624e63:

    # Mom "(Okay... here goes nothing.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:159
translate chinese MLR3_NS2_489200bc:

    # Mom "(My heart’s racing right now. Why do I feel so worried?! It’s not like we haven’t done this before.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:160
translate chinese MLR3_NS2_9588797f_1:

    # MC "*Snore*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:164
translate chinese MLR3_NS2_0506030e:

    # Mom "(I guess I’ll wake him up with a gentle kiss.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:165
translate chinese MLR3_NS2_a6f6858c:

    # Mom "(It’s how I’d like to be woken up, after all.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:169
translate chinese MLR3_NS2_89024f27:

    # Mom "*Whispered* You’re so handsome, [player_name]."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:171
translate chinese MLR3_NS2_7809c36d:

    # Mom "*Whispered* I can’t believe I have such a beautiful son."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:173
translate chinese MLR3_NS2_aee10932:

    # Mom "*Whispered* I can’t believe I have such a beautiful guy in my life."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:177
translate chinese MLR3_NS2_08a6cfb7:

    # Mom "*Whispered* I love you, [player_name]. I really do."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:178
translate chinese MLR3_NS2_3aff1f32:

    # Mom "*Whispered* You have no idea how much happier you have made me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:182
translate chinese MLR3_NS2_6e6d3ea6:

    # Mom "*Mwah*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:183
translate chinese MLR3_NS2_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:184
translate chinese MLR3_NS2_302a3f87:

    # Mom "(His lips are so soft...)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:188
translate chinese MLR3_NS2_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:189
translate chinese MLR3_NS2_acdce1cd_1:

    # MC "Zzz..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:193
translate chinese MLR3_NS2_10c2f82b:

    # MC "(Ugh... I’m having another one of those erotic dreams...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:194
translate chinese MLR3_NS2_f8404175:

    # MC "(Wait... Why is my mouth so warm?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:198
translate chinese MLR3_NS2_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:199
translate chinese MLR3_NS2_2ffa53de:

    # MC "(Is someone's tongue in my mouth?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:203
translate chinese MLR3_NS2_abd39c81:

    # MC "Hmm?!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:205
translate chinese MLR3_NS2_56911e09:

    # MC "(Holy shit! [Mom_name]?!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:206
translate chinese MLR3_NS2_1fd97556:

    # Mom "(Ahh! He finally woke up!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:210
translate chinese MLR3_NS2_5acc15c8:

    # Mom "I thought you’d never wake up. You must have been in a pretty deep sleep."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:211
translate chinese MLR3_NS2_6da8e0df:

    # MC "Uh huh... Sorry, I wasn’t expecting you tonight."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:213
translate chinese MLR3_NS2_497e5cc8:

    # Mom "Listen, your father is still at work... and I want to do it."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:215
translate chinese MLR3_NS2_0e513183:

    # Mom "Listen, Bob is still at work... and I want to do it."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:216
translate chinese MLR3_NS2_5085aa09:

    # MC "You mean, like have sex, right now?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:223
translate chinese MLR3_NS2_29cc2c58:

    # Mom "Yes! Now let’s get these clothes and blankets off you."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:224
translate chinese MLR3_NS2_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:225
translate chinese MLR3_NS2_e122d104:

    # Mom "There we go!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:229
translate chinese MLR3_NS2_bcccaac2:

    # Mom "We won’t be needing THESE things either!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:230
translate chinese MLR3_NS2_28a42246:

    # MC "(Holy shit! This is actually happening again! I didn’t realise [Dad_name] would be away for so long!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:231
translate chinese MLR3_NS2_ceafef25:

    # Mom "Well? What are you waiting for? I’m all ready for you.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:235
translate chinese MLR3_NS2_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:236
translate chinese MLR3_NS2_28c4f346:

    # Mom "You like what you see?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:237
translate chinese MLR3_NS2_9d2b34eb:

    # MC "Y-Yeah! It’s great! You’re great!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:241
translate chinese MLR3_NS2_fcf10a01:

    # Mom "I just couldn’t hold myself back any longer. I get so horny, all the time, and I haven’t been able to stop thinking about fucking your cock, since that beach getaway we had together."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:242
translate chinese MLR3_NS2_cbb22d44:

    # Mom "Please... just fuck me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:243
translate chinese MLR3_NS2_e51f2269:

    # MC "I haven’t got a condom..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:247
translate chinese MLR3_NS2_b48f688b:

    # Mom "Relax - it’ll be fine. We’re wasting time! Just hurry up and stick your cock inside me."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:248
translate chinese MLR3_NS2_c47346e8:

    # MC "Alright, as long as you’re sure it’s safe."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:249
translate chinese MLR3_NS2_cb155f30:

    # Mom "I’m at a safe time of the month. You can cum inside - don't worry about it."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:253
translate chinese MLR3_NS2_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:255
translate chinese MLR3_NS2_e30a9802:

    # Mom "Mmm... yes... Just like that..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:256
translate chinese MLR3_NS2_9f9cdb91:

    # MC "(Her pussy is so wet right now, her vulva feels like a pair of lips, sucking on my cock.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:260
translate chinese MLR3_NS2_98dfc4dc:

    # MC "Mmm! Yes! Ugh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:261
translate chinese MLR3_NS2_3a45e9c4:

    # Mom "Oh... wow... "
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:262
translate chinese MLR3_NS2_ed81bfa1:

    # Mom "(My mind’s melting, right now... this feels sooooo good!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:266
translate chinese MLR3_NS2_aa1d59ab:

    # Mom "D-Deeper! Push it ALL THE WAY in!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:267
translate chinese MLR3_NS2_df0c049f:

    # Mom "I want to feel your cock, all the way inside me, right up to my cervix!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:268
translate chinese MLR3_NS2_73de22f3:

    # Mom "AHH!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:272
translate chinese MLR3_NS2_4bb9ba19:

    # MC "(Fuck... this feels so good! I really missed this, after we left the beach house.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:273
translate chinese MLR3_NS2_4d8c589a:

    # Mom "Mmm! Oh!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:277
translate chinese MLR3_NS2_b01d1396:

    # MC "Spread your legs a little more, [Mom_name]. I just need to get a better angle."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:279
translate chinese MLR3_NS2_9845568a:

    # Mom "Uh huh! Whatever you want! Ah!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:281
translate chinese MLR3_NS2_bfcc03a9:

    # MC "There we go. Perfect. I can fuck you properly now!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:285
translate chinese MLR3_NS2_4a314bce:

    # MC "Ugh! Hnng!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:287
translate chinese MLR3_NS2_0cf139fb:

    # Mom "Ohh! Ahh! Yes!! YES! Oh my God! Yes!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:289
translate chinese MLR3_NS2_ffabef4d:

    # Mom "Holy fuck!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:293
translate chinese MLR3_NS2_22488aa0:

    # Mom "(This is the best sex I have ever had, in my life! I wonder why?)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:294
translate chinese MLR3_NS2_3a0397a6:

    # Mom "(Is it to do with the girth or length of his cock?)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:295
translate chinese MLR3_NS2_93eb55a0:

    # Mom "(Maybe it’s got to do with the angle he’s screwing me at?)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:299
translate chinese MLR3_NS2_c0d1e1a1:

    # Mom "(Perhaps it’s just, the knowledge that I’m being fucked by my own son.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:301
translate chinese MLR3_NS2_abc48810:

    # Mom "(Perhaps it’s just the knowledge that I’m being fucked by a guy so much younger than I am.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:302
translate chinese MLR3_NS2_375e4e4b:

    # Mom "(Judy once told me that the brain is the most intense sexual organ... perhaps its true.)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:303
translate chinese MLR3_NS2_0d7c9e06:

    # Mom "Ah! Ahh! AHH!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:307
translate chinese MLR3_NS2_e0520807:

    # Mom "YEEEEESSSSS!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:308
translate chinese MLR3_NS2_ffdb0bfc:

    # MC "Ugh! Uh! Ahh! Oh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:309
translate chinese MLR3_NS2_88cb71c5:

    # Mom "Suck on my tits! Quick!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:313
translate chinese MLR3_NS2_cd7f6e60:

    # MC "*Suck Suck*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:314
translate chinese MLR3_NS2_fbb0fa01:

    # Mom "Mmm! Just like that! Ugh! Ahh!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:315
translate chinese MLR3_NS2_13f50765:

    # Mom "Y-You can bite them a bit, if you want! J-Just don’t be too oohhhh hard!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:319
translate chinese MLR3_NS2_1060eba7:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:320
translate chinese MLR3_NS2_7045618c:

    # Mom "AH! YES! OHHH FUCK! I’M GONNA CUM! I’M CUMMING! AHHHHHHH!!!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:321
translate chinese MLR3_NS2_4399b9a7:

    # MC "(That’s one orgasm for [Mom_name] so far!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:325
translate chinese MLR3_NS2_b0b5b190:

    # Mom "*Pant Pant*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:326
translate chinese MLR3_NS2_8fa7af89:

    # Mom "W-Wow... That was good."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:327
translate chinese MLR3_NS2_c13231b6:

    # MC "Heh, I’m glad you’re enjoying this as much as I am."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:331
translate chinese MLR3_NS2_e0dcdc6c:

    # MC "I think I’m gonna cum pretty soon too, though!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:332
translate chinese MLR3_NS2_d189d5c2:

    # Mom "Aww, really? We were just getting started!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:333
translate chinese MLR3_NS2_79d51762:

    # MC "I know, but your pussy just feels so fucking good!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:337
translate chinese MLR3_NS2_c69bf8f7:

    # Mom "Slow down, a bit. Take a couple of slow deep thrusts."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:338
translate chinese MLR3_NS2_074175ea:

    # Mom "I’m rarely going to get the chance to properly fuck you, so when we do get our opportunities, we’re gonna make the most of them."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:339
translate chinese MLR3_NS2_fdfd450f:

    # MC "Okay, [Mom_name]. No problem. Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:343
translate chinese MLR3_NS2_819799f8:

    # Mom "I’m serious. If you cum right now, I’ll... ground you for a week!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:345
translate chinese MLR3_NS2_0303181b:

    # Mom "Good luck explaining the reasoning behind that one, to your sisters! Haha!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:347
translate chinese MLR3_NS2_cb07a7b6:

    # Mom "I’m serious. If you cum right now, I’ll... raise the rent for all of you - starting next week! "
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:349
translate chinese MLR3_NS2_d3f02e30:

    # Mom "Good luck explaining the reasoning behind that one to Sara and Caroline! Haha!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:352
translate chinese MLR3_NS2_fd9199dd:

    # MC "Haha, that’s just cruel, [Mom_name]!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:356
translate chinese MLR3_NS2_2f52473c:

    # Mom "Ohh... fuck... Mmm!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:358
translate chinese MLR3_NS2_e2241d62:

    # Mom "That’s the spot, Baby! Right there!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:359
translate chinese MLR3_NS2_caabc932:

    # MC "Hnng... Fuck, I’m so close to cumming!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:364
translate chinese MLR3_NS2_a18dfd5d:

    # MC "(It gets tighter and hotter, the deeper I go! It would feel amazing to just, blow my load, deep inside her, right now.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:365
translate chinese MLR3_NS2_f3289f18:

    # Mom "Ah! Ahhhh!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:366
translate chinese MLR3_NS2_02d18261:

    # MC "Ah! Fuck! Mmm! Hnnng!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:370
translate chinese MLR3_NS2_71d575cb:

    # Mom "You sound like you’re about to cum! Pull out and we’ll switch up positions."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:371
translate chinese MLR3_NS2_7338053c:

    # Mom "It’ll give you a chance to regain some stamina, before round two."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:372
translate chinese MLR3_NS2_befc87ba:

    # MC "Sure. What position are you thinking? Doggy style?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:376
translate chinese MLR3_NS2_b08230c6:

    # Mom "Nah, nothing that basic. Let’s try it sideways."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:377
translate chinese MLR3_NS2_00f7a73e:

    # MC "Ohh, this looks interesting."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:378
translate chinese MLR3_NS2_18c39297:

    # Mom "Climb behind me and fuck me from behind."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:382
translate chinese MLR3_NS2_2cfc15b1:

    # Mom "Just... make sure you aim your cock at the right hole."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:383
translate chinese MLR3_NS2_14d41da1:

    # Mom "I’m down for anal, but only when I can prepare for it, with lube!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:384
translate chinese MLR3_NS2_4e7b79f6:

    # MC "Haha! No problem, [Mom_name]. I’ll be careful I get the right hole."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:388
translate chinese MLR3_NS2_b105e7ab:

    # Mom "You’re DANGEROUSLY close to the wrong one, right now!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:389
translate chinese MLR3_NS2_f0a44a86:

    # MC "I know, I know! Don’t worry about it - I’ve got a hold of my dick."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:390
translate chinese MLR3_NS2_304654f7:

    # Mom "You better!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:394
translate chinese MLR3_NS2_a3da8621:

    # Mom "Ah!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:395
translate chinese MLR3_NS2_ac780dec:

    # MC "See? What did I tell you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:399
translate chinese MLR3_NS2_473a9c18:

    # MC "Slipped in like a glove. See?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:401
translate chinese MLR3_NS2_463e5c7c:

    # Mom "Mmm! Uh huh! Yeah!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:402
translate chinese MLR3_NS2_82bb72a1:

    # Mom "(This angle is perfect - he’s thrusting into my g-spot now!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:406
translate chinese MLR3_NS2_9d564a0a:

    # Mom "Ohh... Yes... right there!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:407
translate chinese MLR3_NS2_a117f745:

    # MC "Ugh... Fuck... I love you, [Mom_name]."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:408
translate chinese MLR3_NS2_488626ce:

    # Mom "I love you too, [player_name]."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:412
translate chinese MLR3_NS2_f0aac57c:

    # Mom "OHHH!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:414
translate chinese MLR3_NS2_dadc208c:

    # Mom "(God! He’s going so deep inside me! This feels soooo good!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:420
translate chinese MLR3_NS2_7cd21a98:

    # Mom "Ah! Ahh... Mmm! Ohhh!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:422
translate chinese MLR3_NS2_996783ae:

    # Mom "Don’t stop, [player_name]! Don’t stop fucking your mommy! You’re making me feel sooo good!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:424
translate chinese MLR3_NS2_d5eb38eb:

    # Mom "Don’t stop, [player_name]! Don’t stop fucking me! You’re making me feel sooo good!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:428
translate chinese MLR3_NS2_b0dbea4a:

    # MC "Ugh! Ah... Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:429
translate chinese MLR3_NS2_70d4cd36:

    # Mom "Yes! Oh! Yes! Right there! That’s the spot!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:434
translate chinese MLR3_NS2_2bef2142:

    # Mom "Kiss me! I want to feel your lips, while you fuck me!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:435
translate chinese MLR3_NS2_c453b06c:

    # MC "(She’s really getting into this! I’ve never seen her so excited before!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:439
translate chinese MLR3_NS2_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:440
translate chinese MLR3_NS2_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:441
translate chinese MLR3_NS2_9318227b:

    # Mom "MMMM!!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:445
translate chinese MLR3_NS2_1df066a7:

    # Mom "(Oh God! He’s going, so deep inside me! This feels sooooo good!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:448
translate chinese MLR3_NS2_0bb9d7e8:

    # MC "([Mom_name]’s pussy is quivering around my cock! She’s about to cum again!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:450
translate chinese MLR3_NS2_1a6efd55:

    # MC "(Her pussy is quivering around my cock! She’s about to cum again!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:451
translate chinese MLR3_NS2_601cd872:

    # Mom "MMM! MMMMMM!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:455
translate chinese MLR3_NS2_66c9ea5e:

    # Mom "D-Don’t stop! Keep going! AHHH!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:456
translate chinese MLR3_NS2_31e941ef:

    # MC "Ugh! Hnnng! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:460
translate chinese MLR3_NS2_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:461
translate chinese MLR3_NS2_b1141087:

    # Mom "Mmm! MMMMM!!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:465
translate chinese MLR3_NS2_6ecbbbc0:

    # MC "I’m gonna cum!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:466
translate chinese MLR3_NS2_3c73ccd7:

    # Mom "Do it inside me! Cum in my pussy!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:467
translate chinese MLR3_NS2_09681933:

    # Mom "I want to feel your hot cum, filling me up!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:471
translate chinese MLR3_NS2_1f5671ab:

    # MC "Hnnnngggg! AHHH!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:472
translate chinese MLR3_NS2_e9ca704e:

    # Mom "Ahhh! I’m CUMMING AGAIN! AYYAAAHHHHHH!!!!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:473
translate chinese MLR3_NS2_f4a0e1d2:

    # MC "([Mom_name]’s pussy is convulsing around my cock - she’ll milk me dry, if I don’t pull out!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:477
translate chinese MLR3_NS2_e0aa9078:

    # MC "I’m pulling out!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:486
translate chinese MLR3_NS2_ae3538c8:

    # MC "(It’s too risky to cum inside her!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:487
translate chinese MLR3_NS2_dc0e0b32:

    # Mom "Aww, okay..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:488
translate chinese MLR3_NS2_a96656a6:

    # MC "Hnnng! Ugh! Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:494
translate chinese MLR3_NS2_18fc3329:

    # MC "Yes! Hnng! FUCK! Ahhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:496
translate chinese MLR3_NS2_4ab63885:

    # Mom "Ohh God... Mmm... it feels sooo hot!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:505
translate chinese MLR3_NS2_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:506
translate chinese MLR3_NS2_57dc26bf:

    # Mom "Wow... That was... fucking amazing..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:515
translate chinese MLR3_NS2_con2_c609d275:

    # MC "That was incredible - thank you so much, [Mom_name]."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:516
translate chinese MLR3_NS2_con2_fa3be7f9:

    # Mom "I hope you enjoyed it as much as I did! Wow, I’m still trembling a little. Can you feel my hands shaking?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:517
translate chinese MLR3_NS2_con2_01661cdf:

    # MC "Haha, yeah, I can!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:521
translate chinese MLR3_NS2_con2_56688a68:

    # Mom "So... What do you say, ready for round two?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:522
translate chinese MLR3_NS2_con2_02a45c2b:

    # MC "Round two?!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:523
translate chinese MLR3_NS2_con2_d479dffe:

    # MC "There’s NO way I’ll be able to get hard again, anytime soon, after that!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:527
translate chinese MLR3_NS2_con2_de30b54c:

    # Mom "Oh..."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:528
translate chinese MLR3_NS2_con2_86ab5048:

    # MC "Sorry, [Mom_name]. Guys just don’t work like that... we can’t keep cumming multiple times, like you women can."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:532
translate chinese MLR3_NS2_con2_6b14744f:

    # Mom "That sounds like a challenge to me!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:533
translate chinese MLR3_NS2_con2_3fdfd822:

    # MC "W-Wait! It wasn’t a challenge, I was being serious!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:537
translate chinese MLR3_NS2_con2_834e97b2:

    # Mom "First things first: we need to get you hard again!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:538
translate chinese MLR3_NS2_con2_0329d9f5:

    # MC "Listen, [Mom_name], this isn’t going to work - I can’t just make it go-"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:539
translate chinese MLR3_NS2_con2_d678375c:

    # Mom "Take a look at my breasts... Do you not want me to rub them, all over your fat cock?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:543
translate chinese MLR3_NS2_con2_5d0a5d86:

    # MC "Oh yeah... They’re amazing."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:544
translate chinese MLR3_NS2_con2_7f00473a:

    # Mom "Imagine them, rubbing all up and down your body, massaging every single inch of it."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:548
translate chinese MLR3_NS2_con2_f9405048:

    # Mom "Aha! There we go!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:549
translate chinese MLR3_NS2_con2_52149836:

    # MC "Huh?! What?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:550
translate chinese MLR3_NS2_con2_8111c436:

    # Mom "Told you I’d get you hard! I’m gonna suck you off now. You gave me two orgams - it’s only fair that I return the favour!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:554
translate chinese MLR3_NS2_con2_651ce7e2:

    # MC "You don’t have to, [Mom_name]. I don’t want you stressing yourself out, about me."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:555
translate chinese MLR3_NS2_con2_021b2565:

    # Mom "I’m not stressing myself out."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:556
translate chinese MLR3_NS2_con2_bd2667ce:

    # Mom "I’m just, finally indulging a fantasy, I’ve kept repressed for years."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:560
translate chinese MLR3_NS2_con2_877a50c2:

    # Mom "I don’t know if you have any cum left in your balls, after that, but if you do, I’m gonna suck it ALL out."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:561
translate chinese MLR3_NS2_con2_a298f833:

    # MC "(That sounds so goddamn sexy!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:565
translate chinese MLR3_NS2_con2_8c20f667:

    # Mom "*Lick*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:566
translate chinese MLR3_NS2_con2_8130653d:

    # MC "Ahh... Oh...."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:570
translate chinese MLR3_NS2_con2_ea1a54f8:

    # Mom "(Hehe, I can feel his cock quivering, as I lick his glans. It must be extra sensitive, since he has cum already!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:571
translate chinese MLR3_NS2_con2_2dccbc5a:

    # Mom "*Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:572
translate chinese MLR3_NS2_con2_75a723b3:

    # MC "Mmm... You’re amazing at that, [Mom_name]."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:576
translate chinese MLR3_NS2_con2_3008810b:

    # MC "Fuck... Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:577
translate chinese MLR3_NS2_con2_4ed10276:

    # Mom "*Suck *Shlurp*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:581
translate chinese MLR3_NS2_con2_f1e73f4a:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:582
translate chinese MLR3_NS2_con2_003e4dfe:

    # MC "Ah! Ah! Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:586
translate chinese MLR3_NS2_con2_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:587
translate chinese MLR3_NS2_con2_b3044b58:

    # Mom "(His cock is so delicious! I could suck, on this bad boy, for hours!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:588
translate chinese MLR3_NS2_con2_9cf2a5a7:

    # Mom "(Sadly, I don’t think he’d be able to last, that long though!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:592
translate chinese MLR3_NS2_con2_f1a81d87:

    # MC "Mmm, don’t stop, [Mom_name]! Oh God... Fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:593
translate chinese MLR3_NS2_con2_4a26fb17:

    # MC "I never thought I’d... ahh.. get hard again, so quickly."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:594
translate chinese MLR3_NS2_con2_9c9667c1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:598
translate chinese MLR3_NS2_con2_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:599
translate chinese MLR3_NS2_con2_f5b3b18b:

    # MC "Ohhh! Yes! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:603
translate chinese MLR3_NS2_con2_3a4abcf6:

    # Mom "*Shlurp Shlurp*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:604
translate chinese MLR3_NS2_con2_d6da0ff5:

    # MC "I’m gonna cum again soon. Just keep doing th-"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:606
translate chinese MLR3_NS2_con2_48c1e588:

    # "*Creak*"
    ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:610
translate chinese MLR3_NS2_con2_5c1879d0:

    # MC "(Shit! Was that footsteps in the hallway?!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:612
translate chinese MLR3_NS2_con2_48c1e588_1:

    # "*Creak*"
    ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:613
translate chinese MLR3_NS2_con2_f1e73f4a_1:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:617
translate chinese MLR3_NS2_con2_f525097c:

    # MC "(It might just be Sara, going to the bathroom...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:619
translate chinese MLR3_NS2_con2_85d89482:

    # MC "(Maybe I should pull a blanket up, over [Mom_name], to hide her?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:620
translate chinese MLR3_NS2_con2_0ecd9b8f:

    # MC "(On the other hand, I don’t want to kill the mood for her. She was so excited to have sex with me tonight.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:627
translate chinese MLR3_NS2_con2_18f1c0a4:

    # Dad "Huh? (What are those weird noises coming from [player_name]’s room.)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:628
translate chinese MLR3_NS2_con2_06fc1a8a:

    # Dad "(I should probably check on him, to make sure he’s alright.)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:632
translate chinese MLR3_NS2_con2_9491107f:

    # MC "(Fuck it... Better safe, than sorry!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:633
translate chinese MLR3_NS2_con2_81a02b63:

    # MC "(This blanket should do fine - if Sara walks in, I’ll just come up with some lame excuse. If I’m lucky, they won’t even notice [Mom_name]’s body under the covers!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:637
translate chinese MLR3_NS2_con2_10367c21:

    # Dad "Hey there, champ. What are you doin-"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:638
translate chinese MLR3_NS2_con2_02c34e99:

    # MC "(Oh FUCK! How did [Dad_name] get home?!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:639
translate chinese MLR3_NS2_con2_40564029:

    # Mom "(HOLY SHIT! FUCK! When did he get back?!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:643
translate chinese MLR3_NS2_con2_fd3a675e:

    # MC "I... uh... um..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:644
translate chinese MLR3_NS2_con2_f972e0c1:

    # Mom "(Shit! SHIT! SHIT!)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:645
translate chinese MLR3_NS2_con2_522b1248:

    # MC "I can... explain! I was..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:649
translate chinese MLR3_NS2_con2_b406ae2d:

    # Dad "[player_name]! Oh, my God!"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:651
translate chinese MLR3_NS2_con2_7b04313c:

    # MC "D-Dad! I can explain! It’s NOT what you think it is!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:653
translate chinese MLR3_NS2_con2_b34df5fd:

    # MC "B-Bob! I can explain! It’s NOT what you think it is!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:656
translate chinese MLR3_NS2_con2_fccc86ca:

    # MC "I was just... and then she came in and..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:657
translate chinese MLR3_NS2_con2_1bd21e26:

    # MC "...um, I was... er... (Fuck! I’m just rambling like an idiot!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:661
translate chinese MLR3_NS2_con2_ba06d3fb:

    # Dad "Why didn’t you tell me you got yourself a girlfriend?!"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:662
translate chinese MLR3_NS2_con2_42096cee:

    # Dad "Nice job, champ! I can’t wait to meet the lucky lady, tomorrow morning."
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:664
translate chinese MLR3_NS2_con2_807a7e16:

    # Dad "You’ve done your Dad proud."
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:666
translate chinese MLR3_NS2_con2_6ce60519:

    # Dad "You’ve done me proud."
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:669
translate chinese MLR3_NS2_con2_7cce963f:

    # MC "Y-Yeah! You’re gonna... love her..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:670
translate chinese MLR3_NS2_con2_ef64b017:

    # Dad "I’ll leave, you two lovebirds, in peace. Goodnight, folks."
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:674
translate chinese MLR3_NS2_con2_9e1132f6:

    # MC "Jesus fucking Christ..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:675
translate chinese MLR3_NS2_con2_183745d4:

    # MC "Kill me now."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:676
translate chinese MLR3_NS2_con2_454e892a:

    # Mom "*Whispered* Is he gone?"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:677
translate chinese MLR3_NS2_con2_10d26591:

    # MC "Yeah... he’s gone."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:681
translate chinese MLR3_NS2_con2_9443de6a:

    # Dad "My, my, my! I never imagined he’d get lucky, so fast."
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:682
translate chinese MLR3_NS2_con2_b1c28e1f:

    # Dad "(In fact... it was taking so long, for him to get a girl, I was eighty percent sure he was a gay!)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:683
translate chinese MLR3_NS2_con2_d1540cf7:

    # Dad "I was SO close to bringing home that gay fellow Tim in accounting to meet [player_name]. Good thing I didn’t jump the gun!)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:684
translate chinese MLR3_NS2_con2_e2747dd0:

    # Dad "(Good for him, good for him. Right, I’ll grab myself a drink and then hit the hay. Maybe I’ll get lucky with my wife tonight!)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:688
translate chinese MLR3_NS2_con2_8cc39c12:

    # MC "Are you okay, [Mom_name]?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:689
translate chinese MLR3_NS2_con2_50c782c6:

    # Mom "That was... too fucking close."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:690
translate chinese MLR3_NS2_con2_72cfebce:

    # MC "I know! It was insane! I can’t believe we got away with that."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:691
translate chinese MLR3_NS2_con2_df8b49e4:

    # Mom "Good idea, with the blanket - that was some quick thinking!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:695
translate chinese MLR3_NS2_con2_b21b771c:

    # Mom "I better get dressed and get back to my room, before your father notices I’m missing, and puts two and two together."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:697
translate chinese MLR3_NS2_con2_55c73d6b:

    # Mom "I better get dressed and get back to my room, before Bob notices I’m missing, and puts two and two together."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:698
translate chinese MLR3_NS2_con2_bc8e5fb5:

    # MC "Yeah, hurry on back. We’ll see each other another night, [Mom_name]."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:699
translate chinese MLR3_NS2_con2_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:700
translate chinese MLR3_NS2_con2_2b4de539:

    # Mom "I love you too."
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:728
translate chinese MLR3_NS2_con2_18f1c0a4_1:

    # Dad "Huh? (What are those weird noises coming from [player_name]’s room.)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:729
translate chinese MLR3_NS2_con2_06fc1a8a_1:

    # Dad "(I should probably check on him, to make sure he’s alright.)"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:730
translate chinese MLR3_NS2_con2_ac1ec820:

    # MC "([Mom_name] was so excited to come over tonight. There’s no sense in spoiling the mood, by hiding her under a blanket!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:734
translate chinese MLR3_NS2_con2_f1e73f4a_2:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:738
translate chinese MLR3_NS2_con2_9c9667c1_1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:739
translate chinese MLR3_NS2_con2_11b7c251:

    # Dad "What in tarnation...?"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:743
translate chinese MLR3_NS2_con2_ffc50cea:

    # MC "D-DAD!?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:745
translate chinese MLR3_NS2_con2_489f8b19:

    # MC "B-BOB!?"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:746
translate chinese MLR3_NS2_con2_575b2027:

    # MC "I- uh?!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:747
translate chinese MLR3_NS2_con2_d7ca8077:

    # Mom "*Suck Su-*"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:748
translate chinese MLR3_NS2_con2_f5f5b274:

    # Mom "(Oh fuck...)"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:752
translate chinese MLR3_NS2_con2_a27978d8:

    # Dad "WH-WHAT THE HECK IS GOING ON?!"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:754
translate chinese MLR3_NS2_con2_456695a5:

    # Dad "JESUS H. CHRIST, LINDA! You’re in bed with your SON!"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:756
translate chinese MLR3_NS2_con2_4d1eb204:

    # Dad "JESUS H. CHRIST, LINDA! You're in bed with [player_name]!?"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:760
translate chinese MLR3_NS2_con2_1cea5c24:

    # Mom "N-No! W-Wait! I can explain-"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:761
translate chinese MLR3_NS2_con2_f6434f5d:

    # Dad "Y-You were sucking him off?!"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:762
translate chinese MLR3_NS2_con2_f7d15627:

    # Dad "Wait a minute... this is all starting to make sense!"
    Dad ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:766
translate chinese MLR3_NS2_con2_31f95e60:

    # Mom "BOB! Wait!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:767
translate chinese MLR3_NS2_con2_f7026917:

    # MC "Oh shit... FUCK!"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:768
translate chinese MLR3_NS2_con2_30dbe208:

    # Mom "No! NOOO!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:772
translate chinese MLR3_NS2_con2_8ce1484d:

    # "*SLAM*"
    ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:773
translate chinese MLR3_NS2_con2_4d47783e:

    # MC "(I am so fucked... He’s gonna murder me now.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:777
translate chinese MLR3_NS2_con2_e5ba378f:

    # Mom "BOB! Come back! Don’t go!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:778
translate chinese MLR3_NS2_con2_07690258:

    # MC "Holy shit... My life is ruined..."
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:782
translate chinese MLR3_NS2_con2_d78da6eb:

    # Mom "BOB! BOB!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:783
translate chinese MLR3_NS2_con2_e59aab48:

    # Mom "Please! Don’t leave! I can- I can explain everything! I’ll do anything!"
    Mom ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:787
translate chinese MLR3_NS2_con2_8965d4d9:

    # MC "(Crap, I might have just lost my relationships with [Mom_name] and [Dad_name] in the same night...)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:788
translate chinese MLR3_NS2_con2_8e2e085c:

    # MC "(I can’t see either of them wanting to speak to me ever again after this.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/MLR3_NS2.rpy:789
translate chinese MLR3_NS2_con2_e9128916:

    # MC "Tomorrow is gonna be a tough day..."
    MC ""

