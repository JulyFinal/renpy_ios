﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:23
translate chinese B2_AS1_label_6797b0de:

    # MC "I sorted the documents. Could you pay me?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:24
translate chinese B2_AS1_label_dffe2bb4:

    # Dad "Ah! Good job, [player_name]! Here, take it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:25
translate chinese B2_AS1_label_15d5ec2d:

    # MC "Thanks!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:27
translate chinese B2_AS1_label_c78ce402:

    # Dad "No, I thank you! I hate doing that! "
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:28
translate chinese B2_AS1_label_1af0f792:

    # Dad "After so many times, it started to be incredibly boring."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:29
translate chinese B2_AS1_label_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:37
translate chinese B2_AS1_label_4ac4c319:

    # Dad "Not now, [player_name]."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:49
translate chinese B2_AS1_label_6797b0de_1:

    # MC "I sorted the documents. Could you pay me?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:50
translate chinese B2_AS1_label_dffe2bb4_1:

    # Dad "Ah! Good job, [player_name]! Here, take it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:51
translate chinese B2_AS1_label_15d5ec2d_1:

    # MC "Thanks!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:53
translate chinese B2_AS1_label_c78ce402_1:

    # Dad "No, I thank you! I hate doing that! "
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:54
translate chinese B2_AS1_label_1af0f792_1:

    # Dad "After so many times, it started to be incredibly boring."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:55
translate chinese B2_AS1_label_2416cba9_1:

    # MC "Haha!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:63
translate chinese B2_AS1_label_4ac4c319_1:

    # Dad "Not now, [player_name]."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:75
translate chinese B2_AS1_label_4b4d0951:

    # MC "Hey, Dad!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:77
translate chinese B2_AS1_label_be8f25fd:

    # MC "Hey, Bob!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:78
translate chinese B2_AS1_label_321ddb57:

    # Dad "Hello there, champ. What’s cooking?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:82
translate chinese B2_AS1_label_59913ea2:

    # MC "What’s... cooking?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:83
translate chinese B2_AS1_label_eb14929b:

    # Dad "It’s an old expression... nevermind. What’s up?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:93
translate chinese B2_AS1_menu_label_6797b0de:

    # MC "I sorted the documents. Could you pay me?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:94
translate chinese B2_AS1_menu_label_dffe2bb4:

    # Dad "Ah! Good job, [player_name]! Here, take it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:95
translate chinese B2_AS1_menu_label_15d5ec2d:

    # MC "Thanks!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:97
translate chinese B2_AS1_menu_label_c78ce402:

    # Dad "No, I thank you! I hate doing that! "
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:98
translate chinese B2_AS1_menu_label_1af0f792:

    # Dad "After so many times, it started to be incredibly boring."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:99
translate chinese B2_AS1_menu_label_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:105
translate chinese B2_AS1_menu_label_75d3055b:

    # MC "I didn’t know you smoked."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:106
translate chinese B2_AS1_menu_label_84070ff7:

    # Dad "I don’t. At least, not cigarettes. They’re awful for your lungs."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:107
translate chinese B2_AS1_menu_label_769f0769:

    # MC "Aren’t cigars really bad for you too?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:111
translate chinese B2_AS1_menu_label_59bab916:

    # Dad "A lot of people think that, but the truth is that you don’t inhale a cigar."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:112
translate chinese B2_AS1_menu_label_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:116
translate chinese B2_AS1_menu_label_560f8fee:

    # Dad "You just gently draw it into your mouth to taste it..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:120
translate chinese B2_AS1_menu_label_a998d7c3:

    # Dad "...then exhale it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:121
translate chinese B2_AS1_menu_label_36b708f1:

    # Dad "It’s all about the taste, not the nicotine."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:125
translate chinese B2_AS1_menu_label_c34ba62d:

    # MC "Huh? Interesting! I never knew that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:126
translate chinese B2_AS1_menu_label_15f8e945:

    # Dad "The more you know..!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:140
translate chinese B2_AS1_menu_label_423e197b:

    # MC "Have you heard about Caroline’s shop?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:142
translate chinese B2_AS1_menu_label_2562c9dc:

    # Dad "Oh yeah! Your mom mentioned that a while back. How’s it going?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:144
translate chinese B2_AS1_menu_label_477aacc2:

    # Dad "Oh yeah! Linda mentioned that a while back. How’s it going?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:145
translate chinese B2_AS1_menu_label_5cf2e4cb:

    # MC "Pretty good! She’s moved into online sales."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:149
translate chinese B2_AS1_menu_label_28a1984a:

    # Dad "That’s the dream, right there. Minimal costs for rent and FAR less staff to deal with."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:150
translate chinese B2_AS1_menu_label_e5737a55:

    # Dad "Let me tell you something, champ. Take a seat."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:154
translate chinese B2_AS1_menu_label_9350cc84:

    # Dad "This is a lesson I want you to NEVER forget."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:155
translate chinese B2_AS1_menu_label_00caf026:

    # MC "I’m listening."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:156
translate chinese B2_AS1_menu_label_fb8807c8:

    # Dad "Work is easy. It’s managing staff that’s the hard part."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:157
translate chinese B2_AS1_menu_label_eed88a2a_1:

    # MC "Really?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:158
translate chinese B2_AS1_menu_label_9e59012b:

    # Dad "You can control work and be responsible for it - but staff are human beings, and VERY unpredictable at times."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:162
translate chinese B2_AS1_menu_label_7ac67d1d:

    # MC "Thanks, Dad. I’ll remember that!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:164
translate chinese B2_AS1_menu_label_8a9c69e0:

    # MC "Thanks, Bob. I’ll remember that!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:165
translate chinese B2_AS1_menu_label_8f4a249a:

    # Dad "Good lad."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:180
translate chinese B2_AS1_menu_label_3fdffadc:

    # MC "You look very relaxed!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:181
translate chinese B2_AS1_menu_label_eaef7602:

    # Dad "I work hard. I think I deserve to take a little time off, every now and then."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:185
translate chinese B2_AS1_menu_label_e01ce15a:

    # Dad "And what more could I ask for? It’s a gorgeous day. And I’ve got a brilliant cigar, and a comfortable couch."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:186
translate chinese B2_AS1_menu_label_d87e9fd7:

    # MC "Heh... I guess you’re right."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:190
translate chinese B2_AS1_menu_label_a089b93e:

    # Dad "Whenever you’re young, make the most of your free time, and enjoy your days off work."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:191
translate chinese B2_AS1_menu_label_d5bc3706:

    # Dad "You’ll never be able to truly appreciate them, until they’re gone - but still, try to enjoy them."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:195
translate chinese B2_AS1_menu_label_1decb526:

    # Dad "When you get to my age, you’ll have maybe, an hour here and there to relax."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:196
translate chinese B2_AS1_menu_label_614e45e5:

    # Dad "But each one becomes much more special. Like this moment right now."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:197
translate chinese B2_AS1_menu_label_73bece16:

    # Dad "I know it’s few and far between - but I can sit back, kick my feet up, and enjoy every last second."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:211
translate chinese B2_AS1_menu_label_9105debf:

    # MC "Doesn’t Mom get angry when you smoke cigars in the bedroom? I know she doesn’t let Sara, Caroline, or me smoke in the rooms we rent."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:215
translate chinese B2_AS1_menu_label_4b526d44:

    # Dad "I only started recently. A couple of boys recommended them on my last fishing trip."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:219
translate chinese B2_AS1_menu_label_3a8437d2:

    # Dad "It took me a while to really learn to appreciate them - but I think I’m getting there."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:220
translate chinese B2_AS1_menu_label_134ef71c:

    # MC "What about the smell?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:221
translate chinese B2_AS1_menu_label_0f5c9829:

    # Dad "A bit of air freshener and an open window sorts that out."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:222
translate chinese B2_AS1_menu_label_19940e86:

    # Dad "Your mom hasn’t complained so far, at least!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:235
translate chinese B2_AS1_menu_label_6a6ef10f:

    # MC "Doesn’t Linda get angry when you smoke cigars in the bedroom? I know she doesn’t let Sara, Caroline, or me smoke in the rooms we rent."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:239
translate chinese B2_AS1_menu_label_4b526d44_1:

    # Dad "I only started recently. A couple of boys recommended them on my last fishing trip."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:243
translate chinese B2_AS1_menu_label_3a8437d2_1:

    # Dad "It took me a while to really learn to appreciate them - but I think I’m getting there."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:244
translate chinese B2_AS1_menu_label_134ef71c_1:

    # MC "What about the smell?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:245
translate chinese B2_AS1_menu_label_0f5c9829_1:

    # Dad "A bit of air freshener and an open window sorts that out."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:246
translate chinese B2_AS1_menu_label_d5b32070:

    # Dad "The old ‘ball and chain’ hasn’t complained so far, at least! Haha!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:263
translate chinese B2_AS1_menu_label_20fed5eb:

    # MC "Is everything okay between you and Mom?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:267
translate chinese B2_AS1_menu_label_c18f07da:

    # Dad "Why would you ask that?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:268
translate chinese B2_AS1_menu_label_d02c9561:

    # MC "I’m just curious. The two of you just seem a little more... distant than usual."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:269
translate chinese B2_AS1_menu_label_0c8149db:

    # Dad "When you’ve been in a marriage as long as we have, you’ll learn that there are peaks and troughs."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:270
translate chinese B2_AS1_menu_label_c81531c9:

    # Dad "Your mother is a complex woman - one of the many reasons I fell in love with her."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:275
translate chinese B2_AS1_menu_label_3419a63e:

    # Dad "Sometimes she becomes withdrawn and needs to ‘find herself.’ I’ve found that it’s best to let her get on with it, and give her some space."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:289
translate chinese B2_AS1_menu_label_e008f011:

    # MC "Is everything okay between you and Linda?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:293
translate chinese B2_AS1_menu_label_c18f07da_1:

    # Dad "Why would you ask that?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:294
translate chinese B2_AS1_menu_label_d02c9561_1:

    # MC "I’m just curious. The two of you just seem a little more... distant than usual."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:295
translate chinese B2_AS1_menu_label_7978d211:

    # Dad "When you’ve been in a relationship as long as we have, you’ll learn that there are peaks and troughs."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:296
translate chinese B2_AS1_menu_label_f01feb39:

    # Dad "Linda is a complex woman - one of the many reasons I fell in love with her."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:301
translate chinese B2_AS1_menu_label_b56e0e68:

    # Dad "Sometimes she becomes withdrawn and needs to ‘find herself’. I’ve found that it’s best to let her get on with it and give her some space."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:315
translate chinese B2_AS1_menu_label_1c4960bd:

    # MC "Have you got any advice for finding a girlfriend, Dad?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:317
translate chinese B2_AS1_menu_label_013091ef:

    # MC "Have you got any advice for finding a girlfriend, Bob?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:321
translate chinese B2_AS1_menu_label_ee584e18:

    # Dad "A girlfriend? Hmm..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:322
translate chinese B2_AS1_menu_label_3ad5abd7:

    # Dad "Put yourself out there."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:326
translate chinese B2_AS1_menu_label_9f65a0bb:

    # Dad "Be open and honest about your interests. If you’re a videogamer, then state that you are."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:327
translate chinese B2_AS1_menu_label_9fbdaf03:

    # Dad "If you’re into sports or movies, then be upfront about it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:329
translate chinese B2_AS1_menu_label_ca76102a:

    # MC "But what if they don’t like the same things as me, Dad."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:331
translate chinese B2_AS1_menu_label_e7a45e61:

    # MC "But what if they don’t like the same things as me, Bob."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:335
translate chinese B2_AS1_menu_label_32d41a7f:

    # Dad "Opposites attract, champ."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:336
translate chinese B2_AS1_menu_label_7c1a49ca:

    # Dad "Contrary to what you may believe, people aren’t looking for carbon copies of themselves when they go dating."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:337
translate chinese B2_AS1_menu_label_fd9448ec:

    # Dad "They’re looking for individuals, with get-up-and-go. People who embrace life and enjoy it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:341
translate chinese B2_AS1_menu_label_1f59d3d5:

    # Dad "The only thing I need to warn you about, is that solitary hobbies won’t help you meet girls."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:342
translate chinese B2_AS1_menu_label_14a75d48:

    # Dad "If your hobby is painting models - then go to a gaming club. If your hobby is watching movies, then go to a movie club."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:343
translate chinese B2_AS1_menu_label_c0166d66:

    # Dad "You NEED to get yourself out there. And then, when you’re out there, say hello."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:344
translate chinese B2_AS1_menu_label_818482da:

    # Dad "Be polite, introduce yourself, be charming. That’s all there is to it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:348
translate chinese B2_AS1_menu_label_d266360b:

    # MC "But, what if I get rejected?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:352
translate chinese B2_AS1_menu_label_dec269c7:

    # Dad "Suck it up and move on. It’ll happen."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:353
translate chinese B2_AS1_menu_label_366bf3fb:

    # Dad "You can take solace in the fact that you did your absolute best - you put your best foot forward and you tried."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:378
translate chinese B2_AS1_payment_2b92be3b:

    # "You receive {color=#00ff00}[bob_payment_money]${/color}."
    ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:388
translate chinese B2_AS1_payment2_2b92be3b:

    # "You receive {color=#00ff00}[bob_payment_money]${/color}."
    ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "I didn’t know you smoked."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "Have you heard about Caroline’s shop?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "You look very relaxed!"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "Doesn’t Mom get angry with you smoking cigars in the bedroom?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "Doesn’t Linda get angry with you smoking cigars in the bedroom?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "Is everything okay between you and Mom? "
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "Is everything okay between you and Linda? "
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/B2_AS1.rpy:89
    old "Have you got any advice for finding a girlfriend?"
    new ""

