﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/day/scens/salon_money.rpy:17
translate chinese salon_money_label_d8293799:

    # MC "Nice! +[money]$"
    MC ""

