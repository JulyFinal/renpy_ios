﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:10
translate chinese SR2_bath_label_5f49fb38:

    # MC "(I can't do it when someone is the kitchen.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:14
translate chinese SR2_bath_label_cc8ea887:

    # MC "(I already know who's there.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:27
translate chinese SR2_bath_label_457442c7:

    # MC "(Huh? What is she doing?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:28
translate chinese SR2_bath_label_b29b3745:

    # MC "(She was supposed to take a shower.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:30
translate chinese SR2_bath_label_8f7203b3:

    # MC "(Is she sleepy again? Those games are gonna kill her one day.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:32
translate chinese SR2_bath_label_b92b183a:

    # MC "(Seriously!? Is she planning on taking a nap in the bathroom?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:33
translate chinese SR2_bath_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:35
translate chinese SR2_bath_label_ae852d89:

    # MC "I hope Mom doesn't notice her."
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:37
translate chinese SR2_bath_label_da9e6c2d:

    # MC "(I hope Linda doesn't notice her.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:51
translate chinese SR2_bath_label_86942359:

    # MC "(It’s locked! I wonder who is there...?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:52
translate chinese SR2_bath_label_33178a05:

    # MC "(If I only had some spy camera I could use it to see through the door!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:60
translate chinese SR2_bath_label_86942359_1:

    # MC "(It’s locked! I wonder who is there...?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/SR2_bath.rpy:61
translate chinese SR2_bath_label_33178a05_1:

    # MC "(If I only had some spy camera I could use it to see through the door!)"
    MC ""

