﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:77
translate chinese SR2_NS3_label_28fadb05:

    # Sara "Hi, [player_name]. I was beginning to think you’d forgotten about me."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:78
translate chinese SR2_NS3_label_c697914f:

    # MC "Of course not! I couldn’t wait for tonight."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:79
translate chinese SR2_NS3_label_793b268c:

    # Sara "I hope you’re not scared of heights, by the way. We ARE going to be climbing ALL the way up onto the garage roof."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:83
translate chinese SR2_NS3_label_8d8a0955:

    # MC "Pfft! That’s nothing! I’ll be able to help you up, there."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:84
translate chinese SR2_NS3_label_6801ac54:

    # Sara "Aww, you’re sweet. Let’s get going! We’re missing the stars!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:86
translate chinese SR2_NS3_label_41a51c9b:

    # MC "Just be careful not to be too loud - we don’t want to wake Mom and Dad."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:88
translate chinese SR2_NS3_label_9ab2e52b:

    # MC "Just be careful not to be too loud - we don’t want to wake everyone up."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:92
translate chinese SR2_NS3_label_2b1fdfe1:

    # Sara "Oops! Sorry, I’ll try to keep my voice down. I’m just so excited."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:93
translate chinese SR2_NS3_label_cfebd804:

    # MC "That’s fine."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:94
translate chinese SR2_NS3_label_48605822:

    # MC "(There’s a nice floral scent in the air - is she wearing a new perfume?)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:98
translate chinese SR2_NS3_label_138332f3:

    # Sara "*Sigh*"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:99
translate chinese SR2_NS3_label_64685318:

    # MC "(That was a big sigh. How could she turn from excited to exasperation so quickly?)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:100
translate chinese SR2_NS3_label_fd14fda2:

    # MC "Is something wrong, Sara?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:101
translate chinese SR2_NS3_label_ceaa8dc3:

    # Sara "It’s nothing... I was just kind of hoping that you’d kiss me as soon as we met."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:102
translate chinese SR2_NS3_label_c70969d1:

    # MC "I could kiss you now."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:106
translate chinese SR2_NS3_label_613665b5:

    # Sara "I’d REALLY like that."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:107
translate chinese SR2_NS3_label_df3c2a35:

    # Sara "Every time you kiss me it feels like there are butterflies in my stomach. It’s like all the weight of life’s problems just float away."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:109
translate chinese SR2_NS3_label_f4e21001:

    # Sara "I love you, [player_name]. Much more than any sis really should..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:111
translate chinese SR2_NS3_label_b416e79c:

    # Sara "I love you, [player_name]. Much more than anyone probably should love another person."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:115
translate chinese SR2_NS3_label_932f985a:

    # Sara "I hope you feel as strongly for me as I do for you."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:116
translate chinese SR2_NS3_label_70c2d8c4:

    # MC "(Her green eyes rival the stars in their beauty tonight.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:117
translate chinese SR2_NS3_label_9869fa2c:

    # MC "I do, Sara. I love you."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:121
translate chinese SR2_NS3_label_c90f6004:

    # Sara "Hehe... Sorry about the frumpy jumper. I guessed it was going to be cold."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:122
translate chinese SR2_NS3_label_ceb91264:

    # MC "I think it looks good on you. Just answer me one question."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:123
translate chinese SR2_NS3_label_bb5ae6c5:

    # Sara "Yes?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:127
translate chinese SR2_NS3_label_4989233b:

    # MC "You thought it was going to be cold?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:128
translate chinese SR2_NS3_label_4bf2cda1:

    # Sara "Yeah, I did."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:132
translate chinese SR2_NS3_label_4ab31891:

    # MC "And yet, you decided not to wear any leggings?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:133
translate chinese SR2_NS3_label_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:134
translate chinese SR2_NS3_label_e4eb887e:

    # MC "You should know by now, how turned on I get by your body. Especially your slender legs."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:138
translate chinese SR2_NS3_label_3356ecab:

    # Sara "I love you so much. Hurry up and kiss me."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:140
translate chinese SR2_NS3_label_560f3cf2:

    # MC "(Sara needed a date like this. It offers her some respite from being grounded.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:141
translate chinese SR2_NS3_label_802482ab:

    # MC "(I hope that Mom finally changes her mind and lets up on her soon.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:143
translate chinese SR2_NS3_label_b1d76bed:

    # MC "(Sara needed a date like this. It offers her some relief and fun from all that stress coming from studying very hard.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:144
translate chinese SR2_NS3_label_5e2e9eb8:

    # MC "(I hope I’m not disturbing her study too much. I want her to have a lot of time for me again very soon.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:148
translate chinese SR2_NS3_label_0c330e25:

    # MC "Mmmm...."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:149
translate chinese SR2_NS3_label_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:152
translate chinese SR2_NS3_label_09eb4c67:

    # MC "(I hope none of the family wake up and look out their windows right now... It’d give Dad a heart attack!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:154
translate chinese SR2_NS3_label_77fdf1ab:

    # MC "(I hope nobody wakes up and looks out their windows right now... It’d give Bob a heart attack since he probably doesn't expect to see his tenants kissing!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:159
translate chinese SR2_NS3_label_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:160
translate chinese SR2_NS3_label_baaffcad:

    # Sara "(I go weak, each time he kisses me like this. It’s like all the energy just leaves my body...)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:161
translate chinese SR2_NS3_label_e2a7a388:

    # Sara "(I’ll have to break it soon, or we’ll get distracted and miss the best part of the night sky!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:165
translate chinese SR2_NS3_label_35b1163a:

    # Sara "*Pant* W-Wow..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:166
translate chinese SR2_NS3_label_ab3a7c79:

    # Sara "(That was sensational...)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:170
translate chinese SR2_NS3_label_79e0ca0b:

    # Sara "Just like that."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:171
translate chinese SR2_NS3_label_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:172
translate chinese SR2_NS3_label_39f6d984:

    # Sara "That’s EXACTLY how I want to be kissed when we meet. It’s just perfect."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:173
translate chinese SR2_NS3_label_bcdc8dda:

    # MC "I’ll try and remember to do that more often for you, then."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:181
translate chinese SR2_NS3_label_e48de3a8:

    # Sara "C’mon! Hurry up, [player_name]! We don’t have forever!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:182
translate chinese SR2_NS3_label_09ee9127:

    # MC "Yeah, I’m coming!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:183
translate chinese SR2_NS3_label_d3278f17:

    # Sara "I don’t think I’ll be able to get up onto the roof without your help. Can you give me a boost?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:187
translate chinese SR2_NS3_label_f4fbb764:

    # MC "Sure, no problem. How’s this?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:188
translate chinese SR2_NS3_label_39b9fc8e:

    # Sara "I’m almost there! Just a little bit more!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:189
translate chinese SR2_NS3_label_e0795e85:

    # Sara "Make sure you don’t drop me!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:193
translate chinese SR2_NS3_label_531cef67:

    # MC "Don’t worry, I won’t drop you, Sara. There’s nothing at all that could possibly distract me right now."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:194
translate chinese SR2_NS3_label_d9070ebf:

    # Sara "You’re looking at my panties, aren’t you?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:195
translate chinese SR2_NS3_label_dce9cdcb:

    # MC "...maybe."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:199
translate chinese SR2_NS3_label_62ab56d8:

    # Sara "Pervert!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:200
translate chinese SR2_NS3_label_830367dd:

    # MC "I can’t help it! It’s just the angle you were at!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:204
translate chinese SR2_NS3_label_92a3ba01:

    # Sara "Uh huh, I’m sure!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:205
translate chinese SR2_NS3_label_9015dfe3:

    # Sara "You can find your own way up!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:206
translate chinese SR2_NS3_label_d8332194:

    # MC "Wait - aren’t you going to give me a hand?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:210
translate chinese SR2_NS3_label_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:211
translate chinese SR2_NS3_label_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:212
translate chinese SR2_NS3_label_929d9ee1:

    # MC "*Sigh...*"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:216
translate chinese SR2_NS3_label_75f04e4d:

    # MC "Hnnngg! C’mon! Almost there!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:217
translate chinese SR2_NS3_label_c4d40ba2:

    # MC "(Just a couple more inches...)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:221
translate chinese SR2_NS3_label_98e2a470:

    # MC "*Phew!*"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:222
translate chinese SR2_NS3_label_2b84bb2b:

    # MC "I finally made it, Sara!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:223
translate chinese SR2_NS3_label_c8b18188_1:

    # MC "Sara?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:228
translate chinese SR2_NS3_label_dc5ab8aa:

    # MC "Sara, are you okay?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:229
translate chinese SR2_NS3_label_d7f5df3c:

    # Sara "They’re all so beautiful. Look at them, [player_name]."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:230
translate chinese SR2_NS3_label_f4ba1aa0:

    # Sara "Sit down beside me."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:234
translate chinese SR2_NS3_label_cf37c3e3:

    # MC "Wow, we got clear skies tonight."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:235
translate chinese SR2_NS3_label_964c81eb:

    # Sara "There’s so many... you couldn’t even begin to count them..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:239
translate chinese SR2_NS3_label_cc6cfc8a:

    # Sara "I’d love to go exploring them someday. Just travelling from star to star."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:240
translate chinese SR2_NS3_label_6cc2a6e8:

    # Sara "It would be so wonderful..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:241
translate chinese SR2_NS3_label_963d57fe:

    # Sara "Just look at the colours: Purples and greens and yellows..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:245
translate chinese SR2_NS3_label_d0cb0c34:

    # Sara "The greatest imagination in the world couldn’t come up with something as perfect as this."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:246
translate chinese SR2_NS3_label_db2bcfc8:

    # Sara "It’s... infinite."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:247
translate chinese SR2_NS3_label_a0d3e15f:

    # Sara "We’re like ants in a sandbox, staring out into a garden we could never fully explore."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:251
translate chinese SR2_NS3_label_7fe18a4e:

    # MC "There’s billions of those stars. And yet, the one place I’d choose to be is exactly where I am right now."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:252
translate chinese SR2_NS3_label_05380ad5:

    # MC "Right here on this roof, beside you."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:253
translate chinese SR2_NS3_label_80d1d31e:

    # Sara "Really?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:257
translate chinese SR2_NS3_label_69915823:

    # MC "Really, Sara. That’s the truth."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:258
translate chinese SR2_NS3_label_f04d906a:

    # Sara "I’m sorry I’m not ready yet."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:259
translate chinese SR2_NS3_label_32617e96:

    # MC "Ready for what?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:263
translate chinese SR2_NS3_label_aaf0e409:

    # Sara "For sex... I want to be 100 percent sure that you are the one... It’s important for me. Just please don't take it as something bad or that I am not trust you..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:264
translate chinese SR2_NS3_label_4c00f3db:

    # Sara "I know you want it - and if I can’t give you it then some other girl will."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:265
translate chinese SR2_NS3_label_de7fabb3:

    # MC "It’s not like that."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:266
translate chinese SR2_NS3_label_685f6300:

    # Sara "Please... I’ve seen how other girls in college look at you. Even after you made a fool of yourself in front of professor Celia, they still think you’re hot."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:267
translate chinese SR2_NS3_label_421de18e:

    # MC "(Ugh, I wish she didn’t bring up that incident with Ms. Celia. I’m STILL cringing when I think about it!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:268
translate chinese SR2_NS3_label_2423feda:

    # Sara "I want to go further with you tonight. Could... we try anal?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:269
translate chinese SR2_NS3_label_7b02e252:

    # MC "Are you sure? We don’t have to-"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:270
translate chinese SR2_NS3_label_a526799b:

    # Sara "I want to. I’m not ready to use my pussy yet, but I think... maybe I can do anal. I won’t know if I don’t try."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:274
translate chinese SR2_NS3_label_1eebefd9:

    # MC "I don’t want to hurt you."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:275
translate chinese SR2_NS3_label_ce297bcc:

    # Sara "Y-You won’t hurt me... and I want it."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:276
translate chinese SR2_NS3_label_f5a15549:

    # MC "You don’t know that for sure."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:277
translate chinese SR2_NS3_label_27df4561:

    # Sara "*Gulp* P-Please don’t try to talk me out of it."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:281
translate chinese SR2_NS3_label_1c5ec41c:

    # MC "Will you at least promise me that you’ll tell me to stop if it starts to hurt?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:282
translate chinese SR2_NS3_label_117d3c2b:

    # Sara "... I promise."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:283
translate chinese SR2_NS3_label_615eedc7:

    # MC "Okay."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:287
translate chinese SR2_NS3_label_bc5ffff4:

    # MC "At least let me finger you for a bit first, to turn you on."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:288
translate chinese SR2_NS3_label_b43e7a00:

    # Sara "I... Ahh..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:289
translate chinese SR2_NS3_label_1717532b:

    # MC "(Her pussy is so warm right now.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:293
translate chinese SR2_NS3_label_3c7e487d:

    # Sara "W-Wait... Can we just... get straight to it?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:294
translate chinese SR2_NS3_label_24d16f3f:

    # MC "Why? Is something wrong?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:298
translate chinese SR2_NS3_label_e7dde135:

    # Sara "If we do foreplay, then I might... chicken out."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:299
translate chinese SR2_NS3_label_94a7d704:

    # MC "If you're sure."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:300
translate chinese SR2_NS3_label_4d3a1d77:

    # Sara "Y-Yeah, I think this is for the best."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:304
translate chinese SR2_NS3_label_9092d6db:

    # MC "Do you want to take off your panties now?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:305
translate chinese SR2_NS3_label_a73e9591:

    # MC "Why do you look so shocked?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:306
translate chinese SR2_NS3_label_92e16a5c:

    # Sara "I... You were just so forward about it!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:307
translate chinese SR2_NS3_label_c381649f:

    # MC "How am I going to fuck you if you’ve still got them on? Haha"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:311
translate chinese SR2_NS3_label_e13dd671:

    # Sara "Fine, I’m taking them off now."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:312
translate chinese SR2_NS3_label_d140435d:

    # Sara "(God, I hope nobody sees us up here. I wonder if [player_name] has even thought about the risks of doing this.)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:313
translate chinese SR2_NS3_label_2f717c9d:

    # Sara "Umm... [player_name], do you think anyone will be able to see us up here?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:314
translate chinese SR2_NS3_label_4708fe05:

    # MC "Nah, absolutely not. It’s too dark - plus we’re not near a main street. Do you know anyone who walks around looking at the roofs of houses?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:318
translate chinese SR2_NS3_label_4d4b93ef:

    # Sara "*Gulp* If you say so."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:319
translate chinese SR2_NS3_label_22c0fb02:

    # MC "It’ll be fine. As long as we’re quiet we shouldn’t get caught."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:321
translate chinese SR2_NS3_label_ba7378dd:

    # MC "Plus, the rest of our family should have been asleep for A LONG time by now."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:323
translate chinese SR2_NS3_label_2efbea9f:

    # MC "Plus, the rest of the house should be deep asleep by now."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:324
translate chinese SR2_NS3_label_171a57d0:

    # MC "(Damn, it’s a shame I can’t use her pussy tonight. My cock would fit so snuggly in that tight little hole.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:328
translate chinese SR2_NS3_label_6b86ceef:

    # Sara "O-Okay, I think I’m ready. How do you want me to do this?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:329
translate chinese SR2_NS3_label_8ab5e8a4:

    # MC "How about you lean forward over the tip of the roof? I’ll stand behind you."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:330
translate chinese SR2_NS3_label_1fd0a650:

    # Sara "Is it safe?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:331
translate chinese SR2_NS3_label_3e56c1a0:

    # MC "It’ll be fine - it’s only a few feet. We’ll hardly hurt ourselves if we fall."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:335
translate chinese SR2_NS3_label_546e8965:

    # Sara "Is this okay? Do you need me to angle my ass up more?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:336
translate chinese SR2_NS3_label_734da78e:

    # MC "That’s perfect, Sara. Just stay like that."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:337
translate chinese SR2_NS3_label_4e737e70:

    # MC "(What a view! This is either going to be the most unusual place I will ever have sex with a woman, in my life... Or the most unusual story of how a guy ended up in hospital!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:341
translate chinese SR2_NS3_label_4126017d:

    # Sara "This is gonna feel weird, isn’t it?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:342
translate chinese SR2_NS3_label_71491a3d:

    # MC "I... don’t know, Sara. Sorry, I’ve never had a dick in my ass before."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:343
translate chinese SR2_NS3_label_c76a1a84:

    # Sara "Just... go slow, okay?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:348
translate chinese SR2_NS3_label_3c8b4fb6:

    # MC "Try to relax, Sara. I’ll take things very slowly. And if you want me to stop, for any reason, just say."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:349
translate chinese SR2_NS3_label_800c1314:

    # MC "I don’t want to cause you any pain. For all I know, it might take us two or three attempts, before I can even get it all the way in."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:350
translate chinese SR2_NS3_label_2130b29d:

    # MC "We’ll just take things as they come, okay?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:354
translate chinese SR2_NS3_label_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:355
translate chinese SR2_NS3_label_879bbc29:

    # Sara "*Deep breath*"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:356
translate chinese SR2_NS3_label_11d17b9c:

    # Sara "(I just have to keep breathing and focus on keeping my voice down.)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:357
translate chinese SR2_NS3_label_3e4164c6:

    # Sara "(I can feel his glans pushing up against my asshole... This is it!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:361
translate chinese SR2_NS3_label_3697d17d:

    # Sara "Mmmm!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:362
translate chinese SR2_NS3_label_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:364
translate chinese SR2_NS3_label_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:365
translate chinese SR2_NS3_label_828c5f30:

    # Sara "(Goddamn! His cock is fucking huge!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:369
translate chinese SR2_NS3_label_6ea1674c:

    # Sara "Ahhh.... Ugh..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:370
translate chinese SR2_NS3_label_d8d815a3:

    # Sara "(Why didn’t I think to start with something small first? Like a finger or two?!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:371
translate chinese SR2_NS3_label_586ab9ce:

    # MC "(Oooh! This is great! She’s so tight that I can barely get it in!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:375
translate chinese SR2_NS3_label_9c31ca3c:

    # MC "Ahh... Yes... Ugh!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:376
translate chinese SR2_NS3_label_5b72e012:

    # Sara "Ow..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:377
translate chinese SR2_NS3_label_93e77b2e:

    # MC "Fuck, this is good..."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:381
translate chinese SR2_NS3_label_d0e370a2:

    # Sara "Ah... Ah... Oww... Ah..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:382
translate chinese SR2_NS3_label_01d05623:

    # MC "(I didn’t manage to push my cock very far in. I’ll pull out and try again.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:383
translate chinese SR2_NS3_label_dc992cb7:

    # MC "How are you holding up there, Sara?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:384
translate chinese SR2_NS3_label_01116398:

    # Sara "Fine! Ugh..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:388
translate chinese SR2_NS3_label_aad9bb41:

    # MC "I’m going to try thrusting it in again. I’ll go slowly."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:389
translate chinese SR2_NS3_label_d884e337:

    # Sara "(Fuck! He’s so damn thick! I don’t know if I can handle this much longer!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:393
translate chinese SR2_NS3_label_b318b000:

    # MC "Ooohhh yeah... That’s the spot!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:395
translate chinese SR2_NS3_label_0fe3c5b3:

    # Sara "AHHH!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:397
translate chinese SR2_NS3_label_627c53aa:

    # MC "(Damn! She’s being REALLY loud right now!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:401
translate chinese SR2_NS3_label_5ce64851:

    # Sara "(SHIT!! FUCK!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:403
translate chinese SR2_NS3_label_965b0f1e:

    # Sara "(Damn! This hurts so much! I should NEVER have agreed to this!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:405
translate chinese SR2_NS3_label_a03df080:

    # Sara "(Damn! This feels weird! I feel pleasure and something ELSE at the same time!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:406
translate chinese SR2_NS3_label_0800b6c9:

    # Sara "(Why didn’t I just let him fuck my pussy?! God DAMN!)"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:411
translate chinese SR2_NS3_label_8c32044e:

    # Sara "Fuck! It hurts! Pull it out! Pull it out!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:413
translate chinese SR2_NS3_label_92ebb7a2:

    # Sara "Ah! Fuck! It feels weird. Maybe pull it out or try a little slower."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:414
translate chinese SR2_NS3_label_a010f877:

    # MC "Really? I’m not even halfway in yet!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:416
translate chinese SR2_NS3_label_431f60e7:

    # Sara "It’s sooooo sore!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:418
translate chinese SR2_NS3_label_a524605a:

    # Sara "It’s sooooo dry!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:419
translate chinese SR2_NS3_label_671d92fa:

    # MC "(Damn, I’m not that far from cumming. I could VERY quickly thrust a few more times and cum in her ass...)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:425
translate chinese SR2_NS3_label_eff95422:

    # MC "(A few more thrusts won’t hurt her. I’ll quickly cum and then we’ll be done with it.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:426
translate chinese SR2_NS3_label_41085739:

    # Sara "Are you pulling out, [player_name]?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:430
translate chinese SR2_NS3_label_1d486d0b:

    # MC "Mmm! Ahh! Ahh! Hnnng!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:431
translate chinese SR2_NS3_label_e21f8708:

    # Sara "AHHH! AHHH!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:432
translate chinese SR2_NS3_label_fad6ffd3:

    # Sara "FUCK! OUCH! OWIE! TAKE IT OUT!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:434
translate chinese SR2_NS3_label_4aed8b6c:

    # MC "Mmm! Ahh! Just a few more thrusts okay!?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:435
translate chinese SR2_NS3_label_430e1aef:

    # Sara "O-Okay! Only a few! Ahh!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:436
translate chinese SR2_NS3_label_83911e09:

    # Sara "FUCK! AH! HARDER!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:437
translate chinese SR2_NS3_label_94fa733a:

    # Sara "[player_name]!!!!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:441
translate chinese SR2_NS3_label_bafed9f0:

    # MC "HNNNNGGG! UGH! YES!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:443
translate chinese SR2_NS3_label_b26e402c:

    # MC "(Fuck! This feels good! Her ass is so tight, it's milking my cock!)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:445
translate chinese SR2_NS3_label_5aa5de31:

    # Sara "AHH! AHH OWWW!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:454
translate chinese SR2_NS3_label_db1fd57c:

    # MC "Phew..."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:455
translate chinese SR2_NS3_label_00c1f838:

    # Sara "Oww.... Ouch..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:457
translate chinese SR2_NS3_label_1f7ba49c:

    # Sara "Why’d you do that, [player_name]? It REALLY hurt!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:459
translate chinese SR2_NS3_label_1ad2a84b:

    # Sara "That was the weirdest feeling I ever had... Ah..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:460
translate chinese SR2_NS3_label_e8ba1c43:

    # MC "Sorry Sara, I was just so close to cumming."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:462
translate chinese SR2_NS3_label_d61dce3e:

    # Sara "Hmmpph... Just don’t do it again!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:464
translate chinese SR2_NS3_label_eefba7ff:

    # Sara "Hmmppph... Just let’s prepare better the next time!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:470
translate chinese SR2_NS3_label_28c134ca:

    # MC "(I better pull it out, I don’t want to hurt Sara by accident.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:471
translate chinese SR2_NS3_label_949585e6:

    # MC "It’s okay, Sara, I’m pulling out now."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:472
translate chinese SR2_NS3_label_18acdf28:

    # Sara "Oww... Th-Thanks, [player_name]."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:476
translate chinese SR2_NS3_label_98b1e218:

    # MC "There we go, that’s it out."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:477
translate chinese SR2_NS3_label_9d4155ae:

    # Sara "I’m sorry you didn’t get to cum."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:478
translate chinese SR2_NS3_label_22594833:

    # MC "It’s okay, Sara. I wasn’t going to have any fun if you were in pain."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:485
translate chinese SR2_NS3_continue_a949f462:

    # Sara "That was really, really sore..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:487
translate chinese SR2_NS3_continue_635dc3fb:

    # Sara "That was really, really dry..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:488
translate chinese SR2_NS3_continue_466368d7:

    # MC "I’ll tell you what, how about I go out and I buy us some lube instead?"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:489
translate chinese SR2_NS3_continue_5c2af5d8:

    # Sara "Lube?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:490
translate chinese SR2_NS3_continue_e546ae95:

    # MC "Yeah, it’s a slippery stuff. I can get one from the sex shop."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:495
translate chinese SR2_NS3_continue_285c9893:

    # Sara "What do I do with it?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:497
translate chinese SR2_NS3_continue_e107c624:

    # Sara "That’s a good idea... And how will you plan to use it?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:498
translate chinese SR2_NS3_continue_d020f891:

    # MC "I’ll put it in your ass and around my cock. It should help it slide in easier."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:500
translate chinese SR2_NS3_continue_e571876b:

    # Sara "Will it... make it less sore?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:501
translate chinese SR2_NS3_continue_d0392d47:

    # MC "It should. If we’re lucky it MIGHT even make it feel good for you."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:504
translate chinese SR2_NS3_continue_69ebfdef:

    # Sara "No way! I don’t think I could EVER enjoy what we just did! Haha!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:506
translate chinese SR2_NS3_continue_e8cf4d0a:

    # Sara "Will it... make it less dry?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:507
translate chinese SR2_NS3_continue_869d7e9c:

    # Sara "Sounds great, we should have used it today..."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:508
translate chinese SR2_NS3_continue_ff89060b:

    # MC "We should have. If we're lucky it MIGHT even make it feel really good for you too!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:512
translate chinese SR2_NS3_continue_7892d5fc:

    # Sara "Hmm! Maybe! We’ll have to try it out.. Haha! "
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:513
translate chinese SR2_NS3_continue_6b854c1a:

    # MC "That’s okay, we don’t have to do it again."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:514
translate chinese SR2_NS3_continue_8a365d6d:

    # Sara "But I WANT to do it for you."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:515
translate chinese SR2_NS3_continue_75e0f11b:

    # MC "Sara, you don’t have to offer anal if it’s going to hur-"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:519
translate chinese SR2_NS3_continue_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:520
translate chinese SR2_NS3_continue_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:521
translate chinese SR2_NS3_continue_65a61302:

    # MC "(Sara doesn't need to put herself through trials like this to make me happy. She should know by now that I’m already happy with her.)"
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:525
translate chinese SR2_NS3_continue_cfc51d7c:

    # Sara "Thank you, [player_name]. You’ve made this one of the most magical nights of my life."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:526
translate chinese SR2_NS3_continue_9d37a09f:

    # Sara "Can we just agree to forget that the last bit on the roof happened?"
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:527
translate chinese SR2_NS3_continue_ecb3f264:

    # MC "Haha, sure... Staring at the stars was my favourite part anyway."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:528
translate chinese SR2_NS3_continue_696935f8:

    # Sara "Hehe, mine too."
    Sara ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:530
translate chinese SR2_NS3_continue_e55aa971:

    # MC "C’mon, we better sneak back inside before Mom or Dad notice us missing. I’ll help you down from the roof."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:532
translate chinese SR2_NS3_continue_d463a3dc:

    # MC "C’mon, we better go back to the house. I’ll help you down from the roof."
    MC ""

# game/scripts/home/entrance2/night/scenes/SR2_NS3.rpy:533
translate chinese SR2_NS3_continue_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

