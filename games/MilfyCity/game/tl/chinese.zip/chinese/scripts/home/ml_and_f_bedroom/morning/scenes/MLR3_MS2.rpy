﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:19
translate chinese MLR3_MS2_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:32
translate chinese MLR3_MS2_b85ea1e5:

    # MC "(I wonder what [Mom_name]’s doing home at this time. She doesn’t normally just hang around in her room like this.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:33
translate chinese MLR3_MS2_75e1b082:

    # MC "Hey [Mom_name], are you making tea?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:34
translate chinese MLR3_MS2_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:38
translate chinese MLR3_MS2_ebf08c07:

    # MC "Umm, [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:39
translate chinese MLR3_MS2_2ddc096c:

    # Mom "Huh? Oh! Sorry, I didn’t hear you come in there, [player_name]."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:40
translate chinese MLR3_MS2_da67d71a:

    # MC "I just asked if you were making tea."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:44
translate chinese MLR3_MS2_aa1ec5e9:

    # Mom "Oh, yeah. Would you like a cup put on? I can refill the kettle."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:45
translate chinese MLR3_MS2_83e1e1c6:

    # MC "Nah, don’t worry about it. Are you okay? You look a little anxious."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:46
translate chinese MLR3_MS2_2d73f20c:

    # Mom "I’m, uh..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:50
translate chinese MLR3_MS2_b5a0b90c:

    # Mom "Of course I’m fine. Never been better."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:51
translate chinese MLR3_MS2_0e2becf6:

    # MC "Cool. What are you doing at home at the minute?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:52
translate chinese MLR3_MS2_8a46cdfe:

    # Mom "Just working on a few projects I can’t bring into the office. I’ll have them cleared up soon enough."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:53
translate chinese MLR3_MS2_968ad036:

    # MC "Is it something I can help with?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:57
translate chinese MLR3_MS2_00751020:

    # Mom "Not this time, Sweetie. I’ll keep you in mind if something comes up that you can help me with though."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:58
translate chinese MLR3_MS2_2b9936b8:

    # MC "No problem. I love your dress, by the way! Is it a new one?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:59
translate chinese MLR3_MS2_c0456c40:

    # Mom "This thing? I’ve had it for a couple of years. I used to wear it to company functions, but the other men would sometimes get a bit too feely when the drinks started to flow."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:60
translate chinese MLR3_MS2_c6cd0852:

    # MC "Well, it certainly shows off your best assets!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:64
translate chinese MLR3_MS2_d6850d86_1:

    # Mom "..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:65
translate chinese MLR3_MS2_08ab770d:

    # Mom "(Yes... Now when I look at him, I know this will be a perfect idea!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:66
translate chinese MLR3_MS2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:69
translate chinese MLR3_MS2_e101bb2b:

    # Mom "Hmm? Sorry, what did you say?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:73
translate chinese MLR3_MS2_45f33a72:

    # MC "I said, that dress shows off your best assets. Are you okay?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:74
translate chinese MLR3_MS2_58455c9a:

    # Mom "Sorry, just lost in thought."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:75
translate chinese MLR3_MS2_8459d254:

    # MC "You seem rather distracted today. Is everything okay? Something on your mind?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:79
translate chinese MLR3_MS2_2d70fa74:

    # Mom "I.. uh... y-yeah, everything is fine. Why? Did something happen?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:80
translate chinese MLR3_MS2_5661f00d:

    # MC "Hmm, as long as you’re okay."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:84
translate chinese MLR3_MS2_b119265c:

    # Mom "Really, I’m fine. I just have a lot on my plate right now. I’ll be more focused when things calm down."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:85
translate chinese MLR3_MS2_4e8f7612:

    # MC "No sweat."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:86
translate chinese MLR3_MS2_65624db3:

    # Mom "Err... random question, are you planning to go away anytime soon?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:87
translate chinese MLR3_MS2_39f5c646:

    # MC "Away? What do you mean?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:91
translate chinese MLR3_MS2_c76977ca:

    # Mom "You know... like a holiday or weekend break?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:92
translate chinese MLR3_MS2_b8ee85fd:

    # MC "Umm... I don’t think so. Why?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:93
translate chinese MLR3_MS2_d7afdc0e:

    # Mom "No reason!"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:97
translate chinese MLR3_MS2_59245a3d:

    # MC "(She’s acting so bizarre right now!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:98
translate chinese MLR3_MS2_979e3858:

    # MC "Okay, is it a problem if I had something booked?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:99
translate chinese MLR3_MS2_3b723046:

    # Mom "Can you hold off on making plans? I might need your help, for something soon."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:100
translate chinese MLR3_MS2_8c6a877b:

    # MC "Huh, no problem."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_MS2.rpy:101
translate chinese MLR3_MS2_d839a24b:

    # Mom "Just put it out of your head. I’ll talk about it with you later on."
    Mom ""

