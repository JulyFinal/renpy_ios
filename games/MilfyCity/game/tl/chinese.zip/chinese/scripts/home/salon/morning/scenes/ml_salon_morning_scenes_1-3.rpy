﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:47
translate chinese ml_morning_salon_scenes1to3_v1_label_21bf76d6:

    # MC "(I should go wash the dishes.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:52
translate chinese ml_morning_salon_scenes1to3_v1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:62
translate chinese ml_morning_salon_scenes1to3_v1_label_b43447e8:

    # Television "...are in a high speed pursuit with three masked men."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:63
translate chinese ml_morning_salon_scenes1to3_v1_label_4b36e152:

    # Television "The vehicle was stolen from a local bank parking lot."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:66
translate chinese ml_morning_salon_scenes1to3_v1_label_44769379:

    # MC "(Looks like Mom’s watching the morning news.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:68
translate chinese ml_morning_salon_scenes1to3_v1_label_3f82340c:

    # MC "Morning, Mom!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:70
translate chinese ml_morning_salon_scenes1to3_v1_label_0877c9d6:

    # MC "(Looks like Linda’s watching the morning news.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:73
translate chinese ml_morning_salon_scenes1to3_v1_label_35e122b6:

    # MC "Morning, Linda!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:74
translate chinese ml_morning_salon_scenes1to3_v1_label_411ebead:

    # Mom "Good morning, [player_name]. Where are you off to?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:75
translate chinese ml_morning_salon_scenes1to3_v1_label_c128d9f2:

    # MC "It’s a college day, remember?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:76
translate chinese ml_morning_salon_scenes1to3_v1_label_b81b520b:

    # Mom "Oh! Right."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:77
translate chinese ml_morning_salon_scenes1to3_v1_label_55c1c17b:

    # Mom "You’ve still got some time. Come and sit beside me for a while."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:78
translate chinese ml_morning_salon_scenes1to3_v1_label_4be45c59:

    # MC "Uh, okay."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:81
translate chinese ml_morning_salon_scenes1to3_v1_label_a88c46c3:

    # MC "I’ve only got a few minutes - I can’t stay too long, or I’ll-"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:82
translate chinese ml_morning_salon_scenes1to3_v1_label_aab722c4:

    # Mom "I know - you’ll be late for class."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:83
translate chinese ml_morning_salon_scenes1to3_v1_label_f08c44f1:

    # Mom "I’m going to teach you a very important lesson right now. One that you should have learnt YEARS ago."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:85
translate chinese ml_morning_salon_scenes1to3_v1_label_a462dbc6:

    # Mom "Never let your work get in the way of quality family time."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:87
translate chinese ml_morning_salon_scenes1to3_v1_label_7b41b667:

    # Mom "Never let your work get in the way of building good quality friendships."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:91
translate chinese ml_morning_salon_scenes1to3_v1_label_e20d760d:

    # Mom "Even if that means just getting a few minutes in front of the TV with your son, before he goes to college."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:93
translate chinese ml_morning_salon_scenes1to3_v1_label_921f3142:

    # Mom "Even if that means just getting a few minutes in front of the TV with me before you go to college."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:94
translate chinese ml_morning_salon_scenes1to3_v1_label_31dfef05:

    # MC "Uh... Okay. I’ll remember that."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:95
translate chinese ml_morning_salon_scenes1to3_v1_label_39bea479:

    # Mom "Please do. You’ll look back on this in ten years time and be grateful that you spent time fostering relationships."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:99
translate chinese ml_morning_salon_scenes1to3_v1_label_b3a5e795:

    # MC "(Holy shit! Mom’s not wearing a bra!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:101
translate chinese ml_morning_salon_scenes1to3_v1_label_b875055d:

    # MC "(Holy shit! Linda’s not wearing a bra!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:102
translate chinese ml_morning_salon_scenes1to3_v1_label_53082c17:

    # MC "(Why isn’t she wearing one?!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:103
translate chinese ml_morning_salon_scenes1to3_v1_label_e832bb1b:

    # MC "(She’s leaning so close that I can almost feel her left nipple!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:104
translate chinese ml_morning_salon_scenes1to3_v1_label_e07ee20a:

    # Mom "...and I’ll never make that mistake again."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:107
translate chinese ml_morning_salon_scenes1to3_v1_label_08ec63cc:

    # Mom "Are you listening, [player_name]?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:108
translate chinese ml_morning_salon_scenes1to3_v1_label_3751b1e2:

    # MC "Huh?! Oh! Y-Yeah!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:109
translate chinese ml_morning_salon_scenes1to3_v1_label_4f7fada2:

    # Mom "Here, let me give you a kiss, before you rush off to class."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:112
translate chinese ml_morning_salon_scenes1to3_v1_label_66a1c066:

    # MC "(Uh oh... Is she going to-)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:113
translate chinese ml_morning_salon_scenes1to3_v1_label_b9370c6d:

    # MC "(Oh, it’s just on the cheek. My heart started racing there!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:115
translate chinese ml_morning_salon_scenes1to3_v1_label_195ff4f9:

    # MC "(Maybe I am over analyzing things? Perhaps that kiss before, was her being a loving mother?)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:117
translate chinese ml_morning_salon_scenes1to3_v1_label_cbfda419:

    # MC "(Maybe I am over analyzing things? Perhaps that kiss before, was her being a loving friend?)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:118
translate chinese ml_morning_salon_scenes1to3_v1_label_f97e6f7f:

    # MC "(I’ve got to stop replaying it in my mind.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:121
translate chinese ml_morning_salon_scenes1to3_v1_label_6bddd499:

    # MC "(Huh?! She’s turning my head! This ISN’T a peck on the cheek!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:122
translate chinese ml_morning_salon_scenes1to3_v1_label_11281868:

    # MC "(What should I do?!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:124
translate chinese ml_morning_salon_scenes1to3_v1_label_ed28ebe3:

    # MC "(I can’t kiss her back like this - she’s my mother! It’s FAR too intimate!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:126
translate chinese ml_morning_salon_scenes1to3_v1_label_190321ad:

    # MC "(I'm not sure if I should respond to her kiss like this! She's much older than me! She could practically be my mother! It feels way too intimate!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:128
translate chinese ml_morning_salon_scenes1to3_v1_label_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:129
translate chinese ml_morning_salon_scenes1to3_v1_label_1943d626:

    # MC "(She’s biting my lower lip!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:130
translate chinese ml_morning_salon_scenes1to3_v1_label_183b850d:

    # MC "(That’s it - any chances of this just being a regular kiss are out the window.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:133
translate chinese ml_morning_salon_scenes1to3_v1_label_bac03fc8:

    # Mom "(Oh fuck! I almost did it again!)"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:134
translate chinese ml_morning_salon_scenes1to3_v1_label_47a68bd1:

    # Mom "I- um... I have to rush to work now. See you tonight!"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:136
translate chinese ml_morning_salon_scenes1to3_v1_label_28f45a3b:

    # MC "Uh... S-See you later, Mom..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:138
translate chinese ml_morning_salon_scenes1to3_v1_label_ebe90201:

    # MC "Uh... S-See you later, Linda... (Is she interested in me, or is that incident with Celia causing me to have strange thoughts?)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:139
translate chinese ml_morning_salon_scenes1to3_v1_label_bba7cab1:

    # Mom "(Maybe I got lucky, and I broke off the kiss off before he got suspicious?)"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:152
translate chinese ml_morning_salon_scenes1to3_v1_label_eb740dfa:

    # Mom "Morning, [player_name]."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:154
translate chinese ml_morning_salon_scenes1to3_v1_label_8a7dc386:

    # MC "Hey, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:156
translate chinese ml_morning_salon_scenes1to3_v1_label_32bdb685:

    # MC "Hey, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:157
translate chinese ml_morning_salon_scenes1to3_v1_label_cd46045a:

    # Mom "Are you about to leave for college?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:158
translate chinese ml_morning_salon_scenes1to3_v1_label_00621fe6:

    # MC "In a few minutes, yeah."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:159
translate chinese ml_morning_salon_scenes1to3_v1_label_f97ca21e:

    # Mom "Do you have time to wash a few dishes before you go?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:163
translate chinese ml_morning_salon_scenes1to3_v1_label_a2978dac:

    # MC "Sure, no problem."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:164
translate chinese ml_morning_salon_scenes1to3_v1_label_6405b8f6:

    # Mom "Thanks! You’re a sweetie."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:176
translate chinese ml_morning_salon_scenes1to3_v1_label_98a12696:

    # MC "Sorry, Mom. I’m in a bit of a rush. I can’t afford to be late."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:177
translate chinese ml_morning_salon_scenes1to3_v1_label_a53b0328:

    # Mom "Don’t worry, I’ll get them later. Enjoy your day!"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:178
translate chinese ml_morning_salon_scenes1to3_v1_label_58844155:

    # MC "Thanks, Mom!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:180
translate chinese ml_morning_salon_scenes1to3_v1_label_748d0c16:

    # MC "Sorry, Linda. I’m in a bit of a rush. I can’t afford to be late."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:181
translate chinese ml_morning_salon_scenes1to3_v1_label_a53b0328_1:

    # Mom "Don’t worry, I’ll get them later. Enjoy your day!"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:182
translate chinese ml_morning_salon_scenes1to3_v1_label_bc6f5a79:

    # MC "Thanks, Linda!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:191
translate chinese ml_morning_salon_scenes1to3_v1_label_7f647179:

    # MC "Morning, Mom! I’m heading to college now."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:193
translate chinese ml_morning_salon_scenes1to3_v1_label_84da5df8:

    # MC "Morning, Linda! I’m heading to college now."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:194
translate chinese ml_morning_salon_scenes1to3_v1_label_3800c856:

    # Mom "Wait - don’t go yet!"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:197
translate chinese ml_morning_salon_scenes1to3_v1_label_392c19fa:

    # Mom "Sit with me awhile."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:198
translate chinese ml_morning_salon_scenes1to3_v1_label_1a4c8084:

    # MC "I don’t want to be late."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:199
translate chinese ml_morning_salon_scenes1to3_v1_label_0023c0c7:

    # Mom "You won’t be late - just a few minutes."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:200
translate chinese ml_morning_salon_scenes1to3_v1_label_615eedc7:

    # MC "Okay."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:203
translate chinese ml_morning_salon_scenes1to3_v1_label_a58b068c:

    # Mom "So, have you got your eye on any girls right now?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:209
translate chinese ml_morning_salon_scenes1to3_v1_label_93277a6c:

    # MC "I’ve seen a few cute girls about. You know how guys are."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:210
translate chinese ml_morning_salon_scenes1to3_v1_label_a78dfc91:

    # Mom "Oooh, I hope you’re not going to turn into one of those playboys who chases all the girls!!"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:212
translate chinese ml_morning_salon_scenes1to3_v1_label_7ecceeae:

    # MC "Mom!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:214
translate chinese ml_morning_salon_scenes1to3_v1_label_fa3a6335:

    # MC "Linda!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:215
translate chinese ml_morning_salon_scenes1to3_v1_label_d0048356:

    # Mom "Hehe, I’m just teasing you."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:218
translate chinese ml_morning_salon_scenes1to3_v1_label_e31f6997:

    # Mom "You know that no matter what you do, I’ll always be proud of my boy."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:220
translate chinese ml_morning_salon_scenes1to3_v1_label_77b19a8d:

    # Mom "Anyway, I’m keeping you back from your studies. Get some good grades and make me proud."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:222
translate chinese ml_morning_salon_scenes1to3_v1_label_37b3dc02:

    # MC "Haha! You’re gonna make me blush, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:224
translate chinese ml_morning_salon_scenes1to3_v1_label_0267727a:

    # MC "Haha! You’re gonna make me blush, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:225
translate chinese ml_morning_salon_scenes1to3_v1_label_b8e7fdfe:

    # MC "(She seems... different today. I wonder what’s gotten into her.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:229
translate chinese ml_morning_salon_scenes1to3_v1_label_a341c4dc:

    # MC "Umm... Mom?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:231
translate chinese ml_morning_salon_scenes1to3_v1_label_53f7bd29:

    # MC "Umm... Linda?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:232
translate chinese ml_morning_salon_scenes1to3_v1_label_b480a1e8:

    # Television "Up next - are lattes making you fat? Barry McSwindon investigates."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:233
translate chinese ml_morning_salon_scenes1to3_v1_label_45cdee9f:

    # Mom "(Slowly does it... I’m going to move my hand, right up to his crotch and see how he reacts.)"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:236
translate chinese ml_morning_salon_scenes1to3_v1_label_7e0bceff:

    # Television "The truth is, Barry - drinking more than fifty lattes a day, greatly increases your risk of obesity."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:237
translate chinese ml_morning_salon_scenes1to3_v1_label_92d40197:

    # Television "But, Sonja - who the hell drinks fifty cups of coffee a day?!"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:238
translate chinese ml_morning_salon_scenes1to3_v1_label_98608089:

    # Television "That’s not the point I’m trying to make, Barry."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:240
translate chinese ml_morning_salon_scenes1to3_v1_label_b113b2f9:

    # MC "(Mom looks engrossed in her show... I don’t think she’s paying attention to what she’s doing.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:242
translate chinese ml_morning_salon_scenes1to3_v1_label_d7fb4571:

    # MC "(Linda looks engrossed in her show... I don’t think she’s paying attention to what she’s doing.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:244
translate chinese ml_morning_salon_scenes1to3_v1_label_d4e22342:

    # MC "(HUH?!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:245
translate chinese ml_morning_salon_scenes1to3_v1_label_d9634311:

    # Television "A typical latte from StarFucks has 190 calories. If you multiply that by fifty-"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:246
translate chinese ml_morning_salon_scenes1to3_v1_label_46186207:

    # Television "Jesus Fucking Christ, Sonja! You’re missing the point!"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:250
translate chinese ml_morning_salon_scenes1to3_v1_label_7c1463eb:

    # MC "M-Mom! Your hand!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:252
translate chinese ml_morning_salon_scenes1to3_v1_label_fc53d302:

    # MC "L-Linda! Your hand!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:253
translate chinese ml_morning_salon_scenes1to3_v1_label_2b4e5afa:

    # Mom "Huh? Oops! Sorry, I was trying to grab your arm. I thought you had it resting on your lap."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:254
translate chinese ml_morning_salon_scenes1to3_v1_label_0efb08b4:

    # Mom "I should have looked."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:257
translate chinese ml_morning_salon_scenes1to3_v1_label_041b1cf5:

    # MC "Why did you want to grab my arm?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:258
translate chinese ml_morning_salon_scenes1to3_v1_label_5b8fe4c6:

    # Mom "Here, let me show you."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:261
translate chinese ml_morning_salon_scenes1to3_v1_label_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:262
translate chinese ml_morning_salon_scenes1to3_v1_label_198a3d9a:

    # Mom "Do you feel that?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:263
translate chinese ml_morning_salon_scenes1to3_v1_label_443642f9:

    # MC "Y-Yeah - but I don’t think I should!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:264
translate chinese ml_morning_salon_scenes1to3_v1_label_0430f206:

    # Mom "My heartbeat."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:265
translate chinese ml_morning_salon_scenes1to3_v1_label_b2c21f6a:

    # MC "Oh! R-Right."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:268
translate chinese ml_morning_salon_scenes1to3_v1_label_ea6b8999:

    # Mom "Do you feel, how fast it beats around you?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:269
translate chinese ml_morning_salon_scenes1to3_v1_label_0173610a:

    # Mom "It’s only around you. You’re special to me."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:271
translate chinese ml_morning_salon_scenes1to3_v1_label_f869b2cc:

    # MC "M-Mom..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:273
translate chinese ml_morning_salon_scenes1to3_v1_label_3b4eb2e9:

    # MC "L-Linda..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:275
translate chinese ml_morning_salon_scenes1to3_v1_label_82b3076d:

    # Mom "Always remember my heartbeat, and you’ll know how much you mean to me."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:276
translate chinese ml_morning_salon_scenes1to3_v1_label_813900f8:

    # Mom "I really do lov..-ike you, [player_name]."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:278
translate chinese ml_morning_salon_scenes1to3_v1_label_4889ace0:

    # MC "I will, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:280
translate chinese ml_morning_salon_scenes1to3_v1_label_0a3f4d39:

    # MC "I will, Linda. (What’s with her? What about Bob?)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:281
translate chinese ml_morning_salon_scenes1to3_v1_label_84abe89b:

    # MC "(What’s gotten into her today? I’ve never seen her act this emotionally before.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:284
translate chinese ml_morning_salon_scenes1to3_v1_label_36d11300:

    # Mom "Okay, you better get to college. I’m gonna make you late."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:286
translate chinese ml_morning_salon_scenes1to3_v1_label_d854faa9:

    # MC "It’s okay, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:288
translate chinese ml_morning_salon_scenes1to3_v1_label_e3a0c50e:

    # MC "It’s okay, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:289
translate chinese ml_morning_salon_scenes1to3_v1_label_a70c183b:

    # Mom "See you later on."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:293
translate chinese ml_morning_salon_scenes1to3_v1_label_883ad1b6:

    # MC "Bye, Mom. See you later..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:295
translate chinese ml_morning_salon_scenes1to3_v1_label_a0fcbc38:

    # MC "Bye, Linda. See you later..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:296
translate chinese ml_morning_salon_scenes1to3_v1_label_b369d5cf:

    # MC "(She’s acting really bizarre lately. I wonder if there’s something she’s not telling me.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:311
translate chinese ml_morning_salon_scenes1to3_v1_label_0fd69328:

    # MC "I’ve kinda got my eye on one right now."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:312
translate chinese ml_morning_salon_scenes1to3_v1_label_be55aeb6:

    # Mom "Oh... You do?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:313
translate chinese ml_morning_salon_scenes1to3_v1_label_01f3cca0:

    # MC "Yeah. Are you alright?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:314
translate chinese ml_morning_salon_scenes1to3_v1_label_5f105d89:

    # Mom "Oh yeah! I’m fine! I’m great."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:317
translate chinese ml_morning_salon_scenes1to3_v1_label_e31f6997_1:

    # Mom "You know that no matter what you do, I’ll always be proud of my boy."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:319
translate chinese ml_morning_salon_scenes1to3_v1_label_77b19a8d_1:

    # Mom "Anyway, I’m keeping you back from your studies. Get some good grades and make me proud."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:321
translate chinese ml_morning_salon_scenes1to3_v1_label_37b3dc02_1:

    # MC "Haha! You’re gonna make me blush, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:323
translate chinese ml_morning_salon_scenes1to3_v1_label_0267727a_1:

    # MC "Haha! You’re gonna make me blush, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:324
translate chinese ml_morning_salon_scenes1to3_v1_label_b8e7fdfe_1:

    # MC "(She seems... different today. I wonder what’s gotten into her.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:328
translate chinese ml_morning_salon_scenes1to3_v1_label_a341c4dc_1:

    # MC "Umm... Mom?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:330
translate chinese ml_morning_salon_scenes1to3_v1_label_53f7bd29_1:

    # MC "Umm... Linda?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:331
translate chinese ml_morning_salon_scenes1to3_v1_label_b480a1e8_1:

    # Television "Up next - are lattes making you fat? Barry McSwindon investigates."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:332
translate chinese ml_morning_salon_scenes1to3_v1_label_45cdee9f_1:

    # Mom "(Slowly does it... I’m going to move my hand, right up to his crotch and see how he reacts.)"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:335
translate chinese ml_morning_salon_scenes1to3_v1_label_7e0bceff_1:

    # Television "The truth is, Barry - drinking more than fifty lattes a day, greatly increases your risk of obesity."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:336
translate chinese ml_morning_salon_scenes1to3_v1_label_92d40197_1:

    # Television "But, Sonja - who the hell drinks fifty cups of coffee a day?!"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:337
translate chinese ml_morning_salon_scenes1to3_v1_label_98608089_1:

    # Television "That’s not the point I’m trying to make, Barry."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:339
translate chinese ml_morning_salon_scenes1to3_v1_label_b113b2f9_1:

    # MC "(Mom looks engrossed in her show... I don’t think she’s paying attention to what she’s doing.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:341
translate chinese ml_morning_salon_scenes1to3_v1_label_d7fb4571_1:

    # MC "(Linda looks engrossed in her show... I don’t think she’s paying attention to what she’s doing.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:343
translate chinese ml_morning_salon_scenes1to3_v1_label_d4e22342_1:

    # MC "(HUH?!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:344
translate chinese ml_morning_salon_scenes1to3_v1_label_d9634311_1:

    # Television "A typical latte from StarFucks has 190 calories. If you multiply that by fifty-"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:345
translate chinese ml_morning_salon_scenes1to3_v1_label_46186207_1:

    # Television "Jesus Fucking Christ, Sonja! You’re missing the point!"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:349
translate chinese ml_morning_salon_scenes1to3_v1_label_7c1463eb_1:

    # MC "M-Mom! Your hand!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:351
translate chinese ml_morning_salon_scenes1to3_v1_label_fc53d302_1:

    # MC "L-Linda! Your hand!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:352
translate chinese ml_morning_salon_scenes1to3_v1_label_2b4e5afa_1:

    # Mom "Huh? Oops! Sorry, I was trying to grab your arm. I thought you had it resting on your lap."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:353
translate chinese ml_morning_salon_scenes1to3_v1_label_0efb08b4_1:

    # Mom "I should have looked."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:356
translate chinese ml_morning_salon_scenes1to3_v1_label_041b1cf5_1:

    # MC "Why did you want to grab my arm?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:357
translate chinese ml_morning_salon_scenes1to3_v1_label_5b8fe4c6_1:

    # Mom "Here, let me show you."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:360
translate chinese ml_morning_salon_scenes1to3_v1_label_95e59f81_1:

    # MC "What?!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:361
translate chinese ml_morning_salon_scenes1to3_v1_label_198a3d9a_1:

    # Mom "Do you feel that?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:362
translate chinese ml_morning_salon_scenes1to3_v1_label_443642f9_1:

    # MC "Y-Yeah - but I don’t think I should!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:363
translate chinese ml_morning_salon_scenes1to3_v1_label_0430f206_1:

    # Mom "My heartbeat."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:364
translate chinese ml_morning_salon_scenes1to3_v1_label_b2c21f6a_1:

    # MC "Oh! R-Right."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:367
translate chinese ml_morning_salon_scenes1to3_v1_label_ea6b8999_1:

    # Mom "Do you feel, how fast it beats around you?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:368
translate chinese ml_morning_salon_scenes1to3_v1_label_0173610a_1:

    # Mom "It’s only around you. You’re special to me."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:370
translate chinese ml_morning_salon_scenes1to3_v1_label_f869b2cc_1:

    # MC "M-Mom..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:372
translate chinese ml_morning_salon_scenes1to3_v1_label_3b4eb2e9_1:

    # MC "L-Linda..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:374
translate chinese ml_morning_salon_scenes1to3_v1_label_82b3076d_1:

    # Mom "Always remember my heartbeat, and you’ll know how much you mean to me."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:375
translate chinese ml_morning_salon_scenes1to3_v1_label_813900f8_1:

    # Mom "I really do lov..-ike you, [player_name]."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:377
translate chinese ml_morning_salon_scenes1to3_v1_label_4889ace0_1:

    # MC "I will, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:379
translate chinese ml_morning_salon_scenes1to3_v1_label_0a3f4d39_1:

    # MC "I will, Linda. (What’s with her? What about Bob?)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:380
translate chinese ml_morning_salon_scenes1to3_v1_label_84abe89b_1:

    # MC "(What’s gotten into her today? I’ve never seen her act this emotionally before.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:383
translate chinese ml_morning_salon_scenes1to3_v1_label_36d11300_1:

    # Mom "Okay, you better get to college. I’m gonna make you late."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:385
translate chinese ml_morning_salon_scenes1to3_v1_label_d854faa9_1:

    # MC "It’s okay, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:387
translate chinese ml_morning_salon_scenes1to3_v1_label_e3a0c50e_1:

    # MC "It’s okay, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:388
translate chinese ml_morning_salon_scenes1to3_v1_label_a70c183b_1:

    # Mom "See you later on."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:392
translate chinese ml_morning_salon_scenes1to3_v1_label_883ad1b6_1:

    # MC "Bye, Mom. See you later..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:394
translate chinese ml_morning_salon_scenes1to3_v1_label_a0fcbc38_1:

    # MC "Bye, Linda. See you later..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:395
translate chinese ml_morning_salon_scenes1to3_v1_label_b369d5cf_1:

    # MC "(She’s acting really bizarre lately. I wonder if there’s something she’s not telling me.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:410
translate chinese ml_morning_salon_scenes1to3_v1_label_59a0fbf8:

    # MC "Nah, I’d rather be single for a while. Especially after that embarrassing situation with Ms. Celia."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:411
translate chinese ml_morning_salon_scenes1to3_v1_label_36e487a8:

    # Mom "Good."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:412
translate chinese ml_morning_salon_scenes1to3_v1_label_a5072317:

    # MC "Good?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:413
translate chinese ml_morning_salon_scenes1to3_v1_label_5d9df147:

    # Mom "Err... I mean, it’s good that you’re... taking things slow and recovering."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:414
translate chinese ml_morning_salon_scenes1to3_v1_label_0526541d:

    # MC "Oh, right."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:418
translate chinese ml_morning_salon_scenes1to3_v1_label_e31f6997_2:

    # Mom "You know that no matter what you do, I’ll always be proud of my boy."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:420
translate chinese ml_morning_salon_scenes1to3_v1_label_77b19a8d_2:

    # Mom "Anyway, I’m keeping you back from your studies. Get some good grades and make me proud."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:422
translate chinese ml_morning_salon_scenes1to3_v1_label_37b3dc02_2:

    # MC "Haha! You’re gonna make me blush, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:424
translate chinese ml_morning_salon_scenes1to3_v1_label_0267727a_2:

    # MC "Haha! You’re gonna make me blush, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:425
translate chinese ml_morning_salon_scenes1to3_v1_label_b8e7fdfe_2:

    # MC "(She seems... different today. I wonder what’s gotten into her.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:429
translate chinese ml_morning_salon_scenes1to3_v1_label_a341c4dc_2:

    # MC "Umm... Mom?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:431
translate chinese ml_morning_salon_scenes1to3_v1_label_53f7bd29_2:

    # MC "Umm... Linda?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:432
translate chinese ml_morning_salon_scenes1to3_v1_label_b480a1e8_2:

    # Television "Up next - are lattes making you fat? Barry McSwindon investigates."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:433
translate chinese ml_morning_salon_scenes1to3_v1_label_45cdee9f_2:

    # Mom "(Slowly does it... I’m going to move my hand, right up to his crotch and see how he reacts.)"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:436
translate chinese ml_morning_salon_scenes1to3_v1_label_7e0bceff_2:

    # Television "The truth is, Barry - drinking more than fifty lattes a day, greatly increases your risk of obesity."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:437
translate chinese ml_morning_salon_scenes1to3_v1_label_92d40197_2:

    # Television "But, Sonja - who the hell drinks fifty cups of coffee a day?!"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:438
translate chinese ml_morning_salon_scenes1to3_v1_label_98608089_2:

    # Television "That’s not the point I’m trying to make, Barry."
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:440
translate chinese ml_morning_salon_scenes1to3_v1_label_b113b2f9_2:

    # MC "(Mom looks engrossed in her show... I don’t think she’s paying attention to what she’s doing.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:442
translate chinese ml_morning_salon_scenes1to3_v1_label_d7fb4571_2:

    # MC "(Linda looks engrossed in her show... I don’t think she’s paying attention to what she’s doing.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:444
translate chinese ml_morning_salon_scenes1to3_v1_label_d4e22342_2:

    # MC "(HUH?!)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:445
translate chinese ml_morning_salon_scenes1to3_v1_label_d9634311_2:

    # Television "A typical latte from StarFucks has 190 calories. If you multiply that by fifty-"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:446
translate chinese ml_morning_salon_scenes1to3_v1_label_46186207_2:

    # Television "Jesus Fucking Christ, Sonja! You’re missing the point!"
    Television ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:450
translate chinese ml_morning_salon_scenes1to3_v1_label_7c1463eb_2:

    # MC "M-Mom! Your hand!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:452
translate chinese ml_morning_salon_scenes1to3_v1_label_fc53d302_2:

    # MC "L-Linda! Your hand!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:453
translate chinese ml_morning_salon_scenes1to3_v1_label_2b4e5afa_2:

    # Mom "Huh? Oops! Sorry, I was trying to grab your arm. I thought you had it resting on your lap."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:454
translate chinese ml_morning_salon_scenes1to3_v1_label_0efb08b4_2:

    # Mom "I should have looked."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:457
translate chinese ml_morning_salon_scenes1to3_v1_label_041b1cf5_2:

    # MC "Why did you want to grab my arm?"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:458
translate chinese ml_morning_salon_scenes1to3_v1_label_5b8fe4c6_2:

    # Mom "Here, let me show you."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:461
translate chinese ml_morning_salon_scenes1to3_v1_label_95e59f81_2:

    # MC "What?!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:462
translate chinese ml_morning_salon_scenes1to3_v1_label_198a3d9a_2:

    # Mom "Do you feel that?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:463
translate chinese ml_morning_salon_scenes1to3_v1_label_443642f9_2:

    # MC "Y-Yeah - but I don’t think I should!"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:464
translate chinese ml_morning_salon_scenes1to3_v1_label_0430f206_2:

    # Mom "My heartbeat."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:465
translate chinese ml_morning_salon_scenes1to3_v1_label_b2c21f6a_2:

    # MC "Oh! R-Right."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:468
translate chinese ml_morning_salon_scenes1to3_v1_label_ea6b8999_2:

    # Mom "Do you feel, how fast it beats around you?"
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:469
translate chinese ml_morning_salon_scenes1to3_v1_label_0173610a_2:

    # Mom "It’s only around you. You’re special to me."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:471
translate chinese ml_morning_salon_scenes1to3_v1_label_f869b2cc_2:

    # MC "M-Mom..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:473
translate chinese ml_morning_salon_scenes1to3_v1_label_3b4eb2e9_2:

    # MC "L-Linda..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:475
translate chinese ml_morning_salon_scenes1to3_v1_label_82b3076d_2:

    # Mom "Always remember my heartbeat, and you’ll know how much you mean to me."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:476
translate chinese ml_morning_salon_scenes1to3_v1_label_813900f8_2:

    # Mom "I really do lov..-ike you, [player_name]."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:478
translate chinese ml_morning_salon_scenes1to3_v1_label_4889ace0_2:

    # MC "I will, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:480
translate chinese ml_morning_salon_scenes1to3_v1_label_0a3f4d39_2:

    # MC "I will, Linda. (What’s with her? What about Bob?)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:481
translate chinese ml_morning_salon_scenes1to3_v1_label_84abe89b_2:

    # MC "(What’s gotten into her today? I’ve never seen her act this emotionally before.)"
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:484
translate chinese ml_morning_salon_scenes1to3_v1_label_36d11300_2:

    # Mom "Okay, you better get to college. I’m gonna make you late."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:486
translate chinese ml_morning_salon_scenes1to3_v1_label_d854faa9_2:

    # MC "It’s okay, Mom."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:488
translate chinese ml_morning_salon_scenes1to3_v1_label_e3a0c50e_2:

    # MC "It’s okay, Linda."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:489
translate chinese ml_morning_salon_scenes1to3_v1_label_a70c183b_2:

    # Mom "See you later on."
    Mom ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:493
translate chinese ml_morning_salon_scenes1to3_v1_label_883ad1b6_2:

    # MC "Bye, Mom. See you later..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:495
translate chinese ml_morning_salon_scenes1to3_v1_label_a0fcbc38_2:

    # MC "Bye, Linda. See you later..."
    MC ""

# game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:496
translate chinese ml_morning_salon_scenes1to3_v1_label_b369d5cf_2:

    # MC "(She’s acting really bizarre lately. I wonder if there’s something she’s not telling me.)"
    MC ""

translate chinese strings:

    # game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:205
    old "I’ve seen a few cute ones around."
    new ""

    # game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:205
    old "Just one right now."
    new ""

    # game/scripts/home/salon/morning/scenes/ml_salon_morning_scenes_1-3.rpy:205
    old "No, I’d rather be single for a while."
    new ""

