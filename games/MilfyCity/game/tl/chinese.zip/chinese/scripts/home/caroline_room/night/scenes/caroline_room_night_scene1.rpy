﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:122
translate chinese caroline_room_night_scene1_label_4ea5d130:

    # MC "(I've already done something tonight.. I’ll let her sleep.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:131
translate chinese caroline_room_night_scene1_label_4834de63:

    # MC "Whispered Hey, Caroline? Are you asleep?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:133
translate chinese caroline_room_night_scene1_label_bb111e43:

    # Caroline "Zzz... Hmm?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:137
translate chinese caroline_room_night_scene1_label_0f89a9f6:

    # Caroline "[player_name]? I already told you - the deal's off."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:139
translate chinese caroline_room_night_scene1_label_3aa0362e:

    # MC "I know, but it's all I can think about."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:143
translate chinese caroline_room_night_scene1_label_e5e03392:

    # Caroline "You need to move on with your life. And I really need to get some sleep."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:147
translate chinese caroline_room_night_scene1_label_a8d98881:

    # MC "Caroline, please-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:149
translate chinese caroline_room_night_scene1_label_a420c03b:

    # Caroline "The deal isn't up for discussion or negotitation. It's over. Goodnight, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:151
translate chinese caroline_room_night_scene1_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:153
translate chinese caroline_room_night_scene1_label_20258f7b:

    # MC "Sigh Goodnight Caroline. Sorry for bothering you."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:163
translate chinese caroline_room_night_scene1_label_4834de63_1:

    # MC "Whispered Hey, Caroline? Are you asleep?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:165
translate chinese caroline_room_night_scene1_label_bb111e43_1:

    # Caroline "Zzz... Hmm?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:169
translate chinese caroline_room_night_scene1_label_1d43a1a2:

    # Caroline "[player_name]? What's going on? Are you okay? Is something wrong?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:173
translate chinese caroline_room_night_scene1_label_f640580a:

    # MC "Nothing's wrong! Sorry for making you worry."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:175
translate chinese caroline_room_night_scene1_label_23a0e851:

    # MC "I couldn't sleep. I wanted to check if you'd like to watch a movie with me? There's that great new Russian streaming service that has no movies on it - Nyetflix."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:179
translate chinese caroline_room_night_scene1_label_bd6ccbdb:

    # Caroline "Sorry, I really need to rest. I've got stuff to do for work in the morning."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:181
translate chinese caroline_room_night_scene1_label_f2fc5dcc:

    # MC "Of course, sorry for bothering you. Sleep tight, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:183
translate chinese caroline_room_night_scene1_label_c6bbcfd9:

    # Caroline "Sweet dreams, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:188
translate chinese caroline_room_night_scene1_label_cbf0d915:

    # MC "Hey Caroline, I didn’t wake you up, did I?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:189
translate chinese caroline_room_night_scene1_label_428d3808:

    # Caroline "Nah, I was just finishing a couple of chapters of my book. What’s up?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:192
translate chinese caroline_room_night_scene1_label_b0d046fa:

    # MC "I was wondering if you fancied doing some roleplay?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:193
translate chinese caroline_room_night_scene1_label_37ebc258:

    # Caroline "Roleplay? What do you mean?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:194
translate chinese caroline_room_night_scene1_label_086fb8f6:

    # MC "I was thinking that you could pretend to be asleep and let me play with your body."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:197
translate chinese caroline_room_night_scene1_label_c99458c3:

    # Caroline "Pretend to be asleep?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:198
translate chinese caroline_room_night_scene1_label_9b0903a4:

    # MC "Yeah! Just pretend to be asleep and I’ll play with your body."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:199
translate chinese caroline_room_night_scene1_label_fba8a606:

    # Caroline "I guess so. What do you want to do to me?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:202
translate chinese caroline_room_night_scene1_label_380663ab:

    # MC "Whatever you’re down for!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:203
translate chinese caroline_room_night_scene1_label_391805e0:

    # Caroline "Hmm... There’s a few things I might be willing to try..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:204
translate chinese caroline_room_night_scene1_label_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:209
translate chinese caroline_room_night_scene1_label_73408423:

    # MC "(I need to be quiet, I don’t want to wake anyone else in the house!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:212
translate chinese caroline_room_night_scene1_label_20edb5be:

    # MC "(Just look at those breasts! They’re fucking massive!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:213
translate chinese caroline_room_night_scene1_label_a6d6a886:

    # MC "(Hehe, I’m gonna have some fun with you tonight!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:214
translate chinese caroline_room_night_scene1_label_e85410d3:

    # MC "(Where should we begin...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:220
translate chinese caroline_room_night_scene1_label_7345ee5e:

    # MC "(I hope I haven’t come in too early. I need to wait until Caroline’s in a deep sleep.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:221
translate chinese caroline_room_night_scene1_label_a146de18:

    # MC "(Hmm... She doesn’t seem to have moved since I opened the door.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:222
translate chinese caroline_room_night_scene1_label_07dff19c:

    # MC "(I guess it’s safe for me to creep across the room now.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:225
translate chinese caroline_room_night_scene1_label_20edb5be_1:

    # MC "(Just look at those breasts! They’re fucking massive!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:226
translate chinese caroline_room_night_scene1_label_ee337f9c:

    # MC "(Hehe... I’m gonna have some fun with you tonight, Caroline.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:227
translate chinese caroline_room_night_scene1_label_79640298:

    # MC "(But where to begin...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:297
translate chinese CR2_NS_label_74d4d3a3:

    # Caroline "[player_name]? Do you want some help again with your big issue?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:298
translate chinese CR2_NS_label_9eafdb6f:

    # Caroline "What’s it gonna be, [player_name]?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:303
translate chinese CR2_NS_label_221a045c:

    # MC "Hey, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:304
translate chinese CR2_NS_label_635ed007:

    # Caroline "Hmm? What time is it?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:305
translate chinese CR2_NS_label_2d66878c:

    # Caroline "Did I sleep in?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:309
translate chinese CR2_NS_label_347429bd:

    # Caroline "Huh?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:310
translate chinese CR2_NS_label_7e13c036:

    # Caroline "(Did I forget to lock my door last night?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:311
translate chinese CR2_NS_label_53f4f33f:

    # Caroline "(Wait... It’s still dark..?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:315
translate chinese CR2_NS_label_89e4f6f5:

    # Caroline "[player_name]! Did you just break into my room?!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:316
translate chinese CR2_NS_label_c0afc856:

    # MC "No, I-"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:317
translate chinese CR2_NS_label_eb9cc573:

    # Caroline "What did you use? A lockpick, or something?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:321
translate chinese CR2_NS_label_47ce3e23:

    # MC "N-No! I just took the spare key from your shop."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:322
translate chinese CR2_NS_label_0c82dccc:

    # Caroline "You stole my spare key?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:323
translate chinese CR2_NS_label_72021254:

    # MC "I was planning on giving it back... sometime."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:327
translate chinese CR2_NS_label_9bbbbf76:

    # Caroline "What the hell are you here for?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:328
translate chinese CR2_NS_label_a35bc9b7:

    # MC "I was kinda hoping, we could maybe do something together tonight?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:329
translate chinese CR2_NS_label_43cdc422:

    # Caroline "What do you mean?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:333
translate chinese CR2_NS_label_b52b6039:

    # MC "We could do some naughty stuff together..?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:334
translate chinese CR2_NS_label_fb76fefb:

    # MC "Nobody would know - as long as we’re quiet. It’s the middle of the night, after all."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:335
translate chinese CR2_NS_label_32406091:

    # Caroline "*Sigh* Fine, I guess I still owe you for those photos."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:339
translate chinese CR2_NS_label_9eafdb6f_1:

    # Caroline "What’s it gonna be, [player_name]?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:340
translate chinese CR2_NS_label_b214546b:

    # Caroline "Would you like a handjob?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:374
translate chinese CNS_1_dc6923e9:

    # MC "(Okay, let’s try putting my cock in her mouth while she sleeps.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:375
translate chinese CNS_1_2512f9fc:

    # MC "(This is gonna be risky. Lips are rather sensitive, and I could very easily wake her up if I’m not careful.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:377
translate chinese CNS_1_21718f3c:

    # Caroline "(I’m so excited for this roleplay tonight! I’ve been waiting for it all day!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:378
translate chinese CNS_1_ff1509f1:

    # MC "(Okay, let’s start by seeing if Caroline will let me put my cock in her mouth..)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:380
translate chinese CNS_1_e7ecc236:

    # MC "(Easy does it...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:383
translate chinese CNS_1_309a795a:

    # MC "Ooh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:384
translate chinese CNS_1_96549d42:

    # MC "(I can feel the warm breath from her nose, blowing over my cock.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:385
translate chinese CNS_1_6b5a6020:

    # MC "(Just another half an inch!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:386
translate chinese CNS_1_7d22a49a:

    # MC "(Damn! Her teeth are in the way.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:389
translate chinese CNS_1_6d1220e2:

    # Caroline "(Hehe! You honestly didn’t think I’d make this easy for you, did you [player_name]?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:393
translate chinese CNS_1_4abc7dd3:

    # MC "(Caroline’s dedicated to the roleplay, I have to give her that!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:394
translate chinese CNS_1_9d19c465:

    # MC "(I’ll have to make her breathe through her mouth instead.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:395
translate chinese CNS_1_7bb309b3:

    # MC "(Let’s see if this works.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:396
translate chinese CNS_1_423adb14:

    # MC "Sorry Caroline..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:398
translate chinese CNS_1_a4cd6437:

    # Caroline "(Haha, fine! You win!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:401
translate chinese CNS_1_a0bfa611:

    # MC "(There we go! She’s beginning to open her mouth!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:402
translate chinese CNS_1_0f84ae9c:

    # MC "(I’m almost in!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:405
translate chinese CNS_1_efb4b496:

    # Caroline "Aahhh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:407
translate chinese CNS_1_5bf7240a:

    # Caroline "Mmpfff..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:408
translate chinese CNS_1_c2d28774:

    # MC "Aahhh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:411
translate chinese CNS_1_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:415
translate chinese CNS_1_ff7dfe03:

    # MC "(This feels so good!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:417
translate chinese CNS_1_0443ce52:

    # MC "(That’s it, Caroline. Suck my cock!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:420
translate chinese CNS_1_96f5a139:

    # Caroline "(God, this is so fucking hot.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:424
translate chinese CNS_1_0277ce1c:

    # MC "(God... I wish I could force it in deeper!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:425
translate chinese CNS_1_aca9b2d1:

    # MC "(Maybe, if I’m really careful, I could get a couple of inches in.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:427
translate chinese CNS_1_8d8ec300:

    # MC "Ahh... (I wish I could push it in deeper!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:428
translate chinese CNS_1_f20efb56:

    # MC "(Let’s see if she’ll let me push another couple of inches in.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:429
translate chinese CNS_1_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:431
translate chinese CNS_1_81e28f2c:

    # MC "(Dammit - I’ve come this far! Let’s do this!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:434
translate chinese CNS_1_1f56d826:

    # MC "Ahh... fuck..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:435
translate chinese CNS_1_f1a9221e:

    # MC "(That’s so good!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:438
translate chinese CNS_1_9003236f:

    # Caroline "(Oh! His cock’s gone a bit too deep. I’ll let him know.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:439
translate chinese CNS_1_974da75c:

    # Caroline "Mmm... Hmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:442
translate chinese CNS_1_c6c837ff:

    # MC "(Oh shit! She’s beginning to wake up!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:444
translate chinese CNS_1_28b156a6:

    # MC "(Oops, that’s the signal that I might have gone too far. I’ll pull my cock out now.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:448
translate chinese CNS_1_7d8e4bdb:

    # MC "(Fuck fuck fuck!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:449
translate chinese CNS_1_f284db84:

    # MC "(I’ve gotta get my dick out of her mouth and bail from her room before she catches me!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:451
translate chinese CNS_1_089b7d3f:

    # MC "(Okay, there we go. Let’s slide it out.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:452
translate chinese CNS_1_e9e92863:

    # Caroline "(That’s better. I’m looking forward to doing this again another night. Roleplaying being asleep was actually pretty fun!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:455
translate chinese CNS_1_7d26f227:

    # MC "(Shit, that was REALLY close!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:467
translate chinese CNS_2_468dcd47:

    # MC "(She looks sound asleep. If I’m really careful I might be able to mess about with her tits.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:468
translate chinese CNS_2_83ef1257:

    # MC "(Well, here goes nothing...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:470
translate chinese CNS_2_5eeaae0e:

    # MC "(Caroline said she was up for some sleep-play. Let’s see if she enjoys me teasing her breasts during this roleplay.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:473
translate chinese CNS_2_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:474
translate chinese CNS_2_56597295:

    # MC "(Just look at that nipple. I’d love to suck on that!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:475
translate chinese CNS_2_9bf07ca0:

    # MC "(And her cleavage is amazing. My cock would fit so perfectly between them!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:477
translate chinese CNS_2_68e15403:

    # Caroline "(This is so exciting! I can sense him looking at my bare breasts right now. I wonder what he’s going to do to me?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:480
translate chinese CNS_2_c0c1ea20:

    # MC "(Mmm! So soft and warm!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:482
translate chinese CNS_2_862691f1:

    # MC "(It doesn’t look like she’s been disturbed yet - maybe I could get away with squeezing it a bit?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:483
translate chinese CNS_2_81e28f81:

    # MC "(Here goes nothing!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:485
translate chinese CNS_2_45f1580b:

    # Caroline "Ohh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:486
translate chinese CNS_2_eddc142a:

    # MC "(It certainly sounds like she’s enjoying it! Maybe I’ll try squeezing it for a bit.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:489
translate chinese CNS_2_f84e5999:

    # MC "(God, her tits are fucking perfect.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:493
translate chinese CNS_2_a6e8d832:

    # MC "(I wonder how she’s react if she woke up right now?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:494
translate chinese CNS_2_3b10ad56:

    # MC "(It’s better not to think about that...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:496
translate chinese CNS_2_a710a107:

    # Caroline "(This is incredible... Mmm... God... I just want him to mount me and fuck my tits right now.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:499
translate chinese CNS_2_fa9eda8d:

    # MC "(Okay, just one final thing to do, then I’ll leave.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:502
translate chinese CNS_2_104b5c66:

    # MC "Ah...."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:503
translate chinese CNS_2_e746f59d:

    # MC "(I’m so fucking hard right now.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:504
translate chinese CNS_2_81df1040:

    # MC "(I wish I could fuck her breasts so much right now.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:507
translate chinese CNS_2_309a795a:

    # MC "Ooh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:509
translate chinese CNS_2_a39afd4d:

    # Caroline "(This feels amazing... I should probably get some actual sleep though! I do have work tomorrow after all. I’ll give [player_name] the signal.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:510
translate chinese CNS_2_71074fd4:

    # Caroline "Hmmm...."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:512
translate chinese CNS_2_943dc732:

    # MC "(Uh oh!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:514
translate chinese CNS_2_d9db5de3:

    # MC "(That was a loud moan there! I think she wants me to stop now.) "
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:517
translate chinese CNS_2_22abeeaf:

    # Caroline "Yawn!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:519
translate chinese CNS_2_4a79e1e5:

    # MC "(Fuck, she’s waking up. Time to bail!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:520
translate chinese CNS_2_d1040182:

    # MC "(That’s a shame - things were just getting good!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:522
translate chinese CNS_2_2111bb21:

    # MC "(Yup, time to go.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:523
translate chinese CNS_2_4153324f:

    # MC "(That’s a shame - things were just getting good! I’ll come back and have some more fun another night when she’s in the mood.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:536
translate chinese CNS_3_97850899:

    # MC "(Okay, Caroline. Let’s see if that ass of yours feels as good as it looks.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:538
translate chinese CNS_3_cb9e9980:

    # MC "(I’ve got my fingers crossed that she’s in a deep enough sleep to not wake up.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:540
translate chinese CNS_3_90ac1a9f:

    # Caroline "(I wonder what [player_name] will do to me tonight. I’m getting all wet just imagining what might happen.) "
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:543
translate chinese CNS_3_969b2b87:

    # MC "(Her whole body is perfect. She won the jackpot on the genetic lottery!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:545
translate chinese CNS_3_7b88a04f:

    # MC "(I can see how she’s my Mom’s daughter. They both have brilliant bodies!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:547
translate chinese CNS_3_650bc362:

    # MC "(God... she’s definitely Linda’s friend. They both have brilliant bodies!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:551
translate chinese CNS_3_a0dcc58d:

    # Caroline "(Snoooore...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:554
translate chinese CNS_3_781ffebd:

    # MC "(Let’s begin by groping her butt a bit.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:556
translate chinese CNS_3_fa4ccf60:

    # MC "(If she doesn’t rouse then I’ll see how far I can take things.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:558
translate chinese CNS_3_e8b08b47:

    # MC "(Come on... Don’t keep me waiting!) "
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:561
translate chinese CNS_3_2fa6b376:

    # MC "(Mmm, she’s got an amazing ass!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:563
translate chinese CNS_3_b34bf164:

    # MC "(Alright, she seems to be in a deep enough sleep for me to rub my cock on her a bit.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:565
translate chinese CNS_3_e1cd21d1:

    # Caroline "(Oooh, he’s playing with my butt tonight!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:566
translate chinese CNS_3_41f1b99f:

    # MC "(Let’s see if Caroline likes having my cock rubbed on her.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:568
translate chinese CNS_3_80564582:

    # MC "(Here we go...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:571
translate chinese CNS_3_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:572
translate chinese CNS_3_55baa8d6:

    # MC "(I’d love to fuck her ass in this position.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:573
translate chinese CNS_3_b7a81864:

    # MC "(I imagine she’s got a very tight asshole.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:575
translate chinese CNS_3_6f2f2b0c:

    # Caroline "Mmm... (I’d love to feel his thick dick buried in my ass right now.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:578
translate chinese CNS_3_4da414a3:

    # MC "(I’d plunge my cock really deep inside her with long slow strokes.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:579
translate chinese CNS_3_e54fa08f:

    # MC "(Then, when I’m done, I’d thrust my hips forward and cum deep in her ass.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:580
translate chinese CNS_3_173ae9d3:

    # MC "(God, the thought of that is getting me so horny!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:583
translate chinese CNS_3_68c5daa5:

    # MC "Oooh.... I would fuck you so hard..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:585
translate chinese CNS_3_347429bd:

    # Caroline "Huh?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:587
translate chinese CNS_3_1d2b343a:

    # Caroline "(Hehe, sounds like he’s forgotten the roleplay and started talking out loud!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:588
translate chinese CNS_3_bc4628d7:

    # Caroline "Hmm?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:590
translate chinese CNS_3_41657564:

    # MC "(Shit! Did I say that out loud?!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:595
translate chinese CNS_3_e1ea0fa5:

    # MC "(Time for me to abandon ship!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:596
translate chinese CNS_3_435ee40c:

    # Caroline "(I’d a really weird dream there... Something about my brother fucking my ass.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:597
translate chinese CNS_3_eb94d6b8:

    # Caroline "(I need to stop eating cheese so late at night. It gives me bizarre dreams!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:599
translate chinese CNS_3_25d7b35e:

    # MC "(That’s awkward, I guess I’ll call it there for the night.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:600
translate chinese CNS_3_a0470de5:

    # Caroline "(It’s good to know that he wants to fuck me as badly as I want to screw him.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:613
translate chinese CNS_4_31069fc5:

    # MC "(Let’s play with her feet a bit tonight.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:614
translate chinese CNS_4_5e7f5db2:

    # MC "(Caroline was kind enough to not wear any socks to bed.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:615
translate chinese CNS_4_4f0e0348:

    # MC "(Mmm, you really do have gorgeous feet, Caroline!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:618
translate chinese CNS_4_75b73b87:

    # MC "(Okay, time to get your toes working on my cock!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:620
translate chinese CNS_4_bb384b72:

    # Caroline "(Hehe! That tickles!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:621
translate chinese CNS_4_4b144c1e:

    # MC "(There we go, almost there...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:624
translate chinese CNS_4_58556015:

    # MC "Ahh... "
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:628
translate chinese CNS_4_f3e5238f:

    # MC "(I just wish I could grab both her feet and thrust my cock between them.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:629
translate chinese CNS_4_a42478e8:

    # MC "(Maybe I could get her other foot before she wakes up?)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:631
translate chinese CNS_4_86e4b888:

    # MC "(I just wish I could grab both her feet and thrust my cock between them. That would probably break the immersion though.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:634
translate chinese CNS_4_7e9409f5:

    # MC "Slowly does it..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:635
translate chinese CNS_4_1b4f62c9:

    # Caroline "Hmm... Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:637
translate chinese CNS_4_f69be4d1:

    # MC "(CRAP! I’ve pushed her too far!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:638
translate chinese CNS_4_20989ede:

    # MC "(Don’t wake up... don’t wake up...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:641
translate chinese CNS_4_91883ce6:

    # Caroline "Mmm... "
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:644
translate chinese CNS_4_48e6741d:

    # Caroline "(This is getting WAY too tickly! I’ll yawn to let him know I've had enough.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:646
translate chinese CNS_4_a77d94fb:

    # Caroline "Yawwwwn!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:648
translate chinese CNS_4_c4e2483f:

    # MC "(Uh oh! Time for me to leg it out of here!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:650
translate chinese CNS_4_bfe3feb3:

    # MC "(Sounds like Caroline’s done for the night. I’ll come back some other time!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:672
translate chinese CNS_wake_1_ff2ecd1c:

    # MC "Could you give me a handjob?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:673
translate chinese CNS_wake_1_541dc698:

    # Caroline "Sure. Take your boxers off and lie back on the bed for me."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:677
translate chinese CNS_wake_1_e8c457fa:

    # Caroline "You must have been looking forward to this, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:678
translate chinese CNS_wake_1_ba4eff9b:

    # Caroline "Your cock is already rock-hard for me. I hardly need to warm it up, at all."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:679
translate chinese CNS_wake_1_67a36871:

    # MC "That was just from looking at you in your underwear."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:683
translate chinese CNS_wake_1_9d2d99d8:

    # Caroline "Well, aren’t you just a little charmer?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:684
translate chinese CNS_wake_1_0e9dc926:

    # Caroline "I know you tend to moan pretty loudly when you cum, but you’re gonna have to keep your voice down tonight."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:686
translate chinese CNS_wake_1_2649a76c:

    # Caroline "If you wake up Mom, Dad, or Sara then our deal is off. Okay?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:688
translate chinese CNS_wake_1_64da656c:

    # Caroline "If you wake up Linda, Bob, or Sara then our deal is off. Okay?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:692
translate chinese CNS_wake_1_fbfad56b:

    # MC "Y-Yeah, I understand."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:695
translate chinese CNS_wake_1_37b7f947:

    # Caroline "I’m serious, [player_name]. If I get caught, wanking off my brother, I’ll probably get kicked out of the house!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:696
translate chinese CNS_wake_1_46b193e6:

    # Caroline "God forbid, I have to explain to Sara or Mom about our incest! They'd never understand!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:698
translate chinese CNS_wake_1_5c81d2db:

    # Caroline "I’m serious, [player_name]. If I get caught wanking you off Linda is probably gonna kick me out of the house!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:699
translate chinese CNS_wake_1_60009e05:

    # Caroline "Oh God... If Sara saw us. Ugh, that would be so awkward if they knew I was trading sexual favours for help with my business."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:703
translate chinese CNS_wake_1_0b7ec172:

    # MC "(Ehh... I’m not so sure about that. They may be more understanding than Caroline thinks!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:704
translate chinese CNS_wake_1_53151e65:

    # MC "Yeah, don’t worry. I’ll keep quiet."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:705
translate chinese CNS_wake_1_d8243095:

    # Caroline "Good. How’s this? Am I gripping it too tightly?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:706
translate chinese CNS_wake_1_c5b6f611:

    # MC "Mmm... No, that’s absolutely perfect."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:710
translate chinese CNS_wake_1_5748a53b:

    # Caroline "(Wow... it’s even longer than my hand!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:711
translate chinese CNS_wake_1_f0cd619c:

    # Caroline "(If this was inside me, it would go, in twice as deep as my fingers!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:713
translate chinese CNS_wake_1_24563497:

    # MC "Ooohh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:717
translate chinese CNS_wake_1_facf1c62:

    # Caroline "Remember, [player_name] - you’ve got to keep really quiet."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:718
translate chinese CNS_wake_1_c258675e:

    # MC "Y-Yeah, I will."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:719
translate chinese CNS_wake_1_be3f7e37:

    # Caroline "Promise not to make a sound?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:720
translate chinese CNS_wake_1_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:724
translate chinese CNS_wake_1_1a8a16b4:

    # Caroline "Even if I go REALLY fast, like this?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:725
translate chinese CNS_wake_1_b68db724:

    # MC "Wait- Ugh! Mmmm!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:728
translate chinese CNS_wake_1_1be9aa54:

    # MC "(Dammit! This feels so good! I can’t risk waking the family though!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:730
translate chinese CNS_wake_1_6194049b:

    # MC "(Dammit! This feels so good! I can’t risk waking anybody up though!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:734
translate chinese CNS_wake_1_845afcb9:

    # Caroline "Hehe... it’s super cute watching you, struggle not to moan."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:735
translate chinese CNS_wake_1_e831ef65:

    # MC "Mmm... MMM!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:736
translate chinese CNS_wake_1_c938b08b:

    # Caroline "IT’s getting really warm now. Are you about to cum?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:740
translate chinese CNS_wake_1_17c62d0c:

    # Caroline "Cum for me."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:741
translate chinese CNS_wake_1_f104bce9:

    # Caroline "Cum for Caroline."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:742
translate chinese CNS_wake_1_0bdf86b7:

    # Caroline "(Shit! I can’t believe I just said that!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:746
translate chinese CNS_wake_1_80881d68:

    # MC "Hmmmm! HNNNNGGGGG!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:747
translate chinese CNS_wake_1_c8ae8c8b:

    # Caroline "Shush... Shush..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:748
translate chinese CNS_wake_1_f55cf4ce:

    # MC "Mmm! MMMMM!!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:757
translate chinese CNS_wake_1_8a2993cb:

    # MC "Fuck... Fuck..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:758
translate chinese CNS_wake_1_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:759
translate chinese CNS_wake_1_a77ebb10:

    # Caroline "Was that good?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:760
translate chinese CNS_wake_1_60e8c82a:

    # MC "Incredible..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:764
translate chinese CNS_wake_1_6d360f5f:

    # Caroline "I’m glad you enjoyed that."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:765
translate chinese CNS_wake_1_d073667f:

    # Caroline "However! It IS the middle of the night and we BOTH need our sleep."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:766
translate chinese CNS_wake_1_557b3afa:

    # Caroline "I’ll see you tomorrow. Goodnight, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:767
translate chinese CNS_wake_1_badd05da:

    # MC "Goodnight, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:780
translate chinese CNS_wake_2_b9113204:

    # MC "Could you maybe use your feet, for a change?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:781
translate chinese CNS_wake_2_39825504:

    # Caroline "Sure. Take your boxers off and sit on the floor, beside the bed."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:782
translate chinese CNS_wake_2_448d6136:

    # MC "On the floor?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:783
translate chinese CNS_wake_2_0a80a572:

    # Caroline "Yeah, that’s what I said."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:787
translate chinese CNS_wake_2_9819439c:

    # MC "Well... this is novel."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:788
translate chinese CNS_wake_2_adca9e9c:

    # Caroline "I’m not gonna lie to you - the only reason I did this, was so I’d be more comfortable."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:789
translate chinese CNS_wake_2_332b0bba:

    # Caroline "But it looks like you’ll enjoy it anyway - you’re already VERY hard."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:793
translate chinese CNS_wake_2_0c7b75a3:

    # Caroline "Now remember - even though I’m using my feet to get you off - you’re going to have to be quiet."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:795
translate chinese CNS_wake_2_e40b6af9:

    # Caroline "No waking Mom or Dad or Sara. Okay?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:797
translate chinese CNS_wake_2_cf3cf151:

    # Caroline "No waking anybody. Okay?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:799
translate chinese CNS_wake_2_3e8496be:

    # Caroline "If you do that, our deal is over."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:800
translate chinese CNS_wake_2_453fbadc:

    # Caroline "(And I’d probably have to move out of the damned house!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:805
translate chinese CNS_wake_2_09630d3c:

    # MC "Y-Yeah, I get it."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:806
translate chinese CNS_wake_2_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:807
translate chinese CNS_wake_2_122917ff:

    # MC "(The soles of her feet, feel so good against my cock!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:811
translate chinese CNS_wake_2_45ac4358:

    # Caroline "You must be really enjoying this. I can feel your cock, quivering between my feet."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:812
translate chinese CNS_wake_2_7096da86:

    # Caroline "You’ve definitely got a fetish for feet, don’t you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:813
translate chinese CNS_wake_2_df4057ba:

    # MC "N-No..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:817
translate chinese CNS_wake_2_3a193bb5:

    # Caroline "Oh, come on. You can’t lie. Your body is giving it away, right now!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:818
translate chinese CNS_wake_2_e6f58797:

    # Caroline "Even when I’m only using a single foot - you’re shivering with pleasure."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:819
translate chinese CNS_wake_2_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:823
translate chinese CNS_wake_2_6f631bd3:

    # MC "F-Fine. Maybe I do, have a bit of a foot fetish."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:824
translate chinese CNS_wake_2_d4ea7bac:

    # Caroline "Haha! I knew it!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:826
translate chinese CNS_wake_2_d0974cda:

    # MC "Ahh... Ohh! Yes!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:830
translate chinese CNS_wake_2_0695fc1b:

    # Caroline "Shush - you’re moaning too loudly. "
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:831
translate chinese CNS_wake_2_f0c9f8d3:

    # MC "S-Sorry... ahh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:832
translate chinese CNS_wake_2_0b306a48:

    # MC "You’re amazing with your feet. Have you done this before?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:836
translate chinese CNS_wake_2_20485e66:

    # Caroline "You mean, with past boyfriends?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:837
translate chinese CNS_wake_2_afc8cc1f:

    # MC "Yeah..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:838
translate chinese CNS_wake_2_819ab0ca:

    # Caroline "Once or twice. None of them had fetishes though. It was just something different for us to do together."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:842
translate chinese CNS_wake_2_22b5fefd:

    # MC "I’m gonna cum soon..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:843
translate chinese CNS_wake_2_2d1d8a65:

    # Caroline "Make sure you keep your voice down when you cum, okay?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:844
translate chinese CNS_wake_2_bbe36381:

    # MC "I’ll try. Hnngg...."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:848
translate chinese CNS_wake_2_95cbe282:

    # MC "Hnnnng! Ohhh... Ohhh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:849
translate chinese CNS_wake_2_3467aa2c:

    # MC "(Her feet are massaging my cock so well... I’m gonna blow my load all over them!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:850
translate chinese CNS_wake_2_21cd6249:

    # MC "(God, those toes are curling around my glans! It’s so sensitive!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:851
translate chinese CNS_wake_2_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:861
translate chinese CNS_wake_2_a96656a6:

    # MC "Hnnng! Ugh! Ahh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:862
translate chinese CNS_wake_2_e74198fa:

    # Caroline "There we go. You came so fast!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:863
translate chinese CNS_wake_2_24652342:

    # MC "Uh huh... Phew..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:867
translate chinese CNS_wake_2_af92c97d:

    # Caroline "Well, if I ever need to get you out of my room quickly - I know that I can make you cum, in seconds, if I use my feet!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:868
translate chinese CNS_wake_2_f5c928f5:

    # MC "H-Hey, I lasted longer than seconds!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:869
translate chinese CNS_wake_2_8a8a1118:

    # Caroline "Hehe... You better get back to bed. I’ll see you tomorrow, [player_name]."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:882
translate chinese C_NS_wake_blow_9c1d73d0:

    # Caroline "It looks like we’ve got quite a big problem on our hands. How would you like me to handle it tonight?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:884
translate chinese C_NS_wake_blow_c714b711:

    # MC "How about sucking my cock?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:888
translate chinese C_NS_wake_blow_2a00c25e:

    # Caroline "Of course, [player_name]. I’d do anything for you. You know that? Don't you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:890
translate chinese C_NS_wake_blow_7c0c372e:

    # MC "I do, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:894
translate chinese C_NS_wake_blow_2b38813a:

    # Caroline "Okay, let’s see if I can help you."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:897
translate chinese C_NS_wake_blow_c900483f:

    # Caroline "I always enjoy it when you sneak into my room, late at night. My heart races at the thought of mom or dad walking in on us."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:899
translate chinese C_NS_wake_blow_3cd4dcca:

    # Caroline "I always enjoy it when you sneak into my room, late at night. My heart races at the thought of Linda or Bob walking in on us."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:901
translate chinese C_NS_wake_blow_a9bbcde3:

    # MC "I know what you mean. It’s exciting."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:905
translate chinese C_NS_wake_blow_6c420c5e:

    # "*Kiss*"
    ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:907
translate chinese C_NS_wake_blow_309a795a:

    # MC "Ooh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:909
translate chinese C_NS_wake_blow_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:914
translate chinese C_NS_wake_blow_37620a77:

    # MC "Ohh... Fuck... That’s amazing, sis. Just like that. Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:916
translate chinese C_NS_wake_blow_0061ce5f:

    # MC "Ohh... Fuck... That’s amazing, Caroline. Just like that. Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:918
translate chinese C_NS_wake_blow_54d3900c:

    # Caroline "*Suck* *Suck*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:923
translate chinese C_NS_wake_blow_76b73678:

    # MC "Ooooohh! Yeah! Mmmm!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:927
translate chinese C_NS_wake_blow_49240dd4:

    # Caroline "*Suuuuck* *Shlurp* *Suck*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:929
translate chinese C_NS_wake_blow_51ce7d2d:

    # MC "*Pant* God... Your mouth is incredible, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:933
translate chinese C_NS_wake_blow_705050d4:

    # Caroline "*Suck* *Shlurp*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:935
translate chinese C_NS_wake_blow_aa7431ff:

    # MC "*Pant* Ohh... Fuck... Mmm! Hnnng!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:937
translate chinese C_NS_wake_blow_1b044bae:

    # Caroline "*Shlurp* *Suck*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:940
translate chinese C_NS_wake_blow_602065cb:

    # MC "*Pant* I’m getting close, sis!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:942
translate chinese C_NS_wake_blow_6fb0e95b:

    # MC "*Pant* I’m getting close!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:946
translate chinese C_NS_wake_blow_ec5750b8:

    # Caroline "*Suck* *Suck* *Suck*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:950
translate chinese C_NS_wake_blow_47eef443:

    # MC "Arrghhh! Hnnngg!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:960
translate chinese C_NS_wake_blow_6d3d0308:

    # Caroline "*Suck* *GULP* *Suck* *Suck* *GULP*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:962
translate chinese C_NS_wake_blow_7dc8d3ae:

    # MC "Ohhh!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:964
translate chinese C_NS_wake_blow_d90ec03f:

    # Caroline "*GULP*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:968
translate chinese C_NS_wake_blow_850f5267:

    # MC "*Pant* Mmmm... God, that was fucking amazing, sis."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:970
translate chinese C_NS_wake_blow_e468babb:

    # MC "*Pant* Mmmm... God, that was fucking amazing, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:972
translate chinese C_NS_wake_blow_6cdcfc3e:

    # Caroline "I’m just glad I could make you happy. It’s really late though - we both better get some sleep."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:975
translate chinese C_NS_wake_blow_ce4e612f:

    # MC "I’ll see you tomorrow, sis."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:978
translate chinese C_NS_wake_blow_f6a9b7d1:

    # MC "I’ll see you tomorrow."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:980
translate chinese C_NS_wake_blow_9523bc28:

    # Caroline "Goodnight, [player_name]. Sleep tight."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:994
translate chinese C_NS_wake_anal_724aabe8:

    # MC "Can we try something a bit different tonight, sis?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:996
translate chinese C_NS_wake_anal_4ce5c308:

    # Caroline "What’s on your mind?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:998
translate chinese C_NS_wake_anal_f89e5748:

    # MC "I was kinda wanting to give anal a go."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1002
translate chinese C_NS_wake_anal_a1a9ecf1:

    # Caroline "Sure, why not? How’s this? Do you need me to arch my back any more?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1004
translate chinese C_NS_wake_anal_d026a74d:

    # MC "Honestly, you’re just showing off at this point."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1006
translate chinese C_NS_wake_anal_9f37b23f:

    # Caroline "Hehe, ya got me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1010
translate chinese C_NS_wake_anal_ce3075a2:

    # MC "(Her butt looks amazing! Her panties are barely covering her asshole!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1012
translate chinese C_NS_wake_anal_0bc53fce:

    # MC "(Mmm! I can’t wait to spread her ass open and-)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1016
translate chinese C_NS_wake_anal_4bcd6f54:

    # Caroline "Are you just gonna spend the rest of the night staring at my backside?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1018
translate chinese C_NS_wake_anal_d364efb4:

    # MC "Just taking in the view."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1020
translate chinese C_NS_wake_anal_c622c468:

    # Caroline "Don’t take too long. I still need to get some sleep!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1024
translate chinese C_NS_wake_anal_03a66d93:

    # MC "Sorry, my bad."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1026
translate chinese C_NS_wake_anal_77911a1a:

    # MC "(Alright, let’s slide her panties off...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1030
translate chinese C_NS_wake_anal_fc648412:

    # MC "*Whistle* Nice..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1032
translate chinese C_NS_wake_anal_ced693ff:

    # MC "(Her hole looks soooo tight!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1036
translate chinese C_NS_wake_anal_600a6262:

    # Caroline "You’re staring again."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1038
translate chinese C_NS_wake_anal_134855d3:

    # MC "Aww, c’mon. Can you blame me? Your ass is incredible!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1042
translate chinese C_NS_wake_anal_f8364147:

    # Caroline "Just hurry up and fuck me, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1044
translate chinese C_NS_wake_anal_4717411c:

    # MC "Alright, alright!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1048
translate chinese C_NS_wake_anal_8ab18f9a:

    # MC "Mmm... Fuuuck..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1050
translate chinese C_NS_wake_anal_3e24a6a7:

    # Caroline "Ow... *Gasp*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1052
translate chinese C_NS_wake_anal_16c70088:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1056
translate chinese C_NS_wake_anal_f2c0a3b7:

    # Caroline "N-No, I just- *Gasp* forgot how girthy your cock was! *Pant* Keep going!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1058
translate chinese C_NS_wake_anal_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1060
translate chinese C_NS_wake_anal_90f89fbf:

    # Caroline "*GASP* Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1067
translate chinese C_NS_wake_anal_d159b531:

    # Caroline "AHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1069
translate chinese C_NS_wake_anal_f95b85f7:

    # MC "Hnngg! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1071
translate chinese C_NS_wake_anal_a2403d5e:

    # Caroline "*Pant* Oh my God! Ohh! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1078
translate chinese C_NS_wake_anal_b373c2e3:

    # Caroline "*Pant* I’m cumming! I’m cumming!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1080
translate chinese C_NS_wake_anal_44588c4f:

    # MC "(Her sphincter is clenching around my dick! Shit! I’m gonna cum too!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1082
translate chinese C_NS_wake_anal_458ef478:

    # MC "Hnnng! Arrghhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1084
translate chinese C_NS_wake_anal_c29f67f8:

    # Caroline "Ayaaahhhhhh!! OOHHHH!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1094
translate chinese C_NS_wake_anal_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1096
translate chinese C_NS_wake_anal_bcabc806:

    # Caroline "*Pant* *Pant* *Pant* Holy shit... that was intense... *Gasp* Oh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1098
translate chinese C_NS_wake_anal_48998932:

    # MC "Thanks, Caroline.That was amazing!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1100
translate chinese C_NS_wake_anal_4d8a36ea:

    # Caroline "No problem. *Pant* I really need to get some sleep now, though."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1102
translate chinese C_NS_wake_anal_43c458e0:

    # MC "Goodnight, sis."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1104
translate chinese C_NS_wake_anal_8522aa2f:

    # Caroline "Sweet dreams, little bro."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1108
translate chinese C_NS_wake_anal_47083ee0:

    # MC "Can we try something a bit different tonight, Caroline?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1110
translate chinese C_NS_wake_anal_4ce5c308_1:

    # Caroline "What’s on your mind?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1112
translate chinese C_NS_wake_anal_f89e5748_1:

    # MC "I was kinda wanting to give anal a go."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1116
translate chinese C_NS_wake_anal_a1a9ecf1_1:

    # Caroline "Sure, why not? How’s this? Do you need me to arch my back any more?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1118
translate chinese C_NS_wake_anal_d026a74d_1:

    # MC "Honestly, you’re just showing off at this point."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1120
translate chinese C_NS_wake_anal_9f37b23f_1:

    # Caroline "Hehe, ya got me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1124
translate chinese C_NS_wake_anal_ce3075a2_1:

    # MC "(Her butt looks amazing! Her panties are barely covering her asshole!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1126
translate chinese C_NS_wake_anal_0bc53fce_1:

    # MC "(Mmm! I can’t wait to spread her ass open and-)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1130
translate chinese C_NS_wake_anal_4bcd6f54_1:

    # Caroline "Are you just gonna spend the rest of the night staring at my backside?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1132
translate chinese C_NS_wake_anal_d364efb4_1:

    # MC "Just taking in the view."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1134
translate chinese C_NS_wake_anal_c622c468_1:

    # Caroline "Don’t take too long. I still need to get some sleep!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1138
translate chinese C_NS_wake_anal_03a66d93_1:

    # MC "Sorry, my bad."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1140
translate chinese C_NS_wake_anal_77911a1a_1:

    # MC "(Alright, let’s slide her panties off...)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1144
translate chinese C_NS_wake_anal_fc648412_1:

    # MC "*Whistle* Nice..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1146
translate chinese C_NS_wake_anal_ced693ff_1:

    # MC "(Her hole looks soooo tight!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1150
translate chinese C_NS_wake_anal_600a6262_1:

    # Caroline "You’re staring again."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1152
translate chinese C_NS_wake_anal_134855d3_1:

    # MC "Aww, c’mon. Can you blame me? Your ass is incredible!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1156
translate chinese C_NS_wake_anal_f8364147_1:

    # Caroline "Just hurry up and fuck me, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1158
translate chinese C_NS_wake_anal_4717411c_1:

    # MC "Alright, alright!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1162
translate chinese C_NS_wake_anal_8ab18f9a_1:

    # MC "Mmm... Fuuuck..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1164
translate chinese C_NS_wake_anal_3e24a6a7_1:

    # Caroline "Ow... *Gasp*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1166
translate chinese C_NS_wake_anal_16c70088_1:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1170
translate chinese C_NS_wake_anal_f2c0a3b7_1:

    # Caroline "N-No, I just- *Gasp* forgot how girthy your cock was! *Pant* Keep going!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1172
translate chinese C_NS_wake_anal_d174ea9d_1:

    # MC "Hnnng..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1174
translate chinese C_NS_wake_anal_90f89fbf_1:

    # Caroline "*GASP* Ohhh!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1180
translate chinese C_NS_wake_anal_d159b531_1:

    # Caroline "AHH!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1182
translate chinese C_NS_wake_anal_f95b85f7_1:

    # MC "Hnngg! Ugh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1184
translate chinese C_NS_wake_anal_a2403d5e_1:

    # Caroline "*Pant* Oh my God! Ohh! Mmm!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1191
translate chinese C_NS_wake_anal_b373c2e3_1:

    # Caroline "*Pant* I’m cumming! I’m cumming!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1193
translate chinese C_NS_wake_anal_44588c4f_1:

    # MC "(Her sphincter is clenching around my dick! Shit! I’m gonna cum too!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1195
translate chinese C_NS_wake_anal_458ef478_1:

    # MC "Hnnng! Arrghhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1197
translate chinese C_NS_wake_anal_c29f67f8_1:

    # Caroline "Ayaaahhhhhh!! OOHHHH!!!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1207
translate chinese C_NS_wake_anal_fb32e779_1:

    # MC "Ohh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1209
translate chinese C_NS_wake_anal_bcabc806_1:

    # Caroline "*Pant* *Pant* *Pant* Holy shit... that was intense... *Gasp* Oh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1211
translate chinese C_NS_wake_anal_48998932_1:

    # MC "Thanks, Caroline.That was amazing!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1213
translate chinese C_NS_wake_anal_4d8a36ea_1:

    # Caroline "No problem. *Pant* I really need to get some sleep now, though."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1215
translate chinese C_NS_wake_anal_badd05da:

    # MC "Goodnight, Caroline."
    MC ""

# game/scripts/home/caroline_room/night/scenes/caroline_room_night_scene1.rpy:1217
translate chinese C_NS_wake_anal_c6bbcfd9:

    # Caroline "Sweet dreams, [player_name]."
    Caroline ""

