﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:27
translate chinese ml_kitchen_morning_scene4_V1_label_2effc887:

    # MC "I've already talked with them."
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:40
translate chinese ml_kitchen_morning_scene4_V1_label_6e9662c9:

    # MC "(Huh, looks like Auntie is visiting today!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:41
translate chinese ml_kitchen_morning_scene4_V1_label_eb726d19:

    # MC "(She’s a fairly close, member of the family. We used to see her dropping by every other week. It’s become much less frequent though recently.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:43
translate chinese ml_kitchen_morning_scene4_V1_label_11f1365c:

    # MC "(Huh, looks like Linda’s sister is visiting today.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:44
translate chinese ml_kitchen_morning_scene4_V1_label_cca27305:

    # MC "(She’s very close to Linda... or at least, she used to be. We used to see her dropping by every other week. It’s become much less frequent though recently.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:47
translate chinese ml_kitchen_morning_scene4_V1_label_65258479:

    # MC "(It’s strange... I don’t know why they aren’t hanging out as frequently as they did when I first moved in.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:49
translate chinese ml_kitchen_morning_scene4_V1_label_5df725b1:

    # MC "(They’ve got remarkable different personalities too. Mom is a hard worker career-driven woman. Auntie is a walking, talking Barbie doll.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:52
translate chinese ml_kitchen_morning_scene4_V1_label_334b39f7:

    # MC "(They’ve got remarkable different personalities too. Linda’s a hard working career-driven woman. Liza is a walking, talking Barbie doll.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:53
translate chinese ml_kitchen_morning_scene4_V1_label_4dd4c9d9:

    # MC "(She spends most of her free time at day spas, shopping, and hanging out with her similarly air-headed friends.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:56
translate chinese ml_kitchen_morning_scene4_V1_label_66abb0ba:

    # Mom "Ah! There you are!"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:57
translate chinese ml_kitchen_morning_scene4_V1_label_599cd7d4:

    # Mom "I thought I was going to have to come to your bedroom and get you up."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:60
translate chinese ml_kitchen_morning_scene4_V1_label_5bfaa9a7:

    # MC "Hi, Mom! Hi, Auntie!"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:62
translate chinese ml_kitchen_morning_scene4_V1_label_470e7b1e:

    # MC "Hi."
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:64
translate chinese ml_kitchen_morning_scene4_V1_label_2a3887fe:

    # Auntie "Hi, [player_name]."
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:65
translate chinese ml_kitchen_morning_scene4_V1_label_aa0ab497:

    # Mom "C’mere and let me kiss you."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:68
translate chinese ml_kitchen_morning_scene4_V1_label_e8321a81:

    # Mom "Mwah!"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:69
translate chinese ml_kitchen_morning_scene4_V1_label_926ae9f5:

    # Auntie "Anyway, I was saying to Margaret - if you want to go out in THAT dress, then we’re NOT sitting at the same table during lunch."
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:70
translate chinese ml_kitchen_morning_scene4_V1_label_d82de8b7:

    # Auntie "I mean, SERIOUSLY - who wears a beige dress?!"
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:73
translate chinese ml_kitchen_morning_scene4_V1_label_d301bce3:

    # Mom "Oh yeah... That’s... really something else..."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:75
translate chinese ml_kitchen_morning_scene4_V1_label_3b2ab81d:

    # Mom "(God, does she not have ANY other interests than clothes and fashion?!)"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:76
translate chinese ml_kitchen_morning_scene4_V1_label_2e259c4b:

    # Mom "(I have to change the topic before she drives me crazy.)"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:77
translate chinese ml_kitchen_morning_scene4_V1_label_feae0d38:

    # Mom "So, [player_name] is looking for a part-time job. Did you know that?"
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:78
translate chinese ml_kitchen_morning_scene4_V1_label_6182bc79:

    # Auntie "Really?"
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:81
translate chinese ml_kitchen_morning_scene4_V1_label_4a9e6c8f:

    # Auntie "I have a swimming pool that needs cleaning out regularly."
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:82
translate chinese ml_kitchen_morning_scene4_V1_label_e51cb377:

    # Auntie "If you’re interested, I’m happy to pay you for it."
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:83
translate chinese ml_kitchen_morning_scene4_V1_label_a1de01a1:

    # Auntie "What do you say?"
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:85
translate chinese ml_kitchen_morning_scene4_V1_label_adefd310:

    # MC "Sure! Thanks, Auntie!"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:87
translate chinese ml_kitchen_morning_scene4_V1_label_a74c7964:

    # MC "Sure! Thanks."
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:90
translate chinese ml_kitchen_morning_scene4_V1_label_d8a2d2e2:

    # Auntie "Great! We’ll organise a date for you to come around soon."
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:92
translate chinese ml_kitchen_morning_scene4_V1_label_646454a9:

    # Mom "Thanks, Sis. I really appreciate that."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:94
translate chinese ml_kitchen_morning_scene4_V1_label_ba84796f:

    # Mom "Thanks. I really appreciate that."
    Mom ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:96
translate chinese ml_kitchen_morning_scene4_V1_label_fe25b698:

    # Auntie "Aww, come on! It’s nothing. I’ve got money to burn - and I may as well spend it on my favourite nephew!"
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:98
translate chinese ml_kitchen_morning_scene4_V1_label_4c05269d:

    # Auntie "Aww, come on! It’s nothing. I’ve got money to burn - and I may as well spend it on you!"
    Auntie ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:100
translate chinese ml_kitchen_morning_scene4_V1_label_f777874c:

    # MC "Thanks, Auntie!"
    MC ""

# game/scripts/home/kitchen/morning/scenes/ml_kitchen_morning_scene4_v1.rpy:102
translate chinese ml_kitchen_morning_scene4_V1_label_15d5ec2d:

    # MC "Thanks!"
    MC ""

