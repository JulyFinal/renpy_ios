﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep.rpy:18
translate chinese ML_NS_sleep_label_d465b029:

    # Mom "Zzz..."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep.rpy:19
translate chinese ML_NS_sleep_label_e871c597:

    # Dad "*Snore*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep.rpy:20
translate chinese ML_NS_sleep_label_b364292b:

    # MC "(They’re both fast asleep. Let’s see if I can wake up [Linda_name] - and bring her back to my bedroom for some fun!)"
    MC ""

