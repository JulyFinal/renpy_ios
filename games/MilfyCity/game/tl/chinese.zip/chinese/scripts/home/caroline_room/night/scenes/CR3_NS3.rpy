﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:29
translate chinese CR3_NS3_label_73e0d529:

    # MC "(I should let her sleep.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:45
translate chinese CR3_NS3_label_89c7e355:

    # MC "(Okay, with the deal back on, Caroline should be feeling extra horny. With any luck, she’ll be desperate to masturbate.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:46
translate chinese CR3_NS3_label_fce875cc:

    # MC "(Let’s see how long she endures, without her vibrator to keep her calm!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:50
translate chinese CR3_NS3_label_364ad65e:

    # Caroline "Ohh... Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:52
translate chinese CR3_NS3_label_9f9ab0d1:

    # Caroline "(Dammit! Why did I have to wake up?! I was having such a great dream!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:53
translate chinese CR3_NS3_label_c9fdfa22:

    # Caroline "(I have to try and focus... I can remember the details...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:57
translate chinese CR3_NS3_label_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:58
translate chinese CR3_NS3_label_39a5f5f9:

    # Caroline "(It was [player_name] and me again... We were on a cruise ship together, for a holiday - but they screwed up our bedrooms, so we had to move to a - double bed suite.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:59
translate chinese CR3_NS3_label_f9c300e6:

    # Caroline "(God... That dream seemed to go on forever. I remember how we were getting closer, each night we slept beside each other.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:63
translate chinese CR3_NS3_label_a31fddf0:

    # Caroline "(Fuck... Where the hell did my dildo go?!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:64
translate chinese CR3_NS3_label_c8bfc838:

    # Caroline "(I could SERIOUSLY use it, right now! Dammit!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:65
translate chinese CR3_NS3_label_e567bda2:

    # Caroline "(Ugh - where was I, before I woke up?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:69
translate chinese CR3_NS3_label_82a46bbd:

    # Caroline "(Oh yeah! My brother had gone to take a shower, in the cabin’s ensuite. I decided to be nosy, and peek on him, while he was washing himself.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:71
translate chinese CR3_NS3_label_a568fecb:

    # Caroline "(Oh yeah! [player_name] had gone to take a shower, in the cabin’s ensuite. I decided to be nosy, and peek on him, while he was washing himself.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:73
translate chinese CR3_NS3_label_ba23ad33:

    # Caroline "(God... he was so fucking hot. I loved the sight of him rubbing bubbly water, all over his body.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:74
translate chinese CR3_NS3_label_44089637:

    # Caroline "(I guess I could continue - with the wet dream - now that I’m awake?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:78
translate chinese CR3_NS3_label_e80fbf9a:

    # Caroline "(It’s only a fantasy, right? Nobody can get hurt!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:80
translate chinese CR3_NS3_label_f92155dd:

    # Caroline "(Mmm... I slip out of my clothes and strip naked. He’s slowly washing his cock, now, rubbing his hand - back and forth. It’s causing it to grow in size, with each passing second.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:81
translate chinese CR3_NS3_label_05d1b90c_1:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:85
translate chinese CR3_NS3_label_45f1580b:

    # Caroline "Ohh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:86
translate chinese CR3_NS3_label_66dd75e9:

    # Caroline "(I step into the ensuite, and open the shower door. He looks at me, shocked and stunned, but I - press on inside - to join him.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:87
translate chinese CR3_NS3_label_ec2769d9:

    # Caroline "(I think you need a hand, washing yourself, I whisper, as I reach out and wrap my fingers around - his thick cock.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:91
translate chinese CR3_NS3_label_1d2f0a66:

    # MC "(I stole her dildo, but there’s not much I can do about her fingers. I guess I’ll just have to wait, and hope that they leave her unsatisfied!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:92
translate chinese CR3_NS3_label_4b4a3999:

    # MC "(She looks REALLY horny right now, though!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:96
translate chinese CR3_NS3_label_aeed5ab8:

    # Caroline "(I begin, rubbing my hand - back and forth - over his cock, wanking him off - as I massage him closer and closer to an orgasm.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:97
translate chinese CR3_NS3_label_05d1b90c_2:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:101
translate chinese CR3_NS3_label_9ed88261:

    # Caroline "(As the hot water of the shower trickles over my body, I feel him reach up and pinch my nipples.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:102
translate chinese CR3_NS3_label_7916bd8d:

    # Caroline "(I moan in pleasure, my pussy quickly getting wet at the thought of him, ravaging and taking me, right there, in the shower.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:103
translate chinese CR3_NS3_label_03f2db6b:

    # Caroline "Ah... Ah..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:107
translate chinese CR3_NS3_label_cc09d250:

    # Caroline "(In a haze of lust, I drop to my knees, my hair, soaked from the shower. My brother leans back, against the wall - as I raise my head to his waist.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:109
translate chinese CR3_NS3_label_9ec2c7f3:

    # Caroline "(In a haze of lust, I drop to my knees, my hair soaked by the shower. He leans back against the wall as I raise my head to his waist.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:111
translate chinese CR3_NS3_label_f4108d76:

    # Caroline "(There is a brief silence, as he opens his mouth in surprise. I stun him, by taking his glans between my lips, and gently start sucking on it.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:112
translate chinese CR3_NS3_label_d34881d4:

    # Caroline "(His moans are louder than the water, splashing around us.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:116
translate chinese CR3_NS3_label_45f1580b_1:

    # Caroline "Ohh..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:118
translate chinese CR3_NS3_label_bb7c130e:

    # Caroline "(And then we hear a sharp knock at the door - it’s Mom and Dad! They want to know when we’ll be joining them for dinner, in the cruise ship’s restaurant. I look up at [player_name], and motion for him to answer, while I suck his cock.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:120
translate chinese CR3_NS3_label_1535ba28:

    # Caroline "(And then we hear a sharp knock at the door - it’s Bob and Linda! They want to know when we’ll be joining them for dinner, in the cruise ship’s restaurant. I look up at [player_name] and motion for him to answer while I suck his cock.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:121
translate chinese CR3_NS3_label_521df651:

    # Caroline "(He stammers and struggles, to give a straight answer. We’ll be there soon, I’m just s-showering, he gasps, as I begin to deepthroat his shaft.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:126
translate chinese CR3_NS3_label_fde67fe0:

    # Caroline "(Eventually, Mom and Dad leave, but I never stop sucking on his delicious cock for even a second.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:128
translate chinese CR3_NS3_label_c5bc4002:

    # Caroline "(They eventually leave, but I never stop sucking on his delicious cock - for even a second.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:130
translate chinese CR3_NS3_label_2282be0c:

    # Caroline "(I bob my head, faster and faster. The shower’s stream, running down my face - like tears.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:131
translate chinese CR3_NS3_label_c674afb2:

    # Caroline "Ahhhh... Hnng..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:135
translate chinese CR3_NS3_label_f38aa7e7:

    # Caroline "(I feel my brother, reach around the back of my head, and weave his fingers through my hair. He pulls me closer.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:137
translate chinese CR3_NS3_label_d9e3787b:

    # Caroline "(I feel my best friend reach around the back of my head and weave his fingers through my hair. He pulls me closer.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:138
translate chinese CR3_NS3_label_614c1d3d:

    # Caroline "(He thrusts his hips, and pulls my head down, fucking my face, like he would my pussy.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:139
translate chinese CR3_NS3_label_acacd7d2:

    # Caroline "(I’m soaking wet, but it’s impossible to tell, in the shower.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:143
translate chinese CR3_NS3_label_b6f4d8fd:

    # Caroline "Ah! Ah!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:144
translate chinese CR3_NS3_label_b45acefe:

    # Caroline "(I feel him tense up, as he begins to cum in my mouth. The salty taste of his semen, coats my tongue - and as my cheeks puff out, I do my best to swallow it all.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:146
translate chinese CR3_NS3_label_05d1b90c_3:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:150
translate chinese CR3_NS3_label_16876ef0:

    # Caroline "Fuck..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:151
translate chinese CR3_NS3_label_6c508ad8:

    # Caroline "(Can’t cum! I’m so used to my vibrator, now, that I just can’t - bring myself to cum - with my fingers!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:155
translate chinese CR3_NS3_label_be12d454:

    # Caroline "God... This is so frustrating..."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:156
translate chinese CR3_NS3_label_4cd1e77f:

    # MC "(Hehe... it looks like my plan is working! She’ll be coming to me, and begging me - to fuck her brains out - in no time! I’m a genius!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:160
translate chinese CR3_NS3_label_2cc70eb5:

    # Caroline "*Sigh*"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:162
translate chinese CR3_NS3_label_91f3c2e2:

    # Caroline "(Where could my dildo have gone? Mom wouldn’t have found it, when she was cleaning, would she?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:164
translate chinese CR3_NS3_label_a062c750:

    # Caroline "(Where could my dildo have gone? Linda wouldn’t have found it when she was inspecting the room? Would she?)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:166
translate chinese CR3_NS3_label_a1980e1c:

    # Caroline "(Or maybe it was Sara, being nosy. Dammit! If she stole my dildo - I swear to God, I will be fucking furious!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:170
translate chinese CR3_NS3_label_cf9e5184:

    # Caroline "(I mean, where could it have gone? It was under my bed... There’s nowhere else for it to go.)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:171
translate chinese CR3_NS3_label_7395b02b:

    # Caroline "(And who could possibly benefit from me not having...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:172
translate chinese CR3_NS3_label_551f58fb:

    # Caroline "(Wait a minute... Hmm... What if...)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/CR3_NS3.rpy:173
translate chinese CR3_NS3_label_7af033e3:

    # Caroline "Zzz..."
    Caroline ""

