﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:11
translate chinese caroline_room_morning_scene4_label_08728b1a:

    # MC "I've already talked to her."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:21
translate chinese caroline_room_morning_scene4_label_7cd614a4:

    # MC "(Caroline’s on her phone, but it looks like she’s just texting.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:23
translate chinese caroline_room_morning_scene4_label_7cd614a4_1:

    # MC "(Caroline’s on her phone, but it looks like she’s just texting.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:24
translate chinese caroline_room_morning_scene4_label_0bc75553:

    # MC "(Hopefully she’s in a better mood now that I’ve helped out in her shop!)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:25
translate chinese caroline_room_morning_scene4_label_3b6891ac:

    # MC "Hey, Caroline!"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:29
translate chinese caroline_room_morning_scene4_label_be3f3ddd:

    # Caroline "Oh! Hiiii, [player_name]!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:30
translate chinese caroline_room_morning_scene4_label_3a87d71a:

    # Caroline "Thanks again for your help down at the store. I really believe we’re gonna see things turn around soon! I can feel it in my gut!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:31
translate chinese caroline_room_morning_scene4_label_d3d00b86:

    # Caroline "It’s too early to tell if I’ll turn a profit, but I’ve definitely seen more customers browsing. Maybe they’ll talk to their friends and I’ll continue to see foot traffic grow."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:32
translate chinese caroline_room_morning_scene4_label_2d2f3b05:

    # Caroline "Oh! I almost forgot. The online store has started taking off too."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:35
translate chinese caroline_room_morning_scene4_label_5784d326:

    # Caroline "Thank you so much for everything you’ve done!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:37
translate chinese caroline_room_morning_scene4_label_ff705b98:

    # Caroline "You’re the best little brother in the whole world!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:39
translate chinese caroline_room_morning_scene4_label_3848e92d:

    # Caroline "You’re the best friend I could ever ask for!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:40
translate chinese caroline_room_morning_scene4_label_056d0a05:

    # MC "Aww, thanks Caroline! I’m just glad I could be of assistance."
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:43
translate chinese caroline_room_morning_scene4_label_db6bab33:

    # Caroline "If you fancy visiting me again at work, I’m sure I could use your help more often."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:44
translate chinese caroline_room_morning_scene4_label_6eb6dc96:

    # Caroline "Just drop by whenever you’re free."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene4.rpy:45
translate chinese caroline_room_morning_scene4_label_5ab05444:

    # MC "No problem! I’m sure you’ll see me again, soon enough."
    MC ""

