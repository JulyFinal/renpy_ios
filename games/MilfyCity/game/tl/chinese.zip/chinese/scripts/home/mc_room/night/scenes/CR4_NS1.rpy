﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:310
translate chinese CR4_NS1_label_498f28db:

    # MC "(Ahh, there she is! I don’t know why I was worried - Caroline told me to meet her where we had our first kiss.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:311
translate chinese CR4_NS1_label_7affdba5:

    # MC "(She’s on the exact same stone bench. I can still remember that night as clearly as I’m looking at her right now.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:312
translate chinese CR4_NS1_label_6ba09790:

    # MC "Evening, Caroline!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:313
translate chinese CR4_NS1_label_ad2cb933:

    # Caroline "Hey! You remembered the spot!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:314
translate chinese CR4_NS1_label_36f4c818:

    # MC "Haha, of course I did! And now that I’m here, I’ve got something very important to tell you."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:318
translate chinese CR4_NS1_label_1ac7ef12:

    # Caroline "Oh? Is everything alright?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:319
translate chinese CR4_NS1_label_82544783:

    # Caroline "(Oh no... He’s going to break up with me, isn’t he?)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:320
translate chinese CR4_NS1_label_f23fb640:

    # MC "Don’t look so worried! Everything’s fine."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:321
translate chinese CR4_NS1_label_ca1437e3:

    # Caroline "Okay, but... what’s the super important thing you wanted to tell me?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:322
translate chinese CR4_NS1_label_a2933087:

    # MC "There is a gorgeous reflection of the moon shining over the lake right in front of me - but I’d rather keep my eyes on you. You’re far more beautiful than the clearest night sky."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:326
translate chinese CR4_NS1_label_a9820957:

    # Caroline "Thank you, [player_name]. That’s the most beautiful thing anyone has ever said to me."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:327
translate chinese CR4_NS1_label_f691e4c9:

    # MC "May I kiss you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:328
translate chinese CR4_NS1_label_1b144d19:

    # Caroline "I’d love that."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:332
translate chinese CR4_NS1_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:333
translate chinese CR4_NS1_label_f788a7c2:

    # MC "(I don’t know how I came up with that line so quickly. Being near Caroline awakens an intense creativity within me I’ve never felt before.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:334
translate chinese CR4_NS1_label_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:338
translate chinese CR4_NS1_label_a40b039a:

    # Caroline "(My heart’s still fluttering from what he said. He must have spent all day trying to come up with that one.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:339
translate chinese CR4_NS1_label_4bf4bcde:

    # Caroline "(Or maybe he just searched for pick-up lines on the internet.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:343
translate chinese CR4_NS1_label_d51e6539:

    # Caroline "So... Tell me the truth."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:344
translate chinese CR4_NS1_label_a7de562d:

    # MC "The truth? About what?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:345
translate chinese CR4_NS1_label_657e672b:

    # Caroline "Oh, c’mon. You know! That line about the moon! Where’d you learn it?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:349
translate chinese CR4_NS1_label_d2587398:

    # MC "I didn’t learn it anywhere, Caroline. It just came to me while I was looking at you."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:350
translate chinese CR4_NS1_label_9767219a:

    # Caroline "Suuure."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:351
translate chinese CR4_NS1_label_ec43ba42:

    # MC "I’m serious!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:355
translate chinese CR4_NS1_label_5028e296:

    # Caroline "When have YOU ever been a Shakespeare?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:356
translate chinese CR4_NS1_label_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:358
translate chinese CR4_NS1_label_44424f01:

    # Caroline "I mean, I’ve known you for your whole life and I’ve never heard you speak like that about anything or to anyone!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:360
translate chinese CR4_NS1_label_c3969a77:

    # Caroline "I mean, I've known you for a while now and I've never heard you seak like that to anything or anyone!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:364
translate chinese CR4_NS1_label_03174e02:

    # MC "I told you, it just came to me. I was inspired by seeing you sit under the moonlight."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:365
translate chinese CR4_NS1_label_7989d147:

    # MC "Is everything okay, Caroline? You seem a little on edge tonight."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:366
translate chinese CR4_NS1_label_7cf6f761:

    # Caroline "No, I mean, yeah..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:370
translate chinese CR4_NS1_label_88121271:

    # MC "(Huh, something seems to be worrying her. I wonder if she wants to talk about it.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:371
translate chinese CR4_NS1_label_23072611:

    # MC "Can you tell me what's going on? If there’s a problem, I can help fix it. You know I will. Think back to when you needed money for your shop - I ALWAYS had your back."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:372
translate chinese CR4_NS1_label_c1b7500e:

    # MC "And I always will."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:376
translate chinese CR4_NS1_label_7e42f5cb:

    # Caroline "Alright, listen... I..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:377
translate chinese CR4_NS1_label_d5aefe35:

    # MC "It’s okay. Just take your time and think of what you want to say. Don’t rush it out."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:381
translate chinese CR4_NS1_label_92696398:

    # Caroline "When I... Umm..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:382
translate chinese CR4_NS1_label_96467ca0:

    # Caroline "(Fuck. This is tough...)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:383
translate chinese CR4_NS1_label_67913229:

    # Caroline "When I was with... Charles... I..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:384
translate chinese CR4_NS1_label_5461960b:

    # Caroline "He always kept..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:388
translate chinese CR4_NS1_label_1e06ace6:

    # Caroline "Y-You better not hurt me like he did, okay?!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:389
translate chinese CR4_NS1_label_4d2ba7a5:

    # Caroline "I’m not going to go through hell again for some stupid guy!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:390
translate chinese CR4_NS1_label_88b8dea0:

    # MC "(Ahh, I see where this is going.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:394
translate chinese CR4_NS1_label_438dea58:

    # Caroline "So, if you feel like... cheating on me or... shouting at me in the middle of a crowded shopping mall."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:395
translate chinese CR4_NS1_label_1931e776:

    # Caroline "Or if you think you’d ever hit me after drinking a bit too much after a night out with your buddies... please just... go now - and we’ll finish it before this gets any more serious."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:396
translate chinese CR4_NS1_label_a3bb982c:

    # Caroline "I don’t think I’d survive going through that again."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:400
translate chinese CR4_NS1_label_19af2154:

    # MC "Caroline..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:401
translate chinese CR4_NS1_label_d71affb8:

    # MC "I’m not your ex. I’m not going to hurt you like your ex did."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:402
translate chinese CR4_NS1_label_a6e164a0:

    # MC "I’m not going to leave during the trailers. I’m by your side until the credits roll."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:409
translate chinese CR4_NS1_label_0b195746:

    # Caroline "Okay, now I KNOW for CERTAIN that you searched these lines before our date tonight!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:410
translate chinese CR4_NS1_label_b833c882:

    # MC "Haha! I didn’t, I swear!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:411
translate chinese CR4_NS1_label_d2ade0cb:

    # Caroline "Hmm, alright, I’ll give you the benefit of the doubt this time! Haha!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:412
translate chinese CR4_NS1_label_10cb5130:

    # Caroline "Now, how about I give you something else too?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:413
translate chinese CR4_NS1_label_1b83645d:

    # MC "What were you thinking of?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:414
translate chinese CR4_NS1_label_b892d18a:

    # Caroline "Would you like me to wrap my lips around your fat cock, and suck you dry?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:415
translate chinese CR4_NS1_label_2f72bc4d:

    # MC "Mmm, fuck yeah!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:419
translate chinese CR4_NS1_label_88296784:

    # Caroline "Oh my, you’re already hard! I thought my breakdown there might have turned you off!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:420
translate chinese CR4_NS1_label_86bc2254:

    # MC "Relax. Nothing you do is going to turn me off, Caroline."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:421
translate chinese CR4_NS1_label_63a20bd6:

    # Caroline "You have a really beautiful cock, you know that?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:425
translate chinese CR4_NS1_label_64992a73:

    # MC "Seems kinda weird to call a cock “beautiful”."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:426
translate chinese CR4_NS1_label_7bfecc74:

    # Caroline "Hehe, I suppose so. Yours looks really nice though. Very suckable."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:427
translate chinese CR4_NS1_label_cb0b1342:

    # Caroline "Now, are you ready for me to blow your mind?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:431
translate chinese CR4_NS1_label_69a69a87:

    # MC "I’m looking forward to it!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:432
translate chinese CR4_NS1_label_02de43a5:

    # Caroline "Can you spread your legs a little more for me? I just need a bit more room to work."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:433
translate chinese CR4_NS1_label_4255fe22:

    # MC "How’s that now?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:434
translate chinese CR4_NS1_label_b2b43a26:

    # Caroline "Absolutely perfect."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:438
translate chinese CR4_NS1_label_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:439
translate chinese CR4_NS1_label_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:440
translate chinese CR4_NS1_label_f697ae3f:

    # Caroline "(I can feel his thighs clench each time I drag my tongue over his frenulum. He’s really enjoying this!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:444
translate chinese CR4_NS1_label_26bfecfa:

    # MC "Ah... fuck."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:445
translate chinese CR4_NS1_label_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:447
translate chinese CR4_NS1_label_d3a12f84:

    # MC "God... Just like that. Mmm! Can you start at the base and work your way up?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:448
translate chinese CR4_NS1_label_8d19b83a:

    # Caroline "Uh huh."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:452
translate chinese CR4_NS1_label_cba6a38a:

    # MC "Ahh... Shit..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:453
translate chinese CR4_NS1_label_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:455
translate chinese CR4_NS1_label_1f9e6117:

    # Caroline "*Sluuurrrrp*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:459
translate chinese CR4_NS1_label_6c72382b:

    # Caroline "(It’s so quiet out here at night - there’s nothing in the air except the sound of chirping cicadas.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:460
translate chinese CR4_NS1_label_0b2482b9:

    # Caroline "(His breathing is getting faster now, I’ll go up and down his shaft a couple more times, and then engulf his cock in my mouth.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:464
translate chinese CR4_NS1_label_9a76b28e:

    # MC "Oh fuck, just like that, Caroline. Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:466
translate chinese CR4_NS1_label_951cc58a:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:470
translate chinese CR4_NS1_label_1aa36d5b:

    # MC "Ahh... Fuck... Yes..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:471
translate chinese CR4_NS1_label_c12b37dd:

    # Caroline "*Liiiiiccccck*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:472
translate chinese CR4_NS1_label_c159c162:

    # Caroline "(His cock is twitching with each flick of my tongue. I wonder how long he’ll last?)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:476
translate chinese CR4_NS1_label_bcf6065d:

    # MC "(I wish this moment would never end. This is heavenly!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:477
translate chinese CR4_NS1_label_a61d2fd8:

    # MC "You’re so good at that. Mmm! Don’t stop!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:478
translate chinese CR4_NS1_label_951cc58a_1:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:482
translate chinese CR4_NS1_label_e538bc98:

    # Caroline "(I think that’s [player_name] suitably warmed up - time for the main event!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:483
translate chinese CR4_NS1_label_7d191740_2:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:484
translate chinese CR4_NS1_label_47fd04f8:

    # MC "(Her tongue is so warm! I love the feeling of her, slowly lapping her way up my cock.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:488
translate chinese CR4_NS1_label_fb32e779_1:

    # MC "Ohh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:489
translate chinese CR4_NS1_label_ff5ba78d:

    # Caroline "(I can hear his heart beating through his shirt. It looks like my tongue’s really got his blood flowing!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:490
translate chinese CR4_NS1_label_f733f981:

    # Caroline "*Slurp*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:491
translate chinese CR4_NS1_label_9c1ed6bb:

    # Caroline "(Time to take the tip of his cock in my mouth now.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:495
translate chinese CR4_NS1_label_8a391467:

    # MC "Ahh... Yes! Ohhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:496
translate chinese CR4_NS1_label_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:497
translate chinese CR4_NS1_label_f2f49b9f:

    # Caroline "(He’s quivering now. I love the way he can’t resist my mouth pleasuring him, down there.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:501
translate chinese CR4_NS1_label_1ae8aaf4:

    # MC "Oh my God... You’re so good at that!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:502
translate chinese CR4_NS1_label_e0cee18c:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:503
translate chinese CR4_NS1_label_d7fb4eb4:

    # MC "Can you ugh... go deeper? "
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:507
translate chinese CR4_NS1_label_a1f5f8b7:

    # Caroline "*Shlurrrrp*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:508
translate chinese CR4_NS1_label_23da9308_1:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:509
translate chinese CR4_NS1_label_8f2a8573:

    # MC "Oh fuck! Hnnnggg.... Deeper! Ah!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:513
translate chinese CR4_NS1_label_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:514
translate chinese CR4_NS1_label_5ecb200d:

    # Caroline "*SHLUUURRRRP*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:516
translate chinese CR4_NS1_label_0fcbb5c5:

    # MC "Ugh! Ahhhhhh! Yes! Mmmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:517
translate chinese CR4_NS1_label_1f48ebd4:

    # Caroline "(Time to suck you dry, [player_name]!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:521
translate chinese CR4_NS1_label_35aeaed4:

    # Caroline "*SHLLUURRRRRRP*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:523
translate chinese CR4_NS1_label_b3f0608d:

    # MC "Oh, my God! Yes! Mmm! Fuck!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:524
translate chinese CR4_NS1_label_f1a30237:

    # MC "(Holy shit, it’s so fucking intense!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:528
translate chinese CR4_NS1_label_14b73e35:

    # MC "You’re ah-aaahhmmazing! Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:530
translate chinese CR4_NS1_label_7d31255b:

    # Caroline "*SUCK SUCK SUCK*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:532
translate chinese CR4_NS1_label_3cbcaad7:

    # MC "Don’t stop! Keep sucking my cock! Hnnnggg.... Aaarrghh...."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:536
translate chinese CR4_NS1_label_a0307c02:

    # Caroline "(I’ll start picking up the pace now. This should really bring him close to a climax.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:538
translate chinese CR4_NS1_label_e0cee18c_1:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:540
translate chinese CR4_NS1_label_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:544
translate chinese CR4_NS1_label_7abe0eef:

    # MC "Mmm, holy fuck! Yes! Yes! Keep going, I’m so fucking close!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:545
translate chinese CR4_NS1_label_2e746551:

    # Caroline "Mmmpfff!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:546
translate chinese CR4_NS1_label_c25752a2:

    # Caroline "*SHLURP*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:550
translate chinese CR4_NS1_label_39da96e9:

    # MC "Fuck! I’m cumming!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:552
translate chinese CR4_NS1_label_7d31255b_1:

    # Caroline "*SUCK SUCK SUCK*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:553
translate chinese CR4_NS1_label_cd3a1094:

    # MC "Ahhh! HNNNGGG!!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:558
translate chinese CR4_NS1_label_24e3b64a:

    # Caroline "(Oh wow! I can taste his hot salty cum, filling up my mouth!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:559
translate chinese CR4_NS1_label_a96656a6:

    # MC "Hnnng! Ugh! Ahh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:560
translate chinese CR4_NS1_label_54d3900c:

    # Caroline "*Suck* *Suck*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:571
translate chinese CR4_NS1_label_c821daf5:

    # MC "*Pant* That was *Pant* incredible."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:572
translate chinese CR4_NS1_label_32053a88:

    # Caroline "Ahh..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:576
translate chinese CR4_NS1_label_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:577
translate chinese CR4_NS1_label_7c6f49c1:

    # MC "(Oh fuck... That’s hot!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:581
translate chinese CR4_NS1_label_a98290a3:

    # Caroline "Well? What did you think? I got that last part from a porno I watched, a few nights back."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:582
translate chinese CR4_NS1_label_18a588b4:

    # MC "It was insanely sexy, watching you swallow my cum!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:583
translate chinese CR4_NS1_label_ab0d02ab:

    # Caroline "Hehe, I’m glad you liked it."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:584
translate chinese CR4_NS1_label_0de80242:

    # Caroline "That wasn’t the only surprise I have for you tonight though. I’m going to need you to give me five minutes, for the next surprise."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:585
translate chinese CR4_NS1_label_36daacf1:

    # MC "Sure, what do you want me to do?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:586
translate chinese CR4_NS1_label_65e9a16f:

    # Caroline "Just sit and wait right here. Focus on getting your guy stiff again - you’ll be needing him."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:587
translate chinese CR4_NS1_label_af21b99c:

    # MC "Ohh, I like the sound of this!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:588
translate chinese CR4_NS1_label_761d9fd6:

    # Caroline "I’ll be back in five! No peeking!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:602
translate chinese CR4_NS1_label_wait_07dc4477:

    # MC "(Caroline’s only been away for a couple of minutes. I wonder what else she has planned as a surprise though?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:603
translate chinese CR4_NS1_label_wait_6263bf76:

    # MC "(I mean, she’s already given me a blowjob. You can’t get much better than that, right?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:607
translate chinese CR4_NS1_label_wait_db8a293f:

    # MC "(Unless she was wanting to go the whole way with me - but she would have probably brought blankets or something.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:608
translate chinese CR4_NS1_label_wait_1d899a5d:

    # MC "(I don’t imagine she would just want to fuck on the grass.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:612
translate chinese CR4_NS1_label_wait_3e460e0f:

    # MC "(I didn’t notice any condoms or sex toys beside her either. So it probably isn’t going to involve me fucking her.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:613
translate chinese CR4_NS1_label_wait_ac266be3:

    # MC "(Oh! Maybe she’s bringing her friend Violet over for a threesome?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:617
translate chinese CR4_NS1_label_wait_8a665e9a:

    # MC "(Actually, that doesn’t make sense either. If Caroline is really worried about me cheating on her or leaving her, she wouldn’t be involving Violet.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:618
translate chinese CR4_NS1_label_wait_a52d8960:

    # MC "(Bugger... I’m out of ideas. What the heck could she be planning?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:622
translate chinese CR4_NS1_label_wait_7494f8db:

    # Caroline "That’s me ready! Come on back around!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:623
translate chinese CR4_NS1_label_wait_8dd9d09d:

    # MC "Great! Coming now!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:642
translate chinese CR4_NS1_lake_f869a591:

    # MC "Caroline? Where are yo-"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:643
translate chinese CR4_NS1_lake_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:644
translate chinese CR4_NS1_lake_eedcb3d7:

    # MC "(Holy shit! She looks incredible in that swimsuit! I normally prefer bikinis, but that one-piece really makes her breasts stand out!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:648
translate chinese CR4_NS1_lake_e4ca7ec0:

    # Caroline "Surprise! Haha! What do you think? Like it?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:649
translate chinese CR4_NS1_lake_892f5f13:

    # MC "You look amazing in that!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:650
translate chinese CR4_NS1_lake_644627e8:

    # Caroline "Thanks. I’ve had it in my cupboard for a few years now. I’ve never really gotten a chance to wear it anywhere."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:651
translate chinese CR4_NS1_lake_cb7c9c0d:

    # Caroline "It is a LITTLE bit too lewd for the swimming pool, after all. Haha!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:652
translate chinese CR4_NS1_lake_d1ac6f39:

    # MC "Ahaha, true."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:656
translate chinese CR4_NS1_lake_9f906d4b:

    # Caroline "Now, how about you strip down to your trunks. We’re going swimming!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:657
translate chinese CR4_NS1_lake_45799c83:

    # MC "In the lake?!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:658
translate chinese CR4_NS1_lake_91778c47:

    # Caroline "Why not? It’s a warm night."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:662
translate chinese CR4_NS1_lake_2fb32a9e:

    # MC "Uh, sure. Why not?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:663
translate chinese CR4_NS1_lake_14d8d878:

    # Caroline "Great, I’ll catch you in there!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:664
translate chinese CR4_NS1_lake_18572fd2:

    # MC "(I would never have guessed this was the surprise she was talking about!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:668
translate chinese CR4_NS1_lake_891ed115:

    # MC "(She just dove straight in! I can’t keep her waiting any longer - time to strip out of these clothes.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:669
translate chinese CR4_NS1_lake_6d66197d:

    # MC "Wait for me!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:674
translate chinese CR4_NS1_lake_7fda7291:

    # "*SPLASH**"
    ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:675
translate chinese CR4_NS1_lake_7b1843dc:

    # MC "(That tight swimsuit really shows off the best angle of her ass!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:676
translate chinese CR4_NS1_lake_9264f6cd:

    # MC "(Her feet look incredible too!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:680
translate chinese CR4_NS1_lake_5d0c1bcd:

    # MC "(I hope Caroline’s right about the water being warm!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:681
translate chinese CR4_NS1_lake_4c6ceec6:

    # MC "(I wouldn’t like to get a cold shock from diving blindly into this!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:685
translate chinese CR4_NS1_lake_1005c2c5:

    # Caroline "Ahh... Hurry up and get in here. The water’s lovely!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:686
translate chinese CR4_NS1_lake_0ed64fa4:

    # Caroline "What are you waiting for? You’re not scared of a little water, are you? Haha!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:687
translate chinese CR4_NS1_lake_afc28ee3:

    # MC "Of course not! I’m not Sara! Haha!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:691
translate chinese CR4_NS1_lake_1144b4ed:

    # Caroline "Hehe! Well, when you’re done admiring the view, come and join me. And when I say “view”, I mean me!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:692
translate chinese CR4_NS1_lake_038afe11:

    # MC "I wasn’t - umm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:693
translate chinese CR4_NS1_lake_99355bd7:

    # Caroline "It’s okay, look all you want. I dressed this way, for YOU tonight. Enjoy it."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:697
translate chinese CR4_NS1_lake_39124583:

    # MC "You are beautiful, Caroline, you know that? You take my breath away every single time I see you. It doesn’t matter whether you’re in a sexy swimsuit, or your hot cosplay outfits, or... even just your regular clothes."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:698
translate chinese CR4_NS1_lake_804903a4:

    # MC "You rock whatever outfit you wear, and you are stunningly gorgeous."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:699
translate chinese CR4_NS1_lake_a723c211:

    # Caroline "Aww, thank you, [player_name]. You’re so sweet."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:700
translate chinese CR4_NS1_lake_2b630d0d:

    # Caroline "Now, how about you stop stalling, and join me? I’m not going to bite you! Unless you ask me to. Hehe!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:705
translate chinese CR4_NS1_lake_6ccbac6e:

    # "*Splash*"
    ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:706
translate chinese CR4_NS1_lake_d486f4c9:

    # Caroline "Haha! That was the LEAST elegant dive I’ve ever seen!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:710
translate chinese CR4_NS1_lake_34ea6d79:

    # MC "You’ve clearly practiced more than me. Do you come down to this place to swim often?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:711
translate chinese CR4_NS1_lake_13218543:

    # Caroline "Umm... Once or twice per year, when the stars align. I need good weather, a clear schedule, and a warm night. So it’s not as often as I’d like to be here."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:712
translate chinese CR4_NS1_lake_b9272d36:

    # MC "What do you do?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:713
translate chinese CR4_NS1_lake_ad19a370:

    # Caroline "Honestly, I’ll just swim a couple of laps - then I like to lie back and float. When there’s no clouds, you can see right up into the stars. There was one night, three years ago, when the power went out. Do you remember?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:714
translate chinese CR4_NS1_lake_df5384da:

    # MC "Sort of."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:715
translate chinese CR4_NS1_lake_abb05762:

    # Caroline "You went into Sara’s room to keep her company. I snuck out of the house and came down to the lake. The whole city had lost its power. There was no light pollution."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:716
translate chinese CR4_NS1_lake_eff24a2b:

    # Caroline "The sky wasn’t black that night. If you stared hard enough you could see a rainbow of nebula between the starry diamonds. It was a once-in-a-lifetime experience."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:720
translate chinese CR4_NS1_lake_a8fde49d:

    # Caroline "...and then the city’s power came back on and all I could see was a crescent moon and a handful of the strongest stars."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:721
translate chinese CR4_NS1_lake_00f397f0:

    # MC "That sounds heavenly. I’d like to see that with you someday."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:722
translate chinese CR4_NS1_lake_57e4b0e1:

    # Caroline "We’d probably have to borrow [Linda_name]’s car and drive outside the city limits though. Unless you want to wait for the miniscule chance of us seeing another blackout."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:723
translate chinese CR4_NS1_lake_8e9c4586:

    # MC "Maybe that’s something we could do? Do you mind if I slip your top down?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:724
translate chinese CR4_NS1_lake_5b02a939:

    # Caroline "Haha, of course not, [player_name]. You can do whatever you want to me."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:728
translate chinese CR4_NS1_lake_903faf79:

    # MC "*Whistle* Beautiful as always, Caroline."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:729
translate chinese CR4_NS1_lake_bf1cd9c8:

    # MC "(Her nipples are already stiff! Either she finds the water colder than she would care to admit, or she is already turned on!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:730
translate chinese CR4_NS1_lake_b3371eaf:

    # MC "(I’m gonna start kissing my way down the back of her neck.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:734
translate chinese CR4_NS1_lake_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:735
translate chinese CR4_NS1_lake_4d3e8258:

    # Caroline "Mmm... Oh fuck... Right there."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:736
translate chinese CR4_NS1_lake_1c0586b2:

    # Caroline "(God, I love the way he holds my breasts.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:740
translate chinese CR4_NS1_lake_f050ce10_1:

    # MC "*Lick*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:741
translate chinese CR4_NS1_lake_bca896ee:

    # Caroline "Mmm! Ah... Ohh..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:742
translate chinese CR4_NS1_lake_2c2ccb86:

    # MC "(Her moaning is getting louder - she’s really enjoying this!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:746
translate chinese CR4_NS1_lake_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:747
translate chinese CR4_NS1_lake_063d9ac3:

    # Caroline "Ah... Yes... Mmm! Play with my nipples! Ohh..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:748
translate chinese CR4_NS1_lake_72b604d0:

    # Caroline "(I’m getting so horny and wet right now!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:752
translate chinese CR4_NS1_lake_3b58c51b:

    # MC "What can I do for you? Anything at all! I owe you big time for those amazing blowjobs you gave me."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:753
translate chinese CR4_NS1_lake_a9c20ce1:

    # Caroline "Anything?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:754
translate chinese CR4_NS1_lake_bbd91dd1:

    # MC "I’ll suck your boobs, lick your pussy. Just name it. I want to make you feel as good as you made me feel."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:758
translate chinese CR4_NS1_lake_a3ea908d:

    # Caroline "(I think... tonight might be the night to finally do it.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:759
translate chinese CR4_NS1_lake_61fcaada:

    # Caroline "Hmm... Well, there is one thing."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:760
translate chinese CR4_NS1_lake_5f172b26:

    # MC "Yeah, Caroline?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:761
translate chinese CR4_NS1_lake_cc15df20:

    # Caroline "I... Can you look away when I ask? Sorry, I can’t say it when you’re looking straight at me."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:765
translate chinese CR4_NS1_lake_0607b189:

    # MC "Haha, okay. What did you want to ask?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:766
translate chinese CR4_NS1_lake_ca7f19e4:

    # Caroline "Can you... fuck- I want to have my first time with you tonight."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:767
translate chinese CR4_NS1_lake_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:771
translate chinese CR4_NS1_lake_7a803880:

    # Caroline "Y-Yeah, I think I’m ready."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:772
translate chinese CR4_NS1_lake_227b2517:

    # MC "Right here in the lake?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:773
translate chinese CR4_NS1_lake_0cc20184:

    # Caroline "No... Over there on the riverbank. That’s where I lay when the power cut out. I love that spot."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:777
translate chinese CR4_NS1_lake_d182bf2e:

    # Caroline "Whoa! You don’t have to carry me over there. I can swim by myself, you know!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:778
translate chinese CR4_NS1_lake_62d30eec:

    # MC "But do you like me carrying you like this?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:779
translate chinese CR4_NS1_lake_dfafef7c:

    # Caroline "...yeah..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:783
translate chinese CR4_NS1_lake_06ccc228:

    # MC "Is this the spot?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:784
translate chinese CR4_NS1_lake_cff1b41d:

    # Caroline "Yes, just right of the oak tree."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:785
translate chinese CR4_NS1_lake_83e16f39:

    # MC "You’re not cold, are you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:789
translate chinese CR4_NS1_lake_47820d97:

    # Caroline "Try and relax. I’m fine. I promise."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:790
translate chinese CR4_NS1_lake_00ac0da5:

    # MC "Okay, I just didn’t want you catching a flu or-"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:794
translate chinese CR4_NS1_lake_c75cdf38:

    # Caroline "Hush... You’re worrying too much."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:795
translate chinese CR4_NS1_lake_ee20bde4:

    # Caroline "Go ahead and set me down here. I’ll get myself ready for you."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:796
translate chinese CR4_NS1_lake_8c704b78:

    # Caroline "(My heart is racing right now - I guess tonight's the night.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:800
translate chinese CR4_NS1_lake_4d31d835:

    # Caroline "Well, this is it, [player_name]. *Gulp* I’m all yours."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:801
translate chinese CR4_NS1_lake_49ba2601:

    # MC "Are you okay, Caroline? You sound a little bit nervous."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:802
translate chinese CR4_NS1_lake_eca4355f:

    # Caroline "I’ll be fine. I’m not sure if it’s nerves or maybe just excitement. What I do know for sure, is that I definitely want this."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:806
translate chinese CR4_NS1_lake_b8dc1140:

    # Caroline "I can see you’re already hard. Come on over and fuck me on the bank."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:807
translate chinese CR4_NS1_lake_4709766e:

    # Caroline "I can’t wait to feel your thick cock inside me. "
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:808
translate chinese CR4_NS1_lake_f6bfe6f1:

    # Caroline "(I’ve been imagining [player_name]’s cock when I’ve been using my dildo, for FAR too long now.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:812
translate chinese CR4_NS1_lake_f46fa3c8:

    # MC "I’m going to go slow when I start. I don’t want to hurt you."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:813
translate chinese CR4_NS1_lake_e741f1b6:

    # Caroline "Thank you, [player_name]. But don’t worry - you’re not going to hurt me. I promise."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:814
translate chinese CR4_NS1_lake_30034a6e:

    # MC "Oh..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:818
translate chinese CR4_NS1_lake_ae37533a:

    # MC "(It already feels so good! Her vulva is so warm and wet!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:820
translate chinese CR4_NS1_lake_67c2bad7:

    # MC "(I’ll have to try and not blow my load too quickly. I want to make our first time last as long as possible.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:824
translate chinese CR4_NS1_lake_d52e6084:

    # Caroline "Ahh... yes! Put your cock inside me, [player_name]! I want to feel you fill me up!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:825
translate chinese CR4_NS1_lake_afaa2e63:

    # MC "Ohh... Fuck... Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:826
translate chinese CR4_NS1_lake_84c0945f:

    # MC "(I can’t believe it - after waiting so long, it’s finally going to happen. I’m going to get to fuck her!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:830
translate chinese CR4_NS1_lake_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:831
translate chinese CR4_NS1_lake_278d5957:

    # MC "I love you too, Caroline."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:832
translate chinese CR4_NS1_lake_69fa2a22:

    # MC "Ready?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:833
translate chinese CR4_NS1_lake_8d19b83a:

    # Caroline "Uh huh."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:837
translate chinese CR4_NS1_lake_84e09ab8:

    # Caroline "Ah!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:838
translate chinese CR4_NS1_lake_4d7e8441:

    # MC "Ohh... Fuck!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:839
translate chinese CR4_NS1_lake_376ad084:

    # MC "(The feeling of her pussy wrapped around my glans is amazing!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:843
translate chinese CR4_NS1_lake_a1be6637:

    # MC "Are you alright, ah... Caroline?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:844
translate chinese CR4_NS1_lake_12dc1d57:

    # Caroline "Uh huh! Y-Yeah! Fuck me, [player_name]!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:845
translate chinese CR4_NS1_lake_573aeacd:

    # Caroline "I want to feel you go ohh... balls-deep inside my tight little pussy!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:849
translate chinese CR4_NS1_lake_281ddf39:

    # MC "Alright, as long as you’re sure."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:850
translate chinese CR4_NS1_lake_91ba1b61:

    # Caroline "Mmm! I’m sure! Put it inside me!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:851
translate chinese CR4_NS1_lake_81e28f81:

    # MC "(Here goes nothing!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:855
translate chinese CR4_NS1_lake_3e40661b:

    # Caroline "OHHH GODDDD! YES!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:857
translate chinese CR4_NS1_lake_ab7674e9:

    # MC "Hnnng! Ugh! Oh shit! That’s so good!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:858
translate chinese CR4_NS1_lake_a6b09409:

    # Caroline "Ah! Your cock is so ahh... thick!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:862
translate chinese CR4_NS1_lake_16c70088:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:863
translate chinese CR4_NS1_lake_576bc79f:

    # Caroline "No! Mmm! It feels really good right now!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:864
translate chinese CR4_NS1_lake_42057a49:

    # MC "Are you okay if I keep thrusting?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:865
translate chinese CR4_NS1_lake_ec5a3228:

    # Caroline "Yes, please - and don’t stop!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:869
translate chinese CR4_NS1_lake_dcb3a52e:

    # MC "Uh! Ah!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:870
translate chinese CR4_NS1_lake_31666053:

    # Caroline "Ohh! Mmm! Yes! Just like that!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:871
translate chinese CR4_NS1_lake_c33c03dd:

    # MC "Ugh! Your pussy is so hot!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:875
translate chinese CR4_NS1_lake_fd6ddc55:

    # Caroline "Ah! AHH! Fuck me! Yes!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:876
translate chinese CR4_NS1_lake_361028b4:

    # Caroline "Fuck me harder, [player_name]! I’m going to cum!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:877
translate chinese CR4_NS1_lake_c0e23921:

    # Caroline "AHHH! AHHHHHH!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:881
translate chinese CR4_NS1_lake_edce70ef:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:882
translate chinese CR4_NS1_lake_b5dd395e:

    # Caroline "(I’m cumming! Holy shit! I can’t control my body, right now!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:883
translate chinese CR4_NS1_lake_374f76bb:

    # MC "(Her whole body is shaking like crazy, right now! I never realised she would climax, this quickly, from me fucking her!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:887
translate chinese CR4_NS1_lake_0796017b:

    # Caroline "MPPFFFFF!!!! MMMMMM!! AAAAHHMMMMMMM!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:889
translate chinese CR4_NS1_lake_fda3b9ca:

    # MC "(She must have REALLY been looking forward to this!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:890
translate chinese CR4_NS1_lake_2cfeb5e3:

    # MC "(Her pussy is clamping down around my shaft! I’m not going to be able to last very long if she keeps cumming as intensely as this!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:894
translate chinese CR4_NS1_lake_c2b543cd:

    # Caroline "Mmm mmm..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:895
translate chinese CR4_NS1_lake_c599aac5:

    # Caroline "(Wow... It’s finally passing. That orgasm was amazing!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:896
translate chinese CR4_NS1_lake_8448b3ac:

    # Caroline "(I hope he doesn’t stop though - if he keeps fucking me like this I might be able to cum multiple times!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:900
translate chinese CR4_NS1_lake_a161433d:

    # MC "Hnnnng! Ugh! Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:901
translate chinese CR4_NS1_lake_4fe392f8:

    # Caroline "(Yes! Keep pounding me like that!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:902
translate chinese CR4_NS1_lake_4ee65a4e:

    # Caroline "(His fat cock is making my entire body shake, each time he thrusts it inside me!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:906
translate chinese CR4_NS1_lake_4f5e7e04:

    # Caroline "MMMMM!!! AHMMMMMM!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:908
translate chinese CR4_NS1_lake_253b8129:

    # MC "(I can feel her fingers digging into the back of my head. She is really enjoying this!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:909
translate chinese CR4_NS1_lake_160a1c6b:

    # MC "(It must feel so intense for her, right now.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:913
translate chinese CR4_NS1_lake_4c14c112:

    # MC "Mmm! Aaahmmmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:915
translate chinese CR4_NS1_lake_f6a31822:

    # Caroline "Faster, [player_name]!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:917
translate chinese CR4_NS1_lake_edce70ef_1:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:919
translate chinese CR4_NS1_lake_75d8cda3:

    # Caroline "(This feels so good! I’d really like to change up positions a bit too, though.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:921
translate chinese CR4_NS1_lake_4f5e7e04_1:

    # Caroline "MMMMM!!! AHMMMMMM!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:924
translate chinese CR4_NS1_lake_1195c13d:

    # Caroline "This ahh... feels so good! Do you want to try ohh... doing it from behind?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:925
translate chinese CR4_NS1_lake_e40ae654:

    # MC "Sure, why not?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:926
translate chinese CR4_NS1_lake_b93dccf9:

    # Caroline "Okay, let me just swivel round."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:930
translate chinese CR4_NS1_lake_7ad805ae:

    # MC "How do you want me to do it?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:931
translate chinese CR4_NS1_lake_795da874:

    # Caroline "As fast and as hard as you possibly can. I love it when you go really rough."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:932
translate chinese CR4_NS1_lake_9839e13a:

    # MC "I’ll try pounding you as hard as I can, then."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:936
translate chinese CR4_NS1_lake_89e26a3c:

    # Caroline "Thanks. I’m looking forward to it!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:937
translate chinese CR4_NS1_lake_4f6893c9:

    # MC "(I wonder if she will let me cum inside her.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:938
translate chinese CR4_NS1_lake_993e287c:

    # MC "Can I finish inside you, Caroline?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:942
translate chinese CR4_NS1_lake_e8ce10ea:

    # Caroline "Umm... I’m not on any birth control right now... It’s probably not a great idea."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:943
translate chinese CR4_NS1_lake_3c01d8a7:

    # MC "Ahh, that’s okay."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:944
translate chinese CR4_NS1_lake_2ed5cc7f:

    # Caroline "Sorry..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:948
translate chinese CR4_NS1_lake_8e8af02a:

    # Caroline "Oh! And make sure you screw the right hole!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:949
translate chinese CR4_NS1_lake_63b28f7d:

    # Caroline "I might be horny right now, but I’m NOT in the mood for surprise anal!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:950
translate chinese CR4_NS1_lake_45523c04:

    # MC "Haha, don’t worry - I wouldn’t do that to you, Caroline."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:954
translate chinese CR4_NS1_lake_599b6842:

    # Caroline "Thanks, [player_name]. I MIGHT let you fuck my ass in the future, but for tonight let’s keep it to the pussy."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:955
translate chinese CR4_NS1_lake_f219acb6:

    # MC "No problem. I’ll make sure to fuck your pussy very roughly."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:959
translate chinese CR4_NS1_lake_3264540b:

    # MC "(Her asscheeks are so soft! I could squeeze and play with these all day!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:960
translate chinese CR4_NS1_lake_98c29d17:

    # Caroline " Are you having fun there?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:961
translate chinese CR4_NS1_lake_0d502e3a:

    # MC "Haha, sorry, I got distracted."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:965
translate chinese CR4_NS1_lake_33a529dc:

    # MC "(Damn, it looks really sexy when I tug her swimsuit up, tight like that!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:966
translate chinese CR4_NS1_lake_47c5ba7f:

    # Caroline "Pull it to the side and shove your cock inside me! I’m so fucking horny!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:970
translate chinese CR4_NS1_lake_a64d02ae:

    # Caroline "Yes! Hurry up and fuck me, [player_name]!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:971
translate chinese CR4_NS1_lake_b9d87c35:

    # MC "(Okay! Here we go!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:975
translate chinese CR4_NS1_lake_7ccdfa6f:

    # "*RRRIIIIP*"
    ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:976
translate chinese CR4_NS1_lake_f57d5b3c:

    # MC "(Oh shit, I just ripped it!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:977
translate chinese CR4_NS1_lake_97920477:

    # Caroline "Mmm, that was really hot! I like it when you tear my clothes off."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:981
translate chinese CR4_NS1_lake_6632cc61:

    # MC "(Phew! I thought I was going to get in shit for ruining her bathing suit!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:982
translate chinese CR4_NS1_lake_08614751:

    # Caroline "It feels so aggressive and domineering when you strip me naked. I really love that."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:983
translate chinese CR4_NS1_lake_8bed9a81:

    # MC "Well, in that case, I’ll make sure to pound you extra hard. Spread your legs a bit wider, and I’ll start."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:987
translate chinese CR4_NS1_lake_145da06c:

    # Caroline "How’s this?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:988
translate chinese CR4_NS1_lake_ffeaaac5:

    # MC "Just a little bit wider, I want to make sure I can plough every single inch of my cock into your pussy."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:989
translate chinese CR4_NS1_lake_db9d1731:

    # Caroline "Mmm, I’m looking forward to this!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:993
translate chinese CR4_NS1_lake_7b0ec0e9:

    # MC "That’s perfect. I hope you’re ready - because I’m about to destroy your pussy."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:994
translate chinese CR4_NS1_lake_5dc0efae:

    # Caroline "Ooh, yes please!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:998
translate chinese CR4_NS1_lake_ba26d38c:

    # MC "(I wonder if she would mind me cumming inside her if she gets caught up in the heat of the moment?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:999
translate chinese CR4_NS1_lake_ea3670f5:

    # MC "(Maybe she’ll get too horny to resist?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1000
translate chinese CR4_NS1_lake_540e7da5:

    # MC "(I mean, there’s always the risk of pregnancy. But it feels SOOO much better, just shooting a hot load of baby batter deep into her unprotected cunt.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1004
translate chinese CR4_NS1_lake_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1005
translate chinese CR4_NS1_lake_47b594c5:

    # Caroline "(I can feel his dick at the entrance to my pussy!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1006
translate chinese CR4_NS1_lake_60768891:

    # Caroline "(Oh God, my heart’s racing with excitement, right now!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1010
translate chinese CR4_NS1_lake_d24bf861:

    # MC "Oh God! Mmm! Yes!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1011
translate chinese CR4_NS1_lake_d2ee7ab9:

    # Caroline "Ohh... Right there!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1012
translate chinese CR4_NS1_lake_1d8d436b:

    # Caroline "(His bare cock is slipping into my pussy! Damn, I REALLY should have brought condoms with me...)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1016
translate chinese CR4_NS1_lake_ce854b83:

    # MC "Ahh... Fuck, your pussy feels so good, Caroline!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1017
translate chinese CR4_NS1_lake_02737bc5:

    # Caroline "Mmm! Uh huh! Ahh!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1018
translate chinese CR4_NS1_lake_717e8ec9:

    # Caroline "Fuck me really hard! Ah!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1022
translate chinese CR4_NS1_lake_a614c71e:

    # MC "Oh, I will. By the time I’m finished, your legs will be too weak to stand."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1023
translate chinese CR4_NS1_lake_2a1b0b54:

    # Caroline "Ahh... Mmm!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1027
translate chinese CR4_NS1_lake_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1028
translate chinese CR4_NS1_lake_ea05542d:

    # Caroline "AHHH! OH FUCK! AHHH!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1029
translate chinese CR4_NS1_lake_fee15f0d:

    # Caroline "J-Just like that! Ugh!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1033
translate chinese CR4_NS1_lake_87d837d4:

    # Caroline "I love it when you fuck ahh.. me rough and ohhh... hard like this! MMMM!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1034
translate chinese CR4_NS1_lake_1932d5af:

    # MC "Arrgh! You’re so fucking tight!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1035
translate chinese CR4_NS1_lake_c7572ea3:

    # Caroline "Ah! AHHH!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1038
translate chinese CR4_NS1_lake_2155bffb:

    # Caroline "Harder! Fuck me harder! Ohhhhh!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1039
translate chinese CR4_NS1_lake_148d1d95:

    # MC "(Thankfully we’re far away from the house! Caroline is really loud right now! I’d hate [Linda_name] or [Bob_name] to hear us doing this!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1040
translate chinese CR4_NS1_lake_489d5bdc:

    # MC "(Okay, it’s time to wreck her pussy, like I promised!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1044
translate chinese CR4_NS1_lake_11f53c8a:

    # Caroline "AYAAAAHHHHHHH!!! Holy ahhhh... shit! OHHH!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1046
translate chinese CR4_NS1_lake_887c96aa:

    # Caroline "Talk dirty to me! OHH!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1048
translate chinese CR4_NS1_lake_e59b5844:

    # MC "Mmmm! Ahh! Ugh! Take my cock, you fucking slut!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1052
translate chinese CR4_NS1_lake_f232f539:

    # MC "Fuck! I’m gonna cum soon! UGh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1053
translate chinese CR4_NS1_lake_bb5a2d93:

    # MC "Hnng... Can I do it inside you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1054
translate chinese CR4_NS1_lake_51fbeb05:

    # Caroline "I ahhh... ohhh! I don’t know... MMM!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1058
translate chinese CR4_NS1_lake_ec4cb8fe:

    # MC "Hnnng! I’m about to cum! Inside or out?! Ahhh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1060
translate chinese CR4_NS1_lake_9a1d6a7e:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1062
translate chinese CR4_NS1_lake_5709fc1e:

    # Caroline "(Shit! It’s too risky! I have to say outside - but it feels sooo fucking good right now!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1064
translate chinese CR4_NS1_lake_9d78e7b8:

    # MC "Caroline?!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1066
translate chinese CR4_NS1_lake_2e150c2d:

    # MC "(She’s too lost in pleasure to make a decision - I’ll have to do it for her.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1068
translate chinese CR4_NS1_lake_c7572ea3_1:

    # Caroline "Ah! AHHH!!!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1072
translate chinese CR4_NS1_lake_d6b5136f:

    # MC "Fuck it! I’m cumming inside you!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1076
translate chinese CR4_NS1_lake_00016007:

    # Caroline "Oh God!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1077
translate chinese CR4_NS1_lake_5700a7a8:

    # MC "Hnnnngggg!!!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1078
translate chinese CR4_NS1_lake_be9334a4:

    # Caroline "AHHH! FILL ME UP, [player_name]! OHHH, FUCK!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1088
translate chinese CR4_NS1_lake_ec4c3180:

    # Caroline "(I can feel his hot cum, blasting up against my cervix! Holy shit! This is incredible!)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1095
translate chinese CR4_NS1_lake_ea965d7a:

    # MC "(Fuck it! Cumming inside is too risky!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1096
translate chinese CR4_NS1_lake_a8839386:

    # MC "Hnnng! Ugh! Ahh!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1106
translate chinese CR4_NS1_lake_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1107
translate chinese CR4_NS1_lake_e75a8159:

    # Caroline "(Thank God he pulled out... I don’t think I could have resisted otherwise...)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1108
translate chinese CR4_NS1_lake_772d1c92:

    # Caroline "(There’s probably still a tiny risk of me getting pregnant, but it’s much smaller than having him stuff me full of his semen.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1109
translate chinese CR4_NS1_lake_5971d331:

    # MC "Ugh! Yes! Ahhh.... *Pant*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1117
translate chinese CR4_NS1_lake_con2_4e1ebe13:

    # Caroline "That was... *Pant* amazing..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1118
translate chinese CR4_NS1_lake_con2_677a9149:

    # MC "Y-Yeah, we *Pant* did good... Phew... I’m exhausted."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1119
translate chinese CR4_NS1_lake_con2_64217f5c:

    # Caroline "Heh, me too..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1123
translate chinese CR4_NS1_lake_con2_3e5f61ba:

    # MC "Sorry about damaging your swimsuit, Caroline. I’ll buy you a new one tomorrow."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1124
translate chinese CR4_NS1_lake_con2_2f0848d9:

    # Caroline "Hehe, relax. It’s fine. I enjoyed it - it was... spontaneous."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1125
translate chinese CR4_NS1_lake_con2_6c86f23f:

    # Caroline "Besides, it’s not like I’m going to have to run half-naked, back to our house. I’ve got a spare change of clothes behind the tree."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1129
translate chinese CR4_NS1_lake_con2_ffc5cc31:

    # MC "Ahh, that’s good to hear. Although, seeing you try and sneak your way back to your bedroom with no clothes on, would be pretty fucking hot."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1130
translate chinese CR4_NS1_lake_con2_d38057b9:

    # Caroline "You’ve got a REALLY dirty mind, you know that?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1131
translate chinese CR4_NS1_lake_con2_ad086509:

    # MC "Heh, I guess I do."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1132
translate chinese CR4_NS1_lake_con2_1a58f0a7:

    # Caroline "[player_name]?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1133
translate chinese CR4_NS1_lake_con2_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1134
translate chinese CR4_NS1_lake_con2_e92bbe60:

    # Caroline "I’m really glad we finally did this."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1135
translate chinese CR4_NS1_lake_con2_671e1b78:

    # MC "Me too."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1136
translate chinese CR4_NS1_lake_con2_439fa5f1:

    # Caroline "Remind me to show you a few tricks next time. I’ve got a few things I want to teach you."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1137
translate chinese CR4_NS1_lake_con2_b09a3568:

    # MC "Mmm, I’m looking forward to it. We should probably head back now, though. Before anyone notices us missing."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1138
translate chinese CR4_NS1_lake_con2_5ea4f63a:

    # Caroline "Good call. I’ll get dressed again now."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1158
translate chinese CR4_MS2_label_f8f8176a:

    # MC "(Christ almighty, it’s scorching today!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1159
translate chinese CR4_MS2_label_cd0caf62:

    # MC "(I’m glad I wasn’t wearing pyjamas when I went to bed, or my sheets would be soaked with sweat.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1160
translate chinese CR4_MS2_label_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1164
translate chinese CR4_MS2_label_396871d5:

    # MC "(Clear blue skies - it’s almost like I’m looking out onto the ocean, y’know. Those bright blue oceans you see when you look at pictures of Hawaii?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1165
translate chinese CR4_MS2_label_a2d8f61c:

    # MC "(I’d love to take Caroline to Hawaii someday. I think she’d like that.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1166
translate chinese CR4_MS2_label_212cc0ee:

    # MC "(Actually, no - she’d prefer Japan. She lives for their cosplay culture.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1170
translate chinese CR4_MS2_label_25424b85:

    # MC "(Okay, time to stop daydreaming and get myself up - I have to make the most of this beautiful day.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1174
translate chinese CR4_MS2_label_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1177
translate chinese CR4_MS2_label_f3a99030:

    # MC "Huh? Who is it?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1180
translate chinese CR4_MS2_label_6f76f879:

    # Caroline "Just me!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1186
translate chinese CR4_MS2_label_7f4fb2e6:

    # Caroline "Morning, sleepyhead! Are you still not awake?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1187
translate chinese CR4_MS2_label_9e7b4f9d:

    # MC "*Yawn* Yeah, I’m just getting up now."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1188
translate chinese CR4_MS2_label_63cf2835:

    # Caroline "Haha, I’m surprised [Mom_name] hasn’t yelled at you for sleeping in so late!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1189
translate chinese CR4_MS2_label_2e2b8bc8:

    # MC "Oh please. [Mom_name] gave up trying to wake me up the first few months! I’m just not a morning person!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1193
translate chinese CR4_MS2_label_8beec602:

    # Caroline "So, what has my handsome boyfriend got planned for today?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1194
translate chinese CR4_MS2_label_b2a94502:

    # MC "(Huh? I think this is the FIRST time she’s actually openly called me her boyfriend. She didn’t even seem fazed when she said it!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1195
translate chinese CR4_MS2_label_c6998850:

    # MC "Uh, yeah, no big plans for today. I’ll just see what happens. "
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1196
translate chinese CR4_MS2_label_b6bdacf8:

    # Caroline "Well, how about you begin by saying ‘Good Morning’ to your girlfriend?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1200
translate chinese CR4_MS2_label_29761283:

    # MC "Morning! *Yawn*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1201
translate chinese CR4_MS2_label_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1202
translate chinese CR4_MS2_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1206
translate chinese CR4_MS2_label_bddf499f:

    # MC "Umm... Is something wrong, Caroline?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1207
translate chinese CR4_MS2_label_4df4b341:

    # Caroline "Is that how you would say ‘Good Morning’ to your girlfriend if you met one in college?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1208
translate chinese CR4_MS2_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1212
translate chinese CR4_MS2_label_66215202:

    # Caroline "No, it’s not. You’d be a gentleman, and greet them with a kiss."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1213
translate chinese CR4_MS2_label_51f28a83:

    # Caroline "Just because we’ve known each other for years, doesn’t mean we’re going to be skipping out the romantic parts of being a couple!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1214
translate chinese CR4_MS2_label_7dc5c0ae:

    # MC "Ahh, I see where you’re coming from."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1218
translate chinese CR4_MS2_label_da6c6b30:

    # MC "Sorry about that, Caroline. How about we start again?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1219
translate chinese CR4_MS2_label_a941880a:

    # Caroline "Thank you, [player_name]."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1223
translate chinese CR4_MS2_label_64889fa5:

    # Caroline "Ready whenever you are!"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1224
translate chinese CR4_MS2_label_437095dc:

    # MC "(Caroline probably has some anxiety about getting into a new relationship. I guess it’s natural for her to feel a little worried, with how things ended, dating that asshole Charles.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1225
translate chinese CR4_MS2_label_db6e107d:

    # MC "(Having a dickhead like that for a partner would really shake your confidence. If this is what Caroline needs in order to feel secure in this relationship, then it’s fine by me.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1229
translate chinese CR4_MS2_label_2f2ca5d8:

    # MC "Sorry again, Caroline. Let’s give this morning a better start."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1230
translate chinese CR4_MS2_label_b8fc91e9:

    # MC "You really are incredibly beautiful, you know that?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1234
translate chinese CR4_MS2_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1235
translate chinese CR4_MS2_label_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1239
translate chinese CR4_MS2_label_048f8bed:

    # Caroline "(Mmm... That’s nice, [player_name] can be so romantic. I think he just needs someone to prompt him, every now and then.)"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1240
translate chinese CR4_MS2_label_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1244
translate chinese CR4_MS2_label_f59da683:

    # Caroline "Thanks, [player_name]. That was really sweet."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1245
translate chinese CR4_MS2_label_643705c2:

    # MC "No problem, Caroline. Sorry I didn’t get it right the first time."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1246
translate chinese CR4_MS2_label_542e4477:

    # Caroline "Relax, it’s fine. I overreacted a little. My bad."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1247
translate chinese CR4_MS2_label_b9416216:

    # MC "Are you in a rush to head out?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1248
translate chinese CR4_MS2_label_2d16c931:

    # Caroline "No, why?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1249
translate chinese CR4_MS2_label_c96c9bb1:

    # MC "Hop up on my knee for a while."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1253
translate chinese CR4_MS2_label_4447c249:

    # Caroline "I’m not too heavy, am I?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1254
translate chinese CR4_MS2_label_c40ef92c:

    # MC "You’re fine. Just try to relax. What have you got planned for today, then?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1255
translate chinese CR4_MS2_label_096110d2:

    # Caroline "Ugh, restocking at work. I’m going to have to check what products I’m running out of, and then order them online."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1259
translate chinese CR4_MS2_label_9b2f3613:

    # MC "Sounds tough!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1260
translate chinese CR4_MS2_label_98ce08b3:

    # Caroline "I don’t mind some LONG AND HARD work every now and then."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1261
translate chinese CR4_MS2_label_514ac08d:

    # MC "Haha! When do you have to leave?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1265
translate chinese CR4_MS2_label_cff31ad6:

    # Caroline "I’ll be heading in a few minutes. Say, if you’re free today at all, would you be able to lend me a hand?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1266
translate chinese CR4_MS2_label_e35c2908:

    # MC "What do you need?"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1267
translate chinese CR4_MS2_label_aa70b968:

    # Caroline "I’m going to have to spend quite a lot of time out the back, counting stuff and planning deliveries. Would you be able to stand behind the counter and man the till for me during that time?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1271
translate chinese CR4_MS2_label_633aab6e:

    # MC "Not a problem. I’m happy to help."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1272
translate chinese CR4_MS2_label_347317b0:

    # Caroline "Are you sure? I don’t want to take up your time."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1273
translate chinese CR4_MS2_label_907366a7:

    # MC "Honestly, relax! It’ll be fine."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1277
translate chinese CR4_MS2_label_ec4cdb9e:

    # Caroline "I guess, if I’m really quick I can try and get everything sorted in one afternoon. Would that be alright with you?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1278
translate chinese CR4_MS2_label_b970157d:

    # MC "Take as long as you need. If it runs over a couple of days, that’s not a problem."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1279
translate chinese CR4_MS2_label_496a730b:

    # MC "I’ve always been behind you and your business, right from the very start."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1283
translate chinese CR4_MS2_label_1b1d9c4b:

    # MC "Remember when you used to pay me for taking those naughty photos of you? Haha!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1284
translate chinese CR4_MS2_label_d9b2f5d2:

    # Caroline "Hehe, how could I forget?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1285
translate chinese CR4_MS2_label_821b0f47:

    # MC "That was a dream come true. Like, seriously, you have no idea how many times I jacked off, after those photoshoots."
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1289
translate chinese CR4_MS2_label_15012daf:

    # Caroline "Seriously? You jacked off?"
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1290
translate chinese CR4_MS2_label_0a43fdbf:

    # MC "All the time. You were so fucking hot in those outfits!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1291
translate chinese CR4_MS2_label_665438e6:

    # MC "Heck - you’re fucking hot, even in your regular clothes!"
    MC ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1295
translate chinese CR4_MS2_label_bffc411e:

    # Caroline "Awk, you’re too sweet. Thanks again, [player_name]. I’ll see you later on, in the store."
    Caroline ""

# game/scripts/home/mc_room/night/scenes/CR4_NS1.rpy:1296
translate chinese CR4_MS2_label_cad0a5ae:

    # MC "Excellent. I’ll see you then."
    MC ""

