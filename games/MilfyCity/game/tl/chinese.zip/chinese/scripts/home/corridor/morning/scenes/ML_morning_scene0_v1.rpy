﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:17
translate chinese ML_morning_scene0_v1_label_de5563f1:

    # MC "(Huh, that’s unusual. That’s Mom’s office suit.)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:19
translate chinese ML_morning_scene0_v1_label_844fcadf:

    # MC "(Huh, that’s unusual. That’s Linda’s office suit.)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:20
translate chinese ML_morning_scene0_v1_label_03247729:

    # MC "(She’s doesn’t normally dress and leave, for AT LEAST another hour.)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:23
translate chinese ML_morning_scene0_v1_label_625349f2:

    # MC "(Her legs DO look really good in it though...)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:24
translate chinese ML_morning_scene0_v1_label_79b3ab91:

    # MC "(Wait - what am I thinking?!)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:25
translate chinese ML_morning_scene0_v1_label_764a1127:

    # MC "(Ever since she kissed me on the mouth the other morning, these lewd thoughts about her have kept creeping into my mind.)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:26
translate chinese ML_morning_scene0_v1_label_a53c9a1d:

    # MC "(Perhaps I should just talk openly with Linda about this to clear the air?)"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:31
translate chinese ML_morning_scene0_v1_label_4fad776d:

    # Mom "Oh! You startled me there, [player_name]!"
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:32
translate chinese ML_morning_scene0_v1_label_c87ad7f4:

    # Mom "I was just about to leave for work. I’m making an early start today."
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:33
translate chinese ML_morning_scene0_v1_label_8ffa0bac:

    # Mom "What’s up with you? Something on your mind?"
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:34
translate chinese ML_morning_scene0_v1_label_ed434da7:

    # MC "Uhh... Y-Yeah actually - I wanted to talk to you about that... umm... kiss you gave me, the other day."
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:37
translate chinese ML_morning_scene0_v1_label_e2e318e4:

    # Mom "Oh, that... Haha... That was... nothing."
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:39
translate chinese ML_morning_scene0_v1_label_a81bfa69:

    # MC "It was... just... It was the first time I’ve ever kissed a girl."
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:41
translate chinese ML_morning_scene0_v1_label_b239f017:

    # MC "It was... just... It was the first time I’ve ever kissed a woman like you... You’re also married!"
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:42
translate chinese ML_morning_scene0_v1_label_c1a0d887:

    # Mom "Aww, I’m sorry. C’mere."
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:46
translate chinese ML_morning_scene0_v1_label_abeb7a9b:

    # Mom "I’m sorry. You just looked so sad the other day. I wanted to try and make my boy happy."
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:48
translate chinese ML_morning_scene0_v1_label_94d03f91:

    # Mom "I’m sorry. You just looked so sad the other day. I wanted to try and cheer you up a bit."
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:49
translate chinese ML_morning_scene0_v1_label_56840449:

    # Mom "Seeing you like that made me a little too emotional and I got all caught up in the moment."
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:50
translate chinese ML_morning_scene0_v1_label_550bf977:

    # Mom "Can you forgive me?"
    Mom ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:52
translate chinese ML_morning_scene0_v1_label_79f650e7:

    # MC "Y-Yeah, Mom. It’s alright."
    MC ""

# game/scripts/home/corridor/morning/scenes/ML_morning_scene0_v1.rpy:54
translate chinese ML_morning_scene0_v1_label_c583ae6b:

    # MC "Y-Yeah, Linda. It’s alright."
    MC ""

