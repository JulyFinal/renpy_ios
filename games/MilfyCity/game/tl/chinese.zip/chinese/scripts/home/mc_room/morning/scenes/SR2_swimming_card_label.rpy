﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:33
translate chinese SR2_swimming_card_label_e195764b:

    # MC "*Snooore...*"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:35
translate chinese SR2_swimming_card_label_6ce92b2e:

    # Sara "[player_name]? Are you asleep?"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:37
translate chinese SR2_swimming_card_label_618ca323:

    # MC "Zzzz..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:41
translate chinese SR2_swimming_card_label_b6484a1c:

    # Sara "[player_name]?"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:42
translate chinese SR2_swimming_card_label_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:43
translate chinese SR2_swimming_card_label_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:47
translate chinese SR2_swimming_card_label_035eb3c3:

    # Sara "Yay! You’re finally up!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:48
translate chinese SR2_swimming_card_label_568923ca:

    # MC "Huh? What time is it? You’re never up before me. I must have slept in."
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:49
translate chinese SR2_swimming_card_label_308b81cc:

    # Sara "Hey! There’s LOADS of times, I’ve been up before you!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:50
translate chinese SR2_swimming_card_label_3c15e64f:

    # MC "Oh really? Name me two occasions when you’ve woken up before me."
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:55
translate chinese SR2_swimming_card_label_e6227143:

    # Sara "Err... There was that time we were on that college trip in Spain!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:56
translate chinese SR2_swimming_card_label_e87a8f51:

    # MC "That’s because a cockroach crawled into your bed and you woke up screaming at five in the morning!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:57
translate chinese SR2_swimming_card_label_d1daa5ea:

    # Sara "I woke up before you so it still counts! And... uhh... today is number two! I win!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:59
translate chinese SR2_swimming_card_label_b8f245d4:

    # MC "*Sigh* What do you want me for, then? Did Mom tell you to get me out of bed?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:61
translate chinese SR2_swimming_card_label_bcfd70f2:

    # MC "*Sigh* What do you want me for, then? Did Linda tell you to get me out of bed?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:64
translate chinese SR2_swimming_card_label_9fb48996:

    # Sara "No, silly! I got you something!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:65
translate chinese SR2_swimming_card_label_1db20991:

    # MC "OOh cool! What is it?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:69
translate chinese SR2_swimming_card_label_82faae9c:

    # Sara "Ta-da! Here you go!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:70
translate chinese SR2_swimming_card_label_940e8a8c:

    # MC "What is it?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:71
translate chinese SR2_swimming_card_label_81a7d243:

    # Sara "Just open it!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:75
translate chinese SR2_swimming_card_label_e631171d:

    # MC "(Hmm, it doesn’t feel too heavy. I wonder what it could be.)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:77
translate chinese SR2_swimming_card_label_170657d7:

    # MC "(I’m gonna try shaking it.)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:79
translate chinese SR2_swimming_card_label_d05d1581:

    # "*RATTLE RATTLE*"
    ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:81
translate chinese SR2_swimming_card_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:82
translate chinese SR2_swimming_card_label_4a182ae3:

    # Sara "Seriously? What age are you?"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:83
translate chinese SR2_swimming_card_label_7f9791e2:

    # MC "C’mon! It’s perfectly natural to want to shake a present!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:84
translate chinese SR2_swimming_card_label_8ca17aad:

    # Sara "If you say so..."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:88
translate chinese SR2_swimming_card_label_520f74de:

    # Sara "Now, hurry up and open it. I can’t wait around all morning!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:89
translate chinese SR2_swimming_card_label_0983b7de:

    # MC "Fine, I’ll open it. Don’t get your panties in a twist!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:90
translate chinese SR2_swimming_card_label_e8a498fa:

    # Sara "(Ooh... That sounds kinda lewd...)"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:94
translate chinese SR2_swimming_card_label_29588c22:

    # MC "Oh! Swimming Pool VIP Cards! Awesome!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:95
translate chinese SR2_swimming_card_label_a439f99a:

    # Sara "Yeah. They let you-"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:96
translate chinese SR2_swimming_card_label_475f126b:

    # MC "Unlimited access, right?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:97
translate chinese SR2_swimming_card_label_ba22f5fe:

    # Sara "That’s right!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:98
translate chinese SR2_swimming_card_label_9bdb4c55:

    # MC "These must have cost you a fortune, Sara! Where did you get this kind of money?!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:102
translate chinese SR2_swimming_card_label_8c1fd2b8:

    # Sara "I’ve been saving up my allowance, that Dad gave me."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:104
translate chinese SR2_swimming_card_label_e368332e:

    # Sara "I’d been saving up spare cash for a few months now."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:106
translate chinese SR2_swimming_card_label_a3ac04ca:

    # Sara "I didn’t know what I actually wanted though - Until we started... seeing each other."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:107
translate chinese SR2_swimming_card_label_43160892:

    # Sara "[player_name], I want to go to the swimming pool with you on the weekends, if you’re free."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:108
translate chinese SR2_swimming_card_label_e6c35eb5:

    # Sara "That’s why I got two, so we could spend some time together."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:112
translate chinese SR2_swimming_card_label_dab06735:

    # MC "Aww, thank you so much, Sara. This is so thoughtful of you."
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:113
translate chinese SR2_swimming_card_label_e54e4d45:

    # MC "You keep this one, I’ll hold onto the other. Sometime, when we’re both free, we can organise, going to the pool together."
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:114
translate chinese SR2_swimming_card_label_c1d4ab17:

    # Sara "Really?!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:115
translate chinese SR2_swimming_card_label_63873555:

    # MC "Absolutely!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:119
translate chinese SR2_swimming_card_label_971906b2:

    # Sara "Thanks, [player_name]! You’re the best!"
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:120
translate chinese SR2_swimming_card_label_75673ca2:

    # Sara "I’m gonna head downstairs and grab breakfast. See you later, [player_name]."
    Sara ""

# game/scripts/home/mc_room/morning/scenes/SR2_swimming_card_label.rpy:121
translate chinese SR2_swimming_card_label_d1e18b33:

    # MC "Thanks again, Sara! Catch you later!"
    MC ""

