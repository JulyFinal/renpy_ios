﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:19
translate chinese sister_nerdy_scene4_v11_cc8ea887:

    # MC "(I already know who's there.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:23
translate chinese sister_nerdy_scene4_v11_5f49fb38:

    # MC "(I can't do it when someone is the kitchen.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:35
translate chinese sister_nerdy_scene4_v11_bd4eacfa:

    # MC "(Looks like I made it just in time.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:36
translate chinese sister_nerdy_scene4_v11_bd48d07d:

    # MC "(Hey, those are the panties I almost stole from her!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:37
translate chinese sister_nerdy_scene4_v11_7270c0e7:

    # MC "(She’s got a matching bra too - it must be a set she likes.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:38
translate chinese sister_nerdy_scene4_v11_8393317a:

    # MC "(Maybe tomorrow there will be a better view!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:58
translate chinese sister_nerdy_scene4_v11_06bb3b0b:

    # MC "(Mmm, even better this time! I get a front row seat to her naked ass!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:59
translate chinese sister_nerdy_scene4_v11_4cc1676c:

    # MC "(Damn, she has such sexy thighs too.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:60
translate chinese sister_nerdy_scene4_v11_586ec205:

    # MC "(I’d love to spread those cheeks and fuck her silly.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:61
translate chinese sister_nerdy_scene4_v11_38c8ffb3:

    # MC "(Let’s watch her again some other time.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:82
translate chinese sister_nerdy_scene4_v11_9a77299b:

    # MC "(Perfect timing! It looks like she’s just about to take a shower!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:83
translate chinese sister_nerdy_scene4_v11_93fd85ee:

    # MC "(I can almost see her pussy from this angle!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:85
translate chinese sister_nerdy_scene4_v11_d5788aaf:

    # MC "(Please, if there’s a God up there, I’m begging you! Let my sister bend over right now!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:87
translate chinese sister_nerdy_scene4_v11_0aeadce3:

    # MC "(Please, if there’s a God up there, I’m begging you! Let her bend over right now!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:90
translate chinese sister_nerdy_scene4_v11_bf08c1a8:

    # Sara "(Huh, looks like I missed a hair when I was shaving my legs.)"
    Sara ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:91
translate chinese sister_nerdy_scene4_v11_9b4e3fbc:

    # MC "(There is a God!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:92
translate chinese sister_nerdy_scene4_v11_c6d9d0c2:

    # MC "(Damn, she looks so tight! I would love to bury my cock in her cunt.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:93
translate chinese sister_nerdy_scene4_v11_d2a54f89:

    # MC "(It would feel fucking amazing!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:113
translate chinese sister_nerdy_scene4_v11_dce4b31f:

    # Sara "Ah! Ah... Ahh... Mmm... Ooh..."
    Sara ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:114
translate chinese sister_nerdy_scene4_v11_76fad9cd:

    # MC "(Just in time! Looks like she is masturbating!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:115
translate chinese sister_nerdy_scene4_v11_4b4e8dc1:

    # MC "(I wonder what she’s looking at on her phone. Could it be that picture of my cock?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:116
translate chinese sister_nerdy_scene4_v11_cd962bf8:

    # Sara "Ohh! [player_name]! Yes...!"
    Sara ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:118
translate chinese sister_nerdy_scene4_v11_5470c930:

    # MC "(She’ll need to be quieter than that, if she doesn’t want Mom to hear her!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:120
translate chinese sister_nerdy_scene4_v11_8b716537:

    # MC "(She’ll need to be quieter than that, if she doesn’t want Linda to hear her!)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:139
translate chinese sister_nerdy_scene4_v1_l_door_locked_cc8ea887:

    # MC "(I already know who's there.)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:142
translate chinese sister_nerdy_scene4_v1_l_door_locked_86942359:

    # MC "(It’s locked! I wonder who is there...?)"
    MC ""

# game/scripts/home/kitchen/morning/scenes/sara_scene4_v1.rpy:143
translate chinese sister_nerdy_scene4_v1_l_door_locked_33178a05:

    # MC "(If I only had some spy camera I could use it to see through the door!)"
    MC ""

