﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:11
translate chinese caroline_room_morning_scene3_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:21
translate chinese caroline_room_morning_scene3_label_7cb7a126:

    # MC "(Huh? What’s wrong with Caroline?)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:22
translate chinese caroline_room_morning_scene3_label_125e2543:

    # MC "(This isn’t like her at all. She’s usually such a happy upbeat person. I wonder what’s going on.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:24
translate chinese caroline_room_morning_scene3_label_e2303a44:

    # MC "(Even Mom’s gotten involved - this must be serious.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:26
translate chinese caroline_room_morning_scene3_label_5e793f4d:

    # MC "(Even Linda’s gotten involved - this must be serious.)"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:29
translate chinese caroline_room_morning_scene3_label_a1074600:

    # Mom "Listen, I can afford to delay your rent for a couple more months."
    Mom ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:31
translate chinese caroline_room_morning_scene3_label_61f64a16:

    # Mom "But after that, we’ll be relying, almost entirely on your father’s overtime, to make ends meet."
    Mom ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:33
translate chinese caroline_room_morning_scene3_label_ed69d7db:

    # Mom "But after that, we’ll be relying almost entirely on Bob’s overtime money to make ends meet."
    Mom ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:35
translate chinese caroline_room_morning_scene3_label_044d124b:

    # Caroline "I know. *Sniff* I’m sorry, Mom."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:37
translate chinese caroline_room_morning_scene3_label_08081e87:

    # Caroline "I know. *Sniff* I’m sorry Linda. I’ve never missed a rent payment in my life! It’s this damn business!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:38
translate chinese caroline_room_morning_scene3_label_4f2e41fb:

    # Caroline "I really thought this shop idea would work!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:42
translate chinese caroline_room_morning_scene3_label_8846ebde:

    # Mom "Perhaps you should consider cutting your losses? Your father might be able to get you a job in Risk Management at the firm?"
    Mom ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:44
translate chinese caroline_room_morning_scene3_label_8557291f:

    # Mom "Perhaps you should consider cutting your losses? Bob might be able to get you a job in risk management at the firm?"
    Mom ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:45
translate chinese caroline_room_morning_scene3_label_4d176f6e:

    # Caroline "God no! Trust me - I am going to fix this!"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:46
translate chinese caroline_room_morning_scene3_label_7c073f1d:

    # Caroline "I can’t do it on my own though. I’m gonna need some help to get things off the ground."
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:47
translate chinese caroline_room_morning_scene3_label_e5862af7:

    # Caroline "Do you think I could borrow [player_name], to help out at my shop a bit?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:48
translate chinese caroline_room_morning_scene3_label_6793980b:

    # Mom "Sure, as long as he doesn’t mind."
    Mom ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:51
translate chinese caroline_room_morning_scene3_label_46b93dbf:

    # Caroline "Would you be able to help me, [player_name]?"
    Caroline ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:52
translate chinese caroline_room_morning_scene3_label_650df3e5:

    # MC "What do you need me to do?"
    MC ""

# game/scripts/home/caroline_room/morning/scenes/caroline_room_morning_scene3.rpy:53
translate chinese caroline_room_morning_scene3_label_b46f7f3f:

    # Caroline "Just drop into my store some afternoon when you’re free. I’ll have everything ready to go."
    Caroline ""

