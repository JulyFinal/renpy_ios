﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:26
translate chinese CNS_wake_butt_label_659adba5:

    # MC "Do you think you could use your butt for a change?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:27
translate chinese CNS_wake_butt_label_7bce6311:

    # Caroline "My butt?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:28
translate chinese CNS_wake_butt_label_b656a1b5:

    # MC "Yeah, kinda like what you did with your thighs in your shop when you were wearing the White Princess outfit."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:33
translate chinese CNS_wake_butt_label_008164a6:

    # MC "The only difference is that my cock would be between your ass cheeks instead of your thighs."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:34
translate chinese CNS_wake_butt_label_8a125c45:

    # Caroline "Eh... I’m not sure."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:35
translate chinese CNS_wake_butt_label_43cff140:

    # MC "Pleeeeease! You’ll love it, I promise!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:36
translate chinese CNS_wake_butt_label_72c45449:

    # Caroline "You’re not going to go inside, are you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:40
translate chinese CNS_wake_butt_label_35ca97df:

    # MC "No! Definitely not!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:41
translate chinese CNS_wake_butt_label_d149f087:

    # Caroline "Hmm, yeah, I guess I could do that. It’s certainly not the weirdest request a guy has ever made of me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:42
translate chinese CNS_wake_butt_label_dd20cdd0:

    # MC "Great! Take off your panties. We’ll do it up against the wall."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:46
translate chinese CNS_wake_butt_label_1ba66374:

    # Caroline "Is this what you were thinking of?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:47
translate chinese CNS_wake_butt_label_cc33940d:

    # MC "Yeah, this is great. Just move your ass up and down now - it’ll be perfect."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:48
translate chinese CNS_wake_butt_label_e943397c:

    # Caroline "Can I actually get you to cum like this?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:52
translate chinese CNS_wake_butt_label_1bc379b2:

    # MC "Mmm... yeah, it shouldn’t be a problem. It feels great already!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:53
translate chinese CNS_wake_butt_label_463f8b2a:

    # Caroline "Hehe, really?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:54
translate chinese CNS_wake_butt_label_dfbf5d88:

    # Caroline "I never thought guys would be into something like this. But then again, guys are into EVERYTHING!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:58
translate chinese CNS_wake_butt_label_7d42ca06:

    # MC "Ah... Mmm... You’re making it sound like all guys are perverts!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:59
translate chinese CNS_wake_butt_label_7b8c57ef:

    # Caroline "If you’d met my ex, or any of the dozens of guys who tried hitting on me, you’d think so too."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:60
translate chinese CNS_wake_butt_label_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:64
translate chinese CNS_wake_butt_label_daea5906:

    # MC "Ugh... This is really good, Caroline. Thanks so much!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:65
translate chinese CNS_wake_butt_label_d47735aa:

    # Caroline "No need to thank me, I’m just glad you’re enjoying this!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:66
translate chinese CNS_wake_butt_label_646b75e6:

    # Caroline "Do you want me to go a bit faster, [player_name]?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:70
translate chinese CNS_wake_butt_label_c61d9be0:

    # MC "Mmm! Hnng... Ugh..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:71
translate chinese CNS_wake_butt_label_315ff0e0:

    # MC "That’s perfect, Caroline. Just keep going like that."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:72
translate chinese CNS_wake_butt_label_7d8eea9f:

    # Caroline "Give me a heads up before you cum, okay? I’m not a huge fan of sticky surprises."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:76
translate chinese CNS_wake_butt_label_829baee5:

    # MC "Ahh... I’ll try."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:78
translate chinese CNS_wake_butt_label_b8c7ce96:

    # MC "(Caroline’s ass feels amazing. It’s so warm and soft as it rubs up and down against my cock.)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:79
translate chinese CNS_wake_butt_label_dc8ae290:

    # Caroline "I bet you think of doing stuff like this to me when you’re wanking, don’t you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:83
translate chinese CNS_wake_butt_label_bd3c320e:

    # MC "Heh, you caught me. I do. Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:84
translate chinese CNS_wake_butt_label_b5c31ddc:

    # MC "(I also think about fucking your pussy. But I probably shouldn’t say that out loud!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:85
translate chinese CNS_wake_butt_label_c320b50b:

    # Caroline "*Pant* Are you close to cumming?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:89
translate chinese CNS_wake_butt_label_35c453fa:

    # MC "I’m getting there..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:91
translate chinese CNS_wake_butt_label_443078ee:

    # Caroline "Is there anything I can do to help you cum? Would it help if I talked dirty to you?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:92
translate chinese CNS_wake_butt_label_41be8207:

    # MC "Talked dirty?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:96
translate chinese CNS_wake_butt_label_be02600b:

    # Caroline "Uh huh. You’ve never had a girl speak dirty to you before?"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:97
translate chinese CNS_wake_butt_label_47b4c0c2:

    # MC "N-No?"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:98
translate chinese CNS_wake_butt_label_c10fab57:

    # Caroline "*Whispered* I want you to imagine me on top of you, slipping your cock inside my tight little asshole."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:102
translate chinese CNS_wake_butt_label_e2fd4b27:

    # Caroline "*Whispered* Imagine the feeling of it pressing against my hole while slowly slipping inside."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:103
translate chinese CNS_wake_butt_label_609dfd20:

    # MC "Ah... Fuck... Mmm..."
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:104
translate chinese CNS_wake_butt_label_4f9e35b0:

    # Caroline "*Whispered* And then, once you’re fully inside me, I’ll begin to bounce up and down. I’ll take the ENTIRE length of your cock deep inside me."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:108
translate chinese CNS_wake_butt_label_de053856:

    # MC "Oh! Oh... Fuck... Mmm...!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:109
translate chinese CNS_wake_butt_label_a30851a1:

    # Caroline "(Looks like my dirty talking worked! I can feel him beginning to twitch!)"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:111
translate chinese CNS_wake_butt_label_f94f2d2b:

    # Caroline "That’s it... cum for your big sister. Cum for me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:113
translate chinese CNS_wake_butt_label_8c724ef5:

    # Caroline "That’s it... cum for your best friend! Cum for me!"
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:116
translate chinese CNS_wake_butt_label_ae07a893:

    # MC "Ohh! Hnnng! UGH! Ahhh!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:117
translate chinese CNS_wake_butt_label_ac2b9dd4:

    # Caroline "*Whispered* Imagine yourself blowing a load deep into my pretty little ass."
    Caroline ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:118
translate chinese CNS_wake_butt_label_60ba3287:

    # MC "Hnnnnngggg! AHHHHHH!!!"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:129
translate chinese CNS_wake_butt_label_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:132
translate chinese CNS_wake_butt_label_bf372b0e:

    # MC "Wow... (The dirty talking REALLY helped there!)"
    MC ""

# game/scripts/home/caroline_room/night/scenes/NSB/CNS_wake_butt.rpy:133
translate chinese CNS_wake_butt_label_6d3147e2:

    # Caroline "Hehe, it seemed like you really enjoyed it. I’ll try and remember that you really like asses, for the future!"
    Caroline ""

