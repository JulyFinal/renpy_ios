﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:23
translate chinese CR3_MS2_label_a64ce99b:

    # Caroline "One... Two... Three..."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:24
translate chinese CR3_MS2_label_3df20cc3:

    # MC "(It looks like Caroline is stretching. She must be going out for some exercise!)"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:25
translate chinese CR3_MS2_label_9b70e4ce:

    # MC "Hey Caroline, what’s up?"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:29
translate chinese CR3_MS2_label_2df45f3e:

    # Caroline "Hi, [player_name]! Two seconds!"
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:30
translate chinese CR3_MS2_label_286e3c86:

    # Caroline "Four... Five... Six!"
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:31
translate chinese CR3_MS2_label_e424e5ee:

    # Caroline "Sorry about that. I just wanted to finish, stretching out my calves."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:34
translate chinese CR3_MS2_label_37a1120f:

    # MC "Are you heading off to the gym?"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:35
translate chinese CR3_MS2_label_f62c407d:

    # Caroline "Not today! The weather is great, so I’m going to jog in - the great outdoors. A couple of laps around the block ought to do me."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:36
translate chinese CR3_MS2_label_b6ac33d7:

    # MC "Any particular reason?"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:40
translate chinese CR3_MS2_label_3b023be5:

    # Caroline "Yeah, I mostly run to clear my head. My brain’s fried, after that damn tax return I had to submit. Plus, I’m trying to get myself in shape."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:41
translate chinese CR3_MS2_label_0667da0a:

    # MC "Are you serious? You’re in great shape already!"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:42
translate chinese CR3_MS2_label_675aad66:

    # Caroline "I thought I was too - but this new batch of clothes I ordered are a size too small for me. I’m gonna have to tone myself up, here."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:46
translate chinese CR3_MS2_label_d5eeb4b4:

    # MC "Cool! If you wait five minutes, I could grab my tracksuit and join you!"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:47
translate chinese CR3_MS2_label_0107e9dc:

    # Caroline "Sorry, [player_name]. This is something I prefer to do on my own. It’s ‘me time’."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:48
translate chinese CR3_MS2_label_41ed6968:

    # MC "Oh, okay..."
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:52
translate chinese CR3_MS2_label_06181694:

    # Caroline "What’s wrong? You’re looking downhearted, all of a sudden."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:53
translate chinese CR3_MS2_label_ce3f6bc0:

    # MC "It’s just... It’s nothing."
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:54
translate chinese CR3_MS2_label_df6b71a2:

    # Caroline "Aww c’mon - you can tell ME."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:58
translate chinese CR3_MS2_label_56071fad:

    # MC "It just, kinda feels that you’re avoiding me - ever since this deal ended. I mean, we used to hang out more than this, right?"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:59
translate chinese CR3_MS2_label_2cc70eb5:

    # Caroline "*Sigh*"
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:60
translate chinese CR3_MS2_label_10cf7e8c:

    # Caroline "How often did we hang out before the deal?"
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:61
translate chinese CR3_MS2_label_9c01bff3:

    # MC "I uh... I don’t remember."
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:62
translate chinese CR3_MS2_label_7b955829:

    # Caroline "Let me remind you, We - almost NEVER - hung out. Then, once this deal came into place, we were seeing each other all the time."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:66
translate chinese CR3_MS2_label_20608a6a:

    # Caroline "We can work out a healthy balance, but as of now, I’m your sister, NOT your girlfriend."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:68
translate chinese CR3_MS2_label_40f30086:

    # Caroline "We can work out a healthy balance, but as of now, I’m your friend, not your GIRLfriend."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:69
translate chinese CR3_MS2_label_3311c13c:

    # MC "...You were never my girlfriend. It was just a-"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:70
translate chinese CR3_MS2_label_81a8f0b0:

    # Caroline "-I know exactly what it was. There’s no need to rehash it. Can’t we just bury this, and move on?"
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:75
translate chinese CR3_MS2_label_37baebf2:

    # MC "How can you expect me to just, bury and forget, after everything that we did together?"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:76
translate chinese CR3_MS2_label_a64ce99b_1:

    # Caroline "One... Two... Three..."
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:77
translate chinese CR3_MS2_label_b82866b3:

    # MC "(Dammit...! She’s stretching again.)"
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:81
translate chinese CR3_MS2_label_2dea8104:

    # Caroline "Okay. Gotta go! There ain’t no way I’m getting into those outfits if I don’t get started today!"
    Caroline ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:82
translate chinese CR3_MS2_label_453bbeb3:

    # MC "*Sigh* See you later, Caroline."
    MC ""

# game/scripts/home/entrace1/M/scenes/CR3_MS2.rpy:83
translate chinese CR3_MS2_label_718361c3:

    # MC "(What has gotten into her? Why has she had, such a sudden change of heart, about our deal.)"
    MC ""

