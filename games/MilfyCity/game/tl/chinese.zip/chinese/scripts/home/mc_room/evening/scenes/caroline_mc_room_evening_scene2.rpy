﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:15
translate chinese caroline_mc_room_evening_scene2_label_639b771b:

    # MC "Caroline? I- I’m sorry about earlier today."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:16
translate chinese caroline_mc_room_evening_scene2_label_58705159:

    # MC "I’ll make it up to you, I swear. If you just let me-"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:17
translate chinese caroline_mc_room_evening_scene2_label_7fa0bcb8:

    # Caroline "Shush."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:20
translate chinese caroline_mc_room_evening_scene2_label_ba9b4adb:

    # Caroline "I’m the one who should be apologising. I completely overreacted."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:21
translate chinese caroline_mc_room_evening_scene2_label_a75ed757:

    # MC "Y-You did?"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:22
translate chinese caroline_mc_room_evening_scene2_label_22097a62:

    # Caroline "It’s completely normal - and probably even healthy - for a guy your age."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:23
translate chinese caroline_mc_room_evening_scene2_label_e0223f93:

    # Caroline "And to be fair, my outfit wasn’t leaving a lot to the imagination."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:24
translate chinese caroline_mc_room_evening_scene2_label_90e78139:

    # MC "(Yeah, she’s right, there!)"
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:27
translate chinese caroline_mc_room_evening_scene2_label_9e706f88:

    # Caroline "So, I’m sorry, [player_name]. Are we cool?"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:28
translate chinese caroline_mc_room_evening_scene2_label_682fd291:

    # MC "Yeah, we’re cool."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:29
translate chinese caroline_mc_room_evening_scene2_label_828a132f:

    # MC "And for the record... I’m sorry too."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:30
translate chinese caroline_mc_room_evening_scene2_label_142cadda:

    # Caroline "Oh! Before I forget - I’m planning a little surprise, to make it up to you."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:33
translate chinese caroline_mc_room_evening_scene2_label_d756c601:

    # MC "Aww, you don’t have to do that."
    MC ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:34
translate chinese caroline_mc_room_evening_scene2_label_8cee5fb1:

    # Caroline "Trust me. I think you’ll enjoy it!"
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:35
translate chinese caroline_mc_room_evening_scene2_label_d1f894e2:

    # Caroline "Catch you later, [player_name]."
    Caroline ""

# game/scripts/home/mc_room/evening/scenes/caroline_mc_room_evening_scene2.rpy:36
translate chinese caroline_mc_room_evening_scene2_label_3f624e1f:

    # MC "See ya, Caroline!"
    MC ""

