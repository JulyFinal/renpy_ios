﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:24
translate chinese MLR3_ES1_6ea055f1:

    # MC "(I've already talked with them.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:40
translate chinese MLR3_ES1_d07750d7:

    # MC "(Huh, looks like [Mom_name] and Sara are hanging out. I’ve never seen them do much mother-daughter stuff together.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:42
translate chinese MLR3_ES1_09a8a67c:

    # MC "(Huh, looks like Linda and Sara are hanging out. The two of them have started growing closer in recent weeks.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:43
translate chinese MLR3_ES1_c6d1295c:

    # MC "(I wonder what they’re up to.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:44
translate chinese MLR3_ES1_7c0f8158:

    # Mom "I'm so happy that you want to do dinner tonight, Sara."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:48
translate chinese MLR3_ES1_3399b5de:

    # Sara "Thank you, Linda. I mostly play computer games, so I thought it would be a good idea to work on improving my cooking skills."
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:49
translate chinese MLR3_ES1_39b3d1ff:

    # Mom "Yes, I'm glad you made that decision. The computer is consuming much more of your time than it should."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:50
translate chinese MLR3_ES1_a1f184e9:

    # "*CLICK*"
    ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:54
translate chinese MLR3_ES1_7f0bee21:

    # Mom "Alright, let's begin cooking. We'll start with the vegetables."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:56
translate chinese MLR3_ES1_dbf46562:

    # MC "(They're cooking together?)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:57
translate chinese MLR3_ES1_cde12c8a:

    # MC "(Perhaps [Mom_name] is trying to get closer to Sara.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:59
translate chinese MLR3_ES1_dbf46562_1:

    # MC "(They're cooking together?)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:60
translate chinese MLR3_ES1_077169b7:

    # MC "(Perhaps Linda is trying to get closer to Sara.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:61
translate chinese MLR3_ES1_e5228e51:

    # Mom "Oh! Hey, [player_name]. We've just begun preparing dinner. Would you like to join us?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:62
translate chinese MLR3_ES1_dc1078de:

    # MC "I’m okay, I was just passing by."
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:63
translate chinese MLR3_ES1_c2f5e7e5:

    # MC "How’s it going, Sara? You haven’t burnt anything yet, have you?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:66
translate chinese MLR3_ES1_6a166d0c:

    # Sara "Oh, HA HA! Very funny."
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:68
translate chinese MLR3_ES1_d83c186e:

    # Mom "[player_name] - stop teasing your sister! Apologize to her now."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:70
translate chinese MLR3_ES1_2dab4cd4:

    # Mom "[player_name] - stop teasing her! Apologize to her now."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:72
translate chinese MLR3_ES1_1eb796db:

    # MC "Sorry, Sara."
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:73
translate chinese MLR3_ES1_83d3063f:

    # Mom "Although, to be fair..."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:77
translate chinese MLR3_ES1_675c8245:

    # Mom "...she DID burn the bacon. "
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:78
translate chinese MLR3_ES1_1a1ed21b:

    # MC "Ahaha! Really?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:79
translate chinese MLR3_ES1_e82b4b96:

    # Sara "It wasn’t my fault... the oven was too hot!"
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:83
translate chinese MLR3_ES1_2d8c447f:

    # Mom "Someone got centigrade and fahrenheit mixed up when they were reading the cookbook. I had to chuck the bacon in the bin. It was blacker than tar and tougher than a hockey puck."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:84
translate chinese MLR3_ES1_688b704c:

    # MC "Ahh, so THAT’S what the awful smell is in here!"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:85
translate chinese MLR3_ES1_1ab856fb:

    # Sara "Hmmph... Why do we need centigrade AND fahrenheit? If there was only one, I wouldn't get all confused..."
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:86
translate chinese MLR3_ES1_08144300:

    # Mom "Haha, don’t worry, Dear. It’s better that this happens, when I’m around to help you fix things. Now, let’s get back on track."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:90
translate chinese MLR3_ES1_8a2f9244:

    # MC "(I suppose it’s good to see [Mom_name] and Sara spending some quality time together.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:91
translate chinese MLR3_ES1_b55bce9d:

    # Sara "Anyway, I better get back to this, before I destroy a second dinner!"
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:92
translate chinese MLR3_ES1_5f30580c:

    # Mom "Haha, at least you’re keeping positive about it. Check if the water is boiling in the pot yet."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:96
translate chinese MLR3_ES1_3ceea14e:

    # Sara "Sure, [Mom_name]!"
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:97
translate chinese MLR3_ES1_3ad8f11e:

    # Mom "So, what are you up to now? Big plans for this evening?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:98
translate chinese MLR3_ES1_196d66d7:

    # MC "Nothing much, I was just going to-"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:99
translate chinese MLR3_ES1_9e319961:

    # "*THUNK*"
    ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:103
translate chinese MLR3_ES1_1207ee4a:

    # Sara "Eek!"
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:104
translate chinese MLR3_ES1_785b5263:

    # Mom "Are you alright, Sara?"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:105
translate chinese MLR3_ES1_15e7b101:

    # Sara "Oops! Sorry, I knocked over a can with my elbow."
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:109
translate chinese MLR3_ES1_de7ea1b2:

    # MC "Don’t worry about it. I’ll grab that for you."
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:110
translate chinese MLR3_ES1_20c99fa3:

    # Sara "Thanks, [player_name]!"
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:114
translate chinese MLR3_ES1_919d8e64:

    # MC "(Hmm, Sara is wearing a REALLY short skirt today. I could try and peek up it while I’m down here.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:115
translate chinese MLR3_ES1_d243e7c6:

    # MC "(It’s not like either of them would notice - they’re both FAR too focused on their cooking!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:119
translate chinese MLR3_ES1_411cb9d5:

    # MC "(Oh yeah! Her panties are so slim I can almost see her vulva on either side of them.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:120
translate chinese MLR3_ES1_b1109f1e:

    # MC "(It’s a shame Sara never goes commando, or I would have hit the jackpot right now.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:124
translate chinese MLR3_ES1_43aa5819:

    # MC "(Oh fuck! There’s no way she saw me peeking up my sister’s skirt? Right?!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:126
translate chinese MLR3_ES1_2ffec5e0:

    # MC "(Oh fuck! There’s no way she saw me peeking up Sara's skirt? Right?!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:128
translate chinese MLR3_ES1_dd11370b:

    # MC "(Fuck... she looks shocked! There’s no doubt about it - she’s caught me. I am SO screwed...)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:129
translate chinese MLR3_ES1_81dc4851:

    # Mom "(Huh... I’m almost certain I caught [player_name] looking up Sara’s skirt. It was a little difficult to tell though.)"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:135
translate chinese MLR3_ES1_ecc84782:

    # Mom "(Let’s put this to the test, and see if he’s interested in her.)"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:136
translate chinese MLR3_ES1_d07d4015:

    # MC "(Holy shit! [Mom_name]’s holding Sara’s skirt up! No way!)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:137
translate chinese MLR3_ES1_29a3bd3c:

    # Sara "Ahh! It’s all bubbling out of the pot!"
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:138
translate chinese MLR3_ES1_5ad43641:

    # Mom "Easy, Dear. You just need to turn the heat down, a little."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:142
translate chinese MLR3_ES1_f120e2b6:

    # MC "Where do you want this can put, Sara?"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:143
translate chinese MLR3_ES1_3e4d4924:

    # Sara "Oh! I forgot about that! Umm... just pass it to me. I’ll be using it now, anyway."
    Sara ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:144
translate chinese MLR3_ES1_da320624:

    # MC "Sure thing."
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:149
translate chinese MLR3_ES1_13aaa039:

    # Mom "(My, my, my... I knew my boy was a horny guy, but I never imagined he’d be so bold, as to lust after his own sister.)"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:151
translate chinese MLR3_ES1_fda0c51b:

    # Mom "(My, my, my... I knew [player_name] was a horny guy, but I never imagined he’d be so bold as to lust after Sara too.)"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:152
translate chinese MLR3_ES1_400ccc09:

    # Mom "(Then again, I’d be a hypocrite to say anything on the subject.)"
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:154
translate chinese MLR3_ES1_4a53fb5a:

    # Mom "See you later, [player_name]. I hope you enjoyed watching your sister... cook."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:156
translate chinese MLR3_ES1_258329d7:

    # Mom "See you later, [player_name]. I hope you enjoyed watching Sara... cook."
    Mom ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:157
translate chinese MLR3_ES1_adf7f83a:

    # MC "(She paused in that sentence on purpose! She definitely knows I was looking - but I don’t think she’s actually angry about it.)"
    MC ""

# game/scripts/home/kitchen/evening/scenes/MLR3_ES1.rpy:158
translate chinese MLR3_ES1_e27c7e3a:

    # MC "Y-Yeah, see you later, [Mom_name]."
    MC ""

