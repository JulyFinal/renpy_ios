﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:37
translate chinese ML_NS_sleep_foot_job_label_36b32c14:

    # MC "Can we try something a little different tonight, [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:39
translate chinese ML_NS_sleep_foot_job_label_654feac5:

    # Mom "Sure. As long as it isn’t something that’s gonna make me squeal and moan. I don’t want to wake your father up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:41
translate chinese ML_NS_sleep_foot_job_label_d360f513:

    # Mom "Sure, as long as it isn’t something that’s gonna make me squeal and moan. I don’t want to wake my husband up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:42
translate chinese ML_NS_sleep_foot_job_label_272db624:

    # MC "Don’t worry, we won’t be loud."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:46
translate chinese ML_NS_sleep_foot_job_label_42113e18:

    # MC "I want you to use your feet on my cock tonight."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:47
translate chinese ML_NS_sleep_foot_job_label_e7254e6f:

    # Mom "Mmm, very naughty. I like it."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:48
translate chinese ML_NS_sleep_foot_job_label_6bdecde4:

    # MC "God, your soles are so soft..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:52
translate chinese ML_NS_sleep_foot_job_label_ebd07636:

    # Mom "Most people don’t take proper care of their feet. All I do is wear proper shoes and moisturise daily"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:53
translate chinese ML_NS_sleep_foot_job_label_28369a02:

    # Mom "Hehe, you’re really having fun playing with them, aren’t you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:54
translate chinese ML_NS_sleep_foot_job_label_6bf29844:

    # MC "I can’t wait to feel these rubbing up against my cock."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:58
translate chinese ML_NS_sleep_foot_job_label_6f30f769:

    # Mom "Hmm... You’ve had a footjob before, haven’t you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:59
translate chinese ML_NS_sleep_foot_job_label_be551ec5:

    # MC "Yeah, you gave me one a while back."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:60
translate chinese ML_NS_sleep_foot_job_label_efe5707e:

    # Mom "There’s no reason for us to keep things vanilla, then. Let’s spice it up a bit."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:64
translate chinese ML_NS_sleep_foot_job_label_10f7a572:

    # Dad "Zzz..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:65
translate chinese ML_NS_sleep_foot_job_label_fe0ce194:

    # MC "Where are you going?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:66
translate chinese ML_NS_sleep_foot_job_label_5da32f5f:

    # Mom "I’ll be back in a minute. I have a surprise for you... which I think you are going to adore."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:70
translate chinese ML_NS_sleep_foot_job_label_95e4618f:

    # Mom "Ahh, thank goodness. I was worried that I didn’t have a clean pair."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:71
translate chinese ML_NS_sleep_foot_job_label_194bc632:

    # MC "Pair of what, [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:72
translate chinese ML_NS_sleep_foot_job_label_966654c0:

    # Mom "(These will do nicely! I hope [player_name] is into these, because they’re a real bitch to put on!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:76
translate chinese ML_NS_sleep_foot_job_label_68676e9d:

    # MC "You look really hot in those stockings, [Mom_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:77
translate chinese ML_NS_sleep_foot_job_label_3b9ca467:

    # Mom "These aren't just any old stockings, [player_name]. I bought these from France last year. The customs charge on them was painful, but you don’t get quality like that in this country."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:78
translate chinese ML_NS_sleep_foot_job_label_72e02a23:

    # Mom "These are the smoothest silk stockings you’ll ever feel - and they’re going to be caressing all over your rock hard cock."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:82
translate chinese ML_NS_sleep_foot_job_label_e871c597:

    # Dad "*Snore*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:83
translate chinese ML_NS_sleep_foot_job_label_2ebd6eaf:

    # MC "([Dad_name] seems to be fast asleep, still. As long as we keep our voices low, he probably won’t wake up!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:84
translate chinese ML_NS_sleep_foot_job_label_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:88
translate chinese ML_NS_sleep_foot_job_label_49a4beb1:

    # MC "I love them. You really should wear those more often. They’d look great with a miniskirt on."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:89
translate chinese ML_NS_sleep_foot_job_label_f2ba3fa5:

    # Mom "Mmm... A miniskirt with no panties underneath? That could make a fun future date together."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:90
translate chinese ML_NS_sleep_foot_job_label_2d9b9b78:

    # MC "I like how you think!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:94
translate chinese ML_NS_sleep_foot_job_label_65ccb6d5:

    # Mom "Now, when I start rubbing my feet all over your cock, it’s going to get very sensitive, very quickly. I need you to promise me that you’re not just going to blow your load straight away."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:95
translate chinese ML_NS_sleep_foot_job_label_33922dde:

    # MC "Pfft! When have I EVER done that?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:97
translate chinese ML_NS_sleep_foot_job_label_3dc01b21:

    # Mom "Fair enough - but I’m also gonna need you to keep your voice down, so we don’t wake your father up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:99
translate chinese ML_NS_sleep_foot_job_label_81d4dd15:

    # Mom "Fair enough - but I’m also gonna need you to keep your voice down, so we don’t wake Bob up."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:103
translate chinese ML_NS_sleep_foot_job_label_619ab6ef:

    # MC "Easy peasy. Let’s get started. I’m already hard for you."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:104
translate chinese ML_NS_sleep_foot_job_label_112ac334:

    # Mom "Hehe, someone’s eager. Okay, let’s get this show on the road."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:108
translate chinese ML_NS_sleep_foot_job_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:110
translate chinese ML_NS_sleep_foot_job_label_74cbfafc:

    # MC "(God, that feels so soft against my dick. [Mom_name] was right about these stockings. They’re incredible!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:112
translate chinese ML_NS_sleep_foot_job_label_f53f86e0:

    # MC "(God, that feels so soft against my dick. She was right about these stockings. They’re incredible!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:113
translate chinese ML_NS_sleep_foot_job_label_846ab86b:

    # Mom "I’m gonna start off slowly, just massaging my foot up and down your shaft."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:117
translate chinese ML_NS_sleep_foot_job_label_f7c911da:

    # Mom "We’ll speed things up a bit, but just enjoy it for now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:118
translate chinese ML_NS_sleep_foot_job_label_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:119
translate chinese ML_NS_sleep_foot_job_label_db74c9cb:

    # Mom "Does that feel good for you?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:124
translate chinese ML_NS_sleep_foot_job_label_df93751a:

    # MC "Uh huh... so good, [Mom_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:125
translate chinese ML_NS_sleep_foot_job_label_0ddbd6b1:

    # Mom "I’m glad you like it. Let’s switch up positions, so I can use both feet on you at the same time."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:126
translate chinese ML_NS_sleep_foot_job_label_a8a70b38:

    # MC "Do you want me to move?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:127
translate chinese ML_NS_sleep_foot_job_label_280cabdc:

    # Mom "No, just sit right there. I’ll lie down beside you."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:131
translate chinese ML_NS_sleep_foot_job_label_d6bce4ea:

    # Mom "There we go - that’s MUCH better. Let’s get my feet wrapped around that cock of yours now."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:132
translate chinese ML_NS_sleep_foot_job_label_a4cef647:

    # MC "(I can see [Mom_name]’s pussy from this angle - she has such a sexy body.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:133
translate chinese ML_NS_sleep_foot_job_label_285515a8:

    # Mom "Hehe, you’re staring, [player_name]. See something you like?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:137
translate chinese ML_NS_sleep_foot_job_label_247fc4dd:

    # MC "Honestly? Every single inch of you looks fucking amazing."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:139
translate chinese ML_NS_sleep_foot_job_label_aef34f99:

    # Mom "Aww, you’re very sweet. How does this feel? Do you want me to go faster?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:140
translate chinese ML_NS_sleep_foot_job_label_ebb717fe:

    # MC "Could you speed up just a bit?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:144
translate chinese ML_NS_sleep_foot_job_label_d813b4fc:

    # MC "Oh yeah, that’s perfect now. Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:145
translate chinese ML_NS_sleep_foot_job_label_e871c597_1:

    # Dad "*Snore*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:146
translate chinese ML_NS_sleep_foot_job_label_30b23d0c:

    # Mom "(I can feel his cock twitching against my sole. This must be extremely pleasurable for him.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:150
translate chinese ML_NS_sleep_foot_job_label_0d323b3b:

    # MC "Oh God... Mmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:152
translate chinese ML_NS_sleep_foot_job_label_3008810b:

    # MC "Fuck... Ah..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:153
translate chinese ML_NS_sleep_foot_job_label_496a796c:

    # Mom "Remember to keep your voice down, Sweetie. If we get caught, then this is all over."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:157
translate chinese ML_NS_sleep_foot_job_label_f673f147:

    # Mom "Unless you can very quickly think of a very good reason why Mommy is massaging her son’s cock with her feet, in the middle of the night?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:159
translate chinese ML_NS_sleep_foot_job_label_5b96c27a:

    # Mom "Unless you can very quickly think of a very good reason why your landlady is massaging her tenant’s cock with her feet in the middle of the night?"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:160
translate chinese ML_NS_sleep_foot_job_label_1216288e:

    # MC "Ugh... Oh... Y-Yeah, I don’t think I could lie my way out of that one. I’ll keep my voice down."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:161
translate chinese ML_NS_sleep_foot_job_label_a910f6bd:

    # Mom "Heh, I thought so."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:165
translate chinese ML_NS_sleep_foot_job_label_4930441c:

    # Mom "Give me a heads-up before you cum."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:166
translate chinese ML_NS_sleep_foot_job_label_94b3818f:

    # MC "Mmm... uh huh... Is it okay if I accidentally cum on your stockings?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:167
translate chinese ML_NS_sleep_foot_job_label_430614f8:

    # Mom "You can cum on them if you want to. They’re just clothes - I can always wash them."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:171
translate chinese ML_NS_sleep_foot_job_label_bbf58074:

    # MC "Ah... sweet. Thanks, [Mom_name]. Ohh... fuck..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:174
translate chinese ML_NS_sleep_foot_job_label_1459a487:

    # MC "(Her soft silk stockings are heavenly. I almost climax, each time her toes curl over the tip of my cock. [Mom_name] certainly knows her stuff, when it comes to sex! This was a great idea!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:176
translate chinese ML_NS_sleep_foot_job_label_3296246c:

    # MC "(Her soft silk stockings are heavenly. I almost climax each time her toes curl over the tip of my cock. She certainly knows her stuff when it comes to sex! This was a great idea!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:177
translate chinese ML_NS_sleep_foot_job_label_e47743ab:

    # Mom "(I love having him at my mercy like this. It’s so much fun, knowing that a man has put himself in such a vulnerable position. I have complete control over his pleasure right now.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:181
translate chinese ML_NS_sleep_foot_job_label_8d214981:

    # Mom "(If I wanted to, I could speed things up and make him ejaculate. Or I could even just pause or stop.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:182
translate chinese ML_NS_sleep_foot_job_label_f936268a:

    # MC "Oh [Mom_name]... I’m getting close. Fuck... I’m so close right now..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:184
translate chinese ML_NS_sleep_foot_job_label_1776bc72:

    # Mom "That’s it... Just relax and enjoy Mommy rubbing her feet over your cock."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:186
translate chinese ML_NS_sleep_foot_job_label_6fa594f7:

    # Mom "That’s it... Just relax and enjoy me rubbing my feet over your cock."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:190
translate chinese ML_NS_sleep_foot_job_label_da037344:

    # MC "Hnnnng... Uh! Ahh..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:191
translate chinese ML_NS_sleep_foot_job_label_f690e6b5:

    # MC "(This feels so fucking good!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:194
translate chinese ML_NS_sleep_foot_job_label_f713f945:

    # Mom "(I can feel his cock pulsating between my feet. It seems like he’s about to cum. I knew he wouldn’t last long, with these stockings on!)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:205
translate chinese ML_NS_sleep_foot_job_label_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:206
translate chinese ML_NS_sleep_foot_job_label_7eef9385:

    # MC "Wow... that was... *pant* ...amazing."
    MC ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:207
translate chinese ML_NS_sleep_foot_job_label_998a26f8:

    # Mom "Hehe, take a minute to catch your breath before you go. I don’t want you bumping into Caroline or Sara when you are returning to your room."
    Mom ""

# game/scripts/home/ml_and_f_bedroom/night/scenes/NSB/ML_NS_sleep_foot_job.rpy:208
translate chinese ML_NS_sleep_foot_job_label_a107e307:

    # MC "*Phew* Good point... Thanks, [Mom_name]. That was amazing. Great idea, with the stockings."
    MC ""

