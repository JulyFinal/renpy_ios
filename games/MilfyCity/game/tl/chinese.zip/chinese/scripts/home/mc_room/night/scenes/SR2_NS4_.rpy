﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:79
translate chinese SR2_NS4_label_382bb2dd:

    # MC "(Sara is still looking especially nervous. The whole, painful sex on the roof, must have really gotten to her.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:80
translate chinese SR2_NS4_label_22ea7ceb:

    # MC "(I’ll have to tread carefully and take things slowly. I don’t want to hurt her again.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:82
translate chinese SR2_NS4_label_c203311f:

    # MC "(Sara is still looking especially nervous. The whole, sex on the roof, must have really gotten to her.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:83
translate chinese SR2_NS4_label_2165986d:

    # MC "(I’ll have to tread carefully and take things slowly. I want it to be pleasant for her too!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:84
translate chinese SR2_NS4_label_89f52b5b:

    # MC "Hey, Sara. Thanks for coming over."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:88
translate chinese SR2_NS4_label_3cd94aeb:

    # Sara "N-No problem. I love sneaking over to see you."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:89
translate chinese SR2_NS4_label_d33b02c9:

    # MC "You’re still scared about the anal thing, aren’t you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:91
translate chinese SR2_NS4_label_f42163ca:

    # Sara "N-No problem. I love coming over to see you."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:92
translate chinese SR2_NS4_label_2a44698f:

    # MC "You’re still concerned about the anal thing, aren’t you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:93
translate chinese SR2_NS4_label_8881bf12:

    # Sara "Just a little bit, yeah."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:94
translate chinese SR2_NS4_label_8402f18c:

    # MC "A little bit?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:96
translate chinese SR2_NS4_label_47c0d22f:

    # Sara "Okay, that was a lie. I’m, like, REALLY scared."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:98
translate chinese SR2_NS4_label_742250b5:

    # Sara "Okay, that was a lie. I’m, like, REALLY confused."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:102
translate chinese SR2_NS4_label_c772a71a:

    # MC "Just try to relax, Sara. I’ve said this already, and I’m sure you’re sick of hearing me repeat myself..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:103
translate chinese SR2_NS4_label_15ffaa60:

    # MC "...but we’re going to take this nice and slow. If you need me to stop or it hurts too much, just say."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:104
translate chinese SR2_NS4_label_a2aeaf58:

    # Sara "I will."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:105
translate chinese SR2_NS4_label_bb3ff7ab:

    # MC "I promise you, the lube will make things MUCH easier."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:106
translate chinese SR2_NS4_label_04e8880b:

    # Sara "It’d be easier if I could just relax a bit too."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:110
translate chinese SR2_NS4_label_f2e718f7:

    # MC "Is there anything I can do to help you relax?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:111
translate chinese SR2_NS4_label_4896cd33:

    # Sara "(If he told me that he loves me and that I was his girlfriend it would certainly help.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:112
translate chinese SR2_NS4_label_b092e0f8:

    # Sara "(I don’t want to press the topic on him again. He seemed hesitant to answer last time, and I don’t want to drive him away.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:113
translate chinese SR2_NS4_label_2b4ef9d5:

    # Sara "N-No, let’s just get started."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:117
translate chinese SR2_NS4_label_ff536593:

    # MC "(She’s shaking slightly. I have to try and calm her down.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:118
translate chinese SR2_NS4_label_f3556577:

    # MC "(Starting off with a kiss isn’t a bad idea.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:119
translate chinese SR2_NS4_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:123
translate chinese SR2_NS4_label_8bf799d1:

    # Sara "(God... It’s like an electric current, zapping through my body, every time he kisses me.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:125
translate chinese SR2_NS4_label_98343c3a:

    # Sara "(I thought it would pass, after the novelty of our first kiss... but the feeling hasn’t ever faded.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:126
translate chinese SR2_NS4_label_1ce29e7c:

    # Sara "(It’s a strange sensation, but it leaves me melting in his arms. I love it when he holds me, just like this.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:130
translate chinese SR2_NS4_label_312847cd:

    # MC "Mmm...."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:131
translate chinese SR2_NS4_label_1f793de6:

    # Sara "Mmm!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:132
translate chinese SR2_NS4_label_cf12e919:

    # Sara "(I love you, [player_name]. There isn’t a girl in the whole damn world as lucky as ME right now.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:136
translate chinese SR2_NS4_label_3581212e:

    # MC "I bet I can guess what you’re thinking."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:137
translate chinese SR2_NS4_label_5d2d42da:

    # Sara "Haha! Oh really?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:138
translate chinese SR2_NS4_label_de40568f:

    # MC "You’re thinking, how did I ever get so lucky to date such a hot and handsome guy?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:139
translate chinese SR2_NS4_label_7f4d5ca4:

    # Sara "Haha! You’re REALLY overconfident, you know that?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:143
translate chinese SR2_NS4_label_315ab6c0:

    # MC "Do you want to know what I was thinking?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:144
translate chinese SR2_NS4_label_7e55cd43:

    # Sara "Yeah, tell me."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:145
translate chinese SR2_NS4_label_fb29699d:

    # MC "Just how much I love you."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:149
translate chinese SR2_NS4_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:151
translate chinese SR2_NS4_label_5f2ec5ea:

    # Sara "(I’m so close to just giving... everything to him right now.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:152
translate chinese SR2_NS4_label_12224535:

    # Sara "(Does he even know how good he makes me feel?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:157
translate chinese SR2_NS4_label_b69d6024:

    # Sara "Wow... That was amazing!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:158
translate chinese SR2_NS4_label_51116ec2:

    # MC "Am I a good kisser?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:159
translate chinese SR2_NS4_label_95abac24:

    # Sara "You’re the best I’ve ever kissed."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:160
translate chinese SR2_NS4_label_6d0d0adf:

    # MC "Wait - I’m the ONLY guy you’ve ever kissed!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:161
translate chinese SR2_NS4_label_65b119b7:

    # Sara "Hehe! Okay, I’m gonna strip down for you now."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:165
translate chinese SR2_NS4_label_acc7d400:

    # Sara "(Damn... My nerves are starting to kick off again. I shouldn’t be so scared about this.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:166
translate chinese SR2_NS4_label_c5462963:

    # Sara "(I mean, I’ve already done it before! And this time it should be easier - we have the lube, after all.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:168
translate chinese SR2_NS4_label_70564cd8:

    # Sara "(Damn... I'm having butterflies in my tummy again! I can't believe I'm so nervous about this!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:170
translate chinese SR2_NS4_label_30c910c5:

    # MC "(I get so hard every time I see her perky tits. They’re unbelievable!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:175
translate chinese SR2_NS4_label_a26130a2:

    # MC "(And that ass is just stunning! I can’t wait to fuck it again tonight.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:176
translate chinese SR2_NS4_label_125a58f9:

    # MC "(I’d love to bury my cock, balls-deep in her, and just shoot my cum, deep into her body.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:177
translate chinese SR2_NS4_label_840005b8:

    # Sara "(I’m starting to get wet, now that he’s leering at me like that.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:181
translate chinese SR2_NS4_label_cfb94d1f:

    # Sara "Okay... *Phew*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:182
translate chinese SR2_NS4_label_c82be1a5:

    # Sara "(Here we go - deep breaths! I can do this!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:183
translate chinese SR2_NS4_label_e31e3cc6:

    # Sara "I’m ready whenever you are."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:184
translate chinese SR2_NS4_label_f673695a:

    # MC "Okay, let me grab the lube."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:188
translate chinese SR2_NS4_label_a6a8c6a6:

    # Sara "How do we do this, then?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:189
translate chinese SR2_NS4_label_f2c5c7b0:

    # MC "You just roll over and lie on your side. I’ll get some of the lube in my hand and begin to spread it on your ass."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:191
translate chinese SR2_NS4_label_84c0dc48:

    # Sara "It’s not gonna be cold, is it?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:193
translate chinese SR2_NS4_label_cd8e6374:

    # Sara "It’s gonna be cold as other lubes, is it?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:197
translate chinese SR2_NS4_label_81559a9d:

    # MC "I’ll make sure to warm it up with my fingers first."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:198
translate chinese SR2_NS4_label_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:199
translate chinese SR2_NS4_label_94226072:

    # Sara "(This is it... ) *Gulp*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:204
translate chinese SR2_NS4_label_d0e462fa:

    # Sara "Just before we begin - can you promise me that you’ll definitely stop if it starts to hurt?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:206
translate chinese SR2_NS4_label_396eab6a:

    # Sara "Just before we begin - can you promise me that you'll definitely stop when I tell you?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:207
translate chinese SR2_NS4_label_cc50ea08:

    # MC "Of course I will, Sara."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:208
translate chinese SR2_NS4_label_b3f48b0e:

    # Sara "Okay, whenever you’re ready."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:212
translate chinese SR2_NS4_label_19b61e2e:

    # MC "I’m just gonna spread your asscheeks here so I can get inside."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:214
translate chinese SR2_NS4_label_5fbee909:

    # MC "(Damn, look how tight her little hole is! No wonder my fat cock hurt her!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:216
translate chinese SR2_NS4_label_f8dc99ff:

    # MC "(Damn! Look how tight her little hole is!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:217
translate chinese SR2_NS4_label_40de3cb0:

    # MC "(This lube should definitely do the trick!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:221
translate chinese SR2_NS4_label_1aa768d3:

    # Sara "Oh!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:222
translate chinese SR2_NS4_label_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:223
translate chinese SR2_NS4_label_2b9edb68:

    # Sara "Y-Yeah, I was just a little shocked when your finger went in."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:224
translate chinese SR2_NS4_label_6f2d4e75:

    # MC "How does that feel?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:225
translate chinese SR2_NS4_label_4ebd96d2:

    # Sara "Err... A bit strange... But not really painful at all."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:226
translate chinese SR2_NS4_label_1903d282:

    # MC "Okay, I’m gonna use two fingers now."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:230
translate chinese SR2_NS4_label_2b253959:

    # Sara "Ah..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:231
translate chinese SR2_NS4_label_59829ef9:

    # MC "Is this sore?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:232
translate chinese SR2_NS4_label_f579b084:

    # Sara "Um... On a scale of one to ten, with ten being the worst pain ever... It's like two right now."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:237
translate chinese SR2_NS4_label_10f68c07:

    # MC "What was the pain like, on the roof the other night?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:238
translate chinese SR2_NS4_label_ef0e1615:

    # Sara "Like a... seven, maybe an eight."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:239
translate chinese SR2_NS4_label_fadb6bf0:

    # MC "Aww, I’m sorry. I didn’t realise it was that sore."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:240
translate chinese SR2_NS4_label_73e5f070:

    # Sara "It’s okay. You’re doing things to try and make it hurt less. That means you care about me."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:242
translate chinese SR2_NS4_label_52196ad6:

    # MC "What was the feeling like, on the roof the other night?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:243
translate chinese SR2_NS4_label_85103af4:

    # Sara "Like a... nevermind..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:244
translate chinese SR2_NS4_label_a828f189:

    # Sara "It’s okay. You're doing things to make me feel pleasure just as yourself. That means you care about me."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:248
translate chinese SR2_NS4_label_6df4baee:

    # MC "Okay, I’m bringing my cock up now. I’m gonna slide it in, slowly and gently."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:249
translate chinese SR2_NS4_label_04177990:

    # MC "If you need me to stop - just say, okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:250
translate chinese SR2_NS4_label_56c2e20f:

    # MC "(I think I’ve applied enough lube. It should HOPEFULLY slide in much easier this time.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:254
translate chinese SR2_NS4_label_c67573a9:

    # Sara "Ah...."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:255
translate chinese SR2_NS4_label_2bc01b43:

    # Sara "(Oh shit... here we go... I can do this...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:256
translate chinese SR2_NS4_label_cf125997:

    # Sara "(Just keep breathing and clench your teeth.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:260
translate chinese SR2_NS4_label_a523bec2:

    # Sara "Oooohh!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:261
translate chinese SR2_NS4_label_2b84bca2:

    # MC "Sorry, a bit more slipped in than I intended!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:262
translate chinese SR2_NS4_label_5b72e012:

    # Sara "Ow..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:263
translate chinese SR2_NS4_label_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:267
translate chinese SR2_NS4_label_a7835e8e:

    # Sara "Y-Yeah! (Fuck!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:270
translate chinese SR2_NS4_label_14778c02:

    # Sara "(Even with the lube, this is still hurting like hell!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:271
translate chinese SR2_NS4_label_934c8571:

    # Sara "(How do women in porn take it in the ass so easily?! Is it practice? Or is it because they’ve got bigger bodies than I do?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:273
translate chinese SR2_NS4_label_28fbeb47:

    # Sara "(Even with the lube, I can still feel that strange feeling... But... It’s not so bad!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:274
translate chinese SR2_NS4_label_e81da301:

    # Sara "(How do women in porn take it in the ass so easily?! Is it practice? Or is it because they are milfs?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:278
translate chinese SR2_NS4_label_256b85e4:

    # MC "How does it feel now?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:281
translate chinese SR2_NS4_label_0ce69dc0:

    # Sara "Like... a four. It’s hurting a bit."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:283
translate chinese SR2_NS4_label_3d7f5e25:

    # Sara "It’s weird... But I'm starting to like it more and more..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:284
translate chinese SR2_NS4_label_28b91e37:

    # MC "Am I going too fast?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:285
translate chinese SR2_NS4_label_861073d7:

    # Sara "N-No... you can speed up a LITTLE bit, if you want."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:289
translate chinese SR2_NS4_label_a0d35193:

    # MC "Okay, if you’re sure."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:291
translate chinese SR2_NS4_label_80742e70:

    # Sara "(Uh oh... maybe this was a bad idea.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:292
translate chinese SR2_NS4_label_ad155ffe:

    # Sara "Ah! Ow! Ouch!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:297
translate chinese SR2_NS4_label_1fbf0ed8:

    # Sara "Ah! AHH! It hurts! Ow!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:299
translate chinese SR2_NS4_label_531fea76:

    # Sara "Ah! AHH! Let’s stop!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:300
translate chinese SR2_NS4_label_4d7084eb:

    # MC "I’m sorry! I’m sorry!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:301
translate chinese SR2_NS4_label_da63a008:

    # MC "(Fuck! I thrust my cock in too deep, there. I better pull out and make sure she’s okay.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:307
translate chinese SR2_NS4_label_2b00cd3f:

    # Sara "Owww..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:308
translate chinese SR2_NS4_label_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:309
translate chinese SR2_NS4_label_b559db00:

    # Sara "(I couldn’t do it... I couldn’t go through with it. Now [player_name]’s going to be disappointed in me.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:313
translate chinese SR2_NS4_label_6a476a30:

    # MC "Sara? Are you okay?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:314
translate chinese SR2_NS4_label_8eea1b83:

    # Sara "*Sniff*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:315
translate chinese SR2_NS4_label_484cf5b0:

    # MC "(Shit! I think I’ve made her cry!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:319
translate chinese SR2_NS4_label_9c34d15e:

    # Sara "I’m sorry.... I’m just not good at this sex thing."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:321
translate chinese SR2_NS4_label_dd266e21:

    # Sara "I’m sorry... I’m just not good at this anal thing."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:322
translate chinese SR2_NS4_label_492af58f:

    # Sara "You should just go and find another hot girl, who can do the things that you want."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:323
translate chinese SR2_NS4_label_3d23ce79:

    # MC "Hey! That’s not true! You’re absolutely perfect."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:324
translate chinese SR2_NS4_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:325
translate chinese SR2_NS4_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:326
translate chinese SR2_NS4_label_fe5e5074:

    # MC "Give me a sec and we can talk. I’ll go-"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:330
translate chinese SR2_NS4_label_53c5ded2:

    # Sara "-I’m sorry! I just can’t relax when we’re doing it. It’s... different to when I’m giving you a blowjob."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:331
translate chinese SR2_NS4_label_c7354125:

    # Sara "I can’t explain why... it’s more... intimate when I use my ass."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:332
translate chinese SR2_NS4_label_cf4e28e2:

    # MC "Sara, I-"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:336
translate chinese SR2_NS4_label_bc03f348:

    # Sara "Can you call me your girlfriend?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:337
translate chinese SR2_NS4_label_19570c32:

    # MC "What?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:338
translate chinese SR2_NS4_label_1d7f6a60:

    # Sara "Please, just tell me I’m your girlfriend. I need to hear those words. I think I can relax when I know that you’re committed to me."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:339
translate chinese SR2_NS4_label_79d1df5e:

    # MC "Sara... I love you. And... I want you to be my girlfriend."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:340
translate chinese SR2_NS4_label_80d1d31e:

    # Sara "Really?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:341
translate chinese SR2_NS4_label_a65f733f:

    # MC "Really. I mean it."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:342
translate chinese SR2_NS4_label_b8bb3e3f:

    # Sara "Lie back down beside me. I want to try one last time."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:346
translate chinese SR2_NS4_label_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:347
translate chinese SR2_NS4_label_95f478c3:

    # Sara "I think... I think I can go through with it. Maybe try lifting my leg up?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:354
translate chinese SR2_NS4_label_be6dd1da:

    # MC "Just like this?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:355
translate chinese SR2_NS4_label_ee826b86:

    # Sara "Yeah, that feels a little better already."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:356
translate chinese SR2_NS4_label_f46479c5:

    # MC "(I can’t wait till I get to fuck her pussy someday. It’s so gorgeous.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:360
translate chinese SR2_NS4_label_2b253959_1:

    # Sara "Ah..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:362
translate chinese SR2_NS4_label_26d81e11:

    # MC "It’s okay. I'm not going to hurt you."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:363
translate chinese SR2_NS4_label_4bf708c6:

    # Sara "Tell me it again. Ah..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:367
translate chinese SR2_NS4_label_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:368
translate chinese SR2_NS4_label_e165edae:

    # Sara "N-No, the other one. I want- need to hear you say it."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:369
translate chinese SR2_NS4_label_1471d848:

    # MC "You’re my girlfriend, Sara. You’re the one I want to be with. That’s the truth."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:373
translate chinese SR2_NS4_label_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:374
translate chinese SR2_NS4_label_2d012949:

    # MC "(Now that she’s relaxed a bit, this is starting to feel much better for me!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:376
translate chinese SR2_NS4_label_eb501a61:

    # MC "(She doesn’t seem to be in much pain at all now.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:378
translate chinese SR2_NS4_label_ce74ff19:

    # MC "(She seems to be enjoing it a lot more now!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:382
translate chinese SR2_NS4_label_246bd3ab:

    # Sara "Ah... Oh.... Mmm..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:385
translate chinese SR2_NS4_label_0d92e2e2:

    # Sara "(This is starting to feel... strange now. It isn’t as sore as it used to be.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:387
translate chinese SR2_NS4_label_ce9184cf:

    # Sara "(This is starting to feel... GOOD now. It isn't the same feeling as it used to be.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:388
translate chinese SR2_NS4_label_2110d0c2:

    # MC "(It sounds like Sara’s moans are getting quieter. Maybe her body is getting used to it.)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:392
translate chinese SR2_NS4_label_1fce08ff:

    # MC "How are you doing there, Sara? Do you need me to slow down at all?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:393
translate chinese SR2_NS4_label_bed3023e:

    # Sara "Ah... Mmm..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:394
translate chinese SR2_NS4_label_e2d0cf56:

    # MC "(Her nipples have gone stiff. Maybe she’s actually beginning to enjoy this?)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:398
translate chinese SR2_NS4_label_c8b711b7:

    # Sara "Could we... ah... change positions?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:399
translate chinese SR2_NS4_label_a3ff5a94:

    # MC "What way do you want to go?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:400
translate chinese SR2_NS4_label_c8c5b000:

    # Sara "I want to face you when we’re fucking. I want to be able to see your eyes."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:404
translate chinese SR2_NS4_label_365afdc9:

    # MC "Like this?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:405
translate chinese SR2_NS4_label_21f1978d:

    # Sara "Ahh! Y-Yeah, like this."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:406
translate chinese SR2_NS4_label_0cecbf5d:

    # Sara "(God, I’m getting so wet right now. Am I actually beginning to enjoy being fucked in the ass?)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:410
translate chinese SR2_NS4_label_7d58ad3b:

    # Sara "Ah! Ah! Ahh!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:411
translate chinese SR2_NS4_label_71418457:

    # MC "Are you okay, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:412
translate chinese SR2_NS4_label_70a678b4:

    # Sara "Y-yeah, it’s... mmm! Starting to feel good!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:416
translate chinese SR2_NS4_label_9d0253f9:

    # Sara "MMMM! OHHH!!!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:419
translate chinese SR2_NS4_label_56ddf9c7:

    # MC "Shush, you don’t want to wake up Mom."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:420
translate chinese SR2_NS4_label_fc099a01:

    # MC "This would be REALLY difficult to explain to her. Haha!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:422
translate chinese SR2_NS4_label_0bfb6c58:

    # MC "Shush! You don’t want to wake up anybody!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:423
translate chinese SR2_NS4_label_c191a852:

    # MC "We’re in a very private situation... Are we? Haha!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:424
translate chinese SR2_NS4_label_268369df:

    # Sara "Hehe! Ohhh!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:428
translate chinese SR2_NS4_label_8f48db05:

    # Sara "Fuck... *GASP*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:429
translate chinese SR2_NS4_label_dd6422e5:

    # MC "Do you need me to slow down?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:430
translate chinese SR2_NS4_label_d2c37a39:

    # Sara "N-No... You can speed up a little, if you want to. Just... ah... don’t go much deeper. Okay?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:434
translate chinese SR2_NS4_label_5468574b:

    # Sara "I love you, [player_name]. Thank you for having me over, in your room."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:435
translate chinese SR2_NS4_label_bfc3b44f:

    # MC "You’re ALWAYS welcome to come over, Sara. I love you too."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:436
translate chinese SR2_NS4_label_2d7ad50d:

    # MC "Plus, you’re my girlfriend now."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:440
translate chinese SR2_NS4_label_e6a95c7f:

    # MC "Ugh! Ah..."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:441
translate chinese SR2_NS4_label_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:442
translate chinese SR2_NS4_label_d8b3262d:

    # MC "Mmm! (I just put my hand on her face for balance, but she’s already started sucking on my thumb!)"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:446
translate chinese SR2_NS4_label_d63b0594:

    # MC "I’m gonna cum soon - can we make out while I finish?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:447
translate chinese SR2_NS4_label_2f31a332:

    # Sara "Sure, [player_name]."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:448
translate chinese SR2_NS4_label_b48bfc73:

    # MC "Are you okay if I cum in your ass?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:449
translate chinese SR2_NS4_label_9a64e39c:

    # Sara "Finish wherever you want."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:453
translate chinese SR2_NS4_label_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:454
translate chinese SR2_NS4_label_a44ee2be:

    # Sara "Ohhhmmmm! MMMMM!"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:455
translate chinese SR2_NS4_label_89793c95:

    # Sara "(This almost feels as good as the vibrator [player_name] bought for me.)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:459
translate chinese SR2_NS4_label_0361910e:

    # MC "MMM! HNNNNGGGG!!!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:460
translate chinese SR2_NS4_label_90ac8d0e:

    # MC "UGH! AAHHHH!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:461
translate chinese SR2_NS4_label_c072896c:

    # Sara "(Wow! I can feel his hot cum flooding into my ass! It feels amazing!)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:462
translate chinese SR2_NS4_label_21c0841c:

    # Sara "(Fuck... I wonder how it would feel in my pussy...)"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:471
translate chinese SR2_NS4_label_d27542c6:

    # MC "*Pant* Th-That was fucking amazing, Sara."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:472
translate chinese SR2_NS4_label_0cc8d77f:

    # Sara "You enjoyed that?"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:473
translate chinese SR2_NS4_label_4dc73c16:

    # MC "Oh yeah... How about you?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:474
translate chinese SR2_NS4_label_fd806f9b:

    # Sara "I’m not gonna lie, it’s growing on me. I actually kind of found it... pleasurable that time."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:475
translate chinese SR2_NS4_label_451951e1:

    # MC "C’mon, let’s cuddle for a while before you go back to your room."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:485
translate chinese SR2_NS4_label_6559f47d:

    # Sara "Yay! Hehe! This is the best part."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:486
translate chinese SR2_NS4_label_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:490
translate chinese SR2_NS4_label_800755f2:

    # Sara "I could just close my eyes and drift off to sleep like this."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:491
translate chinese SR2_NS4_label_4a4fce81:

    # Sara "I love the feeling of your soft skin against mine. It just feels so perfect..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:492
translate chinese SR2_NS4_label_b06f5213:

    # Sara "Like everything is just right in the world."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:496
translate chinese SR2_NS4_label_138332f3:

    # Sara "*Sigh*"
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:497
translate chinese SR2_NS4_label_fd14fda2:

    # MC "Is something wrong, Sara?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:498
translate chinese SR2_NS4_label_9d5118f7:

    # Sara "I just realised... you’re my boyfriend, but I can’t hang out with you like normal girlfriends do."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:499
translate chinese SR2_NS4_label_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:501
translate chinese SR2_NS4_label_fc5be3a9:

    # Sara "Everybody in this town knows us. And Mom and Dad would DEFINITELY not approve."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:503
translate chinese SR2_NS4_label_9e8017b7:

    # Sara "Everybody in this town knows us for a while now. A nerdy girl like me and a handsome man like you? Together? It's all wrong... Lily would be better for you than I am..."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:507
translate chinese SR2_NS4_label_9a64ddd3:

    # MC "Oh c’mon! You’re thinking too much about this."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:510
translate chinese SR2_NS4_label_e05bd261:

    # MC "We can do LOTS of things together, sure we’ll have to be a little more careful than most couples, but we can still have fun!"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:511
translate chinese SR2_NS4_label_bfac8e05:

    # MC "And don’t worry about Mom and Dad - we haven’t been caught yet."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:513
translate chinese SR2_NS4_label_a6d0686f:

    # MC "I don’t fucking care about that kind of thing! The feeling between us is what is most important. Also, who says that you're a nerd?"
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:514
translate chinese SR2_NS4_label_0383b342:

    # MC "Even if that is true, you're my lovely nerd. "
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:518
translate chinese SR2_NS4_label_bc2b3485:

    # Sara "Yeah, I guess you’re right. I just wish things were simpler."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:520
translate chinese SR2_NS4_label_37b96a61:

    # Sara "It sounds bad... but I kinda wish you weren’t my brother. Maybe just a hot guy at college."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:522
translate chinese SR2_NS4_label_5945b0f2:

    # Sara "It sounds bad... but I kinda wish you weren’t living in the same house as me. Maybe just another hot guy at college. That would be easier."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:523
translate chinese SR2_NS4_label_4a3eac11:

    # Sara "That way I could bring you over and hang out with you. Watch TV and stuff like that."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:527
translate chinese SR2_NS4_label_69e1b9eb:

    # MC "Sara, you’re overthinking this. You’re my girlfriend now and we’re gonna make this work. I promise."
    MC ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:528
translate chinese SR2_NS4_label_f97a0e6d:

    # Sara "Thanks, [player_name]. I love you so much."
    Sara ""

# game/scripts/home/mc_room/night/scenes/SR2_NS4_.rpy:529
translate chinese SR2_NS4_label_f7f96222:

    # MC "I love you, too, Sara."
    MC ""

