﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:52
translate chinese caroline_mc_room_morning_scene5_label_f28c318c:

    # Caroline "(Well... this is it. I’ve thought things through, and I know my limitations.)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:53
translate chinese caroline_mc_room_morning_scene5_label_25e8d212:

    # Caroline "(I’ll lay down the boundaries with [player_name] and see if he’s interested in a deal.)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:54
translate chinese caroline_mc_room_morning_scene5_label_37c0a2b8:

    # Caroline "(God... I hope I’m doing the right thing.)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:57
translate chinese caroline_mc_room_morning_scene5_label_73a88263:

    # Caroline "[player_name]? Are you awake?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:58
translate chinese caroline_mc_room_morning_scene5_label_dabaf0fc:

    # MC "*Snooooree...*"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:59
translate chinese caroline_mc_room_morning_scene5_label_fbb20bf2:

    # Caroline "(He’s in a deep sleep... I guess that gives me an excuse to break the ice before I have to try and have this difficult conversation.)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:64
translate chinese caroline_mc_room_morning_scene5_label_ccc620ff:

    # Caroline "BOO!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:65
translate chinese caroline_mc_room_morning_scene5_label_007dcd03:

    # MC "AHHH!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:66
translate chinese caroline_mc_room_morning_scene5_label_d46af2ae:

    # MC "Jesus Christ! You scared the shit out of me, Caroline! What the Hell?!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:69
translate chinese caroline_mc_room_morning_scene5_label_e51822ee:

    # Caroline "Aww, come on. You’re happy to see me."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:72
translate chinese caroline_mc_room_morning_scene5_label_39fe1185:

    # MC "Yeah - but couldn’t you have woken me up gently?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:73
translate chinese caroline_mc_room_morning_scene5_label_dd69a703:

    # MC "Y’know - maybe a hug or pat on the shoulder..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:74
translate chinese caroline_mc_room_morning_scene5_label_860c3643:

    # Caroline "Pfft! That’s no fun!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:77
translate chinese caroline_mc_room_morning_scene5_label_28d9be90:

    # Caroline "Anyway, I have something important to tell you. So I need you to be fully awake."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:78
translate chinese caroline_mc_room_morning_scene5_label_2d25befd:

    # MC "Uh huh?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:79
translate chinese caroline_mc_room_morning_scene5_label_f685b95e:

    # Caroline "I’m willing to help you out with your... problem."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:80
translate chinese caroline_mc_room_morning_scene5_label_5e900ee0:

    # MC "Do you mean my erection?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:83
translate chinese caroline_mc_room_morning_scene5_label_2f6d268b:

    # Caroline "Yeah... that. However, there are some conditions and rules I want to lay down first."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:84
translate chinese caroline_mc_room_morning_scene5_label_3c734d6b:

    # MC "Like what?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:85
translate chinese caroline_mc_room_morning_scene5_label_866dff39:

    # Caroline "I need you to promise me something, first."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:86
translate chinese caroline_mc_room_morning_scene5_label_e68773c7:

    # MC "Anything!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:87
translate chinese caroline_mc_room_morning_scene5_label_89ed0769:

    # Caroline "You have to respect these rules and not try to push me to do something I’m uncomfortable with. Does that sound fair to you?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:88
translate chinese caroline_mc_room_morning_scene5_label_190f8f14:

    # MC "Sure, I guess so. What are you comfortable with?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:92
translate chinese caroline_mc_room_morning_scene5_label_fb908a32:

    # Caroline "I’m happy to help you get off using my hands or butt again, but there’s two conditions."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:93
translate chinese caroline_mc_room_morning_scene5_label_a61319b9:

    # Caroline "The first is that you start working for free when I need photo sessions done. I don’t have the spare cash to take on a part-time employee."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:94
translate chinese caroline_mc_room_morning_scene5_label_26289e4d:

    # MC "Fair enough. I understand."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:95
translate chinese caroline_mc_room_morning_scene5_label_23959a90:

    # Caroline "The second condition is that this ends when you find yourself a girlfriend. From then on, it’s her job."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:96
translate chinese caroline_mc_room_morning_scene5_label_48c2db1f:

    # Caroline "Does that sound fair to you?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:97
translate chinese caroline_mc_room_morning_scene5_label_ca08d846:

    # MC "Yeah, that sounds fair."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:100
translate chinese caroline_mc_room_morning_scene5_label_d14db211:

    # Caroline "Ahh, I see you could probably use some help, RIGHT NOW."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:101
translate chinese caroline_mc_room_morning_scene5_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:104
translate chinese caroline_mc_room_morning_scene5_label_5fff9b0c:

    # MC "Aw, crap. Sorry. I’ve no control over it - I swear!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:105
translate chinese caroline_mc_room_morning_scene5_label_d8ff8c20:

    # Caroline "Would you like to begin our deal RIGHT NOW?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:106
translate chinese caroline_mc_room_morning_scene5_label_2b515de7:

    # MC "Definitely!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:107
translate chinese caroline_mc_room_morning_scene5_label_23f67ca2:

    # Caroline "Let’s get this started, then - Kick off your boxer shorts."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:110
translate chinese caroline_mc_room_morning_scene5_label_1cd3255c:

    # Caroline "Well, that was fast! Shall I begin with my hand today, since you had my ass last time?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:111
translate chinese caroline_mc_room_morning_scene5_label_4c987f37:

    # MC "Yeah, that works for me!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:112
translate chinese caroline_mc_room_morning_scene5_label_bbd25215:

    # Caroline "Okay, here we go."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:115
translate chinese caroline_mc_room_morning_scene5_label_3273a3bd:

    # Caroline "Hehe... You’ve got such a hard cock. Do I really turn you on THAT MUCH?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:116
translate chinese caroline_mc_room_morning_scene5_label_68eb99a2:

    # MC "Any beautiful girl would, to be honest."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:117
translate chinese caroline_mc_room_morning_scene5_label_211aad25:

    # Caroline "Oh, so you think I’m beautiful then?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:118
translate chinese caroline_mc_room_morning_scene5_label_741a2f58:

    # MC "Of course I do. You’re stunning."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:121
translate chinese caroline_mc_room_morning_scene5_label_cd33d6ea:

    # Caroline "How’s this? Am I holding your cock too hard?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:122
translate chinese caroline_mc_room_morning_scene5_label_ba83cc5f:

    # MC "Mmmm... No, that’s good, right there."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:123
translate chinese caroline_mc_room_morning_scene5_label_93050b21:

    # Caroline "Okay then, I’ll keep stroking your thick dick like this then."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:126
translate chinese caroline_mc_room_morning_scene5_label_9eae3fc7:

    # Caroline "You are a pervert. You know that, right?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:130
translate chinese caroline_mc_room_morning_scene5_label_16180b3a:

    # Caroline "Getting, all hard and horny, because of your older sister. Don’t think I didn’t know that you used to perv on me when I was sitting in my bedroom in my underwear."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:132
translate chinese caroline_mc_room_morning_scene5_label_b86c7bf8:

    # Caroline "Getting all hard and horny from looking at me like this. Don’t think I didn’t know that you used to perv on me when I was sitting in my bedroom in my underwear."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:135
translate chinese caroline_mc_room_morning_scene5_label_7b7325d6:

    # MC "Well, it seems being a pervert, comes with benefits."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:136
translate chinese caroline_mc_room_morning_scene5_label_7961385c:

    # Caroline "So, have you been thinking of me, when you masturbate?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:137
translate chinese caroline_mc_room_morning_scene5_label_85f705c4:

    # MC "What? I don’t-"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:140
translate chinese caroline_mc_room_morning_scene5_label_dbbafff3:

    # Caroline "Are you trying to tell me that you, don’t wank yourself? That’s bullshit!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:141
translate chinese caroline_mc_room_morning_scene5_label_cab940e8:

    # MC "Of course I do that... but I’m not gonna just tell you what or who I fantasise about."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:144
translate chinese caroline_mc_room_morning_scene5_label_de5e0d85:

    # Caroline "Oh well... Maybe you’ll open up to me, someday soon."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:147
translate chinese caroline_mc_room_morning_scene5_label_109237fd:

    # Caroline "Are you enjoying this, by the way? Do you want me to do anything different?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:153
translate chinese caroline_mc_room_morning_scene5_label_4fb5d7f9:

    # MC "It’s amazing! Don’t stop! Ahh..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:154
translate chinese caroline_mc_room_morning_scene5_label_3ed61d5e:

    # Caroline "In that case, I’ll use both my hands, then!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:155
translate chinese caroline_mc_room_morning_scene5_label_eb3bf8af:

    # MC "Ah! I’m so close to cumming! Ugh!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:160
translate chinese caroline_mc_room_morning_scene5_label_f2634aca:

    # Caroline "Cum for me! Cum for your big sister!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:162
translate chinese caroline_mc_room_morning_scene5_label_dba5eba9:

    # Caroline "Cum for me! Blow your hot cum all over my hands!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:163
translate chinese caroline_mc_room_morning_scene5_label_1f2a47b3:

    # MC "Hnnng! Ahhh! Ugh! Yes!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:164
translate chinese caroline_mc_room_morning_scene5_label_2a539d84:

    # MC "(She’s amazing with her hands!)"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:175
translate chinese caroline_mc_room_morning_scene5_label_c31d1970:

    # Caroline "Remember, it only lasts until you get a girlfriend - and you’re working for free, with me now!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:176
translate chinese caroline_mc_room_morning_scene5_label_4f4c09f6:

    # Caroline "Come back to my shop, when you get a chance. I’m ordering in some new stock."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:177
translate chinese caroline_mc_room_morning_scene5_label_afdcdc5c:

    # MC "Will do, Caroline!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:178
translate chinese caroline_mc_room_morning_scene5_label_591d46f7:

    # MC "Phew... I’m exhausted after that..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:179
translate chinese caroline_mc_room_morning_scene5_label_e3688b64:

    # Caroline "Well, I hate to break the bad news - but it’s time for you to get up."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:201
translate chinese caroline_mc_room_morning_scene5_label_7ec749ec:

    # MC "Could you try using your feet instead?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:202
translate chinese caroline_mc_room_morning_scene5_label_6c7561a6:

    # Caroline "M-My feet?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:203
translate chinese caroline_mc_room_morning_scene5_label_16fb6d15:

    # MC "I know you said you would get me off with your hand or ass, as part of the deal - but can we make an exception for feet too?"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:206
translate chinese caroline_mc_room_morning_scene5_label_521570d5:

    # Caroline "Sure, I guess so."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:207
translate chinese caroline_mc_room_morning_scene5_label_059f239d:

    # Caroline "To be honest, my real limitations were oral and actual sex. I didn’t imagine you had a foot fetish."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:208
translate chinese caroline_mc_room_morning_scene5_label_985fe578:

    # Caroline "I’ve never actually used my feet on a guy before. So you’ll need to guide me a bit. How is this?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:213
translate chinese caroline_mc_room_morning_scene5_label_ed749b12:

    # MC "That’s good. Just keep moving your feet up and down."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:214
translate chinese caroline_mc_room_morning_scene5_label_80d0ccaf:

    # Caroline "It feels a little awkward."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:215
translate chinese caroline_mc_room_morning_scene5_label_574523da:

    # MC "Don’t worry about it - you’re doing fine."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:216
translate chinese caroline_mc_room_morning_scene5_label_af3d86f6:

    # MC "If you wanted - you could also try holding my balls with your toes and caressing my cock with your other foot."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:219
translate chinese caroline_mc_room_morning_scene5_label_4ba0da28:

    # Caroline "Kinda like this?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:220
translate chinese caroline_mc_room_morning_scene5_label_64fee7b5:

    # MC "Yeah, just like that! Mmm..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:221
translate chinese caroline_mc_room_morning_scene5_label_799566bd:

    # Caroline "(This is kinda fun actually!)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:224
translate chinese caroline_mc_room_morning_scene5_label_924b3b29:

    # Caroline "Are you gonna cum soon? My legs are getting a bit tired."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:225
translate chinese caroline_mc_room_morning_scene5_label_b356b6b1:

    # MC "Soon-ish. If it helps, though, you can use your hand as well."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:226
translate chinese caroline_mc_room_morning_scene5_label_9ccb25ef:

    # Caroline "Is that okay?"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:227
translate chinese caroline_mc_room_morning_scene5_label_63873555:

    # MC "Absolutely!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:230
translate chinese caroline_mc_room_morning_scene5_label_d3ca72f4:

    # MC "Oh God... yes! Ahh..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:231
translate chinese caroline_mc_room_morning_scene5_label_8bd80efe:

    # Caroline "Oh! You’re about to cum! I’m gonna use my hand, to finish you, now!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:232
translate chinese caroline_mc_room_morning_scene5_label_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:235
translate chinese caroline_mc_room_morning_scene5_label_db433e78:

    # Caroline "Here we go!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:236
translate chinese caroline_mc_room_morning_scene5_label_0ca3fba5:

    # MC "Ah! Ahhh! Ahhhhhh! HNNNNGGGGG!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:237
translate chinese caroline_mc_room_morning_scene5_label_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:248
translate chinese caroline_mc_room_morning_scene5_label_ec8d31b9:

    # Caroline "Oh wow... That’s A LOT of cum right there!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:250
translate chinese caroline_mc_room_morning_scene5_label_e2872de8:

    # Caroline "(I think [player_name] really enjoyed this!)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:252
translate chinese caroline_mc_room_morning_scene5_label_e2872de8_1:

    # Caroline "(I think [player_name] really enjoyed this!)"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:253
translate chinese caroline_mc_room_morning_scene5_label_e8530e51:

    # MC "Phew, that was incredible, Caroline. Thank you so much... *Yaaawwwn!*"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:254
translate chinese caroline_mc_room_morning_scene5_label_21b0c43c:

    # Caroline "I hope you aren’t tired! It’s time to get up!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:257
translate chinese caroline_mc_room_morning_scene5_label_58b96e51:

    # MC "Aww... Thanks anyway, Caroline. I’m going to enjoy this deal we made!"
    MC ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:258
translate chinese caroline_mc_room_morning_scene5_label_53f6a2cd:

    # Caroline "Remember, it only lasts until you get a girlfriend - and you’re working for me for free now!"
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:259
translate chinese caroline_mc_room_morning_scene5_label_4f4c09f6_1:

    # Caroline "Come back to my shop, when you get a chance. I’m ordering in some new stock."
    Caroline ""

# game/scripts/home/mc_room/morning/scenes/caroline_mc_room_morning_scene5.rpy:260
translate chinese caroline_mc_room_morning_scene5_label_afdcdc5c_1:

    # MC "Will do, Caroline!"
    MC ""

