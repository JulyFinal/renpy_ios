﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/night/labels_mc_room_night.rpy:20
translate chinese mc_room_night1_cf77105c:

    # MC "Time to get up!"
    MC ""

