﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:18
translate chinese CR3_AS7a_label_a0c1419c:

    # MC "(Caroline seems to rely VERY heavily on that dildo, to keep her lust in check.)"
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:19
translate chinese CR3_AS7a_label_a1cd4eae:

    # MC "(If I can find and steal it, I’ll hopefully leave her feeling extra horny, when she can’t - get herself off.)"
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:20
translate chinese CR3_AS7a_label_591e0842:

    # MC "(If my plan works properly, she’ll come running to me, to try and relieve herself.)"
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:24
translate chinese CR3_AS7a_label_85040573:

    # MC "Hmm, let's see... I could have sworn she hid it under her bed."
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:25
translate chinese CR3_AS7a_label_82aa5dd9:

    # MC "Ugh... I should have brought a torch."
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:26
translate chinese CR3_AS7a_label_3a526d22:

    # MC "Aha! (I think I’ve got it.)"
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:30
translate chinese CR3_AS7a_label_13ddd06d:

    # MC "Bingo!"
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:31
translate chinese CR3_AS7a_label_865fe6e2:

    # MC "(Let’s see what Caroline does, now that she can’t use her fancy vibrator, to cum!)"
    MC ""

# game/scripts/home/caroline_room/day/scenes/CR3_AS7a.rpy:32
translate chinese CR3_AS7a_label_461f9a23:

    # MC "(I’ll hide this in my room, so she doesn’t find it.)"
    MC ""

