﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:15
translate chinese MLR3_Bob_MS1_5477a073:

    # MC "(I've already talked with him.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:22
translate chinese MLR3_Bob_MS1_5477a073_1:

    # MC "(I've already talked with him.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:36
translate chinese MLR3_Bob_MS1_3f35fa98:

    # "*VROOOM*"
    ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:37
translate chinese MLR3_Bob_MS1_e4a3d605:

    # MC "Hey, [Dad_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:38
translate chinese MLR3_Bob_MS1_dcd60da1:

    # "*VROOOOOMMM*"
    ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:39
translate chinese MLR3_Bob_MS1_f4515e95:

    # MC "Hey! [Dad_name]!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:43
translate chinese MLR3_Bob_MS1_41eadd98:

    # Bob "Hey, sorry champ. Couldn’t hear you with the old vacuum on, there."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:44
translate chinese MLR3_Bob_MS1_618d1974:

    # Bob "What’s up?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:45
translate chinese MLR3_Bob_MS1_5d96b067:

    # MC "Are you free to talk right now?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:49
translate chinese MLR3_Bob_MS1_fe03000d:

    # Bob "Yeah, shoot."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:50
translate chinese MLR3_Bob_MS1_3495ba09:

    # Bob "What do you want to discuss?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:55
translate chinese MLR3_Bob_MS1_95451026:

    # Bob "Hello again, champ. Looking to chat with your Dad?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:57
translate chinese MLR3_Bob_MS1_a0a2f680:

    # Bob "Hello again, champ. Looking to chat with me?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:58
translate chinese MLR3_Bob_MS1_29715e91:

    # MC "Yeah, are you busy?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:61
translate chinese MLR3_Bob_MS1_62a65650:

    # Bob "I can always spare some time for my favourite son."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:64
translate chinese MLR3_Bob_MS1_82c2ee44:

    # Bob "I can always spare some time for my favourite other man in the house."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:65
translate chinese MLR3_Bob_MS1_c5b85830:

    # Bob "Bob...I’m the ONLY other man in the house."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:68
translate chinese MLR3_Bob_MS1_a6f96f87:

    # Dad "Exactly! Haha!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:72
translate chinese MLR3_Bob_MS1_3719b147:

    # Mom "(Ugh... His jokes are fucking awful.)"
    Mom ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:75
translate chinese MLR3_Bob_MS1_ca2e2610:

    # Bob "So, what’s up?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:83
translate chinese MLR3_Bob_MS1_menu_d5f8c247:

    # MC "*Whispered* Is everything okay between you and [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:84
translate chinese MLR3_Bob_MS1_menu_5ef7a96d:

    # Bob "Umm... Y-Yeah, all good. All good."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:85
translate chinese MLR3_Bob_MS1_menu_b05866df:

    # MC "*Whispered* I thought I heard you two arguing the other day."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:90
translate chinese MLR3_Bob_MS1_menu_cc3f708c:

    # Bob "*Whispered* We um... might have had a teensy disagreement."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:91
translate chinese MLR3_Bob_MS1_menu_70368145:

    # Linda "*Slurp*"
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:92
translate chinese MLR3_Bob_MS1_menu_06b6150e:

    # Bob "*Whispered* I better get back to vacuuming here. I’m getting the evil eyes from her right now."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:93
translate chinese MLR3_Bob_MS1_menu_8a17c36f:

    # MC "Oops, sorry."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:106
translate chinese MLR3_Bob_MS1_menu_0f5b1a6b:

    # MC "I was wondering if you could give me some advice for finding a job. I’m about to graduate fairly soon."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:107
translate chinese MLR3_Bob_MS1_menu_5691c0a8:

    # Bob "Hmm... That’s a tough one. The labour market has changed massively from my day."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:108
translate chinese MLR3_Bob_MS1_menu_7ed8baac:

    # Bob "It used to be you got a solid union job for life, or you started your own business. I opted for the latter. It’s not like that anymore."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:112
translate chinese MLR3_Bob_MS1_menu_b35ccb01:

    # Bob "The biggest growth is in STEM right now. Science, Technology, Engineering, and Maths."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:113
translate chinese MLR3_Bob_MS1_menu_009a6801:

    # Bob "Train yourself in those and you’ll go far. That’s where you earn the big bucks!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:114
translate chinese MLR3_Bob_MS1_menu_129775cb:

    # MC "Great! Thanks, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:124
translate chinese MLR3_Bob_MS1_menu_830b3c48:

    # MC "Any tips on dealing with stress, [Dad_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:125
translate chinese MLR3_Bob_MS1_menu_b7eaae74:

    # Bob "Stress? At your age?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:126
translate chinese MLR3_Bob_MS1_menu_71fd04b7:

    # MC "Yeah... exams and stuff can be stressful."
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:130
translate chinese MLR3_Bob_MS1_menu_814de894:

    # Bob "Hmm... I guess you’re right. "
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:131
translate chinese MLR3_Bob_MS1_menu_6086faa6:

    # Bob "Honestly, the best way is to get yourself involved in a hobby. That’ll be a long term solution. Make it a weekly thing if you can."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:132
translate chinese MLR3_Bob_MS1_menu_bbfb8060:

    # Bob "Something that you really enjoy and can work into your routine."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:133
translate chinese MLR3_Bob_MS1_menu_fe98dded:

    # MC "Yeah, that sounds good!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:137
translate chinese MLR3_Bob_MS1_menu_98161ca4:

    # Bob "In the short term, you just need to learn how to take a breather."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:138
translate chinese MLR3_Bob_MS1_menu_5e87fded:

    # Bob "Go for a walk on your lunch break. Stuff like that."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:146
translate chinese MLR3_Bob_MS1_menu_c754bd3d:

    # MC "Why have you been vacuuming so often, lately?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:147
translate chinese MLR3_Bob_MS1_menu_9785bcc0:

    # Bob "Ah... haha! Yes, that’s a very good question."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:151
translate chinese MLR3_Bob_MS1_menu_1c694dec:

    # Bob "I was told to- I... volunteered to help out more around the house. Your mother was getting tired of having to do the cooking and the cleaning AND hold down a full time job."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:153
translate chinese MLR3_Bob_MS1_menu_230185d2:

    # Bob "I was told to- I... volunteered to help out more around the house. Linda was getting tired of having to do the cooking and the cleaning AND hold down a full time job."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:154
translate chinese MLR3_Bob_MS1_menu_f49452fe:

    # Bob "Right, Honey?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:155
translate chinese MLR3_Bob_MS1_menu_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:159
translate chinese MLR3_Bob_MS1_menu_5cd53aa6:

    # Bob "So, yeah... That’s why I’m being so helpful around the house lately..."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:160
translate chinese MLR3_Bob_MS1_menu_7f3a6fcb:

    # Bob "I had to cancel a fishing trip - but this is... just as fun. It’s great fun spending the day with you, Linda."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:161
translate chinese MLR3_Bob_MS1_menu_ce59ffb9:

    # MC "(Jesus, I’ve never heard a man sound more defeated in my life before.)"
    MC ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:79
    old "*Whisper* Is everything okay between you and [Mom_name]?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:79
    old "Could you give me some advice on finding a job?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:79
    old "Any tips on dealing with stress, [Dad_name]?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/morning/scenes/MLR3_Bob_MS1.rpy:79
    old "Why have you been vacuuming so often, lately?"
    new ""

