﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/mc_room/D/labels_mc_room_day.rpy:11
translate chinese mc_room_day1_cf77105c:

    # MC "Time to get up!"
    MC ""

