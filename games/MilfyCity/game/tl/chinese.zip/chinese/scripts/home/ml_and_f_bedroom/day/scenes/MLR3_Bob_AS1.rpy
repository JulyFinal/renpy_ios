﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:37
translate chinese MLR3_Bob_AS1_5477a073:

    # MC "(I've already talked with him.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:51
translate chinese MLR3_Bob_AS1_ed28066d:

    # MC "(Looks like [Dad_name] just got out of the shower.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:52
translate chinese MLR3_Bob_AS1_142f3396:

    # MC "Hey [Dad_name], what’s up?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:56
translate chinese MLR3_Bob_AS1_9d2e55b4:

    # Dad "Oh, hey there, [player_name]. Nothing much. Just chilling."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:57
translate chinese MLR3_Bob_AS1_22cd6e5d:

    # Dad "Something I can help you with?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:58
translate chinese MLR3_Bob_AS1_f77f8a64:

    # MC "I just wanted to chat with you about a few things."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:62
translate chinese MLR3_Bob_AS1_6db7a626:

    # Dad "Ahh, some father-son time."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:64
translate chinese MLR3_Bob_AS1_c1e60fbe:

    # Dad "Ahh, sure thing!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:65
translate chinese MLR3_Bob_AS1_30373af5:

    # Dad "I’ll tell you what - grab me a cigar from beside my bed, then you and I will have a good chat."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:66
translate chinese MLR3_Bob_AS1_57d0d718:

    # MC "No problem, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:70
translate chinese MLR3_Bob_AS1_c375482b:

    # MC "(This looks like his cigar box here. I know [Mom_name] hates it when he smokes these in the house.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:74
translate chinese MLR3_Bob_AS1_4a20bc41:

    # MC "Any particular one, [Dad_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:75
translate chinese MLR3_Bob_AS1_265c5cec:

    # Dad "Yeah, they are all the same. Sometimes I’ll get a few special ones ordered from Cuba. But right now I’m down to the local cigars."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:79
translate chinese MLR3_Bob_AS1_a9412c4b:

    # MC "(I don’t get why [Dad_name] likes these so much. They look awful, and smell even worse.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:80
translate chinese MLR3_Bob_AS1_632e7ab4:

    # MC "(Maybe I’ll ask him about it someday.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:84
translate chinese MLR3_Bob_AS1_1bae5748:

    # MC "(This one will do.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:85
translate chinese MLR3_Bob_AS1_0986ff35:

    # Dad "Did you find them, there?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:86
translate chinese MLR3_Bob_AS1_9e56931a:

    # MC "Yeah, got one. Coming back now, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:90
translate chinese MLR3_Bob_AS1_339e7f74:

    # Dad "Top notch! Thanks, [player_name]."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:91
translate chinese MLR3_Bob_AS1_92ed3895:

    # MC "Anytime, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:95
translate chinese MLR3_Bob_AS1_5752fed3:

    # Dad "So... *Puff* What was it you wanted to ask me?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:96
translate chinese MLR3_Bob_AS1_f38bf49e:

    # Dad "I’m all ears."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:108
translate chinese MLR3_Bob_AS1_9f4dde50:

    # Dad "Hey again, [player_name]. Grab me another cigar, would you? I’ve got a few questions for you today."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:109
translate chinese MLR3_Bob_AS1_4dee9c9b:

    # MC "Oh, sure, [Dad_name]!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:113
translate chinese MLR3_Bob_AS1_5a1ca242:

    # Dad "Thanks, [player_name]."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:114
translate chinese MLR3_Bob_AS1_fd35746d:

    # MC "(I wonder what [Dad_name] wants to ask me about.)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:118
translate chinese MLR3_Bob_AS1_5308c3f5:

    # Dad "*Puff*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:119
translate chinese MLR3_Bob_AS1_9731a212:

    # MC "(Those cigars really do stink! No wonder they drive [Mom_name] crazy!)"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:121
translate chinese MLR3_Bob_AS1_2af01d88:

    # Dad "So, girls... Have you got your eye on one yet?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:126
translate chinese MLR3_Bob_AS1_cf462e4c:

    # MC "Yeah, I’ve got my eye on one, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:128
translate chinese MLR3_Bob_AS1_cf462e4c_1:

    # MC "Yeah, I’ve got my eye on one, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:129
translate chinese MLR3_Bob_AS1_1646de91:

    # Dad "Ohh, lucky lady! I’ll have to hear more about her!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:136
translate chinese MLR3_Bob_AS1_ee188846:

    # MC "No, not yet, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:137
translate chinese MLR3_Bob_AS1_e25775a7:

    # Dad "Oh... Shame. You’re at the prime of your life right now. Try now to waste your youth."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:138
translate chinese MLR3_Bob_AS1_b5f746dc:

    # Dad "Get out there and meet some people. I’m sure there’s dozens of women that are dying to meet you!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:145
translate chinese MLR3_Bob_AS1_54891a46:

    # MC "I’ve met a few girls that I like."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:146
translate chinese MLR3_Bob_AS1_a8440ca0:

    # Dad "A few?! Now we’re talking! Let’s hear some stuff about them!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:153
translate chinese MLR3_Bob_AS1_ff5519f2:

    # Dad "Hey again, [player_name]. I forgot to ask you the last time we met - think of your ideal woman."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:154
translate chinese MLR3_Bob_AS1_6a43f3ba:

    # MC "Okay?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:155
translate chinese MLR3_Bob_AS1_1acc7c61:

    # Dad "What kinda rack does she have?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:156
translate chinese MLR3_Bob_AS1_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:161
translate chinese MLR3_Bob_AS1_53090226:

    # MC "Honestly, the bigger the better!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:163
translate chinese MLR3_Bob_AS1_56866fce:

    # Dad "Nice! Good man! That’s just another reason I fell in love with your mother, her tits are amazing!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:165
translate chinese MLR3_Bob_AS1_e667713b:

    # Dad "Nice! Good man! That’s just another reason I fell in love with Linda, her tits are amazing!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:166
translate chinese MLR3_Bob_AS1_0fff0ed7:

    # MC "I know!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:170
translate chinese MLR3_Bob_AS1_4d2f286d:

    # Dad "... Did you just say, you know that your own mother’s tits are amazing?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:171
translate chinese MLR3_Bob_AS1_5f681696:

    # MC "Uh... (FUCK!) N-No! I meant... I know that... you are... in love with Mom for many reasons!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:173
translate chinese MLR3_Bob_AS1_0cf5733a:

    # Dad "... Did you just say you know that my wife’s tits are amazing?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:174
translate chinese MLR3_Bob_AS1_0bb89b70:

    # MC "Uh... (FUCK!) N-No! I meant... I know that... you are... in love with Linda for many reasons!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:177
translate chinese MLR3_Bob_AS1_8a58fac9:

    # Dad "Ahh! That makes sense! Haha! We had a breakdown in communication there!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:182
translate chinese MLR3_Bob_AS1_39bf8624:

    # MC "Honestly, not too big, not too small."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:183
translate chinese MLR3_Bob_AS1_ea0158e0:

    # Dad "I can respect that. Are we talking a C/D cup?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:184
translate chinese MLR3_Bob_AS1_b6eb42be:

    # MC "Yeah, about that."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:189
translate chinese MLR3_Bob_AS1_edb0a1be:

    # MC "I really like small breasts: an A or B cup."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:190
translate chinese MLR3_Bob_AS1_5e54c957:

    # Dad "Really? Small breasts? Huh? I never pictured you for a tiny tits guy."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:191
translate chinese MLR3_Bob_AS1_8e2311d7:

    # Dad "Don’t take this the wrong way, but are we talking the size of Sara’s?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:192
translate chinese MLR3_Bob_AS1_5ecc3ae1:

    # MC "Yeah, about that size is good."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:193
translate chinese MLR3_Bob_AS1_e8145257:

    # Dad "Huh, different strokes for different folks, I guess!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:200
translate chinese MLR3_Bob_AS1_menu3_86651648:

    # Dad "What about the ideal age?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:201
translate chinese MLR3_Bob_AS1_menu3_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:206
translate chinese MLR3_Bob_AS1_menu3_2b5bbbb7:

    # MC "I like my women a bit more mature than me."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:207
translate chinese MLR3_Bob_AS1_menu3_ca18921f:

    # Dad "Ahh, you’re into MILFs. I remember I was too, at your age."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:208
translate chinese MLR3_Bob_AS1_menu3_3c23fa61:

    # Dad "I had a wonderful few encounters with a Ms. Bridgend, during my time working in Scotland. Wonderful lady - amazing skills with her mouth."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:214
translate chinese MLR3_Bob_AS1_menu3_6956eb63:

    # MC "I like them to be around my age. Maybe a couple of years on either side."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:215
translate chinese MLR3_Bob_AS1_menu3_bbe55bac:

    # Dad "That’s fair enough. A healthy attitude to have. It means you’re both of a similar level of maturity too, for relationships."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:223
translate chinese MLR3_Bob_AS1_menu3_fa87268b:

    # MC "I like my women a little bit younger than me."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:225
translate chinese MLR3_Bob_AS1_menu3_b3bf2f46:

    # Dad "A little younger? Sara’s age?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:226
translate chinese MLR3_Bob_AS1_menu3_5447f3ee:

    # MC "Yeah, around that... and she's only younger about a few months..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:227
translate chinese MLR3_Bob_AS1_menu3_d3c95506:

    # Dad "Which means she's still eighteen! Haha! But I understand you."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:229
translate chinese MLR3_Bob_AS1_menu3_50893bd1:

    # Dad "Are you thinking of dating girls around your own age?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:230
translate chinese MLR3_Bob_AS1_menu3_ee0fab58:

    # MC "Yeah, around that..."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:231
translate chinese MLR3_Bob_AS1_menu3_dfe8d06a:

    # Dad "As long as she's over eighteen, that's what matters most."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:235
translate chinese MLR3_Bob_AS1_menu3_0cecec6d:

    # Dad "I guess you can’t beat wild sex with a college student!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:236
translate chinese MLR3_Bob_AS1_menu3_45fa94d5:

    # Dad "You must be SPOILED for choice with all those girls at your college!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:242
translate chinese MLR3_Bob_AS1_menu2_cdd739cc:

    # Dad "So, what kinda hair colour do you go for in a women?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:245
translate chinese MLR3_Bob_AS1_menu2_5366b3cd:

    # MC "I’m quite fond of blondes, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:246
translate chinese MLR3_Bob_AS1_menu2_629ee209:

    # Dad "Ahh, I’m sure there’s quite a few blond girls at your college!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:247
translate chinese MLR3_Bob_AS1_menu2_e9443253:

    # MC "Yeah, there’s a couple!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:252
translate chinese MLR3_Bob_AS1_menu2_a4dd58e7:

    # MC "I’m more into brunettes."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:253
translate chinese MLR3_Bob_AS1_menu2_0abd24c9:

    # Dad "Oh yeah? Like Caroline?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:254
translate chinese MLR3_Bob_AS1_menu2_d9ab25bf:

    # MC "Wh-What?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:258
translate chinese MLR3_Bob_AS1_menu2_280b3ff2:

    # Dad "Oops! I meant Caroline’s hair colour. Sorry, that came out wrong!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:260
translate chinese MLR3_Bob_AS1_menu2_28a498db:

    # Dad "Oops! I meant Caroline’s hair colour. Sorry, that came out wrong! I know she’s one of your friends."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:261
translate chinese MLR3_Bob_AS1_menu2_1d2ec480:

    # MC "Uh, yeah, brunette like her. Maybe a bit lighter."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:267
translate chinese MLR3_Bob_AS1_menu2_52930bf2:

    # MC "Gingers and redheads are my thing."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:268
translate chinese MLR3_Bob_AS1_menu2_dce45863:

    # Dad "Ohh, like bright ginger, or more muted like Sara’s hair?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:269
translate chinese MLR3_Bob_AS1_menu2_50412c3a:

    # MC "Either. I’m not really fussy."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:274
translate chinese MLR3_Bob_AS1_menu2_7f325c71:

    # MC "I like really dark hair, almost black."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:276
translate chinese MLR3_Bob_AS1_menu2_48913939:

    # Dad "Ahh, same as me. That’s one of the many reasons I fell for your mother!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:278
translate chinese MLR3_Bob_AS1_menu2_cf1b72bf:

    # Dad "Ahh, same as me. That’s one of the many reasons I fell for my wife!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:292
translate chinese MLR3_Bob_AS1_menu_3ae7d9cf:

    # MC "Hey, [Dad_name]. Can I steal you for a minute?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:293
translate chinese MLR3_Bob_AS1_menu_b95cda67:

    # Bob "Hmm? Sure, champ. What’s up?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:294
translate chinese MLR3_Bob_AS1_menu_fc2cbfd2:

    # MC "I just got an opportunity to go to an event with the college. We need a recommendation from a local business leader. I just wanted to check if you thought it would be worthwhile, or a waste of my time?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:298
translate chinese MLR3_Bob_AS1_menu_d73daa6d:

    # Bob "A college trip, eh? What’s it for?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:299
translate chinese MLR3_Bob_AS1_menu_f49a6a0d:

    # MC "Umm... team building and leadership skills, I think."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:301
translate chinese MLR3_Bob_AS1_menu_6182ca1a:

    # Bob "Hmm, that’s a good course to be on. Employers REALLY value strong team players. I’m glad to see you’re going on this, son. You’re staying overnight as well?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:303
translate chinese MLR3_Bob_AS1_menu_04d04786:

    # Bob "Hmm... That's a wise path to follow. Employers truly appreciate individuals who excel as team players. I'm pleased to see that you're pursuing this, [player_name]. I'll be happy to provide you with my recommendation. Are you also planning to stay overnight?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:304
translate chinese MLR3_Bob_AS1_menu_ccdcb5ea:

    # MC "Yeah, we’re staying overnight and coming back the day after."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:308
translate chinese MLR3_Bob_AS1_menu_233e96e9:

    # Bob "So, is this a ‘guys only’ trip, then? Or are there gonna be a few girls there too?"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:309
translate chinese MLR3_Bob_AS1_menu_70023a37:

    # MC "I, uh... I’m not sure."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:310
translate chinese MLR3_Bob_AS1_menu_14ea0820:

    # Bob "Ahh c’mon, you can tell me!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:314
translate chinese MLR3_Bob_AS1_menu_129a7233:

    # MC "Yeah, there’s... there’s probably gonna be at least one woma- girl there too."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:315
translate chinese MLR3_Bob_AS1_menu_24c1c5aa:

    # Bob "You know, I remember going on these when I was your age. These field trips are great for hooking upp with other students. Protip: Law and Medicine majors are the freakiest!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:316
translate chinese MLR3_Bob_AS1_menu_0527732c:

    # Bob "Why, I remember cuddling up with this ginger bombshell on a bus trip to the Grand Canyon. We had this blanket over us."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:320
translate chinese MLR3_Bob_AS1_menu_b02c221c:

    # Bob "God, I must have fingiered that woman half the way there. She was trembling and shaking, trying not to moan in a bus full of her fellow students."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:321
translate chinese MLR3_Bob_AS1_menu_9d529434:

    # Bob "She was kind enough to return the favour on the way back home! Heh heh!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:322
translate chinese MLR3_Bob_AS1_menu_2b6a5186:

    # Bob "Now, where did I leave it? I could have sworn I set it down here..."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:326
translate chinese MLR3_Bob_AS1_menu_eed9a8b8:

    # Bob "Aha! Here we go! This is for you!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:327
translate chinese MLR3_Bob_AS1_menu_940e8a8c:

    # MC "What is it?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:331
translate chinese MLR3_Bob_AS1_menu_a5a3003c:

    # Bob "It’s a condom - I know what lads your age are like. Heck, I was your age once!"
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:332
translate chinese MLR3_Bob_AS1_menu_2807aacf:

    # Bob "Abstinence only sex education, is horse shit. Anyone with half a brain knows that. If anything happens, and I’m keeping my fingers crossed for you that it does, make sure you use this."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:333
translate chinese MLR3_Bob_AS1_menu_80fd7d0c:

    # MC "[Dad_name], I-"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:337
translate chinese MLR3_Bob_AS1_menu_66460ce0:

    # Bob "Go and get yourself laid, [player_name]."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:339
translate chinese MLR3_Bob_AS1_menu_50b33a10:

    # MC "What about you? Do you not need it?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:341
translate chinese MLR3_Bob_AS1_menu_35939de5:

    # Bob "Relax, I’ve got plenty. Plus, your mother is also away on some business trip. Ironically, it's the same time as yours, so I’ve got no use for it at all."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:343
translate chinese MLR3_Bob_AS1_menu_30837238:

    # Bob "Relax, I’ve got plenty. Plus, my wife is also away on some damn business trip. Ironically, it's the same time as yours, so I’ve got no use for it at all."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:347
translate chinese MLR3_Bob_AS1_menu_dce16752:

    # Bob "Oh, and before you go - remember the two rules of safe sex."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:348
translate chinese MLR3_Bob_AS1_menu_b18e7e3f:

    # Bob "One: always use protection, and two: don’t pressure someone into doing something they don’t want to do."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:349
translate chinese MLR3_Bob_AS1_menu_24e371f1:

    # Bob "If you follow those two rules, you’ll keep yourself safe. As for actually picking up chicks - a guy who looks like you should have no problem at all. Good luck, [player_name]."
    Bob ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:350
translate chinese MLR3_Bob_AS1_menu_397eae9f:

    # MC "Thanks, [Dad_name]!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:362
translate chinese MLR3_Bob_AS1_menu_8de0ccd7:

    # MC "Why were you yelling at [Mom_name]? You two aren’t planning to get divorced, are you?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:363
translate chinese MLR3_Bob_AS1_menu_65ddea96:

    # Dad "I uh... well... Oh, that’s a tough old question, isn’t it? Haha..."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:365
translate chinese MLR3_Bob_AS1_menu_6b75dca9:

    # Dad "There’s a lot of complex issues going on between your mother and me right now."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:367
translate chinese MLR3_Bob_AS1_menu_6e7ec64f:

    # Dad "There’s a lot of complex issues going on between me and my wife and me right now."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:370
translate chinese MLR3_Bob_AS1_menu_3c734d6b:

    # MC "Like what?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:371
translate chinese MLR3_Bob_AS1_menu_173eb4e9:

    # Dad "It’s... ah... bedroom stuff. Not really appropriate to talk about with you. Sorry."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:375
translate chinese MLR3_Bob_AS1_menu_49b8d9b5:

    # Dad "To answer your second question though - no. There are NO divorce plans on the table."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:376
translate chinese MLR3_Bob_AS1_menu_75754d2a:

    # Dad "We’re both mature adults and we’re going to work through this. "
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:380
translate chinese MLR3_Bob_AS1_menu_dfb6869f:

    # Dad "At least... we will when your mother finally agrees to go to mediation and therapy with me."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:382
translate chinese MLR3_Bob_AS1_menu_124f3133:

    # Dad "At least... we will when my wife finally agrees to go to mediation and therapy with me."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:383
translate chinese MLR3_Bob_AS1_menu_8d49b8f4:

    # Dad "She can be very stubborn. A real wild stallion!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:390
translate chinese MLR3_Bob_AS1_menu_7857de34:

    # MC "Could you give me some advice for finding a girlfriend? I’m worried that a girl I like isn’t interested in me."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:391
translate chinese MLR3_Bob_AS1_menu_6131d1d5:

    # Dad "Oh, so there IS a girl you like. That’s good!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:395
translate chinese MLR3_Bob_AS1_menu_2c04b97d:

    # Dad "Hmm, if she isn’t interested in you, then there really isn’t much you can do. If you’ve already tried speaking with her."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:396
translate chinese MLR3_Bob_AS1_menu_41accb0d:

    # Dad "I suppose it wouldn’t hurt, formally asking her to go out for dinner or drinks, and see how she reacts. Perhaps she just doesn’t know that you like her."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:400
translate chinese MLR3_Bob_AS1_menu_8e24263a:

    # MC "Or the cinema?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:401
translate chinese MLR3_Bob_AS1_menu_5308c3f5:

    # Dad "*Puff*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:405
translate chinese MLR3_Bob_AS1_menu_958204e0:

    # Dad "Oh, God no. The cinema is an awful first date idea. The two of you can’t speak during the movie."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:406
translate chinese MLR3_Bob_AS1_menu_eab462bd:

    # Dad "It means you never properly break the ice. Hold off on the cinema until the two of you have gone on a few dates."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:407
translate chinese MLR3_Bob_AS1_menu_04173a4a:

    # MC "Ahh, that’s good advice."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:411
translate chinese MLR3_Bob_AS1_menu_c7b0a45f:

    # Dad "If she isn’t interested in you, or doesn’t want to date... well... I’m afraid you’re just going to have to man up and move on."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:412
translate chinese MLR3_Bob_AS1_menu_1668fa4a:

    # Dad "There’s billions of women in the world. Just because the chemicals in your brain make you think she’s the one, doesn’t make it necessarily true."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:413
translate chinese MLR3_Bob_AS1_menu_72a08610:

    # MC "Thanks, [Dad_name]."
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:423
translate chinese MLR3_Bob_AS1_menu_ef2a6122:

    # MC "Why do you always smoke cigars?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:424
translate chinese MLR3_Bob_AS1_menu_5308c3f5_1:

    # Dad "*Puff*"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:428
translate chinese MLR3_Bob_AS1_menu_e5cbca60:

    # Dad "Why do you play computer games?"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:429
translate chinese MLR3_Bob_AS1_menu_d8ed3901:

    # Dad "It’s just a way for me to kick back and relax."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:433
translate chinese MLR3_Bob_AS1_menu_7b654177:

    # MC "Are you not worried that you might be addicted to nicotine?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:434
translate chinese MLR3_Bob_AS1_menu_2cf6f191:

    # Dad "Haha, there’s a MASSIVE difference between cigars and cigarettes. With cigars, you draw the smoke into your mouth, taste the flavours, and then exhale."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:435
translate chinese MLR3_Bob_AS1_menu_3573df5c:

    # Dad "I’ll let you try one, someday - these ones might be a little too strong for a first try."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:444
translate chinese MLR3_Bob_AS1_menu_5427b95a:

    # MC "What did you think of Caroline opening up her own shop?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:447
translate chinese MLR3_Bob_AS1_menu_0ee2e434:

    # Dad "I’m a capitalist, at heart. And nothing makes my heart beat prouder, than seeing my own daughter, launch her own business."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:449
translate chinese MLR3_Bob_AS1_menu_38fc868f:

    # Dad "I’m a capitalist, at heart. And nothing makes my heart beat prouder, than seeing her launch her own business."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:453
translate chinese MLR3_Bob_AS1_menu_0fec61d5:

    # Dad "Oh, I heard through the grapevine that YOU’VE been helping her."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:455
translate chinese MLR3_Bob_AS1_menu_556bb198:

    # Dad "Nice work, champ! Doing your Dad proud. You always gotta stick by your siblings. They’ll be with you longer than your mother or I will."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:457
translate chinese MLR3_Bob_AS1_menu_7189a3ca:

    # Dad "Nice work, [player_name]! Gentlemen are in such short supply nowadays - you’re doing me proud! You always gotta stick by your friends."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:470
translate chinese MLR3_Bob_AS1_menu_0b2331c4:

    # MC "How did you and [Mom_name] meet?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:472
translate chinese MLR3_Bob_AS1_menu_72caae77:

    # Dad "How did we meet? God... We met at a young business leaders conference in Vienna."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:476
translate chinese MLR3_Bob_AS1_menu_2ce07d90:

    # Dad "It was an international event for young entrepreneurs under twenty five. Your mom and I hit it off on the first night of the conference."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:478
translate chinese MLR3_Bob_AS1_menu_e842eed5:

    # Dad "It was an international event for young entrepreneurs under twenty five. Linda and I hit it off on the first night of the conference."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:479
translate chinese MLR3_Bob_AS1_menu_3b1b3170:

    # Dad "We lived on opposite sides of the country, but we kept in touch after the conference and eventually found our way back together."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:488
translate chinese MLR3_Bob_AS1_menu_783a397e:

    # MC "When did you fall in love with [Mom_name]?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:489
translate chinese MLR3_Bob_AS1_menu_88e06ff7:

    # Dad "God... that’s a tough one. It just sorta naturally evolved over time. I can’t put a specific date on it."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:490
translate chinese MLR3_Bob_AS1_menu_bfb210fe:

    # Dad "I remember the first time I told her. It was in Times Square, New York. She was holding my hand as we walked under the neon lights and flashing billboards."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:494
translate chinese MLR3_Bob_AS1_menu_a89f4925:

    # Dad "Her eyes were so beautiful. I grabbed her and spilled my heart out to her."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:495
translate chinese MLR3_Bob_AS1_menu_3262af06:

    # Dad "Turns out she felt the same way!"
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:504
translate chinese MLR3_Bob_AS1_menu_e876e3f0:

    # MC "What did you do to win [Mom_name] over?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:506
translate chinese MLR3_Bob_AS1_menu_fb7c4c80:

    # Dad "Your mother was a tough cookie, at first. I’m not gonna lie, she turned me down when I asked her out for drinks, at first."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:508
translate chinese MLR3_Bob_AS1_menu_077b6024:

    # Dad "Linda was a tough cookie, at first. I’m not gonna lie, she turned me down when I asked her out for drinks, at first."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:509
translate chinese MLR3_Bob_AS1_menu_f5aa382b:

    # Dad "It wasn’t until I saw her getting harassed by a creep, at the bar in Vienna, that things kicked off."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:510
translate chinese MLR3_Bob_AS1_menu_509965d0:

    # MC "What did you do?!"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:511
translate chinese MLR3_Bob_AS1_menu_b20d3a83:

    # Dad "I went up to him, shook his hand, and introduced myself as her boyfriend."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:512
translate chinese MLR3_Bob_AS1_menu_a29a088e:

    # Dad "The creep quickly backed down."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:513
translate chinese MLR3_Bob_AS1_menu_b9569660:

    # MC "You didn’t fight him?"
    MC ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:517
translate chinese MLR3_Bob_AS1_menu_f573d770:

    # Dad "Not everything needs to be solved with violence. You can talk people down, or just bluff them into backing off ninety nine percent of the time."
    Dad ""

# game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:518
translate chinese MLR3_Bob_AS1_menu_2853f7c7:

    # Dad "Try it sometime - life isn’t a video game where you need to go punching everyone! Haha!"
    Dad ""

translate chinese strings:

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:122
    old "Yeah, I’ve got my eye on one."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:122
    old "I’ve met a few I like."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:157
    old "Massive tits!"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:157
    old "Average sized breasts."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:157
    old "I like really small breasts, an A or B cup."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:202
    old "I like them more mature than me."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:202
    old "I like them to be around my age."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:202
    old "I like my women a little bit younger than me."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:243
    old "Blondes."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:243
    old "Brunettes."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:243
    old "Gingers."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:243
    old "Black Hair"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "{color=#00ff00}Talk about the trip.{/color}"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "Why were you yelling at [Mom_name]? Are you planning to get a divorce?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "Could you give me some advice for finding a girlfriend? I’m worried that a girl I like isn’t interested in me."
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "Why do you always smoke cigars?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "What did you think of Caroline opening up her own shop?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "How did you and [Mom_name] meet?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "When did you fall in love with [Mom_name]?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "What did you do to win [Mom_name] over?"
    new ""

    # game/scripts/home/ml_and_f_bedroom/day/scenes/MLR3_Bob_AS1.rpy:285
    old "Bye."
    new ""

