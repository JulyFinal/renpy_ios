﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:12
translate chinese SR2_AS1_label_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:25
translate chinese SR2_AS1_label_4b368e09:

    # MC "(There’s Sara! It looks like she’s deep in concentration. I wonder what could be so important?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:26
translate chinese SR2_AS1_label_b221c000:

    # MC "Hey, Sara! what are you reading?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:27
translate chinese SR2_AS1_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:28
translate chinese SR2_AS1_label_9dc0959f:

    # MC "(She didn’t seem to notice me. I’ll try again.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:29
translate chinese SR2_AS1_label_17358665:

    # MC "Hello, Sara!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:33
translate chinese SR2_AS1_label_4deb6b4e:

    # Sara "Huh? Oh! Hey, [player_name]. What’s up?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:34
translate chinese SR2_AS1_label_ceb216ef:

    # MC "What are you reading?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:35
translate chinese SR2_AS1_label_f46c442a:

    # Sara "Oh, I’m just doing some last-minute cramming for my History test."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:36
translate chinese SR2_AS1_label_9ce26e25:

    # MC "What period are you studying?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:37
translate chinese SR2_AS1_label_56223e3f:

    # Sara "Syria during the Cold War."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:38
translate chinese SR2_AS1_label_c40dd007:

    # MC "Huh, I remember doing that module. Except, it was Syria and Egypt during the Cold War."
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:42
translate chinese SR2_AS1_label_8137865d:

    # Sara "Oh shit! You’re right! I forgot about Egypt!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:43
translate chinese SR2_AS1_label_0075dd4f:

    # MC "Well, at least you’ve studied Syria. Just focus on Egypt now, and you should be fine."
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:44
translate chinese SR2_AS1_label_46a6e29b:

    # Sara "I haven’t studied ANYTHING yet! I only opened my book this morning!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:45
translate chinese SR2_AS1_label_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:49
translate chinese SR2_AS1_label_b4fdbf2e:

    # Sara "I kinda stayed up late last night playing some games. Haha..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:50
translate chinese SR2_AS1_label_ec1141d1:

    # MC "But... What about the test?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:51
translate chinese SR2_AS1_label_854a46ec:

    # Sara "I’ll be fine, right?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:52
translate chinese SR2_AS1_label_cbc42e3d:

    # MC "What was the United Arab Republic?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:56
translate chinese SR2_AS1_label_eaa2f04f:

    # Sara "Umm... Was it an ally of Syria and Egypt?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:57
translate chinese SR2_AS1_label_a1d805dd:

    # MC "It WAS Syria and Egypt. They joined together and formed a unified country for a few years."
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:61
translate chinese SR2_AS1_label_c1d77ba5:

    # Sara "Aww nuts. I’m so screwed..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:62
translate chinese SR2_AS1_label_a4d2382d:

    # MC "(This isn’t like Sara, at all! She used to be, top of her class!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:63
translate chinese SR2_AS1_label_17ed3968:

    # MC "(I guess she’s just been distracted by video games. She really needs to get back on track and focus. Hopefully she’ll pass this test.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:64
translate chinese SR2_AS1_label_3afa826a:

    # MC "Good luck, I guess. Hope it goes well for you."
    MC ""

# game/scripts/school/school_entrace/day/scenes/SR2_AS1.rpy:65
translate chinese SR2_AS1_label_49219255:

    # Sara "*Gulp* Thanks, [player_name]."
    Sara ""

