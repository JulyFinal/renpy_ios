﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:5
translate chinese judy_day_menu_v1_label_c3b1382f:

    # Judy "The Dean wants to speak with you. Please go to his office after we finish."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:24
translate chinese judy_day_scene1_v1_label_21bba4de:

    # Judy "Welcome back, [player_name]. I’m always glad to see students decide to continue their therapy."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:25
translate chinese judy_day_scene1_v1_label_afa5012a:

    # Judy "Is there anything in-particular you would like to discuss today?"
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:26
translate chinese judy_day_scene1_v1_label_4eda72a8:

    # MC "Thanks, Judy. Yeah, actually. I was wondering though... Is everything that is said in therapy confidential?"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:27
translate chinese judy_day_scene1_v1_label_4fa2fcc2:

    # Judy "Unless you’re planning to kill yourself or somebody else, then yes. It is entirely confidential."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:30
translate chinese judy_day_scene1_v1_label_8b045d2d:

    # MC "Awesome! Right, I think I’ve figured out a way to get revenge on Celia."
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:31
translate chinese judy_day_scene1_v1_label_1b80eef3:

    # Judy "Oh, really?"
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:32
translate chinese judy_day_scene1_v1_label_2175bfb7:

    # MC "I was on her computer, when I found out she has been selling top grades for THOUSANDS of dollars! She must have made at LEAST $10,000!"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:34
translate chinese judy_day_scene1_v1_label_cc5949e5:

    # MC "I’m gonna use this information to blackmail her into-"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:36
translate chinese judy_day_scene1_v1_label_8228df44:

    # MC "I had the opportunity to have fun with her, but she caught me and now SHE wants ME to subject her to a BDSM relationship!"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:39
translate chinese judy_day_scene1_v1_label_0b653bbe:

    # Judy "Okay, I’m gonna stop you right there."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:40
translate chinese judy_day_scene1_v1_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:41
translate chinese judy_day_scene1_v1_label_45f2b916:

    # Judy "This is a TERRIBLE idea."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:42
translate chinese judy_day_scene1_v1_label_5a9d7893:

    # MC "What? Why?!"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:46
translate chinese judy_day_scene1_v1_label_4da97175:

    # Judy "You can’t just walk in and blackmail her. Celia is a formidable woman. There will be consequences."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:48
translate chinese judy_day_scene1_v1_label_312585d7:

    # Judy "Celia is a formidable woman. I know she instructed you to subject her to a BDSM relationship, but she is WAAAY too much for a guy like you to handle."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:49
translate chinese judy_day_scene1_v1_label_4ccb437d:

    # MC "B-But I worked so hard to get this evidence..."
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:51
translate chinese judy_day_scene1_v1_label_06b15570:

    # Judy "You can still use it. You just need to be smart about HOW you blackmail her."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:53
translate chinese judy_day_scene1_v1_label_d9357e4d:

    # Judy "*Sgh* Fine. If you’re insisting on going through with this then you’re just going to need to be smart about how you handle Celia."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:54
translate chinese judy_day_scene1_v1_label_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:58
translate chinese judy_day_scene1_v1_label_9bcd1757:

    # Judy "You need to work in gradual steps. Begin by buying yourself a webcam. I’ll give you her Skipe address and you can anonymously blackmail her from there."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:59
translate chinese judy_day_scene1_v1_label_d7595f40:

    # Judy "It’s really important that you only push her a little bit at a time. You don’t want to scare her off or cause her to go to the police."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:61
translate chinese judy_day_scene1_v1_label_e850cf1b:

    # Judy "Build things up gradually. She’ll just end up dominating you if you try to do it in person. The safest way to start is probably by buying yourself a webcam. You can roleplay blackmailing her on that to kick things off."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:62
translate chinese judy_day_scene1_v1_label_336a97cc:

    # Judy "It’s really important that you take things gradually. You don’t want her to reverse this relationship! She already humiliated you once. I’m sure she would relish the chance to do so again."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:64
translate chinese judy_day_scene1_v1_label_183e241f:

    # MC "Good idea! But, why are you helping me?"
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:66
translate chinese judy_day_scene1_v1_label_4abfc7e6:

    # Judy "Celia voted against, giving the college support staff a pay rise at the last union conference. Let’s just say that this is my way of getting my own revenge on that, stuck-up bitch!"
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:68
translate chinese judy_day_scene1_v1_label_9d915992:

    # Judy "Celia voted against giving college support staff a pay rise at the last union conference. Let’s just say this is my way of getting my own back on her!"
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:69
translate chinese judy_day_scene1_v1_label_3115b9d5:

    # MC "Huh, I never knew that."
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:72
translate chinese judy_day_scene1_v1_label_4828e021:

    # Judy "First thing though - go and write her a letter and put it in her cabinet in the professor’s break room. You can take my envelope from the table near the door."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:73
translate chinese judy_day_scene1_v1_label_740d9260:

    # Judy "Then, create a fake webcam account, and stay logged in this evening. She should contact you."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:74
translate chinese judy_day_scene1_v1_label_e7d33dfb:

    # MC "Thanks, Judy. I really hope this works."
    MC ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:76
translate chinese judy_day_scene1_v1_label_817fa3e4:

    # Judy "Trust me, it will. Now hurry up and write your blackmail note."
    Judy ""

# game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:78
translate chinese judy_day_scene1_v1_label_4a0ed792:

    # Judy "Trust me, it will. Now hurry up and write your fake “blackmail” note. It’ll help make the fantasy feel more real for her, and she’ll enjoy it more."
    Judy ""

translate chinese strings:

    # game/scripts/school/therapist_room/day/scenes/judy_day_scene1_v1.rpy:8
    old "Talk about Celia’s been selling grades."
    new ""

