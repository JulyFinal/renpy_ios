﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:45
translate chinese macy_scene1_label_374b73b4:

    # Macy "What’s up, [player_name]?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:95
translate chinese macy_scene1_label_9108aa7e:

    # MC "(Ah! There she is! Macy. She's the kindest person in this college...)"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:96
translate chinese macy_scene1_label_bdbce380:

    # MC "(She’s was the only one who believed in me and told me that I've got a chance with Celia!)"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:98
translate chinese macy_scene1_label_e5751c61:

    # MC "Hey, Macy! What’s up?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:99
translate chinese macy_scene1_label_a2316a2e:

    # Macy "..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:100
translate chinese macy_scene1_label_9f4eeeaf:

    # MC "Macy?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:101
translate chinese macy_scene1_label_4c547983:

    # Macy "(I can hold it! I CAN HOLD IT!)"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:103
translate chinese macy_scene1_label_74a30c27:

    # Macy "Hahahahaah! I-I can't believe you actually did this! Haha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:104
translate chinese macy_scene1_label_10dee013:

    # Macy "Asking our professor- Haha! You've got balls, I must admit that! Haha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:105
translate chinese macy_scene1_label_6f4d5c48:

    # MC "Hey! You promised not to laugh about it!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:106
translate chinese macy_scene1_label_f3c4c7a7:

    # Macy "Sorry! Haha! Don’t be mad!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:108
translate chinese macy_scene1_label_7a5f3c13:

    # MC "Shut up!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:109
translate chinese macy_scene1_label_dc6c2a6e:

    # Macy "Okay, okay!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:110
translate chinese macy_scene1_label_a2316a2e_1:

    # Macy "..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:111
translate chinese macy_scene1_label_5f3a4264:

    # Macy "You even had to go and talk with a therapist! N-No it’s too much! Haha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:112
translate chinese macy_scene1_label_5340112e:

    # MC "I had enough! You know what? Fuck you! "
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:114
translate chinese macy_scene1_label_b89a447c:

    # MC "(Ehh.. This is going to be a long day..)"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:120
translate chinese macy_scene1_label_a2316a2e_2:

    # Macy "..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:121
translate chinese macy_scene1_label_2c01cf99:

    # Macy "BOO!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:122
translate chinese macy_scene1_label_20d4466d:

    # MC "I’m not sleeping."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:123
translate chinese macy_scene1_label_f0487f6f:

    # MC "Did yo-"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:124
translate chinese macy_scene1_label_7e8aa986:

    # Macy "Wait! Let me say something first."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:126
translate chinese macy_scene1_label_4d1d3a51:

    # Macy "I'm sorry. I shouldn’t have laughed at you. It was bad, I know."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:127
translate chinese macy_scene1_label_21023a35:

    # Macy "You know me! I'm not like that.. It's just.. everyone was talking about it.."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:128
translate chinese macy_scene1_label_bf3bf54b:

    # MC "Relax. It’s okay."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:130
translate chinese macy_scene1_label_1493e67f:

    # Macy "So.. Do you hate me now!?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:131
translate chinese macy_scene1_label_f2819107:

    # MC "N-No! We’re fine."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:132
translate chinese macy_scene1_label_bbbadfe2:

    # Macy "Good..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:133
translate chinese macy_scene1_label_eb26c900:

    # MC "I know now that it was stupid to even ask her that... In addition, in the college..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:135
translate chinese macy_scene1_label_5b30ebd5:

    # Macy "{size=-8}You could just ask me, moron...{/size}"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:154
translate chinese macy_q1_e9ab9fff:

    # MC "Hey Macy. How’s it going?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:158
translate chinese macy_q1_eb2c98b4:

    # Macy "Ugh, I’m bored out of my mind! I mean, King Lear? More like King..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:160
translate chinese macy_q1_2d204a49:

    # MC "..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:162
translate chinese macy_q1_0f3cca51:

    # Macy "...I was kinda hoping I’d get a natural pun there. Best I’ve got is “King Bore”, but that isn’t even funny."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:166
translate chinese macy_q1_93d0e50f:

    # Macy "How about you bail me out here before I bury myself in a grave of social awkwardness? Got any good gossip?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:168
translate chinese macy_q1_eca15b6a:

    # MC "Gossip, huh? Hmm... Well... Do you know Caroline?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:170
translate chinese macy_q1_62d308cf:

    # Macy "Nope, I don’t think so."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:172
translate chinese macy_q1_fe8bc59d:

    # MC "Dark haired girl, quite tall, run the local cosplay shop-"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:176
translate chinese macy_q1_37bcd0bf:

    # Macy "Oh yeah! I’ve been there a couple of times. I know who she is."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:178
translate chinese macy_q1_65df1503:

    # MC "Well, I’ve got a spicy little deal going on with her."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:180
translate chinese macy_q1_774e6b0b:

    # Macy "Oh? Tell me more!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:184
translate chinese macy_q1_3bdaf803:

    # MC "So, Caroline needs to model clothes for her online store. But she’s got no model and no one to take the photos."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:186
translate chinese macy_q1_8fb23d86:

    # MC "She ends up offering me a deal. She models these sexy costumes, I take the pictures, and she helps get me off in return!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:190
translate chinese macy_q1_61f33072:

    # Macy "Mmm, that’s hot! Is she a good fuck then? Tight pussy?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:194
translate chinese macy_q1_afc3ac94:

    # MC "I’ve no idea. The deal doesn’t include actual sex. Mostly just hands, thighs, and boobs. It suits me fine though."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:198
translate chinese macy_q1_f0fd802b:

    # MC "ANYWAY! Pretty awesome, right?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:200
translate chinese macy_q1_c9afac2b:

    # Macy "So, when are you going to proclaim that you love her?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:202
translate chinese macy_q1_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:204
translate chinese macy_q1_1696986a:

    # Macy "Hehe! I know you, [player_name]. You’re gonna get attached to this girl and ask her to be your girlfriend or something!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:206
translate chinese macy_q1_169e6454:

    # MC "I am not!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:208
translate chinese macy_q1_367b6706:

    # Macy "Oh really? Exhibit A - Ms. Celia."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:212
translate chinese macy_q1_6d28e7ba:

    # MC "...this is different. Caroline pays rent in the same house I live in, so I can’t-"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:214
translate chinese macy_q1_0859cc12:

    # Macy "Ahahaha! Oh my God! I thought she just worked in the cosplay store! You actually live with her as well?!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:218
translate chinese macy_q1_4f497db3:

    # MC "I... uh..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:220
translate chinese macy_q1_51d7b11a:

    # Macy "Let me tell you a golden rule - don’t sleep with your roommates. I’ve never seen it end well before."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:222
translate chinese macy_q1_3b97d6b3:

    # Macy "One of you will always want more than the other and things will get awkward."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:226
translate chinese macy_q1_ec73f0c7:

    # MC "I don’t think you understand, Macy. This is going to be great! It’s a purely transactional arrangement between Caroline and me."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:227
translate chinese macy_q1_f0f0e703:

    # MC "I take photos, she makes me cum."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:231
translate chinese macy_q1_cf2aae63:

    # Macy "And that’s ALL there is to it? You don’t have ANY feelings for her, beyond that?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:233
translate chinese macy_q1_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:237
translate chinese macy_q1_66f7dd13:

    # MC "What if I do? I’m a professional. I can be satisfied with the current arrangement."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:241
translate chinese macy_q1_eb497e07:

    # Macy "You really won’t be, [player_name]. This is gonna end with either you or Caroline getting hurt."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:243
translate chinese macy_q1_5ffccb32:

    # Macy "I really don’t want to see you get hurt, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:247
translate chinese macy_q1_4a62daf6:

    # MC "I’ll be fine, Macy. I promise. In fact, I think I’ll go and visit her cosplay store today!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:249
translate chinese macy_q1_6cfd10b4:

    # Macy " ...take care of yourself."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:251
translate chinese macy_q1_581ed409:

    # MC "Catch ya later, Macy!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:268
translate chinese macy_q2_e9f8eac6:

    # MC "Hey Macy."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:270
translate chinese macy_q2_a54e69d0:

    # Macy "Everything okay, [player_name]? You’re looking a little bit down."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:274
translate chinese macy_q2_4097527d:

    # MC "Remember that deal I told you about? The one that Caroline and I had?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:276
translate chinese macy_q2_988e18da:

    # Macy "The one I told you was a terrible idea?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:280
translate chinese macy_q2_1ea0e76c:

    # MC "Heh... I guess you did..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:282
translate chinese macy_q2_c7352949:

    # MC "Well... She ended it."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:286
translate chinese macy_q2_8e29a533:

    # Macy "Oh no! I’m sorry, [player_name]. Are you okay?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:288
translate chinese macy_q2_bda87800:

    # MC "She... *Sigh* I wanted more... she didn’t."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:295
translate chinese macy_q2_d04165a5:

    # Macy "Oof. I’m sorry, [player_name]. Is there anything I can do for you?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:296
translate chinese macy_q2_f7edcda4:

    # MC "Nah, I think I’m just going to... *Sigh* I don’t know."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:300
translate chinese macy_q2_043d71c7:

    # MC "I’ll see you later, Macy."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:303
translate chinese macy_q2_cba47e45:

    # Macy "...take care of yourself, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:310
translate chinese macy_q2_75e6ff28:

    # Macy "Oof. I’m sorry, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:312
translate chinese macy_q2_329c339e:

    # MC "...but anyway! She actually got super drunk and admitted that she was in love with me!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:314
translate chinese macy_q2_012ee628:

    # Macy "What? Really?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:316
translate chinese macy_q2_33a2c42e:

    # MC "Yep, so, we kinda rekindled things from there."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:318
translate chinese macy_q2_cf06dbf6:

    # Macy "I'm so happy for you, [player_name]. That's great news."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:322
translate chinese macy_q2_043d71c7_1:

    # MC "I’ll see you later, Macy."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:324
translate chinese macy_q2_cba47e45_1:

    # Macy "...take care of yourself, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:340
translate chinese macy_q3_ff22182d:

    # Macy "Well, you’re looking happy today!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:342
translate chinese macy_q3_6ff14d7e:

    # MC "Oh yeah! Just had the best day of my life!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:346
translate chinese macy_q3_0cdcd0b2:

    # Macy "Oh? What happened?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:348
translate chinese macy_q3_7585cee5:

    # MC "Remember Caroline?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:350
translate chinese macy_q3_29735825:

    # Macy "The woman you were taking photos of in skimpy clothing in exchange for sexual favours, who eventually broke that deal off and left you with crippling loneliness and a broken heart?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:354
translate chinese macy_q3_2d204a49:

    # MC "..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:356
translate chinese macy_q3_3a68597a:

    # MC "Yeah. That one."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:359
translate chinese macy_q3_3814c07c:

    # MC "ANYWAY! I managed to sort things out with her! We’re officially a couple now!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:363
translate chinese macy_q3_81f19bfd:

    # Macy "What?! How?! The last I heard, she had basically dumped you!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:367
translate chinese macy_q3_6a8249af:

    # MC "I just stuck around. She needed help financing her business, and I was there for her with some cash to see her through."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:369
translate chinese macy_q3_a50270c1:

    # Macy "*Cough* Simp. *Cough*"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:373
translate chinese macy_q3_0b241107:

    # MC "I heard that!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:375
translate chinese macy_q3_9be76716:

    # Macy "Hehe!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:379
translate chinese macy_q3_c3f26286:

    # MC "Anyway, it turns out she had an abusive ex-boyfriend. I ended up fighting him for her and getting back some family heirloom necklace that he stole."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:381
translate chinese macy_q3_ce478970:

    # MC "We ended up professing our love for each other and had a wonderful night together at Milfy Central Hotel."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:385
translate chinese macy_q3_aba27b8c:

    # Macy "Aww... That’s really sweet actually."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:387
translate chinese macy_q3_f1e1317a:

    # MC "I know. It turned out really well actually!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:391
translate chinese macy_q3_f33db818:

    # MC "Thanks again for taking the time to listen to my drama, Macy. It’s nice to have a friendly ear."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:393
translate chinese macy_q3_532dd666:

    # Macy "Anytime, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:410
translate chinese macy_q4_cc78edb4:

    # MC "I just fucked a girl in the ass... wait for it..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:414
translate chinese macy_q4_a2316a2e:

    # Macy "..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:418
translate chinese macy_q4_0f24ece9:

    # MC "...ON A ROOF!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:422
translate chinese macy_q4_10c14812:

    # Macy "Like... the roof of a house?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:424
translate chinese macy_q4_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:426
translate chinese macy_q4_c5f1babb:

    # Macy "You fucked a girl in the ass... on the roof of a house?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:428
translate chinese macy_q4_9a405e3d:

    # MC "Yup! That’s what I said!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:432
translate chinese macy_q4_c1054ae2:

    # Macy "Ahahaha! That never happened!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:434
translate chinese macy_q4_ec43ba42:

    # MC "I’m serious!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:436
translate chinese macy_q4_865855cc:

    # Macy "Oh c’mon! We all know you exaggerate your sexual exploits, [player_name], but this is really taking it to new HEIGHTS!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:440
translate chinese macy_q4_57ac48bb:

    # MC "I’m not exaggerating! I literally-"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:442
translate chinese macy_q4_72133cd5:

    # Macy "How did you manage to stay on the roof without falling or knocking the slates off? TILE and error?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:446
translate chinese macy_q4_fee77774:

    # MC "Heh! That was a good one. It honestly wasn’t that difficult though. Climbing up was the hardest part."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:448
translate chinese macy_q4_cf5f4d1b:

    # Macy "So, did you give her a nice, hot creampie inside her ass?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:450
translate chinese macy_q4_e78d38d7:

    # MC "Get your mind out of the GUTTER!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:454
translate chinese macy_q4_2b780a96:

    # Macy "Ahahaha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:456
translate chinese macy_q4_3c672dc8:

    # Macy "So, are you two technically a couple now? Or are you still SHINGLE?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:460
translate chinese macy_q4_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:464
translate chinese macy_q4_87d6e8b3:

    # Macy "So, who was it?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:468
translate chinese macy_q4_30cf97bd:

    # MC "(I probably shouldn’t tell Macy who it was. I don’t want gossip traveling around campus that I’m sleeping with Sara.)"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:470
translate chinese macy_q4_94002e13:

    # MC "It was a prostitute actually. I tried to pay her at the end, but she told me it was ON THE HOUSE!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:474
translate chinese macy_q4_60b470ed:

    # Macy "Hehehe! You’re hilarious, [player_name]!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:476
translate chinese macy_q4_eb2928de:

    # MC "I better head on, but it was nice chatting with you."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:480
translate chinese macy_q4_fb5cdcf9:

    # Macy "Catch you later, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:497
translate chinese macy_q5_4727ea94:

    # MC "Hey Macy. How’re you keeping?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:501
translate chinese macy_q5_291cb688:

    # Macy " Morning! I’m fine. Anything new with you?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:506
translate chinese macy_q5_60f5774e:

    # MC "Yeah actually, a pretty weird one actually. My landlady tried to kiss me."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:510
translate chinese macy_q5_050eb974:

    # Macy "Whoa! Seriously?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:512
translate chinese macy_q5_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:514
translate chinese macy_q5_bb9dc94d:

    # Macy "Like... on the lips?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:516
translate chinese macy_q5_9d70455d:

    # MC "She offered me her lip or cheek."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:520
translate chinese macy_q5_e8f41c17:

    # Macy "Is she hot?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:522
translate chinese macy_q5_2e1c59e3:

    # MC "Oh yeah, she really is. She’s a total MILF!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:526
translate chinese macy_q5_75e564fd:

    # Macy "Oh no... I realise what’s going on..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:528
translate chinese macy_q5_29930721:

    # MC "What?! What’s going on?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:530
translate chinese macy_q5_24df45be:

    # Macy "She’s your landlady, right?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:532
translate chinese macy_q5_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:536
translate chinese macy_q5_23403e86:

    # Macy "She’s just trying to get another DEPOSIT out of you! Ahahahaha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:540
translate chinese macy_q5_eab46b0c:

    # MC "Ugh... and here I was thinking you were going to be giving some helpful advice, Macy!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:542
translate chinese macy_q5_cb1f87c0:

    # Macy "Haha! You should know me better than that by now."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:547
translate chinese macy_q5_978d86e5:

    # MC "Heh, I’ll catch you later, Macy."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:551
translate chinese macy_q5_c3b5187d:

    # Macy "See ya, [player_name]. Good luck with your landlady!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:568
translate chinese macy_q6_23f3b287:

    # MC "You love juicy gossip, don’t you Macy?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:572
translate chinese macy_q6_e81182d3:

    # Macy "What have you got for me?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:576
translate chinese macy_q6_2fe8647b:

    # MC "Remember I told you about my landlady trying to kiss me?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:578
translate chinese macy_q6_af0d271b:

    # Macy "Uh huh?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:580
translate chinese macy_q6_26adabdd:

    # MC "Well, we went away for the weekend together to a beach resort."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:584
translate chinese macy_q6_f1f3e058:

    # Macy "No way! Are you serious?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:586
translate chinese macy_q6_c8032f25:

    # MC "Uh huh! Turns out she was TOTALLY into me! We’ve been hooking up behind her husband’s back."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:590
translate chinese macy_q6_4f809d02:

    # Macy "That’s crazy! Tell me more! And don’t leave out any of the details!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:594
translate chinese macy_q6_40740902:

    # MC "So, we’d been fooling around in the house, but it was risky - with her husband always being around."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:595
translate chinese macy_q6_3357b79c:

    # MC "Linda decided to take us away for the weekend to a beach resort. It was amazing. We went rock diving, ate icecream, sunbathed. And that night, we fucked like four times."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:600
translate chinese macy_q6_ddde4191:

    # Macy "Mmm... Go on."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:602
translate chinese macy_q6_9394b4ed:

    # MC "She’d rented this little holiday home. I must have fucked her twice in the bed and in the shower as well! Oh! And I forgot to mention, she’s got a body like a pornstar!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:604
translate chinese macy_q6_0f0d8e7c:

    # Macy "Mmm... That’s pretty hot. Are you not worried about her husband though?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:608
translate chinese macy_q6_df301a2b:

    # MC "I mean, a little bit, yeah."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:610
translate chinese macy_q6_dc2d5301:

    # Macy "What if he catches you?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:612
translate chinese macy_q6_aa304d2f:

    # MC "We’re being careful. It’s not gonna happen."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:616
translate chinese macy_q6_1a7bfe74:

    # Macy "I don’t know, [player_name]. It might be worth quitting while you’re still ahead."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:618
translate chinese macy_q6_b24a8899:

    # MC "I don’t think I can. This woman really, really likes me, Macy."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:622
translate chinese macy_q6_b61dcc28:

    # Macy "And do you like her too?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:624
translate chinese macy_q6_5893254a:

    # MC "Yeah... I do. She’s seductive, incredibly hot. She knows what she wants. She’s incredibly driven."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:626
translate chinese macy_q6_ca46dac7:

    # Macy "How do you see this ending? Someone’s gonna get hurt here. If not you, then definitely her husband."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:630
translate chinese macy_q6_a33085af:

    # MC "I’m just gonna have to make sure we don’t get caught, then!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:632
translate chinese macy_q6_57a432af:

    # Macy "Really? You’re going to spend the rest of your life, cheating with a married woman?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:636
translate chinese macy_q6_73275906:

    # Macy "I just... I don’t think this is going to end well for you, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:640
translate chinese macy_q6_e1e10ce5:

    # MC "Listen, Macy, I appreciate your concern. I really do. Trust me though, I’ve got this."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:642
translate chinese macy_q6_7dacc69e:

    # Macy "I’ll keep my fingers crossed for you."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:659
translate chinese macy_q7_143cb4c6:

    # MC "Got some really juicy gossip for you, Macy! Remember I told you I was sleeping with my landlady?"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:661
translate chinese macy_q7_47e59855:

    # Macy "Oh yeah? What became of that?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:665
translate chinese macy_q7_7425ed84:

    # MC "Her husband caught us!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:667
translate chinese macy_q7_75249b38:

    # Macy "Oh my God! Seriously?! What happened?!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:671
translate chinese macy_q7_0f8c16b7:

    # MC "Well, they had a huge fight and my landlady kicked him out of the house."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:673
translate chinese macy_q7_a07646a3:

    # Macy "Oof."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:675
translate chinese macy_q7_172593fc:

    # MC "On the bright side, that meant we had the place to ourselves - which was fun! We could actually have sex without worrying about getting caught."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:679
translate chinese macy_q7_7c2e37a0:

    # Macy "Huh, turned out better than expected, then!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:681
translate chinese macy_q7_0724f230:

    # MC "Oh, I haven’t even told you the juiciest part yet!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:685
translate chinese macy_q7_0f5ae11d:

    # MC "Remember I said she kicked her husband out of the house? Well, he was sitting in the garage the whole time watching us on hidden cameras!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:689
translate chinese macy_q7_170c0d0b:

    # Macy "WHAT?!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:691
translate chinese macy_q7_28081ca1:

    # MC "Yup! The guy is a major cuck!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:695
translate chinese macy_q7_d7827b8a:

    # Macy "WOW! Oh my God!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:697
translate chinese macy_q7_ad7bfe0a:

    # MC "I know, right? He ended up watching us have sex a few times. Turns out he is totally fine with me banging his wife."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:699
translate chinese macy_q7_76fb388c:

    # Macy "That’s crazy!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:703
translate chinese macy_q7_52a84f68:

    # MC "Anyway, I gotta dash on here. But it was nice chatting with you, Macy."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:705
translate chinese macy_q7_33e9bb53:

    # Macy "Catch you later, [player_name]!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:723
translate chinese macy_q8_b234c5c8:

    # MC "Morning Macy!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:725
translate chinese macy_q8_91b8fd44:

    # Macy "Morning, [player_name]. Got any juicy gossip for me today?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:729
translate chinese macy_q8_9813b428:

    # MC "I met a girl from the rough end of town. Huge tits. Like WAY bigger than yours."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:733
translate chinese macy_q8_229e64b6:

    # Macy "You’re treading on very thin ice here, [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:735
translate chinese macy_q8_713b2de2:

    # MC "Heh, sorry."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:739
translate chinese macy_q8_4b8ed7f9:

    # MC "Anyway! She’s running this massage parlor out of her house. I helped her out with a few problems she was facing, and now she’s offering me unlimited free titjobs whenever I want!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:744
translate chinese macy_q8_6e644919:

    # MC "Like, I just show up to her house and she’ll rub her breasts all over my cock. It’s amazing!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:748
translate chinese macy_q8_c9b547fb:

    # Macy "Let me guess... is she the BREAST you’ve ever had?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:750
translate chinese macy_q8_bc6e53f0:

    # MC "*Groan*"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:754
translate chinese macy_q8_2b780a96:

    # Macy "Ahahaha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:756
translate chinese macy_q8_b89941e6:

    # Macy "Did you even take this women out on a date before you started fucking her?"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:760
translate chinese macy_q8_6a358e6a:

    # MC "No, but I thought about taking her to a fancy BREASTAURANT!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:764
translate chinese macy_q8_1d58a88d:

    # Macy "Ahahahaha!"
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:766
translate chinese macy_q8_f1fb2d5e:

    # Macy "I think we’ve MILKED these puns for all they’re worth..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:770
translate chinese macy_q8_774394cb:

    # MC "Heh..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:772
translate chinese macy_q8_85dcb026:

    # MC "Tit... Boob... Nipple..."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:774
translate chinese macy_q8_cd149c18:

    # MC "Nah, I’m out of ideas."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:778
translate chinese macy_q8_7f3737c8:

    # Macy "Well, if you ever get tired of this girl and want to try someone with smaller boobs, I’m right here."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:782
translate chinese macy_q8_a43f8dc9:

    # MC "Haha! That’s a good one, Macy. You don’t need to try and catch me out with a joke, you’re one of my closest friends! I’m not gonna just start hitting on you."
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:786
translate chinese macy_q8_362b3af2:

    # Macy "Heh... Y-Yeah... I was joking..."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:790
translate chinese macy_q8_49f7c3a0:

    # MC "Right, I better head on. Bye Macy. Catch ya later!"
    MC ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:794
translate chinese macy_q8_def6cfc4:

    # Macy "Yeah... bye [player_name]."
    Macy ""

# game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:796
translate chinese macy_q8_1af7c3a7:

    # Macy "(Am I the only girl in this town not getting some action from [player_name]?)"
    Macy ""

translate chinese strings:

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about beginning of your deal with Caroline"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her the deal with Caroline"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about the Love Hotel date with Caroline"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about the roof date"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about kiss from [Mom_name]"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about the beach date with [Mom_name]"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about [Mom_name]"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Tell her about Violet"
    new ""

    # game/scripts/school/classroom1/morning/scenes/macy_scene1.rpy:46
    old "Locked: Progress more with other characters (disabled)"
    new ""

