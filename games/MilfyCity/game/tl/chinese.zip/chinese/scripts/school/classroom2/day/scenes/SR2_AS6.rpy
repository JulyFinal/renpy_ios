﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:9
translate chinese SR2_AS6_label_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:16
translate chinese SR2_AS6_label_643c7ec5:

    # MC "(I still haven't bought a lubricant.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:30
translate chinese SR2_AS6_label_710852ac:

    # MC "I finally got it, Sara. I’ll keep it in the house until later tonight."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:31
translate chinese SR2_AS6_label_3622986d:

    # Sara "Huh? What did you get? I don’t know what you’re talking about."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:32
translate chinese SR2_AS6_label_744756d6:

    # MC "The lube, Sara! Remember?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:36
translate chinese SR2_AS6_label_56da777c:

    # Sara "You actually bought lube?!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:37
translate chinese SR2_AS6_label_18d5a87c:

    # MC "(Shit! This is like the vibrator, all over again!)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:38
translate chinese SR2_AS6_label_4a13c89e:

    # MC "Shush! Keep your voice down!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:42
translate chinese SR2_AS6_label_86b1858b:

    # MC "Remember we talked about this on the roof? It’ll make things easier when we finally do it."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:43
translate chinese SR2_AS6_label_783ba5fb:

    # MC "Can I take my hand off your mouth now?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:44
translate chinese SR2_AS6_label_301b6e6e:

    # Sara "Mmm hmm."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:48
translate chinese SR2_AS6_label_5a74d527:

    # Sara "Wh-What happens now?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:49
translate chinese SR2_AS6_label_9976f62a:

    # MC "Come over to my room tonight, and we’ll try it out."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:51
translate chinese SR2_AS6_label_8704f5fd:

    # Sara "I’m scared... It was soooo painful last time."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:53
translate chinese SR2_AS6_label_fed04fee:

    # Sara "Okay... I hope this time will be a lot more pleasant... "
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:57
translate chinese SR2_AS6_label_011b75c8:

    # MC "It’ll be better this time, I promise. We weren’t properly prepared last time."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:58
translate chinese SR2_AS6_label_98a43143:

    # MC "And if it hurts you at all we’ll immediately stop. Okay?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:59
translate chinese SR2_AS6_label_12d5cb2c:

    # Sara "Okay... I guess so. I’ll see you tonight in your bedroom, then."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:60
translate chinese SR2_AS6_label_73375f75:

    # MC "I’m looking forward to it. Catch you later, Sara."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS6.rpy:75
translate chinese Sara_class_talked_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

