﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/lily_school_scene_nothing.rpy:10
translate chinese lily_school_scene_nothing_label_7b1f829e:

    # Lily "Not now, [player_name]."
    Lily ""

