﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/morning/scenes/school_entrance_intercom.rpy:14
translate chinese school_entrance_intercom_label_70b18d9a:

    # "Attention! Attention!"
    ""

# game/scripts/school/school_entrace/morning/scenes/school_entrance_intercom.rpy:16
translate chinese school_entrance_intercom_label_7804e83d:

    # "[player_name], please go to the Professor's Office. It's an emergency."
    ""

# game/scripts/school/school_entrace/morning/scenes/school_entrance_intercom.rpy:17
translate chinese school_entrance_intercom_label_ad01a7e3:

    # "I repeat - [player_name], please go to the Professor's Office! Celia is waiting there for you!"
    ""

# game/scripts/school/school_entrace/morning/scenes/school_entrance_intercom.rpy:18
translate chinese school_entrance_intercom_label_e367ea52:

    # MC "Huh? I wonder what that bit... wants from me."
    MC ""

