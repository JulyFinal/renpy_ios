﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:14
translate chinese SR2_AS2_label_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:27
translate chinese SR2_AS2_label_4e86e838:

    # MC "Hey, Sara! How’s it going?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:28
translate chinese SR2_AS2_label_3117c36a:

    # Sara "Hi, [player_name]! Not too great, to be honest."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:32
translate chinese SR2_AS2_label_0627a5d0:

    # Sara "Mom has me up, at the crack of dawn, for college. And then, as soon as I get home, she’s making me work ALL evening!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:34
translate chinese SR2_AS2_label_4de12d2f:

    # Sara "Linda has me up, at the crack of dawn, for college. And then, as soon as I get home, she’s making me work ALL evening!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:35
translate chinese SR2_AS2_label_c25b507b:

    # Sara "I can’t STAND reading any more of these textbooks! It’s driving me mad!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:47
translate chinese SR2_AS2_menu_bb7acd65:

    # MC "Maybe you should have studied, instead of playing video games?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:50
translate chinese SR2_AS2_menu_c825e1c4:

    # Sara "Uuuggghhh.... Not you too!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:52
translate chinese SR2_AS2_menu_da36f94d:

    # Sara "That’s EXACTLY what Mom said."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:54
translate chinese SR2_AS2_menu_eeeaa43d:

    # Sara "That’s EXACTLY what Linda said."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:55
translate chinese SR2_AS2_menu_bba56eb1:

    # MC "Maybe she’s right?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:56
translate chinese SR2_AS2_menu_1c168d40:

    # Sara "God... I’m so stupid! Stupid, stupid, Sara!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:57
translate chinese SR2_AS2_menu_92db2cc9:

    # MC "(Gee, she’s beating herself up, pretty hard about this.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:61
translate chinese SR2_AS2_menu_83251600:

    # MC "(I have to comfort her - I can’t stand seeing her like this.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:62
translate chinese SR2_AS2_menu_c7a7aed1:

    # MC "Hey, don’t worry. You’ll be back on track with your studies in no time!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:63
translate chinese SR2_AS2_menu_e7da9739:

    # MC "You’re one of the smartest people I know. We just need to get you back in the saddle. Then you’ll be top of your courses again!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:67
translate chinese SR2_AS2_menu_af9db03e:

    # Sara "Thanks, I appreciate you saying that."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:68
translate chinese SR2_AS2_menu_b6c41bf1:

    # Sara "Whenever I get my grades back up, we'll play some more video games together. Deal?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:69
translate chinese SR2_AS2_menu_2543de57:

    # MC "Deal."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:79
translate chinese SR2_AS2_menu_bd427958:

    # MC "Have you tried speaking to Mom about getting some freedoms back?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:80
translate chinese SR2_AS2_menu_2b15c846:

    # MC "Maybe she’d ease up and give you a break, for a change?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:84
translate chinese SR2_AS2_menu_50636ced:

    # Sara "Nah, I tried that already. I practically BEGGED her to let me have an hour of ‘me time’ before I went to bed."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:85
translate chinese SR2_AS2_menu_e2a0879d:

    # MC "How’d that go?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:86
translate chinese SR2_AS2_menu_b84c793a:

    # Sara "Disastrously. I’ve never seen her so furious before."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:87
translate chinese SR2_AS2_menu_b557f980:

    # MC "(Well, Sara did kinda bring it on, herself.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:98
translate chinese SR2_AS2_menu_479891de:

    # MC "Have you tried speaking to Linda? Can you maybe suggest she tries something less harsh?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:99
translate chinese SR2_AS2_menu_2b15c846_1:

    # MC "Maybe she’d ease up and give you a break, for a change?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:103
translate chinese SR2_AS2_menu_cfd66758:

    # Sara "Nah, I tried that already. No dice."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:104
translate chinese SR2_AS2_menu_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:105
translate chinese SR2_AS2_menu_b84c793a_1:

    # Sara "Disastrously. I’ve never seen her so furious before."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:106
translate chinese SR2_AS2_menu_b557f980_1:

    # MC "(Well, Sara did kinda bring it on, herself.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:115
translate chinese SR2_AS2_menu_5595bea5:

    # MC "Do you have ANY free time, at all, right now?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:116
translate chinese SR2_AS2_menu_a7020dd1:

    # Sara "If you count my break and lunch at college, then yeah, I have a total of forty five minutes."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:117
translate chinese SR2_AS2_menu_4d49d017:

    # MC "Aww, jeez."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:121
translate chinese SR2_AS2_menu_f73ea0f2:

    # Sara "I know. It sucks!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:122
translate chinese SR2_AS2_menu_82b053f5:

    # Sara "The worst part of it is - my friends are all going out and having fun! I’m stuck in the house with my books and coursework!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:123
translate chinese SR2_AS2_menu_e584702c:

    # MC "Umm... Didn’t you spend most nights in the house, anyway - playing video games?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:127
translate chinese SR2_AS2_menu_3ba750e6:

    # Sara "That’s... not relevant."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:128
translate chinese SR2_AS2_menu_f923323f:

    # MC "(I’m pretty sure it’s VERY relevant. No point in arguing with her, right now though. She’s learning a painful lesson.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:130
translate chinese SR2_AS2_menu_4a9c46db:

    # MC "Fine. Just try and make the most of it, to get your grades back to the high A’s again. Okay? If not for Mom, then do it for me."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:132
translate chinese SR2_AS2_menu_56241e5f:

    # MC "Fine. Just try and make the most of it, to get your grades back to the high A’s again. Okay? If not for Linda, then do it for me."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:136
translate chinese SR2_AS2_menu_adb85793:

    # Sara "It’s really exhausting! But I’ll try."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:137
translate chinese SR2_AS2_menu_e289ce74:

    # MC "Thanks, Sara."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:148
translate chinese SR2_AS2_cantinue_17e1b277:

    # MC "I guess I’ll catch you later, then."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:149
translate chinese SR2_AS2_cantinue_372955e8:

    # Sara "Wait - before you go... Can I sneak over to your room tonight?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:151
translate chinese SR2_AS2_cantinue_abfeb5ae:

    # MC "Will Mom allow that? I thought you were grounded."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:153
translate chinese SR2_AS2_cantinue_6bd37088:

    # MC "Well... I mean... But, what about your studies?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:157
translate chinese SR2_AS2_cantinue_1bc90dc6:

    # Sara "I am. That’s why I said SNEAK!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:159
translate chinese SR2_AS2_cantinue_6c4639ed:

    # Sara "I promise to finish everything I'm planning for today before coming to you!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:160
translate chinese SR2_AS2_cantinue_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:161
translate chinese SR2_AS2_cantinue_fd1cb416:

    # Sara "I wanted to talk with you about... some things that I can't... say out loud in class."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:163
translate chinese SR2_AS2_cantinue_ea85296d:

    # MC "No problem. Come over whenever you’re free. Just make sure that Mom doesn’t see you!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:165
translate chinese SR2_AS2_cantinue_605f748f:

    # MC "Then, no problem. Come over whenever you’re free! Just remember about your promise."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:166
translate chinese SR2_AS2_cantinue_1b8d34aa:

    # Sara "Cool! Catch you later."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:167
translate chinese SR2_AS2_cantinue_08639f8e:

    # MC "See ya!"
    MC ""

translate chinese strings:

    # game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:44
    old "Maybe you should have just studied, instead of playing video games?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:44
    old "Have you tried speaking to Mom about giving you some freedom again?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:44
    old "Have you tried speaking to Linda?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS2.rpy:44
    old "Do you have ANY free time?"
    new ""

