﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/teacher_room1/morning/scenes/celia_work_in_progress.rpy:9
translate chinese celia_work_in_progress_v1_label_f97f88b2:

    # Celia "Meet me at my home at night."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_work_in_progress.rpy:22
translate chinese celia_waitR2_ec37bed5:

    # Celia "Not now, [player_name]."
    Celia ""

