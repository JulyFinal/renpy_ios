﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:5
translate chinese celia_morning_laptopv1_label_2cacbde3:

    # MC "(That's Celia's computer. I wonder if she hides something there.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:8
translate chinese celia_morning_laptopv1_label_43f1a128:

    # MC "(I wonder where she has hidden the password. Perhaps in a locker or in a sealed room?)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:13
translate chinese celia_morning_laptopv1_label_722e2c67:

    # MC "(Yes! The password was accepted!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:14
translate chinese celia_morning_laptopv1_label_15af9932:

    # MC "(Let’s see if I can embarrass her in any way!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:17
translate chinese celia_morning_laptopv1_label_308eb198:

    # MC "(Fuck! The password is wrong.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:29
translate chinese celia_morning_password_correct_v1_ff37be84:

    # MC "(Let’s see... grades? Emails? Course content guides?)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:30
translate chinese celia_morning_password_correct_v1_abcacdbe:

    # MC "(Maybe the emails have something interesting in them...)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:31
translate chinese celia_morning_password_correct_v1_1929e243:

    # MC "(Course planning... Parent-Professor meetings... Ugh... it’s all boring rubbish.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:32
translate chinese celia_morning_password_correct_v1_9c6f3a54:

    # MC "(I guess I could just boost my grades, while I’m here.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:35
translate chinese celia_morning_password_correct_v1_a355d356:

    # MC "(Wait... Hold up! This isn’t a grades recording folder!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:36
translate chinese celia_morning_password_correct_v1_2b87fce9:

    # MC "(Maddox $2000? England $4400?)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:37
translate chinese celia_morning_password_correct_v1_cff52b5a:

    # MC "(No way! Is Ms. Celia SELLING grades?!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:41
translate chinese celia_morning_password_correct_v1_53a6153d:

    # MC "(YES! This is top quality blackmail material!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:44
translate chinese celia_morning_password_correct_v1_a08d6342:

    # MC "(YES! This is top quality material!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:45
translate chinese celia_morning_password_correct_v1_59dd0916:

    # MC "(She won’t be picking on me anymore, now that I have this!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:46
translate chinese celia_morning_password_correct_v1_5c9fb9f1:

    # MC "(I better take a photo quickly.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:51
translate chinese celia_morning_password_correct_v1_90a5a5c6:

    # MC "(And... there we go. I’ll need to come up with a solid plan, but at least I have all the evidence I’ll ever need.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:54
translate chinese celia_morning_password_correct_v1_841194c7:

    # MC "(Watch out, Ms. Celia, because I’m coming for you!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:59
translate chinese celia_morning_password_correct_v1_98a2e65c:

    # MC "(I can’t believe Ms. Celia is selling grades for cash! This is the kind of scandal which could end a career and bring the whole college into disrepute!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:60
translate chinese celia_morning_password_correct_v1_98278413:

    # MC "(I have to speak with Judy about this. She’ll know what to do. Maybe I could even use this information as leverage to stop Ms. Celia from humiliating me again?)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:61
translate chinese celia_morning_password_correct_v1_192ed8a3:

    # Celia "(Hmm... Where are you up to, [player_name]?)"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:63
translate chinese celia_morning_password_correct_v1_4285a508:

    # MC "Once I turn this picture over to Judy, I’ll make sure that Ms. Celia never treats me like crap again. That’ll teach her for selling grades."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:64
translate chinese celia_morning_password_correct_v1_82503b08:

    # Celia "(Ahh, so that’s his plan. Well, if that’s what the little twerp has planned then I guess I’ll just play along.)"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:66
translate chinese celia_morning_password_correct_v1_b4dea01b:

    # Celia "So, you’ve found my little side-business then, have you?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:67
translate chinese celia_morning_password_correct_v1_ac18df6b:

    # MC "H-Huh?!"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:68
translate chinese celia_morning_password_correct_v1_bae1980d:

    # MC "(N-No way? She was right behind me the whole time?!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:70
translate chinese celia_morning_password_correct_v1_0d751c35:

    # Celia "You have been a busy boy, haven’t you? Sneaking around, breaking into my office, hacking into my computer. Some might call that behaviour obsessive."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:71
translate chinese celia_morning_password_correct_v1_c7e64b15:

    # MC "M-Ms. Celia, I-"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:73
translate chinese celia_morning_password_correct_v1_8a7b9beb:

    # Celia "You’re planning to tell Judy about my little enterprise, aren't you?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:74
translate chinese celia_morning_password_correct_v1_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:75
translate chinese celia_morning_password_correct_v1_19ad58dc:

    # Celia "Well, how about setting some ground rules before you dig your own grave any deeper."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:77
translate chinese celia_morning_password_correct_v1_313ff6dc:

    # Celia "You are forbidden from talking to anyone about what you found on my computer. No chatting to your other professors, no talking to Judy, and no gossiping with your fellow students."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:78
translate chinese celia_morning_password_correct_v1_3f92138d:

    # MC "Wh-What do I get out of this?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:79
translate chinese celia_morning_password_correct_v1_9660b1c8:

    # Celia "In exchange for keeping your mouth shut, I will... permit you to have some fun with me."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:80
translate chinese celia_morning_password_correct_v1_32182962:

    # MC "Fun?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:82
translate chinese celia_morning_password_correct_v1_dcc12abb:

    # Celia "Yeah, fun. I will let you tease me, boss me around, partake in your fantasies. Truth be told, I do quite enjoy a bit of roleplay."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:83
translate chinese celia_morning_password_correct_v1_1e81afbe:

    # MC "R-Really?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:84
translate chinese celia_morning_password_correct_v1_559560e9:

    # Celia "Really. But this offer is predicated entirely on your capacity to keep your mouth shut about what you saw."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:86
translate chinese celia_morning_password_correct_v1_aee8499c:

    # Celia "Do you think you can do that for me, [player_name]?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:87
translate chinese celia_morning_password_correct_v1_4c71e276:

    # MC "Y-Yeah, I can."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:88
translate chinese celia_morning_password_correct_v1_6139e04a:

    # MC "(I can probably make this work to my advantage.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:90
translate chinese celia_morning_password_correct_v1_276b1c41:

    # Celia "So, you aren’t going to be talking to Judy about any of this, are you?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:91
translate chinese celia_morning_password_correct_v1_a99f00b8:

    # MC "No."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:92
translate chinese celia_morning_password_correct_v1_569f9d78:

    # Celia "Mmm... Good boy. That was a smart decision you just made."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:94
translate chinese celia_morning_password_correct_v1_3ff692c1:

    # Celia "I should add though, I am fairly experienced with BDSM. I trust that you’ll be making proper efforts to... satisfy me."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:95
translate chinese celia_morning_password_correct_v1_c4bdf612:

    # Celia "If you were to be a disappointing partner, well... let’s just say the embarrassment you felt at my rejection will pale in comparison to what I will put you through. Understand?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:97
translate chinese celia_morning_password_correct_v1_52352c24:

    # MC "Yeah, I got it."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:98
translate chinese celia_morning_password_correct_v1_c9805825:

    # Celia "Good."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:99
translate chinese celia_morning_password_correct_v1_cfcb1084:

    # MC "(Christ, she is one scary lady. I’m really gonna have to make an effort on this.)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:101
translate chinese celia_morning_password_correct_v1_d9da11d6:

    # Celia "Now, how about you walk away from here and start planning something fun for the two of us?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:102
translate chinese celia_morning_password_correct_v1_94172429:

    # Celia "And, for your own sake, try to be a little bit creative. If your idea of BDSM is showing up to my office with a flimsy rope and spanking paddle, then don’t even bother."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:103
translate chinese celia_morning_password_correct_v1_a95ff44b:

    # MC "C-Can you give me some hints?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:105
translate chinese celia_morning_password_correct_v1_f3e9350d:

    # Celia "*Whispered* You want a hint? Hmm..."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:106
translate chinese celia_morning_password_correct_v1_648104d7:

    # Celia "*Whispered* I’ve always wanted to try out a glory hole. I’ve never had the opportunity though. How about you arrange that for us?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:107
translate chinese celia_morning_password_correct_v1_d85af51b:

    # MC "Okay, I can do that."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:109
translate chinese celia_morning_password_correct_v1_1be95f7d:

    # Celia "*Whispered* Good boy. Now, I have to get back to class, and so do you."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:110
translate chinese celia_morning_password_correct_v1_ce8e838c:

    # Celia "*Whispered* I’m going to turn around and walk away, then you’re going to do the same. You’re never going to bring up my side job ever again, okay?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:111
translate chinese celia_morning_password_correct_v1_ba0ba84c:

    # MC "Got it..."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:113
translate chinese celia_morning_password_correct_v1_dc4728fa:

    # Celia "Don’t look so down, [player_name]. It was a good plan to speak to Judy - my plan was MUCH better though."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:114
translate chinese celia_morning_password_correct_v1_7fa4a1fb:

    # Celia "You and I are going to have a lot of fun together. Don’t view this as a ‘loss’, think of it as an exciting new beginning."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:115
translate chinese celia_morning_password_correct_v1_27449049:

    # Celia "I mean, you did ask me out - getting the opportunity to fuck me IS what you wanted, after all."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_morning_laptop.rpy:116
translate chinese celia_morning_password_correct_v1_5aca997a:

    # MC "(Yeah, I guess she’s right... but... Judy is... I don’t know.)"
    MC ""

