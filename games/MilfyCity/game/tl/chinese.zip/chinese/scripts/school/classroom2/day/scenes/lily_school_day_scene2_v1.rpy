﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:19
translate chinese lily_school_day_scene2_v1_label_57099fa5:

    # Lily "Ooh! Hi there, [player_name]. Did you come all the way over here, just to visit me?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:20
translate chinese lily_school_day_scene2_v1_label_3336647a:

    # MC "Hey, Lily. I was passing by, so I thought I’d drop in to say hi."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:21
translate chinese lily_school_day_scene2_v1_label_4f987349:

    # Lily "I’m very glad that you came by. Things were getting a little boring - and things are always so much more fun when you’re about."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:24
translate chinese lily_school_day_scene2_v1_label_0c4c8523:

    # MC "Haha! I guess I’ll take that as a compliment."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:26
translate chinese lily_school_day_scene2_v1_label_cc6c9bed:

    # Lily "How’s your sister? Has she recovered from her freakout, the other day?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:28
translate chinese lily_school_day_scene2_v1_label_aa53d982:

    # Lily "How’s Sara? Has she recovered from her freakout, the other day?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:29
translate chinese lily_school_day_scene2_v1_label_52f71834:

    # MC "Freakout?"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:30
translate chinese lily_school_day_scene2_v1_label_4fdbe622:

    # Lily "Yeah - when she threw the bottle across the room."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:31
translate chinese lily_school_day_scene2_v1_label_2c304465:

    # MC "Oh! Right! Yeah, she’s calmed down now."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:32
translate chinese lily_school_day_scene2_v1_label_ba44aaf5:

    # Lily "Good to hear."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:35
translate chinese lily_school_day_scene2_v1_label_3be77fc0:

    # Lily "Whoops! Silly me - I’ve gone and dropped my pen."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:36
translate chinese lily_school_day_scene2_v1_label_156b04be:

    # Lily "You couldn’t bend down and pick it up for me, could you?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:41
translate chinese lily_school_day_scene2_v1_label_3aa99e02:

    # MC "Yeah, no problem, Lily."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:42
translate chinese lily_school_day_scene2_v1_label_88964233:

    # MC "(There it is there. I wonder why she didn’t just bend down to pick it up herself though!)"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:45
translate chinese lily_school_day_scene2_v1_label_60a3c68d:

    # MC "(Holy shit!)"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:46
translate chinese lily_school_day_scene2_v1_label_6d2d197e:

    # MC "(Lily’s spreading her legs on purpose! I can see right up to her panties.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:47
translate chinese lily_school_day_scene2_v1_label_ac182fb5:

    # Lily "Ahem!"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:48
translate chinese lily_school_day_scene2_v1_label_1292b001:

    # MC "(Uh oh...)"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:51
translate chinese lily_school_day_scene2_v1_label_4916865e:

    # Lily "Did you find my pen down there? Or did something else... distract you?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:52
translate chinese lily_school_day_scene2_v1_label_dfe7aa2e:

    # MC "N-No! I got it here."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:53
translate chinese lily_school_day_scene2_v1_label_82414128:

    # Lily "Cool... So, are you coming back up, then?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:54
translate chinese lily_school_day_scene2_v1_label_9d7e733a:

    # MC "Uh, yeah!"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:57
translate chinese lily_school_day_scene2_v1_label_ca090a54:

    # MC "I better head on out of here. But I’ll see you around, Lily."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:58
translate chinese lily_school_day_scene2_v1_label_f1e184bb:

    # Lily "See ya later, [player_name]."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:64
translate chinese lily_school_day_scene2_v1_label_819a7153:

    # MC "Oh look! It rolled under your side of the table. I think it’ll be easier for you to pick it up."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:65
translate chinese lily_school_day_scene2_v1_label_ecef0d60:

    # Lily "Huh?"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:66
translate chinese lily_school_day_scene2_v1_label_58ab995e:

    # MC "Look - it’s just down on your side of the desk."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:67
translate chinese lily_school_day_scene2_v1_label_8605213a:

    # Lily "(Does he not understand? I’m TRYING to show him my panties!)"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:69
translate chinese lily_school_day_scene2_v1_label_b2aaa206:

    # Lily "(Is he seriously this dense?! I’m giving him the PERFECT opportunity! Dozens of guys in this college would KILL to be able to see up my skirt!)"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:70
translate chinese lily_school_day_scene2_v1_label_47bf8605:

    # MC "Anyway, I better head on out of here. Things to do! I’ll catch you later, Lily."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:71
translate chinese lily_school_day_scene2_v1_label_4a9a0d1c:

    # Lily "Grr... See you later."
    Lily ""

translate chinese strings:

    # game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:38
    old "Bend down and pick up the pen."
    new ""

    # game/scripts/school/classroom2/day/scenes/lily_school_day_scene2_v1.rpy:38
    old "Refuse to pick up the pen."
    new ""

