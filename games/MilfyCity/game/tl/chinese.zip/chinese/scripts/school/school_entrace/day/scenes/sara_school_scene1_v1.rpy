﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:15
translate chinese sis_nerdy_school_scene1_v1_label_3ac27868:

    # MC "(There she is! I wonder what she’s doing out here by herself.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:16
translate chinese sis_nerdy_school_scene1_v1_label_35a8b072:

    # MC "Hi, Sara. Are you busy right now?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:19
translate chinese sis_nerdy_school_scene1_v1_label_e9f26221:

    # Sara "Oh! Hey there!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:20
translate chinese sis_nerdy_school_scene1_v1_label_229b7396:

    # Sara "I’m ALMOST finished this chapter - then I can drop my notes in to Dr. Roberts and head home."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:21
translate chinese sis_nerdy_school_scene1_v1_label_309c0f45:

    # MC "Great! See you soon."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:30
translate chinese sis_nerdy_school_scene1_v1_label_ee58181c:

    # MC "Heya, Sara. Ready to go?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:31
translate chinese sis_nerdy_school_scene1_v1_label_f6e1dac4:

    # Sara "Not yet. I’ll let you know when I’m free."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:34
translate chinese sis_nerdy_school_scene1_v1_label_87cf57e8:

    # Sara "I might be a while, so go and find something to do."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:35
translate chinese sis_nerdy_school_scene1_v1_label_a871987c:

    # MC "Fine, catch you later."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:36
translate chinese sis_nerdy_school_scene1_v1_label_00e2d772:

    # Sara "See ya!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:46
translate chinese sis_nerdy_school_scene1_v1_label_0d10a79c:

    # MC "Hi Sara, what’s up? Ready to go?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:49
translate chinese sis_nerdy_school_scene1_v1_label_4ccdce50:

    # Sara "Not quite yet. I’ve still got Chemistry class. I’ll be free after that though."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:50
translate chinese sis_nerdy_school_scene1_v1_label_ef606c46:

    # MC "Okay, I’ll see you back home."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:58
translate chinese sis_nerdy_school_scene1_v1_label_002183a0:

    # Sara "*Mumbling* ...and then take the square root... gets us... 12.806..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:59
translate chinese sis_nerdy_school_scene1_v1_label_4a1cbe56:

    # MC "Maths today?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:60
translate chinese sis_nerdy_school_scene1_v1_label_64a3ef37:

    # Sara "Ugh, yeah. This is melting my brain!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:63
translate chinese sis_nerdy_school_scene1_v1_label_b2054437:

    # MC "I take it you’re not ready to come home yet?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:64
translate chinese sis_nerdy_school_scene1_v1_label_70b5cf15:

    # Sara "Give me another hour or so to crank out this Maths coursework."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:65
translate chinese sis_nerdy_school_scene1_v1_label_381f9b22:

    # MC "Why do you keep using the corridor instead of the library?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:66
translate chinese sis_nerdy_school_scene1_v1_label_cb6efc0e:

    # Sara "The library’s too quiet - I need background noise to concentrate."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:67
translate chinese sis_nerdy_school_scene1_v1_label_f0ba4af4:

    # MC "Do you at least want a chair?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:68
translate chinese sis_nerdy_school_scene1_v1_label_b48b31c3:

    # Sara "Nah, I’m comfy like this. Catch you later, [player_name]."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:69
translate chinese sis_nerdy_school_scene1_v1_label_5700a8c6:

    # MC "See ya, Sara."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:76
translate chinese sis_nerdy_school_scene1_v1_label_ab9a6ce9:

    # MC "Hey there, sexy."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:79
translate chinese sis_nerdy_school_scene1_v1_label_385618ee:

    # Sara "Shush! Y-You can’t say stuff like that in public!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:84
translate chinese sis_nerdy_school_scene1_v1_label_6e6ae745:

    # MC "Can’t say stuff like what? Like how absolutely gorgeous you are?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:85
translate chinese sis_nerdy_school_scene1_v1_label_c710ac86:

    # Sara "(Oooh... I get so wet when he compliments me like that...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:86
translate chinese sis_nerdy_school_scene1_v1_label_5568689b:

    # Sara "J-Just save it for when we get home... I don’t want anyone else to see..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:87
translate chinese sis_nerdy_school_scene1_v1_label_ceaa1616:

    # MC "I’ll see you later on then... beautiful."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:88
translate chinese sis_nerdy_school_scene1_v1_label_c3b6a884:

    # Sara "[player_name]! Haha!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:95
translate chinese sis_nerdy_school_scene1_v1_label_ea0a5d8c:

    # MC "Yeah, you’re probably right. I won’t say it anymore."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:96
translate chinese sis_nerdy_school_scene1_v1_label_a70e0bd9:

    # Sara "I... I didn’t tell you... to not say it anymore... Just not in public."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:97
translate chinese sis_nerdy_school_scene1_v1_label_746446ef:

    # MC "Oh, so you want me to keep telling you that you’re stunningly beautiful?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:98
translate chinese sis_nerdy_school_scene1_v1_label_28a16d60:

    # Sara "(Hehe!) N-No... I didn’t say that either..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:99
translate chinese sis_nerdy_school_scene1_v1_label_e7fb7d3c:

    # MC "I’ll see you when you get home."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:100
translate chinese sis_nerdy_school_scene1_v1_label_87e8f7eb:

    # Sara "See ya then!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:110
translate chinese sis_nerdy_school_scene1_v1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

translate chinese strings:

    # game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:81
    old "Flatter her."
    new ""

    # game/scripts/school/school_entrace/day/scenes/sara_school_scene1_v1.rpy:81
    old "Don’t embarrass her in college."
    new ""

