﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:15
translate chinese SR2_AS5_label_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:29
translate chinese SR2_AS5_label_cad4da82:

    # Sara "Haha!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:30
translate chinese SR2_AS5_label_f6ee8cbb:

    # MC "(It’s nice to see her laughing for a change. I wonder what she’s reading.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:31
translate chinese SR2_AS5_label_50d982bb:

    # Sara "Aries... You will..."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:35
translate chinese SR2_AS5_label_ac60baf4:

    # MC "Hey, Sara! What’s up?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:36
translate chinese SR2_AS5_label_53da0fd2:

    # Sara "Hey..."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:37
translate chinese SR2_AS5_label_dc14a78c:

    # MC "What are you reading, there?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:38
translate chinese SR2_AS5_label_4eadda9d:

    # Sara "Just some silly rubbish."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:42
translate chinese SR2_AS5_label_77564545:

    # MC "Let me see."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:43
translate chinese SR2_AS5_label_d83f5200:

    # Sara "Trust me, you won’t be interested in it."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:44
translate chinese SR2_AS5_label_2111355e:

    # MC "Does that say ‘Zodiac Signs’?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:48
translate chinese SR2_AS5_label_d0d312b8:

    # Sara "Yeah, it’s all about predicting who you should matched with, based on your star sign."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:49
translate chinese SR2_AS5_label_5399c774:

    # MC "I didn’t know you were into astrology and the star signs."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:50
translate chinese SR2_AS5_label_68734901:

    # Sara "It’s not so much the star sign part of things... I don’t really believe that nonsense. It’s just a silly bit of fun."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:51
translate chinese SR2_AS5_label_1dd58eba:

    # MC "Why are you reading it, then?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:55
translate chinese SR2_AS5_label_ffcc47eb:

    # Sara "Honestly? It’s going to be a really clear night sky, for the next few days..."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:56
translate chinese SR2_AS5_label_c620326d:

    # Sara "I kinda wanted to go stargazing with you at the town tower."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:57
translate chinese SR2_AS5_label_2aa28062:

    # MC "Aww, that’s so sweet. I’d love to go."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:61
translate chinese SR2_AS5_label_eea1b7be:

    # Sara "It doesn’t matter. It isn’t happening anymore."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:62
translate chinese SR2_AS5_label_9e03f56a:

    # MC "Huh? Why?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:64
translate chinese SR2_AS5_label_39c7d849:

    # Sara "Mom grounded me, remember? I’m not allowed to leave the house."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:66
translate chinese SR2_AS5_label_2a589b51:

    # Sara "I have to study and improve my grades, remember? I have even small amount of time for myself at night."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:72
translate chinese SR2_AS5_label_d37a5f9e:

    # MC "How about we go up onto the garage roof together and watch the stars at home?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:76
translate chinese SR2_AS5_label_f8f6ff05:

    # Sara "Are you serious?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:77
translate chinese SR2_AS5_label_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:78
translate chinese SR2_AS5_label_4bec79a1:

    # Sara "Yes! Yes! Yes! Let’s do it! I’m so excited!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:85
translate chinese SR2_AS5_label_bf298926:

    # MC "I’m sorry, Sara. We’re just going to have to wait until you’re not grounded anymore."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:87
translate chinese SR2_AS5_label_0bed7bcf:

    # MC "It’s okay Sara. I’ll wait until you finish catching up on your studies and then we’ll watch the stars together some other day."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:88
translate chinese SR2_AS5_label_bb9da425:

    # MC "I promise, we’ll go to the town tower together someday to watch the stars."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:89
translate chinese SR2_AS5_label_07c34aaf:

    # Sara "(Sigh...)"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:93
translate chinese SR2_AS5_label_79f764bc:

    # Sara "Actually, hold on! I’ve got an idea!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:94
translate chinese SR2_AS5_label_db770d02:

    # Sara "How about we climb up onto the garage roof tonight and watch the stars from there?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:95
translate chinese SR2_AS5_label_c421126b:

    # MC "Yeah! That’s a great idea!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:102
translate chinese SR2_AS5_continue_41134945:

    # Sara "This is going to be amazing! I can’t wait! I’m so excited!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:103
translate chinese SR2_AS5_continue_1a57dc9b:

    # MC "Where do you want to meet?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:105
translate chinese SR2_AS5_continue_72fbd05f:

    # Sara "I’ll sneak out of my bedroom after Mom goes to sleep. Then we’ll meet up at the garage?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:107
translate chinese SR2_AS5_continue_ce6525bc:

    # Sara "I'll make a list and finish studying for today earlier. Then we'll meet up at the garage."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:108
translate chinese SR2_AS5_continue_dccffa0c:

    # MC "Sounds great! I’ll see you there tonight."
    MC ""

translate chinese strings:

    # game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:68
    old "How about we go up onto the garage roof together and watch the stars at home?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS5.rpy:68
    old "It’s okay Sara. I’ll wait until you finish catching up on your studies and then we’ll watch the stars together some other day."
    new ""

