﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/morning/scenes/school_lockerv1.rpy:24
translate chinese empty_envelope_pen_usev1_label_d9e82080:

    # MC "I could use those pens to write that empty envelope."
    MC ""

# game/scripts/school/school_entrace/morning/scenes/school_lockerv1.rpy:33
translate chinese empty_envelope_pen_usev1_label_899812af:

    # MC "(Okay.. Let’s write it, just as we planned, Judy.)"
    MC ""

# game/scripts/school/school_entrace/morning/scenes/school_lockerv1.rpy:45
translate chinese empty_envelope_pen_usev1_label_c016af63:

    # MC "That's my pens."
    MC ""

