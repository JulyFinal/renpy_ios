﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/lily_work_in_progress_v1.rpy:7
translate chinese lily_work_in_progress_v1_label_ecbcb805:

    # "(I've already talked with her.)"
    ""

