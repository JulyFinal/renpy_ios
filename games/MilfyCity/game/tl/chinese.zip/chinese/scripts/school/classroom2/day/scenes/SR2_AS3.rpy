﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:12
translate chinese SR2_AS3_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:18
translate chinese SR2_AS3_label_8256fae2:

    # MC "(I still did not buy that vibrator.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:31
translate chinese SR2_AS3_label_b148adc9:

    # MC "*Psst! Sara... I got it."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:32
translate chinese SR2_AS3_label_8dc8227c:

    # Sara "Huh?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:33
translate chinese SR2_AS3_label_04a5ec71:

    # MC "I went to the sex shop in the evening and got you the vibrator. It’s in my roo-"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:39
translate chinese SR2_AS3_label_924ddabc:

    # Sara "VIBRATOR!?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:40
translate chinese SR2_AS3_label_c26e8613:

    # Sara "Really!?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:41
translate chinese SR2_AS3_label_2a990a65:

    # MC "(Shit! She’s too loud! Other students will hear her and laugh!)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:42
translate chinese SR2_AS3_label_46f04f3e:

    # MC "(I don’t know why she sounds so surprised! We TALKED about this!)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:46
translate chinese SR2_AS3_label_40f57afb:

    # MC "Shush! If you’re not careful, half the students here are gonna hear you!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:47
translate chinese SR2_AS3_label_ca0e89f2:

    # Sara "(Oops! I didn’t think of that... I was just so shocked, that it never occured to me.)"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:48
translate chinese SR2_AS3_label_cc74aa26:

    # MC "Can I take my hand off now? Or are you going to announce to everyone that you gave me a blowjob too?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:49
translate chinese SR2_AS3_label_39b3c976:

    # Sara "Mmm hmm..."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:53
translate chinese SR2_AS3_label_4c0c87a4:

    # Sara "S-Sorry, I was just... a little taken aback."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:54
translate chinese SR2_AS3_label_29d7fd24:

    # MC "That's okay. I'll see you later on. Are you still good to meet in my room tonight?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:55
translate chinese SR2_AS3_label_468c3e55:

    # MC "I’ll be able to give you it when we meet then."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:59
translate chinese SR2_AS3_label_37e866c3:

    # Sara "*Gulp* O-Okay, I’ll be in your bedroom."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:61
translate chinese SR2_AS3_label_a112087b:

    # MC "It’s probably best if you wait until Mom goes to sleep."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:63
translate chinese SR2_AS3_label_6354743d:

    # MC "It’s probably best if you finish your studying again before coming to my bedroom. Do you remember that you promised me that?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:64
translate chinese SR2_AS3_label_868d76de:

    # Sara "Yeah, I’ll see you then."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:66
translate chinese SR2_AS3_label_49de0fff:

    # MC "You should probably look for a good place to hide it too. I don’t want Mom finding it when she cleans your room."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:68
translate chinese SR2_AS3_label_df9915ec:

    # MC "You should probably look for a good place to hide it too! I noticed that your friend Lily is very curious about everything and everyone... Even pictures on your smartphone..."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS3.rpy:69
translate chinese SR2_AS3_label_8b07fd03:

    # Sara "Don’t worry, I know a few places she won’t look."
    Sara ""

