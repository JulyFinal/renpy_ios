﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:30
translate chinese headmaster_S2_c44fb587:

    # MC "(I can’t go in. Judy is there.)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:47
translate chinese headmaster_S2_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:54
translate chinese headmaster_S2_27c604de:

    # Headmaster "Hold up, give me a minute!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:55
translate chinese headmaster_S2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:56
translate chinese headmaster_S2_fdd54973:

    # Headmaster "Okay, c’mon in!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:67
translate chinese headmaster_S2_606723ba:

    # Headmaster "Why, hello again, [player_name]. What brings you back?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:68
translate chinese headmaster_S2_486415a6:

    # MC "Hi sir, sorry to bother you again. Judy told me to-"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:72
translate chinese headmaster_S2_493fb164:

    # Headmaster "Oh yeah! That hot piece of ass stopped by earlier. Something about needing permission to miss some college classes?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:73
translate chinese headmaster_S2_f19d4a61:

    # MC "Yes, sir. She didn’t give me any other instructions than to show up today."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:77
translate chinese headmaster_S2_474cb4cf:

    # Headmaster "That’s fair, just hold up. I’ve got it somewhere here in my drawers."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:78
translate chinese headmaster_S2_58048e00:

    # MC "(Awesome! It sounds like Judy got the slip approved! Nothing’s going to stand in the way of me going on holiday with [Mom_name] now!)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:79
translate chinese headmaster_S2_c3d6e103:

    # Headmaster "Aha! There it is, buried under that joint-"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:80
translate chinese headmaster_S2_cfd629f2:

    # Headmaster "Umm, I mean... joint checking account. Yeah..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:84
translate chinese headmaster_S2_17782c27:

    # Headmaster "Anyway! Whaddya need this permission slip for? Judy wasn’t actually very clear with me. Patient confidentiality and all that I suppose."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:85
translate chinese headmaster_S2_ced6ecb8:

    # MC "It’s... uh..."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:89
translate chinese headmaster_S2_62edc4ea:

    # MC "(Shit, I can’t tell him that I’m going away for the day to fuck my Mom’s brains out.)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:91
translate chinese headmaster_S2_0e438258:

    # MC "(Shit, I can’t tell him that I’m going away for the day to fuck my landlady’s brains out.)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:92
translate chinese headmaster_S2_8ba43629:

    # Headmaster "Yes?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:93
translate chinese headmaster_S2_9c1b4b85:

    # MC "I... um... remember what you said last time about caring for my mental health?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:97
translate chinese headmaster_S2_342a49a0:

    # Headmaster "Oh shit, why didn’t you say earlier?! How long did Judy request for?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:98
translate chinese headmaster_S2_2a977792:

    # MC "Just a day, I think."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:99
translate chinese headmaster_S2_6427b7e6:

    # Headmaster "Is that long enough? I can up it to four or five, if you like."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:100
translate chinese headmaster_S2_691f8b3b:

    # MC "Is that... legal?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:101
translate chinese headmaster_S2_b14e859a:

    # Headmaster "I’m the goddamn dean, I don’t follow the rules - I make ‘em."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:105
translate chinese headmaster_S2_2d5e522e:

    # MC "Thanks, sir. That’s very kind. Honestly, one day should do me just fine though."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:106
translate chinese headmaster_S2_9801ba19:

    # Headmaster "If you’re certain. Take this one with you - that’s your copy."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:107
translate chinese headmaster_S2_c6ef7afd:

    # MC "Thanks again, sir."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:111
translate chinese headmaster_S2_8972a85e:

    # Headmaster "No sweat, homie. Oh, before I forget, have you been keeping away from the ladies?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:112
translate chinese headmaster_S2_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:113
translate chinese headmaster_S2_fb6b7764:

    # Headmaster "Heh, I’m just kidding you. Celia hasn’t filed any more complaints with me. Hopefully that means you two are getting along reasonably well together, again."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:117
translate chinese headmaster_S2_b33f2b2a:

    # MC "Yes, we-"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:118
translate chinese headmaster_S2_18b38ebb:

    # Headmaster "Hnng... *Cough*"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:119
translate chinese headmaster_S2_823a5032:

    # MC "Are you okay, sir?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:123
translate chinese headmaster_S2_12938a6e:

    # Headmaster "Y-Yeah, just a- Mmm- *Cough* chesty cough."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:124
translate chinese headmaster_S2_fb056c2f:

    # MC "Do you need a glass of water?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:125
translate chinese headmaster_S2_12bfefe0:

    # Headmaster "Ah... I’ll be fine. Just, quickly leave. And close the door behind you!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:129
translate chinese headmaster_S2_c8dc49c1:

    # Headmaster "Mmm! *Cough*"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:130
translate chinese headmaster_S2_86fda746:

    # MC "See you later, sir..."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:131
translate chinese headmaster_S2_a3dd7d39:

    # Headmaster "Later, [player_name]. Don’t forget to close the door! Ah..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:145
translate chinese headmaster_S2_558891a3:

    # MC "(Well, THAT was weird... I wonder what got into him all of a sudden.)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:173
translate chinese headmaster_S2_5ee8d35a:

    # Headmaster "Ugh... (I thought he’d NEVER leave!)"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:174
translate chinese headmaster_S2_0989d512:

    # Headmaster "It’s okay, you can continue, Cindy. He’s finally gone."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:176
translate chinese headmaster_S2_69c87f55:

    # Cindy "*Suck Suck*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:180
translate chinese headmaster_S2_fac0e825:

    # Cindy "Hehe! That was fun!"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:181
translate chinese headmaster_S2_a24e8ade:

    # Headmaster "It was goddamn nerve wracking, girl! I came THIS close to blowing my load while he was standing right in front of me!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:182
translate chinese headmaster_S2_18ba2964:

    # Cindy "And that’s bad because...?"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:183
translate chinese headmaster_S2_a3fb0b0e:

    # Headmaster "Because if he saw you there, and decided to tell anyone that I’m fucking a student, I would lose my job! We got things called professional standards at this college!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:184
translate chinese headmaster_S2_09aa483f:

    # Cindy "Hey - look on the bright side! You didn’t get caught! Now, where do you wanna cum?"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:185
translate chinese headmaster_S2_fbfb6294:

    # Headmaster "Just the usual."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:189
translate chinese headmaster_S2_69c87f55_1:

    # Cindy "*Suck Suck*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:190
translate chinese headmaster_S2_930c38d5:

    # Headmaster "Mmm... Damn..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:191
translate chinese headmaster_S2_2b92d1b7:

    # Headmaster "(Cindy is fucking incredible with that tongue of hers!)"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:195
translate chinese headmaster_S2_4ea09236:

    # Cindy "*Shluuuurrrrp*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:196
translate chinese headmaster_S2_4407fb7e:

    # Cindy "*Suck Suck Suck*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:198
translate chinese headmaster_S2_969d877a:

    # Headmaster "Mmm..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:202
translate chinese headmaster_S2_5b8a8193:

    # Headmaster "Dayum girl! You suck even harder than your grades!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:203
translate chinese headmaster_S2_84e8a230:

    # Cindy "Hehe! I love your jokes, sir!"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:204
translate chinese headmaster_S2_e2c6b474:

    # Headmaster "Y’know Cindy, you don’t HAVE to suck my cock, every time you want another ‘package.’"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:205
translate chinese headmaster_S2_31e0b1d5:

    # Cindy "Don’t be silly - I’m doing this because it’s FUN! Now, grab my hair and pull my face down. I LOVE it when you facefuck me really roughly!"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:209
translate chinese headmaster_S2_706e9275:

    # Headmaster "Well, if you insist. Hnng..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:210
translate chinese headmaster_S2_d43af99e:

    # Cindy "*SHLURP SHLURP*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:211
translate chinese headmaster_S2_ecccf652:

    # Headmaster "(Fuck, her mouth is so hot. Cindy seems to get better at giving blowjobs, each time she visits my office!)"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:215
translate chinese headmaster_S2_68951ca4:

    # Headmaster "Hnnng! Fuck! I’m cumming! Swallow it all, girl. Ugh! Yes!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:225
translate chinese headmaster_S2_6b8e1c8c:

    # Cindy "*Shlurp Suck*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:226
translate chinese headmaster_S2_29f6fb87:

    # Cindy "*Gulp* *Gulp*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:230
translate chinese headmaster_S2_1d9390bc:

    # Headmaster "Ohh... fuck..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:231
translate chinese headmaster_S2_e0e283d8:

    # Headmaster "That was great, Cindy. Fucking fantastic, as always. I hope that load wasn’t too much for your little mouth to handle."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:232
translate chinese headmaster_S2_df2eb9f5:

    # Cindy "*GULP*"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:236
translate chinese headmaster_S2_9a6b84ff:

    # Cindy "*Cough* A-All done!"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:237
translate chinese headmaster_S2_9bd6ccdb:

    # Cindy "You mustn’t have cum for DAYS, sir. I don’t remember the last time you came so much!"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:238
translate chinese headmaster_S2_ac49483f:

    # Headmaster "Yeah, I was too busy to beat one out. Tissues are over there if you need one."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:239
translate chinese headmaster_S2_7e9b9845:

    # Cindy "I’m good, hehe."
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:243
translate chinese headmaster_S2_996f28c5:

    # Cindy "Oh! Don’t forget to drop the package in my locker. I’ll pick it up at the end of the day."
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:244
translate chinese headmaster_S2_85cf028d:

    # Headmaster "Have I ever forgotten before?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:245
translate chinese headmaster_S2_2e5de42c:

    # Cindy "No, I guess not."
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:246
translate chinese headmaster_S2_351916f2:

    # Headmaster "Your dean ALWAYS delivers. That’s why I’m the goddamn kingpin in this town."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:250
translate chinese headmaster_S2_82faab5b:

    # Cindy "I know, I know. You’re the big boss."
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:251
translate chinese headmaster_S2_c67b3c0b:

    # Headmaster "Ain’t you got a lecture right now? Your professor is gonna get suspicious of your absence. Which class are you missing right now?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:252
translate chinese headmaster_S2_303457f7:

    # Cindy "Umm... Algebra, I think."
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:253
translate chinese headmaster_S2_054ef086:

    # Headmaster "Tell her you were being... disciplined by the Dean. I’ll verify it if your professor wants to check it out."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:257
translate chinese headmaster_S2_893d2191:

    # Cindy "Coolio! See you later, sir!"
    Cindy ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:258
translate chinese headmaster_S2_43b3149e:

    # Headmaster "See you later, Cindy. I’ll prepare the package now. Make sure you close the door behind you."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:259
translate chinese headmaster_S2_0e2574cc:

    # Cindy "Thanks, sir! And thanks for your OTHER package too, hehe!"
    Cindy ""

translate chinese strings:

    # game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:148
    old "Go away."
    new ""

    # game/scripts/school/headmaster_room/morning/Scenes/headmaster_S2.rpy:148
    old "Stand in front of the door."
    new ""

