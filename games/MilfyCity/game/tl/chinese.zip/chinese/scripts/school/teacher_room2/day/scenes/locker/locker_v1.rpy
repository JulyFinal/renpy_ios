﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/teacher_room2/day/scenes/locker/locker_v1.rpy:41
translate chinese put_envelopev1_label_a18b92a2:

    # MC "Okay. That should do it. Let’s get out of here."
    MC ""

# game/scripts/school/teacher_room2/day/scenes/locker/locker_v1.rpy:50
translate chinese empty_envelopev1_label_d2fd283d:

    # MC "Why should I put an empty envelope inside?"
    MC ""

# game/scripts/school/teacher_room2/day/scenes/locker/locker_v1.rpy:51
translate chinese empty_envelopev1_label_361c01da:

    # MC "I need a pen. I have probably a few in my locker in the college corridor."
    MC ""

# game/scripts/school/teacher_room2/day/scenes/locker/locker_v1.rpy:59
translate chinese put_dildov1_label_a18b92a2:

    # MC "Okay. That should do it. Let’s get out of here."
    MC ""

# game/scripts/school/teacher_room2/day/scenes/locker/locker_v1.rpy:68
translate chinese put_sexy_cloth_label_a18b92a2:

    # MC "Okay. That should do it. Let’s get out of here."
    MC ""

# game/scripts/school/teacher_room2/day/scenes/locker/locker_v1.rpy:76
translate chinese put_vibrator_label_a18b92a2:

    # MC "Okay. That should do it. Let’s get out of here."
    MC ""

