﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/monitoring/M/moni_label.rpy:28
translate chinese moni_M1_locked_aeb91391:

    # MC "(It's locked.)"
    MC ""

