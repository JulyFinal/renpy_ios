﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:14
translate chinese celia_school_morning_scene1v1_label_4767cc95:

    # MC "(I don’t want to talk to that... bitch.)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:20
translate chinese celia_school_morning_scene1v1_label_9733d5ae:

    # MC "(There's peculiar key behind her. Let's attempt to take it when she's not around...)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:26
translate chinese celia_school_morning_scene1v1_label_4767cc95_1:

    # MC "(I don’t want to talk to that... bitch.)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:40
translate chinese celia_school_morning_scene1v1_label_8332369a:

    # Celia "Good morning, loverboy!"
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:41
translate chinese celia_school_morning_scene1v1_label_df234461:

    # Celia "Any luck getting yourself a girl yet?"
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:44
translate chinese celia_school_morning_scene1v1_label_d5528ed7:

    # MC "(Fuck you! I promise I'll get my way of handling you!)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:45
translate chinese celia_school_morning_scene1v1_label_20f50576:

    # Celia "Or were you thinking of asking out your professor again?"
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:46
translate chinese celia_school_morning_scene1v1_label_70d68059:

    # MC "(Grr... She’s embarrassing me in front of the whole class!)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:47
translate chinese celia_school_morning_scene1v1_label_befbdea9:

    # MC "I only come here to apo-"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:50
translate chinese celia_school_morning_scene1v1_label_5243f8d3:

    # Classmates "-Ahahahaha!"
    Classmates ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:51
translate chinese celia_school_morning_scene1v1_label_3970d803:

    # Celia "Go back to your classroom, [player_name]. Class is about to begin."
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:52
translate chinese celia_school_morning_scene1v1_label_959be831:

    # MC "(God... Now I hate her! I wonder how long it will be until she forgets about this.)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:53
translate chinese celia_school_morning_scene1v1_label_2eea073b:

    # MC "(Regardless... I tried to apologize but the class won't let me.)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:70
translate chinese celia_school_morning_scene1v1_label_8af057a4:

    # Celia "You again? Are you trying to ask me out again?"
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:71
translate chinese celia_school_morning_scene1v1_label_8d28bb11:

    # MC "Wh-What?! No!"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:74
translate chinese celia_school_morning_scene1v1_label_cf46543b:

    # Celia "So you don’t want to go out with me..?"
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:75
translate chinese celia_school_morning_scene1v1_label_97178a54:

    # MC "I- Wh- N-No? I mean y-yes?"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:76
translate chinese celia_school_morning_scene1v1_label_7680ebe5:

    # Celia "Ugh, what a loser. Get back to your class."
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:77
translate chinese celia_school_morning_scene1v1_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:80
translate chinese celia_school_morning_scene1v1_label_76ac9e09:

    # Classmates "Hahahahaha!"
    Classmates ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:81
translate chinese celia_school_morning_scene1v1_label_05f2fc00:

    # Blonde_Boy "Wow! How pathetic!"
    Blonde_Boy ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:82
translate chinese celia_school_morning_scene1v1_label_0880e9ed:

    # Brunette_Girl "Oh, my God! That’s soooo cringeworthy!"
    Brunette_Girl ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:83
translate chinese celia_school_morning_scene1v1_label_9cd0fbd3:

    # MC "(Oh God... That was fucking terrible...)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:84
translate chinese celia_school_morning_scene1v1_label_f8adf709:

    # MC "(I promise you, I'll get my way of handling you, bitch!)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:85
translate chinese celia_school_morning_scene1v1_label_773067b2:

    # MC "(Maybe I could find something on her computer?)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:86
translate chinese celia_school_morning_scene1v1_label_57299849:

    # MC "(There's also a peculiar key behind her. Let's attempt to take it when she's not around...)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:105
translate chinese celia_school_morning_scene1v1_label_496249a5:

    # MC "Hey, Ms. Celia..."
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:106
translate chinese celia_school_morning_scene1v1_label_fe6d3740:

    # Celia "If you have any questions... just... just ask one of your classmates."
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:109
translate chinese celia_school_morning_scene1v1_label_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:110
translate chinese celia_school_morning_scene1v1_label_670b39ca:

    # Celia "Yeah. Just... get back to your class."
    Celia ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:111
translate chinese celia_school_morning_scene1v1_label_4124c8a5:

    # MC "Huh? Okay."
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:112
translate chinese celia_school_morning_scene1v1_label_69a58161:

    # MC "(She’s acting less aggressive than before!)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:113
translate chinese celia_school_morning_scene1v1_label_26a2647c:

    # MC "(I guess my strategy is working very well.)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/celia_school_morning_scene1_1a_v1.rpy:130
translate chinese celia_school_morning_scene1v1_label_4767cc95_2:

    # MC "(I don’t want to talk to that... bitch.)"
    MC ""

