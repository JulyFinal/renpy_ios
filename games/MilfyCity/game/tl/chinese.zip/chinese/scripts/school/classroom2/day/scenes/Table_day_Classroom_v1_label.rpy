﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/Table_day_Classroom_v1_label.rpy:15
translate chinese Table_day_Classroom_exams_v1_label_f5be21cb:

    # MC "Our exams... I better leave it alone."
    MC ""

# game/scripts/school/classroom2/day/scenes/Table_day_Classroom_v1_label.rpy:25
translate chinese Table_day_Classroom_books_v1_label_14f78008:

    # MC "Just some random books."
    MC ""

