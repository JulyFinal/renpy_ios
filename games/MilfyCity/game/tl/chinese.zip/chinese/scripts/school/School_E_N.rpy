﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/School_E_N.rpy:18
translate chinese school_entrance_E_N_locked_50b95862:

    # MC "(Judy is somewhere in the college! I should find her instead of leaving.)"
    MC ""

# game/scripts/school/School_E_N.rpy:20
translate chinese school_entrance_E_N_locked_a91012a8:

    # MC "(Let's look around the college.)"
    MC ""

# game/scripts/school/School_E_N.rpy:22
translate chinese school_entrance_E_N_locked_bdca7a92:

    # MC "(Let's go back to the Dean's Office.)"
    MC ""

# game/scripts/school/School_E_N.rpy:123
translate chinese school_corridor1_E_N_locked_aeb91391:

    # MC "(It's locked.)"
    MC ""

# game/scripts/school/School_E_N.rpy:511
translate chinese school_corridor2_E_N_locked_aeb91391:

    # MC "(It's locked.)"
    MC ""

