﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:17
translate chinese celia_school_morning_scene1bv1_label_52e92182:

    # Celia "[player_name]? Oh, thank God you’re here."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:18
translate chinese celia_school_morning_scene1bv1_label_cdb7f867:

    # MC "Huh? Is everything alright, Ms. Celia?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:19
translate chinese celia_school_morning_scene1bv1_label_5ad81e3e:

    # Celia "Everything’s fine... Actually, no. No, it really isn’t. We need to talk."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:22
translate chinese celia_school_morning_scene1bv1_label_b067e449:

    # Celia "You may be wondering why I have been acting so... interested in you lately."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:23
translate chinese celia_school_morning_scene1bv1_label_51301d95:

    # MC "You mean like in the toilet when we-"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:24
translate chinese celia_school_morning_scene1bv1_label_0048600d:

    # Celia "Yes! You don’t need to describe it to me. The truth of the matter is, I’m being blackmailed."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:26
translate chinese celia_school_morning_scene1bv1_label_960eb453:

    # MC "Blackmailed?! By who?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:28
translate chinese celia_school_morning_scene1bv1_label_7e467f34:

    # MC "(Ahh, she’s REALLY getting into this fantasy! She isn’t even breaking character for a second! I should play along!) Blackmailed?! By who?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:31
translate chinese celia_school_morning_scene1bv1_label_0168ab74:

    # Celia "That’s the crux of the problem. I don’t know who."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:32
translate chinese celia_school_morning_scene1bv1_label_031d4a8d:

    # MC "Huh... There’s nothing you can do then?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:33
translate chinese celia_school_morning_scene1bv1_label_ba153b35:

    # Celia "There most certainly is. I need your help though."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:34
translate chinese celia_school_morning_scene1bv1_label_40ba78fd:

    # MC "What’s in it for me? Tracking down some creepy blackmailer, doesn’t sound too safe."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:37
translate chinese celia_school_morning_scene1bv1_label_5350bdda:

    # Celia "If you help me catch him, there will be a reward in it for you."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:38
translate chinese celia_school_morning_scene1bv1_label_fe5c8d47:

    # Celia "If you catch my drift?"
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:39
translate chinese celia_school_morning_scene1bv1_label_fc3b080f:

    # MC "I’ll get to fuck you?"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:40
translate chinese celia_school_morning_scene1bv1_label_d68c3165:

    # Celia "It depends on how good you are at catching this bastard."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:44
translate chinese celia_school_morning_scene1bv1_label_0702a081:

    # MC "Count me in!"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:46
translate chinese celia_school_morning_scene1bv1_label_07f7827b:

    # MC "Count me in! (Heh! I like how she set up the next part of the scenario for me. Takes some work off my plate!)"
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:47
translate chinese celia_school_morning_scene1bv1_label_510e1f87:

    # Celia "Excellent! Please, take this. It’s my address. I want you to come over."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:48
translate chinese celia_school_morning_scene1bv1_label_a917954b:

    # Celia "I’m usually at home in the evening... No, make it at night."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:49
translate chinese celia_school_morning_scene1bv1_label_55183c3b:

    # Celia "My husband’s away on a business trip, so we’ll sit down and hammer out a solid strategy for catching this prick."
    Celia ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:50
translate chinese celia_school_morning_scene1bv1_label_4cd1b556:

    # MC "Cool. See you later on then, Ms. Celia."
    MC ""

# game/scripts/school/teacher_room1/morning/scenes/celia_school_morning_scene1bv1_label.rpy:51
translate chinese celia_school_morning_scene1bv1_label_920522b9:

    # Celia "Goodbye, [player_name]."
    Celia ""

