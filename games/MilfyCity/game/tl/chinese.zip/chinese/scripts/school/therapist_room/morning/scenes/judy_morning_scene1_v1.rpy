﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:27
translate chinese judy_menu_v1_label_c3b1382f:

    # Judy "The Dean wants to speak with you. Please go to his office after we finish."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:68
translate chinese judy_morning_scene1_v1_label_21bba4de:

    # Judy "Welcome back, [player_name]. I’m always glad to see students decide to continue their therapy."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:69
translate chinese judy_morning_scene1_v1_label_afa5012a:

    # Judy "Is there anything in-particular you would like to discuss today?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:70
translate chinese judy_morning_scene1_v1_label_4eda72a8:

    # MC "Thanks, Judy. Yeah, actually. I was wondering though... Is everything that is said in therapy confidential?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:71
translate chinese judy_morning_scene1_v1_label_4fa2fcc2:

    # Judy "Unless you’re planning to kill yourself or somebody else, then yes. It is entirely confidential."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:74
translate chinese judy_morning_scene1_v1_label_8b045d2d:

    # MC "Awesome! Right, I think I’ve figured out a way to get revenge on Celia."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:75
translate chinese judy_morning_scene1_v1_label_1b80eef3:

    # Judy "Oh, really?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:76
translate chinese judy_morning_scene1_v1_label_2175bfb7:

    # MC "I was on her computer, when I found out she has been selling top grades for THOUSANDS of dollars! She must have made at LEAST $10,000!"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:79
translate chinese judy_morning_scene1_v1_label_cc5949e5:

    # MC "I’m gonna use this information to blackmail her into-"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:81
translate chinese judy_morning_scene1_v1_label_8228df44:

    # MC "I had the opportunity to have fun with her, but she caught me and now SHE wants ME to subject her to a BDSM relationship!"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:84
translate chinese judy_morning_scene1_v1_label_0b653bbe:

    # Judy "Okay, I’m gonna stop you right there."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:85
translate chinese judy_morning_scene1_v1_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:86
translate chinese judy_morning_scene1_v1_label_45f2b916:

    # Judy "This is a TERRIBLE idea."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:87
translate chinese judy_morning_scene1_v1_label_5a9d7893:

    # MC "What? Why?!"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:91
translate chinese judy_morning_scene1_v1_label_4da97175:

    # Judy "You can’t just walk in and blackmail her. Celia is a formidable woman. There will be consequences."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:93
translate chinese judy_morning_scene1_v1_label_312585d7:

    # Judy "Celia is a formidable woman. I know she instructed you to subject her to a BDSM relationship, but she is WAAAY too much for a guy like you to handle."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:94
translate chinese judy_morning_scene1_v1_label_4ccb437d:

    # MC "B-But I worked so hard to get this evidence..."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:96
translate chinese judy_morning_scene1_v1_label_06b15570:

    # Judy "You can still use it. You just need to be smart about HOW you blackmail her."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:98
translate chinese judy_morning_scene1_v1_label_d9357e4d:

    # Judy "*Sgh* Fine. If you’re insisting on going through with this then you’re just going to need to be smart about how you handle Celia."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:99
translate chinese judy_morning_scene1_v1_label_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:103
translate chinese judy_morning_scene1_v1_label_9bcd1757:

    # Judy "You need to work in gradual steps. Begin by buying yourself a webcam. I’ll give you her Skipe address and you can anonymously blackmail her from there."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:104
translate chinese judy_morning_scene1_v1_label_d7595f40:

    # Judy "It’s really important that you only push her a little bit at a time. You don’t want to scare her off or cause her to go to the police."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:106
translate chinese judy_morning_scene1_v1_label_e850cf1b:

    # Judy "Build things up gradually. She’ll just end up dominating you if you try to do it in person. The safest way to start is probably by buying yourself a webcam. You can roleplay blackmailing her on that to kick things off."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:107
translate chinese judy_morning_scene1_v1_label_336a97cc:

    # Judy "It’s really important that you take things gradually. You don’t want her to reverse this relationship! She already humiliated you once. I’m sure she would relish the chance to do so again."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:108
translate chinese judy_morning_scene1_v1_label_183e241f:

    # MC "Good idea! But, why are you helping me?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:110
translate chinese judy_morning_scene1_v1_label_cacc7345:

    # Judy "Celia voted against giving college support staff a pay rise at the last union conference. Let’s just say that this is my way of getting my own revenge on that, stuck-up bitch!"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:112
translate chinese judy_morning_scene1_v1_label_9d915992:

    # Judy "Celia voted against giving college support staff a pay rise at the last union conference. Let’s just say this is my way of getting my own back on her!"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:113
translate chinese judy_morning_scene1_v1_label_3115b9d5:

    # MC "Huh, I never knew that."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:116
translate chinese judy_morning_scene1_v1_label_4828e021:

    # Judy "First thing though - go and write her a letter and put it in her cabinet in the professor’s break room. You can take my envelope from the table near the door."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:117
translate chinese judy_morning_scene1_v1_label_740d9260:

    # Judy "Then, create a fake webcam account, and stay logged in this evening. She should contact you."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:118
translate chinese judy_morning_scene1_v1_label_e7d33dfb:

    # MC "Thanks, Judy. I really hope this works."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:121
translate chinese judy_morning_scene1_v1_label_817fa3e4:

    # Judy "Trust me, it will. Now hurry up and write your blackmail note."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:123
translate chinese judy_morning_scene1_v1_label_4a0ed792:

    # Judy "Trust me, it will. Now hurry up and write your fake “blackmail” note. It’ll help make the fantasy feel more real for her, and she’ll enjoy it more."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:144
translate chinese judy_lindadeal_8dfc0204:

    # Judy "It’s good to see you again, [player_name]. It is important for people experiencing trauma to attend therapy on a regular basis."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:145
translate chinese judy_lindadeal_b85c2d1e:

    # Judy "Far too many of my other patients skip sessions - or even drop out."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:146
translate chinese judy_lindadeal_667f9380:

    # MC "Hey, Judy. I wasn’t actually here for therapy today."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:150
translate chinese judy_lindadeal_072da21e:

    # Judy "No? Is something wrong?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:151
translate chinese judy_lindadeal_4ea00255:

    # MC "Yes... No... Maybe? I’m not sure right now."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:152
translate chinese judy_lindadeal_9740f922:

    # Judy "Calm down, and breathe. What is it you want to say?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:154
translate chinese judy_lindadeal_4503c938:

    # MC "I... I overheard my mom talking to you on the phone."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:156
translate chinese judy_lindadeal_60a8201c:

    # MC "I... I overheard Linda talking to you on the phone."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:158
translate chinese judy_lindadeal_fe89d79a:

    # Judy "Okay, There’s nothing unusual about that. Parental involvement can be very important in therapy."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:160
translate chinese judy_lindadeal_eb935773:

    # Judy "Okay, there’s nothing unusual about that. She’s your landlord, and she spends far more time with you than I do. It’s important that she lets me know if you are improving - purely for your welfare."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:161
translate chinese judy_lindadeal_ec15b268:

    # MC "The two of you were talking about some kind of deal involving me."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:165
translate chinese judy_lindadeal_68ad318b:

    # Judy "Ahh! You’re more aware of the situation than I thought. Did you learn about this by eavesdropping on your mom’s conversations?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:167
translate chinese judy_lindadeal_dbe1098d:

    # Judy "Ahh, you’re more aware of the situation than I thought. Did you learn about this by eavesdropping on Linda’s conversations?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:168
translate chinese judy_lindadeal_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:169
translate chinese judy_lindadeal_4fd26a00:

    # Judy "Hmm... Fine. I’ll tell you about it - but not here."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:173
translate chinese judy_lindadeal_63d6b4d3:

    # Judy "Come over to my house in the evening whenever you have some free time, and I'll explain everything in person. Here's my address."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:174
translate chinese judy_lindadeal_c8a7e029:

    # MC "Why can’t you just tell me right now? Is this some kind of secret? You're just using me for your own purpose?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:175
translate chinese judy_lindadeal_358917ca:

    # Judy "I would be violating - SO many departamentul HR policies - if I did!"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:176
translate chinese judy_lindadeal_d72c312c:

    # Judy "I apologize if it seems that way, but it's not about using you or keeping secrets. Some matters are best discussed in person, where we can have a more private and thorough conversation."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:177
translate chinese judy_lindadeal_d4d878fd:

    # Judy "I value our connection and want to ensure we communicate effectively. I’ll speak to you at my house, also I'm a very busy woman, so please don't be surprised when I don't anticipate your presence at my house. Okay? "
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:178
translate chinese judy_lindadeal_d30e6ff4:

    # MC "Fine. I’ll see you there."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:196
translate chinese judy_q3_label_28fdfd85:

    # MC "Hey Judy, can I bother you for a minute?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:197
translate chinese judy_q3_label_2f085add:

    # Judy "Of course, [player_name]. You know my office is always open to you while you’re undergoing your treatment. Please, take a seat."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:198
translate chinese judy_q3_label_6d71980d:

    # MC "Thanks for the offer, but I’ll only be a minute."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:202
translate chinese judy_q3_label_7b76e414:

    # Judy "What can I do for you, then?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:203
translate chinese judy_q3_label_cd8b6d5e:

    # MC "Well, I was wondering if you could maybe approve an exemption from college for me?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:204
translate chinese judy_q3_label_f5bcc307:

    # Judy "An exemption? Why would you need that?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:208
translate chinese judy_q3_label_e6590944:

    # MC "It’s just a... quick getaway for my mental health. I wanted to take a break and focus on recovering."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:210
translate chinese judy_q3_label_5bde8866:

    # Judy "(Hmm, he’s being especially evasive with that answer. I wonder if this has anything to do with Linda making moves on her son. I’ll try prying a little deeper.)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:212
translate chinese judy_q3_label_69e3c763:

    # Judy "(Hmm, he’s being especially evasive with that answer. I wonder if this has anything to do with Linda making moves on him. I’ll try prying a little deeper.)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:213
translate chinese judy_q3_label_714bda38:

    # Judy "How long do you need off?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:214
translate chinese judy_q3_label_592c9614:

    # MC "Just one day."
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:218
translate chinese judy_q3_label_77fd4bfc:

    # Judy "(One day for a mental health break? Most students would need a week or two off for something like that. Come to think of it - wasn’t Linda going away for a day soon? I tried to organise lunch, and she said she was out of town.)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:219
translate chinese judy_q3_label_54834752:

    # Judy "(This has Linda’s fingerprints ALL over it!)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:221
translate chinese judy_q3_label_24f40f4f:

    # Judy "(She must be taking her son away to a hotel somewhere, for the night. Then again, there’s nothing at all wrong with that. This is something I should be encouraging!)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:223
translate chinese judy_q3_label_2eca3bd9:

    # Judy "(She must be taking [player_name] away to a hotel somewhere, for the night. Then again, there’s nothing at all wrong with that. This is something I should be encouraging!)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:224
translate chinese judy_q3_label_a76a8a1a:

    # Judy "Hmm... I guess that’s something I could look into for you. I’ll need to speak with the Dean about this, to get his consent."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:228
translate chinese judy_q3_label_badfc81f:

    # Judy "How about I go and have a chat with him now, and then you visit him tomorrow?"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:229
translate chinese judy_q3_label_39c25048:

    # MC "Do you think he’ll approve it?"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:230
translate chinese judy_q3_label_b9f324b5:

    # Judy "Don’t worry - I can be VERY persuasive."
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:231
translate chinese judy_q3_label_4abb40dd:

    # MC "Thanks, Judy! I owe you one!"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:233
translate chinese judy_q3_label_9beaa6a2:

    # Judy "(After this holiday with Linda, you’re going to owe me WAY more than one, kiddo!)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:235
translate chinese judy_q3_label_7e0a3333:

    # Judy "(After this holiday with Linda you’re going to owe me WAY more than one!)"
    Judy ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:237
translate chinese judy_q3_label_85e37663:

    # Judy "You can thank me later. I’ll pop off to the Dean’s office now."
    Judy ""

translate chinese strings:

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Ask Judy for help with Celia{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Tell Judy what you found out about Celia{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Talk about an exemption from college{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Talk about Celia being selling grades{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Talk about Mom{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Talk about Linda{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "{color=#00ff00}Talk about [Mom_name]{/color}"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "Required: 3 Relationship Points with [Mom_name] (disabled)"
    new ""

    # game/scripts/school/therapist_room/morning/scenes/judy_morning_scene1_v1.rpy:34
    old "Required: 4 Relationship Points with [Mom_name] (disabled)"
    new ""

