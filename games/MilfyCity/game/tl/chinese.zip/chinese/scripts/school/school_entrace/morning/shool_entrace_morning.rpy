﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/morning/shool_entrace_morning.rpy:38
translate chinese CeR1_step1_intercom_70b18d9a:

    # "Attention! Attention!"
    ""

# game/scripts/school/school_entrace/morning/shool_entrace_morning.rpy:41
translate chinese CeR1_step1_intercom_e75a8f52:

    # "*Buzzzzz* [player_name], please report to the Dean's office."
    ""

# game/scripts/school/school_entrace/morning/shool_entrace_morning.rpy:42
translate chinese CeR1_step1_intercom_d0e15a52:

    # MC "(What!? What do they want now!?)"
    MC ""

