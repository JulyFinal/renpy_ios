﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/teacher_room2/morning/scenes/locker/locker_v1_morning.rpy:9
translate chinese locker_v1_morning_label_a18b92a2:

    # MC "Okay. That should do it. Let’s get out of here."
    MC ""

# game/scripts/school/teacher_room2/morning/scenes/locker/locker_v1_morning.rpy:52
translate chinese put_envelopev1_morning_label_a18b92a2:

    # MC "Okay. That should do it. Let’s get out of here."
    MC ""

# game/scripts/school/teacher_room2/morning/scenes/locker/locker_v1_morning.rpy:61
translate chinese empty_envelopev1_morning_label_d2fd283d:

    # MC "Why should I put an empty envelope inside?"
    MC ""

# game/scripts/school/teacher_room2/morning/scenes/locker/locker_v1_morning.rpy:62
translate chinese empty_envelopev1_morning_label_361c01da:

    # MC "I need a pen. I have probably a few in my locker in the college corridor."
    MC ""

