﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:14
translate chinese lily_school_day_scene1_v1_label_b40ac31f:

    # Lily "Hey, [player_name]!"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:15
translate chinese lily_school_day_scene1_v1_label_8a73ad84:

    # MC "Oh, hey Lily!"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:30
translate chinese questions_lily_school_day_scene1_v1_c1cf27d8:

    # MC "What’s up?"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:31
translate chinese questions_lily_school_day_scene1_v1_35c12263:

    # Lily "Eh, kinda bored right now. I think I’m gonna sneak out early and try to miss Chemistry."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:32
translate chinese questions_lily_school_day_scene1_v1_939cc6fc:

    # MC "Aren’t you worried about getting caught?"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:33
translate chinese questions_lily_school_day_scene1_v1_f2e4ce9b:

    # Lily "Nah - what’s the worst that could happen? Mr. Jackon keeps threatening to discipline me - but he’s all bark and no bite!"
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:34
translate chinese questions_lily_school_day_scene1_v1_ec71ff70:

    # MC "(Everyone probably has a little bite in them if you push them hard enough. Lily ought to be careful!)"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:44
translate chinese questions_lily_school_day_scene1_v1_92a57c6c:

    # MC "Have you seen my sister?"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:45
translate chinese questions_lily_school_day_scene1_v1_b5b1bd71:

    # Lily "Sara? Sure - she’s probably still in the corridor. At least, that’s where I last seen her before I came into class."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:46
translate chinese questions_lily_school_day_scene1_v1_0306e743:

    # MC "Thanks, Lily."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:47
translate chinese questions_lily_school_day_scene1_v1_dec27dfb:

    # Lily "No sweat, [player_name]."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:57
translate chinese questions_lily_school_day_scene1_v1_98334809:

    # MC "Have you seen Sara?"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:58
translate chinese questions_lily_school_day_scene1_v1_b5b1bd71_1:

    # Lily "Sara? Sure - she’s probably still in the corridor. At least, that’s where I last seen her before I came into class."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:59
translate chinese questions_lily_school_day_scene1_v1_0306e743_1:

    # MC "Thanks, Lily."
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:60
translate chinese questions_lily_school_day_scene1_v1_dec27dfb_1:

    # Lily "No sweat, [player_name]."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:69
translate chinese questions_lily_school_day_scene1_v1_d8e50943:

    # MC "Are you up to anything interesting after college?"
    MC ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:70
translate chinese questions_lily_school_day_scene1_v1_201718ef:

    # Lily "I’m gonna go shopping for a new bikini. Aside from that, I don’t have big plans."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:71
translate chinese questions_lily_school_day_scene1_v1_870fbb3a:

    # Lily "I’m thinking of going for something really... skimpy. Small and tight."
    Lily ""

# game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:72
translate chinese questions_lily_school_day_scene1_v1_4d2d8b83:

    # MC "Uh... Wow! (I’d love to see her dressed like that!)"
    MC ""

translate chinese strings:

    # game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:25
    old "What’s up?"
    new ""

    # game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:25
    old "Have you seen my sister?"
    new ""

    # game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:25
    old "Have you seen Sara?"
    new ""

    # game/scripts/school/classroom2/day/scenes/lily_school_day_scene1_v1.rpy:25
    old "You up to anything interesting after college?"
    new ""

