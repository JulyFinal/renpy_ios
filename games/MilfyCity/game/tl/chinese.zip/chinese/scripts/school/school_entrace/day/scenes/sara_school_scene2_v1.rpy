﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:18
translate chinese sis_nerdy_school_scene2_v1_label_f142ffd5:

    # MC "(Oh! There’s Lily and Sara. They must be waiting for their next class to start.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:19
translate chinese sis_nerdy_school_scene2_v1_label_ee97e9a8:

    # Lily "What was it you were sooo desperate to show me, Sara?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:20
translate chinese sis_nerdy_school_scene2_v1_label_52ad57d2:

    # MC "(Huh? Is Sara getting her phone out?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:21
translate chinese sis_nerdy_school_scene2_v1_label_bc50efbc:

    # Lily "Oh, my God! Is this Dan from Chemistry?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:25
translate chinese sis_nerdy_school_scene2_v1_label_e9bb54bb:

    # Sara "No! It’s... my brother..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:27
translate chinese sis_nerdy_school_scene2_v1_label_79915e7c:

    # Sara "No! It’s... my roommate... [player_name]"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:28
translate chinese sis_nerdy_school_scene2_v1_label_490eec29:

    # Lily "No way! Show me again!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:29
translate chinese sis_nerdy_school_scene2_v1_label_6b70fdb5:

    # Sara "Not here... I’ll text you later."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:30
translate chinese sis_nerdy_school_scene2_v1_label_d30d2b3a:

    # Lily "Oh, my God!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:31
translate chinese sis_nerdy_school_scene2_v1_label_673acfd4:

    # MC "(She’s showing off that picture she took, of my dick!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:34
translate chinese sis_nerdy_school_scene2_v1_label_fab0dd04:

    # Lily "Like, what the hell happened? Why was he showing you his junk?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:35
translate chinese sis_nerdy_school_scene2_v1_label_f84d8c21:

    # Sara "We... We were playing a game... It got a little out of hand."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:36
translate chinese sis_nerdy_school_scene2_v1_label_1031f128:

    # Lily "No kidding! You NEED to get another one!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:37
translate chinese sis_nerdy_school_scene2_v1_label_4e333721:

    # Sara "Another pic?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:38
translate chinese sis_nerdy_school_scene2_v1_label_2492eb25:

    # Lily "Yeah, and make sure he is fully hard this time."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:41
translate chinese sis_nerdy_school_scene2_v1_label_1eeba268:

    # MC "(Jeez... I should have forced her to delete it when I had the chance. I should head on to my next class.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:42
translate chinese sis_nerdy_school_scene2_v1_label_b43a1ff7:

    # Sara "How exactly am I supposed to do that?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:43
translate chinese sis_nerdy_school_scene2_v1_label_c3242dff:

    # Lily "Easy - wait until he goes to sleep. Rub your hand over his junk a bit, to get him all hot and horny - then snap a pic. Easy!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:44
translate chinese sis_nerdy_school_scene2_v1_label_cf01e464:

    # Sara "Eh... I don’t know... It sounds a bit risky."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene2_v1.rpy:45
translate chinese sis_nerdy_school_scene2_v1_label_bc04be3e:

    # Lily "Don’t pussy out on me now, Sara!"
    Lily ""

