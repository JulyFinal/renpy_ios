﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:19
translate chinese delilah_scene1_label_4b6fa7de:

    # MC "...."
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:20
translate chinese delilah_scene1_label_f27eecec:

    # MC "(Damn, she’s hot...)"
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:21
translate chinese delilah_scene1_label_cc5d667e:

    # MC "(I haven’t seen her around here before. Is she a new student?)"
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:23
translate chinese delilah_scene1_label_189132d5:

    # Delilah "How long are you gonna stare at me like that?"
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:24
translate chinese delilah_scene1_label_77839d9f:

    # Delilah "You know that I can see your reflection in the water, right?"
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:26
translate chinese delilah_scene1_label_34248f0f:

    # MC "Oh! S-Sorry, my bad."
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:28
translate chinese delilah_scene1_label_6744c96e:

    # Delilah "The name’s Delilah by the way."
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:30
translate chinese delilah_scene1_label_a7e7ce15:

    # MC "(Delilah?! She must be the bully those nerds were talking about in the hallway!)"
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:31
translate chinese delilah_scene1_label_5d15079d:

    # Delilah "Do you fancy joining the swim club? We could always use someone to do the dirty work around here. The janitors in this place are awful!"
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:32
translate chinese delilah_scene1_label_681a9c67:

    # MC "You expect me to provide your club with free labour?"
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:33
translate chinese delilah_scene1_label_c0bf2d96:

    # Delilah "Someone’s gotta keep this place shiny. Why not?"
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:34
translate chinese delilah_scene1_label_b6446d1f:

    # MC "No thanks. I don’t fancy spending my free time as a cleaner."
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:36
translate chinese delilah_scene1_label_baa37850:

    # Delilah "Oh, come on. It would be good for you. Especially after that... cringeworthy incident with Ms. Celia"
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:37
translate chinese delilah_scene1_label_c42db376:

    # Delilah "There’s a lotta girls in this club. You could put yourself out there again, maybe meet someone."
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:39
translate chinese delilah_scene1_label_abfa540b:

    # Delilah "I mean, OBVIOUSLY not me! Haha! I’m, like, totally out of your league. But I could find you some solid twos or threes who you’d match nicely with."
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:40
translate chinese delilah_scene1_label_c4078499:

    # MC "Oh, ha ha. Very funny. Kick the loser while he’s down."
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:41
translate chinese delilah_scene1_label_f46c38cb:

    # Delilah "How about chubby Chloe? Or I could set you up with pimple-faced Patricia? "
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:42
translate chinese delilah_scene1_label_86f8a497:

    # Delilah "God knows it would take some desperate creature to be interested in someone like you! Haha!"
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:43
translate chinese delilah_scene1_label_75134cad:

    # Delilah "I mean no offense, of course. I’m just telling the truth."
    Delilah ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:44
translate chinese delilah_scene1_label_a290b9b2:

    # MC "(That bitch! She’s making fun of me!)"
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:45
translate chinese delilah_scene1_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/school/pool/morning/scenes/delilah_scene1.rpy:47
translate chinese delilah_scene1_label_a4729087:

    # Delilah "Well, if you change your mind, you know where to find me."
    Delilah ""

