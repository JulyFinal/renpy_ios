﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/morning/scenes/Table_morning_Classroom_v1.rpy:9
translate chinese Table_morning_Classroom_v1_label_f8123170:

    # MC "(I can’t just search her desk while she’s around.)"
    MC ""

# game/scripts/school/classroom2/morning/scenes/Table_morning_Classroom_v1.rpy:14
translate chinese Table_morning_Classroom_v1_label_f8123170_1:

    # MC "(I can’t just search her desk while she’s around.)"
    MC ""

