﻿# TODO: Translation updated at 2023-11-20 15:50

translate chinese strings:

    # game/scripts/school/classroom1/morning/scenes/deskb1.rpy:7
    old "Do you want to start the lesson?"
    new ""

