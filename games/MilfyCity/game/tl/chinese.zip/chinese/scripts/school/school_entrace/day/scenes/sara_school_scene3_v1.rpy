﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:114
translate chinese sis_nerdy_school_scene3_v1_label_e538b3d3:

    # Sara "I honestly don’t know what to do."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:115
translate chinese sis_nerdy_school_scene3_v1_label_6f856fd8:

    # Lily "Well... do you like him?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:116
translate chinese sis_nerdy_school_scene3_v1_label_fbe49129:

    # Sara "Of course I like him."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:117
translate chinese sis_nerdy_school_scene3_v1_label_4f6a170b:

    # Lily "C’mon, Sara. You know what I mean - do you ‘like’ like him?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:118
translate chinese sis_nerdy_school_scene3_v1_label_f4d230ea:

    # Sara "Y...Yeah... I think I do."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:121
translate chinese sis_nerdy_school_scene3_v1_label_52dae02c:

    # Lily "Speak of the Devil!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:122
translate chinese sis_nerdy_school_scene3_v1_label_35b52e6b:

    # Sara "Huh?!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:123
translate chinese sis_nerdy_school_scene3_v1_label_edf311db:

    # Lily "Hey, [player_name]. We were just talking about you."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:126
translate chinese sis_nerdy_school_scene3_v1_label_fe6fbde2:

    # MC "Only good things, I hope."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:127
translate chinese sis_nerdy_school_scene3_v1_label_f6fba076:

    # Lily "Hehe! Of course!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:128
translate chinese sis_nerdy_school_scene3_v1_label_e2b84c2e:

    # MC "What’s wrong, Sara? You’re looking a bit nervous."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:129
translate chinese sis_nerdy_school_scene3_v1_label_0474d3ba:

    # Lily "She’s fine! She just needs to lighten up. How about we all get together and play a fun game? Chill out for a bit!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:132
translate chinese sis_nerdy_school_scene3_v1_label_bac376ae:

    # MC "Sure, sounds good to me."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:133
translate chinese sis_nerdy_school_scene3_v1_label_4a6c57c2:

    # Sara "Uh... I guess so..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:134
translate chinese sis_nerdy_school_scene3_v1_label_0f40f771:

    # Sara "(God... I hope he didn’t hear me saying those things to Lily...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:136
translate chinese sis_nerdy_school_scene3_v1_label_8e8c5302:

    # Lily "Are your parents home right now, Sara?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:138
translate chinese sis_nerdy_school_scene3_v1_label_8fcbcb5f:

    # Lily "Are you alone right now, Sara?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:139
translate chinese sis_nerdy_school_scene3_v1_label_b87ada06:

    # Sara "I don’t think so."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:140
translate chinese sis_nerdy_school_scene3_v1_label_c10a5083:

    # Lily "Great! We can use your bedroom then!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:141
translate chinese sis_nerdy_school_scene3_v1_label_05ce8463:

    # Sara "My bedroom? What kind of game IS this?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:146
translate chinese sis_nerdy_school_scene3_v1_label_a9508214:

    # MC "This sounds interesting. Let’s!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:147
translate chinese sis_nerdy_school_scene3_v1_label_2068930e:

    # Lily "That’s the spirit!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:152
translate chinese sis_nerdy_school_scene3_v1_label_073a3eba:

    # MC "It’s your bedroom, Sara. Do you want to do this?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:153
translate chinese sis_nerdy_school_scene3_v1_label_5f294141:

    # Sara "Umm... Maybe? I think so..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:154
translate chinese sis_nerdy_school_scene3_v1_label_876dca3f:

    # Lily "Yeah, she does. Let’s go!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:164
translate chinese after_sis_nerdy_school_scene3_v1_choice_dda88904:

    # MC "Well? What now?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:165
translate chinese after_sis_nerdy_school_scene3_v1_choice_3df50e37:

    # Lily "Go and get a bottle."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:166
translate chinese after_sis_nerdy_school_scene3_v1_choice_76fa5664:

    # MC "A bottle?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:167
translate chinese after_sis_nerdy_school_scene3_v1_choice_8d75ac47:

    # Lily "Yeah - a glass one. They spin better."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:168
translate chinese after_sis_nerdy_school_scene3_v1_choice_16b95a17:

    # MC "Oh! We’re gonna play, spin the bottle."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:171
translate chinese after_sis_nerdy_school_scene3_v1_choice_beee5322:

    # MC "I’ll be back in a few minutes."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:172
translate chinese after_sis_nerdy_school_scene3_v1_choice_1b16073c:

    # Lily "Cool! See you soon!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:173
translate chinese after_sis_nerdy_school_scene3_v1_choice_9939c3e6:

    # Sara "*Whispered* You can’t be serious, Lily! He’s not gonna actually kiss me if it points to me! Is he?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:174
translate chinese after_sis_nerdy_school_scene3_v1_choice_3d2782e5:

    # Lily "Let’s wait and see..."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:177
translate chinese after_sis_nerdy_school_scene3_v1_choice_b03dd85e:

    # Lily "Aww... Don’t look soooo gloomy, Sara! What’s the matter?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:178
translate chinese after_sis_nerdy_school_scene3_v1_choice_8e5b3e87:

    # Sara "Wh... What if he doesn’t want to kiss me?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:179
translate chinese after_sis_nerdy_school_scene3_v1_choice_31be7e7a:

    # Lily "Well, that doesn’t matter..."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:182
translate chinese after_sis_nerdy_school_scene3_v1_choice_4d623374:

    # Lily "...because he’s gonna be kissing these luscious lips first!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:183
translate chinese after_sis_nerdy_school_scene3_v1_choice_8666765c:

    # Lily "I think he’s really gonna enjoy making out with me. I’ll make sure to kiss him REAL good for you."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:187
translate chinese after_sis_nerdy_school_scene3_v1_choice_21cdf066:

    # Sara "Hey! That’s my brother you’re talking about!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:189
translate chinese after_sis_nerdy_school_scene3_v1_choice_8e300b88:

    # Sara "Hey! What the fuck are you talking about!?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:190
translate chinese after_sis_nerdy_school_scene3_v1_choice_98cb487e:

    # Lily "Easy, Sara. Chill out!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:191
translate chinese after_sis_nerdy_school_scene3_v1_choice_afba90df:

    # Sara "Don’t tell me to chill out!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:194
translate chinese after_sis_nerdy_school_scene3_v1_choice_ad4482c6:

    # Sara "Don’t you dare think you can just kis-"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:195
translate chinese after_sis_nerdy_school_scene3_v1_choice_d63ff404:

    # MC "Hey, I found a glass bot-"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:196
translate chinese after_sis_nerdy_school_scene3_v1_choice_d642fc87:

    # MC "*Ahem* Is everything alright? You two aren’t fighting, are you?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:199
translate chinese after_sis_nerdy_school_scene3_v1_choice_3e6cc04c:

    # Lily "Fighting? Haha! No, we’re just wrestling!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:200
translate chinese after_sis_nerdy_school_scene3_v1_choice_c9e69812:

    # Sara "Y-Yeah..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:201
translate chinese after_sis_nerdy_school_scene3_v1_choice_5c96457e:

    # MC "Great! Let’s get started then. How do you want to do this?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:204
translate chinese after_sis_nerdy_school_scene3_v1_choice_af3d04a8:

    # Lily "Okay, you’re first, [player_name]. Whoever the bottle points at - you’ve got to kiss them."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:205
translate chinese after_sis_nerdy_school_scene3_v1_choice_70423bd9:

    # MC "Wait - even Sara?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:206
translate chinese after_sis_nerdy_school_scene3_v1_choice_41ea9a7e:

    # Lily "Yup! Sara too!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:207
translate chinese after_sis_nerdy_school_scene3_v1_choice_4b6e929c:

    # MC "(Wow... Sara looks so nervous...)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:210
translate chinese after_sis_nerdy_school_scene3_v1_choice_d1421a24:

    # Lily "Let’s spin the bottle!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:215
translate chinese after_sis_nerdy_school_scene3_v1_choice_de6e2178:

    # Lily "Woo! That’s me!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:218
translate chinese after_sis_nerdy_school_scene3_v1_choice_60b59fa5:

    # Lily "C’mere, big boy, and gimme a kiss!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:219
translate chinese after_sis_nerdy_school_scene3_v1_choice_09eb04fc:

    # MC "Uh... O-Okay..."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:220
translate chinese after_sis_nerdy_school_scene3_v1_choice_9cba3da9:

    # MC "(She seems really into this! I never imagined that girls might actually like me this much!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:222
translate chinese after_sis_nerdy_school_scene3_v1_choice_e1b8b959:

    # Sara "(Nooo! God... the sight of her leaning into my brother, is making me feel sick.)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:224
translate chinese after_sis_nerdy_school_scene3_v1_choice_8775a2a1:

    # Sara "(Nooo! God... the sight of her leaning into him is making me feel sick.)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:227
translate chinese after_sis_nerdy_school_scene3_v1_choice_563044f5:

    # Sara "(I know she’s meant to be my friend... but I feel so... sad and angry, that she flirts with him like this.)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:229
translate chinese after_sis_nerdy_school_scene3_v1_choice_e749b5e4:

    # Sara "(And he’s my brother, I shouldn’t even have feelings about him!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:231
translate chinese after_sis_nerdy_school_scene3_v1_choice_d09528df:

    # Sara "(And he’s just my friend... I shouldn't even have any feelings for him...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:234
translate chinese after_sis_nerdy_school_scene3_v1_choice_3921b1e6:

    # Lily "Mmm..."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:235
translate chinese after_sis_nerdy_school_scene3_v1_choice_0c0c87a2:

    # MC "(Wow! She’s a good kisser!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:236
translate chinese after_sis_nerdy_school_scene3_v1_choice_90ff270c:

    # Sara "(Calm down, Sara... it’s just ONE kiss. You’ll get your turn with him soon.)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:239
translate chinese after_sis_nerdy_school_scene3_v1_choice_137b0962:

    # Lily "(Hehe... I can feel Sara’s eyes on me right now. Why are men always, so much more attractive when other women want them?)"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:240
translate chinese after_sis_nerdy_school_scene3_v1_choice_887a832b:

    # MC "(Her lips are so soft! I could kiss her for hours!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:244
translate chinese after_sis_nerdy_school_scene3_v1_choice_0f2bc35c:

    # Lily "Mmm, that was fun. Thanks, [player_name]."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:245
translate chinese after_sis_nerdy_school_scene3_v1_choice_ac33b12b:

    # Lily "Hopefully that won’t be the last time our lips touch today."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:246
translate chinese after_sis_nerdy_school_scene3_v1_choice_4270a82c:

    # Sara "(That bitch...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:247
translate chinese after_sis_nerdy_school_scene3_v1_choice_b2c94eb0:

    # MC "Y-Yeah, I hope so too!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:250
translate chinese after_sis_nerdy_school_scene3_v1_choice_9f433530:

    # Lily "Your turn, Sara! Who do you want to spin the bottle for?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:251
translate chinese after_sis_nerdy_school_scene3_v1_choice_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:252
translate chinese after_sis_nerdy_school_scene3_v1_choice_6719c05f:

    # Lily "C’mon! We’re burning daylight here!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:253
translate chinese after_sis_nerdy_school_scene3_v1_choice_18d447aa:

    # Sara "I’ll... pass."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:254
translate chinese after_sis_nerdy_school_scene3_v1_choice_7345e158:

    # Lily "Eh? Your loss!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:257
translate chinese after_sis_nerdy_school_scene3_v1_choice_324209bb:

    # Lily "I guess it’s your turn again, [player_name]! Who do you want to spin the bottle for?"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:258
translate chinese after_sis_nerdy_school_scene3_v1_choice_73c4273d:

    # MC "Can I pick myself?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:259
translate chinese after_sis_nerdy_school_scene3_v1_choice_07d96a23:

    # Lily "Hehe! Sure!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:266
translate chinese after_sis_nerdy_school_scene3_v1_choice_83465e50:

    # Lily "Yay! Me again!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:267
translate chinese after_sis_nerdy_school_scene3_v1_choice_fbd100d1:

    # Lily "Hope you’re ready for round two!"
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:270
translate chinese after_sis_nerdy_school_scene3_v1_choice_5a13bea4:

    # MC "(Damn! I never imagined this would turn out to be such an awesome afternoon!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:271
translate chinese after_sis_nerdy_school_scene3_v1_choice_21e802f4:

    # MC "(I ought to hang out with Lily more often!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:277
translate chinese after_sis_nerdy_school_scene3_v1_choice_85f2490d:

    # Sara "(That... fucking bitch! That’s my brother!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:279
translate chinese after_sis_nerdy_school_scene3_v1_choice_f39225d8:

    # Sara "(That... fucking bitch! She was supposed to help me!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:280
translate chinese after_sis_nerdy_school_scene3_v1_choice_b1413407:

    # Sara "(How DARE she think she can just come into my bedroom and make out with him like this?!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:283
translate chinese after_sis_nerdy_school_scene3_v1_choice_85173506:

    # Sara "(I’ll show her. I’ll FUCKING show that slutty little tart!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:285
translate chinese after_sis_nerdy_school_scene3_v1_choice_875c82a9:

    # Sara "Get off my brother!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:287
translate chinese after_sis_nerdy_school_scene3_v1_choice_020a4d45:

    # Sara "Get off him!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:295
translate chinese after_sis_nerdy_school_scene3_v1_choice_e30f71b3:

    # "*SMASH*"
    ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:298
translate chinese after_sis_nerdy_school_scene3_v1_choice_c4dcfa8f:

    # MC "WHAT?!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:299
translate chinese after_sis_nerdy_school_scene3_v1_choice_86a19954:

    # Sara "EEK!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:300
translate chinese after_sis_nerdy_school_scene3_v1_choice_d76ac3ae:

    # Sara "Lily! Get OUT of my house!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:301
translate chinese after_sis_nerdy_school_scene3_v1_choice_be3055de:

    # Lily "Geez! Okay, I’m going! Catch you later, [player_name]."
    Lily ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:304
translate chinese after_sis_nerdy_school_scene3_v1_choice_f1f15d3b:

    # Sara "I don’t want to play this... stupid game anymore."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:305
translate chinese after_sis_nerdy_school_scene3_v1_choice_cf4e28e2:

    # MC "Sara, I-"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:306
translate chinese after_sis_nerdy_school_scene3_v1_choice_7ec2ff2f:

    # Sara "Leave me alone!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:307
translate chinese after_sis_nerdy_school_scene3_v1_choice_e48d3e4d:

    # MC "But-"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:308
translate chinese after_sis_nerdy_school_scene3_v1_choice_a146e16f:

    # Sara "I said I wanted to be alone!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:314
translate chinese after_sis_nerdy_school_scene3_v1_choice_77f81d65:

    # MC "Hey, Sara... It’s alright. What’s wrong?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:315
translate chinese after_sis_nerdy_school_scene3_v1_choice_8eea1b83:

    # Sara "*Sniff*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:316
translate chinese after_sis_nerdy_school_scene3_v1_choice_b3fc7e0f:

    # MC "Are you crying?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:319
translate chinese after_sis_nerdy_school_scene3_v1_choice_67795fad:

    # Sara "I - *Sniff* - I’m s-sorry. When I saw you k-kissng her, I- I..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:320
translate chinese after_sis_nerdy_school_scene3_v1_choice_bc51f5e8:

    # MC "Hey, it’s alright. Shush - it’s okay."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:326
translate chinese after_sis_nerdy_school_scene3_v1_choice_761a60e2:

    # MC "Mwah."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:327
translate chinese after_sis_nerdy_school_scene3_v1_choice_10a50884:

    # Sara "(Oh wow... He’s actually kissing me... )"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:328
translate chinese after_sis_nerdy_school_scene3_v1_choice_be0861d1:

    # Sara "(It’s like one of my dreams coming true...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:334
translate chinese after_sis_nerdy_school_scene3_v1_choice_0704468f:

    # MC "It’s okay, Sara. I think I understand."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:335
translate chinese after_sis_nerdy_school_scene3_v1_choice_8eea1b83_1:

    # Sara "*Sniff*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:336
translate chinese after_sis_nerdy_school_scene3_v1_choice_37e53bb2:

    # MC "There there - I’ve got you. We won’t play that game anymore."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:342
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f1cb1929:

    # Sara "*Sniff* Th-Thank you. D-Do you think you could give me a... real kiss?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:343
translate chinese after_sis_nerdy_school_scene3_v1_choice2_677ad2fd:

    # MC "A real kiss?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:345
translate chinese after_sis_nerdy_school_scene3_v1_choice2_852285a4:

    # Sara "Like Mom and Dad do, when they watch a romantic movie."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:347
translate chinese after_sis_nerdy_school_scene3_v1_choice2_49446923:

    # Sara "Like Linda and Bob do when they watch a romantic movie... Or like in porn..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:348
translate chinese after_sis_nerdy_school_scene3_v1_choice2_5c37b3a0:

    # MC "Of course, Sara. Come closer."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:351
translate chinese after_sis_nerdy_school_scene3_v1_choice2_756120e1:

    # Sara "(Oh my God! He did it! ...This is Heaven!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:353
translate chinese after_sis_nerdy_school_scene3_v1_choice2_3d635c85:

    # MC "(She’s a much better kisser than Lily! It feels like there’s more... passion behind Sara’s kiss.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:354
translate chinese after_sis_nerdy_school_scene3_v1_choice2_5d265f2c:

    # MC "(Why am I going along with this, so freely? She’s my sister! I shouldn’t be kissing her like this. Right?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:356
translate chinese after_sis_nerdy_school_scene3_v1_choice2_3d635c85_1:

    # MC "(She’s a much better kisser than Lily! It feels like there’s more... passion behind Sara’s kiss.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:357
translate chinese after_sis_nerdy_school_scene3_v1_choice2_8cb383a1:

    # MC "(Why am I going along with this so freely? We only just found out that we like each other. I shouldn’t be kissing her like this. Right?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:359
translate chinese after_sis_nerdy_school_scene3_v1_choice2_73c293ab:

    # Sara "Thank you so much, [player_name]."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:360
translate chinese after_sis_nerdy_school_scene3_v1_choice2_359d65c6:

    # MC "What was wrong? You kinda freaked out back there."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:361
translate chinese after_sis_nerdy_school_scene3_v1_choice2_8705fabe:

    # Sara "I... I don’t know... When I saw Lily kissing you, I just got so... irrationally angry."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:362
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f6e6d7f8:

    # MC "It’s okay. I think I understand."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:365
translate chinese after_sis_nerdy_school_scene3_v1_choice2_2c1e31e2:

    # Sara "I... I want to do... something for YOU."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:366
translate chinese after_sis_nerdy_school_scene3_v1_choice2_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:368
translate chinese after_sis_nerdy_school_scene3_v1_choice2_a2bae5be:

    # Sara "I saw a video once... of a woman using her mouth, to suck a guy’s... thing."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:370
translate chinese after_sis_nerdy_school_scene3_v1_choice2_da902cc9:

    # Sara "I.. I saw in a porn video... of a woman sucking on a guy’s dick..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:371
translate chinese after_sis_nerdy_school_scene3_v1_choice2_e49e30f1:

    # MC "What?! Are you talking about giving me a blowjob?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:374
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f6c09fca:

    # Sara "Please, just stay still and let me do this. I really want to make you feel good."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:376
translate chinese after_sis_nerdy_school_scene3_v1_choice2_818c61b1:

    # MC "Sara, I- You’re my little sister."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:378
translate chinese after_sis_nerdy_school_scene3_v1_choice2_8b5d3a93:

    # MC "Sara, I- It's happening so fast! I don’t want to ruin that."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:379
translate chinese after_sis_nerdy_school_scene3_v1_choice2_0acb455e:

    # Sara "Shush! Just let me pull your trousers down."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:382
translate chinese after_sis_nerdy_school_scene3_v1_choice2_378579b4:

    # MC "Sara, wait. Are you sure about this?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:383
translate chinese after_sis_nerdy_school_scene3_v1_choice2_faa1ac27:

    # Sara "I- Um... yeah, I am."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:384
translate chinese after_sis_nerdy_school_scene3_v1_choice2_1f6647f0:

    # MC "I don’t want you doing something that you’ll regret later on."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:387
translate chinese after_sis_nerdy_school_scene3_v1_choice2_547a22c9:

    # Sara "If I’m going to do it for you, there’s no way I could ever regret it."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:388
translate chinese after_sis_nerdy_school_scene3_v1_choice2_e4f3dac2:

    # MC "Are you sure? Have you done anything like this before?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:390
translate chinese after_sis_nerdy_school_scene3_v1_choice2_336b3046:

    # Sara "No... this is my first time."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:392
translate chinese after_sis_nerdy_school_scene3_v1_choice2_16d46c0e:

    # Sara "I’d a boyfriend before, but we never really did anything... I wanted to go slow, but he ended up cheating."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:393
translate chinese after_sis_nerdy_school_scene3_v1_choice2_154c2e3d:

    # MC "Let me sit down on the bed, to make it easier for you then."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:394
translate chinese after_sis_nerdy_school_scene3_v1_choice2_04691602:

    # Sara "Is there anything else I should do?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:395
translate chinese after_sis_nerdy_school_scene3_v1_choice2_8db73fa8:

    # MC "Could you take your top off before you start?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:396
translate chinese after_sis_nerdy_school_scene3_v1_choice2_ccfa597d:

    # Sara "(Ahh... That’s so embarrassing... I feel like I should do it for him though...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:397
translate chinese after_sis_nerdy_school_scene3_v1_choice2_c0f9a610:

    # Sara "O-Okay..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:400
translate chinese after_sis_nerdy_school_scene3_v1_choice2_b39178eb:

    # MC "Wow... You look so hot, Sara."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:401
translate chinese after_sis_nerdy_school_scene3_v1_choice2_ad17c1a3:

    # Sara "Th-Thank you..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:402
translate chinese after_sis_nerdy_school_scene3_v1_choice2_1251f229:

    # Sara "Do... *Gulp* ...do you want me to continue?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:403
translate chinese after_sis_nerdy_school_scene3_v1_choice2_d60d860a:

    # MC "Go ahead and pull down my underwear."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:410
translate chinese after_sis_nerdy_school_scene3_v1_choice2_d3862519:

    # Sara "Wow!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:411
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f8148128:

    # Sara "(It’s bigger than I remember! How can I possibly get it all in my mouth?)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:412
translate chinese after_sis_nerdy_school_scene3_v1_choice2_ccc566f8:

    # Sara "Hehe! It’s all bouncy..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:413
translate chinese after_sis_nerdy_school_scene3_v1_choice2_1e11f49a:

    # MC "(She definitely hasn't played with a cock as big as mine before. I guess I’ll just let her have some fun for a bit!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:415
translate chinese after_sis_nerdy_school_scene3_v1_choice2_05b885e9:

    # Sara "Can you feel it when I do this?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:417
translate chinese after_sis_nerdy_school_scene3_v1_choice2_c2d156ce:

    # Sara "Do you like it?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:418
translate chinese after_sis_nerdy_school_scene3_v1_choice2_5950f323:

    # MC "Yeah, but it feels better if you wrap your hands around it and move them up and down."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:421
translate chinese after_sis_nerdy_school_scene3_v1_choice2_4eb3bad5:

    # Sara "Sure. Just like this, [player_name]?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:422
translate chinese after_sis_nerdy_school_scene3_v1_choice2_267a6ae0:

    # MC "Ahh... That’s good, Sara."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:423
translate chinese after_sis_nerdy_school_scene3_v1_choice2_e4f3bc91:

    # Sara "Hehe... You’re smiling!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:424
translate chinese after_sis_nerdy_school_scene3_v1_choice2_20f52615:

    # MC "That’s because it feels really good."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:427
translate chinese after_sis_nerdy_school_scene3_v1_choice2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:428
translate chinese after_sis_nerdy_school_scene3_v1_choice2_0f656946:

    # Sara "(It keeps getting harder, the more I move!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:430
translate chinese after_sis_nerdy_school_scene3_v1_choice2_7fe10f91:

    # Sara "(I’d only ever dreamed about touching [player_name]'s cock before! It’s actually happening now!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:432
translate chinese after_sis_nerdy_school_scene3_v1_choice2_a57c1bb2:

    # Sara "(I’d only ever dreamed about touching his cock before! It’s actually happening now!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:433
translate chinese after_sis_nerdy_school_scene3_v1_choice2_bacc4b22:

    # MC "Okay - you can start licking next. Just use your tongue to swirl around the tip of my cock."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:436
translate chinese after_sis_nerdy_school_scene3_v1_choice2_4477905b:

    # Sara "(His smell is kind of funny...)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:437
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f6041a73:

    # MC "Ohh... That’s good. Keep going, Sara."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:441
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f6f8ade0:

    # Sara "Am I doing it right, [player_name]?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:443
translate chinese after_sis_nerdy_school_scene3_v1_choice2_939cd4de:

    # Sara "Do you like it, [player_name]?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:444
translate chinese after_sis_nerdy_school_scene3_v1_choice2_b69772ab:

    # MC "Y-Yeah, it’s so good."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:445
translate chinese after_sis_nerdy_school_scene3_v1_choice2_a48c40b4:

    # Sara "What do you want me to do next?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:448
translate chinese after_sis_nerdy_school_scene3_v1_choice2_62be09e7:

    # MC "Try and take my cock in your mouth."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:449
translate chinese after_sis_nerdy_school_scene3_v1_choice2_fc617ad1:

    # Sara "A-All of it?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:450
translate chinese after_sis_nerdy_school_scene3_v1_choice2_b8043367:

    # Sara "(It’s so big... I don’t think I’ll be able to get, even HALF of it in my mouth!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:453
translate chinese after_sis_nerdy_school_scene3_v1_choice2_e0dacdc7:

    # MC "Just relax - you don’t have to do the whole thing. Just go as far as you can, without making yourself uncomfortable."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:454
translate chinese after_sis_nerdy_school_scene3_v1_choice2_0fa94e0d:

    # Sara "But I want to make you feel good too..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:455
translate chinese after_sis_nerdy_school_scene3_v1_choice2_17202f4a:

    # MC "It’ll feel good - you don’t need to hurt yourself."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:456
translate chinese after_sis_nerdy_school_scene3_v1_choice2_ad2e793c:

    # Sara "O-Okay!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:459
translate chinese after_sis_nerdy_school_scene3_v1_choice2_1cb75114:

    # Sara "*Shlurrrp*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:460
translate chinese after_sis_nerdy_school_scene3_v1_choice2_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:461
translate chinese after_sis_nerdy_school_scene3_v1_choice2_32f3b75b:

    # MC "(Mmm... This feels good. She’s being so gentle with her lips!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:464
translate chinese after_sis_nerdy_school_scene3_v1_choice2_dfd1d230:

    # Sara "*Shllurrrrrrrpp*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:465
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f53e94af:

    # Sara "(I don’t think I can go much deeper than this!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:467
translate chinese after_sis_nerdy_school_scene3_v1_choice2_1f24051a:

    # MC "Easy, Sara. You don’t need to push yourself - it’s your first time."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:469
translate chinese after_sis_nerdy_school_scene3_v1_choice2_87973a72:

    # MC "Easy, Sara. You don’t need to push yourself!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:470
translate chinese after_sis_nerdy_school_scene3_v1_choice2_a593a95d:

    # MC "This feels amazing, I promise."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:473
translate chinese after_sis_nerdy_school_scene3_v1_choice2_c53beae8:

    # MC "(I can’t believe that Sara was sexually attracted to me. How long has she felt this way?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:475
translate chinese after_sis_nerdy_school_scene3_v1_choice2_4dda7640:

    # MC "(Was I really, so obsessed with my professor that I never even noticed my own sister’s affections for me?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:477
translate chinese after_sis_nerdy_school_scene3_v1_choice2_90effdb0:

    # MC "(Was I really so obsessed with Ms. Celia that I never even noticed her growing affection for me?)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:478
translate chinese after_sis_nerdy_school_scene3_v1_choice2_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:481
translate chinese after_sis_nerdy_school_scene3_v1_choice2_99e81497:

    # Sara "*Shlurp Suck*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:482
translate chinese after_sis_nerdy_school_scene3_v1_choice2_fd2d12eb:

    # MC "Ohh! Ahh!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:483
translate chinese after_sis_nerdy_school_scene3_v1_choice2_24d3125b:

    # MC "(I’m gonna cum soon if she keeps this up! It’s probably her first time giving a blowjob, but she’s pretty damn good at it!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:486
translate chinese after_sis_nerdy_school_scene3_v1_choice2_19d20c70:

    # MC "(I’m gonna cum soon. I should let her know!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:487
translate chinese after_sis_nerdy_school_scene3_v1_choice2_a2e4f161:

    # MC "Sara! I’m about to cum! Sara..!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:488
translate chinese after_sis_nerdy_school_scene3_v1_choice2_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:491
translate chinese after_sis_nerdy_school_scene3_v1_choice2_e9215d3b:

    # MC "Ahhh! Fuck! I’m cumming!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:492
translate chinese after_sis_nerdy_school_scene3_v1_choice2_289b0f2e:

    # Sara "(Wow! I can feel him shaking and trembling! He must really, love me doing this!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:493
translate chinese after_sis_nerdy_school_scene3_v1_choice2_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:494
translate chinese after_sis_nerdy_school_scene3_v1_choice2_f737602b:

    # Sara "(I should take the whole head of his cock, in my mouth, while he cums!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:497
translate chinese after_sis_nerdy_school_scene3_v1_choice2_b3cad473:

    # MC "Ahhhh! Yes! Ugh!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:498
translate chinese after_sis_nerdy_school_scene3_v1_choice2_3ac0d78b:

    # Sara "(I can feel it filling my mouth! It’s really warm and salty!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:499
translate chinese after_sis_nerdy_school_scene3_v1_choice2_8ace9305:

    # MC "Fuck! Ah! You’re so good, Sara!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:505
translate chinese after_sis_nerdy_school_scene3_v1_choice2_0869b5c3:

    # MC "Ah! You can stop now - I’m done!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:508
translate chinese after_sis_nerdy_school_scene3_v1_choice2_7f340c8a:

    # Sara "Wha duh I duh wuh thus?"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:509
translate chinese after_sis_nerdy_school_scene3_v1_choice2_d3bc2a54:

    # MC "(I think she’s asking what she does with my cum now.)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:514
translate chinese after_sis_nerdy_school_scene3_v1_choice2_08c11554:

    # MC "I want to see you swallow my cum."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:517
translate chinese after_sis_nerdy_school_scene3_v1_choice2_152e3a83:

    # Sara "*GULP*"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:518
translate chinese after_sis_nerdy_school_scene3_v1_choice2_61f06ace:

    # Sara "(Huh? His sperm is good... )"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:520
translate chinese after_sis_nerdy_school_scene3_v1_choice2_dc35ac4d:

    # Sara "Ahh! All gone!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:521
translate chinese after_sis_nerdy_school_scene3_v1_choice2_1ef2b55f:

    # MC "Thank you, Sara. You’re adorable."
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:522
translate chinese after_sis_nerdy_school_scene3_v1_choice2_03144d53:

    # Sara "Hehe... I know!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:527
translate chinese after_sis_nerdy_school_scene3_v1_choice2_08bf870b:

    # MC "Some girls swallow cum, but you don’t have to if you don’t want-"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:529
translate chinese after_sis_nerdy_school_scene3_v1_choice2_c59f35e4:

    # Sara "*Gulp!* Ahh!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:530
translate chinese after_sis_nerdy_school_scene3_v1_choice2_cb505d6b:

    # Sara "(I hope he’ll like me more if I swallow all his cum!)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:532
translate chinese after_sis_nerdy_school_scene3_v1_choice2_6d3bed4f:

    # Sara "All gone!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:533
translate chinese after_sis_nerdy_school_scene3_v1_choice2_31573640:

    # MC "You didn’t have to do that on your first time!"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:534
translate chinese after_sis_nerdy_school_scene3_v1_choice2_95c56bf6:

    # Sara "I wanted to. I wanted to make it the best for you!"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:539
translate chinese after_sis_nerdy_school_scene3_v1_choice3_5528638c:

    # Sara "I really love you, [player_name]."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:540
translate chinese after_sis_nerdy_school_scene3_v1_choice3_cd1d0227:

    # Sara "(It feels so good lying against him - feeling his clothes against my skin.)"
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:541
translate chinese after_sis_nerdy_school_scene3_v1_choice3_b21305ff:

    # MC "(Wow... She really likes me a whole lot!)"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:543
translate chinese after_sis_nerdy_school_scene3_v1_choice3_ac6eac16:

    # Sara "I want to lie here with you for a while..."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:544
translate chinese after_sis_nerdy_school_scene3_v1_choice3_32be2a74:

    # MC "Are you comfy?"
    MC ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:545
translate chinese after_sis_nerdy_school_scene3_v1_choice3_3b3dbf13:

    # Sara "Yeah."
    Sara ""

# game/scripts/school/school_entrace/day/scenes/sara_school_scene3_v1.rpy:546
translate chinese after_sis_nerdy_school_scene3_v1_choice3_c9ef1493:

    # MC "Just relax, then. Thank you so much for everything, Sara."
    MC ""

