﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:12
translate chinese SR2_AS4_label_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:25
translate chinese SR2_AS4_label_5fef692a:

    # MC "(There’s Sara - it’s nice to see her smiling for a change.)"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:26
translate chinese SR2_AS4_label_d7c2e136:

    # MC "Hey Sara! You’re looking in a better mood today!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:27
translate chinese SR2_AS4_label_30558d98:

    # Sara "Hi, [player_name]. Yeah, I’m feeling a bit better."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:31
translate chinese SR2_AS4_label_1763ce00:

    # MC "I’m happy to hear that. Is the studying getting easier?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:32
translate chinese SR2_AS4_label_d3c78a1a:

    # Sara "Oh, God no. That’s still hell!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:33
translate chinese SR2_AS4_label_82db5f23:

    # MC "What made you so happy, then?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:34
translate chinese SR2_AS4_label_d8513932:

    # Sara "*Whispered* I was just thinking about lying beside you last night. It was so wonderful just lying there with my head on your chest, listening to your heart beating."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:35
translate chinese SR2_AS4_label_87d7c51b:

    # Sara "I’d never felt, more at peace, in my life."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:36
translate chinese SR2_AS4_label_d0c88e40:

    # MC "Aww, that’s so sweet. I loved cuddling you at night too."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:50
translate chinese SR2_AS4_menu_d27b54e8:

    # Sara "So, why did you come to visit me?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:55
translate chinese SR2_AS4_menu_df12d6b4:

    # MC "How’s your studying going? Have your grades improved at, all?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:56
translate chinese SR2_AS4_menu_8b4fc81a:

    # Sara "Ugh, do we HAVE to talk about this?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:57
translate chinese SR2_AS4_menu_292ab96b:

    # MC "The sooner you get your grades back on track, the sooner I get to spend more time with you again!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:61
translate chinese SR2_AS4_menu_281eb6a8:

    # Sara "I know. I know... It’s just... every time you bring it up, it reminds me that I was super lazy."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:63
translate chinese SR2_AS4_menu_c81a0e4d:

    # MC "Okay, I’ll try not to bring the topic up again. Just... try to get your grades up soon, okay? I don’t want you to be grounded forever."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:65
translate chinese SR2_AS4_menu_7a1959e3:

    # MC "Okay, I’ll try not to bring the topic up again. Just... try to get your grades up soon, okay?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:66
translate chinese SR2_AS4_menu_369a3c90:

    # Sara "I’ll try to get back on track as soon as I can, I promise."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:77
translate chinese SR2_AS4_menu_984c962b:

    # MC "Did you enjoy me using the vibrator on you?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:81
translate chinese SR2_AS4_menu_5a8b0d71:

    # Sara "Y-Yeah, kinda. It was just... very very sensitive."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:83
translate chinese SR2_AS4_menu_94f988dd:

    # Sara "I suppose that’s because I’ve never really done anything like that before - so my body isn’t completely used to it."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:85
translate chinese SR2_AS4_menu_1de5fdc3:

    # Sara "I-I like it... I never used a vibrator that would be that strong..."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:89
translate chinese SR2_AS4_menu_21590ea3:

    # Sara "But don’t worry - I’ll be making sure to use it VERY regularly."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:90
translate chinese SR2_AS4_menu_280673ca:

    # Sara "Someday soon, you’ll be able to use it on me, for as long as you want."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:91
translate chinese SR2_AS4_menu_f9dc4b2f:

    # MC "I’m looking forward to that!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:102
translate chinese SR2_AS4_menu_d6b8449f:

    # MC "I don’t think I’ve ever asked you: What’s your favourite subject?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:103
translate chinese SR2_AS4_menu_ff4f2e93:

    # Sara "In college?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:104
translate chinese SR2_AS4_menu_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:105
translate chinese SR2_AS4_menu_bf24345f:

    # Sara "Hmm... To be honest, I haven’t really been interested in any of them at all, lately."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:106
translate chinese SR2_AS4_menu_b69d9030:

    # Sara "I guess, before I really got into video games I enjoyed Maths. It was nice knowing that your answer was either right or wrong - you didn’t have shades of grey, like in History or English literature."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:117
translate chinese SR2_AS4_menu_e93d1d19:

    # MC "I just wanted to come by to say thanks for the amazing blowjob."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:118
translate chinese SR2_AS4_menu_38e6c36f:

    # Sara "H-Hey! We’re in class! Someone might hear us..."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:119
translate chinese SR2_AS4_menu_0ceec953:

    # MC "Everyone’s talking to each other - nobody’s gonna be listening."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:120
translate chinese SR2_AS4_menu_8b9dc7cf:

    # MC "I just had to come and tell you that it felt absolutely amazing. Your technique was brilliant. And the way you swallowed it at the end... God... it felt so fucking great."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:124
translate chinese SR2_AS4_menu_bd52d8af:

    # Sara "Really? You enjoyed it that much?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:125
translate chinese SR2_AS4_menu_f1367ba1:

    # MC "Oh yeah."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:126
translate chinese SR2_AS4_menu_409fd90a:

    # Sara "Mmm, I guess I’ll just have to give you another one, then. I’ll try and take your cock deeper into my mouth next time. Would you like that?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:127
translate chinese SR2_AS4_menu_4d624174:

    # MC "That’d be awesome!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:139
translate chinese SR2_AS4_menu_4db56870:

    # MC "I just wanted to drop by and say that the footjob you gave me was sooo good."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:141
translate chinese SR2_AS4_menu_cf6065c4:

    # Sara "R-Really? You enjoyed it? It was my first time, so I wasn’t sure if I was doing it right."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:143
translate chinese SR2_AS4_menu_215e77a6:

    # Sara "R-Really? You enjoyed it? It was my first time with my feet, so I wasn't sure if I was doing it right. Watching others do it in porn and doing it myself are VERY different."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:144
translate chinese SR2_AS4_menu_3ac86bee:

    # MC "Trust me, you were brilliant!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:148
translate chinese SR2_AS4_menu_1a02643c:

    # Sara "Yay! I guess it paid off then!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:149
translate chinese SR2_AS4_menu_9c1ac953:

    # MC "Huh? What paid off?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:153
translate chinese SR2_AS4_menu_c0a72796:

    # Sara "Learning from the best teacher there is! You!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:154
translate chinese SR2_AS4_menu_c28b6d4b:

    # MC "Haha! You're very sweet."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:155
translate chinese SR2_AS4_menu_bfbed597:

    # Sara "I also spent a few hours, searching sex techniques on the internet. I tried to teach myself as much as I could."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:156
translate chinese SR2_AS4_menu_17523dfa:

    # MC "Seriously? Did you learn any new tricks?"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:157
translate chinese SR2_AS4_menu_a85e17d1:

    # Sara "Oh yeah! But that’s for me to know, and you to find out!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:173
translate chinese SR2_AS4_continue_49c0d4a3:

    # MC "Okay, I better head on now. It was good seeing you today, Sara."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:174
translate chinese SR2_AS4_continue_e16a358c:

    # Sara "Wait - before you go... Do you think we could chat on webcam this evening?"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:176
translate chinese SR2_AS4_continue_5c239642:

    # Sara "I’m confined to my room, but Mom hasn’t taken away my laptop - so we could chat on that."
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:178
translate chinese SR2_AS4_continue_572856fc:

    # Sara "I'll be studying in my room, but I still have a laptop so we could chat on that!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:179
translate chinese SR2_AS4_continue_5c81ea53:

    # MC "Yeah, sure. I’ll see you this evening."
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:183
translate chinese SR2_AS4_continue_e3a31de6:

    # Sara "Yay! I’m looking forward to it!"
    Sara ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:184
translate chinese SR2_AS4_continue_36d4ef6d:

    # MC "Great! See you later then, Sara!"
    MC ""

# game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:185
translate chinese SR2_AS4_continue_00e2d772:

    # Sara "See ya!"
    Sara ""

translate chinese strings:

    # game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:51
    old "How is your studying going?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:51
    old "Did you enjoy me using the vibrator on you?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:51
    old "What’s your favourite subject?"
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:51
    old "I just wanted to come by and say thanks for the amazing blowjob."
    new ""

    # game/scripts/school/classroom2/day/scenes/SR2_AS4.rpy:51
    old "That footjob you gave me was sooo good!"
    new ""

