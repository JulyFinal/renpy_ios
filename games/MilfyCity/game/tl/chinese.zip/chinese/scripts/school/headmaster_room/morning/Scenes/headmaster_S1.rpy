﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:21
translate chinese headmaster_S1_5516f816:

    # MC "(Well, this is the Dean’s office. I suppose I should knock before going in. I’ve only seen this guy a couple of times before. He’s a bit of a recluse - students hardly ever see him walking the corridors.)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:23
translate chinese headmaster_S1_d9018f3c:

    # "*KNOCK KNOCK*"
    ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:26
translate chinese headmaster_S1_608b784c:

    # Headmaster "Yo yo! The door’s open!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:38
translate chinese headmaster_S1_23981847:

    # Headmaster "Wassup, my man? I recognise your face, but I can’t put a name to it."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:39
translate chinese headmaster_S1_3303e48d:

    # MC "It’s [player_name], sir."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:40
translate chinese headmaster_S1_f2399d92:

    # Headmaster "Ahh, [player_name]. Now WHY does that ring a bell when I hear it. Hmm..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:44
translate chinese headmaster_S1_26390318:

    # Headmaster "You didn’t win the college any awards, did ya?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:45
translate chinese headmaster_S1_ccaf2da6:

    # MC "No, sir."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:46
translate chinese headmaster_S1_99e9dd3a:

    # Headmaster "No debating competitions, no sports trophies?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:47
translate chinese headmaster_S1_644a950c:

    # MC "Umm, no. I’m honestly not that into either of those."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:51
translate chinese headmaster_S1_b06a01f9:

    # Headmaster "[player_name]. [player_name], [player_name]..."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:53
translate chinese headmaster_S1_520fd7ec:

    # Headmaster "AHA! Back up a second - you’re that fella who asked Professor Celia out, ain’t cha?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:54
translate chinese headmaster_S1_b3c0a930:

    # MC "(Oh God, is THAT the only reason people know my name in this college?!)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:55
translate chinese headmaster_S1_d94837ff:

    # MC "Yeah... that was... me, sir."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:56
translate chinese headmaster_S1_8ed71707:

    # MC "Is that why you called me, sir?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:60
translate chinese headmaster_S1_2709328f:

    # Headmaster "Hell! No! I just needed to talk to you. Ya' know. College procedures."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:61
translate chinese headmaster_S1_3143558a:

    # Headmaster "Also... Just to think about it!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:62
translate chinese headmaster_S1_feaf968e:

    # Headmaster "Ouch! I feel for you, man. I really do."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:63
translate chinese headmaster_S1_e2e57540:

    # Headmaster "Geez, that’s a real doozy. You know what - props to you, son. Forget what everyone else says about you being a weirdo."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:64
translate chinese headmaster_S1_9d21ca8f:

    # MC "What?! Everyone’s saying I’m a weirdo?!"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:65
translate chinese headmaster_S1_ac74742d:

    # Headmaster "I said forget about it! In my eyes, you’ve got cojones of pure iron!"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:68
translate chinese headmaster_S1_47a4e55a:

    # Headmaster "Seriously, you just marched right up to her and declared your love. I mean, what chance did you have? One in a million?"
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:69
translate chinese headmaster_S1_0f558ae2:

    # MC "I guess, in hindsight I-"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:70
translate chinese headmaster_S1_b0318c17:

    # Headmaster "You were like Han fuckin’ Solo doing that asteroid belt shit."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:71
translate chinese headmaster_S1_baa086cf:

    # MC "(I’ve never seen any of the other professors wearing as much jewelry as the Dean does. He must earn A LOT more than them!)"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:75
translate chinese headmaster_S1_da2fc11a:

    # Headmaster "So yeah - Major respect for you."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:76
translate chinese headmaster_S1_e05426a9:

    # MC "Umm, thank you, sir?"
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:77
translate chinese headmaster_S1_cef2fb42:

    # Headmaster "Ahem I guess I do have to warn you, not to make any... uh... sexual advances on any other professors."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:78
translate chinese headmaster_S1_7a6e0022:

    # MC "I’ll try not to, sir."
    MC ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:79
translate chinese headmaster_S1_6b5227c1:

    # Headmaster "The college counsellor, Judy, is keeping me abreast on your progress with her."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:80
translate chinese headmaster_S1_2de88887:

    # Headmaster "Oh, and one more thing. Please go and have a nice talk with Professor Celia."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:81
translate chinese headmaster_S1_32db6ae7:

    # Headmaster "Apologize to her nicely... It's not must be honest but that's the stuff you have to do my man."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:85
translate chinese headmaster_S1_91efff89:

    # Headmaster "I know taking these therapy sessions with Judy can be embarrassing, especially with all your gossiping peers."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:86
translate chinese headmaster_S1_bb0b19f2:

    # Headmaster "I just wanted to urge you to continue seeing Judy. Don’t slack off on your mental health. Taking care of your mind is just as important as exercising."
    Headmaster ""

# game/scripts/school/headmaster_room/morning/Scenes/headmaster_S1.rpy:87
translate chinese headmaster_S1_293ebc11:

    # Headmaster "Now, I’ve taken up enough of your time, and you should probably go see Ms. Celia. See ya around, Iron Cojones."
    Headmaster ""

