﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/school/therapist_room/morning/scenes/judy_morning_cupboardv1.rpy:11
translate chinese judy_morning_empty_envelopev1_label_18a4589a:

    # MC "(Great, now I only need a pen.)"
    MC ""

# game/scripts/school/therapist_room/morning/scenes/judy_morning_cupboardv1.rpy:12
translate chinese judy_morning_empty_envelopev1_label_0ff7ab5b:

    # MC "(I think I have a few in my locker in the college corridor.)"
    MC ""

