﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/pool_minigame.rpy:45
translate chinese pool_minigame_not_selected_1024c156:

    # "Cleaning stuff has to be selected."
    ""

# game/scripts/pool_minigame.rpy:47
translate chinese pool_minigame_not_selected_9371dd31:

    # MC "(It's too late for cleaning the pool.)"
    MC ""

# game/scripts/pool_minigame.rpy:63
translate chinese pool_minigame_start0_363e7cd6:

    # MC "(I should start cleaning the pool tomorrow.)"
    MC ""

# game/scripts/pool_minigame.rpy:72
translate chinese pool_minigame_start0_9371dd31:

    # MC "(It's too late for cleaning the pool.)"
    MC ""

# game/scripts/pool_minigame.rpy:87
translate chinese pool_minigame_start0_1b0e4322:

    # MC "(That's enough for today. I'm exhausted.)"
    MC ""

# game/scripts/pool_minigame.rpy:148
translate chinese pool_minigame_end_ff1656f9:

    # MC "(Okay, that's enough for today. I'm exhausted.) {color=#00ff00}(+15$){/color}"
    MC ""

# game/scripts/pool_minigame.rpy:155
translate chinese pool_minigame_end_eb37ae1e:

    # MC "(I've finally finished cleaning it. I should go and tell them.) {color=#00ff00}(+15$){/color}"
    MC ""

