﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/1_Vi_S1.rpy:30
translate chinese Vi_S1_db5dfb91:

    # MC "(There she is. I wonder what she needs to speak to me so urgently about?)"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:31
translate chinese Vi_S1_e25f9585:

    # MC "Hey Violet, I got your text - I came as quickly as I could."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:33
translate chinese Vi_S1_c85ff4db:

    # Violet "Thank God you came! I’ve... uh... kinda got myself in a bit of a tough spot again."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:34
translate chinese Vi_S1_84de9ad7:

    # MC "Tough spot? What do you mean? What’s going on?"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:36
translate chinese Vi_S1_d6a42527:

    # Violet "You remember my brother Dwayne, right?"
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:38
translate chinese Vi_S1_e27e58a8:

    # MC "Yeah, the arrogant dickhead?"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:39
translate chinese Vi_S1_de3b504c:

    # Violet "That’s the one. Anyway, he’s hitting me up for money again. God knows what he needs the cash for. Probably hookers and coke."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:41
translate chinese Vi_S1_3b0ed108:

    # Violet "ANYWAY, the last time this happened I... uh... kinda robbed Caroline’s store."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:42
translate chinese Vi_S1_8b8a0f9b:

    # MC "Uh huh. I know. I was the one who had to work to rebuild that shop after you nearly wrecked the business. Speaking of which: is Caroline not paying you enough to give some to your brother?"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:43
translate chinese Vi_S1_3de32d02:

    # Violet "Ha! I wish. He’s wanting a grand from me."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:45
translate chinese Vi_S1_3e92d9a2:

    # MC "A thousand dollars?! Have you considered just telling him to fuck off?"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:46
translate chinese Vi_S1_3bd31bae:

    # Violet "You’ve seen Dwayne, [player_name]. He’s built like a tank and hits just as hard as one."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:47
translate chinese Vi_S1_092069a1:

    # MC "But, he’s your brother! He’s not going to-"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:49
translate chinese Vi_S1_af43e637:

    # Violet "Do you really think it makes a difference that I’m his sister? The bastard would take a swing at me just as quickly as he would some guy that pissed him off."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:50
translate chinese Vi_S1_333b1fb1:

    # MC "Fuck..."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:62
translate chinese Vi_S1_menu_e5a07e1d:

    # MC "Here, this should be enough."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:63
translate chinese Vi_S1_menu_d1f3dd2d:

    # Violet "Wh-What? You’d just give me a thousand dollars, like that? Why?"
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:65
translate chinese Vi_S1_menu_609386c8:

    # MC "Because you’re in trouble. Because you need help."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:66
translate chinese Vi_S1_menu_527c2456:

    # Violet "But... I’m a piece of shit. I robbed my best friend’s... my ONLY friend’s shop when I thought I could get away with it."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:68
translate chinese Vi_S1_menu_fa2de967:

    # MC "You’re not a piece of shit, Violet. You’re a good person who’s just been dealt a shit hand in life."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:69
translate chinese Vi_S1_menu_2b9ed080:

    # Violet "I can’t... I can’t take your money."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:70
translate chinese Vi_S1_menu_cedae414:

    # MC "I insist. Take the cash. I don’t know how I’m going to help you deal with your Dwayne problem in the long term, but what I can do is buy you a few days - without him breathing down your neck."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:72
translate chinese Vi_S1_menu_3ef75f08:

    # Violet "...thank you, [player_name]. You and Caroline have both been so kind to me. I don’t know how I could ever repay you."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:73
translate chinese Vi_S1_menu_089b85c3:

    # MC "I’m sure we’ll come up with something. Put that out of your head right now, though. Just pay Dwayne and I’ll try to figure out a way to get him to back off."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:75
translate chinese Vi_S1_menu_37059051:

    # Violet "Dwayne always goes out drinking in the afternoon. You should stop by my house then. I live around the Dark Alley."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:76
translate chinese Vi_S1_menu_44c1c144:

    # MC "No problem, I’ll drop by when I get a chance. Catch you later, Violet."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:77
translate chinese Vi_S1_menu_e88a5444:

    # Violet "Thanks again, [player_name]. I really appreciate everything you and Caroline have done for me."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:78
translate chinese Vi_S1_menu_d5b4a0f9:

    # MC "Anytime, Violet."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:94
translate chinese Vi_S1_menu_1a72c9b5:

    # MC "(That’s an awful lot of money... I really want to help her, but perhaps I should get my finances in order first.)"
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:95
translate chinese Vi_S1_menu_3ade63a9:

    # MC "I’m really sorry, Violet. I don’t have that kinda cash on me right now."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:97
translate chinese Vi_S1_menu_c5be565f:

    # Violet "*Sigh* It’s alright, I understand. I think... I think I’m going to have to try and find a low risk business to target."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:98
translate chinese Vi_S1_menu_046b82dd:

    # MC "Violet... I’m sorry."
    MC ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:100
translate chinese Vi_S1_menu_5ddd26d5:

    # Violet "I swear I’ll leave Caroline’s cosplay shop alone. You two have already done so much for me. I promise you, I would NEVER do anything to hurt either of you again."
    Violet ""

# game/scripts/Vi_scenes/1_Vi_S1.rpy:101
translate chinese Vi_S1_menu_c6773a59:

    # MC "*Sigh* Try to hold on a little bit longer. I’ll see if I can raise some money to help out."
    MC ""

translate chinese strings:

    # game/scripts/Vi_scenes/1_Vi_S1.rpy:57
    old "{color=#00ff00}Give Violet $1000 to pay her brother.{/color}"
    new ""

    # game/scripts/Vi_scenes/1_Vi_S1.rpy:57
    old "Don’t give Violet $1000."
    new ""

    # game/scripts/Vi_scenes/1_Vi_S1.rpy:57
    old "Give Violet $1000 to pay her brother. (locked)"
    new ""

