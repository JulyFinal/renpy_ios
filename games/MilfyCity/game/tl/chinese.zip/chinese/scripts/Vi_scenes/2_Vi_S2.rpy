﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/2_Vi_S2.rpy:69
translate chinese Vi_S2_locked_d8190367:

    # MC "(Let's talk with Dwayne.)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:74
translate chinese Vi_S2_locked_b74e1846:

    # MC "(Violet is waiting for me in the Spa.)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:90
translate chinese Vi_S2_fa1d6dcd:

    # MC "(Violet said I should visit her in the afternoon when Dwayne isn’t around. I’ve got my fingers crossed he doesn't show up when I’m here. The guy is a fucking psycho!)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:91
translate chinese Vi_S2_0d0fe85f:

    # MC "(God knows how Violet puts up with him.)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:94
translate chinese Vi_S2_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:95
translate chinese Vi_S2_2ee2407c:

    # MC "(I hope this is the right house...)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:98
translate chinese Vi_S2_eb99954b:

    # Violet "Hey, [player_name], you came!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:99
translate chinese Vi_S2_488bcc44:

    # MC "Hey Violet, I was beginning to wonder if I’d taken a wrong turn."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:100
translate chinese Vi_S2_0137ad76:

    # Violet "Yeah, I know. This whole neighbourhood is a shithole."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:102
translate chinese Vi_S2_5ed63e7e:

    # Violet "C’mon in! Dwayne isn’t here, so we have some peace and quiet to chat."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:103
translate chinese Vi_S2_42e69780:

    # MC "Glad to hear it. That guy scares the crap outta me."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:104
translate chinese Vi_S2_c8262c3f:

    # Violet "I’d love to say my brother is all bark and no bite, but that isn’t true."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:106
translate chinese Vi_S2_60585bf1:

    # Violet "Can I get you anything to drink, by the way? Tea? Coffee? I’d offer you a beer, but Dwayne freaks out when he thinks I’ve taken one."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:107
translate chinese Vi_S2_3d24dc1d:

    # MC "Don’t worry, I’m happy with a coffee."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:108
translate chinese Vi_S2_3c5faad6:

    # Violet "Great, c’mon into the kitchen. I’ll brew some now."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:110
translate chinese Vi_S2_08e9f0b4:

    # Violet "There you go!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:111
translate chinese Vi_S2_6339a579:

    # MC "Cheers! Appreciate it. I gotta say, I love your dress by the way. You look fantastic in it."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:112
translate chinese Vi_S2_79dfab8e:

    # Violet "Aww, that’s very sweet of you."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:114
translate chinese Vi_S2_f7a5231b:

    # Violet "It’s one of my raunchier dresses. I figured that wearing it for you was the LEAST I could do, after you bailed me out."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:115
translate chinese Vi_S2_c79df1e6:

    # MC "Don’t sweat it. I’m just glad you didn’t have to risk robbing another shop."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:116
translate chinese Vi_S2_9a9bbbd1:

    # Violet "Haha, true. Oh, Caroline has been telling me that this dress is WAY too short on me. Tell me, [player_name], what do you think?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:118
translate chinese Vi_S2_fe990132:

    # MC "Wow! I, uh..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:119
translate chinese Vi_S2_11a42640:

    # Violet "It isn’t too distracting, is it?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:120
translate chinese Vi_S2_59bb0777:

    # MC "(She’s not wearing any panties! AND she shaved her pussy too! There’s NO way she isn’t doing this on purpose! Right?)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:122
translate chinese Vi_S2_6464d347:

    # MC "N-No, not too short at all!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:123
translate chinese Vi_S2_4876f42c:

    # Violet "Are you sure? You definitely can’t see too much when I’m sitting down?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:124
translate chinese Vi_S2_f8ac28bd:

    # MC "N-No! You look *gulp* fantastic! It’s a great dress."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:125
translate chinese Vi_S2_7184fb21:

    # Violet "Huh, that’s interesting. Caroline and Dwayne both told me I looked like a whore when I wore it."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:126
translate chinese Vi_S2_9c73c9dc:

    # MC "Well, that’s completely untrue. You look incredibly sexy, but you’re not a whore, Violet."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:128
translate chinese Vi_S2_93210f25:

    # Violet "How about now?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:129
translate chinese Vi_S2_359d54e5:

    # MC "W-Wow! *Cough* *Splutter*"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:130
translate chinese Vi_S2_f70d2889:

    # Violet "What’s wrong, [player_name]? Did your coffee go down the wrong way? Hehe!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:132
translate chinese Vi_S2_43efa5ba:

    # MC "*Cough* You just took me by surprise! That’s all. Haha!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:133
translate chinese Vi_S2_f6a5f23f:

    # Violet "Tell me, [player_name], are you enjoying the view?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:134
translate chinese Vi_S2_480c42b2:

    # MC "(God, her pussy looks amazing. She’s even shaved it!)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:136
translate chinese Vi_S2_d3a354fd:

    # MC "Yeah! You look really hot, right now."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:137
translate chinese Vi_S2_b4a00a44:

    # MC "Is it a big occasion? Or do you always just dress this way?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:138
translate chinese Vi_S2_c4ae709c:

    # Violet "I like slutty dresses - but the lack of panties is an extra special touch just for you. Hehe!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:139
translate chinese Vi_S2_b83ee451:

    # MC "Well, I hope you know I REALLY appreciate it."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:141
translate chinese Vi_S2_96b85f90:

    # Violet "Oh, I almost forgot to mention. The reason I brought you over today was to repay you for that thousand dollars you gave me."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:142
translate chinese Vi_S2_919097ba:

    # MC "I already told you not to worry about it."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:143
translate chinese Vi_S2_c27949dc:

    # Violet "I don’t have cash on me, but I HAVE been training as a masseuse. If you give me a few minutes to get changed, I would LOVE to show you what I’ve learned."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:144
translate chinese Vi_S2_ac4d5aa3:

    # MC "Sure! Sounds good to me!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:146
translate chinese Vi_S2_f0c5ecea:

    # Violet "And who knows... you might even get a happy ending out of it."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:147
translate chinese Vi_S2_914442f1:

    # Violet "Wait in here for five minutes and finish off your coffee. I’ll get everything set up in the other room."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:148
translate chinese Vi_S2_d83e41e4:

    # MC "Cool! Looking forward to it!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:151
translate chinese Vi_S2_7874cdc3:

    # Violet "Okay, [player_name], that’s me ready! You can come in now!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:164
translate chinese Vi_S2_451793fe:

    # MC "(Violet should have some time in the afternoon.)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:178
translate chinese Vi_S2_step2_6678ff82:

    # Violet "Ta-da! What do you think?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:179
translate chinese Vi_S2_step2_0d3e65e5:

    # MC "It’s... a VERY daring outfit for a masseuse! I’m not complaining, you look absolutely phenomenal in it!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:181
translate chinese Vi_S2_step2_5132ef52:

    # Violet "Hehe, thank you, [player_name]. Take off your clothes and lie down on the table for me."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:182
translate chinese Vi_S2_step2_e8b0bb45:

    # MC "The decor is very different here. I mean, I wasn’t expecting it to look this nice in here given the state of the neighbourhood outside."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:183
translate chinese Vi_S2_step2_b544cbeb:

    # MC "Sorry, I just realised that probably sounded quite rude."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:184
translate chinese Vi_S2_step2_0e249d11:

    # Violet "No, not at all. I squirreled away a bit of cash from Dwayne and slowly upgraded this over the past couple of years. I grabbed most of this fancy furniture from second-hand stores and charity shops."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:185
translate chinese Vi_S2_step2_d3c8100f:

    # Violet "It still doesn’t stop Dwayne from stealing stuff out of here that he thinks he can sell."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:187
translate chinese Vi_S2_step2_376dd397:

    # MC "Ah... You’re good at that!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:188
translate chinese Vi_S2_step2_8d5d1f0d:

    # Violet "Most of my customers are locals, so my goal was to create a little paradise for them to enjoy during their massage."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:189
translate chinese Vi_S2_step2_7f021416:

    # Violet "None of them could afford a massage at one of those up-market salons, but when they visit me here, they can fantasise that they’re escaping the slums... even if just for a little while."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:190
translate chinese Vi_S2_step2_ff8eb5c9:

    # MC "That’s quite an admirable thing to do, Violet."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:192
translate chinese Vi_S2_step2_14a8285d:

    # Violet "Thank you, [player_name]. I’m still working towards my next qualification, but once I have that I should be able to formally open up a proper business, instead of working cash-in-hand like this."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:193
translate chinese Vi_S2_step2_0d686f22:

    # MC "Plus, you could move out and get away from Dwayne."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:194
translate chinese Vi_S2_step2_79146351:

    # Violet "..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:195
translate chinese Vi_S2_step2_fbfa73af:

    # Violet "I don’t know..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:196
translate chinese Vi_S2_step2_bcb71f9a:

    # MC "You shouldn’t be letting him treat you like this. He’s an abusive asswipe. I mean, he beats you up, he leeches off of you for your money."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:197
translate chinese Vi_S2_step2_1f1c44ee:

    # MC "You deserve so much better than that, Violet."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:199
translate chinese Vi_S2_step2_072251bd:

    # MC "Ooh... That’s the spot! Mmm!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:200
translate chinese Vi_S2_step2_38a6193c:

    # Violet "Dwayne can be an asshole, but don’t forget, I robbed my own best friend when she needed me most. I’m a piece of shit too."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:201
translate chinese Vi_S2_step2_70d87680:

    # MC "I don’t think you’re a piece of shit. You’ve been great to me for as long as I’ve known you."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:203
translate chinese Vi_S2_step2_22da2c45:

    # Violet "That’s very sweet of you to say that."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:204
translate chinese Vi_S2_step2_fb1e415a:

    # MC "Not to mention, the first time we met you let me fuck your throat! Haha!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:205
translate chinese Vi_S2_step2_7ad6d35c:

    # Violet "Oh yeah, that favour to Caroline. I’d almost forgotten about that."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:207
translate chinese Vi_S2_step2_ba56a226:

    # Violet "How’s the pressure? Am I being too hard right now?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:208
translate chinese Vi_S2_step2_9bf09e42:

    # MC "Mmm! No, it’s perfect. You’re REALLY good at this!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:210
translate chinese Vi_S2_step2_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:211
translate chinese Vi_S2_step2_9464062c:

    # MC "Are you getting many customers, at the minute?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:212
translate chinese Vi_S2_step2_c1ef2712:

    # Violet "Only three or four per week. I have to schedule them in for sessions when Dwayne isn’t around, which means the early afternoon."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:214
translate chinese Vi_S2_step2_4130db25:

    # Violet "Given that most people don’t get out of work until the evening, it kinda limits my reach right now."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:215
translate chinese Vi_S2_step2_919333c2:

    # MC "Is Dwayne scaring off your customers?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:216
translate chinese Vi_S2_step2_50d2b5e4:

    # Violet "The asshole threatens anybody who comes by the house. If they’re carrying cash to pay me for a massage, he’ll just view it as extra money that he can take for himself."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:218
translate chinese Vi_S2_step2_e54a73e2:

    # MC "Ugh... What a dickhead."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:219
translate chinese Vi_S2_step2_bcee1fc4:

    # Violet "*Sigh* I know. Once I get qualified, I think I’ll look into setting up a shop somewhere. Maybe that new mall they’re building. I hear they’re setting aside half the retail properties for local businesses."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:220
translate chinese Vi_S2_step2_f283d903:

    # Violet "I’d get a lot of foot traffic - and wouldn’t have to worry about Dwayne scaring customers off."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:222
translate chinese Vi_S2_step2_cd6eb56d:

    # MC "I think that sounds like a great idea."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:223
translate chinese Vi_S2_step2_2d33cea2:

    # Violet "Yeah, I’m cautiously optimistic about it!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:224
translate chinese Vi_S2_step2_59714588:

    # Violet "Alright, just keep lying there. I’m just going to move on to your calves now."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:226
translate chinese Vi_S2_step2_bc133893:

    # MC "Oooh, God... Your fingers are amazing."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:227
translate chinese Vi_S2_step2_cdf077a2:

    # Violet "Hehe, that feels good?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:228
translate chinese Vi_S2_step2_705e2604:

    # MC "Yeah, it really does!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:230
translate chinese Vi_S2_step2_a301c7e8:

    # Violet "You’ve got a lot of knots in your calves. I’m going to work them out, now. If it starts to hurt, just let me know."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:231
translate chinese Vi_S2_step2_a2359a1a:

    # MC "Uh huh, no problem"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:232
translate chinese Vi_S2_step2_eb585b72:

    # MC "Ohhhh... Mmm..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:233
translate chinese Vi_S2_step2_30931c74:

    # Violet "Alright, that should do it. Do you want to roll over for me?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:235
translate chinese Vi_S2_step2_1e26a869:

    # Violet "Perfect. We’ll just finish off with your feet, here, and, then we’ll..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:236
translate chinese Vi_S2_step2_b009a307:

    # MC "(I guess there’s no point in trying to hide my erection. I honestly don’t think Violet would mind anyway.)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:238
translate chinese Vi_S2_step2_54d1b1cc:

    # Violet "Oh my, what do we have here? It looks like SOMEONE is enjoying this massage a bit too much."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:239
translate chinese Vi_S2_step2_f96ee08e:

    # MC "It’s hard not to enjoy it, when the masseuse is dressed like that."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:240
translate chinese Vi_S2_step2_b0271737:

    # Violet "Well, I hope you enjoy what’s about to happen next."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:242
translate chinese Vi_S2_step2_c543150c:

    # MC "Oh yeah? What’s going to happen next?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:243
translate chinese Vi_S2_step2_87a2c90d:

    # Violet "Well, the next part is usually reserved for customers who pay for the premium package..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:244
translate chinese Vi_S2_step2_255abd2b:

    # MC "Am I on the premium package?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:246
translate chinese Vi_S2_step2_001bca7c:

    # Violet "I’m afraid not... but I think I can make an exception, in your case."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:247
translate chinese Vi_S2_step2_c4f25d49:

    # MC "So, what’s included in the premium package?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:248
translate chinese Vi_S2_step2_ba33eab5:

    # Violet "Well..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:250
translate chinese Vi_S2_step2_f03e392d:

    # Violet "...that depends entirely on how frequent of a customer you are. A first-timer, such as yourself, would enjoy my hand stroking their shaft until they finish."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:251
translate chinese Vi_S2_step2_39a06b96:

    # MC "Mmm... That sounds good to me!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:252
translate chinese Vi_S2_step2_df0973aa:

    # Violet "However..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:254
translate chinese Vi_S2_step2_ffe16d07:

    # MC "Oh... H-However?"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:255
translate chinese Vi_S2_step2_d72e2362:

    # Violet "Given the significant financial contribution you made the other day, I think I’m going to bump you up a tier."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:256
translate chinese Vi_S2_step2_93b0e607:

    # MC "Ohh, tell me more."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:258
translate chinese Vi_S2_step2_eb5d48fd:

    # Violet "Would you like me to wrap my breasts around your cock and massage it until you cum?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:259
translate chinese Vi_S2_step2_9779d55e:

    # MC "God, I’d love that."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:261
translate chinese Vi_S2_step2_539d69bb:

    # Violet "I thought you would. I still remember the first time I met you. Do you remember what you asked me?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:262
translate chinese Vi_S2_step2_914cad8f:

    # MC "I remember asking Caroline if you were a prostitute... Heh... You looked like you were about to kick me in the nuts!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:263
translate chinese Vi_S2_step2_47fd1571:

    # Violet "Haha! I remember that. It wasn’t what I was referring to though. You asked to fuck my tits, and that was the first thing we did."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:265
translate chinese Vi_S2_step2_4cf0ba4a:

    # Violet "I bet you’ve been wanting to do this again for a LONG time, [player_name]."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:266
translate chinese Vi_S2_step2_fb32e779_1:

    # MC "Ohh..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:267
translate chinese Vi_S2_step2_ce8c3bd9:

    # Violet "That’s it, moan for me. Let it all out and relax."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:269
translate chinese Vi_S2_step2_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:270
translate chinese Vi_S2_step2_9d8a50ae:

    # Violet "I imagine your dick feels sooo good between my breasts right now, doesn’t it?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:271
translate chinese Vi_S2_step2_c5f156ec:

    # MC "Uh huh! Ohh..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:273
translate chinese Vi_S2_step2_81c32556:

    # Violet "I love watching a man’s face while I do this. There’s something so erotic about his expression as he gets closer and closer to his climax."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:274
translate chinese Vi_S2_step2_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:275
translate chinese Vi_S2_step2_d37964f7:

    # Violet "The groaning of his voice, the wrinkling of his brow, the quicker panting of his breath."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:277
translate chinese Vi_S2_step2_ec3ee892:

    # Violet "I love the anticipation of it. The feeling of not knowing how many more thrusts of his shaft there will be, between my breasts, before he finishes."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:279
translate chinese Vi_S2_step2_fb32e779_2:

    # MC "Ohh..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:280
translate chinese Vi_S2_step2_865b0b0e:

    # Violet "Maybe this time?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:282
translate chinese Vi_S2_step2_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:283
translate chinese Vi_S2_step2_d2d332e6:

    # Violet "Maybe not. Hehe!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:284
translate chinese Vi_S2_step2_01a0afc7:

    # Violet "This is why I became a masseuse. I have complete power and control over the pleasure someone else experiences."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:286
translate chinese Vi_S2_step2_bdb60eab:

    # MC "*Pant* Ohh... Mmm!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:288
translate chinese Vi_S2_step2_be208711:

    # Violet "*Whispered* And it’s an amazing feeling to have. Knowing that you have someone completely at your mercy, for a relief that only YOU can give them."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:289
translate chinese Vi_S2_step2_d4926199_1:

    # MC "*Pant*"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:291
translate chinese Vi_S2_step2_4f7df8e5:

    # Violet "I could stop whenever I wanted to..."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:293
translate chinese Vi_S2_step2_addaf92d:

    # Violet "...but that would be cruel."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:295
translate chinese Vi_S2_step2_08124a90:

    # Violet "Would you like to squeeze my ass while I massage your cock?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:296
translate chinese Vi_S2_step2_8e151b0b:

    # MC "Mmm, absolutely!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:298
translate chinese Vi_S2_step2_313fc97e:

    # MC "(God, her butt feels amazing!)"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:299
translate chinese Vi_S2_step2_27ee63d0:

    # Violet "Mmm, I thought you’d enjoy that. Go on, grab my ass as hard as you want. Really dig your fingers in if you want to. I enjoy it."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:301
translate chinese Vi_S2_step2_c4f3e9b1:

    # Violet "Ohh! Hehe! You’ve got a firm grip!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:302
translate chinese Vi_S2_step2_70eac9f9:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:303
translate chinese Vi_S2_step2_c432ec37:

    # Violet "Are you about to cum for me? Do it. Cum all over my tits."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:305
translate chinese Vi_S2_step2_f3897f9e:

    # MC "*Pant* I’m getting close."
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:306
translate chinese Vi_S2_step2_f85e524f:

    # Violet "You want me to speed up?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:307
translate chinese Vi_S2_step2_1b728617:

    # MC "*Gasp* Ohh... Y-Yeah!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:309
translate chinese Vi_S2_step2_77b1981a:

    # MC "Ohh! Fuck! Mmm! Yes!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:310
translate chinese Vi_S2_step2_2214f99f:

    # Violet "That’s it. Cum for me, [player_name]. Cum all over my tits!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:312
translate chinese Vi_S2_step2_a69c88ca:

    # MC "Uggghh! Ohhh! Hnnnggg!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:313
translate chinese Vi_S2_step2_ed998c41:

    # Violet "Come on! Finish for me. That’s a good boy. Shoot your hot load all over my bit fat titties! I want to feel your c-"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:323
translate chinese Vi_S2_step2_4ea62f90:

    # MC "Arrghhh! OHHHH!! Fuck!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:324
translate chinese Vi_S2_step2_bbef55e1:

    # Violet "Whoa!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:325
translate chinese Vi_S2_step2_c3d2b485:

    # MC "Hnnngg! Ugh! I’m cummming!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:327
translate chinese Vi_S2_step2_be93b5fa:

    # Violet "Hehe! I’d forgotten how big your loads were!"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:328
translate chinese Vi_S2_step2_9c85dbbc:

    # MC "*Pant* S-Sorry, haha!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:329
translate chinese Vi_S2_step2_a7719ffc:

    # Violet "Ah, don’t worry. The dress needed to go in the wash anyway."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:331
translate chinese Vi_S2_step2_0a6ea4fc:

    # Violet "Well? What did you think? Am I on track to running a successful massage parlour?"
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:332
translate chinese Vi_S2_step2_5177c7f2:

    # MC "*Pant* Definitely. That was fucking amazing, Violet. Give me a shout when you open up shop. I’ll be visiting you every week!"
    MC ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:333
translate chinese Vi_S2_step2_ce4b4fba:

    # Violet "Haha! You’re far too kind."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:335
translate chinese Vi_S2_step2_0e9dd412:

    # Violet "I’ll tell you what. I still need to get some more practice in - so anytime you want a massage, just swing by."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:336
translate chinese Vi_S2_step2_79463e66:

    # Violet "Um, afternoon is usually best. Dwayne tends to get up in my shit in the mornings, and he’s a drunken asshole in the evening."
    Violet ""

# game/scripts/Vi_scenes/2_Vi_S2.rpy:337
translate chinese Vi_S2_step2_74bacf65:

    # MC "No problem, got it! Catch you later, Violet - and thanks again!"
    MC ""

