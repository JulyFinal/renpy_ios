﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/5_Vi_S4.rpy:36
translate chinese Vi_S4_a80dad4b:

    # MC "(I should check in on Violet to see how she’s doing.)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:37
translate chinese Vi_S4_d5f1c2d1:

    # MC "(She mentioned that Dwayne isn’t here in the afternoons, so it should be safe enough for me to stop by for a couple of minutes.)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:41
translate chinese Vi_S4_20c73366:

    # "*Slap*"
    ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:44
translate chinese Vi_S4_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:46
translate chinese Vi_S4_8e7a000d:

    # Dwayne "Where the fuck is my money, pal?!"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:47
translate chinese Vi_S4_f6fc1598:

    # MC "(That guy hits like a freight train!)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:49
translate chinese Vi_S4_2fd53d65:

    # MC "Ow... Ugh..."
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:50
translate chinese Vi_S4_3b896df3:

    # Dwayne "Hey! Fucking answer me, dipshit! Where’s the ten grand?"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:51
translate chinese Vi_S4_a54bc1c9:

    # MC "(God, my vision’s blurred since he struck me!)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:53
translate chinese Vi_S4_a922c671:

    # MC "*Cough* Ahh..."
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:54
translate chinese Vi_S4_6cba89d5:

    # Dwayne "What?! Are you some kinda pussy who can’t take a hit like a man?"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:55
translate chinese Vi_S4_c28d3611:

    # MC "(Fucking hell, I’m going to have to face him, aren’t I?)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:57
translate chinese Vi_S4_69fe876f:

    # MC "You didn’t have to jump me from behind. You could have just walked up and ASKED me y’know! Like a NORMAL human being!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:59
translate chinese Vi_S4_c91a5ead:

    # Dwayne "You sayin’ I ain’t normal?!"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:60
translate chinese Vi_S4_185c250e:

    # MC "(Ah, shit. I’ve just made things worse, haven’t I?)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:61
translate chinese Vi_S4_5c932279:

    # MC "I, uh- N-No! Y-You’re v-very av-average!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:63
translate chinese Vi_S4_fac28009:

    # Dwayne "I’m... average?!"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:64
translate chinese Vi_S4_87cfe19f:

    # MC "(Goddammit.)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:65
translate chinese Vi_S4_bd86218f:

    # Dwayne "Do you have my fucking money or not?!"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:67
translate chinese Vi_S4_c58e04a6:

    # MC "I... I don’t have it yet! I’m ALMOST there though! I just- I just need twenty four more hours to get it together!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:68
translate chinese Vi_S4_99443600:

    # Dwayne "You better not be fucking lyin’ to me right now."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:69
translate chinese Vi_S4_2ade751e:

    # MC "I’m not, I swear! I just need a little longer to get the ten thousand. I swear!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:71
translate chinese Vi_S4_7179c4ea:

    # MC "(I thought the Dean said he was going to sort out Dwayne! He hasn’t done ANYTHING so far!)"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:72
translate chinese Vi_S4_65532c37:

    # Dwayne "Fine. But you’re gonna owe me three grand interest on the late payment."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:73
translate chinese Vi_S4_c524b636:

    # MC "Wh-What? Interest? I can’t afford interest as well!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:75
translate chinese Vi_S4_2bad0095:

    # Dwayne "Shoulda thought about that before you insisted on dating my sister."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:76
translate chinese Vi_S4_8fd936bd:

    # MC "We’re not dating, we’re just- *Sigh* I don’t have another three grand!"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:80
translate chinese Vi_S4_67ee7f31:

    # Dwayne "Alright, change of plans. Bring me the ten grand tomorrow, and I’ll write off your interest if you help me out with a job."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:81
translate chinese Vi_S4_e0334670:

    # MC "What- What kinda job?"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:82
translate chinese Vi_S4_731ae74b:

    # Dwayne "I’ve been staking out an apartment in this area. Owner is out for the afternoon."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:84
translate chinese Vi_S4_cd9ac560:

    # Dwayne "YOU are gonna be the lookout. If you see anyone coming, then your role is to whistle to alert me."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:85
translate chinese Vi_S4_0539beeb:

    # Dwayne "If it looks like they're going to come into the apartment, then I need you to distract them while I sneak out of the apartment through the back window. Keep 'em busy. You're a fast talker. Let's see you put these skills to good use."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:86
translate chinese Vi_S4_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:88
translate chinese Vi_S4_193f97ab:

    # Dwayne "And before you think of calling the cops or anything, just remember that there are only two people who know this is about to go down. You and me."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:89
translate chinese Vi_S4_9c82a79d:

    # Dwayne "If I hear a siren, I’m gonna bail, and I’m gonna hunt you down like the rat you are. Got it?"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:90
translate chinese Vi_S4_9c0bc39e:

    # MC "*Gulp* G-Got it."
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:99
translate chinese Vi_S4_2fd7fe38:

    # MC "An interesting afternoon awaits me."
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:101
translate chinese Vi_S4_888fc636:

    # MC "I hope no one catches that ram."
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:103
translate chinese Vi_S4_48e38992:

    # Dwayne "Fuck! There's so much slack here?"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:104
translate chinese Vi_S4_4fb82fd9:

    # Dwayne "It was more tense last time. This should be easy."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:106
translate chinese Vi_S4_3ef0853c:

    # Dwayne "Come on! Come on!"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:107
translate chinese Vi_S4_9e9339f7:

    # Dwayne "A little more...."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:109
translate chinese Vi_S4_84fb62ed:

    # Dwayne "I opened it! Give me two minutes and start watching."
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:110
translate chinese Vi_S4_2a687d1a:

    # Dwayne "You know what to do!"
    Dwayne ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:112
translate chinese Vi_S4_2cb1b21a:

    # MC "Yea! Yea... Yea... Let's get this over with."
    MC ""

# game/scripts/Vi_scenes/5_Vi_S4.rpy:113
translate chinese Vi_S4_aa0c0103:

    # MC "No one is there for now but let's not lose our vigilance."
    MC ""

