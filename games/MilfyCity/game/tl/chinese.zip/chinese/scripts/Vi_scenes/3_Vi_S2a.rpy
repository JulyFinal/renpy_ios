﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:39
translate chinese Vi_S2a_08b3ba65:

    # MC "(I've already been there today.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:49
translate chinese Vi_S2a_6fea57cc:

    # MC "(Violet is usually free in the afternoon.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:51
translate chinese Vi_S2a_d9cdabad:

    # MC "(I need someone who can help me deal with Dwayne. Perhaps the Dean can come up with something? I should visit him at the college.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:70
translate chinese Vi_S2a_6a34babb:

    # MC "*Knock* *Knock*"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:71
translate chinese Vi_S2a_a20cefa7:

    # "..."
    ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:72
translate chinese Vi_S2a_3b551f8f:

    # MC "(I should probably come back to check up on her another time.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:78
translate chinese Vi_S2a_6e8e9a05:

    # MC "(The Milfy City Council voted to replace most trash cans with recycling bins last year... It still doesn’t make this part of town any better. I still feel like I’m gonna get stabbed while walking down the street.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:80
translate chinese Vi_S2a_66e8623d:

    # MC "(What hope did Violet ever have of turning her life around while living in a shithole like this?)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:82
translate chinese Vi_S2a_6a34babb_1:

    # MC "*Knock* *Knock*"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:86
translate chinese Vi_S2a_0ed1f395:

    # Dwayne "You’re not the usual guy."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:87
translate chinese Vi_S2a_739437ee:

    # MC "P-Pardon?"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:88
translate chinese Vi_S2a_9669ddc1:

    # Dwayne "Where’s Markus?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:89
translate chinese Vi_S2a_56bb8c5f:

    # MC "Markus?"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:90
translate chinese Vi_S2a_dd5011ee:

    # Dwayne "You got my shit or not?!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:91
translate chinese Vi_S2a_a9a69c2b:

    # MC "I’m not a dealer, I’m just here to see Violet!"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:93
translate chinese Vi_S2a_db7ec6b1:

    # Dwayne "Violet? What do you want to see that piece of shit for? Ugh, nevermind. If you ain’t my dealer, then you ain’t got no reason to be round here."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:94
translate chinese Vi_S2a_197d4544:

    # MC "But I-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:95
translate chinese Vi_S2a_cdf7c558:

    # Dwayne "Fuck off mate, or I'll break your nose!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:97
translate chinese Vi_S2a_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:98
translate chinese Vi_S2a_6c523369:

    # MC "(Yeah, I can see what Violet must be putting up with on a daily basis. I think I better get out of here - Dwayne seems like the kind of guy who follows through on his threats."
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:109
translate chinese Vi_S2a_6a34babb_2:

    # MC "*Knock* *Knock*"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:110
translate chinese Vi_S2a_a20cefa7_1:

    # "..."
    ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:111
translate chinese Vi_S2a_3b551f8f_1:

    # MC "(I should probably come back to check up on her another time.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:117
translate chinese Vi_S2a_f723c7f9:

    # MC "(Alright, let’s swing by and check on Violet. I’m worried about her having to live in a place like this with an abusive psychopath like Dwayne.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:119
translate chinese Vi_S2a_bd831898:

    # MC "(Caroline and Violet both have really bad luck when it comes to the men in their lives...)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:121
translate chinese Vi_S2a_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:125
translate chinese Vi_S2a_13084d49:

    # Violet "[player_name]?!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:126
translate chinese Vi_S2a_00df2f4e:

    # MC "Hey Violet, I just wanted to stop by to see how you’re-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:129
translate chinese Vi_S2a_7b681d93:

    # Dwayne "Who the fuck is it?!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:130
translate chinese Vi_S2a_9f2de814:

    # Violet "J-Just a door-to-door salesman, Dwayne!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:131
translate chinese Vi_S2a_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:134
translate chinese Vi_S2a_199093c2:

    # Dwayne "Well, tell him to fuck off! And where’s that beer I asked for? Hurry up, you piece of shit!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:135
translate chinese Vi_S2a_960372a1:

    # Violet "*Sigh*"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:136
translate chinese Vi_S2a_708f046b:

    # MC "*Whispered* Are you alright, Violet? You can leave with me now-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:138
translate chinese Vi_S2a_b3c8b841:

    # Violet "*Whispered* I can handle this. Don’t worry about me."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:139
translate chinese Vi_S2a_d7b35604:

    # Violet "N-No, we don’t want any of this garbage you’re selling! Go away!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:140
translate chinese Vi_S2a_c8f7f04b:

    # Dwayne "I already told you I’m thirsty, bitch! God damn, you’re as worthless as your mother was!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:142
translate chinese Vi_S2a_a027d6e9:

    # Violet "*Sniff* I- I- I’m coming!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:145
translate chinese Vi_S2a_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:146
translate chinese Vi_S2a_2fa95e11:

    # MC "(She shut the door... I should probably come back to check up on her another time.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:154
translate chinese Vi_S2a_b465e562:

    # MC "(It’s scary walking around this part of Milfy City late at night. I feel like I’m gonna get mugged any second...)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:155
translate chinese Vi_S2a_91b91e5f:

    # MC "(Dwayne will hopefully be asleep when I call at the door. This might give me a chance to talk to Violet alone to make sure she’s okay.)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:158
translate chinese Vi_S2a_bca3ac64_1:

    # "*Knock* *Knock*"
    ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:159
translate chinese Vi_S2a_b3d7f487:

    # MC "(I can hear footsteps approaching. Please be Violet... Please be Violet...)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:163
translate chinese Vi_S2a_8f447366:

    # Violet "*Whispered* [player_name]? What are you doing here? It’s the middle of the night?"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:164
translate chinese Vi_S2a_280c3858:

    # MC "I had to-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:165
translate chinese Vi_S2a_ddc0e2ef:

    # Violet "*Shush* Keep your voice down, Dwayne’s passed out drunk on the couch."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:166
translate chinese Vi_S2a_59604d1d:

    # MC "*Whispered* Sorry, I wanted to check on you to make sure you were alright."
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:167
translate chinese Vi_S2a_db798284:

    # Violet "*Whispered* C’mon in. No sense in you standing outside in the cold."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:169
translate chinese Vi_S2a_cd35cf5c:

    # MC "*Whispered* Thanks Violet. How are you? Is everything okay? You said Dwayne had passed out drunk? He didn’t threaten you again, did he?"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:170
translate chinese Vi_S2a_bd3b0031:

    # Violet "*Whispered* I’m fine. It’s good when he passes out. It means I get to have a few hours without being beaten or yelled at."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:171
translate chinese Vi_S2a_bd776928:

    # MC "*Whispered* You don’t have to live like this, Violet. You can come back with me. I’ll find you somewhere else to-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:173
translate chinese Vi_S2a_f6d19d27:

    # Violet "*Whispered* That’s very sweet of you, [player_name]. It’s not that simple though. This is my family home, I grew up here."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:174
translate chinese Vi_S2a_94e9b973:

    # Violet "*Whispered* My presence here is the only thing that is stopping this place descending into a crackhouse."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:175
translate chinese Vi_S2a_93242815:

    # MC "*Sigh* I’m sorry, Vi-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:179
translate chinese Vi_S2a_d19fb37e:

    # MC "Ah! Jesus Christ!"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:180
translate chinese Vi_S2a_635571e7:

    # Dwayne "Well, well, *hic* well... Who do we have here?!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:181
translate chinese Vi_S2a_96bc40c4:

    # Violet "D-Dwayne! I thought you were-"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:183
translate chinese Vi_S2a_7824c737:

    # Dwayne "This your new *hic* boyfriend, Sis?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:184
translate chinese Vi_S2a_8fe8c4f4:

    # Violet "No, I-"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:185
translate chinese Vi_S2a_04b5a18e:

    # Dwayne "Y’aint brought a guy home in a while, Sis. This one special *Hic* to ya or somethin’?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:186
translate chinese Vi_S2a_0dd7212f:

    # Violet "Dwayne, please, just go back to bed. He was leaving. He was about to leave!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:188
translate chinese Vi_S2a_5996c74b:

    # Violet "Dwayne! NO! Please!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:189
translate chinese Vi_S2a_c0479f83:

    # Dwayne "Will you shut the *Hic* fuck up with your cryin’, you piece of shit?!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:190
translate chinese Vi_S2a_af852021:

    # Violet "Please! Don’t hurt him! Dwayne! Plea-"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:191
translate chinese Vi_S2a_40ba4acc:

    # Dwayne "If you don’t shut up, I’m gonna break his fucking nose!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:192
translate chinese Vi_S2a_165d63a0:

    # Violet "I..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:193
translate chinese Vi_S2a_56bfd415:

    # Dwayne "Better."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:195
translate chinese Vi_S2a_5d430abb:

    # Dwayne "Not many guys make it *Hic* this far with Violet. All the dirty shit in her closet usually *Hic* drives ‘em away."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:196
translate chinese Vi_S2a_a8c59857:

    # MC "I... Y-You can put your fist down, I’m not-"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:197
translate chinese Vi_S2a_47ef6f8b:

    # Dwayne "Heh... She ain’t told you, has she?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:199
translate chinese Vi_S2a_c648e233:

    # Violet "Dwayne, no... Please... Please don’t do this."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:200
translate chinese Vi_S2a_4e80b41f:

    # Dwayne "Did she ever tell you about what she did to our mother?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:201
translate chinese Vi_S2a_5e79b0eb:

    # Violet "Dwayne! Please!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:202
translate chinese Vi_S2a_fe119055:

    # Dwayne "Caught by *Hic* the cops smuggling drugs when she was only thirteen."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:204
translate chinese Vi_S2a_4eba2bee:

    # Violet "Please... No!"
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:205
translate chinese Vi_S2a_e42e3575:

    # Dwayne "How do you think our mom felt when she opened the front door and *hic* found her favourite child was no better than the one she’d given up on? Huh?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:206
translate chinese Vi_S2a_79146351:

    # Violet "..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:207
translate chinese Vi_S2a_7117bcf5:

    # Dwayne "That’s right - this girl you’re dating. This piece of shit standing behind me. She caused her *Hic* own mother to have a fucking nervous breakdown."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:209
translate chinese Vi_S2a_796f40ff:

    # Dwayne "Heh... Ahaha! I BET she never put THAT on her Tander profile! Am I right?"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:210
translate chinese Vi_S2a_79146351_1:

    # Violet "..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:211
translate chinese Vi_S2a_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:212
translate chinese Vi_S2a_00d50b31:

    # Dwayne "On you go. Get the fuck out of my house, and never show *Hic* yer fuckin’ face again. Just like every other guy she dated, when they saw her for the piece of shit she actually was."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:214
translate chinese Vi_S2a_e8d450db:

    # MC "I... I... I’m not leaving."
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:215
translate chinese Vi_S2a_ec4769a9:

    # Dwayne "Huh. In that case you’re gonna have to *Hic* pay me if yeh want to date her."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:216
translate chinese Vi_S2a_19570c32:

    # MC "What?"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:217
translate chinese Vi_S2a_74a95b1b:

    # Dwayne "$10,000. Cash. That’s what it *Hic* costs if you want to date this piece of shit. Now, hurry up and get the fuck out of my house."
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:219
translate chinese Vi_S2a_39232f0c:

    # Violet "*Whispered* I’m so sorry..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:220
translate chinese Vi_S2a_82060064:

    # MC "(Where am I going to get $10,000 at such short notice?!)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:225
translate chinese Vi_S2a_34b57b9b:

    # Violet "*Muffled* They were YOUR drugs! I didn’t even want to..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:226
translate chinese Vi_S2a_b3227328:

    # Dwayne "*Muffled* You were the dumb bitch... caught... cops!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:227
translate chinese Vi_S2a_da2149fd:

    # Violet "*Muffled* ...my fault..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:228
translate chinese Vi_S2a_b4ca393e:

    # Dwayne "*Muffled* ...course it’s your fault! You... the blame... other people! ...only reason... mom... psychiatric ward is YOU!"
    Dwayne ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:229
translate chinese Vi_S2a_b91177af:

    # Violet "*Muffled* *Sob* *Sob* I’m sorry...just... piece of shit... I’m sorry..."
    Violet ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:230
translate chinese Vi_S2a_7f069fc6:

    # MC "(Dwayne’s a fucking monster! I'm in way over my head here. I need someone who can help me deal with this dickhead once and for all. Someone powerful who isn’t afraid to get their hands dirty...)"
    MC ""

# game/scripts/Vi_scenes/3_Vi_S2a.rpy:231
translate chinese Vi_S2a_da1c4fc1:

    # MC "(Bob is WAY too nice. Linda isn’t strong enough. Caroline or Sara would just get beaten up. God dammit, [player_name], THINK! There has to be someone with the resources to handle this bastard!)"
    MC ""

