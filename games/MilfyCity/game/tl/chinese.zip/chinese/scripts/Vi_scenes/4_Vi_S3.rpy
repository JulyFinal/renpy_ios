﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/4_Vi_S3.rpy:14
translate chinese Dean_Talked_5477a073:

    # MC "(I've already talked with him.)"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:29
translate chinese Vi_S3_552b6cd8:

    # MC "I’m sorry to bother you, sir. Are you free to talk, I’ve got a-"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:30
translate chinese Vi_S3_f03e77a7:

    # Headmaster "Yo, yo! Of course, my man. Come in, close the door, enlighten me more."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:31
translate chinese Vi_S3_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:33
translate chinese Vi_S3_f478e149:

    # Headmaster "..."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:34
translate chinese Vi_S3_2f8997bf:

    # Headmaster "You ARE one of my students... right?"
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:36
translate chinese Vi_S3_da8fd5be:

    # MC "Y-Yeah, I am. [player_name], from Ms. Celia’s class? Don't you remember me?"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:38
translate chinese Vi_S3_a4c892e0:

    # Headmaster "Heh, good thing! If you weren’t one of my students I was afraid I was gonna have to kill ya!"
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:39
translate chinese Vi_S3_2c9a62fe:

    # MC "Wh-What?"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:40
translate chinese Vi_S3_df237584:

    # Headmaster "Ha! I’m just yankin’ your chain, man! Now, tell me, [player_name], what can I help you with?"
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:41
translate chinese Vi_S3_9ef5db7d:

    # Headmaster "(I can never be too careful with these rival gangs lurking about. I wouldn’t put it beneath some of them to pose as my own students to get to me.)"
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:43
translate chinese Vi_S3_9a54be70:

    # MC "I.. uh.... It’s not exactly related to the campus, but one of my friends is getting badly abused by her own brother."
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:44
translate chinese Vi_S3_45057fed:

    # Headmaster "Oof, that’s some Targaryean shit right there."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:45
translate chinese Vi_S3_544dd2ea:

    # MC "I didn’t really know who to turn to-"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:47
translate chinese Vi_S3_9c93a188:

    # Headmaster "And... you didn’t think to call the cops?"
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:48
translate chinese Vi_S3_941a12f7:

    # MC "Uh... No, I didn’t."
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:49
translate chinese Vi_S3_969d877a:

    # Headmaster "Mmm..."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:51
translate chinese Vi_S3_f7716da2:

    # Headmaster "That inaction was a smart move on your part. As long as the fuzz ain’t a part of this, I can be."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:52
translate chinese Vi_S3_765dd93c:

    # MC "Umm, what do you mean?"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:53
translate chinese Vi_S3_92eca82a:

    # Headmaster "I’ll always help any of my students if they need me. Heck, it’s one of the reasons why I chose this campus as dean in the first place."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:55
translate chinese Vi_S3_7913314c:

    # MC "(Chose the campus? What is he talking about?)"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:56
translate chinese Vi_S3_fefebe80:

    # Headmaster "Who’s your friend that needs a brother to bail her out?"
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:57
translate chinese Vi_S3_c1bb0356:

    # MC "Her name is Violet. She lives over in the slums, her brother is Dwayne-"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:59
translate chinese Vi_S3_73509d9b:

    # Headmaster "Dwayne? Well... it just so happens that a Dwayne from the slums was already due an appointment with myself. He just got himself bumped up on my schedule."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:61
translate chinese Vi_S3_38659f05:

    # MC "So, you’re going to help her?!"
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:62
translate chinese Vi_S3_3e710b3e:

    # Headmaster "Of course. I will ALWAYS help a student in need. Remember that, [player_name]."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:64
translate chinese Vi_S3_e4fd2a5b:

    # Headmaster "Oh, and one last thing, good on you for sticking up for this girl. You did the right thing."
    Headmaster ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:66
translate chinese Vi_S3_9775152e:

    # MC "Thanks, sir."
    MC ""

# game/scripts/Vi_scenes/4_Vi_S3.rpy:67
translate chinese Vi_S3_9a45ae02:

    # Headmaster "Don’t sweat it. Leave this to me to take care of. Catch you on the flip side."
    Headmaster ""

