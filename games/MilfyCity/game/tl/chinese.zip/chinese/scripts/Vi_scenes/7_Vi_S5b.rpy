﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:96
translate chinese Vi_S5b_957af62b:

    # MC "(Violet should be at her home in the evening.)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:110
translate chinese Vi_S5b_03f672bf:

    # Dwayne "I said let go of me, asshole!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:111
translate chinese Vi_S5b_fa730b6d:

    # MC "Huh? (What’s going on?)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:112
translate chinese Vi_S5b_63545069:

    # Dwayne "Tell me who you work for? Is it Big Mike? I already paid him his fucking money! I swear to fucking God, if you don’t let me go, I’ll break your fucking legs!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:114
translate chinese Vi_S5b_716c9e33:

    # Bodyguard2 "Uh huh, and how do you intend to do that, buddy? You can’t even get yourself out of an armlock."
    Bodyguard2 ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:115
translate chinese Vi_S5b_dbba5bc3:

    # Dwayne "Grr!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:116
translate chinese Vi_S5b_db85ceca:

    # MC "(What’s going on? Did the Dean organise this?)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:118
translate chinese Vi_S5b_fa6f9e3e:

    # Dwayne "YOU! This was all fucking YOU, wasn’t it?! You sent this thug to come get me, huh?!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:119
translate chinese Vi_S5b_6a86bf0e:

    # MC "Wh-What? I don’t know this guy, Dwayne, I swear!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:121
translate chinese Vi_S5b_d1cba36f:

    # Dwayne "Who’d you rat me out to? Huh?! Tell me! What’d you do? Find all the big-shot dealers I owe money to and tell ‘em my home address? Huh?!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:122
translate chinese Vi_S5b_67fc182d:

    # MC "I don’t know what’s going on, Dwayne! I don’t know any of your dealers!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:123
translate chinese Vi_S5b_b717f115:

    # Dwayne "As soon as I get outta this, I’m gonna break your fuckin’ legs. You and my piece of shit siste-"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:130
translate chinese Vi_S5b_0c4b6ba1:

    # "*Whack*"
    ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:131
translate chinese Vi_S5b_6222f6db:

    # Dwayne "Ooofff!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:132
translate chinese Vi_S5b_1b448e77:

    # Bodyguard2 "Alright, enough of THAT talk, big man. It’s time to go."
    Bodyguard2 ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:134
translate chinese Vi_S5b_1e981d59:

    # MC "Wh-Where are you taking him?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:135
translate chinese Vi_S5b_c0bd9250:

    # Bodyguard2 "A General my boss knows, over in Dilfy City was having trouble getting recruits. He made a deal with the local Governor to take in some scumbags, like this guy, and set ‘em straight."
    Bodyguard2 ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:136
translate chinese Vi_S5b_5cc6a5f3:

    # Dwayne "I ain’t bein’ a part of no fuckin’ military!"
    Dwayne ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:138
translate chinese Vi_S5b_aa761952:

    # Bodyguard2 "Don’t worry, kid. You won’t be seein’ this fucker again, any time soon."
    Bodyguard2 ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:140
translate chinese Vi_S5b_071ebd39:

    # Bodyguard2 "Don’t worry, pal. You won’t be seein’ this fucker again, any time soon."
    Bodyguard2 ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:141
translate chinese Vi_S5b_c0176aaa:

    # Bodyguard2 "Could you do me a favour? I caught this bastard, just as he was about to hit some woman with a hammer. Go and check on her for me."
    Bodyguard2 ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:142
translate chinese Vi_S5b_01944305:

    # MC "Y-Yeah, sure thing."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:144
translate chinese Vi_S5b_7deadf64:

    # MC "Violet! Are you alright? That guy in the suit said Dwayne came at you with a hammer?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:145
translate chinese Vi_S5b_1e8c9771:

    # Violet "Y-Yeah, it was terrifying. That strange man arrived, just in the nick of time! Another few seconds, and Dwayne would have... have... *Gulp* "
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:146
translate chinese Vi_S5b_19345012:

    # MC "Jesus Christ... Well, I can promise you it’s never going to happen again. They’re taking him away to Dilfy City for some military programme."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:148
translate chinese Vi_S5b_2f037497:

    # Violet "He’s... He’s actually gone?"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:149
translate chinese Vi_S5b_e5372a51:

    # MC "Yeah. For good, it seems."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:150
translate chinese Vi_S5b_65b93085:

    # Violet "Ha... Haha! I’m actually free!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:151
translate chinese Vi_S5b_1e591220:

    # MC "You certainly are, Violet."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:153
translate chinese Vi_S5b_04b21d75:

    # Violet "I think this calls for a celebration. Fancy a beer? I’ve got a great selection here."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:154
translate chinese Vi_S5b_d55ef1b4:

    # MC "It’s more fucking Bod Light, isn’t it?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:155
translate chinese Vi_S5b_dfcf53e9:

    # Violet "...surprisingly not! Picked up some Carlsbeer instead."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:158
translate chinese Vi_S5b_41c84adc:

    # MC "Ah, what the hell. I’ll take one. It’s not like Dwayne’s gonna be drinking them, anytime soon, right?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:159
translate chinese Vi_S5b_b3f4d43c:

    # Violet "Haha! That’s the spirit!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:161
translate chinese Vi_S5b_9ad42bb3:

    # MC "All joking aside, are you alright? Your brother is one terrifying dude."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:162
translate chinese Vi_S5b_b04ac186:

    # MC "I mean, I only had to endure him for a few days, and I was scared shitless!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:164
translate chinese Vi_S5b_9b7a722a:

    # Violet "I’ll be fine, now that he’s gone. It’s a huge relief that he’s not around anymore."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:166
translate chinese Vi_S5b_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:167
translate chinese Vi_S5b_a2f559eb:

    # Violet "Something on your mind?"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:168
translate chinese Vi_S5b_8ca8b6a1:

    # MC "I heard what he said to you about your mom, on the night he kicked me out. It wasn’t your fault. You know that, right? I overheard you two shouting at each other. He put you up to smuggling those drugs."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:169
translate chinese Vi_S5b_dc2e48f4:

    # MC "I know you think you’re a piece of shit for what happened. God knows I’ve heard you say it enough times. But, everything that happened to your mom is Dwayne’s fault. Not yours."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:170
translate chinese Vi_S5b_2bdf2b71:

    # MC "You’re not a piece of shit, Violet. You’re just someone who got trapped in a shitty situation they couldn’t escape from."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:172
translate chinese Vi_S5b_79146351:

    # Violet "..."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:173
translate chinese Vi_S5b_2a9eab2c:

    # Violet "Thanks, [player_name]. It means a lot to hear you say that. I think I’m going to try and visit her more often, now that he’s not around. Who knows? Maybe she’ll get better, and I’ll be able to bring her home?"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:174
translate chinese Vi_S5b_e74ca39c:

    # MC "I think she’d really like that, Violet."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:175
translate chinese Vi_S5b_76af5adc:

    # Violet "Thanks again, [player_name]. For everything. Now, how about we pound a few of these beers, before I end up crying or some stupid shit like that? Haha!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:185
translate chinese Vi_S5b_scene_a5b6d5f0:

    # Violet "So, that’s how I ended up stranded in Barcelona - no cash, no *hic* passport, and no ticket home! Haha!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:186
translate chinese Vi_S5b_scene_07849850:

    # MC "Ahaha! That’s mental!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:188
translate chinese Vi_S5b_scene_fcda56a8:

    # Violet "It’s actually been *Hic* really fun hanging out with you, [player_name]. I’m happy that Caroline introduced us."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:189
translate chinese Vi_S5b_scene_68a16fc2:

    # Violet "Even if she was basically just pimping me out like a prostitute at first."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:190
translate chinese Vi_S5b_scene_ea3feab2:

    # MC "Haha! You were the best prostitute I’ve ever had."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:191
translate chinese Vi_S5b_scene_ad5ab5fc:

    # Violet "Hehe, shut up!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:192
translate chinese Vi_S5b_scene_de9be7ff:

    # MC "Ahaha!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:193
translate chinese Vi_S5b_scene_7fc5fbc6:

    # Violet "Haha..."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:194
translate chinese Vi_S5b_scene_159486de:

    # MC "(I wonder if I should kiss her?)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:196
translate chinese Vi_S5b_scene_e8ffd01b:

    # MC "Haha..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:197
translate chinese Vi_S5b_scene_ccd1fa8b:

    # MC "(Nah, I shouldn’t... I mean, Violet just wants the sex without all the intimacy attached, right?)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:198
translate chinese Vi_S5b_scene_79146351:

    # Violet "..."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:199
translate chinese Vi_S5b_scene_4fc84c78:

    # MC "(Yeah, kissing her is a terrible idea.)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:200
translate chinese Vi_S5b_scene_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:201
translate chinese Vi_S5b_scene_b51f2f96:

    # Violet "So... Is this something gonna happen between us, or am I *hic* just reading the room wrong?"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:207
translate chinese Vi_S5b_scene_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:208
translate chinese Vi_S5b_scene_6d6a80bb:

    # Violet "Ooohhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:209
translate chinese Vi_S5b_scene_5824157e:

    # Violet "Yess.... Kiss my neck like that. Mmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:211
translate chinese Vi_S5b_scene_ccf45861:

    # Violet "Ah... Ohhhh! Mmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:212
translate chinese Vi_S5b_scene_bb1cc7aa:

    # Violet "Fuuuck... Keep sucking like that. Mmm! Squeeze my titties! Ah..."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:214
translate chinese Vi_S5b_scene_335a24e4:

    # Violet "*Pant* Ooh... Don’t stop, [player_name]. Mmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:215
translate chinese Vi_S5b_scene_98cd1c43:

    # MC "(Her tits are so soft and warm when I squeeze them!)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:216
translate chinese Vi_S5b_scene_f8bf7cff:

    # Violet "Mmm! Yes! Kiss me!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:218
translate chinese Vi_S5b_scene_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:219
translate chinese Vi_S5b_scene_a2af61d8:

    # Violet "Mmmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:220
translate chinese Vi_S5b_scene_79c50321:

    # MC "(I guess she was into the intimate side of things, after all! You learn something new every day!)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:222
translate chinese Vi_S5b_scene_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:223
translate chinese Vi_S5b_scene_81040b1e:

    # Violet "(I didn’t imagine, kissing someone who actually cares about you, could feel so different. I can’t think of the word to describe it. More meaningful? More passionate?)"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:224
translate chinese Vi_S5b_scene_aa3e54fc:

    # Violet "Mmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:226
translate chinese Vi_S5b_scene_02e3f904:

    # Violet "Let’s *hic* get undressed. I want you to fuck me."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:227
translate chinese Vi_S5b_scene_22e4e2fa:

    # MC "Are you sure, Violet? You’re a bit drunk and you’ve had a pretty traumatic attack from your brother. Maybe we should-"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:228
translate chinese Vi_S5b_scene_277f7f9a:

    # Violet "Please, I’ve wanted to fuck you, for a while now. Don’t kill the moment. I want this. Please, just fuck me."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:230
translate chinese Vi_S5b_scene_8e86ed38:

    # Violet "Ah... God... Mmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:231
translate chinese Vi_S5b_scene_1f60f9f0:

    # Violet "(I knew [player_name] had a big dick when I took it in my mouth, but it feels absolutely gigantic inside my pussy!)"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:232
translate chinese Vi_S5b_scene_0d9d4b8c:

    # MC "Hnnng! Ohh..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:234
translate chinese Vi_S5b_scene_52ad41f9:

    # Violet "*Pant* Ah..."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:236
translate chinese Vi_S5b_scene_8225c330:

    # MC "How is it? I’m not hurting you, am I?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:238
translate chinese Vi_S5b_scene_78f195c5:

    # Violet "No, it’s - much bigger than I expected it to feel, but it’s nice. Oooh... Can you *Hic* keep squeezing my butt like that?"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:240
translate chinese Vi_S5b_scene_08ac0a29:

    # MC "Sure, Violet."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:241
translate chinese Vi_S5b_scene_5272e738:

    # Violet "Oooh... Yessss... Aaahhhh..."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:242
translate chinese Vi_S5b_scene_22f82ccb:

    # Violet "God, your fat cock is REALLY filling me up. Mmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:244
translate chinese Vi_S5b_scene_cd801145:

    # Violet "Ah! That’s it! Lift my body up and down! Make me bounce on your cock."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:245
translate chinese Vi_S5b_scene_ba30a9e1:

    # Violet "Ohhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:246
translate chinese Vi_S5b_scene_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:248
translate chinese Vi_S5b_scene_70eac9f9:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:250
translate chinese Vi_S5b_scene_ddfa2365:

    # MC "(I can feel the warm walls of her pussy, wrapping tightly around my cock. This is fucking incredible!)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:252
translate chinese Vi_S5b_scene_211e4c8a:

    # Violet "Ah! Ahhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:254
translate chinese Vi_S5b_scene_91ca260b:

    # MC "(Let’s see if she enjoys me digging my fingers into her ass.)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:255
translate chinese Vi_S5b_scene_e78033e5:

    # Violet "Oooh! Yesss! Squeeze it harder!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:256
translate chinese Vi_S5b_scene_9bd593d1:

    # MC "*Pant* Ugh! Ohh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:258
translate chinese Vi_S5b_scene_af9a418b:

    # Violet "Mmm! I love it when you manhandle me like that. Ohh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:259
translate chinese Vi_S5b_scene_6dacb725:

    # Violet "I get so fucking wet when you lift my body up and down, MAKING me ride your cock. *Pant* Mmmm! God, you’re so good at this! Ahh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:261
translate chinese Vi_S5b_scene_f3f96861:

    # Violet "*Pant* Yes! Yes! I’m cumming! You’re making me cum! Ohhhhh!!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:262
translate chinese Vi_S5b_scene_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:264
translate chinese Vi_S5b_scene_95108443:

    # Violet "Ayaaahhh! Haaaahhhhhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:266
translate chinese Vi_S5b_scene_cb0176f3:

    # MC "Arrgh! Cum for me, Violet! I want to feel you trembling on my dick."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:268
translate chinese Vi_S5b_scene_df56a210:

    # Violet "*Pant* Ohhhh God! Ooohhhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:269
translate chinese Vi_S5b_scene_29b40162:

    # MC "Bend, over the coffee table. I’m going to fuck you doggy-style there."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:271
translate chinese Vi_S5b_scene_6b9ffaaa:

    # Violet "Ah! Ah! Ah!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:272
translate chinese Vi_S5b_scene_6ab31951_1:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:273
translate chinese Vi_S5b_scene_17e3ad50:

    # Violet "Yes! Fuck me! Fuck me harder!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:275
translate chinese Vi_S5b_scene_8551de15:

    # Violet "I want to feel your balls slapping *Hic* against my clit every time you ah... thrust! Mmmm! Oh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:277
translate chinese Vi_S5b_scene_6b9ffaaa_1:

    # Violet "Ah! Ah! Ah!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:279
translate chinese Vi_S5b_scene_3dba17a5:

    # MC "Argh! *Pant*"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:281
translate chinese Vi_S5b_scene_8045a6ce:

    # Violet "Yes! Yes! Ah! AHHHH!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:283
translate chinese Vi_S5b_scene_74fe29aa:

    # Violet "Ah! Harder! I want to feel you ah... go deeper!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:284
translate chinese Vi_S5b_scene_bbf59c8e:

    # MC "(How much harder can I possibly go?!)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:286
translate chinese Vi_S5b_scene_b0e56bde:

    # Violet "AYAAAHHHHH! YESSS! Ooohhhh! Right theerrreeeee!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:288
translate chinese Vi_S5b_scene_f58feeac:

    # Violet "(That’s the spot! God, this feels amazing!)"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:290
translate chinese Vi_S5b_scene_6ab31951_2:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:292
translate chinese Vi_S5b_scene_86301823:

    # Violet "*Pant* Ooohhh! "
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:293
translate chinese Vi_S5b_scene_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:295
translate chinese Vi_S5b_scene_9476d3b1:

    # Violet "Ah! Ah! Ah! Yes!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:296
translate chinese Vi_S5b_scene_21de0a3e:

    # Violet "Thrust your thick dick as deep as you caaaahhhhnn! Ooohhhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:298
translate chinese Vi_S5b_scene_ab072a08:

    # Violet "(This feels incredible! He’s fucking me so hard, my knees are starting to go weak!)"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:300
translate chinese Vi_S5b_scene_b100af24:

    # MC "*Pant* I want to hear you cum again for me."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:302
translate chinese Vi_S5b_scene_39b66ab2:

    # Violet "*Pant* I’m almost *Gasp* there!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:304
translate chinese Vi_S5b_scene_99ab5612:

    # Violet "Ohh! Mmm! Yes! Ayaaahhh! I’m going to-"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:305
translate chinese Vi_S5b_scene_7b1d55ef:

    # MC "Hnnnnng!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:306
translate chinese Vi_S5b_scene_4e9a3b79:

    # Violet "*GASP I’m cummmmmiinng!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:308
translate chinese Vi_S5b_scene_e68e3060:

    # Violet "AHHHHHHH!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:309
translate chinese Vi_S5b_scene_0d71b5fd:

    # MC "(I can feel the walls of her pussy, tightening around my dick, each time she cums!)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:310
translate chinese Vi_S5b_scene_66bc8ced:

    # Violet "Haaah! Ohhhh my Godddd! Yeessss!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:312
translate chinese Vi_S5b_scene_cd20ab4d:

    # Violet "Ah! Ahhh! AHHHHH!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:313
translate chinese Vi_S5b_scene_d3d447fd:

    # MC "*Pant* Ugh! *Pant* Oh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:314
translate chinese Vi_S5b_scene_bf193fbf:

    # MC "(Violet can really take a hard pounding! I’m starting to work up a sweat, here, and she barely seems fazed!)"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:316
translate chinese Vi_S5b_scene_7909b7f9:

    # MC "*Pant* How about we change positions? You stand up against the wall, and I’ll fuck you from behind?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:317
translate chinese Vi_S5b_scene_cf0d206a:

    # Violet "Ooooh... *Pant* Uh huh, sure!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:319
translate chinese Vi_S5b_scene_c4c672f4:

    # Violet "Ah! Mmm! Grope my tits while you fuck me! Oooh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:321
translate chinese Vi_S5b_scene_7b24f886:

    # MC "Ugh! Arghh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:323
translate chinese Vi_S5b_scene_cd20ab4d_1:

    # Violet "Ah! Ahhh! AHHHHH!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:325
translate chinese Vi_S5b_scene_6672353c:

    # MC "You like it when I squeeze your breasts like this, don’t you?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:326
translate chinese Vi_S5b_scene_deb94533:

    # Violet "Mmm! It feels ah... magical when you *Pant* pound my pussy at the same time! Like fireworks going off in my brain. Ooohh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:328
translate chinese Vi_S5b_scene_b3560375:

    # Violet "Ayaaah! Ah! Right there! Don’t stop! Ohhhhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:330
translate chinese Vi_S5b_scene_2b0f104c:

    # Violet "(He’s hitting my g-spot at this angle!)"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:332
translate chinese Vi_S5b_scene_6afae736:

    # Violet "*Gasp* Yes! Ayaahhh! I’m cumming! I’m cumming again!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:334
translate chinese Vi_S5b_scene_c50dbf50:

    # MC "Hnnng! Ah... *Pant* Ohh...Fuuuck!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:336
translate chinese Vi_S5b_scene_cd20ab4d_2:

    # Violet "Ah! Ahhh! AHHHHH!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:338
translate chinese Vi_S5b_scene_e0a2a9be:

    # Violet "Ayaaahhh!! Ooohhhhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:340
translate chinese Vi_S5b_scene_cb759d8b:

    # MC "Ugh! God, your pussy is so tight!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:342
translate chinese Vi_S5b_scene_24eb960c:

    # Violet "Ah! Ah! Ah! Ahh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:344
translate chinese Vi_S5b_scene_53533f61:

    # MC "Ohh, fuck! Mmm!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:346
translate chinese Vi_S5b_scene_5230119a:

    # MC "*Pant* I’m getting close, Violet!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:347
translate chinese Vi_S5b_scene_ce2d295c:

    # Violet "Ah! Ahh! Finish wherever you want! Ohhhh!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:353
translate chinese Vi_S5b_scene_d9dfff83:

    # MC "Hnnng! Fuck, I’m gonna cum!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:354
translate chinese Vi_S5b_scene_18749215:

    # Violet "Yessss! Fill me up, [player_name]!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:355
translate chinese Vi_S5b_scene_1f021186:

    # MC "HNNNGG!!! Arrgghhh!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:365
translate chinese Vi_S5b_scene_0c18c94f:

    # Violet "*Gasp* Oohhh, it’s so warm! Mmmm!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:366
translate chinese Vi_S5b_scene_031fbec4:

    # MC "*Pant* Ohh... God... that was amazing."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:373
translate chinese Vi_S5b_scene_af5a96b0:

    # MC "*Pant* I’m gonna cum! Hnnngg!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:374
translate chinese Vi_S5b_scene_ea6ac835:

    # Violet "Go on, [player_name]! Paint my ass with your thick cum!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:384
translate chinese Vi_S5b_scene_db810d41:

    # MC "Oohh... Ah... Wow..."
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:385
translate chinese Vi_S5b_scene_c65f583a:

    # MC "Your pussy is phenomenal to fuck, Violet. You know that?"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:386
translate chinese Vi_S5b_scene_d4cfcc18:

    # Violet "I’ve heard better compliments *Pant*, but I guess a girl has to take what she can get, right? Haha!"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:392
translate chinese Vi_S5b_end_335537be:

    # Violet "Listen, [player_name], I really can’t thank you enough for everything you did today for me. And the day before that. And... Well, you get what I’m trying to say."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:393
translate chinese Vi_S5b_end_ca186e4f:

    # Violet "You and Caroline have both been helping me out for a really long time now, and I don’t think I’d have been able to get this far without the two of you."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:394
translate chinese Vi_S5b_end_67567184:

    # Violet "So... I guess what I’m just trying to say is, thank you. For everything."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:396
translate chinese Vi_S5b_end_1bd4f493:

    # Violet "If there’s anything I can do to repay the-"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:397
translate chinese Vi_S5b_end_2196a7de:

    # MC "Your massage was really good!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:398
translate chinese Vi_S5b_end_770be81f:

    # Violet "Haha, fine! Drop by in the morning and I can give you another massage anytime you want one. How does that sound?"
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:399
translate chinese Vi_S5b_end_94f52d0a:

    # MC "Sounds fantastic, Violet. Looking forward to it!"
    MC ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:400
translate chinese Vi_S5b_end_3d59e082:

    # Violet "Goodnight, [player_name]. I think I’ll actually sleep quite peacefully without Dwayne, stomping around drunk in the middle of the night."
    Violet ""

# game/scripts/Vi_scenes/7_Vi_S5b.rpy:401
translate chinese Vi_S5b_end_3adbcd6b:

    # MC "Night, Violet. I’ll swing by in the morning sometime for that free massage."
    MC ""

translate chinese strings:

    # game/scripts/Vi_scenes/7_Vi_S5b.rpy:349
    old "Creampie Violet’s pussy."
    new ""

    # game/scripts/Vi_scenes/7_Vi_S5b.rpy:349
    old "Pull out and cum over Violet’s ass."
    new ""

