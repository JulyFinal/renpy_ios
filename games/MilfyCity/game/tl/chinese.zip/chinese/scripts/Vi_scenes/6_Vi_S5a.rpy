﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:97
translate chinese Vi_S5a_step_locked_01da7875:

    # MC "(Violet should be at her home in the afternoon.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:110
translate chinese Vi_S5a_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:122
translate chinese Vi_S5a_scene_bb872eeb:

    # MC "(Oh thank God, I was beginning to worry that she wasn’t home. I really need to talk to her about Dwayne. I can’t let myself just end up becoming an accessory to his crimes.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:126
translate chinese Vi_S5a_scene_7184b268:

    # MC "Hi Violet, is now a good time to talk? Something’s happened, and I kinda need your advice."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:130
translate chinese Vi_S5a_scene_1bfc64db:

    # Violet "Oh, hey [player_name]. Sure. I don’t have any clients this afternoon. What’s up?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:131
translate chinese Vi_S5a_scene_63a709ce:

    # MC "Good to hear. Sorry I’ve... uh... run into a little bit of trouble with Dwayne."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:133
translate chinese Vi_S5a_scene_3c93e557:

    # Violet "Is this about the ten grand that he claims you owe him?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:134
translate chinese Vi_S5a_scene_a72393c1:

    # MC "Eh, not really. I mean, it’s kinda related to that, but things are just starting to spiral out of control on me."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:135
translate chinese Vi_S5a_scene_7568ef25:

    # Violet "Whoa, take a deep breath, calm down, and tell me what happened."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:137
translate chinese Vi_S5a_scene_a6b73bd8:

    # MC "(Where to begin?)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:138
translate chinese Vi_S5a_scene_af02601e:

    # MC "*Sigh* Alright, so... I couldn’t come up with the money in time, so Dwayne started trying to charge me interest on the debt. But if I couldn’t pay the debt, then there’s no way I could pay the interest either."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:140
translate chinese Vi_S5a_scene_8f489632:

    # MC "Dwayne said that he’d wipe the interest if I stood watch for him while he robbed some apartments. But, he threatened me if I called the cops or anything, so I didn’t really have a choice either way!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:141
translate chinese Vi_S5a_scene_4a7d791b:

    # MC "So, I think I’ve accidentally become like Dwayne’s criminal lackey or something."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:143
translate chinese Vi_S5a_scene_4774dc33:

    # Violet "...shit. I’m super sorry about this, [player_name]."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:144
translate chinese Vi_S5a_scene_db38e3b5:

    # Violet "I... I honestly don’t know what to do. If I had some kind of “magic bullet” to fix the problems I have with my brother, I would have used it years ago."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:145
translate chinese Vi_S5a_scene_51f78459:

    # MC "*Sigh* It’s alright. Thanks for hearing me out, at least."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:147
translate chinese Vi_S5a_scene_faa3f735:

    # Violet "Y’know... There isn’t much I can do to make Dwayne back off, but I MIGHT be able to make you feel a bit better."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:148
translate chinese Vi_S5a_scene_f8756c79:

    # MC "Make me feel better?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:150
translate chinese Vi_S5a_scene_3f3fa184:

    # Violet "Yeah, take the edge off - if you know what I mean."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:151
translate chinese Vi_S5a_scene_a5d9db9f:

    # MC "(God, I love it when she goes commando with that dress on. It’s so fucking hot.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:153
translate chinese Vi_S5a_scene_4a733c4a:

    # Violet "What do you say? How about I “compensate” you for all the hassle Dwayne has caused?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:154
translate chinese Vi_S5a_scene_67a23101:

    # MC "Really Violet, you don’t need to-"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:156
translate chinese Vi_S5a_scene_f8307c04:

    # Violet "What if I want to?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:157
translate chinese Vi_S5a_scene_fcc8053a:

    # MC "Well, if you REALLY want to, I’m hardly gonna say no!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:159
translate chinese Vi_S5a_scene_368f4265:

    # Violet "Hmm, Dwayne’s not going to be home for a while, so we have the kitchen to ourselves. Perhaps we could make out while I stroke you off?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:160
translate chinese Vi_S5a_scene_e67c14e7:

    # MC "That definitely sounds fun."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:162
translate chinese Vi_S5a_scene_8e7a0bf1:

    # Violet "Or, perhaps I could get down on my knees and take your fat cock in my mouth again? I never told you, but I really enjoyed sucking on it when Caroline first introduced us."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:163
translate chinese Vi_S5a_scene_57d8e27c:

    # MC "I probably owe you an apology. I kinda just went wild, fucking your face that day."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:164
translate chinese Vi_S5a_scene_6ed4da13:

    # Violet "Hehe, you were certainly very eager."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:166
translate chinese Vi_S5a_scene_c6df0e33:

    # Violet "Very well, a blowjob it is, then. I bet you’re already rock hard, aren’t you?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:167
translate chinese Vi_S5a_scene_59e3d8a2:

    # MC "You’ll have to find that out for yourself."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:173
translate chinese Vi_S5a_scene_049aff92:

    # Violet "Mmm! You really are! Tell me, [player_name], was it seeing me in this tight black dress that got you so excited?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:174
translate chinese Vi_S5a_scene_38052970:

    # MC "*Groan* Mmm..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:175
translate chinese Vi_S5a_scene_d2aa6aed:

    # Violet "Or perhaps it was when I spread my legs and flashed my pussy?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:177
translate chinese Vi_S5a_scene_23a2643c:

    # Violet "Wait, I know. It was when I said I would suck on your fat cock. That was it. You can’t wait for me to engulf your big dick, can you?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:178
translate chinese Vi_S5a_scene_e00e3f4d:

    # MC "*Pant* Oh..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:180
translate chinese Vi_S5a_scene_138eb574:

    # Violet "Relax and try to enjoy what happens next, [player_name]. Forget about Dwayne and all the shit you have going on."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:182
translate chinese Vi_S5a_scene_f4e534cc:

    # Violet "Just let me suck your stress away."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:184
translate chinese Vi_S5a_scene_655826b5:

    # MC "(I love looking down and seeing the edges of her nipples poking out from the top of that dress. It’s WAY too small for her!)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:186
translate chinese Vi_S5a_scene_009d51a0:

    # MC "Do you want a heads up when I’m about to finish?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:188
translate chinese Vi_S5a_scene_2e45778e:

    # Violet "You don’t need to tell me when you’re about to cum. I’m a girl who enjoys surprises. Hehe!"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:190
translate chinese Vi_S5a_scene_bc6c8364:

    # Violet "*Lick* *Lick*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:191
translate chinese Vi_S5a_scene_9c339297:

    # MC "Ah... Mmm! *Pant* Oohhh..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:192
translate chinese Vi_S5a_scene_b7032bfc:

    # MC "(God, it feels really good when Violet rolls her tongue around the tip of my cock like that.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:194
translate chinese Vi_S5a_scene_2fb79d04:

    # Violet "*Kiss* Mwah! *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:195
translate chinese Vi_S5a_scene_6b58d888:

    # MC "Hnnng... Mmm! God, you’re incredible at that, Violet. *Pant*"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:196
translate chinese Vi_S5a_scene_ef198ddb:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:197
translate chinese Vi_S5a_scene_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:199
translate chinese Vi_S5a_scene_e9415b6b:

    # Violet "*Shlurp* *Suck* *Suck* *SHLUUURRRP*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:200
translate chinese Vi_S5a_scene_63b9af50:

    # MC "Ohhhh God! Hnnnggg! Fuuuuck... *Pant* That’s amazing... Ohhh!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:201
translate chinese Vi_S5a_scene_e658be9a:

    # MC "(She’s just as skilled with her lips, as she is with her tongue!)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:203
translate chinese Vi_S5a_scene_ef198ddb_1:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:204
translate chinese Vi_S5a_scene_0079cd82:

    # MC "*Pant* Mmm! Fuck..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:206
translate chinese Vi_S5a_scene_5ae442bc:

    # Violet "*Suck* *Suck* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:207
translate chinese Vi_S5a_scene_0d4cb0df:

    # MC "Oh! Don’t stop! Mmm! Just like that! Keep going! God, you’re so fucking hot!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:208
translate chinese Vi_S5a_scene_ef198ddb_2:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:211
translate chinese Vi_S5a_scene_554ae777:

    # Dwayne "The FUCK are you ramblin’ about?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:212
translate chinese Vi_S5a_scene_134e6d13:

    # MC "Jesus! D-Dwayne! You’re home!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:213
translate chinese Vi_S5a_scene_f103cd46:

    # Dwayne "‘Course I’m home. It’s my fuckin’ place. Now, what the FUCK are you talkin’ about?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:215
translate chinese Vi_S5a_scene_38568d5d:

    # Dwayne "You sound like you’re getting your cock sucked or somethin’. But you’re CLEARLY not doin’ that, because if you WERE doin’ that in my house, I’d break your fuckin’ legs."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:216
translate chinese Vi_S5a_scene_9554e2d1:

    # MC "I’m... uh... n-not! I’m just... um... m-making a pot of... tea! Would you like some?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:217
translate chinese Vi_S5a_scene_6285f319:

    # Dwayne "You’re making a pot of tea?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:218
translate chinese Vi_S5a_scene_aafaf41c:

    # MC "Uh huh. *Gulp*"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:220
translate chinese Vi_S5a_scene_a2b95791:

    # Dwayne "Do you always say, “Just like that” and “Keep going” when you’re making tea?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:221
translate chinese Vi_S5a_scene_2958fd9d:

    # MC "I was... encouraging the kettle... to boil."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:222
translate chinese Vi_S5a_scene_80246032:

    # Dwayne "Uh huh... And how do you explain, “God, you’re so fucking hot?”"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:223
translate chinese Vi_S5a_scene_32af7e63:

    # MC "I... burnt my fingers on the... *Gulp* k-kettle! S-So I shouted, “God, you’re so... fucking... hot...” to... the kettle."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:225
translate chinese Vi_S5a_scene_6d23f2d7:

    # Dwayne "*Sigh* Fuckin’ weirdo..."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:226
translate chinese Vi_S5a_scene_4215f488:

    # MC "S-So, how are you, Dwayne?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:227
translate chinese Vi_S5a_scene_6663736e:

    # Dwayne "Just came in for a Bod Light. Best beer in the world."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:229
translate chinese Vi_S5a_scene_52af60be:

    # Violet "*Whispered* Shush..."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:230
translate chinese Vi_S5a_scene_795b8175:

    # MC "Y-Yeah, it r-really is! Can’t beat a good bud!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:232
translate chinese Vi_S5a_scene_ef198ddb_3:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:234
translate chinese Vi_S5a_scene_c02ce64b:

    # Dwayne "I’ve tried a few different ones in the past, but Bod Light is the only one that can truly capture the taste and sensation of someone pissing in your mouth. D'ya know what I mean?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:236
translate chinese Vi_S5a_scene_9afe4a13:

    # MC "Y-Yeah! Mmm! *Cough* T-Totally."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:238
translate chinese Vi_S5a_scene_b792c08a:

    # Dwayne "I’m gonna let you in on a little secret, [player_name]. A lot of amateur Bod Light drinkers drink their beer straight from the fridge, but that’s not how you do it."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:239
translate chinese Vi_S5a_scene_47b4c0c2:

    # MC "N-No?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:241
translate chinese Vi_S5a_scene_432b631e:

    # Violet "*Shlurrrp*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:243
translate chinese Vi_S5a_scene_7c5efd24:

    # Dwayne "The REAL trick is to leave it sitting in the sun for an hour or so, to warm up a bit."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:244
translate chinese Vi_S5a_scene_5c00ca9d:

    # MC "Mmm... That sounds... *Gulp* ...r-really good."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:245
translate chinese Vi_S5a_scene_ee2d452f:

    # Dwayne "Takes a true Bod Light aficionado like myself to really appreciate the complex, nuanced flavours."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:247
translate chinese Vi_S5a_scene_98872368:

    # MC "Uh huh - y-yeah."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:248
translate chinese Vi_S5a_scene_a2abc29d:

    # Violet "*Suck* *Suck* *Shlluurrrp*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:249
translate chinese Vi_S5a_scene_54d31a22:

    # Dwayne "I mean, there’s a reason why people on the BudLight forums call this drink “liquid gold” after all."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:251
translate chinese Vi_S5a_scene_27e5d06a:

    # MC "People actually call it that? I- I mean, of course they do! Hnngg..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:252
translate chinese Vi_S5a_scene_eab511cd:

    # Dwayne "Huh... Wait a minute... Something ain’t right."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:253
translate chinese Vi_S5a_scene_bec3432b:

    # MC "(Oh fuck.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:255
translate chinese Vi_S5a_scene_933c9e49:

    # Dwayne "There’s somethin’ fishy goin’ on here..."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:256
translate chinese Vi_S5a_scene_6844332b:

    # MC "F-Fishy? I don’t know what yooohhh’re t-talking about! Hnnng.... Mmm..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:257
translate chinese Vi_S5a_scene_ef198ddb_4:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:259
translate chinese Vi_S5a_scene_67bf2de9:

    # MC "*Whispered* Slow down, I think he’s starting to notice!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:260
translate chinese Vi_S5a_scene_2ef42b7a:

    # Violet "*SUCK* *SUCK* *SUCK*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:261
translate chinese Vi_S5a_scene_eac50f4b:

    # MC "Mmmmm..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:262
translate chinese Vi_S5a_scene_98be8e16:

    # Dwayne "Well, I’ll be damned..."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:265
translate chinese Vi_S5a_scene_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:266
translate chinese Vi_S5a_scene_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:267
translate chinese Vi_S5a_scene_f2396c69:

    # Dwayne "I don’t fuckin’ believe it!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:269
translate chinese Vi_S5a_scene_ed8d9971:

    # Dwayne "This is fuckin’ unacceptable!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:270
translate chinese Vi_S5a_scene_a72b12ec:

    # MC "W-Wait, I can explain Dwayne, it wasn't my idea to-"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:273
translate chinese Vi_S5a_scene_238b2297:

    # "*CLANG*"
    ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:274
translate chinese Vi_S5a_scene_cc48f508:

    # Dwayne "VIOLET! VIOLET! WHERE THE FUCK ARE YOU, YOU PIECE OF SHIT?!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:275
translate chinese Vi_S5a_scene_bf91a631:

    # Violet "*Suck* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:277
translate chinese Vi_S5a_scene_6ffaec87:

    # Dwayne "Arrgh! Dumb bitch forgot to pick me up beer from the store again!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:278
translate chinese Vi_S5a_scene_9dc9ae79:

    # MC "*Phew* (I thought he had noticed Violet sucking on my dick!)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:281
translate chinese Vi_S5a_scene_a792ebb9:

    # "*BANG*"
    ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:282
translate chinese Vi_S5a_scene_47df7a54:

    # Dwayne "Goddamn useless sister."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:283
translate chinese Vi_S5a_scene_fe5cd29c:

    # MC "A-Are you still thirsty?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:285
translate chinese Vi_S5a_scene_5f6708a5:

    # Dwayne "What?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:286
translate chinese Vi_S5a_scene_c0aa1bad:

    # MC "If you’ve got no beer then p-perhaps I could offer you a- a tea? Or maybe not?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:287
translate chinese Vi_S5a_scene_a5fe08a2:

    # Dwayne "Let me tell you what you can do for me. The next time you see Violet, I want you to give her a message?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:289
translate chinese Vi_S5a_scene_e0f30c42:

    # MC "Y-Yeah, sure!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:290
translate chinese Vi_S5a_scene_ef198ddb_5:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:291
translate chinese Vi_S5a_scene_4308689a:

    # Dwayne "You tell that piece of shit to take a look at the dent in the fridge. THEN you tell her that the NEXT time she forgets to pick me up my Bod Light, it won’t be the fridge getting smashed. Capiche?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:293
translate chinese Vi_S5a_scene_3b4f6ad7:

    # MC "G-Got it! I’ll... *Gulp* definitely relay that m-message."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:295
translate chinese Vi_S5a_scene_5b1626aa:

    # Dwayne "Good."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:297
translate chinese Vi_S5a_scene_6246b1bb:

    # Violet "*Suck* *Shlurp* *Suuuck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:299
translate chinese Vi_S5a_scene_434f0d89:

    # Dwayne "And get the fuck out of my house when you finish making that Goddamn tea!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:300
translate chinese Vi_S5a_scene_d1fa9c3e:

    # MC "Y-yeah, n-no problem!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:303
translate chinese Vi_S5a_scene_174dd1aa:

    # MC "(Fucking hell, that was WAY too close!)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:304
translate chinese Vi_S5a_scene_cf46a3f9:

    # MC "*Whispered* I thought you said Dwayne wasn’t going to be home!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:306
translate chinese Vi_S5a_scene_3fa0b1a9:

    # Violet "*Phew*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:307
translate chinese Vi_S5a_scene_84040b44:

    # Violet "*Whispered* He wasn’t supposed to be! He’d have probably killed you if he caught you facefucking his sister in the kitchen."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:308
translate chinese Vi_S5a_scene_fd6437bd:

    # MC "*Whispered* Then why did you keep sucking me in front of him?!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:310
translate chinese Vi_S5a_scene_f640272c:

    # Violet "*Whispered* Hehe, you enjoyed it!"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:311
translate chinese Vi_S5a_scene_21976f9a:

    # MC "*Whispered* That was WAY too risky! It wasn’t just me that Dwayne threatened - you put yourself in danger too."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:312
translate chinese Vi_S5a_scene_759f7070:

    # Violet "*Whispered* It makes little difference to me, I’m always in a bit of danger around him."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:313
translate chinese Vi_S5a_scene_7b90b368:

    # Violet "Now, how about we forget he’s home - you wrap your hands around my head, and fuck my throat?"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:315
translate chinese Vi_S5a_scene_efcd4a96:

    # Violet "*Glompf* *SHLURP* *Gag*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:316
translate chinese Vi_S5a_scene_5d354441:

    # MC "Hnnng! Ugh! Fuck...Your throat feels incredible."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:318
translate chinese Vi_S5a_scene_5b5ef6fb:

    # Violet "*Shlurp* *Gag* Mmppffff!"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:320
translate chinese Vi_S5a_scene_8e77ec34:

    # MC "Ohh... Mmm! *Pant* Just like that, Violet. Ah..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:322
translate chinese Vi_S5a_scene_9426e5a9:

    # Violet "*Gag* Mppfff! *Shluuuurrrp*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:323
translate chinese Vi_S5a_scene_3e73a2f7:

    # MC "*Pant* Hnnng! Mmm!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:325
translate chinese Vi_S5a_scene_d1d6de2e:

    # MC "Ohhh... Fuck... I’m gonna cum!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:327
translate chinese Vi_S5a_scene_ee865c3e:

    # Dwayne "*Distant Voice* You’re gonna what?!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:329
translate chinese Vi_S5a_scene_9bb97344:

    # MC "I’m g-gonna come out with the tea s-soon!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:331
translate chinese Vi_S5a_scene_5c48cde0:

    # Dwayne "*Distant Voice* Huh... Fuckin’ weirdo."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:333
translate chinese Vi_S5a_scene_ef198ddb_6:

    # Violet "*Shlurp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:338
translate chinese Vi_S5a_scene_4db09bd1:

    # MC "Hnnngg! Oh God! I’m cumming! Arrghhh!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:339
translate chinese Vi_S5a_scene_d110cfff:

    # Violet "*Gag* *Gag* *Shlurrrp* *Suck*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:340
translate chinese Vi_S5a_scene_4065a836_1:

    # MC "Ohhh..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:350
translate chinese Vi_S5a_scene_354faad5:

    # MC "HNNNG! Aah... ohhh... *Pant* Fuck..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:351
translate chinese Vi_S5a_scene_43f5d95a:

    # Violet "Mmmpf! *Shlurp* *Gulp* *Gulp*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:352
translate chinese Vi_S5a_scene_5eff602f:

    # MC "*Pant* Your mouth’s amazing, Violet. Mmm..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:354
translate chinese Vi_S5a_scene_5b16fae8:

    # Violet "Mmm! *Gulp*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:355
translate chinese Vi_S5a_scene_731f0a72:

    # Violet "(Delicious!)"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:357
translate chinese Vi_S5a_scene_cbbb77cb:

    # MC "Right, I should better get out of here before Dwayne figures out what was going on."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:358
translate chinese Vi_S5a_scene_abaac7f2:

    # Violet "Yeah, you’re right. Try not to antagonise him on your way out."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:359
translate chinese Vi_S5a_scene_00d05aec:

    # MC "I’ll be careful."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:361
translate chinese Vi_S5a_scene_7efc2e7e:

    # Violet "I’m gonna sneak out the back and grab some beer from the store. I’ll see you later on, [player_name]."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:362
translate chinese Vi_S5a_scene_19fda0c0:

    # Violet "Oh, and thanks for dropping by to check up on me. It meant a lot."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:363
translate chinese Vi_S5a_scene_793eccf8:

    # MC "Anytime, Violet. I’ll see you later."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:369
translate chinese Vi_S5a_scene_fa4e0155:

    # MC "Open wide and stick your tongue out. I’m about to cum!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:370
translate chinese Vi_S5a_scene_dc9f2fbc:

    # Violet "Aaahhh..."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:371
translate chinese Vi_S5a_scene_b4736573:

    # MC "Hnnng! Ugh! *Pant* Ohhh fuck!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:381
translate chinese Vi_S5a_scene_b597a867:

    # MC "Ohhh! Fuck! Arrggh!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:382
translate chinese Vi_S5a_scene_2c0f7dd3:

    # Violet "Aaahhhh..."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:383
translate chinese Vi_S5a_scene_9c50d7d5:

    # MC "Hnnnngg! *Pant* Ohhh..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:385
translate chinese Vi_S5a_scene_dff58f41:

    # MC "*Pant* *Pant* Mmm..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:386
translate chinese Vi_S5a_scene_cbb79ae9:

    # MC "God, you’re a *Pant* great cocksucker, Violet."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:388
translate chinese Vi_S5a_scene_5b16fae8_1:

    # Violet "Mmm! *Gulp*"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:389
translate chinese Vi_S5a_scene_731f0a72_1:

    # Violet "(Delicious!)"
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:391
translate chinese Vi_S5a_scene_cbbb77cb_1:

    # MC "Right, I should better get out of here before Dwayne figures out what was going on."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:392
translate chinese Vi_S5a_scene_abaac7f2_1:

    # Violet "Yeah, you’re right. Try not to antagonise him on your way out."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:393
translate chinese Vi_S5a_scene_00d05aec_1:

    # MC "I’ll be careful."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:395
translate chinese Vi_S5a_scene_7efc2e7e_1:

    # Violet "I’m gonna sneak out the back and grab some beer from the store. I’ll see you later on, [player_name]."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:396
translate chinese Vi_S5a_scene_19fda0c0_1:

    # Violet "Oh, and thanks for dropping by to check up on me. It meant a lot."
    Violet ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:397
translate chinese Vi_S5a_scene_793eccf8_1:

    # MC "Anytime, Violet. I’ll see you later."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:431
translate chinese Vi_S5a_Dwyane_1d37c7b7:

    # MC "(Is he just staring at a black screen? He hasn’t even turned the TV on...)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:435
translate chinese Vi_S5a_Dwyane_1f8cd4db:

    # MC "Uh, h-hey, Dwayne! Whatcha watching?"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:439
translate chinese Vi_S5a_Dwyane_484393c1:

    # Dwayne "Final season of Game of Whores."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:440
translate chinese Vi_S5a_Dwyane_a149a92c:

    # MC "Oh, right. Well, I’m just leaving now, I’ll... uh... see you later."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:442
translate chinese Vi_S5a_Dwyane_35c6e2b0:

    # Dwayne "Hold up. You got my cash?"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:443
translate chinese Vi_S5a_Dwyane_bc596b8f:

    # MC "I... N-Not quite yet, I just need to- um... get the... bank to..."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:444
translate chinese Vi_S5a_Dwyane_c197fc8b:

    # Dwayne "Ugh! Fuck sake."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:446
translate chinese Vi_S5a_Dwyane_79e1662c:

    # Dwayne "What are you still standing in my fucking house for? Fuck off and get me my money!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:447
translate chinese Vi_S5a_Dwyane_01944305:

    # MC "Y-Yeah, sure thing."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:449
translate chinese Vi_S5a_Dwyane_66a8901b:

    # Dwayne "And just so we’re clear, no more second chances. Next time you see me, you BETTER have the cash, or there will be consequences."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:450
translate chinese Vi_S5a_Dwyane_8ee2e2a0:

    # MC "Y-Yeah, no sweat!"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:452
translate chinese Vi_S5a_Dwyane_d3dc8725:

    # Dwayne "Only reason I’m being so lenient with you, right now, is because Game of Whores has got me in a really good mood."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:453
translate chinese Vi_S5a_Dwyane_f074713e:

    # Dwayne "I’m excited to see how this ends, y’know what I mean? It’s gonna be fucking great!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:455
translate chinese Vi_S5a_Dwyane_da35ae38:

    # Dwayne "I mean, God forbid the writers somehow fuck up the last few episodes. Haha! If THAT happened, then I’d probably need someone to take my rage out on..."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:456
translate chinese Vi_S5a_Dwyane_63b9efed:

    # Dwayne "...and that would be you."
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:457
translate chinese Vi_S5a_Dwyane_ee232ae4:

    # MC "W-Well, it’s a g-good thing the ending is... extremely well written! Y-You’re really gonna enjoy it."
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:459
translate chinese Vi_S5a_Dwyane_afbfe7a0:

    # MC "(Fuck me. I’m actually going to die. I’m going to be the first person in history to be killed by shitty writers from HBO.)"
    MC ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:460
translate chinese Vi_S5a_Dwyane_41f909f2:

    # Dwayne "God! I’m so fucking pumped to see how the Golden Company go into battle! They’re gonna be fucking awesome!"
    Dwayne ""

# game/scripts/Vi_scenes/6_Vi_S5a.rpy:471
translate chinese Vi_S5a_Dwyane_5477a073:

    # MC "(I've already talked with him.)"
    MC ""

translate chinese strings:

    # game/scripts/Vi_scenes/6_Vi_S5a.rpy:335
    old "Finish in Violet’s mouth."
    new ""

    # game/scripts/Vi_scenes/6_Vi_S5a.rpy:335
    old "Pull out and paint Violet’s face with your semen."
    new ""

