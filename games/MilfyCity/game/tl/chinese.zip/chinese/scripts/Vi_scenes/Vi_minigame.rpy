﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/Vi_minigame.rpy:162
translate chinese Vi_mg_wrong_c673fb83:

    # Dwayne "The FUCK are you whistling!?"
    Dwayne ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:163
translate chinese Vi_mg_wrong_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:164
translate chinese Vi_mg_wrong_58fdc6c3:

    # Dwayne "No one is coming you moron!"
    Dwayne ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:166
translate chinese Vi_mg_wrong_fea95436:

    # MC "My bad..."
    MC ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:167
translate chinese Vi_mg_wrong_ac40c423:

    # MC "(Maybe let's focus a little more... Asshole...)"
    MC ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:189
translate chinese Vi_mg_tutorial_2781fd8f:

    # "(Pay attention to passersby and make sure they don't even look in your direction.)"
    ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:191
translate chinese Vi_mg_tutorial_facf8a7b:

    # "(If they do, it's better to blow the whistle.)"
    ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:205
translate chinese Vi_mg_end_8aad919c:

    # MC "(Maybe I could call the police and let them know to approach without their sirens on? They could take Dwayne by surprise...)"
    MC ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:206
translate chinese Vi_mg_end_2fe4b1fd:

    # MC "(Then again, they might arrest me too - as an accomplice...)"
    MC ""

# game/scripts/Vi_scenes/Vi_minigame.rpy:207
translate chinese Vi_mg_end_155fc426:

    # MC "(And the Dean DID tell me that he was able to sort it out because I HADN’T called the police so far. Maybe I should just wait and see what the Dean is cooking up?)"
    MC ""

