﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_scenes/8_Vi_S6.rpy:62
translate chinese Vi_S6_talked_f064fcdc:

    # Violet "Swing by any morning you fancy another massage."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:73
translate chinese Vi_S6_f2d0beaa:

    # MC "(Violet is usually free in the morning.)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:89
translate chinese Vi_S6_37bafff9:

    # Violet "Good morning, [player_name], back for another massage?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:91
translate chinese Vi_S6_b6d2a3e6:

    # MC "Morning Violet, you know it! Do you have a slot free right now?"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:95
translate chinese Vi_S6_e3240278:

    # Violet "Yeah, sure! Come on in."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:99
translate chinese Vi_S6_d3d05dc2:

    # Violet "As always, just take your clothes off and lie down on the table."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:104
translate chinese Vi_S6_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:106
translate chinese Vi_S6_dc1a4324:

    # Violet "Some tension in your shoulders again."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:110
translate chinese Vi_S6_8a4e78eb:

    # Violet "Let me just work out a couple of knots here..."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:112
translate chinese Vi_S6_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:116
translate chinese Vi_S6_acca7619:

    # Violet "Would you like a happy ending today?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:120
translate chinese Vi_S6_a725b3c9:

    # MC "Oh yeah, definitely."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:124
translate chinese Vi_S6_4130d593:

    # Violet "I’m always amazed at how you can get so hard, so quickly."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:126
translate chinese Vi_S6_275a2d2b:

    # MC "What can I say? I’m an insatiable sex machine, and you’re stunning to look at."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:130
translate chinese Vi_S6_383c41ee:

    # Violet "Hehe, a charmer as always."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:134
translate chinese Vi_S6_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:138
translate chinese Vi_S6_ca365770:

    # MC "Ohh... That’s perfect, Violet. Mmm!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:140
translate chinese Vi_S6_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:142
translate chinese Vi_S6_03361e2d:

    # MC "God... Your tits are fantastic, Violet. Ahh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:146
translate chinese Vi_S6_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:148
translate chinese Vi_S6_1b85c83d:

    # Violet "I can see you’re really enjoying this, aren't you?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:152
translate chinese Vi_S6_38052970:

    # MC "*Groan* Mmm..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:154
translate chinese Vi_S6_b987e77d_2:

    # MC "Ahh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:157
translate chinese Vi_S6_de162518:

    # Violet "You’re getting close, aren't you? I can feel your cock, throbbing between my tits."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:159
translate chinese Vi_S6_51f7f7fa:

    # MC "Hnnngg... Mmm!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:163
translate chinese Vi_S6_f523b3ec:

    # Violet "Cum for me. Cum all over my big, fat tits."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:173
translate chinese Vi_S6_2cbb4dbf:

    # MC "Hnnng! Aargghh!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:175
translate chinese Vi_S6_6738f607:

    # Violet "Wow! There we go!"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:179
translate chinese Vi_S6_5b83d877:

    # Violet "Hehe, you really had a big load stored for me, there, didn’t you?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:183
translate chinese Vi_S6_5c3cd921:

    # MC "*Pant* Thanks, Violet. That was *Pant* amazing."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:187
translate chinese Vi_S6_f064fcdc:

    # Violet "Swing by any morning you fancy another massage."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:189
translate chinese Vi_S6_6f67aa61:

    # MC "Sure! Will do!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:204
translate chinese Vi_S6a_ca73c09b:

    # MC "(This corner of town is still a shithole, but it DOES feel a little bit better, with Dwayne gone.)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:205
translate chinese Vi_S6a_af6d54cd:

    # MC "(I wonder how Violet is holding up, now that her brother is gone.)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:208
translate chinese Vi_S6a_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:209
translate chinese Vi_S6a_14b85720:

    # Violet "Who is it?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:210
translate chinese Vi_S6a_b64aaf49:

    # MC "Just me. I’m here to collect that free massage you offered me!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:213
translate chinese Vi_S6a_c5de92b3:

    # Violet "I was beginning to wonder whether you were coming over or not."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:214
translate chinese Vi_S6a_f637ae0a:

    # MC "Sorry, got held up a little bit. I see you got a new dress?"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:215
translate chinese Vi_S6a_ed2dbbba:

    # Violet "Do you like it?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:216
translate chinese Vi_S6a_fed13d46:

    # MC "It’s a lot less revealing than your previous one, but it’s nice. You look good in it."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:217
translate chinese Vi_S6a_16f1e585:

    # Violet "Yeah, I figured it was probably time to start dressing more professionally, given that I’m close to qualifying. I’d probably end up attracting the wrong type of clientele, if I dress that way when I open my store in the mall."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:219
translate chinese Vi_S6a_0db36835:

    # Violet "Anyway, why don’t you come on in? You know the drill by now. Make yourself at home."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:220
translate chinese Vi_S6a_81e8fe76:

    # MC "Cheers, Violet."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:221
translate chinese Vi_S6a_e4b22856:

    # Violet "Can I get you something to drink?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:222
translate chinese Vi_S6a_cf01ea3e:

    # MC "Nah, I’m all good."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:223
translate chinese Vi_S6a_c719be7e:

    # Violet "No problem. Follow me into my massage parlour whenever you’re ready."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:225
translate chinese Vi_S6a_674a57bf:

    # MC "(I might not be able to see her nipples anymore, but this dress is still extremely sexy. It really accentuates her cleavage!)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:226
translate chinese Vi_S6a_8584c0b6:

    # Violet "Alright, take off your clothes whenever you’re ready..."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:228
translate chinese Vi_S6a_6c1729ac:

    # Violet "...and lie down on the bed for me."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:229
translate chinese Vi_S6a_8e2faefd:

    # Violet "Is there any particular area of your body that you’d like me to focus on today? Apart from the obvious, hehe!"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:230
translate chinese Vi_S6a_0cdc00be:

    # MC "My back’s a little tense, perhaps you could-"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:231
translate chinese Vi_S6a_baa01f99:

    # Violet "No problem! Leave it to me."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:235
translate chinese Vi_S6a_7f430944:

    # Violet "You were right! There’s quite a few tough knots scattered along your upper back."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:236
translate chinese Vi_S6a_eaf6daf6:

    # MC "Ooh... That’s the spot! Ahmmmmm!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:238
translate chinese Vi_S6a_e99d0514:

    # Violet "That’s okay though, just leave this to me. I’ll work these out in no time at all."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:239
translate chinese Vi_S6a_dec8531a:

    # MC "Uh huh... Mmm... Ah...."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:241
translate chinese Vi_S6a_b6b90714:

    # MC "You’re... mmm... definitely getting better at this!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:242
translate chinese Vi_S6a_5e4cd1bb:

    # Violet "Thanks, [player_name]. Just try to relax. Close your eyes and imagine you’re on a beautiful beach in the Bahamas."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:244
translate chinese Vi_S6a_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:245
translate chinese Vi_S6a_ebf14208:

    # Violet "There we go. You’re lying on a golden sandy beach, a warm sun is gently beating down on your back. The rhythmic sound of waves rushing across the sands, washes into your ears."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:247
translate chinese Vi_S6a_df06caa6:

    # MC "Mmm... Ughhhh... OoooOOooohhh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:248
translate chinese Vi_S6a_f9b50a76:

    # Violet "This isn’t too hard, is it?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:249
translate chinese Vi_S6a_9cc2f288:

    # MC "Mmm, no... It’s perfect."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:251
translate chinese Vi_S6a_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:252
translate chinese Vi_S6a_f298a03e:

    # MC "(Violet’s fingers are incredible! She knows EXACTLY where to put the right amount of pressure!)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:254
translate chinese Vi_S6a_ec09bba3:

    # Violet "All good, [player_name]?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:255
translate chinese Vi_S6a_b8b14f5a:

    # MC "Uh huh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:256
translate chinese Vi_S6a_f2b8c029:

    # Violet "Would you like it if I applied a bit more pressure to your back?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:258
translate chinese Vi_S6a_5bde5c60:

    # MC "Sure, that sounds mmm... great."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:259
translate chinese Vi_S6a_e264a323:

    # Violet "Okay, I’m going to climb up. Just let me know if I go too hard or if it starts to hurt."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:261
translate chinese Vi_S6a_67299693:

    # MC "Mmmm!!!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:262
translate chinese Vi_S6a_3912a63f:

    # Violet "Hehe, is that good?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:263
translate chinese Vi_S6a_6fd67034:

    # MC "Ohhh... Fucking amazing, Violet. Uggghhh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:265
translate chinese Vi_S6a_d712bfa9:

    # Violet "I’m going to keep focusing on your shoulders. There seems to be quite a bit of tension built up there."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:266
translate chinese Vi_S6a_0817600a:

    # MC "Yeah, getting ten thousand dollars demanded off you by an angry psychopath, tends to cause that. Haha!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:267
translate chinese Vi_S6a_3bc262c1:

    # Violet "Hehe!"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:269
translate chinese Vi_S6a_49ccd00f:

    # Violet "I’m sorry again about Dwayne. Thanks for helping me through that. I really appreciate everything you’ve done for me, [player_name]."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:270
translate chinese Vi_S6a_79c51fe1:

    # MC "Mmm! No problem, Violet. I’m just glad to see you’re finally happy ooohhhh... for a change."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:274
translate chinese Vi_S6a_95136fca:

    # Violet "Would you like me to give you an extra special massage next?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:276
translate chinese Vi_S6a_15446753:

    # MC "Mmm, that’d be good. What are you thinking?"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:278
translate chinese Vi_S6a_70e463b6:

    # Violet "Well, I imagine you still have one muscle that needs to be properly rubbed to relieve some stress. Can you flip over for me, while I slip out of this dress?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:282
translate chinese Vi_S6a_b386ed54:

    # Violet "Oh my! You really do have some more tension here that needs worked out!"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:284
translate chinese Vi_S6a_b0ada41b:

    # MC "Well, you’re the professional masseuse. What do you recommend as the best treatment?"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:286
translate chinese Vi_S6a_372f7666:

    # Violet "Hmm, I would DEFINITELY opt for the breast massage treatment if I was in your position right now."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:290
translate chinese Vi_S6a_7cba504c:

    # MC "Very well, the breast massage treatment it is!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:292
translate chinese Vi_S6a_79764628:

    # Violet "You’re going to enjoy this, I promise. I have a one hundred percent success rate with this particular treatment."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:296
translate chinese Vi_S6a_2885ce88:

    # MC "(A hundred percent success rate? She certainly has confidence in her abilities!)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:300
translate chinese Vi_S6a_53622360:

    # MC "There’s something I’ve been wanting to ask, but I didn’t want to offend you."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:302
translate chinese Vi_S6a_02714355:

    # Violet "You probably won’t offend me. Shoot your question."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:304
translate chinese Vi_S6a_cd1be041:

    # MC "Are those... natural?"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:306
translate chinese Vi_S6a_8b091b6b:

    # Violet "Are you asking if I’ve had breast implants?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:308
translate chinese Vi_S6a_7981d408:

    # MC "Yeah. Have you?"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:310
translate chinese Vi_S6a_ab64c8c2:

    # Violet "Nope! Absolutely not. These are entirely real."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:312
translate chinese Vi_S6a_ccccf087:

    # MC "Wow! They look too good to be real!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:314
translate chinese Vi_S6a_b27ad78d:

    # Violet "Haha! I’ll take that as a compliment."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:317
translate chinese Vi_S6a_4322e323:

    # Violet "Let’s get started, shall we?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:319
translate chinese Vi_S6a_2c00cebd:

    # MC "(Wow, she looks so fucking hot!)"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:323
translate chinese Vi_S6a_0a0fd4ea:

    # Violet "You’re enjoying watching from this angle, aren't you? You probably love seeing your cock peeking out between my cleavage."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:325
translate chinese Vi_S6a_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:329
translate chinese Vi_S6a_d7c2c14c:

    # Violet "I’m going to start rubbing your shaft between my breasts, and I’m not going to stop until your balls are thoroughly drained of every last drop."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:331
translate chinese Vi_S6a_63d2c28f:

    # MC "*Groan* Oooohhh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:333
translate chinese Vi_S6a_a9b172ca:

    # Violet "Just lie back and relax as I move my tits up..."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:337
translate chinese Vi_S6a_f807cb9a:

    # Violet "...and all the way back down."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:339
translate chinese Vi_S6a_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:341
translate chinese Vi_S6a_a1e87446:

    # Violet "Focus on how good it feels when my soft boobs stroke against your sensitive glans."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:347
translate chinese Vi_S6a_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:349
translate chinese Vi_S6a_1cefdd3d:

    # Violet "I’m going to hold it here for a second and squeeze my breasts together"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:351
translate chinese Vi_S6a_03361e2d:

    # MC "God... Your tits are fantastic, Violet. Ahh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:354
translate chinese Vi_S6a_5753cad5:

    # Violet "How does this feel, [player_name]? Do you want me to go faster?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:356
translate chinese Vi_S6a_e908e474:

    # MC "Mmm, just like that is perfect. Oohh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:360
translate chinese Vi_S6a_bc568e8a:

    # MC "*Pant* Hnnng..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:362
translate chinese Vi_S6a_961f389f:

    # Violet "You don’t need to suppress your voice. Let it out. Be as loud as you want. I love hearing men moan when I pleasure them."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:364
translate chinese Vi_S6a_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:368
translate chinese Vi_S6a_1bd14793:

    # Violet "That’s it. Good boy. Keep moaning for me."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:370
translate chinese Vi_S6a_4884f764:

    # MC "Oooihh... Ahh! Mmm! *Gasp*"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:374
translate chinese Vi_S6a_3df4b3cd:

    # Violet "I love it when your thick cock throbs between my tits like that. That simple signal that you’re getting closer to your climax."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:376
translate chinese Vi_S6a_588443ed:

    # MC "Mmmm! Oooohhh!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:380
translate chinese Vi_S6a_ffcbfa1c:

    # Violet "I love giving boobjobs to guys when they’re lying down like this."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:382
translate chinese Vi_S6a_31353b37:

    # Violet "In a regular boobjob, where the guy is standing up, he can thrust his hips and fuck my tits as fast as he wants."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:386
translate chinese Vi_S6a_8d39cb21:

    # Violet "But when you’re lying on your back like this, with my weight pressing down, you can’t move your hips."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:388
translate chinese Vi_S6a_19f36314:

    # Violet "I’m in total control right now. I decide how quickly I’m going to rub your cock."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:390
translate chinese Vi_S6a_0ee8f13d:

    # Violet "I decide how much pressure to use..."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:394
translate chinese Vi_S6a_d1b53939:

    # Violet "...how tightly to squeeze your shaft."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:396
translate chinese Vi_S6a_c10dd104:

    # Violet "And the only role you have, is to lie there and watch it happen."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:398
translate chinese Vi_S6a_00d9141d:

    # MC "*Pant* Mmm..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:402
translate chinese Vi_S6a_f126d0e5:

    # MC "Ooohh... You’re so good at this..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:404
translate chinese Vi_S6a_db8b70c5:

    # Violet "That’s why I enjoy being a masseuse. I am completely in control of the pleasure that another human being feels. I can increase their pleasure or immediately cease it, at my whim."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:408
translate chinese Vi_S6a_d00ea810:

    # MC "Hnnnngg! *Pant* Can you move your tits faster? I’m about to cum!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:410
translate chinese Vi_S6a_46d10594:

    # Violet "You clearly haven’t been listening to what I’m saying."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:412
translate chinese Vi_S6a_05413475:

    # MC "*Pant* Huh? Sorry, I got distracted, staring at your boobs."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:416
translate chinese Vi_S6a_08d361cf:

    # Violet "I’m going to keep slowly moving my breasts up and down. You are just going to have to be a patient boy, and wait for your orgasm."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:418
translate chinese Vi_S6a_31b6968e:

    # MC "Hnnnng! Please! I’m so close!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:422
translate chinese Vi_S6a_35c42a89:

    # Violet "Patience, [player_name]. It’ll feel better if you let it come naturally. I’m not going to rush a climax out of you. Massages are supposed to be about relaxing your body."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:424
translate chinese Vi_S6a_1e6c545b:

    # MC "*Pant* I’m- I’m SOOO close!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:426
translate chinese Vi_S6a_7b9e25bd:

    # Violet "Up... and down... Up..."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:428
translate chinese Vi_S6a_0ee83d81:

    # MC "Ahhh! Ooohhhh!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:430
translate chinese Vi_S6a_3a3c3c3f:

    # Violet "And down..."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:434
translate chinese Vi_S6a_b5659dd9:

    # MC "HNNNGG! It’s happening! I’m coming! I’m-"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:436
translate chinese Vi_S6a_d20965d3:

    # Violet "Cum for me."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:438
translate chinese Vi_S6a_3c913c72:

    # MC "Arrghhhh!! HNNNGG! OOOHHHH!!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:448
translate chinese Vi_S6a_355cb09f:

    # MC "*Pant* *Pant* Ooohhh! Fuck!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:450
translate chinese Vi_S6a_60fc2e73:

    # Violet "And there we go!"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:452
translate chinese Vi_S6a_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:456
translate chinese Vi_S6a_f6e689e7:

    # MC "*Pant* Hnnnngg! *Gasp* Ooohhh..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:458
translate chinese Vi_S6a_c54e32ad:

    # Violet "See? What did I tell you? Slow and steady gives you a stronger orgasm."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:463
translate chinese Vi_S6a_9a7eacd6:

    # Violet "...and a bigger mess to clean up, apparently. Haha!"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:465
translate chinese Vi_S6a_8536a506:

    # MC "*Pant* Wow... That was *Pant* incredible..."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:469
translate chinese Vi_S6a_808e89b9:

    # Violet "Well? Are you going to visit me again?"
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:471
translate chinese Vi_S6a_0ff6a76d:

    # MC "Absolutely! That was amazing."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:475
translate chinese Vi_S6a_7bfa041a:

    # Violet "Swing by my place any time you’re feeling stress. I’ll try and fit you in, if I don’t have another client."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:477
translate chinese Vi_S6a_781c3213:

    # MC "Awesome, thanks, Violet!"
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:479
translate chinese Vi_S6a_26ba0f86:

    # Violet "Mornings work best for me."
    Violet ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:481
translate chinese Vi_S6a_c6a11844:

    # MC "I’ll keep that in mind. Catch you again later."
    MC ""

# game/scripts/Vi_scenes/8_Vi_S6.rpy:483
translate chinese Vi_S6a_404b9b06:

    # Violet "See ya soon!"
    Violet ""

