﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:32
translate chinese LiR2_MS1_576580c3:

    # MC "(I should probably check up on my aunties. Liza seemed a little irked with Yazmin abruptly dropping that threesome on her the last time I visited...)"
    MC ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:34
translate chinese LiR2_MS1_27f6ad69:

    # MC "(I should probably check up on Linda’s sister. Liza seemed a little irked with Yazmin abruptly dropping that threesome on her the last time I visited...)"
    MC ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:35
translate chinese LiR2_MS1_6426dd4c:

    # MC "(I wonder if they-)"
    MC ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:40
translate chinese LiR2_MS1_3a580448:

    # Liza "I’m just saying, you SHOULD have told me what you were planning before we jumped into it."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:44
translate chinese LiR2_MS1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:46
translate chinese LiR2_MS1_ab584640:

    # Yazmin "Oh, c’mon! Half the fun is the surprise of not knowing what is going to happen next!"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:48
translate chinese LiR2_MS1_3cd99aab:

    # Liza "He had his hand wrapped around your throat while he fucked you!"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:52
translate chinese LiR2_MS1_996d16cb:

    # Yazmin "And YOU were masturbating while it happened. You enjoyed watching it!"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:54
translate chinese LiR2_MS1_e509b88e:

    # MC "(Sounds like quite a heated discussion. Probably best if I don’t knock on the door right now.)"
    MC ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:65
translate chinese LiR2_MS1_83930275:

    # Liza "I’m not saying I didn’t enjoy it. What I’m trying to tell you is that I’d appreciate a head’s up before you decide to bring a random man into our bedroom."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:67
translate chinese LiR2_MS1_981604b7:

    # Yazmin "He’s not just some random man though, Liza - he’s your nephew!"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:69
translate chinese LiR2_MS1_86015249:

    # Yazmin "He’s not just some random man though, Liza - he’s your sister's tenant!"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:71
translate chinese LiR2_MS1_3a7812b2:

    # Liza "You’re saying that as if it somehow doesn’t make things ten times worse. You do realise how it’s objectively worse, right?"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:75
translate chinese LiR2_MS1_52e9eebf:

    # Yazmin "Fine, fine. How about we take some time to lay out exactly what you want from our sex life?"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:77
translate chinese LiR2_MS1_ff7f6f83:

    # Liza "Yeah, I’d appreciate that."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:79
translate chinese LiR2_MS1_b35ceef5:

    # Yazmin "Okay, so, you aren’t a huge fan of cocks. I know that much. You DID get turned on by [player_name] though, right?"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:83
translate chinese LiR2_MS1_f7fa6d20:

    # Liza "Eh... Not really. It wasn’t seeing [player_name] that turned me on. More... God, it’s hard to describe."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:85
translate chinese LiR2_MS1_5a2e7237:

    # Liza "I kinda got turned on by watching what he was doing to you, rather than [player_name] himself. Does that make sense?"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:89
translate chinese LiR2_MS1_d86b2bc8:

    # Yazmin "Hmm, I don’t think I’m following you. You got turned on when he grabbed my throat and started fucking me, right?"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:91
translate chinese LiR2_MS1_0d6975cc:

    # Liza "Yeah! It wasn’t his dick that was making me wet though. It was the fact I was just watching it happen right in front of me. He had his hand round your throat, his meat thrusting into your pussy."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:93
translate chinese LiR2_MS1_3565dbac:

    # Liza "And there was absolutely nothing I could do to stop it. I felt... helpless?"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:97
translate chinese LiR2_MS1_3ae5973f:

    # Yazmin "Helpless, huh? So, it’s the thought of a man fucking me while you can’t stop it that turns you on."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:99
translate chinese LiR2_MS1_e754cbc5:

    # Liza "Yeah, I guess so. I didn’t realise it before you brought [player_name] into our bedroom."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:101
translate chinese LiR2_MS1_c4b0066c:

    # Yazmin "Hmm, I can work with that."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:105
translate chinese LiR2_MS1_7aad3cd4:

    # Liza "Hold on, what do you mean by “I can work with that”?"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:107
translate chinese LiR2_MS1_caab19e4:

    # Yazmin "Oh, I was just telling you what I was planning to do. You’re the one who wanted me to be open and honest. Healthy boundaries in a relationship and all that."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:109
translate chinese LiR2_MS1_03e545f2:

    # Liza "What’s going on, Yazmin?"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:113
translate chinese LiR2_MS1_cb23c6fc:

    # Yazmin "Well, since you enjoyed seeing me get violated in front of you, I was planning to recreate a similar scenario."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:115
translate chinese LiR2_MS1_d4b95a6d:

    # Liza "Go on..."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:117
translate chinese LiR2_MS1_2cd5afe2:

    # Yazmin "I’m still working out the finer details in my head, but I’m thinking about setting up a little game for you and me to play."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:119
translate chinese LiR2_MS1_b88ba120:

    # Yazmin "If you win, I’ll treat you to whatever you want."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:121
translate chinese LiR2_MS1_766e89e2:

    # Liza "Venice. I want to go to Venice with you."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:123
translate chinese LiR2_MS1_b6adc1c2:

    # Yazmin "Very well, if you win, I’ll take you to Venice. If you lose though..."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:127
translate chinese LiR2_MS1_26ea24fe:

    # Yazmin "...you’re going to have to watch me get fucked right in front of you."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:129
translate chinese LiR2_MS1_d27bcb18:

    # Yazmin "You’re going to be completely powerless to stop while it happens. You’ll be stuck watching as a thick cock destroys your wife’s pussy before your eyes."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:131
translate chinese LiR2_MS1_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:135
translate chinese LiR2_MS1_a05a702c:

    # MC "(I like where this is going! I bet Yazmin’s going to get in touch with me again soon. I don’t think she’d risk trying this out with another man.)"
    MC ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:139
translate chinese LiR2_MS1_fc989c4b:

    # Yazmin "Well, Liza? What do you say? Can I start making plans?"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:141
translate chinese LiR2_MS1_f28bde99:

    # Liza "Absolutely. That sounds... *Gulp* ...thrilling."
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:145
translate chinese LiR2_MS1_e3968a6a:

    # Yazmin "Alright, just sit tight and leave the planning to me."
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:147
translate chinese LiR2_MS1_27e2be81:

    # Liza "When are we doing it? What’s the game going to be?"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:149
translate chinese LiR2_MS1_ec693c7d:

    # Yazmin "Oh, come on, Liza. You have to leave me some surprises to drop, on the day!"
    Yazmin ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:151
translate chinese LiR2_MS1_5882377c:

    # Liza "Haha, fine!"
    Liza ""

# game/scripts/Li_R2/1_Li_R2_MS1.rpy:155
translate chinese LiR2_MS1_3538fdf2:

    # MC "(I should keep an eye on my phone. I reckon Yazmin is going to be getting in touch with me VERY soon!)"
    MC ""

