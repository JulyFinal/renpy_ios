﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Li_R2/LiR2_MS4.rpy:55
translate chinese LiR2_MS4_79d44bfb:

    # MC "(Gotta say, I wasn’t expecting to hear from Yazmin again, so soon.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:57
translate chinese LiR2_MS4_5b3347be:

    # MC "(Oh wow! Yazmin wasn’t lying! Liza is completely naked right now!)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:58
translate chinese LiR2_MS4_a9249eca:

    # MC "(That ass is fucking perfect! And just look at how shiny her body is! She must have spread tanning oil over herself.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:60
translate chinese LiR2_MS4_cc843430:

    # MC "(I wonder if Yazmin told her I was coming over. Probably not. It’s Yazmin’s modus operandi to just drop Liza in the deep end, without any warning.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:61
translate chinese LiR2_MS4_6b5df543:

    # MC "(God damn... She’s so fucking hot!)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:63
translate chinese LiR2_MS4_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:64
translate chinese LiR2_MS4_70ff29ee:

    # MC "(I’m going to have so much fun with you today!)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:66
translate chinese LiR2_MS4_0f1eac51:

    # MC "Hey there, Liza."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:67
translate chinese LiR2_MS4_e18c8618:

    # Liza "Huh?!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:69
translate chinese LiR2_MS4_d76f548d:

    # Liza "Oh my God! [player_name]! You scared the crap out of me!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:70
translate chinese LiR2_MS4_3f1e3019:

    # Liza "*Gasp* I’m not dressed, hold on!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:72
translate chinese LiR2_MS4_b9691860:

    # MC "Oh please, it’s nothing I haven’t seen before, Liza."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:73
translate chinese LiR2_MS4_88322d51:

    # MC "Besides, you look incredible. You’ve got nothing to be embarrassed about!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:77
translate chinese LiR2_MS4_9f224477:

    # Liza "I... *Gulp* I didn’t know you were coming over today, or I would have worn a bikini!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:78
translate chinese LiR2_MS4_7eea5beb:

    # MC "You won’t be needing a bikini for what we’re about to do."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:79
translate chinese LiR2_MS4_7f6d136c:

    # Liza "Huh?"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:80
translate chinese LiR2_MS4_4a3151d8:

    # MC "I’m going to fuck you, Liza."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:81
translate chinese LiR2_MS4_cd814ba8:

    # Liza "*Gasp* I-"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:84
translate chinese LiR2_MS4_28be677a:

    # MC "Don’t worry, you won’t have to move a muscle. You’re just going to lie, nice and still, while I pound your pussy."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:85
translate chinese LiR2_MS4_c23164ec:

    # MC "Yazmin suggested that you may be interested in being a freeuse fucktoy."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:86
translate chinese LiR2_MS4_c350b718:

    # Liza "..."
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:87
translate chinese LiR2_MS4_dabf067e:

    # MC "Your silence speaks volumes."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:89
translate chinese LiR2_MS4_adaf7f58:

    # MC "I’m going to fuck you, Liza. I’m going to fuck you, wherever, and whenever I want."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:90
translate chinese LiR2_MS4_e1281895:

    # Liza "*Gasp*"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:91
translate chinese LiR2_MS4_0a9cb776:

    # MC "And you’re going to accept it. Every. Single. Time. If you’re sunbathing? I’ll fuck you. If you’re having a shower? I’ll come in and screw you, up against the tiled wall."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:92
translate chinese LiR2_MS4_86b576ec:

    # Liza "Oh my..."
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:94
translate chinese LiR2_MS4_35a8e0ae:

    # Liza "AHHH!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:95
translate chinese LiR2_MS4_9545d8ce:

    # MC "Hnnng! God, you’re tight!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:97
translate chinese LiR2_MS4_eebb0684:

    # MC "Mmm! I’m going to enjoy using your body, every single day. Over and over."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:99
translate chinese LiR2_MS4_de0dbc53:

    # Liza "Ah! *Pant* Oh! Ah!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:100
translate chinese LiR2_MS4_1a22ba9f:

    # MC "Yazmin already helped you realise your secret love for cock. You’re going to enjoy it, more and more, each time I fuck you."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:102
translate chinese LiR2_MS4_d895f186:

    # Liza "Ayaaahhhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:103
translate chinese LiR2_MS4_6ca71ad5:

    # MC "Hnngg!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:104
translate chinese LiR2_MS4_1b8143a9:

    # Liza "*Pant* F-Fuck me! Ohhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:106
translate chinese LiR2_MS4_cf6c737f:

    # MC "Tell me that you love being fucked by my cock."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:107
translate chinese LiR2_MS4_72aae977:

    # Liza "*Gasp* I love ah... I love being fucked by your big dick! Ah!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:109
translate chinese LiR2_MS4_106f9f21:

    # MC "Hnnngg! Arrghh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:110
translate chinese LiR2_MS4_c1dc9262:

    # Liza "AH! AHHHH!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:112
translate chinese LiR2_MS4_774d1c65:

    # Liza "AAHHH! OH GOD! OHHHHH!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:113
translate chinese LiR2_MS4_a9cf5242:

    # MC "Your bisexual pussy, loves a big hard dick now, doesn’t it?"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:114
translate chinese LiR2_MS4_963d0b4d:

    # Liza "AH! AHH! Y-YESSSS! OHHHH!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:116
translate chinese LiR2_MS4_8807b36e:

    # MC "Tell me that you’re going to be my freeuse fucktoy."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:117
translate chinese LiR2_MS4_aadb0d04:

    # Liza "Ahhh! HAAAHHHH! I’ll be yoooohhhurrr freeuse fucktoooohhhyyyy! Aaahhhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:119
translate chinese LiR2_MS4_acc7efbc:

    # Liza "Oh God! I’m cumming! I’m cummmmiiinng! AYAAHHHHHHH!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:121
translate chinese LiR2_MS4_0914bf97:

    # MC "Hnnng! Arrghh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:122
translate chinese LiR2_MS4_d895f186_1:

    # Liza "Ayaaahhhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:124
translate chinese LiR2_MS4_8710a162:

    # Liza "*Gasp* It’s shooooooo intenshhee! Aaahhhhhhhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:125
translate chinese LiR2_MS4_d9c6e33c:

    # MC "HNNGG! UGH!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:127
translate chinese LiR2_MS4_7b24f886:

    # MC "Ugh! Arghh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:128
translate chinese LiR2_MS4_fea41191:

    # Liza "AH! AH! AHHHHH!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:130
translate chinese LiR2_MS4_f50191c8:

    # Liza "(Shit! The neighbours are gonna hear me! I can’t contain my voice, though!)"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:132
translate chinese LiR2_MS4_93ab471d:

    # MC "Hnnnng! Ugh! You’re soaking wet, right now, Liza? Your slutty pussy can’t handle my big cock, can it?"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:134
translate chinese LiR2_MS4_1b8143a9_1:

    # Liza "*Pant* F-Fuck me! Ohhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:136
translate chinese LiR2_MS4_45146a9b:

    # Liza "Ayaahhhh! Oooohhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:138
translate chinese LiR2_MS4_0e9b5f56:

    # MC "Say it. Say that your slutty pussy can’t handle my big dick."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:139
translate chinese LiR2_MS4_108eac12:

    # Liza "My slutty aahhh... p-pussy can’t haaahhhhndle your big cooohhhhhck! AHHHHH!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:141
translate chinese LiR2_MS4_0b003fb5:

    # Liza "AH! AHAHHHHHHHH!! OHHHH MY GODDDD!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:143
translate chinese LiR2_MS4_7a5200a2:

    # Liza "I’M CUMMMMIIINNNG!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:145
translate chinese LiR2_MS4_c53418e6:

    # MC "*Pant* Hnnngg!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:147
translate chinese LiR2_MS4_107a1479:

    # MC "(I’m getting close... Should I pull out and cum over her ass? Or fill up her pussy with a hot creampie?)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:151
translate chinese LiR2_MS4_e883d76d:

    # MC "Get ready, Liza. I’m going to finish inside you!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:153
translate chinese LiR2_MS4_c1834eef:

    # Liza "*Pant* Y-Yes, fill me up!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:155
translate chinese LiR2_MS4_fc5b5045:

    # Liza "AYAAAHHHHHHH!!!! I’M CUMMMIINNNNG!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:156
translate chinese LiR2_MS4_2871be5d:

    # MC "HNNNGG!!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:158
translate chinese LiR2_MS4_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:167
translate chinese LiR2_MS4_62ca7dbb:

    # Liza "OH GOD! OH GOD! OH MY GOD! YESSSSS!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:168
translate chinese LiR2_MS4_6e761352:

    # MC "ARRGHHH!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:169
translate chinese LiR2_MS4_6b5565cf:

    # Liza "AYAAHHHHHH!! OOHHHHH!!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:174
translate chinese LiR2_MS4_9597cf97:

    # MC "*Pant* I’m gonna finish over your ass!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:176
translate chinese LiR2_MS4_f0aff58e:

    # Liza "*Pant* *Pant*"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:178
translate chinese LiR2_MS4_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:188
translate chinese LiR2_MS4_fa8e01f4:

    # MC "Hnnng! Oh! Fuck! Mmmm!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:189
translate chinese LiR2_MS4_94e1cdb4:

    # Liza "Ooohhh..."
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:196
translate chinese LiR2_MS4_end_e0713339:

    # MC "That was amazing, Liza. I’ll catch you again later."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:197
translate chinese LiR2_MS4_end_6dc09644:

    # Liza "*Pant* S-See you l-later, [player_name]."
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:198
translate chinese LiR2_MS4_end_7850a0be:

    # Liza "(Wow... It felt so good to just be taken and used like that.)"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:245
translate chinese LiR2_MS4_repeat_573b4447:

    # MC "(Looks like she’s still doing her daily sunbathing routine.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:249
translate chinese LiR2_MS4_repeat_92184844:

    # MC "(I’m sure Yazmin won’t mind me having a bit more fun with her wife. If anything, she’s probably watching us right now!)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:253
translate chinese LiR2_MS4_repeat_5b26ac22:

    # MC "(Fuck, she looks amazing.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:257
translate chinese LiR2_MS4_repeat_4edafa95:

    # MC "Hey Liza, guess who’s back?"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:261
translate chinese LiR2_MS4_repeat_e5395a12:

    # Liza "[player_name]?! What are you-"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:265
translate chinese LiR2_MS4_repeat_b91f2373:

    # MC "Did you really think I was only going to fuck you once on this sunbed?"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:267
translate chinese LiR2_MS4_repeat_7979d492:

    # MC "You’ve had WAY too long without fucking a cock! Someone’s got to help you catch up!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:271
translate chinese LiR2_MS4_repeat_d674285e:

    # Liza "Mmm... (I really shouldn’t without asking Yazmin’s permission first...)"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:278
translate chinese LiR2_MS4_repeat_14239e86:

    # Liza "(It felt so good when it did it last time though...)"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:280
translate chinese LiR2_MS4_repeat_b510746d:

    # Liza "O-Okay... Go ahead."
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:285
translate chinese LiR2_MS4_repeat_e1281895:

    # Liza "*Gasp*"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:287
translate chinese LiR2_MS4_repeat_47359684:

    # MC "That must feel really good! Just wait until I plunge my dick deep inside your soaking wet pussy."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:291
translate chinese LiR2_MS4_repeat_a99e95d7:

    # Liza "Ayaaahhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:295
translate chinese LiR2_MS4_repeat_441efc01:

    # Liza "Oh! Ahh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:299
translate chinese LiR2_MS4_repeat_2677cbb8:

    # MC "Hnnnng!!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:301
translate chinese LiR2_MS4_repeat_576580a5:

    # Liza "AH! OHHH! God! MMMM!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:305
translate chinese LiR2_MS4_repeat_f04c959f:

    # Liza "*GASP* AH! Y-You’re sooo big! AH!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:309
translate chinese LiR2_MS4_repeat_fe3b1d9b:

    # MC "Hnnngg! Arrghhh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:311
translate chinese LiR2_MS4_repeat_30fd5ec4:

    # Liza "Ah! AH! AH! AH! AH!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:316
translate chinese LiR2_MS4_repeat_b2e4bee0:

    # Liza "Ayyyaaaaahhhhhhh!!! OHHHHHHHH!!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:318
translate chinese LiR2_MS4_repeat_f841f5a1:

    # MC "HNNNGG!!! ARRGHHH!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:322
translate chinese LiR2_MS4_repeat_3fbe8043:

    # MC "*Pant* Ugh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:326
translate chinese LiR2_MS4_repeat_2d7cb5e6:

    # Liza "Ahhhhh! Ahhhhhhh! OHHH GOD! I’M CUMMMINNNNNGG!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:329
translate chinese LiR2_MS4_repeat_0914bf97:

    # MC "Hnnng! Arrghh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:330
translate chinese LiR2_MS4_repeat_d895f186:

    # Liza "Ayaaahhhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:332
translate chinese LiR2_MS4_repeat_8710a162:

    # Liza "*Gasp* It’s shooooooo intenshhee! Aaahhhhhhhh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:336
translate chinese LiR2_MS4_repeat_b135c516:

    # Liza "OHHH! AHHHHH! CUMMMMMIIIIINNGGG!!! HAAAAAAHHHH!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:340
translate chinese LiR2_MS4_repeat_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:342
translate chinese LiR2_MS4_repeat_93ab471d:

    # MC "Hnnnng! Ugh! You’re soaking wet, right now, Liza? Your slutty pussy can’t handle my big cock, can it?"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:344
translate chinese LiR2_MS4_repeat_f3227f84:

    # Liza "AH!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:348
translate chinese LiR2_MS4_repeat_d8c4ebc9:

    # Liza "*GASP* Ohhhhh!! Yessss! Don’t stop! AH! AHHHH!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:352
translate chinese LiR2_MS4_repeat_4574afc7:

    # Liza "Ah! Ah! Ah! Ah!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:356
translate chinese LiR2_MS4_repeat_a411506a:

    # Liza "Ayaaaahhhhhhhhhhhhh!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:359
translate chinese LiR2_MS4_repeat_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:361
translate chinese LiR2_MS4_repeat_c53418e6:

    # MC "*Pant* Hnnngg!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:363
translate chinese LiR2_MS4_repeat_441efc01_1:

    # Liza "Oh! Ahh!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:366
translate chinese LiR2_MS4_repeat_099d01a3:

    # Liza "I’m cumming! I’m cumming!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:370
translate chinese LiR2_MS4_repeat_9e86fc3d:

    # Liza "*GASP* OHHHH!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:376
translate chinese LiR2_MS4_repeat_2436b72e:

    # MC "Hnnnnggg! I’m gonna fill you up!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:386
translate chinese LiR2_MS4_repeat_ce552ae7:

    # Liza "AYAAAHHHHH!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:387
translate chinese LiR2_MS4_repeat_cd9d069b:

    # MC "ARRGHHHH!!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:388
translate chinese LiR2_MS4_repeat_0a0ba04c:

    # Liza "OHHHH!!!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:393
translate chinese LiR2_MS4_repeat_6ecbbbc0:

    # MC "I’m gonna cum!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:395
translate chinese LiR2_MS4_repeat_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:405
translate chinese LiR2_MS4_repeat_99f6069f:

    # MC "Ohhh! Fuck... Mmmm!"
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:414
translate chinese LiR2_MS4_repeat_end_638a81e8:

    # MC "Thanks for the fuck today, Liza. I’ll catch you again some other time."
    MC ""

# game/scripts/Li_R2/LiR2_MS4.rpy:416
translate chinese LiR2_MS4_repeat_end_88a87ea4:

    # Liza "*Pant* S-Sure. *Pant*"
    Liza ""

# game/scripts/Li_R2/LiR2_MS4.rpy:418
translate chinese LiR2_MS4_repeat_end_59f7f2d9:

    # Liza "(Wow, my pussy is still throbbing right now!)"
    Liza ""

translate chinese strings:

    # game/scripts/Li_R2/LiR2_MS4.rpy:148
    old "Thrust in deep and creampie her pussy."
    new ""

    # game/scripts/Li_R2/LiR2_MS4.rpy:372
    old "Cum inside Liza’s pussy."
    new ""

    # game/scripts/Li_R2/LiR2_MS4.rpy:372
    old "Pull out and blow a load over Liza’s ass."
    new ""

