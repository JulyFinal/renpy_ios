﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Li_R2/2_LiR2_S2.rpy:181
translate chinese LiR2_S2_step1_e8f7f3a8:

    # Yazmin "Oh, hey there. What’s up?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:183
translate chinese LiR2_S2_step1_12ef325e:

    # MC "Hey Yazmin, I got your text! I ran to the store as fast as I could."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:187
translate chinese LiR2_S2_step1_68100c96:

    # Yazmin "Geez, there was no need to rush!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:189
translate chinese LiR2_S2_step1_a107f279:

    # MC "What? I got excited? So, what did you have in mind? When can we begin?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:193
translate chinese LiR2_S2_step1_968dabc2:

    # Yazmin "Whoa! Calm down there. I’ve still got work I need to finish."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:195
translate chinese LiR2_S2_step1_2a5543c6:

    # Yazmin "Leave the rope with me and come back in the evening."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:199
translate chinese LiR2_S2_step1_a41509aa:

    # MC "Sure, no problem, Yazmin!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:201
translate chinese LiR2_S2_step1_11cdb7b3:

    # MC "You don’t fancy giving me a hint about what you’ve got planned?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:205
translate chinese LiR2_S2_step1_12f12289:

    # Yazmin "Try to have a little bit of patience, [player_name]. You’ll find out what’s going on soon enough."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:207
translate chinese LiR2_S2_step1_ac5a8335:

    # MC "Alright, I’ll see you in the evening."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:231
translate chinese LiR2_S2_step2_a96900ca:

    # Yazmin "I was wondering how long it would take you to show up."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:233
translate chinese LiR2_S2_step2_61d04443:

    # MC "What can I say? I’m a busy man. Places to be, things to do."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:237
translate chinese LiR2_S2_step2_03f188c2:

    # Yazmin "Uh huh. Well, I can see you found what I asked for."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:239
translate chinese LiR2_S2_step2_6cda652c:

    # MC "Oh yeah, the rope!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:243
translate chinese LiR2_S2_step2_41b736b2:

    # MC "What did you have planned for this anyway? Are we gonna be tying Liza up?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:245
translate chinese LiR2_S2_step2_031e3c9e:

    # Yazmin "Patience, [player_name]. All in good time. Here, I’ll take it off you."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:249
translate chinese LiR2_S2_step2_3bab60a9:

    # MC "Not even a little hint?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:251
translate chinese LiR2_S2_step2_18256851:

    # Yazmin "Well, considering that you’re about to find out, it doesn’t make much sense to waste time dropping hints, does it?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:255
translate chinese LiR2_S2_step2_129aa4e1:

    # MC "Liza’s waiting for us?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:257
translate chinese LiR2_S2_step2_d35028c9:

    # Yazmin "Sorta. She doesn’t actually KNOW she’s waiting for us."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:271
translate chinese LiR2_S2_step3_0aac33c6:

    # Yazmin "Evening honey."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:273
translate chinese LiR2_S2_step3_4d76e9d5:

    # Liza "Uh, hey. What’s [player_name] doing here?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:275
translate chinese LiR2_S2_step3_48fc29b7:

    # MC "Hey Auntie Liza!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:277
translate chinese LiR2_S2_step3_3f1ac887:

    # MC "Hey, Liza!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:279
translate chinese LiR2_S2_step3_fe90b7c8:

    # Liza "And why are you carrying a rope?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:283
translate chinese LiR2_S2_step3_535b0589:

    # MC "(I think I’ll just stay quiet and let Yazmin do the talking from this point.)"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:285
translate chinese LiR2_S2_step3_09dcce0d:

    # Liza "Wait a minute! Is this...? Is this the thing we were talking about?!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:287
translate chinese LiR2_S2_step3_5a953696:

    # Liza "You’re- You’re going to tie me up while [player_name] fucks you?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:291
translate chinese LiR2_S2_step3_872fdc88:

    # Yazmin "Bingo! That was a pretty good guess."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:293
translate chinese LiR2_S2_step3_ee8788fb:

    # Yazmin "I haven’t explained the full rules to either of you yet, so I’m going to need you both to listen up and pay attention."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:297
translate chinese LiR2_S2_step3_11d87ff8:

    # Liza "(Yazmin and I only just had our conversation about this fantasy! She must have put some plans into motion immediately after we finished talking!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:299
translate chinese LiR2_S2_step3_72133197:

    # Liza "(I just hope she doesn’t go overboard again like the last threesome we had...)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:303
translate chinese LiR2_S2_step3_884c75ec:

    # Yazmin "So, here’s what’s going to happen. You’re going to sit down in this chair, and I’m going to tie your wrists and ankles to it."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:305
translate chinese LiR2_S2_step3_2ca1edd6:

    # Liza "Alright..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:307
translate chinese LiR2_S2_step3_53f5722c:

    # Yazmin "But, before I do that, I’m going to need you to make a decision. Easy mode or hard mode?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:309
translate chinese LiR2_S2_step3_7d9b94ac:

    # Liza "...what’s the difference?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:311
translate chinese LiR2_S2_step3_458ce7de:

    # Yazmin "If you win easy mode, we’re going to Venice. If you win hard mode, I’m taking us to Venice AND we’re flying first class."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:313
translate chinese LiR2_S2_step3_afcaf312:

    # Liza "First class?! Absolutely!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:315
translate chinese LiR2_S2_step3_79e1fbeb:

    # Yazmin "Well, what are you waiting for, then? Come and take a seat."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:322
translate chinese LiR2_S2_step3_86953eb1:

    # MC "(I don’t think Liza was expecting this today! She isn’t wearing any panties under her dress!)"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:324
translate chinese LiR2_S2_step3_d0597c95:

    # Yazmin "And there we go. That’s the last one secured."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:326
translate chinese LiR2_S2_step3_82e4cb72:

    # Liza "So, what happens next?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:330
translate chinese LiR2_S2_step3_489f7323:

    # Yazmin "The next step is that you’re going to have to try and break free of these restraints. You win, if you break free and touch either me or [player_name]."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:332
translate chinese LiR2_S2_step3_dcd8e2dd:

    # Yazmin "If you manage to do that, we’re on a trip to Venice."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:336
translate chinese LiR2_S2_step3_1cc5cc15:

    # Liza "Heh, that sounds easy enough. I think you’re forgetting that self-defence class we both took. Remember how quickly I broke out of the restraints?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:338
translate chinese LiR2_S2_step3_2c3f67b5:

    # Yazmin "That was years ago, Darling. I doubt you remember HALF of what you learned on that course."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:340
translate chinese LiR2_S2_step3_a7b41386:

    # Liza "We’ll see. So, that’s it, then? I just have to break out of these restraints and touch either of you?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:344
translate chinese LiR2_S2_step3_72135d90:

    # Yazmin "I may have forgotten to mention one tiny detail. For every two minutes that pass by without you escaping, [player_name] will get to do something to me."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:347
translate chinese LiR2_S2_step3_abd6df6d:

    # Yazmin "It’ll start off pretty vanilla, but things will slowly begin to heat up if you can’t break out of those restraints."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:349
translate chinese LiR2_S2_step3_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:353
translate chinese LiR2_S2_step3_fb0c22fa:

    # Liza "Do you mean that he’s going to...?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:355
translate chinese LiR2_S2_step3_78f7d598:

    # Yazmin "That’s right, Liza. If you can’t break free you’re going to have to watch your wife slowly stolen away from you by a man with a big, fat cock."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:357
translate chinese LiR2_S2_step3_a6e60808:

    # Yazmin "And it’s only going to get worse, the longer it takes you to escape."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:359
translate chinese LiR2_S2_step3_1aa95d8c:

    # Yazmin "I’ve set my phone to beep every couple of minutes. Each time it goes off, things are going to get a little more intense."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:361
translate chinese LiR2_S2_step3_5f238525_1:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:363
translate chinese LiR2_S2_step3_ae76abc1:

    # Yazmin "But, let’s start off with something tame. C’mon over here, [player_name]."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:367
translate chinese LiR2_S2_step3_6a726f9f:

    # Yazmin "And... the game has begun."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:369
translate chinese LiR2_S2_step3_c43a66b1:

    # Liza "Ugh! Aarrgh..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:371
translate chinese LiR2_S2_step3_f21e3693:

    # Liza "(Flip me! Yazmin’s really tied these ropes pretty tight! No matter! I just have to get them loosened up by wiggling around.)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:373
translate chinese LiR2_S2_step3_093ed6f0:

    # Yazmin "How are you holding up, Honey?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:377
translate chinese LiR2_S2_step3_3059d357:

    # Liza "Ughh... absolutely fine!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:379
translate chinese LiR2_S2_step3_9bd727aa:

    # Yazmin "It must be absolute torment to watch his hands squeezing my ass like this. Tell her how it feels, [player_name]."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:381
translate chinese LiR2_S2_step3_6c25f2a1:

    # MC "Your wife’s ass is REALLY firm, Liza! God, I love squeezing it."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:385
translate chinese LiR2_S2_step3_ae61c9db:

    # Liza "Hnnngg... Ugh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:387
translate chinese LiR2_S2_step3_047f2f06:

    # Liza "(C’mon! The ropes around my ankles are just as tight as my wrists! How am I even supposed to begin getting out of this?!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:389
translate chinese LiR2_S2_step3_1dd82ca9:

    # Liza "(How long has passed? Yazmin said she set a two minute timer, but I haven’t heard a beep yet.)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:393
translate chinese LiR2_S2_step3_b937197c:

    # Liza "(She said it was going to escalate slowly. So even if I don’t escape when the first alarm sounds, I should still have a few more chances before he does anything really intense to her... right?)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:395
translate chinese LiR2_S2_step3_55a3b95f:

    # Yazmin "Mmm, are you getting wet there, Darling?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:397
translate chinese LiR2_S2_step3_7213b4ba:

    # Liza "What? No!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:399
translate chinese LiR2_S2_step3_c63e4c83:

    # Yazmin "Your clit looks all swollen. I think she’s getting excited by this."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:401
translate chinese LiR2_S2_step3_7091804f:

    # Liza "Absolutely not! Argh! I’m going to break out of these VERY-"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:403
translate chinese LiR2_S2_step3_f4b92fac:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:407
translate chinese LiR2_S2_step3_7e223675:

    # Liza "(Oh no! That’s two minutes gone already?!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:409
translate chinese LiR2_S2_step3_5fcdb04a:

    # Yazmin "And there’s the alarm. [player_name], would you be a darling and strip my top off for Liza?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:411
translate chinese LiR2_S2_step3_66c0595e:

    # MC "Sure!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:415
translate chinese LiR2_S2_step3_cacd8030:

    # Yazmin "Make sure to do it nice and slowly. I want to watch her squirm as she slowly realises her wife’s naked body is going on display."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:417
translate chinese LiR2_S2_step3_d3289a00:

    # Liza "*Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:419
translate chinese LiR2_S2_step3_4eaab137:

    # Yazmin "What’s wrong, Honey? Are you panting because you’re tired from struggling against those restraints?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:423
translate chinese LiR2_S2_step3_df83f1dd:

    # Yazmin "Or is it because you’re SOOO hot and bothered from seeing your wife groped in front of you?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:425
translate chinese LiR2_S2_step3_01e1c3bd:

    # Yazmin "Mmm! It feels soooo good to have some manly hands squeeze my breasts for a change. You feel sooo much better than my wife."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:427
translate chinese LiR2_S2_step3_df67cebf:

    # Liza "(Oh crap... I got distracted by them, and forgot to struggle!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:431
translate chinese LiR2_S2_step3_49039c94:

    # Liza "Argh! C’mon! Hnnngg!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:433
translate chinese LiR2_S2_step3_5c1b58d3:

    # Yazmin "Are you enjoying my tits, [player_name]?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:435
translate chinese LiR2_S2_step3_a55f294b:

    # MC "They’re amazing, Yazmin!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:439
translate chinese LiR2_S2_step3_5a34e571:

    # Liza "What have you done to these ropes?! They’re not budging an inch!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:441
translate chinese LiR2_S2_step3_8bad75e0:

    # Yazmin "Ahmmmm! Oh, yeah, I may have tied a different knot, to the one you broke out of in the self-defence class."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:443
translate chinese LiR2_S2_step3_bc7b02a8:

    # Liza "Oooh! You sneaky bitch!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:445
translate chinese LiR2_S2_step3_822e0980:

    # Yazmin "I didn’t want the fun to end TOO early, Darling."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:447
translate chinese LiR2_S2_step3_58b1d977:

    # Liza "Hnnnng! *Pant* Arrghh! *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:449
translate chinese LiR2_S2_step3_f4b92fac_1:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:453
translate chinese LiR2_S2_step3_fed5636a:

    # Liza "No!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:455
translate chinese LiR2_S2_step3_b0aed69a:

    # Yazmin "Well, that’s another two minutes up. How about you finish stripping off my clothes, [player_name]?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:459
translate chinese LiR2_S2_step3_7adb2f03:

    # Liza "Argh! *Pant* Uggghhh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:461
translate chinese LiR2_S2_step3_3f995af5:

    # Yazmin "This must be torture for you, Liza. It must be soooo difficult seeing your wife stripped naked by a man, in front of you."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:463
translate chinese LiR2_S2_step3_6b18dcca:

    # Yazmin "You can end this though. All you have to do is break free and touch either one of us."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:467
translate chinese LiR2_S2_step3_3e15787a:

    # Liza "That’s what I’m TRYING to do!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:469
translate chinese LiR2_S2_step3_fd7a9d63:

    # MC "(It’s really hot watching Yazmin taunt my aunt like this! I wonder what she’s going to let me do to her at the next alarm.)"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:471
translate chinese LiR2_S2_step3_98152f7d:

    # MC "(It’s really hot watching Yazmin taunt her wife like this! I wonder what she’s going to let me do to her at the next alarm.)"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:475
translate chinese LiR2_S2_step3_b0f7778b:

    # Yazmin "You were too slow, Honey. My jeans are around my ankles now. This man behind me is staring at my bare ass."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:477
translate chinese LiR2_S2_step3_80d313eb:

    # Liza "Hnnng..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:479
translate chinese LiR2_S2_step3_d36e959f:

    # Yazmin "How does that make you feel, Dear?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:483
translate chinese LiR2_S2_step3_6dd188bd:

    # Liza "*Pant* You tied the *Pant* ropes waaaay too tight! I can’t- *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:485
translate chinese LiR2_S2_step3_2ac65148:

    # Yazmin "I’m already naked, Liza. If you can’t manage to escape within the next two minutes, just imagine what [player_name] is going to do to your wife’s body."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:489
translate chinese LiR2_S2_step3_41b89266:

    # Liza "Arrrghh! HHNNNNNG!! *Pant* *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:491
translate chinese LiR2_S2_step3_db41d3a0:

    # Yazmin "Tick tock, Darling. Time’s running out."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:493
translate chinese LiR2_S2_step3_d7a3ed34:

    # Liza "(Shit, shit, shit! C’mon!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:495
translate chinese LiR2_S2_step3_f4b92fac_2:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:499
translate chinese LiR2_S2_step3_e5920069:

    # Yazmin "Uh oh. Looks like you ran out of time again."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:501
translate chinese LiR2_S2_step3_72433f87:

    # Liza "*Gulp* Wh-What happens now?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:503
translate chinese LiR2_S2_step3_766c120f:

    # Yazmin "Well, I’m already naked, so you’re going to have to watch me undress [player_name] instead."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:507
translate chinese LiR2_S2_step3_bdef6a11:

    # Liza "Ahnnngggg! Arrghh! *Pant* Hnnng!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:509
translate chinese LiR2_S2_step3_ae1f7ed1:

    # Yazmin "How do you think I’m going to react when I see his cock, Liza? Are you worried that I’m going to get turned on when I see him with something that you don’t have?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:511
translate chinese LiR2_S2_step3_2bd78c08:

    # Liza "*Gulp* (Come on! What is with these stupid restraints?!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:515
translate chinese LiR2_S2_step3_1ab32e05:

    # Yazmin "If you want this to end, Dear, then all you have to do is reach out and touch us. It’s that simple, Darling."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:517
translate chinese LiR2_S2_step3_f0aff58e:

    # Liza "*Pant* *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:519
translate chinese LiR2_S2_step3_e824045e:

    # MC "I don’t think she’s breaking out of those ropes anytime soon, Yazmin. Go ahead and take my trousers off."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:521
translate chinese LiR2_S2_step3_2fbe31ce:

    # Yazmin "Alright, let’s see what you’re hiding under here."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:525
translate chinese LiR2_S2_step3_e1281895:

    # Liza "*Gasp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:528
translate chinese LiR2_S2_step3_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:532
translate chinese LiR2_S2_step3_c5277e3b:

    # Yazmin "My, my, my! Aren’t you a hard boy?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:534
translate chinese LiR2_S2_step3_093a19a5:

    # Liza "Hnnng! C’mon! Arrghh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:538
translate chinese LiR2_S2_step3_ad79a012:

    # Yazmin "Just look at the size of this cock, Darling! He’s massive, isn’t he?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:540
translate chinese LiR2_S2_step3_0946d244:

    # Liza "HNNNGGG! Ugh! *Pant* Hnnngg!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:542
translate chinese LiR2_S2_step3_fb2afef3:

    # Yazmin "That’s it. Keep struggling, Dear. "
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:546
translate chinese LiR2_S2_step3_6e3c3aec:

    # Yazmin "I think my lovely wife has finally realised that your massive manly dick could very easily be destroying my pussy if she can’t escape."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:548
translate chinese LiR2_S2_step3_67681034:

    # Liza "(I think the rope around my right wrist is beginning to loosen! I can still do this!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:552
translate chinese LiR2_S2_step3_fc3d5325:

    # Yazmin "Your two minutes are almost up again. Tell me, Dear, what do you think is going to happen next?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:554
translate chinese LiR2_S2_step3_2ede1de8:

    # Liza "... *Pant* ..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:556
translate chinese LiR2_S2_step3_c2b9ec08:

    # Yazmin "Oh, go on, humour me."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:558
translate chinese LiR2_S2_step3_0015445c:

    # Liza "You’re going to put a *Pant* condom on him?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:560
translate chinese LiR2_S2_step3_cd940e78:

    # Yazmin "Ahaha! That’s adorable. Remember I asked you if you wanted to play easy mode or hard mode?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:564
translate chinese LiR2_S2_step3_569d1d3b:

    # Yazmin "Hard mode means no protection."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:566
translate chinese LiR2_S2_step3_a7a48428:

    # Liza "*Gulp* No way..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:568
translate chinese LiR2_S2_step3_a406393a:

    # Liza "(I should have clarified the difference with Yazmin when she first asked me! I got distracted by her promising to fly me in first class!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:572
translate chinese LiR2_S2_step3_bf79750b:

    # Yazmin "That’s right, Darling. No condom, no birth control, no spermicidal lube."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:574
translate chinese LiR2_S2_step3_e4d49174:

    # Yazmin "You’re going to have to watch me play with his naked cock right in front of you. Skin against skin. How do you think his big dick is going to make me feel Liza?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:578
translate chinese LiR2_S2_step3_712cca91:

    # Liza "Hnnnngg! *Pant* Argh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:580
translate chinese LiR2_S2_step3_40305567:

    # Yazmin "Are you ever going to pleasure me the way that his thick manly dick can?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:582
translate chinese LiR2_S2_step3_616c81f0:

    # Liza "AARRGHHH! HNNNNNGG!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:584
translate chinese LiR2_S2_step3_bee7b765:

    # Yazmin "That’s it, Dear! Keep struggling."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:586
translate chinese LiR2_S2_step3_f4b92fac_3:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:588
translate chinese LiR2_S2_step3_67b6ec56:

    # Liza "*Pant* *Pant* No!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:590
translate chinese LiR2_S2_step3_f7acc876:

    # Yazmin "Time up! Let’s reset the clock and escalate things again."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:594
translate chinese LiR2_S2_step3_c77a52eb:

    # Yazmin "I think I’ll start giving [player_name] a handjob next. You ought to enjoy watching your wife stroke a cock, right in front of you."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:596
translate chinese LiR2_S2_step3_4ad5c96f:

    # Liza "Yazmin, please! This isn’t fair! You tied these *Pant* ropes waaaay too tight!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:598
translate chinese LiR2_S2_step3_c2f08897:

    # MC "Hnnng... Ohh..."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:602
translate chinese LiR2_S2_step3_877d7506:

    # Yazmin "How does it feel? Are you enjoying it when I use both hands?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:604
translate chinese LiR2_S2_step3_8dd02012:

    # MC "Mmm! It’s amazing, Yazmin."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:606
translate chinese LiR2_S2_step3_e055ab5b:

    # Yazmin "Good. I want you nice and hard for what comes next. The clock is still ticking, Darling. How are those ropes looking?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:608
translate chinese LiR2_S2_step3_370d2e0f:

    # Liza "Argh! *Pant* Hnnng!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:610
translate chinese LiR2_S2_step3_9e95ab0c:

    # Liza "(I know we talked about this... but I still can’t believe how much she’s actually taunting me.)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:614
translate chinese LiR2_S2_step3_ea8cd5e2:

    # Yazmin "I was a bit worried about adding too many stages to this little game when I designed it. I figured that my wife would probably escape before we ever made it to the fun parts."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:616
translate chinese LiR2_S2_step3_8aa4d530:

    # Yazmin "However, I’m beginning to think I greatly overestimated her strength."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:618
translate chinese LiR2_S2_step3_53ab5567:

    # Liza "*Pant* *Pant* Yazmin, just give me a little more time to-"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:620
translate chinese LiR2_S2_step3_0252a89f:

    # Yazmin "Either that, or she doesn’t want to break free because she’s actually enjoying watching this happen."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:622
translate chinese LiR2_S2_step3_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:626
translate chinese LiR2_S2_step3_30d83fbc:

    # MC "*Pant* Mmmm!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:628
translate chinese LiR2_S2_step3_8df5286e:

    # Yazmin "I forgot how much fun it was playing with a cock. You really start to miss them, Liza!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:630
translate chinese LiR2_S2_step3_473e9b49:

    # Liza "Argh! C’mon! Hnnnngggg! Aaahhhhh! *Pant* *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:632
translate chinese LiR2_S2_step3_224a2527:

    # Yazmin "The feeling of them throbbing beneath your fingers, the glistening glans wet with precum, the anticipation of it erupting with a salty treat. Mmm..."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:636
translate chinese LiR2_S2_step3_defa821c:

    # Yazmin "And yours is the PERFECT size. I love it when I need two hands to properly hold a shaft."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:638
translate chinese LiR2_S2_step3_f0aff58e_1:

    # Liza "*Pant* *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:640
translate chinese LiR2_S2_step3_232b974c:

    # Yazmin "Whenever that timer beeps again I’m going to take your fat cock in my mouth and start sucking on it."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:642
translate chinese LiR2_S2_step3_0ebc94fa:

    # Liza "*Pant* No... *Pant* Please..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:646
translate chinese LiR2_S2_step3_9578cf00:

    # Yazmin "I want you to taunt my wife for me while I suck your cock. No matter how much Liza begs or pleads, keep going. She knows that there’s only one way to stop this - she has to break free."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:648
translate chinese LiR2_S2_step3_2934134c:

    # Liza "(My pussy is soaking wet now... Yazmin always knew how to use her cruel streak to turn me on.)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:650
translate chinese LiR2_S2_step3_f4b92fac_4:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:652
translate chinese LiR2_S2_step3_238931ea:

    # Yazmin "You were too slow, Honey. Now you’re going to have to watch your wife suck on this dick."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:654
translate chinese LiR2_S2_step3_feb0a2d4:

    # Yazmin "I want Liza to know what’s coming. The next time you hear the alarm, [player_name], you’re going to pin me against the bed and facefuck me as hard as you can."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:656
translate chinese LiR2_S2_step3_9a567c09:

    # MC "Got it, Yazmin."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:658
translate chinese LiR2_S2_step3_00110f14:

    # Yazmin "You’ve got two minutes on the clock to break free and stop your wife having her throat fucked, Liza. Let’s see if you’ve got it in you."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:662
translate chinese LiR2_S2_step3_336a1f23:

    # Yazmin "*Shlurp* *Suck*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:664
translate chinese LiR2_S2_step3_66bf8cf6:

    # Liza "NO! Hnnnngg! Arrghhh! ARRGHHH!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:666
translate chinese LiR2_S2_step3_8deaa16a:

    # MC "Mmmm! Your wife’s mouth feels SOOOO good, Liza."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:670
translate chinese LiR2_S2_step3_8667efb5:

    # Liza "Yazmin... *Gulp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:672
translate chinese LiR2_S2_step3_ba1ee50d:

    # Yazmin "*Shlurp* *Suck* *Suuuuuck* *Shlurp*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:674
translate chinese LiR2_S2_step3_d4bfeb2d:

    # MC "Hnnngg! Ooohhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:678
translate chinese LiR2_S2_step3_dcc28f51:

    # MC "She’s really good with her tongue! It must be all that practice from eating your pussy. Mmmm!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:680
translate chinese LiR2_S2_step3_d901b788:

    # Yazmin " *Suuuuck* *Shlurp* *SHLUUUURRRP*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:682
translate chinese LiR2_S2_step3_ff7a1425:

    # Liza "Argh! *Pant* Hnnnng! Aahhhhh! *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:684
translate chinese LiR2_S2_step3_c077a668:

    # MC "You can kick and scream all you want, Liza, but in about sixty seconds I’m going to be ramming my dick down your wife’s throat."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:688
translate chinese LiR2_S2_step3_37484dcc:

    # Yazmin "*SHLURP* *SUCK*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:690
translate chinese LiR2_S2_step3_c6b9b362:

    # MC "Ahnnngg! Mmm!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:692
translate chinese LiR2_S2_step3_bb4bdef6:

    # Liza "Ugghh! *Pant*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:694
translate chinese LiR2_S2_step3_80d0f3b7:

    # Liza "(The ropes are barely budging!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:698
translate chinese LiR2_S2_step3_89be2fc6:

    # Yazmin "*Shluuuurrrp* *Suck* *Suck*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:700
translate chinese LiR2_S2_step3_341effd2:

    # MC "Mmmmm! God, your wife is an incredible cocksucker, Liza. It seems like she’s really enjoying this too."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:702
translate chinese LiR2_S2_step3_4fbd47db:

    # Liza "*Pant* Arrghh! *Pant* Shut up, [player_name]!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:706
translate chinese LiR2_S2_step3_33b0ad43:

    # Yazmin "*Shlurp* *Suck* *Suck* *Shluuurrp*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:708
translate chinese LiR2_S2_step3_ec8e4094:

    # MC "I don’t mmm... know if she’s even going to WANT to go back to licking your pussy now that she’s had this. Hnnng! I bet she’s gonna keep coming back to me instead."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:710
translate chinese LiR2_S2_step3_8228ca4f:

    # Liza "*Gulp* Sh-She wouldn’t do that..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:714
translate chinese LiR2_S2_step3_dceca8b1:

    # Yazmin "*GLOMPF* *GAG*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:716
translate chinese LiR2_S2_step3_5b97b327:

    # MC "HNNNGG!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:718
translate chinese LiR2_S2_step3_a56b2b5e:

    # Yazmin "*SHLURP* *SUCK* *SUUUUUCK*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:720
translate chinese LiR2_S2_step3_986f1217:

    # MC "Ohhhh! Are you so sure about that? Mmmm! It seems like she’s REALLY into sucking dick right now?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:724
translate chinese LiR2_S2_step3_0f538468:

    # MC "Hnnnng! Ohhh! Speaking of which, you’re running out of time. Any second now that ugh... alarm is going to go off and I’ll be hnnng... fucking your wife’s face."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:726
translate chinese LiR2_S2_step3_98e14c68:

    # Liza "*Pant* *Pant* Ahhhhnnnnggg! Hnnnnnnggg!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:728
translate chinese LiR2_S2_step3_458c0311:

    # Yazmin "*Suck* *Suck* *SUUUUCCCK*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:732
translate chinese LiR2_S2_step3_f4b92fac_5:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:734
translate chinese LiR2_S2_step3_911d2aa3:

    # Liza "Nooooo! Aaahhh! Hnnnng! *Pant* Crap!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:736
translate chinese LiR2_S2_step3_3b7b19b9:

    # MC "Time to ruin your pretty wife’s throat. I think I’m going to face away from you while I fuck her. I want you to watch how wet her pussy gets when a dick is plunging into her wet mouth."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:738
translate chinese LiR2_S2_step3_c3e3563f:

    # Liza "*Pant* Yazmin..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:742
translate chinese LiR2_S2_step3_6edcf1f2:

    # Yazmin "Mpfff!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:744
translate chinese LiR2_S2_step3_49cae69a:

    # MC "Hnnnngg!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:746
translate chinese LiR2_S2_step3_7c24196c:

    # Liza "Aaarrghhh! Nooooo!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:750
translate chinese LiR2_S2_step3_514afaff:

    # "*Shlick* *Shlick*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:752
translate chinese LiR2_S2_step3_a6534700:

    # MC "Oohhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:754
translate chinese LiR2_S2_step3_2466cacf:

    # Yazmin "*Shlurp* *Gag* *Shlurp*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:758
translate chinese LiR2_S2_step3_5316fadd:

    # Liza "*Pant* Hnnnnnngg! Gah!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:760
translate chinese LiR2_S2_step3_5d5f4ffe:

    # Liza "(I feel so useless! He’s violating her right in front of me, and I can’t even escape!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:762
translate chinese LiR2_S2_step3_514afaff_1:

    # "*Shlick* *Shlick*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:766
translate chinese LiR2_S2_step3_2628bd46:

    # Yazmin "*Suuuuck* *SHLUURRRP*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:769
translate chinese LiR2_S2_step3_54809214:

    # MC "Ughh! Hnnnng! Ohhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:771
translate chinese LiR2_S2_step3_bd230a6b:

    # MC "God, your wife’s mouth feels SOOO good, Liza. Let’s see how it compares to her throat."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:773
translate chinese LiR2_S2_step3_1d3bbe28:

    # Liza "No! Don’t!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:777
translate chinese LiR2_S2_step3_5cdf4b1a:

    # MC "HNNNGG! Ooohhhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:779
translate chinese LiR2_S2_step3_036af164:

    # Yazmin "*GAG* *Splutter* *Cough*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:781
translate chinese LiR2_S2_step3_a411608a:

    # MC "Do you hear that, Liza? That’s the sound of your wife choking on my cock."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:783
translate chinese LiR2_S2_step3_5cdf4b1a_1:

    # MC "HNNNGG! Ooohhhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:785
translate chinese LiR2_S2_step3_2466cacf_1:

    # Yazmin "*Shlurp* *Gag* *Shlurp*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:788
translate chinese LiR2_S2_step3_85a234b3:

    # MC "How does it ugh... look back there? Is your wife’s pussy getting all wet from mmmm... having her face fucked?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:790
translate chinese LiR2_S2_step3_1a6b0ee5:

    # Liza "Sh-Shut up!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:792
translate chinese LiR2_S2_step3_bd21677e:

    # MC "I hope it is. I’m going to need it to be nice and wet for the next part."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:796
translate chinese LiR2_S2_step3_080750ab:

    # Liza "Ahnnnggg! No! Leave her alone!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:798
translate chinese LiR2_S2_step3_509d44b3:

    # Liza "(Holy crap! This is sooooo hot! How did Yazmin come up with this so quickly?!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:800
translate chinese LiR2_S2_step3_96263b6d:

    # Yazmin "*GAG* *SPLUTTER* *CHOKE* *SHLUURRP*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:802
translate chinese LiR2_S2_step3_79e785e0:

    # MC "Aaahhhh! Fuuuuck! *Pant* Mmmm!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:804
translate chinese LiR2_S2_step3_f4b92fac_6:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:806
translate chinese LiR2_S2_step3_e226840f:

    # MC "Looks like you’re running out of time, Liza."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:808
translate chinese LiR2_S2_step3_30ba5d11:

    # Yazmin "*Gasp* *Cough* When I said you *Gasp* could fuck my face *Cough* I forgot how big you were. *Gasp*"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:810
translate chinese LiR2_S2_step3_eb7a2731:

    # MC "Oh! Are you okay?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:812
translate chinese LiR2_S2_step3_69619060:

    # Yazmin "*Cough* Y-Yeah! Just catching my breath."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:816
translate chinese LiR2_S2_step3_5d581c6d:

    # Yazmin "Alright, Darling. This is your *cough* final chance to save your wife’s pussy. Two minutes on the clock."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:818
translate chinese LiR2_S2_step3_557ec988:

    # Yazmin "Look, we’ve even made it easier for you by moving closer. All you have to do is reach out and touch us. Those ropes MUST have loosened A BIT by now. Right?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:820
translate chinese LiR2_S2_step3_3a40d403:

    # Liza "Ahnnnngg! *Pant* Hnnnng!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:824
translate chinese LiR2_S2_step3_ed90755d:

    # Yazmin "I’ll take that as a “no.”"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:826
translate chinese LiR2_S2_step3_c056e1e2:

    # Yazmin "While the timer ticks down, let me regale you with a tale of what’s about to happen. [player_name] is going to grind his unprotected cock back and forth between my thighs to get it nice and wet with my juices."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:828
translate chinese LiR2_S2_step3_9944bb22_1:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:832
translate chinese LiR2_S2_step3_40c7c052:

    # Yazmin "*Pant* And when that little timer beeps again, he’s going to bend me over and fuck me ddoggy-style, right in front of you."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:834
translate chinese LiR2_S2_step3_683539d5:

    # Liza "*Gulp* Ahnnng!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:836
translate chinese LiR2_S2_step3_01839666:

    # Liza "(My wrists are still stuck! I don’t know what she did with these knots, but they aren’t shifting!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:840
translate chinese LiR2_S2_step3_277131ac:

    # Yazmin "Oooh..."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:842
translate chinese LiR2_S2_step3_d9a19254:

    # MC "Can you hear that, Liza? That’s your wife moaning while my fat dick slides up against her clitoris."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:844
translate chinese LiR2_S2_step3_e54353bc:

    # Yazmin "*Pant* Mmmm!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:848
translate chinese LiR2_S2_step3_5f201b4e:

    # MC "Tell me, Yazmin, which feels better against your clit - your wife’s tongue or my rock hard dick?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:850
translate chinese LiR2_S2_step3_5a9a05b0:

    # Yazmin "Ah... Ohhhh.... Your cock! Mmmm! It’s sooo much better! Ah!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:852
translate chinese LiR2_S2_step3_437afecc:

    # Liza "AHNNNG! NOOOOO!!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:856
translate chinese LiR2_S2_step3_ade9f6d6:

    # Liza "(Yazmin always knows EXACTLY what to say to tease me!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:858
translate chinese LiR2_S2_step3_2fa65cc8:

    # Yazmin "*Pant* Ohhhh! If I was you, Liza, I’d be getting mmm... pretty worried right now."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:860
translate chinese LiR2_S2_step3_3a333cdd:

    # MC "Yeah, after this is all over, is your wife secretly going to be imagining my dick when you’re going down on her?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:864
translate chinese LiR2_S2_step3_4db0d204:

    # Liza "Sh-Shut up! Argh! *Pant* Dammit!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:866
translate chinese LiR2_S2_step3_24413b7c:

    # Yazmin "Mmm, I think I might be. God... I don’t even know what's going to happen when that alarm goes off and you finally plunge your dick inside me."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:868
translate chinese LiR2_S2_step3_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:872
translate chinese LiR2_S2_step3_c5c95ca7:

    # Yazmin "Ah!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:874
translate chinese LiR2_S2_step3_6f09d211:

    # MC "Yeah, for all we know, you may not even be interested in Liza anymore."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:876
translate chinese LiR2_S2_step3_5f238525_2:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:880
translate chinese LiR2_S2_step3_8e10c8dd:

    # Yazmin "Ooohh..."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:882
translate chinese LiR2_S2_step3_916bcfe9:

    # Yazmin "My bisexuality always worried you darling, didn’t it? Sure, I married you - but what if I feel this thick cock destroying my pussy in a way you NEVER could, and I wonder if I made a mistake?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:884
translate chinese LiR2_S2_step3_305347c2:

    # Liza "Nooo! *Pant* Hnnnngg!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:888
translate chinese LiR2_S2_step3_4cf15da9:

    # Yazmin "I know this turns *Pant* you on, Darling. I can see your dripping wet pussy right now. Ah!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:890
translate chinese LiR2_S2_step3_01de2e27:

    # Yazmin "You get so excited at the thought of someone stealing me away. Ooohhhh! The fact that he has a cock, just makes it ten times worse for you though, doesn't it?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:892
translate chinese LiR2_S2_step3_f8e46ca1:

    # Liza "Arrgh! Stupid ropes! Hnnnngg!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:896
translate chinese LiR2_S2_step3_9cbd1a25:

    # Yazmin "Mmm! That’s it, Dear! Keep struggling. Do your best! Ah!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:898
translate chinese LiR2_S2_step3_b75714b0:

    # MC "You better be quick though - time is almost up. Who knows if your beloved wife is even going to want to sleep with you anymore after she’s had her pussy stretched out by my shaft?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:900
translate chinese LiR2_S2_step3_edf3f0c5:

    # Liza "Hnnnnngg...."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:904
translate chinese LiR2_S2_step3_4474e951:

    # Liza "(C’mon, c’mon! This is my last chance before he fucks her!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:906
translate chinese LiR2_S2_step3_f14e78b5:

    # Liza "Arghhhhh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:908
translate chinese LiR2_S2_step3_de31085a:

    # "*BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:912
translate chinese LiR2_S2_step3_d5e9210d:

    # Liza "NOOOOOO!!!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:914
translate chinese LiR2_S2_step3_de31085a_1:

    # "*BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:916
translate chinese LiR2_S2_step3_9fe95725:

    # Yazmin "Oh no, it looks like you’ve ran out of time, Darling."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:920
translate chinese LiR2_S2_step3_de266dab:

    # Liza "No! Wait! Don’t fuck her! Please! Pleeeeassee!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:922
translate chinese LiR2_S2_step3_9d625742:

    # MC "Do you want me to stop?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:926
translate chinese LiR2_S2_step3_a1434dfa:

    # Yazmin "*Whispered* Well, Dear? Do you actually want us to stop? Safe word?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:928
translate chinese LiR2_S2_step3_9f80f3f6:

    # Liza "... *Gulp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:930
translate chinese LiR2_S2_step3_1a585027:

    # Yazmin "Keep going, [player_name]. If she actually wanted us to stop, she’d have used our safe word a long time ago. And double down on taunting her. She’s getting turned on by every single second of this."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:934
translate chinese LiR2_S2_step3_5c0d1d81:

    # Yazmin "*Whispered* It’s getting close now, Liza. I can feel the tip of his glans pushing up against my vulva."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:936
translate chinese LiR2_S2_step3_a05dbd58:

    # Yazmin "*Pant* Oohhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:938
translate chinese LiR2_S2_step3_3298fdb5:

    # Yazmin "*Whispered* It’s starting to slide in now. Ah! There’s barely any resistance, I’m already soaking wet and his cock is coated in my juices. OOohhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:940
translate chinese LiR2_S2_step3_7b078c00:

    # Liza "Pleeeeasse stop!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:942
translate chinese LiR2_S2_step3_d5101d59:

    # Yazmin "*Whispered* He’s going to make me feel better than *Gasp* your tongue or fingers EVER could."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:946
translate chinese LiR2_S2_step3_c0667fce:

    # Yazmin "*GASP* AAHHHH! "
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:948
translate chinese LiR2_S2_step3_dcc9d73e:

    # Liza "NOOOO!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:950
translate chinese LiR2_S2_step3_f70c0941:

    # MC "Hnnng! Ohhhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:954
translate chinese LiR2_S2_step3_95c6896a:

    # Yazmin "Ah! Ah! Ahhh! Ahhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:956
translate chinese LiR2_S2_step3_1c88365f:

    # MC "Mmm! Your wife’s pussy is SOOO tight, Liza. I guess that’s what happens when she isn’t getting properly fucked every night."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:958
translate chinese LiR2_S2_step3_d4c73878:

    # Liza "Arrrghhh! NOO! NOOOOO!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:962
translate chinese LiR2_S2_step3_c291e567:

    # Yazmin "Ah! AHHH! Ohhhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:964
translate chinese LiR2_S2_step3_af89d25c:

    # Liza "*Pant* Hnnnngg! *Pant* Argh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:966
translate chinese LiR2_S2_step3_1ecc04ea:

    # MC "Ugh! Do you even think Yazmin’s going to WANT to sleep with you anymore after I’m done with her?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:970
translate chinese LiR2_S2_step3_770a2728:

    # Yazmin "AhH! I don’t know if I will! Mmm! I don’t think she can satisfy me the way your big cock can. Ooohhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:972
translate chinese LiR2_S2_step3_678e97a4:

    # Yazmin "The real thing is soooo much better than any strap-on she’s ever worn!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:974
translate chinese LiR2_S2_step3_645fa34b:

    # MC "HNnnng! Ugh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:978
translate chinese LiR2_S2_step3_8f004ce2:

    # Yazmin "*Pant* Ooohh! Ahhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:980
translate chinese LiR2_S2_step3_ee23b0cd:

    # Liza "(I wish someone was playing with my pussy right now - I can barely take it any longer!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:984
translate chinese LiR2_S2_step3_51ec20a2:

    # Yazmin "I bet you’re wondering ahh... why the timer is still going? *Pant* Mmm!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:986
translate chinese LiR2_S2_step3_5f238525_3:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:988
translate chinese LiR2_S2_step3_28d362b4:

    # Yazmin "Tell me, Dear. Ohh! What do you think is ahh... going to happen when that alarm goes off again?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:992
translate chinese LiR2_S2_step3_1f4aab86:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:994
translate chinese LiR2_S2_step3_f2989b80:

    # Liza "*Gasp* No! No way! Not inside you!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:996
translate chinese LiR2_S2_step3_d99735f1:

    # Yazmin "Ah! Ahhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1000
translate chinese LiR2_S2_step3_43ab315a:

    # Yazmin "*Whispered* That’s right, Dear. Mmm! When that alarm goes again ohhh... I’m going to lie back ahh... on the bed and spread my legs."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1002
translate chinese LiR2_S2_step3_68fc17ff:

    # Liza "No, no, no!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1004
translate chinese LiR2_S2_step3_39302293:

    # Yazmin "That’s mmm... right! [player_name] is going to thrust into your wife’s pussy over and over until..."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1008
translate chinese LiR2_S2_step3_03731429:

    # Yazmin "...he fills me up with his *Moan* thick semen! Ahhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1010
translate chinese LiR2_S2_step3_55c6d52e:

    # Liza "*Gasp* Nooooo! Stop! Arrghhh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1012
translate chinese LiR2_S2_step3_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1016
translate chinese LiR2_S2_step3_eacd5c3c:

    # Yazmin "Ah! Ahhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1018
translate chinese LiR2_S2_step3_0930daf2:

    # Yazmin "You love watching your wife get mmm... fucked up close, don’t you, Darling?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1020
translate chinese LiR2_S2_step3_fed5636a_1:

    # Liza "No!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1024
translate chinese LiR2_S2_step3_b31d8e22:

    # Yazmin "Ah! Admit it! Ohhh! Seeing me get ruined by this thick ahh... fat cock turns you on so fucking much!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1026
translate chinese LiR2_S2_step3_54ad9885:

    # Liza "*Pant* Hnnngg..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1028
translate chinese LiR2_S2_step3_466d91bb:

    # Yazmin "Ohh! Keep struggling, Dear! Maybe you’ll be ahh... able to stop him before he creampies my pussy?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1032
translate chinese LiR2_S2_step3_37927617:

    # Liza "Arrghh! Stop it! *Pant* Aahhh!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1034
translate chinese LiR2_S2_step3_0a2bff7b:

    # Yazmin "What’s wrong, Darling? Is it the ah...thought of all his sperm rushing into my unprotected womb? Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1036
translate chinese LiR2_S2_step3_6ab31951_1:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1040
translate chinese LiR2_S2_step3_f3696a6d:

    # Yazmin "Can you hear him grunting and ayyaahh... groaning, Liza? He must be getting pretty close!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1042
translate chinese LiR2_S2_step3_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1044
translate chinese LiR2_S2_step3_bce27460:

    # Yazmin "I bet you can’t get the thought of him blasting all that cum inside me ahh... out of your head! Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1048
translate chinese LiR2_S2_step3_bdf4c2d9:

    # Yazmin "Ah! Ah! Ahhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1050
translate chinese LiR2_S2_step3_b0b11a1a:

    # Liza "No, no, no! ARRGHHH! *Pant* Hnnnng!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1054
translate chinese LiR2_S2_step3_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1056
translate chinese LiR2_S2_step3_591b487e:

    # Yazmin "Ah! AHHH! AHHH! I’m cumming! I’m cumming!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1059
translate chinese LiR2_S2_step3_f4b92fac_7:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1062
translate chinese LiR2_S2_step3_f3ed3769:

    # Yazmin "OOHHHHHH!!!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1066
translate chinese LiR2_S2_step3_d7f870ab:

    # Yazmin "*Pant* *Pant* Looks like you’re *Pant* about to lose, Dear."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1068
translate chinese LiR2_S2_step3_cc71950c:

    # Yazmin "It’s the final two minutes on the clock. If you can’t *Pant* break free before it goes off, then [player_name] is going to give me the biggest, hottest, stickiest creampie of my life."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1070
translate chinese LiR2_S2_step3_681953fc:

    # Liza "HNNNGGG! *Pant* Nooooooo!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1074
translate chinese LiR2_S2_step3_0e539103:

    # Yazmin "Oohhh! Just like that!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1076
translate chinese LiR2_S2_step3_53f0b153:

    # MC "I’m going to enjoy filling you up, Yazmin."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1078
translate chinese LiR2_S2_step3_595e962e:

    # Liza "(I can’t believe she’s getting pounded right in front of me like this! And I’m too weak to even break free of these ropes...)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1082
translate chinese LiR2_S2_step3_3a0ee80d:

    # Liza "(I’m completely powerless to help her... and I’m dripping all over this chair.)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1084
translate chinese LiR2_S2_step3_8253f33c:

    # Yazmin "Mmm! Fuck me hard, [player_name]. Fuck me the way my wife never could!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1086
translate chinese LiR2_S2_step3_e1281895_1:

    # Liza "*Gasp*"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1090
translate chinese LiR2_S2_step3_2f2ad302:

    # Yazmin "Yes! Yes! Ah! Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1092
translate chinese LiR2_S2_step3_57969667:

    # MC "Hnnng! *Pant* Ohhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1096
translate chinese LiR2_S2_step3_10893ef4:

    # Yazmin "God! Sex is sooo much more satisfying when there’s a cock! Mmmm!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1098
translate chinese LiR2_S2_step3_f084171f:

    # MC "I bet you’ve never cum this hard in years, have you?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1100
translate chinese LiR2_S2_step3_eedde549:

    # Yazmin "Mmmm! It feels sooo much better than anything she can do to me!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1104
translate chinese LiR2_S2_step3_281f505c:

    # Yazmin "Ah! Ahhhh! Ahhhhhhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1106
translate chinese LiR2_S2_step3_6fe7eed7:

    # Liza "(Why do I feel so horny every time she does this to me?!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1110
translate chinese LiR2_S2_step3_cc1d0f99:

    # Yazmin "*Pant* Ohhhh! Mmmmm!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1112
translate chinese LiR2_S2_step3_6ab31951_2:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1114
translate chinese LiR2_S2_step3_d406a93f:

    # Yazmin "Yesssss! I can’t wait to feel your cock throbbing inside me! Ahh! I’ve MISSED having my pussy flooded with thick, salty semen! Ahhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1118
translate chinese LiR2_S2_step3_76823830:

    # Liza "(Oh my God... He’s pounding her so hard! This isn’t just for roleplay... [player_name] is actually going to finish inside her if I can’t escape...)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1120
translate chinese LiR2_S2_step3_55b2bcdf:

    # Liza "(All I have to do is say the safe word... but... it’s so hot...)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1122
translate chinese LiR2_S2_step3_51c8d533:

    # Yazmin "Ah! AHHHHH! Ohhhh God! Faster! Yessss!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1126
translate chinese LiR2_S2_step3_57ce2882:

    # Yazmin "Oohhhhh!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1128
translate chinese LiR2_S2_step3_49cae69a_1:

    # MC "Hnnnngg!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1132
translate chinese LiR2_S2_step3_6fb0e95b:

    # MC "*Pant* I’m getting close!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1134
translate chinese LiR2_S2_step3_0df06024:

    # Liza "No, no, no! Not inside her!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1136
translate chinese LiR2_S2_step3_192ba702:

    # Yazmin "Aaahhhh! Yessss! Cum inside me!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1138
translate chinese LiR2_S2_step3_f4b92fac_8:

    # "*BEEP BEEP* *BEEP BEEP*"
    ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1142
translate chinese LiR2_S2_step3_18fd6a69:

    # Yazmin "I’m sorry, Darling, but that’s the end of the game."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1144
translate chinese LiR2_S2_step3_2506abe6:

    # Liza "NOOO!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1146
translate chinese LiR2_S2_step3_bb98f943:

    # Yazmin "You’re going to have to watch as this man impregnates your wife, right in front of you. "
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1150
translate chinese LiR2_S2_step3_8b08db15:

    # Liza "Pleeeasse... Please don’t impregnate her! "
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1152
translate chinese LiR2_S2_step3_6b7a83ae:

    # Liza "You’ll ruin her! You’ll ruin my marriage!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1154
translate chinese LiR2_S2_step3_32d8ba19:

    # MC "I’ve already ruined her, Liza. Do you really think she’d want to go back to you after everything I’ve shown her?"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1158
translate chinese LiR2_S2_step3_374b1192:

    # Yazmin "*Whispered* Last chance to use your safe word."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1160
translate chinese LiR2_S2_step3_c350b718:

    # Liza "..."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1162
translate chinese LiR2_S2_step3_0c959e7e:

    # Yazmin "That’s what I thought."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1166
translate chinese LiR2_S2_step3_e3ae3114:

    # Yazmin "Do it, [player_name]! Fuck me as hard as you can! Break my cunt like my wife never could!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1168
translate chinese LiR2_S2_step3_c6307d42:

    # Liza "NOOOOO!!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1170
translate chinese LiR2_S2_step3_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1174
translate chinese LiR2_S2_step3_a0332513:

    # Yazmin "Ah! Ah! Ah! AH! AHH! AHH!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1176
translate chinese LiR2_S2_step3_f138b608:

    # Liza "STOP! Don’t cum inside her!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1178
translate chinese LiR2_S2_step3_000752f6:

    # MC "HNNNGGG!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1182
translate chinese LiR2_S2_step3_2c1bd9dc:

    # Yazmin "OHHH! I can feel his cock throbbing! *Pant* Ahh! You’re going to cum soon, aren't you?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1184
translate chinese LiR2_S2_step3_3d08e65c:

    # Liza "No! NO!!! Don’t!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1186
translate chinese LiR2_S2_step3_179db323:

    # MC "*Pant* Ohhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1190
translate chinese LiR2_S2_step3_4a59ea5e:

    # MC "Mmm! I’m gonna make sure I'm nice and deep when I fill her up!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1192
translate chinese LiR2_S2_step3_bc3545e8:

    # Yazmin "Ayaaaahhhhh! I’m cumming! I’m cummmmmmmmiiiinnnng!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1194
translate chinese LiR2_S2_step3_102add15_1:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1197
translate chinese LiR2_S2_step3_3c844132:

    # MC "*Pant* *Pant* Arrghhh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1199
translate chinese LiR2_S2_step3_c2c1cbea:

    # Liza "STOP! STOP IT!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1201
translate chinese LiR2_S2_step3_e70f5cb3:

    # Yazmin "OOOHHHHHHHHH!!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1205
translate chinese LiR2_S2_step3_5f164ed7:

    # MC "HNNNGG! I’m gonna cum!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1208
translate chinese LiR2_S2_step3_a1075ba5:

    # Liza "NOOOOOOO!!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1210
translate chinese LiR2_S2_step3_415f91c3:

    # MC "ARRGGHHHH!!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1216
translate chinese LiR2_S2_step3_e8af4c73:

    # MC "(It feels a little cruel to do this to Liza, but she SEEMS to be enjoying this. I might as well see it through to the end, like Yazmin planned.)"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1218
translate chinese LiR2_S2_step3_86e43aca:

    # MC "Hnnnng! Aarrghh! I’m cummmmiing!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1220
translate chinese LiR2_S2_step3_5284603d:

    # Yazmin "OOHHH! FILL ME UP! AAHAHHHHHH!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1222
translate chinese LiR2_S2_step3_4d7c5e5f:

    # Liza "NOOOOO!! NOT INSIDE HER!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1232
translate chinese LiR2_S2_step3_3d68e50f:

    # MC "*Pant* Ohhh.... Ugh!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1234
translate chinese LiR2_S2_step3_f7531985:

    # Yazmin "Mmmm... It feels so warm! God, that’s a MUCH more satisfying ending than anything my wife has ever given me."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1236
translate chinese LiR2_S2_step3_d59c7940:

    # Liza "Nooooooooooo! I can’t believe you did that!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1240
translate chinese LiR2_S2_step3_f1000b75:

    # Yazmin "Can you see this, Liza? Can you see his potent cum, just dripping out of me?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1242
translate chinese LiR2_S2_step3_b8c92cbb:

    # MC "*Pant* She was an amazing fuck, Liza."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1249
translate chinese LiR2_S2_step3_c3bb4d2d:

    # MC "(I get this is Liza’s fantasy, but I don’t think I can be THAT cruel to her... I’ll pull out and finish over her belly.)"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1251
translate chinese LiR2_S2_step3_eb0efbf4:

    # MC "Hnnnngg! I’m gonna cum!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1255
translate chinese LiR2_S2_step3_cd19401a:

    # Yazmin "Yes! Cum inside- huh?!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1257
translate chinese LiR2_S2_step3_8e51e2d2:

    # MC "*Pant* "
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1261
translate chinese LiR2_S2_step3_5facdcab:

    # Yazmin "No! It slipped out!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1263
translate chinese LiR2_S2_step3_07cef8f4:

    # MC "HNNNG! ARRRGHH!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1265
translate chinese LiR2_S2_step3_5a4f9141:

    # Liza "Oh, thank God!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1275
translate chinese LiR2_S2_step3_be5cb19d:

    # MC "OOHHHH! FUUUUCKK!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1277
translate chinese LiR2_S2_step3_df727101:

    # Yazmin "You missed! Get it back in, quick!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1281
translate chinese LiR2_S2_step3_b36cc1a5:

    # MC "*Pant* Mmmmm!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1283
translate chinese LiR2_S2_step3_b7abbe52:

    # Liza "(I was expecting him to finish inside her! I quite enjoyed the twist at the end!)"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1287
translate chinese LiR2_S2_step3_5151fd5f:

    # Yazmin "What happened?!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1289
translate chinese LiR2_S2_step3_36f5599d:

    # MC "I just slipped out as I was cumming."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1291
translate chinese LiR2_S2_step3_6f2add95:

    # Yazmin "You were supposed to impregnate me, right in front of her."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1295
translate chinese LiR2_S2_step3_a9a16195:

    # Liza "Don’t worry about it, Yazmin. I REALLY enjoyed it! I promise!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1297
translate chinese LiR2_S2_step3_4146030d:

    # Yazmin "Alright, as long as you were happy with it."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1306
translate chinese LiR2_S2_step2_con_7dfffcf3:

    # Liza "Can someone come over here and fuck me now?!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1308
translate chinese LiR2_S2_step2_con_cbc7d619:

    # Liza "Pleeeease, I’m soooo fucking horny!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1312
translate chinese LiR2_S2_step2_con_184822a6:

    # Yazmin "What do you think, [player_name]? Should we fuck her now?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1314
translate chinese LiR2_S2_step2_con_bffc47be:

    # MC "I don’t know, Yazmin. She was begging us to stop quite a lot earlier on. I don’t think it would be right for us to keep going."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1318
translate chinese LiR2_S2_step2_con_ce1a5719:

    # Liza "What are you talking about?! I was roleplaying!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1320
translate chinese LiR2_S2_step2_con_91474a2e:

    # MC "I’m not sure, Yazmin. It doesn’t seem right to end a cuckolding roleplay by fucking the one who got cucked."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1322
translate chinese LiR2_S2_step2_con_f17cc7fd:

    # Yazmin "I concur, [player_name]."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1326
translate chinese LiR2_S2_step2_con_6e920104:

    # Liza "WHAT?! You can’t just leave me horny like this! Pleeeease! Someone fuck me! I don’t care which one of you does it!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1328
translate chinese LiR2_S2_step2_con_917ef625:

    # Yazmin "You don’t care who fucks you? Huh. It sounds like you and me need to have a discussion about what constitutes healthy boundaries in a relationship."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1332
translate chinese LiR2_S2_step2_con_1a1f7d7c:

    # Liza "OOOHHHHHH! How DARE you use that line against me!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1334
translate chinese LiR2_S2_step2_con_45b26e2a:

    # Yazmin "I think you better head on home, [player_name]. I’ll give you a shout when Liza has cooled down."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1338
translate chinese LiR2_S2_step2_con_5466a4b6:

    # Yazmin "In fact, swing by tomorrow. She should be ready by then."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1340
translate chinese LiR2_S2_step2_con_ec524477:

    # MC "Cool, see you then!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1342
translate chinese LiR2_S2_step2_con_72cf0e14:

    # Liza "Wait - you’re going to make me wait a day before you fuck me?! Ugh! I’ll just have to use my vibrator, then."
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1346
translate chinese LiR2_S2_step2_con_d49dbd87:

    # Yazmin "Aww, isn’t she just adorable, [player_name]? She thinks she’s going to be using her vibrator. Haha!"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1348
translate chinese LiR2_S2_step2_con_007abbab:

    # Liza "What? What’s so funny?"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1352
translate chinese LiR2_S2_step2_con_a43335d5:

    # Yazmin "Darling, you aren’t going to be masturbating. I’m not even letting you out of that chair until tomorrow."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1354
translate chinese LiR2_S2_step2_con_05dd9e64:

    # Liza "What?!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1356
translate chinese LiR2_S2_step2_con_92be6e6d:

    # Yazmin "I think I’m going to put on a show, right in front of you. Oh! You know what would be fun? How about I use YOUR vibrator while I lie in bed, right in front of you?"
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1360
translate chinese LiR2_S2_step2_con_c6ec04dc:

    # Yazmin "You can watch me have all the orgasms you’re not going to get."
    Yazmin ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1362
translate chinese LiR2_S2_step2_con_286fa12e:

    # Liza "Wait! Don’t go, [player_name]! PLEASE! I’m so horny! Just fuck me! I don’t care if it’s a cock! I need to be fucked! PLEEEASE!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1364
translate chinese LiR2_S2_step2_con_13a4a45d:

    # MC "I’ll catch you tomorrow, Yazmin."
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1368
translate chinese LiR2_S2_step2_con_ec21b3ba:

    # Liza "PLEEEASE!"
    Liza ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1370
translate chinese LiR2_S2_step2_con_129430e5:

    # MC "Later Liza! See ya in the morning!"
    MC ""

# game/scripts/Li_R2/2_LiR2_S2.rpy:1372
translate chinese LiR2_S2_step2_con_5f74a58e:

    # Yazmin "Okay, let’s put on some sexy lingerie to REALLY tease you."
    Yazmin ""

translate chinese strings:

    # game/scripts/Li_R2/2_LiR2_S2.rpy:1212
    old "Fulfill Liza’s fantasy and cum deep inside her wife’s pussy."
    new ""

    # game/scripts/Li_R2/2_LiR2_S2.rpy:1212
    old "Ease up on Liza, pull out and cum over Yazmin’s belly instead."
    new ""

