﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Li_R2/LiR2_MS3.rpy:29
translate chinese LiR2_MS3_763b5a9f:

    # Liza "I just felt like you never really gave her a chance."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:31
translate chinese LiR2_MS3_3cf2cfd6:

    # Linda "Oh, come on! That’s HARDLY fair! Yazmin was invited to every single family event. Even that big barbeque we held!"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:33
translate chinese LiR2_MS3_eec0f272:

    # MC "(Huh... It sounds like someone is getting into an argument...)"
    MC ""

# game/scripts/Li_R2/LiR2_MS3.rpy:37
translate chinese LiR2_MS3_b63c77bb:

    # Liza "Yeah, you invited her, but you never attempted to interact with her!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:39
translate chinese LiR2_MS3_b75f3796:

    # Linda "I did! I distinctly remember asking if she wanted anything to drink, and then getting her a beer!"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:50
translate chinese LiR2_MS3_f64eee8f:

    # Liza "And what did you do after that?"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:52
translate chinese LiR2_MS3_fdba3200:

    # Linda "*Sigh* After what?"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:54
translate chinese LiR2_MS3_7c746b27:

    # Liza "You don’t remember, do you? You brought a beer over, and then you ignored her for the rest of the day. You didn’t so much as say a single word to her."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:59
translate chinese LiR2_MS3_fcccd21e:

    # Linda "*Sigh* I’ll concede that I might have been a bit quiet, but Yazmin and I weren't that close anyway. We didn’t have much to talk about."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:63
translate chinese LiR2_MS3_a90631c0:

    # Liza "Linda... I’ve known you my whole life. You’re one of the most determined people I know. I can tell when you don’t want to make an effort."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:67
translate chinese LiR2_MS3_6e9fd287:

    # Linda "Excuse me? I’m not making an effort?! When was the last time we went out together as sisters?"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:69
translate chinese LiR2_MS3_cc9742f1:

    # Linda "When’s the last time we hit up a nightclub together? Had a girls’ night out together? Went clothes shopping together?"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:71
translate chinese LiR2_MS3_261daaa6:

    # Liza "Linda, I always-"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:75
translate chinese LiR2_MS3_9b4a557f:

    # Linda "Do you have any idea how much it fucking hurt when all that ended, the moment you got engaged to Yazmin?!"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:77
translate chinese LiR2_MS3_d477dc37:

    # Linda "I never replaced you when I married Bob. I still NEEDED you after I married Bob."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:79
translate chinese LiR2_MS3_39b1b175:

    # Liza "I still need you, Linda."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:81
translate chinese LiR2_MS3_0a724f60:

    # Linda "I just feel like, if you’d married a man instead, then my role as a sister wouldn’t have become fucking obsolete! I mean, why do girly things with your sister when you’ve got a hot wife who can do the same things AND fuck your brains out afterwards?"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:85
translate chinese LiR2_MS3_e2caa400:

    # Liza "That’s enough, Linda!"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:87
translate chinese LiR2_MS3_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:89
translate chinese LiR2_MS3_3f41b90c:

    # Liza "I understand that you’re hurting because you feel like Yazmin has stolen me away from you, but I am not going to tolerate you continually berating me for marrying a woman."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:91
translate chinese LiR2_MS3_ce3d55b6:

    # Liza "I’ve been enduring this behaviour of yours FOR YEARS now, and it’s exhausting."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:95
translate chinese LiR2_MS3_7591e754:

    # Liza "Yes, Yazmin and I spend a lot of time together. We’re a married couple. We do girly dates together. We make each other happy."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:97
translate chinese LiR2_MS3_62ba0e75:

    # Linda "*Gulp*"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:99
translate chinese LiR2_MS3_cf1e35d3:

    # Liza "However, she isn’t you. Yazmin doesn’t replace the sister-shaped hole that you left behind. I still want to hang out with you like we used to do."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:101
translate chinese LiR2_MS3_44694f87:

    # Liza "I still NEED you, Linda. Mom’s not around anymore - and Dad’s barely able to feed himself on a good day. Who am I supposed to talk to when I’m going through a rough patch with Yazmin?"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:105
translate chinese LiR2_MS3_f60803e0:

    # Linda "...my marriage with Bob is falling apart and I... I don’t know what to do."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:107
translate chinese LiR2_MS3_ae264ffa:

    # Liza "Oh my God! Linda, I’m-"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:109
translate chinese LiR2_MS3_6c828cff:

    # Linda "I don’t love him anymore. I haven’t... for a long time now. I’m- I’m-"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:111
translate chinese LiR2_MS3_4788fd97:

    # Linda "...I’m sorry, Liza. For everything."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:115
translate chinese LiR2_MS3_5de16167:

    # MC "(I was worried that was going to devolve into another argument, but it sounds like the two of them are actually making up!)"
    MC ""

# game/scripts/Li_R2/LiR2_MS3.rpy:117
translate chinese LiR2_MS3_6ba8a562:

    # MC "(It’s probably best if I don’t interrupt them while they’re reconciling.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS3.rpy:121
translate chinese LiR2_MS3_d72522a7:

    # Liza "Thank you, Sis. It means a lot to hear that from you. I’m sorry for making you feel as if I didn’t need you anymore."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:123
translate chinese LiR2_MS3_a143ba48:

    # Linda "*Sigh* I was the one in the wrong. You had Yazmin to rely on, and as my relationship with Bob continued to fall apart, I was jealous of how happy you were with her."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:125
translate chinese LiR2_MS3_a5953aab:

    # Liza "Listen Linda, whatever is going on between you and Bob, I’ll be by your side until you get it fixed."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:127
translate chinese LiR2_MS3_7ec7d8ca:

    # Linda "Heh... It’s not something that CAN be fixed."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:131
translate chinese LiR2_MS3_ac90de05:

    # Liza "Oh please - everything’s fixable. I mean, how fucked-up of a situation could it actually be? We just need to unravel what’s gone wrong over a few Proseccos."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:133
translate chinese LiR2_MS3_ab01d9f3:

    # Linda "You wouldn’t believe me, if I told you HALF of it."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:135
translate chinese LiR2_MS3_ee68ca47:

    # Liza "Hehe, try me. Are you free some weekend?"
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:137
translate chinese LiR2_MS3_326a9b86:

    # Linda "Y-Yeah, I am."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:139
translate chinese LiR2_MS3_6524bddf:

    # Liza "How would you fancy doing a girly day out? We’ll go shopping at that new mall, if it’s open. Get some clothes, then hit a couple of clubs on the town like we used to."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:141
translate chinese LiR2_MS3_3d221854:

    # Linda "I’d love that!"
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:145
translate chinese LiR2_MS3_de407b01:

    # Linda "*Sob* I missed you so fucking much."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:147
translate chinese LiR2_MS3_19bc1336:

    # Liza "Shush, it’s okay, Sis. It’s okay. I love you."
    Liza ""

# game/scripts/Li_R2/LiR2_MS3.rpy:149
translate chinese LiR2_MS3_a6e3542f:

    # Linda "I *sob* love you too."
    Linda ""

# game/scripts/Li_R2/LiR2_MS3.rpy:153
translate chinese LiR2_MS3_a8e7563f:

    # MC "(It’s good to see they finally made up with each other.)"
    MC ""

# game/scripts/Li_R2/LiR2_MS3.rpy:155
translate chinese LiR2_MS3_ececc979:

    # MC "(I really hope they don’t bring me up when they go out for their girly night out though. Things could get very awkward, very quickly...)"
    MC ""

