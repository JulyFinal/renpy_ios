﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Li_R2/3_LiR2_MS2.rpy:143
translate chinese LiR2_MS2_3619879e:

    # MC "Morning Yazmin, did I miss much after I left?"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:145
translate chinese LiR2_MS2_a4326c29:

    # Yazmin "Good morning! A few hours of me masturbating in front of her. Then another few hours of me teasing her with my fingers and edging her."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:147
translate chinese LiR2_MS2_34220e32:

    # MC "Damn. Shame I missed it."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:151
translate chinese LiR2_MS2_fd9d8fef:

    # Yazmin "Take a seat. Relax."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:153
translate chinese LiR2_MS2_6f4a2338:

    # MC "Thanks."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:157
translate chinese LiR2_MS2_d158f721:

    # MC "Uh... Where is Liza, by the way? You DID untie her when you were done, right?"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:161
translate chinese LiR2_MS2_f7d4aa0e:

    # Yazmin "..."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:165
translate chinese LiR2_MS2_43ac5be2:

    # MC "You untied her, right?!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:169
translate chinese LiR2_MS2_00db689e:

    # Yazmin "Haha, I’m just teasing you. Of course I untied her... early this morning. The poor dear didn’t get much sleep."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:171
translate chinese LiR2_MS2_66cfe156:

    # Yazmin "You won’t believe how horny she is when you see her."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:173
translate chinese LiR2_MS2_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:177
translate chinese LiR2_MS2_50be9b97:

    # Yazmin "Oh yeah. She’s been edging for close to twelve hours now. She’s practically begging to be fucked."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:179
translate chinese LiR2_MS2_bb4c257d:

    # Yazmin "I’ve even got her dressed up in a slutty costume. She’s going to be my freeuse fucktoy today."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:181
translate chinese LiR2_MS2_d78d2a47:

    # Yazmin "Sorry, I should have said OUR freeuse fucktoy."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:187
translate chinese LiR2_MS2_0b789ebe:

    # Liza "Here’s the water you asked for! Can I plleeeeease cum now?"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:189
translate chinese LiR2_MS2_8d34420b:

    # MC "Hey Auntie!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:191
translate chinese LiR2_MS2_3f1ac887:

    # MC "Hey, Liza!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:195
translate chinese LiR2_MS2_66c10428:

    # Liza "Oh! I forgot you were coming over, [player_name]!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:197
translate chinese LiR2_MS2_2d4e3c03:

    # MC "Don’t let me get in the way! You two enjoy yourselves."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:201
translate chinese LiR2_MS2_ecf05907:

    # Liza "There you go, Darling."
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:203
translate chinese LiR2_MS2_e76cb68e:

    # Yazmin "Thanks, Dear."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:207
translate chinese LiR2_MS2_39f32944:

    # Liza "*Whispered* Can I fuck him now?"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:209
translate chinese LiR2_MS2_e6d315c0:

    # Yazmin "Not yet. Show a little restraint, Liza - he only just got here!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:213
translate chinese LiR2_MS2_545789a9:

    # Liza "Aww! But I’m soooo hooorrrny!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:215
translate chinese LiR2_MS2_e8dd747a:

    # Yazmin "*Sigh* What do you think, [player_name]? Should we finally give Liza some relief?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:219
translate chinese LiR2_MS2_62b9e309:

    # Liza "I’ll do anything! Pleeeease!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:221
translate chinese LiR2_MS2_a6d7a58f:

    # Yazmin "Anything?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:223
translate chinese LiR2_MS2_af7dd698:

    # Liza "I’ll lick your pussy, I’ll... I’ll let him fuck me! I’ll suck his cock, just plleeeasseee! I need to cum!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:227
translate chinese LiR2_MS2_fced161f:

    # MC "She seems pretty desperate, Yazmin."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:229
translate chinese LiR2_MS2_e42c8521:

    # Yazmin "Oh, she really is."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:231
translate chinese LiR2_MS2_27d4dac8:

    # MC "I think she deserves some release."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:235
translate chinese LiR2_MS2_3d1f4249:

    # Yazmin "Very well. C’mon, Darling. Let’s get you into the bedroom."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:239
translate chinese LiR2_MS2_7c621275:

    # Liza "Y-You’re actually going to let me cum?!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:241
translate chinese LiR2_MS2_abcc60e3:

    # Yazmin "Of course, Darling. I’ve kept you waiting long enough."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:245
translate chinese LiR2_MS2_3f29bfeb:

    # Yazmin "But you ARE going to have to do one last thing for me before I let you cum though."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:247
translate chinese LiR2_MS2_2a878e4d:

    # Liza "What? Anything! Just tell me!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:251
translate chinese LiR2_MS2_591a0df4:

    # Yazmin "I want you to get down on your knees and suck [player_name]’s cock while I watch."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:253
translate chinese LiR2_MS2_79116d05:

    # Liza "I’ll do it!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:255
translate chinese LiR2_MS2_b15aca04:

    # MC "(Awesome!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:259
translate chinese LiR2_MS2_e4bf1882:

    # Yazmin "She makes a good little slut, doesn’t she, [player_name]?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:263
translate chinese LiR2_MS2_2296254d:

    # MC "That costume really suits her."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:267
translate chinese LiR2_MS2_5c5fdfce:

    # Yazmin "Well? What are you waiting for, Darling? Go on. Pull his jeans down and take his cock in your mouth."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:271
translate chinese LiR2_MS2_9a00b5de:

    # Yazmin "I put on a show for you with [player_name]. It’s only fair that you put on one for me as well."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:273
translate chinese LiR2_MS2_360f78dd:

    # Yazmin "I want to see you greedily sucking and slurping on his meat."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:277
translate chinese LiR2_MS2_39299e83:

    # Yazmin "That’s it. Keep going. "
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:281
translate chinese LiR2_MS2_e1281895:

    # Liza "*Gasp*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:283
translate chinese LiR2_MS2_fd0d16ee:

    # Yazmin "Don’t you chicken out on me, Dear. I know how horny you are. You were BEGGING for a cock to fuck you last night. Now’s your chance. Take it."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:287
translate chinese LiR2_MS2_8024faf5:

    # Liza "It’s... *Gulp* ...a lot bigger up close."
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:289
translate chinese LiR2_MS2_b32d3b63:

    # MC "(Uh oh, I think Liza’s going to back out again...)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:293
translate chinese LiR2_MS2_8daa9358:

    # Yazmin "You can do it. How about you start off by licking it? Ease yourself into it."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:297
translate chinese LiR2_MS2_7e28facf:

    # Liza "*Lick* *Lick*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:300
translate chinese LiR2_MS2_99bd6d2e:

    # MC "Mmm! Hnnng..."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:302
translate chinese LiR2_MS2_75776d37:

    # Yazmin "See? That’s not so bad. Right?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:304
translate chinese LiR2_MS2_ea221517:

    # Liza "*Lick* Uh huh!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:306
translate chinese LiR2_MS2_23b324d3:

    # Yazmin "[player_name], grab her head and fuck her face."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:308
translate chinese LiR2_MS2_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:310
translate chinese LiR2_MS2_33df629e:

    # Yazmin "Do it."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:314
translate chinese LiR2_MS2_d5711508:

    # Liza "*GLOMPFF*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:316
translate chinese LiR2_MS2_85290cd8:

    # Yazmin "It’s like tearing off a band-aid, Darling. Best to just do it quickly!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:318
translate chinese LiR2_MS2_d4b79473:

    # Liza "*SHLURP* *SUCK* *SHLUURRRP*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:320
translate chinese LiR2_MS2_224c8d92:

    # MC "Hnnnngg! OhhH!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:324
translate chinese LiR2_MS2_f76d7114:

    # Yazmin "Keep your hands behind your back, Honey. Just like we practiced."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:326
translate chinese LiR2_MS2_dcf214e2:

    # Liza "*GLOMPF* *GAG* *SHLURP*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:328
translate chinese LiR2_MS2_f89d7016:

    # MC "Ohhh... Mmmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:332
translate chinese LiR2_MS2_517bd412:

    # Liza "Mppfff!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:334
translate chinese LiR2_MS2_e08532d1:

    # Yazmin "Mmm... That’s my good little cocksucking slut."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:336
translate chinese LiR2_MS2_21cf1e3e:

    # Liza "*Shluuurrrp* *Suck* *Shlurp*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:340
translate chinese LiR2_MS2_fdca1ce4:

    # MC "Oohh! Fuck! Mmmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:342
translate chinese LiR2_MS2_590b7e19:

    # MC "(Liza’s certainly come a LONG way from being too scared to even touch my dick! She’s sucking it like a pro right now!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:344
translate chinese LiR2_MS2_d65929e3:

    # Yazmin "What do you think, [player_name]? I was training her to suck my strap-on last night."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:346
translate chinese LiR2_MS2_e9c495ce:

    # MC "Hnnng! She’s great!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:350
translate chinese LiR2_MS2_06c80bce:

    # Yazmin "I think I did a pretty good job breaking her in - if I do say so myself."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:352
translate chinese LiR2_MS2_0c881159:

    # Liza "*Shluurrrrp* *Suck* *Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:354
translate chinese LiR2_MS2_3cb2335e:

    # Yazmin "Try pulling her head in close. I taught her how to deepthroat too."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:358
translate chinese LiR2_MS2_6e618921:

    # Liza "MPPFFF!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:360
translate chinese LiR2_MS2_35506bef:

    # MC "Ooohhhh....!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:362
translate chinese LiR2_MS2_2e14514f:

    # Yazmin "That’s it. Keep sucking his cock, and I’ll reward you with a climax of your own, Liza."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:366
translate chinese LiR2_MS2_8d4f0ee7:

    # Liza "*Shluuurrrp* *Suck* *Shlurrrp*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:368
translate chinese LiR2_MS2_0574c0f9:

    # MC "Hnnnngg! Ooohhh God! Mmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:372
translate chinese LiR2_MS2_e9cc24ef:

    # Liza "*Suck* *Gag* *Shlurrrrp*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:374
translate chinese LiR2_MS2_80e06166:

    # MC "Mmm! Hnnngg!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:376
translate chinese LiR2_MS2_b965e0be:

    # Yazmin "She’s pretty good at that now, right? Go on, Liza. Stick your tongue out, like I taught you."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:380
translate chinese LiR2_MS2_9fee83a2:

    # Liza "Ahmmmmmm!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:382
translate chinese LiR2_MS2_80ca0d81:

    # MC "Ahhhhh! Ohh! Fuck!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:384
translate chinese LiR2_MS2_00f2d129:

    # Liza "*Shluurrrp*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:388
translate chinese LiR2_MS2_ed2ee77f:

    # Liza "Aahhhhhhmmmmm!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:390
translate chinese LiR2_MS2_514afaff:

    # "*Shlick* *Shlick*"
    ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:392
translate chinese LiR2_MS2_7900a82d:

    # MC "Hnnnng! Fuck! *Pant* Ooohhh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:396
translate chinese LiR2_MS2_b1a98652:

    # Liza "*Shlurp* *Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:398
translate chinese LiR2_MS2_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:400
translate chinese LiR2_MS2_418f4f94:

    # Yazmin "How are you enjoying my wife’s throat?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:402
translate chinese LiR2_MS2_2f050f06:

    # MC "Hnnng! It’s really mmm... fucking good!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:404
translate chinese LiR2_MS2_d80cc37a:

    # Yazmin "Really thrust your cock in there. I want to see how deep she can actually take it."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:408
translate chinese LiR2_MS2_b153c3f2:

    # Liza "*GAG* *CHOKE*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:410
translate chinese LiR2_MS2_267a2e4a:

    # MC "Ooohhh! Mmmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:412
translate chinese LiR2_MS2_dcc5ae24:

    # Yazmin "(Mmm, that’s so fucking hot.)"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:416
translate chinese LiR2_MS2_f7d3ce18:

    # Liza "*Cough* *Gasp* Can I-"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:418
translate chinese LiR2_MS2_eae96ab1:

    # Liza "*Gasp* *Pant* Can I PLEEEASE cum now?! I’ve done EVERYTHING you asked!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:422
translate chinese LiR2_MS2_7456d15b:

    # Yazmin "What do you think, [player_name]? Was the blowjob to your satisfaction?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:424
translate chinese LiR2_MS2_57c77a47:

    # MC "Oh yeah, it was amazing."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:426
translate chinese LiR2_MS2_1e610e58:

    # Yazmin "Well, in that case, I guess it’s only fair."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:430
translate chinese LiR2_MS2_88868639:

    # Yazmin "Alright Liza, bend over. [player_name] is going to pound you from behind. I want to see you cum from having a thick cock shoved deep inside you."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:432
translate chinese LiR2_MS2_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:436
translate chinese LiR2_MS2_863de24c:

    # MC "(Whoa!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:438
translate chinese LiR2_MS2_48cbaaa3:

    # MC "Just to be clear - Liza actually wants me to fuck her? I thought she was almost completely lesbian."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:440
translate chinese LiR2_MS2_e8c98375:

    # Yazmin "Emphasis on “almost”. If you get her horny enough, she’ll be begging for a good dick. Isn’t that right, Darling?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:444
translate chinese LiR2_MS2_94080b59:

    # Liza "Please, just hurry up and fuck me!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:446
translate chinese LiR2_MS2_1070fc99:

    # MC "(Can’t get much clearer than that!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:450
translate chinese LiR2_MS2_e48d97d3:

    # MC "Alright, here we go!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:452
translate chinese LiR2_MS2_940bc2e0:

    # Yazmin "Beg for it. I want to hear you beg for [player_name]’s cock."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:454
translate chinese LiR2_MS2_746dce6e:

    # Liza "Please fuck me, [player_name]. I need to feel your thick dick inside my wet pussy! Please! Hurry up and fuck-"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:458
translate chinese LiR2_MS2_89ccaf11:

    # Liza "-meeeehhhhh! OOHHHHHH!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:460
translate chinese LiR2_MS2_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:464
translate chinese LiR2_MS2_560e7ab4:

    # Liza "Ayaaahhhhhh! I’M CUMMMMIIINNNGG!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:466
translate chinese LiR2_MS2_7727daf3:

    # Yazmin "Oh wow! I knew I’d edged you pretty hard, but I didn’t imagine you’d lose your mind with just a single thrust!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:468
translate chinese LiR2_MS2_68496989:

    # Liza "AAAHHHHHH!! OOHHHHHHHH!!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:472
translate chinese LiR2_MS2_b626c1f1:

    # Yazmin "Don’t move your hips, [player_name]. Liza’s going to do all the work today. Aren’t you my little fucktoy?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:474
translate chinese LiR2_MS2_6c75c765:

    # Liza "AYAAAHHHH! HAAAAHHHHHH!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:476
translate chinese LiR2_MS2_7f6d780d:

    # Yazmin "That means yes."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:480
translate chinese LiR2_MS2_77173883:

    # Liza "AH! AH! AH! YESSSSS! AAHHHHH!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:482
translate chinese LiR2_MS2_b36bac5b:

    # MC "Hnnng! Ugh! Oohhhh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:484
translate chinese LiR2_MS2_96479652:

    # MC "(She’s bucking her hips like crazy right now! She’s gone absolutely wild!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:488
translate chinese LiR2_MS2_0cd25d93:

    # Liza "AHHH! AHHH! AHHHHHHHH!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:490
translate chinese LiR2_MS2_dedcf79d:

    # MC "Mmmm! Ah! *Pant* Ooohhh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:494
translate chinese LiR2_MS2_922ac830:

    # Yazmin "Good girl. Keep riding his dick like that. Faster. Harder."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:496
translate chinese LiR2_MS2_205897b2:

    # Liza "AYAAAHHH! CUMMMMMIING AGAAAIIIINNN!! OOOHHHHHHHH!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:498
translate chinese LiR2_MS2_1e1f9e40:

    # MC "*Pant* Hnnng! Oohhhh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:502
translate chinese LiR2_MS2_470afa2d:

    # MC "She’s not gonna be the only one cumming, if she keeps this up!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:504
translate chinese LiR2_MS2_2ff97048:

    # Liza "Ah! Ah! Ahhh!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:506
translate chinese LiR2_MS2_b36bac5b_1:

    # MC "Hnnng! Ugh! Oohhhh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:509
translate chinese LiR2_MS2_2110770d:

    # Yazmin "How does it feel to have your pussy stretched out by a big fat cock like this?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:511
translate chinese LiR2_MS2_5832af9a:

    # Liza "Shooooo intensshhheee! Aaaahhhh!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:515
translate chinese LiR2_MS2_0e946631:

    # MC "*Pant* Hnnng! Ugh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:517
translate chinese LiR2_MS2_360d1808:

    # Liza "Haaahhhhh! OooohhhOOoOOOhHHH!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:521
translate chinese LiR2_MS2_3cd578ef:

    # MC "*Pant* I’m getting pretty close, Yazmin! Is it okay to cum inside her?"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:523
translate chinese LiR2_MS2_9759abc7:

    # Liza "Ah! AH! AHHH!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:525
translate chinese LiR2_MS2_069d20d3:

    # Yazmin "Absolutely not! I haven’t had MY fun yet."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:529
translate chinese LiR2_MS2_85a173ff:

    # MC "I’m gonna get to fuck you too?"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:531
translate chinese LiR2_MS2_238cd5c7:

    # Yazmin "Absolutely! Cumming inside Liza is one of her firm limits, anyway. But you can finish inside me instead."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:533
translate chinese LiR2_MS2_9759abc7_1:

    # Liza "Ah! AH! AHHH!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:537
translate chinese LiR2_MS2_a7f6907d:

    # MC "(Shame I can’t cum inside Liza, but at least Yazmin has started respecting her boundaries for a change!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:539
translate chinese LiR2_MS2_b0642f5e:

    # MC "Ohhh! *Pant* Mmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:543
translate chinese LiR2_MS2_b94aa1a9:

    # MC "OOHHH FUUUCK! Hnnnngg!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:545
translate chinese LiR2_MS2_c94efb58:

    # Liza "AH! AHHHH!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:547
translate chinese LiR2_MS2_151aff02:

    # MC "Slow down a bit! You’re gonna hnnnng... make me cum if you keep going so fast!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:551
translate chinese LiR2_MS2_11db0c6a:

    # Liza "I caaaahhn’t stoooohhhp! It feeelsh shoooo goooood! OOHHHHHH!!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:553
translate chinese LiR2_MS2_15897b05:

    # MC "HNNNNGGG!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:557
translate chinese LiR2_MS2_c41aab1b:

    # Liza "AAHHHH! I’M CUMMING AGAIN! OH GOD! IT WON’T STOOOOHHHP! OOOHHHHH!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:559
translate chinese LiR2_MS2_656f42b6:

    # MC "HNNNNGG! *Pant* OOHHHH! Fuuck!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:563
translate chinese LiR2_MS2_332a4e17:

    # Yazmin "Okay, I think we’ll call it there before you accidentally ride [player_name] to a creampie."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:567
translate chinese LiR2_MS2_ad33c5c2:

    # Liza "But I’m still horny! *Pant*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:569
translate chinese LiR2_MS2_0b774944:

    # Yazmin "Fine, but you’re the one risking your pussy if you can’t control yourself and he ends up cumming inside you."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:573
translate chinese LiR2_MS2_2ffc8413:

    # Yazmin "Oh, and I’m joining in as well now. I’m getting rather tired of sitting on the sidelines, watching you cum your brains out."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:575
translate chinese LiR2_MS2_bd851a62:

    # Liza "Ah! Ahh! Ah!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:579
translate chinese LiR2_MS2_c0102b57:

    # Yazmin "Hmm..."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:581
translate chinese LiR2_MS2_24780b3f:

    # Yazmin "(Now, where should I slot myself into this threesome?)"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:583
translate chinese LiR2_MS2_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:585
translate chinese LiR2_MS2_3fa3732f:

    # Liza "Ohh! Ohhh!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:587
translate chinese LiR2_MS2_8c89d968:

    # Yazmin "Move over a bit, Honey, it’s time for you to put that mouth to work!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:591
translate chinese LiR2_MS2_df901e4a:

    # Yazmin "Mmm... That’s perfect. Ah..."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:593
translate chinese LiR2_MS2_a4d45d5c:

    # Liza "*Suck* *Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:595
translate chinese LiR2_MS2_090ba930:

    # Yazmin "Oohh... Keep nibbling my nipple like that! Ooohhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:597
translate chinese LiR2_MS2_1f4aab86:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:601
translate chinese LiR2_MS2_ad0b198a:

    # Yazmin "Ah! Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:603
translate chinese LiR2_MS2_1e6ac963:

    # Liza "*Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:605
translate chinese LiR2_MS2_92abd045:

    # Yazmin "*Pant* *Pant* Mmmm!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:609
translate chinese LiR2_MS2_e5206849:

    # Liza "Mmm... *Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:611
translate chinese LiR2_MS2_8e10c8dd:

    # Yazmin "Ooohh..."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:613
translate chinese LiR2_MS2_e69f0e66_1:

    # MC "Hnnng!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:617
translate chinese LiR2_MS2_134d3c64:

    # MC "Mmmm! Ooohh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:619
translate chinese LiR2_MS2_85025c89:

    # Yazmin "*Gasp* Ooohhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:621
translate chinese LiR2_MS2_a4d45d5c_1:

    # Liza "*Suck* *Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:625
translate chinese LiR2_MS2_d2551a2c:

    # MC "Hnnnnngg!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:627
translate chinese LiR2_MS2_5e671a55:

    # MC "(Her pussy is incredible!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:629
translate chinese LiR2_MS2_32129be4:

    # Liza "Mmm! *Suck* Ahhhhmm!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:633
translate chinese LiR2_MS2_c2825861:

    # MC "Hnnnng! Ugh! Ohhh fuck!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:635
translate chinese LiR2_MS2_4b161732:

    # Liza "Ahmmm! *Suck* MMMMM!!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:637
translate chinese LiR2_MS2_fce443ea:

    # MC "*Pant* God, you’re so tight, Liza! Ooohh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:641
translate chinese LiR2_MS2_27cf3e77:

    # MC "*Pant* Ohh! *Pant* Ahh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:643
translate chinese LiR2_MS2_5a461d92:

    # Yazmin "Mmm! Yes! Fuck her! Wreck her pussy with your big, fat cock!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:647
translate chinese LiR2_MS2_8d0005b2:

    # Liza "AHMMMM!! *Suck* AHHHHMMMM!! OOHMMM!! *Suck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:649
translate chinese LiR2_MS2_00064e79:

    # Yazmin "Ah! Oohhhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:653
translate chinese LiR2_MS2_890d50aa:

    # MC "Ugh! Ohh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:655
translate chinese LiR2_MS2_37dfe4db:

    # Yazmin "Mmm! Keep sucking my tits!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:660
translate chinese LiR2_MS2_e54353bc:

    # Yazmin "*Pant* Mmmm!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:662
translate chinese LiR2_MS2_adc1e839:

    # MC "When do you *Pant* want me to start fucking you instead, Yazmin?"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:664
translate chinese LiR2_MS2_f286db6f:

    # MC "It’s getting REALLY difficult to avoid cumming, right now."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:668
translate chinese LiR2_MS2_054bcdca:

    # Yazmin "Ah... Just... Mmm... a few more... seconds! Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:670
translate chinese LiR2_MS2_8e1e1265:

    # Liza "Mmmm! *Suck* *Suuuuuuck*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:672
translate chinese LiR2_MS2_64c86dab:

    # Yazmin "Ayaaahhhh! Cummmmmiiing!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:676
translate chinese LiR2_MS2_38f9d5e2:

    # Yazmin "*Pant* Oh... That was amazing."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:678
translate chinese LiR2_MS2_9382d3d5:

    # Yazmin "Alright [player_name], *Pant* let’s get that giant cock of yours inside me. Fuck me and fill me up!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:682
translate chinese LiR2_MS2_cd1a5b3a:

    # Yazmin "Ooohhhh! Yeeesssss!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:684
translate chinese LiR2_MS2_75776f5d:

    # Yazmin "*Gasp* Keep playing with my clit, Liza! Ohhhh! Rub it faster! Aaahhhhhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:688
translate chinese LiR2_MS2_e69f0e66_2:

    # MC "Hnnng!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:690
translate chinese LiR2_MS2_67d9804e:

    # Yazmin "*Pant* *Pant* Yes, yes, yes! Right there! Don’t stop! Ayaaaahhhhhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:692
translate chinese LiR2_MS2_99f5b1bd:

    # MC "(Her pussy is clamping down around my cock! I can feel each orgasmic contraction rippling around my shaft!)"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:697
translate chinese LiR2_MS2_e6606005:

    # Yazmin "*GASP* Spread my pussy, Liza! Spread it! Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:699
translate chinese LiR2_MS2_1f4aab86_1:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:701
translate chinese LiR2_MS2_e51b06ba:

    # Yazmin "Spread my fucking pussy! I want him to see how fucking wet I am when he fucks me!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:705
translate chinese LiR2_MS2_fb313bb9:

    # Yazmin "Ah! Oh God! Yes!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:707
translate chinese LiR2_MS2_c99f403b:

    # MC "Hnnng! Ugh! Ohh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:709
translate chinese LiR2_MS2_a3abe997:

    # Yazmin "Plow your cock deep into my pussy! I want to feel you deep inside me!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:713
translate chinese LiR2_MS2_73aa6b9b:

    # Yazmin "Ah! AHHHH! YESSSS! OHHHH MY GOD!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:715
translate chinese LiR2_MS2_f068cb8d:

    # Liza "(She’s really into this! Her wetness is leaking all over my fingers!)"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:717
translate chinese LiR2_MS2_1f4aab86_2:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:720
translate chinese LiR2_MS2_da503ab2:

    # Liza "(And my own pussy is still dripping wet too... I haven’t climaxed that hard in YEARS!)"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:722
translate chinese LiR2_MS2_2b4546d3:

    # Liza "(Although, I’m not sure whether it was [player_name]’s cock or the fact that Yazmin had been edging me for FOREVER!)"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:726
translate chinese LiR2_MS2_ce7892a7:

    # Yazmin "*Pant* Are you going to finish inside me, [player_name]? Tell me you’re going to cum inside me!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:728
translate chinese LiR2_MS2_c532dc07:

    # MC "Hnnng! *Pant* I’m gonna cum inside you!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:730
translate chinese LiR2_MS2_e449bdc7:

    # Yazmin "Tell me you’re gonna fill me up!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:734
translate chinese LiR2_MS2_2c023d75:

    # MC "Arrghh! I’m gonna fill you up with my *Pant* hot cum!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:736
translate chinese LiR2_MS2_6e95af5e:

    # Yazmin "Yes! *Gasp* Ohhh!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:740
translate chinese LiR2_MS2_0041c521:

    # Yazmin "AYAAAHHHHHHH!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:742
translate chinese LiR2_MS2_025ceba1:

    # Liza "Go on, [player_name]. Blow your load deep inside her body. Empty your balls into her soaking wet fuckhole."
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:744
translate chinese LiR2_MS2_b6dae9ef:

    # Yazmin "AHHH! AAAHHHHHH!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:747
translate chinese LiR2_MS2_7b2edbbb:

    # Yazmin "*GASP* Ah! AHHH! AHHHH! I’M CUMMMING!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:749
translate chinese LiR2_MS2_bac1883e:

    # MC "Uh! Ohh! Mmm!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:753
translate chinese LiR2_MS2_fab2ced8:

    # Yazmin "Yes! Yes! Fuck me harder! AAHHHHH!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:755
translate chinese LiR2_MS2_0c1f9a69:

    # Liza "You can go faster than that, [player_name]. Give it all you’ve got!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:757
translate chinese LiR2_MS2_5fd458bc:

    # MC "Arrgh! *Pant* Ugh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:761
translate chinese LiR2_MS2_81bac1b9:

    # Liza "That’s it! Make her cum! Force her to cum harder than she’s ever came in her life!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:763
translate chinese LiR2_MS2_b6dae9ef_1:

    # Yazmin "AHHH! AAAHHHHHH!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:767
translate chinese LiR2_MS2_77123216:

    # Yazmin "OooOOOOOhhhhHHHHHH!!!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:769
translate chinese LiR2_MS2_000752f6:

    # MC "HNNNGGG!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:771
translate chinese LiR2_MS2_0041c521_1:

    # Yazmin "AYAAAHHHHHHH!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:774
translate chinese LiR2_MS2_d873ab61:

    # Liza "Do it, [player_name]. Flood her womb with your cum. Fill her up with every last drop you have."
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:776
translate chinese LiR2_MS2_138e819d:

    # Yazmin "AH! AH! AHHHHH! AH! OHHHH! AHHHHH!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:782
translate chinese LiR2_MS2_5f4a8038:

    # Yazmin "Ah! AHhhhh! YESSSS! I’m cumming!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:783
translate chinese LiR2_MS2_a8872f69:

    # MC "HNNNGGG! ME TOOO!!!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:787
translate chinese LiR2_MS2_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:789
translate chinese LiR2_MS2_1e2c89f0:

    # Yazmin "*GASP* Oh my GOD! I can feel it! OHHHHHH! It’s SOOOOOO warm inside me!!!!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:791
translate chinese LiR2_MS2_e72e64d5:

    # MC "Hnnnnggg!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:793
translate chinese LiR2_MS2_dd15c407:

    # Yazmin "*Pant* Ohhhh! *Pant* Aahhhh..."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:802
translate chinese LiR2_MS2_9a88fffc:

    # MC "*Pant* Wow... Oh... That was amazing."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:804
translate chinese LiR2_MS2_4bd732d3:

    # Liza "Huh? Did you actually cum?"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:809
translate chinese LiR2_MS2_99b1c40a:

    # Liza "Oh! There it is! I wasn’t expecting it to take a while to leak out afterwards."
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:811
translate chinese LiR2_MS2_4f826ee3:

    # Yazmin "Ha... *Pant* Ha... That was... phenomenal..."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:818
translate chinese LiR2_MS2_187bec40:

    # MC "Hnnnng! Fuck! I’m about to cum! I’m gonna pull out!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:822
translate chinese LiR2_MS2_7f6d136c:

    # Liza "Huh?"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:824
translate chinese LiR2_MS2_df00e459:

    # MC "OHHHHH!! Mmmmm! Fuck! I’m cumming!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:834
translate chinese LiR2_MS2_799a8e83:

    # Liza "Oh my God!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:837
translate chinese LiR2_MS2_5d9bcaa1:

    # Yazmin "*Pant* Wow! That’s a LOT!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:839
translate chinese LiR2_MS2_a98931c0:

    # Liza "Maybe having him finish inside you wasn’t a good idea after all! That’s A LOT of semen!"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:841
translate chinese LiR2_MS2_e59e8a9c:

    # Yazmin "Yeah! I kinda agree!"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:847
translate chinese LiR2_MS2_con_2083bd7c:

    # Liza "Aahhh.... That was... amazing."
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:849
translate chinese LiR2_MS2_con_984defaa:

    # Yazmin "I’m glad you enjoyed it, Darling."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:851
translate chinese LiR2_MS2_con_68457b2f:

    # Liza "We should do this again sometime. I want... to be tied up... to a chair again... and have you... fuck him... while I... *Snore*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:855
translate chinese LiR2_MS2_con_88c7ef7e:

    # Yazmin "*Whispered* I think that’s her done for the day. Are you alright seeing yourself out?"
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:857
translate chinese LiR2_MS2_con_7a6223f6:

    # MC "Yeah, no problem."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:859
translate chinese LiR2_MS2_con_1c68c6f7:

    # Liza "*Snore*"
    Liza ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:863
translate chinese LiR2_MS2_con_c2a09244:

    # Yazmin "*Whispered* Thanks again for coming over and indulging my wife’s fantasies."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:865
translate chinese LiR2_MS2_con_eee73124:

    # MC "*Whispered* I think I was indulging YOUR fantasies too."
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:867
translate chinese LiR2_MS2_con_a5b13e8c:

    # Yazmin "Hehe, perhaps."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:871
translate chinese LiR2_MS2_con_ef4d6157:

    # Yazmin "*Whispered* See ya later, [player_name]."
    Yazmin ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:873
translate chinese LiR2_MS2_con_d969fdd7:

    # MC "Bye Auntie Yazmin!"
    MC ""

# game/scripts/Li_R2/3_LiR2_MS2.rpy:875
translate chinese LiR2_MS2_con_b19bc798:

    # MC "Bye Yazmin!"
    MC ""

translate chinese strings:

    # game/scripts/Li_R2/3_LiR2_MS2.rpy:778
    old "Finish deep inside Yazmin’s pussy."
    new ""

    # game/scripts/Li_R2/3_LiR2_MS2.rpy:778
    old "Pull out and blow your load over Yazmin’s belly."
    new ""

