﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Judy_Home/Ju_entrance.rpy:19
translate chinese Ju_entrance_closed_de001821:

    # MC "(I shouldn't go in there now.)"
    MC ""

