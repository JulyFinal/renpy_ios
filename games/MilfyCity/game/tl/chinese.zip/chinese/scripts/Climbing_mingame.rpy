﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Climbing_mingame.rpy:44
translate chinese Climbing_start0_e7af5e18:

    # MC "(I've been in their bedroom today.)"
    MC ""

# game/scripts/Climbing_mingame.rpy:53
translate chinese Climbing_start0_08b3ba65:

    # MC "(I've already been there today.)"
    MC ""

