﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R5_last.rpy:57
translate chinese ML_R5_last_D_9414d28f:

    # MC "(I always thought that Linda’s office looked like such a depressing place to work.)"
    MC ""

# game/scripts/ML_R5_last.rpy:58
translate chinese ML_R5_last_D_854f70aa:

    # MC "(Grey carpets, grey walls, grey blinds, grey pottery...)"
    MC ""

# game/scripts/ML_R5_last.rpy:60
translate chinese ML_R5_last_D_a9895b0c:

    # MC "(I can see why Linda turned her attention to me. This corporate career seems completely and utterly soul-destroying.)"
    MC ""

# game/scripts/ML_R5_last.rpy:61
translate chinese ML_R5_last_D_cd968570:

    # MC "(She really needed a little excitement in her life!)"
    MC ""

# game/scripts/ML_R5_last.rpy:63
translate chinese ML_R5_last_D_5c5d8d5d:

    # MC "Hey there, Linda! I’m not interrupting anything, am I?"
    MC ""

# game/scripts/ML_R5_last.rpy:64
translate chinese ML_R5_last_D_a20cefa7:

    # "..."
    ""

# game/scripts/ML_R5_last.rpy:65
translate chinese ML_R5_last_D_0eb93fbd:

    # MC "Hello? Linda?"
    MC ""

# game/scripts/ML_R5_last.rpy:67
translate chinese ML_R5_last_D_f325507d:

    # Linda "Oh! Hi Sweetie! Sorry, I was a million miles away, there."
    Linda ""

# game/scripts/ML_R5_last.rpy:69
translate chinese ML_R5_last_D_c1ebe943:

    # MC "Busy day?"
    MC ""

# game/scripts/ML_R5_last.rpy:70
translate chinese ML_R5_last_D_a96760de:

    # Linda "Pretty stressful. Another big merger is coming up and I’m coordinating the retention of critical staff."
    Linda ""

# game/scripts/ML_R5_last.rpy:72
translate chinese ML_R5_last_D_be45a198:

    # MC "That just sounds like corporate speak for “I’m deciding who we shouldn’t fire.”"
    MC ""

# game/scripts/ML_R5_last.rpy:73
translate chinese ML_R5_last_D_dff99c6c:

    # Linda "Pretty much. If we’re rolling two businesses into a single entity, then we don’t really need two Heads of Marketing."
    Linda ""

# game/scripts/ML_R5_last.rpy:75
translate chinese ML_R5_last_D_bef4b763:

    # MC "Ugh... I don’t envy you. Sounds like it involves some really awkward conversations."
    MC ""

# game/scripts/ML_R5_last.rpy:76
translate chinese ML_R5_last_D_bfb3d6fc:

    # Linda "It can get pretty rough at times."
    Linda ""

# game/scripts/ML_R5_last.rpy:78
translate chinese ML_R5_last_D_c383d99c:

    # Linda "I’m a tough cookie though. You don’t get to where I am without thick skin."
    Linda ""

# game/scripts/ML_R5_last.rpy:79
translate chinese ML_R5_last_D_ff9dc578:

    # Linda "Now, what was it you wanted to talk to me about?"
    Linda ""

# game/scripts/ML_R5_last.rpy:81
translate chinese ML_R5_last_D_f7de5989:

    # MC "I was actually just walking through town and thought I’d drop by to say hello!"
    MC ""

# game/scripts/ML_R5_last.rpy:82
translate chinese ML_R5_last_D_10d0c71c:

    # Linda "Oh, that’s very sweet of you."
    Linda ""

# game/scripts/ML_R5_last.rpy:84
translate chinese ML_R5_last_D_c1ba5211:

    # Linda "Thank you, [player_name]."
    Linda ""

# game/scripts/ML_R5_last.rpy:85
translate chinese ML_R5_last_D_2ac3f80c:

    # Linda "I’m too busy right now to properly chat, but we can hang out when I get back home. Does that sound okay?"
    Linda ""

# game/scripts/ML_R5_last.rpy:87
translate chinese ML_R5_last_D_f926f00a:

    # MC "Sure. Absolutely, Linda. I’ll catch you then."
    MC ""

# game/scripts/ML_R5_last.rpy:88
translate chinese ML_R5_last_D_c100848b:

    # Linda "Thanks for dropping by, Sweetie. You really brightened up my day."
    Linda ""

# game/scripts/ML_R5_last.rpy:90
translate chinese ML_R5_last_D_19053689:

    # MC "(I can’t imagine that’s a difficult thing to do, in an office as drab as this.)"
    MC ""

# game/scripts/ML_R5_last.rpy:92
translate chinese ML_R5_last_D_3c4acbad:

    # MC "I’ll see you back at home, Linda. Love you!"
    MC ""

# game/scripts/ML_R5_last.rpy:93
translate chinese ML_R5_last_D_6ddce77e:

    # Linda "I love you too, Sweetie."
    Linda ""

# game/scripts/ML_R5_last.rpy:103
translate chinese ML_R5_last_D_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/ML_R5_last.rpy:119
translate chinese ML_R5_last_E_2bbdc13d:

    # MC "(Looks like she’s just chilling out tonight.)"
    MC ""

# game/scripts/ML_R5_last.rpy:121
translate chinese ML_R5_last_E_c5ec3065:

    # MC "Morning Linda, what’s up?"
    MC ""

# game/scripts/ML_R5_last.rpy:123
translate chinese ML_R5_last_E_b467600a:

    # Linda "Oh! Hey, [player_name]. I didn’t realise you were home."
    Linda ""

# game/scripts/ML_R5_last.rpy:124
translate chinese ML_R5_last_E_893dcf5a:

    # Linda "I’m not doing much. Just relaxing and waiting for paracetamol to kick in. Work was crazy today."
    Linda ""

# game/scripts/ML_R5_last.rpy:126
translate chinese ML_R5_last_E_e8482b84:

    # MC "Ugh, sorry to hear it."
    MC ""

# game/scripts/ML_R5_last.rpy:127
translate chinese ML_R5_last_E_1718acfd:

    # Linda "Anyway, enough about me. What’s on your mind?"
    Linda ""

# game/scripts/ML_R5_last.rpy:128
translate chinese ML_R5_last_E_63025cc6:

    # MC "I was wondering how Bob’s doing."
    MC ""

# game/scripts/ML_R5_last.rpy:130
translate chinese ML_R5_last_E_199a12b5:

    # Linda "Honestly, he seems fine to me. Happier than he used to be, that’s for certain!"
    Linda ""

# game/scripts/ML_R5_last.rpy:131
translate chinese ML_R5_last_E_84197d1e:

    # MC "That’s good to hear."
    MC ""

# game/scripts/ML_R5_last.rpy:132
translate chinese ML_R5_last_E_0f83466d:

    # Linda "In fact, I could have sworn I saw him driving around the city yesterday with another woman in his car."
    Linda ""

# game/scripts/ML_R5_last.rpy:133
translate chinese ML_R5_last_E_21b53e56:

    # MC "Really?! That doesn’t bother you?"
    MC ""

# game/scripts/ML_R5_last.rpy:135
translate chinese ML_R5_last_E_e9a947e7:

    # Linda "Doesn’t bother me at all! I’m happy for the man. Hope he manages to find some happiness like the kind I found with you."
    Linda ""

# game/scripts/ML_R5_last.rpy:136
translate chinese ML_R5_last_E_f9959ce6:

    # MC "Aww, I’m really glad to hear that."
    MC ""

# game/scripts/ML_R5_last.rpy:138
translate chinese ML_R5_last_E_15902c58:

    # MC "Speaking of which... are you up for doing something right now?"
    MC ""

# game/scripts/ML_R5_last.rpy:139
translate chinese ML_R5_last_E_5658acb9:

    # Linda "I’m still exhausted from work, but how about you come visit me tonight? Or maybe give me a call?"
    Linda ""

# game/scripts/ML_R5_last.rpy:141
translate chinese ML_R5_last_E_fe36461c:

    # MC "Sure, I can do that. Hope your headache clears soon, Linda."
    MC ""

# game/scripts/ML_R5_last.rpy:142
translate chinese ML_R5_last_E_13d26a58:

    # Linda "You and me both!"
    Linda ""

# game/scripts/ML_R5_last.rpy:144
translate chinese ML_R5_last_E_e517d6c7:

    # MC "I love you, Linda."
    MC ""

# game/scripts/ML_R5_last.rpy:145
translate chinese ML_R5_last_E_def30d22:

    # Linda "I love you too, sweetie."
    Linda ""

# game/scripts/ML_R5_last.rpy:147
translate chinese ML_R5_last_E_620312f2:

    # MC "Would you mind if I kissed you?"
    MC ""

# game/scripts/ML_R5_last.rpy:148
translate chinese ML_R5_last_E_f983fe12:

    # Linda "Of course not!"
    Linda ""

# game/scripts/ML_R5_last.rpy:150
translate chinese ML_R5_last_E_d4d328dc:

    # MC "(I’ll give her a call when it gets dark. Hopefully her headache will have passed by then.)"
    MC ""

# game/scripts/ML_R5_last.rpy:152
translate chinese ML_R5_last_E_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/ML_R5_last.rpy:153
translate chinese ML_R5_last_E_22751478:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R5_last.rpy:155
translate chinese ML_R5_last_E_1989226a:

    # Linda "See you tonight, [player_name]."
    Linda ""

# game/scripts/ML_R5_last.rpy:156
translate chinese ML_R5_last_E_40db26df:

    # MC "I’ll call you when I’m ready. Love you!"
    MC ""

# game/scripts/ML_R5_last.rpy:157
translate chinese ML_R5_last_E_16357ff6:

    # Linda "Love you too, sweetie."
    Linda ""

# game/scripts/ML_R5_last.rpy:166
translate chinese ML_R5_last_E_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/ML_R5_last.rpy:184
translate chinese ML_R5_last_M_d21e82ad:

    # MC "*Sniff* *Sniff*"
    MC ""

# game/scripts/ML_R5_last.rpy:185
translate chinese ML_R5_last_M_284e6b0d:

    # MC "(Mmm, something smells good! Is that freshly brewed coffee?)"
    MC ""

# game/scripts/ML_R5_last.rpy:187
translate chinese ML_R5_last_M_40ca2f07:

    # MC "(Her ass looks great in those tight white pants!)"
    MC ""

# game/scripts/ML_R5_last.rpy:189
translate chinese ML_R5_last_M_bedc1efc:

    # MC "Morning Linda! That smells great! What’re you drinking?"
    MC ""

# game/scripts/ML_R5_last.rpy:190
translate chinese ML_R5_last_M_b77ed095:

    # Linda "Oh! Morning, [player_name]!"
    Linda ""

# game/scripts/ML_R5_last.rpy:192
translate chinese ML_R5_last_M_c84c320c:

    # Linda "Just some beans Caroline brought back from her trip to Colombia last year."
    Linda ""

# game/scripts/ML_R5_last.rpy:193
translate chinese ML_R5_last_M_0593f133:

    # MC "They smell fantastic!"
    MC ""

# game/scripts/ML_R5_last.rpy:194
translate chinese ML_R5_last_M_1f8643b5:

    # Linda "Mmm, they’re actually pretty great."
    Linda ""

# game/scripts/ML_R5_last.rpy:196
translate chinese ML_R5_last_M_91fd6584:

    # MC "So, big plans for today?"
    MC ""

# game/scripts/ML_R5_last.rpy:197
translate chinese ML_R5_last_M_2e124661:

    # Linda "Not particularly. I’ll work, clean up around the house, maybe go for a jog later. What about you?"
    Linda ""

# game/scripts/ML_R5_last.rpy:199
translate chinese ML_R5_last_M_738ca81f:

    # MC "Oh, I don’t know. Might visit the town, come back home, fuck the hottest milf in the whole city."
    MC ""

# game/scripts/ML_R5_last.rpy:200
translate chinese ML_R5_last_M_d19711da:

    # Linda "Ha ha. Very funny."
    Linda ""

# game/scripts/ML_R5_last.rpy:202
translate chinese ML_R5_last_M_22be7acd:

    # Linda "If you ever get horny and want to spend some time together, just drop by and let me know."
    Linda ""

# game/scripts/ML_R5_last.rpy:203
translate chinese ML_R5_last_M_e9c74399:

    # Linda "It’s sooo much more relaxing now that we don’t have to hide our relationship from Bob, isn’t it?"
    Linda ""

# game/scripts/ML_R5_last.rpy:205
translate chinese ML_R5_last_M_f66f3a33:

    # MC "Mmm... Much better."
    MC ""

# game/scripts/ML_R5_last.rpy:206
translate chinese ML_R5_last_M_67dcd968:

    # Linda "So, am I going to be seeing you tonight? You can always drop by my room if you want."
    Linda ""

# game/scripts/ML_R5_last.rpy:208
translate chinese ML_R5_last_M_b7bbc377:

    # MC "I think so. I’ll see how tired I’m feeling later on."
    MC ""

# game/scripts/ML_R5_last.rpy:209
translate chinese ML_R5_last_M_2afc61cf:

    # Linda "Well, enjoy the rest of your day, [player_name]. I better finish this coffee and get to work before rush hour traffic hits."
    Linda ""

# game/scripts/ML_R5_last.rpy:211
translate chinese ML_R5_last_M_034a5aa2:

    # MC "No problem, Linda. I won’t keep you!"
    MC ""

# game/scripts/ML_R5_last.rpy:212
translate chinese ML_R5_last_M_8f2f9eed:

    # Linda "Swing by the office if you have some free time. I love it when you call in to visit me."
    Linda ""

# game/scripts/ML_R5_last.rpy:214
translate chinese ML_R5_last_M_64165b50:

    # MC "Sure, Linda! I’ll catch you later."
    MC ""

# game/scripts/ML_R5_last.rpy:215
translate chinese ML_R5_last_M_d2b60328:

    # Linda "Love you, Sweetie."
    Linda ""

# game/scripts/ML_R5_last.rpy:217
translate chinese ML_R5_last_M_4d5588f1:

    # MC "Love you too, Linda!"
    MC ""

# game/scripts/ML_R5_last.rpy:218
translate chinese ML_R5_last_M_aec8fdd4:

    # Linda "*Sip*"
    Linda ""

# game/scripts/ML_R5_last.rpy:219
translate chinese ML_R5_last_M_2dfde3b1:

    # Mom "Ahh... Before you leave... Would you like me to come to your room tonight?"
    Mom ""

# game/scripts/ML_R5_last.rpy:225
translate chinese ML_R5_last_M_8dd7f9fa:

    # MC "Yes, please!"
    MC ""

# game/scripts/ML_R5_last.rpy:227
translate chinese ML_R5_last_M_74658ac7:

    # Mom "Okay, I’ll see you tonight, Dear."
    Mom ""

# game/scripts/ML_R5_last.rpy:229
translate chinese ML_R5_last_M_0ade1347:

    # Mom "Okay, I’ll see you tonight, Honey. "
    Mom ""

# game/scripts/ML_R5_last.rpy:241
translate chinese ML_R5_last_M_d16a9aed:

    # MC "Not today. I’m a bit tired, Mom."
    MC ""

# game/scripts/ML_R5_last.rpy:243
translate chinese ML_R5_last_M_f0fd54af:

    # MC "Not today. I’m a bit tired, Linda."
    MC ""

# game/scripts/ML_R5_last.rpy:244
translate chinese ML_R5_last_M_04050859:

    # Mom "Aww, that’s okay. I understand. I hope, tommorow you'll change your mind."
    Mom ""

# game/scripts/ML_R5_last.rpy:255
translate chinese ML_R5_last_M_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

translate chinese strings:

    # game/scripts/ML_R5_last.rpy:222
    old "Not today"
    new ""

