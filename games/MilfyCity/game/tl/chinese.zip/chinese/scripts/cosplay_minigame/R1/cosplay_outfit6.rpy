﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R1/cosplay_outfit6.rpy:109
translate chinese outfit6_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit6.rpy:110
translate chinese outfit6_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit6.rpy:205
translate chinese outfit6_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit6.rpy:206
translate chinese outfit6_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

