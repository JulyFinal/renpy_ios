﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:15
translate chinese cosplay_outfit5_label_23b19598:

    # Caroline "Umm... I’m going to change here. But..."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:16
translate chinese cosplay_outfit5_label_7e165438:

    # MC "Are you okay, Caroline?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:17
translate chinese cosplay_outfit5_label_3946d615:

    # Caroline "Yeah, it’s just... this outfit is rather... lewd."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:18
translate chinese cosplay_outfit5_label_a0a0d495:

    # Caroline "I’m not sure if it’s too naughty for you to see."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:19
translate chinese cosplay_outfit5_label_84c052b1:

    # MC "Relax - I don’t mind. It’s just for a photo session."
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:20
translate chinese cosplay_outfit5_label_b2e394c3:

    # Caroline "A-Are you sure?"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:21
translate chinese cosplay_outfit5_label_63873555:

    # MC "Absolutely!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:24
translate chinese cosplay_outfit5_label_ad00d55b:

    # Caroline "Next up, I’m proudly presenting the Purple Bunny!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:25
translate chinese cosplay_outfit5_label_4fd2d98e:

    # Caroline "She’s a magical girl and a proud fighter for truth and justice!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:26
translate chinese cosplay_outfit5_label_1f67fdb5:

    # MC "Now THAT’s an interesting costume!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:27
translate chinese cosplay_outfit5_label_47888c0f:

    # Caroline "Another expensive one - I had to import these from Japan this time."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:28
translate chinese cosplay_outfit5_label_63f440e5:

    # Caroline "I’m trying to cover as many different market niches as I can - and the lewd superheroine is one that hasn’t been touched upon much."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:29
translate chinese cosplay_outfit5_label_f4612045:

    # MC "It looks great on you! I’m sure they will sell like hotcakes!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:30
translate chinese cosplay_outfit5_label_6bdfc28e:

    # Caroline "Aww, thanks!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:127
translate chinese outfit5_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:128
translate chinese outfit5_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:226
translate chinese outfit5_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit5.rpy:227
translate chinese outfit5_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

