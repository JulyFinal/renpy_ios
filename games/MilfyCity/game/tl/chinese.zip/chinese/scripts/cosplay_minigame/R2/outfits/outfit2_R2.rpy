﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:17
translate chinese outfit2_R2_label_8388d470:

    # Caroline "This one is... a little embarrassing. I haven’t dressed up as a cheerleader since high school!"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:18
translate chinese outfit2_R2_label_b9916368:

    # MC "Really? I think you’re rocking the look right now!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:19
translate chinese outfit2_R2_label_583bb793:

    # Caroline "Aww... aren’t you sweet."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:20
translate chinese outfit2_R2_label_8c246cde:

    # MC "Okay, strike a pose and we’ll get started!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:120
translate chinese outfit2_R2_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:121
translate chinese outfit2_R2_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:227
translate chinese outfit2_R2_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit2_R2.rpy:228
translate chinese outfit2_R2_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

