﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:16
translate chinese outfit4_R2_label_2df092e6:

    # Caroline "Hmm... Feel free to put away the camera."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:17
translate chinese outfit4_R2_label_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:18
translate chinese outfit4_R2_label_e5936e15:

    # Caroline "This one... um... doesn’t fit properly."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:19
translate chinese outfit4_R2_label_5d9d5c7c:

    # MC "I’m sure it’ll be fine!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:20
translate chinese outfit4_R2_label_681d2337:

    # Caroline "I... It’s really not."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:21
translate chinese outfit4_R2_label_d4e5391b:

    # MC "Oh, come on! How bad can it be?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:25
translate chinese outfit4_R2_label_96a48f19:

    # MC "Holy shit!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:26
translate chinese outfit4_R2_label_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:27
translate chinese outfit4_R2_label_75ba63c7:

    # MC "That is... Wow!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:28
translate chinese outfit4_R2_label_6286b519:

    # MC "I mean... holy fucking shit!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:29
translate chinese outfit4_R2_label_16b6479e:

    # Caroline "God... this is so embarrassing."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:30
translate chinese outfit4_R2_label_79d28975:

    # MC "No! It’s awesome! You’ll sell shit-loads of these when people see you online, modelling it!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:31
translate chinese outfit4_R2_label_ddc73aad:

    # Caroline "Y-You really think so?"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:32
translate chinese outfit4_R2_label_46252668:

    # MC "Absolutely! Now act confident, lean in, and smile for the camera!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:132
translate chinese outfit4_R2_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:133
translate chinese outfit4_R2_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:237
translate chinese outfit4_R2_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit4_R2.rpy:238
translate chinese outfit4_R2_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

