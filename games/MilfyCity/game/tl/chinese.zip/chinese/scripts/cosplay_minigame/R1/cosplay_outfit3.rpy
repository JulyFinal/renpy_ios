﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:15
translate chinese cosplay_outfit3_label_ccd69cc6:

    # Caroline "Next up, we have a rather risque number - the naughty schoolgirl!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:16
translate chinese cosplay_outfit3_label_ff17e058:

    # MC "Excellent choice! The stockings look great on you too."
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:17
translate chinese cosplay_outfit3_label_6130d9ed:

    # Caroline "Aww, thanks, [player_name]."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:18
translate chinese cosplay_outfit3_label_9b6b94d8:

    # Caroline "It’s a little on the lewd side - but I think that’s what people want nowadays."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:19
translate chinese cosplay_outfit3_label_68d33c77:

    # MC "Yeah, you’re probably right there. If I had a girlfriend, I’d buy her that outfit!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:20
translate chinese cosplay_outfit3_label_a93088f1:

    # Caroline "Eww! Haha! I really don’t need to hear about your sexual fantasies, [player_name]!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:121
translate chinese outfit3_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:122
translate chinese outfit3_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:226
translate chinese outfit3_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit3.rpy:227
translate chinese outfit3_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

