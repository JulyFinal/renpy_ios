﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:14
translate chinese outfit1_R2_label_e4b5d049:

    # Caroline "Well? What do you think?"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:15
translate chinese outfit1_R2_label_e25556a0:

    # MC "It’s pretty cool! Not as sexy or slutty as your other costumes though."
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:16
translate chinese outfit1_R2_label_902b18e7:

    # Caroline "Yeah, I thought I needed to expand my market. If I can get regulars walking through the door, as well as pervs, then it’ll help increase my profits."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:17
translate chinese outfit1_R2_label_263ed0ae:

    # MC "Makes sense to me!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:18
translate chinese outfit1_R2_label_7fe6b75c:

    # Caroline "Okay! Are you ready to take some pictures?"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:19
translate chinese outfit1_R2_label_db00bfd0:

    # MC "I sure am!"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:118
translate chinese outfit1_R2_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:119
translate chinese outfit1_R2_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:225
translate chinese outfit1_R2_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit1_R2.rpy:226
translate chinese outfit1_R2_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

