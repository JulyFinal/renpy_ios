﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:17
translate chinese outfit3_R2_label_26b03fc0:

    # Caroline "This next one is a little peculiar, but I figured I may as well stock some more outlandish costumes too."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:18
translate chinese outfit3_R2_label_5709a07c:

    # MC "Is that a... sexy builder?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:19
translate chinese outfit3_R2_label_c4b0cb1b:

    # Caroline "You got it!"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:20
translate chinese outfit3_R2_label_f8400308:

    # MC "(Her cleavage looks fucking awesome!)"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:21
translate chinese outfit3_R2_label_97eb4b91:

    # Caroline "Ready to start taking pictures?"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:22
translate chinese outfit3_R2_label_8a42ed7b:

    # MC "(I’d love to rub my cock between those breasts and-)"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:23
translate chinese outfit3_R2_label_cae5682b:

    # Caroline "Hello? [player_name]?"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:24
translate chinese outfit3_R2_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:25
translate chinese outfit3_R2_label_348d3cf8:

    # Caroline "I said, are you ready to start taking pictures?"
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:26
translate chinese outfit3_R2_label_f93d45ad:

    # MC "Oh! Yeah! I was just... uh... waiting for the camera to load."
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:125
translate chinese outfit3_R2_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:126
translate chinese outfit3_R2_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:230
translate chinese outfit3_R2_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R2/outfits/outfit3_R2.rpy:231
translate chinese outfit3_R2_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

