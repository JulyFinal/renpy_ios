﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R3/outfit_R3.rpy:298
translate chinese outfit_R3_rotate_a13ac530:

    # MC "Can we change position, Caroline?"
    MC ""

# game/scripts/cosplay_minigame/R3/outfit_R3.rpy:299
translate chinese outfit_R3_rotate_42b8aad3:

    # Caroline "Sure."
    Caroline ""

