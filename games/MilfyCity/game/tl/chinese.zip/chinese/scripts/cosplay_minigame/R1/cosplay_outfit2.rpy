﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:15
translate chinese cosplay_outfit2_label_901d786e:

    # Caroline "Bonjour, Monsieur [player_name]. Ça va?"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:16
translate chinese cosplay_outfit2_label_43bf4758:

    # MC "Ça va très bien!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:17
translate chinese cosplay_outfit2_label_ace495e3:

    # Caroline "I figured that this cute little French maid number would sell well."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:18
translate chinese cosplay_outfit2_label_e5f64c13:

    # MC "(The short skirt and kneesocks are a nice addition! She’s got really sexy thighs!)"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:120
translate chinese outfit2_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:121
translate chinese outfit2_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:225
translate chinese outfit2_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit2.rpy:226
translate chinese outfit2_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

