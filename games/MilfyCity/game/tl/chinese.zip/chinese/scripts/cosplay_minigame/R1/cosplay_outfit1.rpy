﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:15
translate chinese cosplay_outfit1_label_e4b5d049:

    # Caroline "Well? What do you think?"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:16
translate chinese cosplay_outfit1_label_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:17
translate chinese cosplay_outfit1_label_bda98b25:

    # MC "(I’m not even sure what she’s cosplaying as - but she looks amazing!)"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:18
translate chinese cosplay_outfit1_label_7ab497b1:

    # Caroline "Do you think it’ll sell well? Any ideas for how to market it?"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:19
translate chinese cosplay_outfit1_label_16750d51:

    # MC "Yeah, it will! Umm, you could maybe try selling some sets around Valentine’s Day."
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:20
translate chinese cosplay_outfit1_label_b286dc17:

    # Caroline "Perfect! I’ll make sure to order extra stock for February then."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:123
translate chinese outfit1_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:124
translate chinese outfit1_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:228
translate chinese outfit1_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit1.rpy:229
translate chinese outfit1_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

