﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:15
translate chinese cosplay_outfit4_label_2ed5f339:

    # Caroline "I noticed this one while I was ordering the maid costumes from the French retailer."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:16
translate chinese cosplay_outfit4_label_58f3c38e:

    # Caroline "It kind of has a Moulin Rouge vibe to it. Couldn’t resist picking up half a dozen!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:17
translate chinese cosplay_outfit4_label_a2be13c2:

    # MC "Yeah, this’ll sell too. How much does each of those cost? It looks like a fairly expensive material!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:18
translate chinese cosplay_outfit4_label_b0f73694:

    # Caroline "They’re from a boutique designer - so each full outfit goes for, slightly over $600."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:19
translate chinese cosplay_outfit4_label_65f96d00:

    # MC "$600?!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:20
translate chinese cosplay_outfit4_label_629f346e:

    # Caroline "And that’s with me making a fifteen percent profit margin on each."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:21
translate chinese cosplay_outfit4_label_ed022efe:

    # MC "Jeez!"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:22
translate chinese cosplay_outfit4_label_d60e6971:

    # Caroline "So yeah, I REALLY need these to sell! Haha!"
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:123
translate chinese outfit4_rotate1_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:124
translate chinese outfit4_rotate1_42b8aad3:

    # Caroline "Sure."
    Caroline ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:228
translate chinese outfit4_rotate2_19f9ee76:

    # MC "Can you turn around?"
    MC ""

# game/scripts/cosplay_minigame/R1/cosplay_outfit4.rpy:229
translate chinese outfit4_rotate2_42b8aad3:

    # Caroline "Sure."
    Caroline ""

