﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:21
translate chinese Zv2_MS1_label_84b68a82:

    # Zuri "Hello, and welcome to Bayside Business Consultants. My name is Zuri. How can I help you?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:29
translate chinese Zv2_MS1_label_5502d6c2:

    # MC "(Wow! That must be Dad’s secretary! She’s REALLY hot!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:30
translate chinese Zv2_MS1_label_78dae213:

    # MC "Hi, Zuri. My name is [player_name]. I was coming to visit my dad."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:31
translate chinese Zv2_MS1_label_83af3485:

    # Zuri "And who is your dad?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:33
translate chinese Zv2_MS1_label_02db6997:

    # MC "(Wow! That must be Bob’s secretary! She’s REALLY hot!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:34
translate chinese Zv2_MS1_label_4a7d95fa:

    # MC "Hi, Zuri. My name is [player_name]. I was coming to visit my landlord, Bob."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:35
translate chinese Zv2_MS1_label_7a5596e1:

    # Zuri "Bob who?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:36
translate chinese Zv2_MS1_label_cda1ab18:

    # MC "Uhh... The one who runs this company?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:40
translate chinese Zv2_MS1_label_27b87d8c:

    # Zuri "Ahahaha! How funny!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:41
translate chinese Zv2_MS1_label_704c04fc:

    # Zuri "Let me guess - you’re with one of those online prank videos, aren’t you?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:42
translate chinese Zv2_MS1_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:43
translate chinese Zv2_MS1_label_9de63d65:

    # Zuri "You’ve got a secret camera and you’re going to humiliate the boss and put it online?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:45
translate chinese Zv2_MS1_label_c8bd7ced:

    # MC "No- What?! I AM actually his son."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:47
translate chinese Zv2_MS1_label_3fcc064c:

    # MC "No- What?! I’m actually his tenant. I just came to check out the business. Maybe give me an idea of what work will be like after I graduate."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:51
translate chinese Zv2_MS1_label_578f2027:

    # Zuri "Really?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:52
translate chinese Zv2_MS1_label_3d2bc4b3:

    # MC "Yes!"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:53
translate chinese Zv2_MS1_label_3488a648:

    # Zuri "Oh! Sorry! My bad!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:62
translate chinese Zv2_MS1_label2_e30f5081:

    # Zuri "Hello, and welcome to Bayside Business Consultants."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:63
translate chinese Zv2_MS1_label2_d844fa26:

    # MC "There is someone in the office?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:66
translate chinese Zv2_MS1_label2_92b47494:

    # Zuri "Please follow me. I’ll take you to your Dad's office."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:68
translate chinese Zv2_MS1_label2_3046b659:

    # Zuri "Please follow me. I’ll take you to Bob's office."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:69
translate chinese Zv2_MS1_label2_55952d17:

    # MC "Thank you."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:74
translate chinese Zv2_MS1_label2_652f6247:

    # Zuri "In that case - please follow me. I’ll take you to his office."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:75
translate chinese Zv2_MS1_label2_0a1517ff:

    # MC "(Finally!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:76
translate chinese Zv2_MS1_label2_55952d17_1:

    # MC "Thank you."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:80
translate chinese Zv2_MS1_label3_ed804c4d:

    # Zuri "Now, I do have to warn you - he is rather busy today, so you might not be able to stay with him for too long."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:81
translate chinese Zv2_MS1_label3_57a6d09b:

    # Zuri "The company is going through a very delicate restructuring of our contracts right now."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:82
translate chinese Zv2_MS1_label3_f5f96d00:

    # MC "I see. That’s not a problem."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:86
translate chinese Zv2_MS1_label3_57399775:

    # "*Knock Knock Knock*"
    ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:88
translate chinese Zv2_MS1_label3_29a058fa:

    # Zuri "Sir? I have a visitor for you."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:89
translate chinese Zv2_MS1_label3_dc90826b:

    # Dad "Who is it?"
    Dad ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:90
translate chinese Zv2_MS1_label3_de87a27f:

    # MC "(She’s got such a short skirt on! Maybe I could steal a chance to peek at her panties?)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:96
translate chinese Zv2_MS1_label3_c1b81787:

    # MC "(Oh, very nice!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:97
translate chinese Zv2_MS1_label3_93c1e701:

    # MC "(Those panties are sooo thin. They barely cover anything!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:99
translate chinese Zv2_MS1_label3_0998a35f:

    # MC "(I’d love to get into that ass! But there’s fat chance of that happening - she’s Dad’s secretary!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:101
translate chinese Zv2_MS1_label3_81a78e4c:

    # MC "(I’d love to get into that ass! But there’s fat chance of that happening - she’s Bob’s secretary!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:108
translate chinese Zv2_MS1_label3_e0b99713:

    # MC "(I better just play it safe. If she catches me, she’ll likely never let me visit Dad again!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:110
translate chinese Zv2_MS1_label3_bc18e453:

    # MC "(I better just play it safe. If she catches me, she’ll likely never let me visit Bob again!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:114
translate chinese Zv2_MS1_label3_858be7ac:

    # Zuri "It’s your son, Sir."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:116
translate chinese Zv2_MS1_label3_681ff27a:

    # Zuri "It’s your tennant, Sir."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:118
translate chinese Zv2_MS1_label3_5dd71fca:

    # Dad "Oh! [player_name]! Come on in!"
    Dad ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:120
translate chinese Zv2_MS1_label3_456add82:

    # Zuri "On you go, Sir. Just try not to keep your father distracted from his job for too long, please."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:122
translate chinese Zv2_MS1_label3_4de021c2:

    # Zuri "On you go, Sir. Just try not to keep my boss distracted from his job for too long, please."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:123
translate chinese Zv2_MS1_label3_184cd68c:

    # MC "I’ll be mindful of that. Thanks, Zuri."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:124
translate chinese Zv2_MS1_label3_969cdd64:

    # Zuri "My pleasure."
    Zuri ""

translate chinese strings:

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:92
    old "Bend down and peek up her skirt."
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS1.rpy:92
    old "It’s not worth the risk. Just play it safe."
    new ""

