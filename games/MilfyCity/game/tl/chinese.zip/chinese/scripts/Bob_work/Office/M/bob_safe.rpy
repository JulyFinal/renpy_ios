﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Office/M/bob_safe.rpy:40
translate chinese bob_safeopen_label_cabb541c:

    # MC "The safe is locked. I need a code."
    MC ""

# game/scripts/Bob_work/Office/M/bob_safe.rpy:48
translate chinese bob_safeopen_label_843dc291:

    # MC "Ah! Good! The code works. It’s now open."
    MC ""

# game/scripts/Bob_work/Office/M/bob_safe.rpy:96
translate chinese bob_safeopenmoney_label_d8293799:

    # MC "Nice! +[money]$"
    MC ""

# game/scripts/Bob_work/Office/M/bob_safe.rpy:106
translate chinese bob_safeopennote_label_44521c90:

    # MC "(Hmm... Some notes... There’s is also a second company name! Nice.)"
    MC ""

