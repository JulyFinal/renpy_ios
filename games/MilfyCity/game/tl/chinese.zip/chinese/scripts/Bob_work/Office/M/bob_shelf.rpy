﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:57
translate chinese bob_shelfopen_label_fde4cd81:

    # MC "I can't do it when someone is in the room."
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:109
translate chinese bob_secret_room_scene_ccd43c58:

    # MC "Huh?!"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:110
translate chinese bob_secret_room_scene_bbe4c5e3:

    # MC "(Is this a secret passageway?)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:112
translate chinese bob_secret_room_scene_33d1227a:

    # MC "(Why the hell would Dad need a hidden room?)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:114
translate chinese bob_secret_room_scene_e506d7c8:

    # MC "(Why the hell would Bob need a hidden room?)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:115
translate chinese bob_secret_room_scene_25f950c7:

    # MC "(Maybe he keeps some of his money in here.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:119
translate chinese bob_secret_room_scene_9029b9da:

    # MC "Ahhhh!"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:120
translate chinese bob_secret_room_scene_297f37c2:

    # MC "Jesus Christ! No!"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:124
translate chinese bob_secret_room_scene_7708f0f3:

    # MC "Its... It’s... He’s naked!"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:125
translate chinese bob_secret_room_scene_6d0dc69a:

    # MC "Eww! That’s revolting!"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:129
translate chinese bob_secret_room_scene_973bb136:

    # MC "(He’s getting whipped and treated like shit...)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:130
translate chinese bob_secret_room_scene_85b58f71:

    # MC "(Is someone blackmailing him?)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:131
translate chinese bob_secret_room_scene_0e2c51c4:

    # MC "(No... that doesn’t make sense. He wouldn’t keep blackmail evidence in his own office.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:135
translate chinese bob_secret_room_scene_e0af6b2c:

    # MC "(He must be into this sorta thing.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:137
translate chinese bob_secret_room_scene_381da3fc:

    # MC "(It all makes sense now! The way Mom treats him so badly...)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:139
translate chinese bob_secret_room_scene_7b9e4fb1:

    # MC "(It all makes sense now! The way Linda treats him so badly...)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:140
translate chinese bob_secret_room_scene_2e772712:

    # MC "(That explains why he hasn’t left her yet! He’s getting off on being treated like crap.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:144
translate chinese bob_secret_room_scene_c80c1915:

    # MC "(Some things should remain private. I’m just going to forget about what I saw here today.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:146
translate chinese bob_secret_room_scene_22e687a7:

    # MC "(This isn’t any of my business. I wouldn’t want Dad snooping into MY sex life.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:148
translate chinese bob_secret_room_scene_f5a062c5:

    # MC "(This isn’t any of my business. I wouldn’t want Bob snooping into my sex life.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_shelf.rpy:149
translate chinese bob_secret_room_scene_736ff727:

    # MC "(So I shouldn’t be snooping into his either.)"
    MC ""

