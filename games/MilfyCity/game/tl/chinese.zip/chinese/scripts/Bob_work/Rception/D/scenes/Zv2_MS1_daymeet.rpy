﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:16
translate chinese Zv2_MS1_daymeet_label_84b68a82:

    # Zuri "Hello, and welcome to Bayside Business Consultants. My name is Zuri. How can I help you?"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:21
translate chinese Zv2_MS1_daymeet_label_5502d6c2:

    # MC "(Wow! That must be Dad’s secretary! She’s REALLY hot!)"
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:22
translate chinese Zv2_MS1_daymeet_label_78dae213:

    # MC "Hi, Zuri. My name is [player_name]. I was coming to visit my dad."
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:23
translate chinese Zv2_MS1_daymeet_label_83af3485:

    # Zuri "And who is your dad?"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:25
translate chinese Zv2_MS1_daymeet_label_02db6997:

    # MC "(Wow! That must be Bob’s secretary! She’s REALLY hot!)"
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:26
translate chinese Zv2_MS1_daymeet_label_4a7d95fa:

    # MC "Hi, Zuri. My name is [player_name]. I was coming to visit my landlord, Bob."
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:27
translate chinese Zv2_MS1_daymeet_label_7a5596e1:

    # Zuri "Bob who?"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:28
translate chinese Zv2_MS1_daymeet_label_cda1ab18:

    # MC "Uhh... The one who runs this company?"
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:32
translate chinese Zv2_MS1_daymeet_label_27b87d8c:

    # Zuri "Ahahaha! How funny!"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:33
translate chinese Zv2_MS1_daymeet_label_704c04fc:

    # Zuri "Let me guess - you’re with one of those online prank videos, aren’t you?"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:34
translate chinese Zv2_MS1_daymeet_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:35
translate chinese Zv2_MS1_daymeet_label_9de63d65:

    # Zuri "You’ve got a secret camera and you’re going to humiliate the boss and put it online?"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:37
translate chinese Zv2_MS1_daymeet_label_c8bd7ced:

    # MC "No- What?! I AM actually his son."
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:39
translate chinese Zv2_MS1_daymeet_label_3fcc064c:

    # MC "No- What?! I’m actually his tenant. I just came to check out the business. Maybe give me an idea of what work will be like after I graduate."
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:43
translate chinese Zv2_MS1_daymeet_label_578f2027:

    # Zuri "Really?"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:44
translate chinese Zv2_MS1_daymeet_label_3d2bc4b3:

    # MC "Yes!"
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:45
translate chinese Zv2_MS1_daymeet_label_3488a648:

    # Zuri "Oh! Sorry! My bad!"
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:46
translate chinese Zv2_MS1_daymeet_label_a34806e7:

    # Zuri "I'm sorry but he's not in the office at the moment. He's only there in the mornings. Please come back tomorrow."
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:55
translate chinese Zv2_MS1_daymeet_label_e30f5081:

    # Zuri "Hello, and welcome to Bayside Business Consultants."
    Zuri ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:56
translate chinese Zv2_MS1_daymeet_label_d844fa26:

    # MC "There is someone in the office?"
    MC ""

# game/scripts/Bob_work/Rception/D/scenes/Zv2_MS1_daymeet.rpy:57
translate chinese Zv2_MS1_daymeet_label_db999436:

    # Zuri "I'm sorry but nobody is in the office at the moment. He's only there in the mornings. Please come back tomorrow."
    Zuri ""

