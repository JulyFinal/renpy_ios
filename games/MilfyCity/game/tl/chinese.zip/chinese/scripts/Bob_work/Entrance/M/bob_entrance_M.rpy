﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Entrance/M/bob_entrance_M.rpy:19
translate chinese bob_entrance_M1_4537a378:

    # MC "(It's too late to enter here.)"
    MC ""

