﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Office/M/bob_desk.rpy:115
translate chinese bob_deskbooks_label_803f3ff2:

    # MC "Those are Dad’s books."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:117
translate chinese bob_deskbooks_label_671d45ce:

    # MC "Those are Bob’s books."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:118
translate chinese bob_deskbooks_label_891d99b4:

    # MC "I guess he has a lot of free time in here."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:126
translate chinese bob_desklaptop_label_179e1438:

    # MC "Dad’s laptop. I don't need to use it right now."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:128
translate chinese bob_desklaptop_label_5de5ac43:

    # MC "Bob’s laptop. I don't need to use it right now."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:135
translate chinese bob_deskpapers_label_322266ed:

    # MC "Meh.. Just papers. Some boring work stuff."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:145
translate chinese bob_deskraports_label_bfc4a3a5:

    # MC "Hmm.. Just some reports..."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:146
translate chinese bob_deskraports_label_97d5e525:

    # MC "I should check a few pages, just in case."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:162
translate chinese bob_deskraports_label_6c79a32a:

    # MC "There's something interesting..."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:163
translate chinese bob_deskraports_label_5e7f9526:

    # MC "Bingo! That's the name of the company. I think this is what Zuri wants."
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:175
translate chinese bob_deskcarbookput_label_4a43d456:

    # MC "(Let’s leave it in here. I don’t need it.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:189
translate chinese bob_deskminigame_label_fc3ecfa4:

    # MC "(Okay. Let’s do some work! It should be easy.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_desk.rpy:198
translate chinese bob_deskminigame_label_3abc842b:

    # MC "(Tomorrow there will probably be more work.)"
    MC ""

