﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/outside/bob_work_locked_label.rpy:12
translate chinese bob_work_locked_label_81912de3:

    # MC "Closed. Bob's Workplace is open only in the morning and afternoon."
    MC ""

