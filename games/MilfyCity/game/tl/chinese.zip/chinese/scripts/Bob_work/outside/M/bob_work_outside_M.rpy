﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/outside/M/bob_work_outside_M.rpy:39
translate chinese leave_cant_fec7aca3:

    # MC "Before I leave, I should put the car keys back."
    MC ""

