﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Office/M/office_items.rpy:23
translate chinese bob_statue_label_1495c5cc:

    # MC "(I never understood why classical artists chose not to sculpt heads or hands.)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:24
translate chinese bob_statue_label_daba2b2b:

    # MC "(I mean, the face is one of the most interesting parts of any statue.)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:79
translate chinese bob_headstatue_label_9f9ee5e9:

    # MC "(It’s a deep blue marble bust. There is a bright shine off it - someone has polished this thing to perfection!)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:80
translate chinese bob_headstatue_label_915d5ec8:

    # MC "(I can almost see my reflection in it!)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:88
translate chinese bob_painting_label_7daa7e67:

    # MC "(There’s something deeply unsettling about this painting.)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:89
translate chinese bob_painting_label_c8329e53:

    # MC "(It’s kinda like a dirty sidewalk. Who the hell would want THIS, hanging up in their office?)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:97
translate chinese bob_statue1_label_b1469dd3:

    # MC "(Is this supposed to be a light switch?)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:98
translate chinese bob_statue1_label_153d920a:

    # MC "(Or maybe it’s a person’s nose?)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:99
translate chinese bob_statue1_label_7067ff82:

    # MC "(God! I hate abstract art.)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:219
translate chinese bob_safenote_label_5422cf34:

    # MC "Hmm... safe code be useful. Not very wise to leave it lying around like that. Anyone could find it."
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:228
translate chinese bob_safenoteput_label_1957603a:

    # MC "Let’s leave it in here."
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:285
translate chinese bob_redstatue2_label_c927d570:

    # MC "(This is pretty cool! It looks like it’s made out of red glass, or maybe even a tinted jade!)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:286
translate chinese bob_redstatue2_label_710b158f:

    # MC "(Is it supposed to be a cat? Or maybe a panther?)"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:294
translate chinese bob_carkeys_label_53936abd:

    # MC "Oh! It’s Dad’s car keys. But why are there two? The other one must be a spare?"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:296
translate chinese bob_carkeys_label_0ec6d8b1:

    # MC "Oh! It’s Bob’s car keys. But why are there two? The other one must be a spare?"
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:313
translate chinese bob_carkeys_put_label_ea096562:

    # MC "Let’s return Dad’s keys."
    MC ""

# game/scripts/Bob_work/Office/M/office_items.rpy:315
translate chinese bob_carkeys_put_label_ae1b6a91:

    # MC "Let’s return Bob’s keys."
    MC ""

