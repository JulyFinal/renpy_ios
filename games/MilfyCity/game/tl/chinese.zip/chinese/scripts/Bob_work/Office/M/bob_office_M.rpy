﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Office/M/bob_office_M.rpy:36
translate chinese office_leave_e8f403f4:

    # MC "(I can't leave now. I should talk with Dad.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_office_M.rpy:38
translate chinese office_leave_0e09789a:

    # MC "(I can't leave now. I should talk with Bob.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_office_M.rpy:44
translate chinese office_leave_9476fed5:

    # MC "(I can't leave now. I should put the safe note back.)"
    MC ""

# game/scripts/Bob_work/Office/M/bob_office_M.rpy:59
translate chinese bob_officelocked_7405c8f7:

    # MC "(I need a magnet card to get in office.)"
    MC ""

