﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:12
translate chinese bob_receptiondiagram_1e512a39:

    # MC "(Eh... Profits aren’t looking too bad for Dad.)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:14
translate chinese bob_receptiondiagram_5a0e7e7e:

    # MC "(Eh... Profits aren’t looking too bad for Bob.)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:15
translate chinese bob_receptiondiagram_704b5c93:

    # MC "(They’ve taken a hit in recent months - but at least it looks like things are finally stabilising.)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:16
translate chinese bob_receptiondiagram_9ae7964b:

    # MC "(That must have been why he was so busy.)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:21
translate chinese bob_receptiondiagram_c01fa597:

    # MC "(Uh oh... Looks like me giving out sensitive company information to Zuri has led to Dad’s profit margins falling!)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:23
translate chinese bob_receptiondiagram_e0ab8e32:

    # MC "(Uh oh... Looks like me giving out sensitive company information to Zuri has led to Bob’s profit margins falling!)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:29
translate chinese bob_receptiondiagram_7d84b617:

    # MC "(Huh? Lying to Zuri has ensured that Dad’s company returns to a profitable position. That’s good to see!)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:30
translate chinese bob_receptiondiagram_c6eeef43:

    # MC "(The projections are looking even stronger than before the crash. Dad’ll be pleased with this!)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:32
translate chinese bob_receptiondiagram_7bc50978:

    # MC "(Huh, lying to Zuri has ensured that Bob’s company returns to a profitable position. That’s good to see!)"
    MC ""

# game/scripts/Bob_work/Entrance/M/scenes/bob_receptiondiagram.rpy:33
translate chinese bob_receptiondiagram_3c43a51a:

    # MC "(The projections are looking even stronger than before the crash. Bob’ll be pleased with this!)"
    MC ""

