﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:40
translate chinese Zv2_MS2_label_4fb9ef10:

    # MC "Hi, Zuri!"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:41
translate chinese Zv2_MS2_label_4b184768:

    # Zuri "Oh! Hello, [player_name]."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:45
translate chinese Zv2_MS2_label_705c739c:

    # Zuri "Your help with those names, earned me and my sister MILLIONS. We’re both VERY thankful for what you did for us."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:47
translate chinese Zv2_MS2_label_868607ff:

    # MC "It was nothing, Zuri. Thanks again for everything the TWO OF YOU did for ME."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:54
translate chinese Zv2_MS2_label_4f80ba3c:

    # Zuri "Ahh! Hello again, [player_name]! How are you?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:55
translate chinese Zv2_MS2_label_0c7caef1:

    # MC "I’m good, Zuri. Busy today?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:56
translate chinese Zv2_MS2_label_7de6ed57:

    # Zuri "We’re always busy here."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:113
translate chinese Zv2_MS2_q1_label_f14d3953:

    # MC "How long have you worked for Dad, Zuri?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:115
translate chinese Zv2_MS2_q1_label_7ef15596:

    # MC "How long have you worked for Bob, Zuri?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:116
translate chinese Zv2_MS2_q1_label_6ae39a5a:

    # Zuri "It must be... three or four months now?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:117
translate chinese Zv2_MS2_q1_label_a60362e4:

    # MC "Huh? You’re fairly new here, then?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:121
translate chinese Zv2_MS2_q1_label_f38a7d4d:

    # Zuri "Yes, I got lucky. This is a great company to work for. Much better than my old job!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:122
translate chinese Zv2_MS2_q1_label_720a1ba0:

    # MC "I’m glad to hear that!"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:129
translate chinese Zv2_MS2_q2_label_28f5ddf7:

    # MC "Where did you meet Dad, then?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:131
translate chinese Zv2_MS2_q2_label_0c0d278e:

    # MC "Where did you meet Bob, then?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:135
translate chinese Zv2_MS2_q2_label_bee94de0:

    # Zuri "The interview was only five months ago - but I’d known him before that."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:136
translate chinese Zv2_MS2_q2_label_38bc526c:

    # Zuri "We met in France, at a business conference in Toulouse. That must have been three or four years ago."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:137
translate chinese Zv2_MS2_q2_label_145f7427:

    # MC "Cool. The two of you go way back, then?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:141
translate chinese Zv2_MS2_q2_label_3084a6b0:

    # Zuri "Not really. We lost touch, shortly after the conference. It wasn’t until I met him again in New York that he told me he was looking for a new secretary."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:142
translate chinese Zv2_MS2_q2_label_dc3097c8:

    # MC "Well, congrats on the job!"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:143
translate chinese Zv2_MS2_q2_label_327530fc:

    # Zuri "Thanks!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:150
translate chinese Zv2_MS2_q3_label_000faa2e:

    # MC "So, what’s it like working for Dad?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:152
translate chinese Zv2_MS2_q3_label_313ffc3c:

    # MC "So, what’s it like working for Bob?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:157
translate chinese Zv2_MS2_q3_label_b0fde9c2:

    # Zuri "I really enjoy working for your father. There are some bosses who pile work on their employees."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:158
translate chinese Zv2_MS2_q3_label_fd108d91:

    # Zuri "Your father isn’t like that - he takes a LOT of work on, himself."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:160
translate chinese Zv2_MS2_q3_label_6cca56d6:

    # Zuri "I really enjoy working for him. There are some bosses who pile work on their employees."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:161
translate chinese Zv2_MS2_q3_label_110d57ea:

    # Zuri "Bob isn’t like that - he takes a LOT of work on, himself."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:162
translate chinese Zv2_MS2_q3_label_1c7675f8:

    # Zuri "He leads by example, and I’m really proud to work for him."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:168
translate chinese Zv2_MS2_magnetcard_label_96717323:

    # MC "Hi, Zuri. I just spoke with Dad there. He said I could grab your magnetic card."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:170
translate chinese Zv2_MS2_magnetcard_label_cbfccb6c:

    # MC "Hi, Zuri. I just spoke with Bob, there. He said I could grab your magnetic card."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:171
translate chinese Zv2_MS2_magnetcard_label_578f2027:

    # Zuri "Really?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:172
translate chinese Zv2_MS2_magnetcard_label_17959b72:

    # MC "Yeah, he probably sent you an email explaining the situation."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:176
translate chinese Zv2_MS2_magnetcard_label_b2bab527:

    # Zuri "Let me check..."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:177
translate chinese Zv2_MS2_magnetcard_label_e00df6b5:

    # Zuri "Ah! There it is. Okay, no problem. Let me get it for you now."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:178
translate chinese Zv2_MS2_magnetcard_label_9dae1b31:

    # MC "Thanks, Zuri!"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:182
translate chinese Zv2_MS2_magnetcard_label_04487454:

    # Zuri "Did your father say anything about getting me a new card?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:184
translate chinese Zv2_MS2_magnetcard_label_bfd4dd28:

    # Zuri "Did Bob say anything about getting me a new card?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:185
translate chinese Zv2_MS2_magnetcard_label_285c0dc1:

    # MC "Yeah, he did. Hopefully it won’t take too long."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:186
translate chinese Zv2_MS2_magnetcard_label_cfb1aa8b:

    # Zuri "It’s okay - I don’t need it soon anyway."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:198
translate chinese Zv2_MS2_bobtrip_label_3d08914b:

    # MC "Zuri, I was wondering... Does Dad have any business trips coming up soon?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:200
translate chinese Zv2_MS2_bobtrip_label_3db63e9e:

    # MC "Zuri, I was wondering... Does Bob have any business trips coming up soon?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:203
translate chinese Zv2_MS2_bobtrip_label_f10f728c:

    # Zuri "Probably? Why do you want to know?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:205
translate chinese Zv2_MS2_bobtrip_label_e5dca4ad:

    # MC "I uh... We’re planning to do a family dinner some night, and we want to make sure he’s at home for it."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:207
translate chinese Zv2_MS2_bobtrip_label_819b38bf:

    # MC "I uh... His wife, Linda, is planning a big dinner some night and we want to make sure he’s at home for it."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:217
translate chinese Zv2_MS2_bobtrip_label_27a4a2aa:

    # Zuri "You still haven't helped me with company names, [player_name]."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:223
translate chinese Zv2_MS2_bobtrip_label_c86a6417:

    # MC "I've helped you, so please tell me, does Dad have any upcoming business trips?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:225
translate chinese Zv2_MS2_bobtrip_label_d0843fd1:

    # MC "I've helped you, so please tell me, does Bob have any upcoming business trips?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:227
translate chinese Zv2_MS2_bobtrip_label_0fd33ad5:

    # Zuri "Let me check his diary for you, to see when he’s busy..."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:231
translate chinese Zv2_MS2_bobtrip_label_8dae9c82:

    # Zuri "Okay... It looks like he is away THIS weekend. I can’t see any other business trips."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:232
translate chinese Zv2_MS2_bobtrip_label_d0ef906c:

    # MC "That’s perfect, Zuri! That’s all I need to know."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:234
translate chinese Zv2_MS2_bobtrip_label_a33fcdfa:

    # Zuri "Happy I could help. Enjoy your family dinner!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:235
translate chinese Zv2_MS2_bobtrip_label_c7e157b3:

    # MC "(Great! I just have to let Mom know that Dad is away this weekend now!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:237
translate chinese Zv2_MS2_bobtrip_label_73dd36be:

    # Zuri "Happy I could help. Enjoy your dinner!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:238
translate chinese Zv2_MS2_bobtrip_label_1392d978:

    # MC "(Great! I just have to let Linda know that Bob is away this weekend now!)"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:247
translate chinese Zv2_MS2_zuriname_label_010e0aa9:

    # MC "Zuri is quite an unusual name. Where did you get it from?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:251
translate chinese Zv2_MS2_zuriname_label_8aa401ea:

    # Zuri "Unusual? What do you mean?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:252
translate chinese Zv2_MS2_zuriname_label_2d41357e:

    # MC "I don’t mean in a bad way! It’s really cute actually!"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:257
translate chinese Zv2_MS2_zuriname_label_047e4728:

    # Zuri "Aww... you’re sweet. It’s French actually. I was born, just outside Marseille."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:258
translate chinese Zv2_MS2_zuriname_label_16358a64:

    # MC "Cool! Do you miss France, at all?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:259
translate chinese Zv2_MS2_zuriname_label_76b43bb4:

    # Zuri "Sometimes... I really enjoy living over here though."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:266
translate chinese Zv2_MS2_pay_label_4333beb2:

    # MC "Is the pay good, working here?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:269
translate chinese Zv2_MS2_pay_label_15dff18e:

    # Zuri "Haha! What makes you think I’d talk about my pay with you?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:271
translate chinese Zv2_MS2_pay_label_e8d90527:

    # MC "I’m just curious if my dad pays his staff well."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:273
translate chinese Zv2_MS2_pay_label_96e2ee65:

    # MC "I’m just curious if Bob pays his staff well."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:275
translate chinese Zv2_MS2_pay_label_dad148c2:

    # Zuri "Let me promise you something - no staff in this company are paid badly. There’s a reason why so few people here leave for other jobs."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:281
translate chinese Zv2_MS2_zuriproposition_label_db0d48e9:

    # Zuri "I take it you’ve considered my proposition."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:285
translate chinese Zv2_MS2_zuriproposition_label_b2c14c96:

    # Zuri "I’m eagerly awaiting your answer. What’s it going to be? "
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:291
translate chinese Zv2_MS2_zuriproposition_label_4acacbff:

    # MC "Yes, I’ll help you get the company name."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:292
translate chinese Zv2_MS2_zuriproposition_label_d5731764:

    # Zuri "Brilliant! Thank you so much!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:293
translate chinese Zv2_MS2_zuriproposition_label_c7ecbe76:

    # Zuri "I will make sure you are handsomely rewarded for your help."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:295
translate chinese Zv2_MS2_zuriproposition_label_1adcd96b:

    # Zuri "Your dad is always out of the office in the afternoon. I’ll let you inside, then you can search for the company name."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:297
translate chinese Zv2_MS2_zuriproposition_label_649da70e:

    # Zuri "Bob is out of the office this afternoon. I’ll let you inside, then you can search for the company name."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:298
translate chinese Zv2_MS2_zuriproposition_label_c84aa686:

    # MC "Why can’t YOU just search his office?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:299
translate chinese Zv2_MS2_zuriproposition_label_3713f849:

    # Zuri "He has installed a few cameras in there, so it’s too risky for me, but he will never suspect YOU! Or even that you’d be searching his office, when he monitors your access."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:310
translate chinese Zv2_MS2_zuriproposition_label_a9a47f12:

    # MC "I’ve thought about it... and I’d rather not get involved in this."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:311
translate chinese Zv2_MS2_zuriproposition_label_513fe733:

    # Zuri "I’m sorry to hear that. If you change your mind, please come back and speak to me."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:312
translate chinese Zv2_MS2_zuriproposition_label_30d7e02c:

    # Zuri "I could REALLY make it worth your while."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:320
translate chinese Zv2_MS2_companyname1_label_d8dcbfaf:

    # Zuri "Do you have it? Do you have the company name?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:325
translate chinese Zv2_MS2_companyname1_label_8758f759:

    # MC "No, I don’t have it yet."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:326
translate chinese Zv2_MS2_companyname1_label_5e7b0754:

    # Zuri "Please, hurry up and get it!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:330
translate chinese Zv2_MS2_companyname1_label_be3d7243:

    # MC "Yes, I have it."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:334
translate chinese Zv2_MS2_companyname1_label_90c25888:

    # Zuri "Great! I knew I could trust you! What’s the name?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:338
translate chinese Zv2_MS2_companyname1_label_31050b96:

    # MC "The company is called Charterhouse Investments."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:339
translate chinese Zv2_MS2_companyname1_label_10adf290:

    # Zuri "Amazing! Please come over to my house again this evening, and I’ll make sure you get your reward."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:349
translate chinese Zv2_MS2_companyname1_label_c7029890:

    # MC "The company is called Beerhouse Investments."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:350
translate chinese Zv2_MS2_companyname1_label_10adf290_1:

    # Zuri "Amazing! Please come over to my house again this evening, and I’ll make sure you get your reward."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:361
translate chinese Zv2_MS2_companyname1_label_0f1b7066:

    # Zuri "Hello, [player_name]! "
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:362
translate chinese Zv2_MS2_companyname1_label_de9016a7:

    # Zuri "Well? Did you have any luck getting the second company name?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:366
translate chinese Zv2_MS2_companyname1_label_8758f759_1:

    # MC "No, I don’t have it yet."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:367
translate chinese Zv2_MS2_companyname1_label_88779c66:

    # Zuri "You were a great help with the first name. Please get it as soon as possible for me."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:371
translate chinese Zv2_MS2_companyname1_label_e43e44db:

    # MC "Yes, I have it. It was written on a note in the safe."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:375
translate chinese Zv2_MS2_companyname1_label_cb34f2de:

    # Zuri "Great! You’re proving a brilliant asset! What’s the second company’s name?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:379
translate chinese Zv2_MS2_companyname1_label_3eed1743:

    # MC "The second company trades under the name of Jakarta Legal Procurements."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:380
translate chinese Zv2_MS2_companyname1_label_9eb73cfa:

    # Zuri "Brilliant! As before, come over to my place and I’ll make sure you’re properly rewarded."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:390
translate chinese Zv2_MS2_companyname1_label_fcdcbd2f:

    # MC "The company name is... Indian Railway and Infrastructure Investments."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:391
translate chinese Zv2_MS2_companyname1_label_9eb73cfa_1:

    # Zuri "Brilliant! As before, come over to my place and I’ll make sure you’re properly rewarded."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:404
translate chinese Zv2_MS2_companyname1_label_ac920c4b:

    # Zuri "[player_name]! Ready for some action?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:405
translate chinese Zv2_MS2_companyname1_label_8e916436:

    # MC "Huh? What do you mean?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:406
translate chinese Zv2_MS2_companyname1_label_e0f45b98:

    # Zuri "Work! We’re not done yet.. I’m sure you want... more?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:407
translate chinese Zv2_MS2_companyname1_label_2a2b8c95:

    # MC "*Gulp* What’s the plan?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:411
translate chinese Zv2_MS2_companyname1_label_41231f95:

    # Zuri "The third and final company name is going to be more difficult to get."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:413
translate chinese Zv2_MS2_companyname1_label_64c481bf:

    # Zuri "It’s a complete secret - the only person who knows is, your father. And he’s not writing it down anywhere."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:415
translate chinese Zv2_MS2_companyname1_label_0a1a4b0c:

    # Zuri "It’s a complete secret - the only person who knows it, is Bob himself. And he’s not writing it down anywhere."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:416
translate chinese Zv2_MS2_companyname1_label_2e46bed5:

    # Zuri "That’s why I need you. I need you to speak with him and get him to give you the name. Understand?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:417
translate chinese Zv2_MS2_companyname1_label_3c3a49b1:

    # MC "I got it. I’ll see what I can do."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:425
translate chinese Zv2_MS2_companyname1_label_849a05c0:

    # Zuri "Well? Did you get the final name from your father?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:427
translate chinese Zv2_MS2_companyname1_label_e1293b8e:

    # Zuri "Well? Did you get the final name from Bob?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:431
translate chinese Zv2_MS2_companyname1_label_9fa9287b:

    # MC "No, I don’t have it yet. It’s proving more difficult than I thought, to make him tell me."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:432
translate chinese Zv2_MS2_companyname1_label_4784bde1:

    # Zuri "Please keep trying. It’s really important that we get this name."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:436
translate chinese Zv2_MS2_companyname1_label_be3d7243_1:

    # MC "Yes, I have it."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:440
translate chinese Zv2_MS2_companyname1_label_03069ba9:

    # Zuri "Great! I knew I could trust you! What’s the last name?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:444
translate chinese Zv2_MS2_companyname1_label_10e1d720:

    # MC "The final company is Nottingham Legal and Commercial Incorporated."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:445
translate chinese Zv2_MS2_companyname1_label_5729c4d8:

    # Zuri "You’re absolutely amazing! God! I could kiss you, right now! Please come over to my house, this evening, and I’ll give you another reward."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:457
translate chinese Zv2_MS2_companyname1_label_bb7029b8:

    # MC "The final company is... Manchester Aviation and Aeronautics Engineering."
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:458
translate chinese Zv2_MS2_companyname1_label_5729c4d8_1:

    # Zuri "You’re absolutely amazing! God! I could kiss you, right now! Please come over to my house, this evening, and I’ll give you another reward."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:474
translate chinese Zv2_MS2_cancel_label_9ec06b37:

    # Zuri "I'll gladly tell you that, [player_name] but after you help me."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:475
translate chinese Zv2_MS2_cancel_label_67eaf4d6:

    # MC "Help you? With what?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:476
translate chinese Zv2_MS2_cancel_label_89af4f46:

    # Zuri "Come over to my house this evening."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:477
translate chinese Zv2_MS2_cancel_label_9e03f56a:

    # MC "Huh? Why?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:478
translate chinese Zv2_MS2_cancel_label_bc0b5d5b:

    # Zuri "Oh, come on. A pretty girl is asking you over to her place. How could you possibly say no?"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:482
translate chinese Zv2_MS2_cancel_label_a60f4ef7:

    # Zuri "Just let me... Hmm... Ah!"
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:486
translate chinese Zv2_MS2_cancel_label_9e423c5f:

    # Zuri "This is my address."
    Zuri ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:487
translate chinese Zv2_MS2_cancel_label_4fc687fe:

    # MC "Is this... a... a date?"
    MC ""

# game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:492
translate chinese Zv2_MS2_cancel_label_f64275bf:

    # Zuri "Haha! Just come over and find out for yourself."
    Zuri ""

translate chinese strings:

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "How long have you worked for Dad for?"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "How long have you worked for Bob for?"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "Where did you meet Dad?"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "Where did you meet Bob?"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "What’s it like working for Dad? "
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "What’s it like working for Bob? "
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "{color=#00ff00}Ask her for magnet card for Dad's office doors.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "{color=#00ff00}Ask her for magnet card for Bob's office doors.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "{color=#00ff00}Ask her when Dad has a business trip, or something.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "{color=#00ff00}Ask her when Bob has a business trip, or something.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "Zuri is an unusual name. Where are you from?"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "Is the pay good?"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "{color=#00ff00}Talk about Zuri proposition.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:64
    old "{color=#00ff00}Talk about company name.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:287
    old "{color=#00ff00}Yes, I’ll help you get the company name.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:287
    old "No, I’m not gonna help with this."
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:322
    old "No, not yet."
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:322
    old "{color=#00ff00}Yes.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:336
    old "{color=#00ff00}Tell the truth.{/color}"
    new ""

    # game/scripts/Bob_work/Rception/M/scenes/Zv2_MS2.rpy:336
    old "{color=#f00}Lie about the name.{/color}"
    new ""

