﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/outside/M/scenes/bob_car.rpy:13
translate chinese bob_car_locked_label_aeb91391:

    # MC "(It's locked.)"
    MC ""

# game/scripts/Bob_work/outside/M/scenes/bob_car.rpy:105
translate chinese bob_carbook_75e61548:

    # MC "What’s that book doing in here? It looks like it’s from Dad’s office. Maybe Dad might need it. I should return it to his office."
    MC ""

# game/scripts/Bob_work/outside/M/scenes/bob_car.rpy:107
translate chinese bob_carbook_61c3ec3a:

    # MC "What’s that book doing in here? It looks like it’s from Bob’s office. Maybe Bob might need it. I should return it to his office."
    MC ""

# game/scripts/Bob_work/outside/M/scenes/bob_car.rpy:118
translate chinese bob_carmoney_d8293799:

    # MC "Nice! +[money]$"
    MC ""

