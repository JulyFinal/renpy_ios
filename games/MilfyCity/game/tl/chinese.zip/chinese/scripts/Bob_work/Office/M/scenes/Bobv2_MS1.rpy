﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:29
translate chinese Bobv2_MS1_label_97f0e90b:

    # MC "(I don't want to bother him with it right now. Let's speak with him at home.)"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:45
translate chinese Bobv2_MS1_label_b878edea:

    # MC "Morning, Dad!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:47
translate chinese Bobv2_MS1_label_07736f49:

    # MC "Morning, Bob!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:48
translate chinese Bobv2_MS1_label_901842a4:

    # Dad "Why, hello there, champ. What brings you over to my office?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:49
translate chinese Bobv2_MS1_label_54d9aa5e:

    # MC "Not much. Just thought I’d drop by to say hello."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:53
translate chinese Bobv2_MS1_label_9948a190:

    # Dad "Well, I’ll never say no to a visit from my favourite son!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:54
translate chinese Bobv2_MS1_label_72165265:

    # MC "I’m your ONLY son."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:56
translate chinese Bobv2_MS1_label_8a8ddef2:

    # Dad "Well, I’ll never say no to a visit from my favourite male tenant! Gotta love the ones that always pay their rent on time."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:57
translate chinese Bobv2_MS1_label_e4d64959:

    # MC "I’m your ONLY male tennant."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:58
translate chinese Bobv2_MS1_label_7cfc5099:

    # Dad "And thus, my favourite."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:64
translate chinese Bobv2_MS1_label_b878edea_1:

    # MC "Morning, Dad!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:66
translate chinese Bobv2_MS1_label_07736f49_1:

    # MC "Morning, Bob!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:68
translate chinese Bobv2_MS1_label_3ae7f030:

    # Dad "Hello there, [player_name]"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:69
translate chinese Bobv2_MS1_label_582d5489:

    # MC "What's up?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:70
translate chinese Bobv2_MS1_label_0107ddaf:

    # Dad "Ah! Nothing important. Same day as always."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:83
translate chinese Bobv2_MS1_menu_6797b0de:

    # MC "I sorted the documents. Could you pay me?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:85
translate chinese Bobv2_MS1_menu_dffe2bb4:

    # Dad "Ah! Good job, [player_name]! Here, take it."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:86
translate chinese Bobv2_MS1_menu_15d5ec2d:

    # MC "Thanks!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:87
translate chinese Bobv2_MS1_menu_c78ce402:

    # Dad "No, I thank you! I hate doing that! "
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:89
translate chinese Bobv2_MS1_menu_1af0f792:

    # Dad "After so many times, it started to be incredibly boring."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:90
translate chinese Bobv2_MS1_menu_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:91
translate chinese Bobv2_MS1_menu_28be78d0:

    # Dad "I'll be more than happy, if you'd start doing it more regularly."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:93
translate chinese Bobv2_MS1_menu_3b3d81f9:

    # MC "No problem, Dad."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:95
translate chinese Bobv2_MS1_menu_76a34a43:

    # MC "No problem, Bob."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:101
translate chinese Bobv2_MS1_menu_3a1262fc:

    # MC "I sorted the documents yesterday. Could you pay me?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:103
translate chinese Bobv2_MS1_menu_8db089af:

    # Dad "Again!?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:104
translate chinese Bobv2_MS1_menu_b8ec99ea:

    # Dad "Brilliant! Here, take it."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:105
translate chinese Bobv2_MS1_menu_4b980c10:

    # Dad "(Now I'll have more time to read my books!)"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:107
translate chinese Bobv2_MS1_menu_778843c5:

    # MC "Thanks, Dad."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:109
translate chinese Bobv2_MS1_menu_94a28d90:

    # MC "Thanks, Bob."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:117
translate chinese Bobv2_MS1_menu_e86bfe38:

    # MC "I was wondering if you had any work I could help with."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:119
translate chinese Bobv2_MS1_menu_4c68907a:

    # MC "I was wondering if you had any work I could help with. Need to earn some extra cash to pay my rent this month."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:123
translate chinese Bobv2_MS1_menu_cb7a9dcd:

    # Dad "And that work has to be paid, does it?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:124
translate chinese Bobv2_MS1_menu_aa41bcae:

    # MC "Yeah, I was kinda hoping that."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:125
translate chinese Bobv2_MS1_menu_f1f66a32:

    # Dad "Come to think of it, I need some documents sorted this afternoon. I’ll be in the house, so you can meet me there if you’re up for it. "
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:129
translate chinese Bobv2_MS1_menu_09284639:

    # Dad "The documents to sort will always be lying on my desk after I leave."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:130
translate chinese Bobv2_MS1_menu_c0cff504:

    # MC "How difficult is this gonna be?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:134
translate chinese Bobv2_MS1_menu_5d882fc1:

    # Dad "Difficult? Haha! Not at all! Simply match the documents to the corresponding number."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:135
translate chinese Bobv2_MS1_menu_ee7985c7:

    # MC "What about the payment?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:136
translate chinese Bobv2_MS1_menu_5fd84e7a:

    # Dad "Whenever you finish the job, always come to me."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:137
translate chinese Bobv2_MS1_menu_97384dbd:

    # Dad "Just remember that I'm only here in the morning!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:138
translate chinese Bobv2_MS1_menu_a9165697:

    # MC "I have to wait another day for a payment?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:139
translate chinese Bobv2_MS1_menu_d89fa5e6:

    # Dad "Haha! Impatience is a very bad habit, [player_name]."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:140
translate chinese Bobv2_MS1_menu_b1743f6a:

    # Dad "You can also ask me at home in the afternoon. I should be in my bedroom smoking my delicious cigars."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:141
translate chinese Bobv2_MS1_menu_957e8b7a:

    # MC "Ugh..!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:142
translate chinese Bobv2_MS1_menu_54eda7f3:

    # Dad "Don't judge!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:143
translate chinese Bobv2_MS1_menu_dce7b90c:

    # Dad "I only smoke recreationally - not by addiction."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:144
translate chinese Bobv2_MS1_menu_68f7ccc2:

    # MC "Yeah... (Every addicted person probably is saying that...)"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:153
translate chinese Bobv2_MS1_menu_bf8da9a6:

    # MC "Could I get the key card to your office?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:157
translate chinese Bobv2_MS1_menu_75fdd041:

    # Dad "Huh... That’s... gonna be a problem. I only have one - and I NEED mine, almost every day."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:158
translate chinese Bobv2_MS1_menu_516c4fb1:

    # MC "Oh. Nevermind, then."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:162
translate chinese Bobv2_MS1_menu_0d0a2689:

    # Dad "No - hold right there for just one minute. I’ve got an idea."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:163
translate chinese Bobv2_MS1_menu_7ed927d7:

    # Dad "Go over to Zuri and ask for her keycard. It has the same access levels as mine."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:164
translate chinese Bobv2_MS1_menu_cb7042f8:

    # MC "Thanks. But what about her?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:168
translate chinese Bobv2_MS1_menu_e0d8214d:

    # Dad "I’ll just order a new one for her."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:170
translate chinese Bobv2_MS1_menu_039e330a:

    # MC "Cool. Thanks, Dad! I’ll go and speak to Zuri now."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:172
translate chinese Bobv2_MS1_menu_b67883e4:

    # MC "Cool. Thanks, Bob! I’ll go and speak to Zuri now."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:183
translate chinese Bobv2_MS1_menu_dc219c36:

    # MC "Hey Dad, I know you’re super into investing. I was wondering if I could get some advice from you?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:185
translate chinese Bobv2_MS1_menu_49e13078:

    # MC "Hey Bob, I know you’re super into investing. I was wondering if I could get some advice from you?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:186
translate chinese Bobv2_MS1_menu_b7b3c403:

    # Dad "Sure, what do you wanna know, champ?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:187
translate chinese Bobv2_MS1_menu_52514562:

    # MC "I know all the big investors have companies that they KNOW will do really well in the market. Sort of like, trade secrets."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:189
translate chinese Bobv2_MS1_menu_c2de8318:

    # Dad "Haha, yeah, that’s true. GME to the moon!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:190
translate chinese Bobv2_MS1_menu_915794cf:

    # MC "Well? Do you have one?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:191
translate chinese Bobv2_MS1_menu_f0728ca2:

    # Dad "I definitely do."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:192
translate chinese Bobv2_MS1_menu_90f86d7a:

    # MC "Cool! What’s it called?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:195
translate chinese Bobv2_MS1_menu_074de4d5:

    # Dad "Sorry - trade secret. I can’t possibly tell, until we close the deal."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:197
translate chinese Bobv2_MS1_menu_0a6e377c:

    # MC "Aww, c’mon Dad! I won’t tell anyone. I just want to know more about the business!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:199
translate chinese Bobv2_MS1_menu_4a8a51f4:

    # MC "Aww, c’mon Bob! I won’t tell anyone. I just want to know more about the business!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:200
translate chinese Bobv2_MS1_menu_987280a4:

    # MC "To be honest, I’m kinda thinking of getting into this line of work when I graduate college."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:202
translate chinese Bobv2_MS1_menu_1fb9a3c9:

    # Dad "Really?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:203
translate chinese Bobv2_MS1_menu_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:204
translate chinese Bobv2_MS1_menu_bf8c04b8:

    # Dad "Hmm... In that case... I suppose."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:205
translate chinese Bobv2_MS1_menu_5df04afd:

    # Dad "Alright! I’ve got this tip from a member of the European Council. "
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:206
translate chinese Bobv2_MS1_menu_8aa0488a:

    # Dad "He’s told me that Nottingham Legal and Commercial Incorporated are getting a massive contract for a rail network running from Portugal to Poland. We’re talking about a multi-billion dollar contract!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:207
translate chinese Bobv2_MS1_menu_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:208
translate chinese Bobv2_MS1_menu_938a5503:

    # MC "(That’s what I need to know!)"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:210
translate chinese Bobv2_MS1_menu_5c1c1657:

    # MC "I’ll talk to you more about this later, Dad."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:212
translate chinese Bobv2_MS1_menu_b2293e29:

    # MC "I’ll talk to you more about this later, Bob."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:213
translate chinese Bobv2_MS1_menu_ad7b1d7e:

    # Dad "No problem! See you later!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:241
translate chinese Bobv2_MS1_zurisuri_label_1980bdf4:

    # MC "Hey, Dad. Did you know Zuri had a twin sister?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:243
translate chinese Bobv2_MS1_zurisuri_label_bdd1bca6:

    # MC "Hey, Bob. Did you know Zuri has a partner?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:248
translate chinese Bobv2_MS1_zurisuri_label_1fb9a3c9:

    # Dad "Really?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:249
translate chinese Bobv2_MS1_zurisuri_label_3462e199:

    # MC "Yeah, a girl named Suri."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:250
translate chinese Bobv2_MS1_zurisuri_label_df1367ea:

    # Dad "Strange. I’ve never heard her talk about her."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:254
translate chinese Bobv2_MS1_zurisuri_label_f7462a5c:

    # Dad "How did you find out she had a twin sister?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:256
translate chinese Bobv2_MS1_zurisuri_label_51d5f5f1:

    # Dad "How did you find out she had a partner?"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:257
translate chinese Bobv2_MS1_zurisuri_label_fabeff3c:

    # MC "I... uh... She mentioned it to me in the lobby there."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:261
translate chinese Bobv2_MS1_zurisuri_label_b8e53cd5:

    # Dad "Huh... Alright then. Good for her, I guess."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:268
translate chinese Bobv2_MS1_work_label_e6d37cff:

    # MC "How’s work going, Dad?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:270
translate chinese Bobv2_MS1_work_label_1eeeb930:

    # MC "How’s work going, Bob?"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:273
translate chinese Bobv2_MS1_work_label_a2b0275c:

    # Dad "Ahh, jeez. I wish you hadn’t asked. The whole company is screwed right now."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:274
translate chinese Bobv2_MS1_work_label_1292b001:

    # MC "(Uh oh...)"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:275
translate chinese Bobv2_MS1_work_label_dbb3aa48:

    # Dad "Profits are nose diving into the red, and corporate headquarters are on my ass, demanding to know why."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:276
translate chinese Bobv2_MS1_work_label_109d3ba0:

    # Dad "I’m gonna have to work TWICE as hard from now on, to turn this ship around."
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:278
translate chinese Bobv2_MS1_work_label_32d95688:

    # MC "Crap! I’m sorry to hear that, Dad."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:280
translate chinese Bobv2_MS1_work_label_0ef217e0:

    # MC "Crap! I’m sorry to hear that, Bob."
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:284
translate chinese Bobv2_MS1_work_label_9697586e:

    # Dad "I’m glad you asked! Things are REALLY turning around over here!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:285
translate chinese Bobv2_MS1_work_label_6c52e78d:

    # Dad "Y’know - I though the market would never recover after that 2009 crash. But look - here we are. And by the looks of things, we’re about to post record profits!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:287
translate chinese Bobv2_MS1_work_label_658e1852:

    # MC "Congratulations, Dad!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:289
translate chinese Bobv2_MS1_work_label_a648933f:

    # MC "Congratulations, Bob!"
    MC ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:290
translate chinese Bobv2_MS1_work_label_064b68e5:

    # Dad "If all goes according to plan, I should finally start to get my annual bonus again!"
    Dad ""

# game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:304
translate chinese bob_work_money_give_813eda63:

    # "(You received {color=#00ff00}[bob_payment_money]${/color}.)"
    ""

translate chinese strings:

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "{color=#00ff00}I sorted the documents. Could you pay me?{/color}"
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "{color=#00ff00}Do you have any work for me?{/color}"
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "{color=#00ff00}Could you give me the key card for your office?{/color}"
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "{color=#00ff00}Ask about company name.{/color}"
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "Ask Dad if he knows about Zuri’s twin sister. "
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "Ask Bob if he knows about Zuri’s partner. "
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "{color=#00ff00}Ask Dad how work is going.{/color}"
    new ""

    # game/scripts/Bob_work/Office/M/scenes/Bobv2_MS1.rpy:78
    old "{color=#00ff00}Ask Bob how work is going.{/color}"
    new ""

