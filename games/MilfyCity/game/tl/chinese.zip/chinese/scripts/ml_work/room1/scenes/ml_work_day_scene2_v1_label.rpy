﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:40
translate chinese ml_work_day_scene2_v1_label_e168e91e:

    # MC "Hi, Mom! That’s me back again."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:42
translate chinese ml_work_day_scene2_v1_label_efcc5fbe:

    # MC "Hi, Linda! That’s me back again."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:43
translate chinese ml_work_day_scene2_v1_label_1cd910dc:

    # Mom "Great! If you just do the same as last time."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:44
translate chinese ml_work_day_scene2_v1_label_9d13eb52:

    # Mom "Is $25 okay for you again?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:45
translate chinese ml_work_day_scene2_v1_label_785de004:

    # MC "Sure. No problem."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:59
translate chinese ml_work_day_scene2_v1_label_after_work_aace769c:

    # MC "(That’s me done for the day.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:61
translate chinese ml_work_day_scene2_v1_label_after_work_4c254a74:

    # MC "(Time to go back to Mom and get my money.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:63
translate chinese ml_work_day_scene2_v1_label_after_work_e064f3bc:

    # MC "(Time to go back to Linda and get my money.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:67
translate chinese ml_work_day_scene2_v1_label_after_work_b90b1676:

    # MC "That’s it all done."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:68
translate chinese ml_work_day_scene2_v1_label_after_work_89d58993:

    # Mom "Great!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:71
translate chinese ml_work_day_scene2_v1_label_after_work_db7178b5:

    # Mom "Say - would you fancy sitting on the couch with me for a while?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:72
translate chinese ml_work_day_scene2_v1_label_after_work_690b7417:

    # MC "Sure."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:75
translate chinese ml_work_day_scene2_v1_label_after_work_32803f1c:

    # MC "(She just sat down on my knee! I didn’t expect that!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:76
translate chinese ml_work_day_scene2_v1_label_after_work_da697af7:

    # Mom "You’ve got beautiful eyes, [player_name]. You know that?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:78
translate chinese ml_work_day_scene2_v1_label_after_work_d3a1fb2c:

    # MC "Gee... Thanks, Mom."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:80
translate chinese ml_work_day_scene2_v1_label_after_work_be7a833b:

    # MC "Gee... Thanks, Linda."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:81
translate chinese ml_work_day_scene2_v1_label_after_work_209d2f53:

    # Mom "You really do. I could gaze into them for hours."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:84
translate chinese ml_work_day_scene2_v1_label_after_work_cd6c2ad2:

    # MC "(Gulp!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:85
translate chinese ml_work_day_scene2_v1_label_after_work_1a8acdca:

    # Mom "You look a little nervous."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:86
translate chinese ml_work_day_scene2_v1_label_after_work_21c3ae9e:

    # Mom "You shouldn’t be. I promise, you’re in very safe hands right now."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:87
translate chinese ml_work_day_scene2_v1_label_after_work_28b9dbae:

    # Mom "Try relaxing. Put your hand on my thigh."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:92
translate chinese ml_work_day_scene2_v1_label_after_work_1200e789:

    # Mom "That’s it. See?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:93
translate chinese ml_work_day_scene2_v1_label_after_work_f77bfdbf:

    # Mom "I can hear your heart pounding from here."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:94
translate chinese ml_work_day_scene2_v1_label_after_work_9c05bbe6:

    # Mom "Just try to breathe, and close your eyes."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:95
translate chinese ml_work_day_scene2_v1_label_after_work_16e681a5:

    # Mom "I promise you’ll enjoy this."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:98
translate chinese ml_work_day_scene2_v1_label_after_work_6bdc411f:

    # MC "(Oh, my God... It's really happening. She's not worried about my reaction anymore!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:99
translate chinese ml_work_day_scene2_v1_label_after_work_60e3ab04:

    # MC "(How far is she going to take this, today? Just a kiss?)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:102
translate chinese ml_work_day_scene2_v1_label_after_work_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:104
translate chinese ml_work_day_scene2_v1_label_after_work_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:106
translate chinese ml_work_day_scene2_v1_label_after_work_027778ee:

    # MC "(Wow! She’s an amazing kisser!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:109
translate chinese ml_work_day_scene2_v1_label_after_work_7d823958:

    # Mom "(God... This is even better than I dreamt it would be.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:110
translate chinese ml_work_day_scene2_v1_label_after_work_dce8e9d6:

    # Mom "(I wish I could just freeze this moment, and stay right here forever.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:112
translate chinese ml_work_day_scene2_v1_label_after_work_cc3052f1:

    # MC "(Mom must be getting nervous too - I can hear her heart beating, even louder than mine!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:114
translate chinese ml_work_day_scene2_v1_label_after_work_25aa3944:

    # MC "(Linda must be getting nervous too - I can hear her heart beating, even louder than mine!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:117
translate chinese ml_work_day_scene2_v1_label_after_work_6b055a44:

    # Mom "Lie down on the couch beside me. I want to do something for you."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:118
translate chinese ml_work_day_scene2_v1_label_after_work_a26b746f:

    # MC "D-Do something? Like what?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:120
translate chinese ml_work_day_scene2_v1_label_after_work_c778e5bf:

    # Mom "Hush... Just you lie back and relax. Mommy will take care of everything."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:122
translate chinese ml_work_day_scene2_v1_label_after_work_6481fe65:

    # Mom "Hush... Just you lie back and relax. I will take care of everything."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:125
translate chinese ml_work_day_scene2_v1_label_after_work_b9cdcbf0:

    # MC "Ooohh...."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:126
translate chinese ml_work_day_scene2_v1_label_after_work_916e8450:

    # MC "(Holy shit... I can feel her fingers, wrapping around my cock.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:127
translate chinese ml_work_day_scene2_v1_label_after_work_c02f54a5:

    # MC "(She’s massaging it now.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:131
translate chinese ml_work_day_scene2_v1_label_after_work_19cd253d:

    # MC "M-Mom! Y-You-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:133
translate chinese ml_work_day_scene2_v1_label_after_work_368ef663:

    # MC "L-Linda. Y-You-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:134
translate chinese ml_work_day_scene2_v1_label_after_work_0786b850:

    # Mom "Shush... I see you’ve got a hard problem, down here."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:136
translate chinese ml_work_day_scene2_v1_label_after_work_4c5cb1d5:

    # Mom "Let Mother help you sort it out."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:138
translate chinese ml_work_day_scene2_v1_label_after_work_b9d33e45:

    # Mom "Let me help you sort it out."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:141
translate chinese ml_work_day_scene2_v1_label_after_work_a6a61779:

    # Mom "(Mmm... It’s so big!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:142
translate chinese ml_work_day_scene2_v1_label_after_work_5bba6f95:

    # Mom "(I’d love to feel this monster inside me. Filling up my pussy!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:143
translate chinese ml_work_day_scene2_v1_label_after_work_2133155c:

    # Mom "(God, I’m getting wet at the mere thought of it!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:146
translate chinese ml_work_day_scene2_v1_label_after_work_d79de929:

    # Mom "Does it feel good when I circle my fingers around, this little bit at the top?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:147
translate chinese ml_work_day_scene2_v1_label_after_work_86e7e604:

    # MC "Ah... yes..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:148
translate chinese ml_work_day_scene2_v1_label_after_work_69bd06ca:

    # Mom "I’ll tell you why it’s so sensitive."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:151
translate chinese ml_work_day_scene2_v1_label_after_work_12a585b5:

    # Mom "It’s called the frenulum - and it’s a sensitive little cluster of nerves."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:152
translate chinese ml_work_day_scene2_v1_label_after_work_263f4e22:

    # Mom "A secret trick of mine, back in the college, was to rapidly flick my tongue back and forth across it."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:153
translate chinese ml_work_day_scene2_v1_label_after_work_24fb8e8f:

    # Mom "No guy could last thirty seconds, when getting one of MY blowjobs."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:156
translate chinese ml_work_day_scene2_v1_label_after_work_4d82224b:

    # Mom "But enough foreplay - let’s get down to business."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:157
translate chinese ml_work_day_scene2_v1_label_after_work_16df264f:

    # MC "Ah! Ahh... Oohhh!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:159
translate chinese ml_work_day_scene2_v1_label_after_work_7c55b7b3:

    # Mom "Mmm... sounds like my boy’s enjoying this."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:161
translate chinese ml_work_day_scene2_v1_label_after_work_554dcc6e:

    # Mom "Mmm... sounds like my toyboy is enjoying it."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:164
translate chinese ml_work_day_scene2_v1_label_after_work_c4560fd2:

    # MC "Oooh!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:167
translate chinese ml_work_day_scene2_v1_label_after_work_fb442bfb:

    # MC "(Oh, my God! I never imagined, Mom would be this kinky!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:169
translate chinese ml_work_day_scene2_v1_label_after_work_76eb0966:

    # MC "(Oh, my God! I never imagined, Linda would be this kinky!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:170
translate chinese ml_work_day_scene2_v1_label_after_work_82c8a240:

    # Mom "(Haha! I felt him shudder as I licked him. He’ll be cumming for me, in no time.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:173
translate chinese ml_work_day_scene2_v1_label_after_work_c5a2b9b4:

    # Mom "Up and down..."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:174
translate chinese ml_work_day_scene2_v1_label_after_work_06858200:

    # Mom "Up... and down."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:175
translate chinese ml_work_day_scene2_v1_label_after_work_89bebdd0:

    # Mom "I hope you’re enjoying this as much as I am."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:178
translate chinese ml_work_day_scene2_v1_label_after_work_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:180
translate chinese ml_work_day_scene2_v1_label_after_work_90eac278:

    # Mom "Are you close?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:181
translate chinese ml_work_day_scene2_v1_label_after_work_b36f4d3c:

    # Mom "I want you to cum for me."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:184
translate chinese ml_work_day_scene2_v1_label_after_work_d40031e0:

    # MC "Mmm! MMMMM!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:185
translate chinese ml_work_day_scene2_v1_label_after_work_1a042b58:

    # MC "(Fuck! I’m gonna cum!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:187
translate chinese ml_work_day_scene2_v1_label_after_work_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:188
translate chinese ml_work_day_scene2_v1_label_after_work_31ea9460:

    # Mom "(I can feel his cock, twitching and throbbing in my hand. My boy’s about to blow his load!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:192
translate chinese ml_work_day_scene2_v1_label_after_work_f2b708c3:

    # Mom "That’s it! Cum for Mommy! Good boy!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:194
translate chinese ml_work_day_scene2_v1_label_after_work_bf4ffce3:

    # Mom "That’s it! Cum for Linda! Good boy!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:195
translate chinese ml_work_day_scene2_v1_label_after_work_985618ca:

    # MC "Ahh! Ooooh! Ahhhh!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:203
translate chinese ml_work_day_scene2_v1_label_after_work_d9e63502:

    # Mom "Wow... That’s a lot of cum! You’re lucky you had me around, to relieve you."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:206
translate chinese ml_work_day_scene2_v1_label_after_work_d921489c:

    # Mom "Is that you all finished? Or should I keep going?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:207
translate chinese ml_work_day_scene2_v1_label_after_work_fddfcb19:

    # MC "N-No, I’m... I’m done..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:208
translate chinese ml_work_day_scene2_v1_label_after_work_9613af35:

    # Mom "So, how was it? Did you enjoy it?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:212
translate chinese ml_work_day_scene2_v1_label_after_work_509fb13a:

    # MC "It was amazing, Mom! Thank you!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:214
translate chinese ml_work_day_scene2_v1_label_after_work_12889189:

    # MC "It was amazing, Linda! Thank you!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:215
translate chinese ml_work_day_scene2_v1_label_after_work_4ccf0242:

    # Mom "I’m very happy to hear that."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:216
translate chinese ml_work_day_scene2_v1_label_after_work_165471c6:

    # Mom "You make SUCH a cute face when you cum!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:218
translate chinese ml_work_day_scene2_v1_label_after_work_2d4e7d96:

    # MC "MOM!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:219
translate chinese ml_work_day_scene2_v1_label_after_work_5b235132:

    # Mom "Haha! I better get back to work. I’ll see you, later this night."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:220
translate chinese ml_work_day_scene2_v1_label_after_work_f3ce303b:

    # MC "See ya, Mom. Thanks again."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:222
translate chinese ml_work_day_scene2_v1_label_after_work_fa3a6335:

    # MC "Linda!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:223
translate chinese ml_work_day_scene2_v1_label_after_work_5b235132_1:

    # Mom "Haha! I better get back to work. I’ll see you, later this night."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene2_v1_label.rpy:224
translate chinese ml_work_day_scene2_v1_label_after_work_78797b54:

    # MC "See ya, Linda. Thanks again."
    MC ""

