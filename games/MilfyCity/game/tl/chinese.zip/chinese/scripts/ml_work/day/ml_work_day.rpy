﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ml_work/day/ml_work_day.rpy:18
translate chinese ml_work_day1_90a0e422:

    # MC "It’s only open in the afternoon."
    MC ""

