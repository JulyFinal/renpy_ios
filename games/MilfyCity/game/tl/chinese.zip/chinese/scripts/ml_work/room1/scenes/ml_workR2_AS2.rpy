﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:16
translate chinese ml_workR2_AS2_label_422a0238:

    # MC "Afternoon, Mom! I’m here for some work."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:18
translate chinese ml_workR2_AS2_label_5e2373de:

    # MC "Afternoon, Linda! I’m here for some work."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:20
translate chinese ml_workR2_AS2_label_c7588a5b:

    # Mom "I'm sorry, Sweetie. I don't have any work for you today."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:21
translate chinese ml_workR2_AS2_label_dda2401a:

    # MC "That's fine."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:22
translate chinese ml_workR2_AS2_label_a1c44ff6:

    # Mom "Try again some other day."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:23
translate chinese ml_workR2_AS2_label_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:24
translate chinese ml_workR2_AS2_label_da9d8974:

    # Mom "Now, let me finish this stupid work, so I'll have more time for my pumpkin."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:25
translate chinese ml_workR2_AS2_label_615eedc7:

    # MC "Okay."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:27
translate chinese ml_workR2_AS2_label_673748a4:

    # MC "(Hmm.. Mom seems very busy.. Maybe I should visit her in the evening, to give her a relaxing massage, after work? She should be in the kitchen or in the bedroom.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:29
translate chinese ml_workR2_AS2_label_8b6a4a40:

    # MC "(Hmm.. Linda seems very busy.. Maybe I should visit her in the evening, to give her a relaxing massage, after work? She should be in the kitchen or in the bedroom.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:37
translate chinese ml_workR2_AS2_label_c7588a5b_1:

    # Mom "I'm sorry, Sweetie. I don't have any work for you today."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:38
translate chinese ml_workR2_AS2_label_dda2401a_1:

    # MC "That's fine."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:39
translate chinese ml_workR2_AS2_label_a1c44ff6_1:

    # Mom "Try again some other day."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:40
translate chinese ml_workR2_AS2_label_71d7d606_1:

    # MC "No problem."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:41
translate chinese ml_workR2_AS2_label_da9d8974_1:

    # Mom "Now, let me finish this stupid work, so I'll have more time for my pumpkin."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:42
translate chinese ml_workR2_AS2_label_615eedc7_1:

    # MC "Okay."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:44
translate chinese ml_workR2_AS2_label_673748a4_1:

    # MC "(Hmm.. Mom seems very busy.. Maybe I should visit her in the evening, to give her a relaxing massage, after work? She should be in the kitchen or in the bedroom.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:46
translate chinese ml_workR2_AS2_label_8b6a4a40_1:

    # MC "(Hmm.. Linda seems very busy.. Maybe I should visit her in the evening, to give her a relaxing massage, after work? She should be in the kitchen or in the bedroom.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:54
translate chinese ml_workR2_AS2_label_fe15ebd9:

    # Mom "Hey, Sweetie. Do you mind cleaning the office again for me?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:55
translate chinese ml_workR2_AS2_label_03df46a3:

    # MC "Sure, no sweat."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:59
translate chinese ml_workR2_AS2_label_fc53b593:

    # Mom "Thank you so much. I’ll be working here. Just come on back in when you’re done."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:61
translate chinese ml_workR2_AS2_label_1a09b417:

    # MC "Okay, Mom!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:63
translate chinese ml_workR2_AS2_label_a614fdf7:

    # MC "Okay, Linda!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:82
translate chinese after_ml_workR2_AS2_label_ea949e28:

    # MC "Aaannnd... that’s me all done!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:83
translate chinese after_ml_workR2_AS2_label_c19d2e48:

    # Mom "Nice work - my staff are really appreciating, coming into a tidy office in the morning."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:84
translate chinese after_ml_workR2_AS2_label_6fb20a7c:

    # Mom "(And hopefully that will be enough, to shut down talk of them unionising!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:88
translate chinese after_ml_workR2_AS2_label_c88c2b5b:

    # Mom "I’ve got good news for you today - I’m almost finished. This is the last file!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:89
translate chinese after_ml_workR2_AS2_label_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:90
translate chinese after_ml_workR2_AS2_label_2aead395:

    # MC "(Hopefully this means I’ll be able to get intimate with her again!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:94
translate chinese after_ml_workR2_AS2_label_b2ec898b:

    # MC "When do you think you’ll be finished?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:95
translate chinese after_ml_workR2_AS2_label_6ab447cd:

    # Mom "Soon. Just give me until time this evening."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:96
translate chinese after_ml_workR2_AS2_label_99d2746b:

    # MC "Oh cool. What are your plans for this evening, then?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:100
translate chinese after_ml_workR2_AS2_label_d6b1c629:

    # Mom "Well... I was thinking about, taking you and me, to a gorgeous little restaurant on the far side of town."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:101
translate chinese after_ml_workR2_AS2_label_56408f22:

    # Mom "It’s an Italian place - one of the best in town. You’ll love the food."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:103
translate chinese after_ml_workR2_AS2_label_72596141:

    # Mom "I could NEVER get your father to go. He’s never been interested in, anything other than American burgers."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:105
translate chinese after_ml_workR2_AS2_label_8bc4dec5:

    # Mom "I could NEVER get my husband to go. He’s never been interested in anything other than American burgers."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:106
translate chinese after_ml_workR2_AS2_label_74a45f19:

    # Mom "(I’ve got more culture in my little toe than the fat idiot has in his whole damn body!) "
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:110
translate chinese after_ml_workR2_AS2_label_3acd838f:

    # Mom "So, what do you say? Interested?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:111
translate chinese after_ml_workR2_AS2_label_2b515de7:

    # MC "Definitely!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:115
translate chinese after_ml_workR2_AS2_label_9507502b:

    # Mom "Great! In that case, we’ll meet in the garage. "
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:116
translate chinese after_ml_workR2_AS2_label_a2029c6a:

    # Mom "I’ll see you there early in the evening. Please don't be late."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:118
translate chinese after_ml_workR2_AS2_label_4e3e293f:

    # MC "I won’t be - don’t worry, Mom!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS2.rpy:120
translate chinese after_ml_workR2_AS2_label_9fd9fabb:

    # MC "I won’t be - don’t worry, Linda!"
    MC ""

