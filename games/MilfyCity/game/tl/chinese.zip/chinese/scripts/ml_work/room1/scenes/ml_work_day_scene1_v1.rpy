﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:27
translate chinese ml_work_day_scene1_v1_label_10d7ea04:

    # MC "Hey, Mom! I’m free to do some work for you now."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:29
translate chinese ml_work_day_scene1_v1_label_0d5b547d:

    # MC "Hey, Linda! I’m free to do some work for you now."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:30
translate chinese ml_work_day_scene1_v1_label_4a00365b:

    # Mom "Good afternoon, Sweetie. Great! Let me see what I need done."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:31
translate chinese ml_work_day_scene1_v1_label_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:34
translate chinese ml_work_day_scene1_v1_label_fda62750:

    # Mom "We’re on top of paperwork and databasing right now."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:35
translate chinese ml_work_day_scene1_v1_label_65ceb441:

    # Mom "However, we lost our cleaner last week. She badly twisted her ankle, and will be off work for a couple of months."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:36
translate chinese ml_work_day_scene1_v1_label_33103223:

    # Mom "I’ll tell you what - if you can clean the offices for me, I’ll give you $25."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:37
translate chinese ml_work_day_scene1_v1_label_05f6d717:

    # MC "What do I need to do?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:38
translate chinese ml_work_day_scene1_v1_label_440a3198:

    # Mom "Take out the trash, pick up any rubbish, tidy up loose papers."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:39
translate chinese ml_work_day_scene1_v1_label_b21b84b2:

    # Mom "Just make sure you don’t throw away anything important!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:41
translate chinese ml_work_day_scene1_v1_label_c5571735:

    # MC "Okay, Mom. I’ll be careful!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:43
translate chinese ml_work_day_scene1_v1_label_65c6aa54:

    # MC "Okay, Linda. I’ll be careful!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:58
translate chinese ml_work_day_scene1_v1_label_after_minigame_8da1f183:

    # MC "Phew! (That looks like the last of it.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:60
translate chinese ml_work_day_scene1_v1_label_after_minigame_34e9ee25:

    # MC "(Mom’s offices are looking, in pretty good shape right now!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:62
translate chinese ml_work_day_scene1_v1_label_after_minigame_5811cff6:

    # MC "(Linda’s offices are looking, in pretty good shape right now!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:63
translate chinese ml_work_day_scene1_v1_label_after_minigame_d30327f8:

    # MC "(I’ll go and let her know I’m finished.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:68
translate chinese ml_work_day_scene1_v1_label_after_minigame_ac880eef:

    # MC "Hi again! That’s me done."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:69
translate chinese ml_work_day_scene1_v1_label_after_minigame_a9b3a568:

    # Mom "Great work! Here’s the $25, as promised."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:72
translate chinese ml_work_day_scene1_v1_label_after_minigame_3758425c:

    # MC "(It’s not much, but it's better than having to constantly beg Dad!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:74
translate chinese ml_work_day_scene1_v1_label_after_minigame_0bcc2489:

    # MC "(It’s not much, but it's better than having to constantly beg Bob!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:77
translate chinese ml_work_day_scene1_v1_label_after_minigame_80c1f08e:

    # Mom "(The cleaner was getting $40 for the work [player_name] just did - but now that I’ve got his attention, I can reel him in with the big money!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:78
translate chinese ml_work_day_scene1_v1_label_after_minigame_77a795ef:

    # Mom "Say - how would you like to earn another $50?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:79
translate chinese ml_work_day_scene1_v1_label_after_minigame_85979b00:

    # MC "(Another $50? That’ll bring me up to $75. I could really use the cash.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:80
translate chinese ml_work_day_scene1_v1_label_after_minigame_06aa6310:

    # MC "Yeah, what do you want me to do?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:81
translate chinese ml_work_day_scene1_v1_label_after_minigame_5797d73a:

    # Mom "I want... to play the game again."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:82
translate chinese ml_work_day_scene1_v1_label_after_minigame_df45f4a7:

    # MC "The game? (The last game...? But she's married... but it's not like I care about that. Maybe she really like me?)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:83
translate chinese ml_work_day_scene1_v1_label_after_minigame_ad3b0fde:

    # Mom "The one we played in the car - but this time you must stay still for two minutes."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:84
translate chinese ml_work_day_scene1_v1_label_after_minigame_0668a118:

    # MC "*Gulp* (Yep... She has a crush on me... Maybe she likes younger men?)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:94
translate chinese ml_work_day_scene1_v1_menu_0de30893:

    # Mom "Well? What do you say?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:98
translate chinese ml_work_day_scene1_v1_menu_aeec2ad1:

    # MC "Before I say “yes”, I want to know... do you love me more than a son?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:99
translate chinese ml_work_day_scene1_v1_menu_57cb6dae:

    # Mom "I don’t know what you mean."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:101
translate chinese ml_work_day_scene1_v1_menu_b018ddc4:

    # MC "I mean, do you- are you attracted to me?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:102
translate chinese ml_work_day_scene1_v1_menu_bdba4321:

    # Mom "Oh, come on. You’re being silly now, [player_name]."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:107
translate chinese ml_work_day_scene1_v1_menu_9ae1b270:

    # MC "Before I say “yes”, I want to know... do love me?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:108
translate chinese ml_work_day_scene1_v1_menu_57cb6dae_1:

    # Mom "I don’t know what you mean."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:110
translate chinese ml_work_day_scene1_v1_menu_b018ddc4_1:

    # MC "I mean, do you- are you attracted to me?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:111
translate chinese ml_work_day_scene1_v1_menu_bdba4321_1:

    # Mom "Oh, come on. You’re being silly now, [player_name]."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:116
translate chinese ml_work_day_scene1_v1_menu_c25a59a6:

    # MC "Why do you want to play this weird game again?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:117
translate chinese ml_work_day_scene1_v1_menu_230b6628:

    # Mom "Why does it matter to you? It’s an easy $50 if you agree."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:118
translate chinese ml_work_day_scene1_v1_menu_9305e733:

    # MC "(Hmm... She’s being evasive with her answers.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:123
translate chinese ml_work_day_scene1_v1_menu_3be79956:

    # MC "If I stand still, are you going to try and kiss me again?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:125
translate chinese ml_work_day_scene1_v1_menu_8932d5bc:

    # Mom "Who knows what will happen?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:126
translate chinese ml_work_day_scene1_v1_menu_95ee846d:

    # Mom "And why do you care? It’s not like I haven’t kissed you before."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:136
translate chinese ml_work_day_scene1_v1_menu_after_4887bca3:

    # MC "Okay, I'm ready. (Wow, she's such a mysterious MILF! I should play along the whole time, and maybe I'll have a chance to take things further with her!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:137
translate chinese ml_work_day_scene1_v1_menu_after_f8c0b913:

    # Mom "Don’t move a muscle. The two minutes begins now."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:140
translate chinese ml_work_day_scene1_v1_menu_after_41842b5d:

    # MC "(One... Two... Three...)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:141
translate chinese ml_work_day_scene1_v1_menu_after_ab16dfdd:

    # MC "(Oh, my God! Is she lifting up my t-shirt?!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:142
translate chinese ml_work_day_scene1_v1_menu_after_4f9e1691:

    # Mom "(My heart’s racing. I wonder how far I can get in two minutes.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:143
translate chinese ml_work_day_scene1_v1_menu_after_72474d9e:

    # Mom "(Will I have enough time to see his hard dick?)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:146
translate chinese ml_work_day_scene1_v1_menu_after_dd2d8c11:

    # Mom "Ah ah - no moving!! We’ve only just started, Sweetie."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:147
translate chinese ml_work_day_scene1_v1_menu_after_02751f09:

    # MC "I... ah..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:148
translate chinese ml_work_day_scene1_v1_menu_after_a271565f:

    # Mom "No talking either. Your tongue counts as a muscle too, you know!"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:152
translate chinese ml_work_day_scene1_v1_menu_after_4f0c80bb:

    # MC "(Sh-Shit! She’s my mother!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:154
translate chinese ml_work_day_scene1_v1_menu_after_d3f1ce80:

    # MC "(Sh-Shit! She’s really gonna do it!? Today is MY day!?)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:155
translate chinese ml_work_day_scene1_v1_menu_after_e56ce7c5:

    # MC "(I mean... I’m definitely getting hard right now... but it’s wrong. Isn’t it? She has a husband... He can kick me out of the house if he knew!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:156
translate chinese ml_work_day_scene1_v1_menu_after_4f22a95e:

    # MC "C-Careful! I’m falling back!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:159
translate chinese ml_work_day_scene1_v1_menu_after_9b9813e6:

    # MC "Whoooaaaa!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:160
translate chinese ml_work_day_scene1_v1_menu_after_68b550d3:

    # Mom "(Oooh! Exciting!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:162
translate chinese ml_work_day_scene1_v1_menu_after_a4041bcc:

    # MC "(Jesus! Mom’s completely lost control of herself!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:164
translate chinese ml_work_day_scene1_v1_menu_after_1809ab55:

    # MC "(Jesus! Linda’s completely lost control of herself!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:170
translate chinese ml_work_day_scene1_v1_menu_after_077ea06c:

    # Mom "(Mmm! I like this position!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:172
translate chinese ml_work_day_scene1_v1_menu_after_b953168a:

    # MC "M-Mom! Wait!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:174
translate chinese ml_work_day_scene1_v1_menu_after_75079981:

    # MC "L-Linda! Wait! I-I mean US! HIM! You want to do it h-here!? Now?!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:175
translate chinese ml_work_day_scene1_v1_menu_after_1d157777:

    # Mom "(Huh? What’s gotten into him? He’s resisting, a lot, this time.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:178
translate chinese ml_work_day_scene1_v1_menu_after_73b6c856:

    # Mom "What’s wrong, Sweetie?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:179
translate chinese ml_work_day_scene1_v1_menu_after_39579819:

    # Mom "Do you want me to continue or not?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:184
translate chinese ml_work_day_scene1_v1_menu_after_458790c7:

    # MC "Y-Yeah... I do."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:185
translate chinese ml_work_day_scene1_v1_menu_after_41fac458:

    # MC "I’m just a little stunned at-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:190
translate chinese ml_work_day_scene1_v1_menu_after_ecae0ae1:

    # MC "I don’t know..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:191
translate chinese ml_work_day_scene1_v1_menu_after_414ad3a0:

    # MC "It’s a bit too... intense...."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:193
translate chinese ml_work_day_scene1_v1_menu_after_a894dd15:

    # MC "I don’t know... You’re married Linda..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:194
translate chinese ml_work_day_scene1_v1_menu_after_81ae29cd:

    # MC "It’s a bit too... quickly... Did you thought about everything?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:201
translate chinese ml_work_day_scene1_v1_menu_after2_8818126e:

    # Mom "(Oh, God... What am I doing?)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:203
translate chinese ml_work_day_scene1_v1_menu_after2_3851591a:

    # Mom "(I can’t believe I’ve sunk this low. What kind of mother tries to rape her own son?!)"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:204
translate chinese ml_work_day_scene1_v1_menu_after2_eae01ca1:

    # Mom "I... I’m so sorry."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:205
translate chinese ml_work_day_scene1_v1_menu_after2_f496e6a8:

    # MC "Mom, I-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:207
translate chinese ml_work_day_scene1_v1_menu_after2_3a1a572b:

    # Linda "(I didn’t realise he wasn’t as into this as I was.)"
    Linda ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:208
translate chinese ml_work_day_scene1_v1_menu_after2_5ed9b093:

    # Linda "I... I’m so sorry. I didn’t realise, [player_name]."
    Linda ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:209
translate chinese ml_work_day_scene1_v1_menu_after2_b2b1a4a7:

    # MC "Linda, I-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:214
translate chinese ml_work_day_scene1_v1_menu_after2_28d20632:

    # Mom "I’m so so sorry, [player_name]."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:216
translate chinese ml_work_day_scene1_v1_menu_after2_d854faa9:

    # MC "It’s okay, Mom."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:218
translate chinese ml_work_day_scene1_v1_menu_after2_e3a0c50e:

    # MC "It’s okay, Linda."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:219
translate chinese ml_work_day_scene1_v1_menu_after2_2c3aca28:

    # Mom "No, it’s not okay."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:221
translate chinese ml_work_day_scene1_v1_menu_after2_b034ea66:

    # Mom "I’ve always felt this way."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:223
translate chinese ml_work_day_scene1_v1_menu_after2_91a89ee4:

    # Mom "I've been feeling like this lately. It's you..."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:226
translate chinese ml_work_day_scene1_v1_menu_after2_b33a04ce:

    # Mom "I’ve been able to contain my emotions for so long."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:227
translate chinese ml_work_day_scene1_v1_menu_after2_703a5304:

    # Mom "I kept it all inside - and sometimes, I allowed myself to fantasise about being with you."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:229
translate chinese ml_work_day_scene1_v1_menu_after2_5cfe49b6:

    # Mom "But I always felt SO guilty afterwards."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:231
translate chinese ml_work_day_scene1_v1_menu_after2_44330eb1:

    # Mom "But I always felt SO guilty afterward. I’m a married woman and you’re just a student and my tenant. You’re just soo hot..."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:232
translate chinese ml_work_day_scene1_v1_menu_after2_a87d5541:

    # Mom "It was when you started wanting to date other women, that I finally cracked."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:233
translate chinese ml_work_day_scene1_v1_menu_after2_e6e34b22:

    # Mom "I... *Sniff* I couldn’t stand the thought of you being romantically involved with someone else."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:237
translate chinese ml_work_day_scene1_v1_menu_after2_82c8f3ad:

    # MC "Shush - it’s okay, Mom. Breathe and relax."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:238
translate chinese ml_work_day_scene1_v1_menu_after2_72893322:

    # MC "You know that I lov-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:240
translate chinese ml_work_day_scene1_v1_menu_after2_32170f55:

    # MC "Shush - it’s okay Linda. Breathe and relax. (So she has a crush on me!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:241
translate chinese ml_work_day_scene1_v1_menu_after2_61d759b3:

    # MC "I have feelings for you too. I can tell it now. Linda, I think that I might lov-"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:244
translate chinese ml_work_day_scene1_v1_menu_after2_e8bebcd6:

    # Mom "No. No."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:245
translate chinese ml_work_day_scene1_v1_menu_after2_1437d1ec:

    # Mom "I don’t want to hear it right now."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:246
translate chinese ml_work_day_scene1_v1_menu_after2_1f243ad9:

    # Mom "I feel like a total piece of shit after what I did to you today. I'm supposed to be more mature, but I acted like a young, stupid girl driven by hormones."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:247
translate chinese ml_work_day_scene1_v1_menu_after2_5a108880:

    # Mom "Just... please, think about everything I've said, and... let me know in the morning, okay? It would be a much more mature approach for both of us."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:249
translate chinese ml_work_day_scene1_v1_menu_after2_077e8ff5:

    # MC "O-Okay, Mom."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:251
translate chinese ml_work_day_scene1_v1_menu_after2_1960712d:

    # MC "O-Okay, Linda."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:252
translate chinese ml_work_day_scene1_v1_menu_after2_51448562:

    # Mom "I'm going to take a long bath once I get home."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:253
translate chinese ml_work_day_scene1_v1_menu_after2_999b1cf7:

    # MC "(She will be in the bathroom soon...? Great!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:254
translate chinese ml_work_day_scene1_v1_menu_after2_c57b0291:

    # MC "That would be a good opportunity to admire her naked body!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:255
translate chinese ml_work_day_scene1_v1_menu_after2_5adea8b9:

    # MC "See you later, [Mom_name]."
    MC ""

translate chinese strings:

    # game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:95
    old "Do you... love me more than a son?"
    new ""

    # game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:95
    old "Do you... love me?"
    new ""

    # game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:95
    old "Why do you want to play this game again?"
    new ""

    # game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:95
    old "Are you going to kiss me again?"
    new ""

    # game/scripts/ml_work/room1/scenes/ml_work_day_scene1_v1.rpy:95
    old "{color=#00ff00}Okay, I’m ready.{/color}"
    new ""

