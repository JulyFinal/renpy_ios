﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:17
translate chinese ml_workR2_AS1_label_6aac9dbc:

    # MC "Hi, Mom!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:19
translate chinese ml_workR2_AS1_label_21b7be9f:

    # MC "Hi, Linda!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:20
translate chinese ml_workR2_AS1_label_c7588a5b:

    # Mom "I'm sorry, Sweetie. I don't have any work for you today."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:21
translate chinese ml_workR2_AS1_label_7df54e58:

    # Mom "I'm a bit busy right now."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:22
translate chinese ml_workR2_AS1_label_fde8c6e9:

    # Mom "If you want to talk with me come to my bedroom in the morning."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:23
translate chinese ml_workR2_AS1_label_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:24
translate chinese ml_workR2_AS1_label_2a691a08:

    # Mom "I’ll see you later on. Love you, Sweetie."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:26
translate chinese ml_workR2_AS1_label_da05c13f:

    # MC "See you later, Mom. Love you too!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:28
translate chinese ml_workR2_AS1_label_b0fa86cd:

    # MC "See you later, Linda. Love you too!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:40
translate chinese ml_workR2_AS1_label_6aac9dbc_1:

    # MC "Hi, Mom!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:42
translate chinese ml_workR2_AS1_label_21b7be9f_1:

    # MC "Hi, Linda!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:43
translate chinese ml_workR2_AS1_label_02d6b472:

    # Mom "Good afternoon, Sweetie. Are you here for work?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:44
translate chinese ml_workR2_AS1_label_4e30daab:

    # MC "Yeah, do you have anything for me?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:48
translate chinese ml_workR2_AS1_label_3c8b8ae2:

    # Mom "Just more cleaning, if you’re happy to do that."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:49
translate chinese ml_workR2_AS1_label_cd39e239:

    # MC "Sure. I’ll get started on that now."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:50
translate chinese ml_workR2_AS1_label_965b8c22:

    # Mom "Thanks, Sweetie! Come back and let me know when you’re done."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:70
translate chinese after_ml_workR2_AS1_label_e0975d13:

    # MC "Alright, that’s me done!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:71
translate chinese after_ml_workR2_AS1_label_d644901d:

    # MC "You’ve got some REALLY messy employees! Do they not know what a bin is?! Haha!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:72
translate chinese after_ml_workR2_AS1_label_9e431c08:

    # Mom "Yeah, there’s a couple of men that are complete slobs. I’d sack them if they weren’t so good at their jobs."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:73
translate chinese after_ml_workR2_AS1_label_b3131414:

    # MC "So... now that I’ve finished that for you, perhaps we could..."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:77
translate chinese after_ml_workR2_AS1_label_5a3ffd2c:

    # Mom "I’m sorry, Sweetie. I’m up to my eyes in work today."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:78
translate chinese after_ml_workR2_AS1_label_cd2e44a8:

    # Mom "See this folder?"
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:79
translate chinese after_ml_workR2_AS1_label_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:80
translate chinese after_ml_workR2_AS1_label_498abd3d:

    # Mom "This will take me an hour to process. And after I’ve finished, I have FIVE more folders to go through."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:84
translate chinese after_ml_workR2_AS1_label_c8273270:

    # MC "Aww, jeez. That sounds tough."
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:85
translate chinese after_ml_workR2_AS1_label_1435cad1:

    # MC "Is there any way I can help you with this?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:86
translate chinese after_ml_workR2_AS1_label_a3d65049:

    # Mom "Thanks for the offer. But unless you’re a qualified accountant, I can’t legally let you work with them."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:87
translate chinese after_ml_workR2_AS1_label_3bc4b3d8:

    # MC "Oh, fair enough then. Well, if there’s anything I can do, just give me a text, okay?"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:91
translate chinese after_ml_workR2_AS1_label_3e8a761e:

    # Mom "C’mon, Sweetie! Don’t look so downhearted. Once we get through tax season, then I will have a LOT of free time for you."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:92
translate chinese after_ml_workR2_AS1_label_481aa7f3:

    # Mom "I’ll just be busy for a couple more days. I promise."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:96
translate chinese after_ml_workR2_AS1_label_85a1ca2b:

    # Mom "In the meantime, just let your imagination wander, with thoughts of all the dirty things I’ll do to you."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:97
translate chinese after_ml_workR2_AS1_label_fefd00ca:

    # MC "(Holy shit! That is a LOT of pent up sexual frustration, right there!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:98
translate chinese after_ml_workR2_AS1_label_ff1db974:

    # MC "(It sounds like I’ll be in for a treat when she has finished!)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:102
translate chinese after_ml_workR2_AS1_label_b7e68bb8:

    # Mom "Anyway, I better let you go, before I get distracted."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:103
translate chinese after_ml_workR2_AS1_label_2a691a08:

    # Mom "I’ll see you later on. Love you, Sweetie."
    Mom ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:105
translate chinese after_ml_workR2_AS1_label_da05c13f:

    # MC "See you later, Mom. Love you too!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:106
translate chinese after_ml_workR2_AS1_label_f0422f20:

    # MC "(Hmm... Linda appears to be quite occupied. Maybe I should her with house chores, after work? She should be in the kitchen or in the bedroom.)"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:108
translate chinese after_ml_workR2_AS1_label_b0fa86cd:

    # MC "See you later, Linda. Love you too!"
    MC ""

# game/scripts/ml_work/room1/scenes/ml_workR2_AS1.rpy:109
translate chinese after_ml_workR2_AS1_label_35e673d5:

    # MC "(Hmm... Linda appears to be quite occupied. Maybe I should offer to assist her with household chores after work? She might be in the kitchen or the bedroom.)"
    MC ""

