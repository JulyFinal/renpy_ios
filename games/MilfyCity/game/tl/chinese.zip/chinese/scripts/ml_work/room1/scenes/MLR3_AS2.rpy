﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:20
translate chinese MLR3_AS2_6a4c1aa8:

    # Mom "Not now, [player_name]."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:34
translate chinese MLR3_AS2_7faf3e86:

    # Mom "Hi, Sweetie. I’m glad you could make it today."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:35
translate chinese MLR3_AS2_7afd26da:

    # MC "Afternoon, [Mom_name]. I’ll just get started on the cleaning here."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:36
translate chinese MLR3_AS2_53976a29:

    # Mom "Try and be quick with it today, we need to have a talk."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:37
translate chinese MLR3_AS2_253ce698:

    # MC "Huh? Is something wrong?"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:38
translate chinese MLR3_AS2_34c9222e:

    # Mom "No, nothing’s wrong. We can talk about it later on. Right now, I need you to finish tidying the office."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:39
translate chinese MLR3_AS2_85faa3e5:

    # MC "(Weird, I wonder what that’s about.)"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:54
translate chinese MLR3_AS2_385a75ca:

    # Mom "Is that you all finished?"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:55
translate chinese MLR3_AS2_885777b0:

    # MC "Yeah, that’s the office tidy again."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:59
translate chinese MLR3_AS2_853af975:

    # MC "(I swear to God though, I think [Mom_name]’s staff are wrecking the place on purpose! Every time I come back to clean it, the whole place is filthy!)"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:60
translate chinese MLR3_AS2_dd1b352e:

    # Mom "Excellent! C’mon over here and grab a seat with me on the couch."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:65
translate chinese MLR3_AS2_dbe4e058:

    # Mom "Okay, I’m gonna be proposing an idea - and I want you to hear me out."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:66
translate chinese MLR3_AS2_a057facc:

    # MC "Alright... Shoot."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:68
translate chinese MLR3_AS2_14168ab8:

    # Mom "You know the way that your father is always around the house and we can never get any time alone together?"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:70
translate chinese MLR3_AS2_9bf08677:

    # Mom "You know the way that Bob is always around the house and we can never get any time alone together?"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:71
translate chinese MLR3_AS2_111dfaaa:

    # MC "Wait - you aren’t gonna kick him out, are you?!"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:75
translate chinese MLR3_AS2_0147b3f0:

    # Mom "Relax! I’m not going to kick your father out! Let me finish, and you’ll understand where I’m coming from."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:76
translate chinese MLR3_AS2_4ae42412:

    # MC "(Thank God... if I was responsible for having Dad kicked out of the house, I’d feel so damn guilty right now.)"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:77
translate chinese MLR3_AS2_d1d781e9:

    # Mom "Your father and me both work long hours. We’re not home till the evenings, and the only private time you and I get together, is when he goes on one of his increasingly rare business trips."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:79
translate chinese MLR3_AS2_ff322eee:

    # Mom "Relax! I’m not going to kick Bob out! Let me finish and you’ll understand where I’m coming from."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:80
translate chinese MLR3_AS2_c9a58b6b:

    # MC "(Thank God... if I was responsible for having Bob kicked out of the house, I’d feel so damn guilty right now.)"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:81
translate chinese MLR3_AS2_15ef76ae:

    # Mom "Bob and me both work long hours. We’re not home till the evenings, and the only private time you and I get together, is when he goes on one of his increasingly rare business trips."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:84
translate chinese MLR3_AS2_c909444a:

    # Mom "I want more than rushed quickies, always panicking that he’ll come home from work early."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:85
translate chinese MLR3_AS2_66f95cc4:

    # Mom "I want to actually be able to snuggle up next to you after sex, to fall asleep with you in my arms, to have a proper romantic relationship."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:87
translate chinese MLR3_AS2_53c4d21e:

    # Mom "I can’t do ANY of those things with your father around... but I can’t kick him out either."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:89
translate chinese MLR3_AS2_f2cb5dd1:

    # Mom "I can’t do ANY of those things with him around... but I can’t kick him out either."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:93
translate chinese MLR3_AS2_78ba4125:

    # Mom "I might not... feel the same way I have always felt about him, but you three still need a father."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:94
translate chinese MLR3_AS2_9fc69159:

    # Mom "Caroline’s strong. She’ll get by fine if he leaves and you might even be okay. But Sara... I don’t know how she’d react if he left. She loves her dad."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:95
translate chinese MLR3_AS2_06c7e5d6:

    # Mom "So, no. I’m not kicking your father out. He’s staying with us, at least until all three of you are ready to move out to your own places."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:97
translate chinese MLR3_AS2_bdb976d2:

    # Mom "I might not... feel the same way I have always felt about him, but we still have two decades of marriage between us and we own this home together. That’s got to count for something."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:98
translate chinese MLR3_AS2_bc005e76:

    # Mom "And then there's the fact you three have been renting here for a while now. Caroline's strong, she'll get by fine if he leaves - and you might even be okay. But Sara... I don't know how she'd react. "
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:99
translate chinese MLR3_AS2_ddff3d1a:

    # Mom "So, no. I'm not kicking my husband out. He's staying with us."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:102
translate chinese MLR3_AS2_4588e6a0:

    # MC "That’s... actually kinda relieving to hear, [Mom_name]. I know you probably don’t love him much anymore - but he’s still a good dad."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:104
translate chinese MLR3_AS2_a11a277d:

    # MC "That’s... actually kinda relieving to hear, Linda. I know you probably don’t love him much anymore - but he’s still a good guy and doesn’t deserve to be kicked out."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:109
translate chinese MLR3_AS2_5e821724:

    # Mom "ANYWAY! That wasn’t what I wanted to talk to you about. Sorry for killing the mood there."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:110
translate chinese MLR3_AS2_d1311d95:

    # Mom "I’ve got a plan to get us a whole day and night to ourselves - just you and me. Nobody else."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:111
translate chinese MLR3_AS2_2cd8f7fe:

    # MC "Really?! How?"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:115
translate chinese MLR3_AS2_c07e9588:

    # Mom "I’m gonna tell your dad that I’ve got a work trip coming up. I’ll have to be away for a full day."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:116
translate chinese MLR3_AS2_774f0369:

    # Mom "He won’t mind - I’m sure that your dad will love having the house to himself, for a change. He can sit back and smoke his goddamn cigars, without me nagging him!"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:118
translate chinese MLR3_AS2_70bf487c:

    # Mom "I’m gonna tell Bob that I’ve got a work trip coming up. I’ll have to be away for a full day."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:119
translate chinese MLR3_AS2_e0022502:

    # Mom "He won’t mind - I’m sure Bob will love having the house to himself, for a change. He can sit back and smoke his goddamn cigars, without me nagging him!"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:120
translate chinese MLR3_AS2_d1259a42:

    # Mom "You’re gonna secretly come with me, and we’ll sneak away together on a romantic getaway!"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:124
translate chinese MLR3_AS2_ec6a87f6:

    # MC "Okay, but what about my college classes?"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:126
translate chinese MLR3_AS2_912c904f:

    # Mom "I’ll tell your dad that you have a college trip coming up. Something like a team building and leadership course."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:127
translate chinese MLR3_AS2_de8f020c:

    # Mom "That will erase any suspicion that your dad has, about us disappearing on the same day. (Although, to be honest, I think that dolt is too dense for suspicion.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:129
translate chinese MLR3_AS2_67bacb1f:

    # Mom "I’ll tell Bob that you have a college trip coming up. Something like a team building and leadership course."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:130
translate chinese MLR3_AS2_454b28bb:

    # Mom "That will erase any suspicion Bob has, about us disappearing on the same day. (Although, to be honest, I think that dolt is too dense for suspicion.)"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:134
translate chinese MLR3_AS2_4a6bc5bb:

    # MC "It’s a good idea - but I’m not gonna be able to just skip college. Life isn’t a video game where there’s no consequences for not attending."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:136
translate chinese MLR3_AS2_2feb8bd9:

    # MC "Especially after my last incident with the Professor..."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:137
translate chinese MLR3_AS2_ee4a8b34:

    # Mom "I know, I know. That’s the ONLY kink in my plan right now. As soon as I figure that part out, we’ll be good to go."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:138
translate chinese MLR3_AS2_6dc51a62:

    # Mom "I haven’t told you where I wanted to take us yet, have I?"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:142
translate chinese MLR3_AS2_b279810f:

    # MC "Does it matter? If I can't obtain an exemption from college, then it would be best not to go at all, as my future depends on it."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:143
translate chinese MLR3_AS2_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:144
translate chinese MLR3_AS2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:145
translate chinese MLR3_AS2_536d81c2:

    # Mom "It was the beach, Sweetie. I wanted to take us far away to the coast and enjoy relaxing on the sunny sands together."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:146
translate chinese MLR3_AS2_022a2d46:

    # Mom "As for your college, I think I have an idea. See if you can get an exemption to miss some classes without impacting your grade."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:147
translate chinese MLR3_AS2_ee1755ec:

    # Mom "Maybe try to speak with your therapist?"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:148
translate chinese MLR3_AS2_a31ada95:

    # MC "My therapist? Do you know her?"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:149
translate chinese MLR3_AS2_fdf5d857:

    # Mom "W-what? No.. I think it's just the best choice."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:152
translate chinese MLR3_AS2_070c10bd:

    # MC "Hmm... An exemption?"
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:153
translate chinese MLR3_AS2_2cedbc91:

    # Mom "I don’t care what nonsense you have to tell them. Call it an emergency, or a medical appointment. Just say whatever you need to in order to get that day off. "
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:156
translate chinese MLR3_AS2_56ed4385:

    # Mom "See if you can get it in writing too - and then give it to your dad. It’ll help keep him off our trail."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:158
translate chinese MLR3_AS2_f78e509c:

    # Mom "See if you can get it in writing too - and then give it to Bob. It’ll help keep him off our trail."
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:162
translate chinese MLR3_AS2_2ad5dd30:

    # MC "No problem, [Mom_name]. I’ll get that done as soon as possible."
    MC ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:163
translate chinese MLR3_AS2_1734a91e:

    # Mom "Thank you, Sweetie. I really do love you. You know that?"
    Mom ""

# game/scripts/ml_work/room1/scenes/MLR3_AS2.rpy:164
translate chinese MLR3_AS2_59143b5c:

    # MC "I know, [Mom_name]. I love you too."
    MC ""

