﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_home/Vi_Spa.rpy:18
translate chinese Vi_Spa_locked_aeb91391:

    # MC "(It's locked.)"
    MC ""

