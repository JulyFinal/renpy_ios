﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Vi_home/Vi_kitchen.rpy:20
translate chinese Vi_kitchen_door_locked_aeb91391:

    # MC "(It's locked.)"
    MC ""

