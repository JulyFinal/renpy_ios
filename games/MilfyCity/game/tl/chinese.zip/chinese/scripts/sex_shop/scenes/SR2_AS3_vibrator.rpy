﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:19
translate chinese SR2_AS3_vibrator_label_610fed68:

    # S "Do you have the $80?"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:20
translate chinese SR2_AS3_vibrator_label_f905203d:

    # MC "Here you are."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:21
translate chinese SR2_AS3_vibrator_label_5f6999b6:

    # S "Thank you very much! Come again!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:28
translate chinese SR2_AS3_vibrator_label_1c9f968d:

    # S "Do you have the $80??"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:29
translate chinese SR2_AS3_vibrator_label_9095325f:

    # MC "Not yet."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:35
translate chinese SR2_AS3_vibrator_label_08820188:

    # MC "(This is probably the best place to get a vibrator for Sara. I’ve no idea which type to get her though.)"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:36
translate chinese SR2_AS3_vibrator_label_fefd1542:

    # MC "(I should probably ask the girl behind the counter. She might be able to to give me some advice.)"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:37
translate chinese SR2_AS3_vibrator_label_28b42f01:

    # MC "(Damn, she’s so fucking sexy! Just look at how much cleavage she’s showing off!)"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:38
translate chinese SR2_AS3_vibrator_label_68306ceb:

    # S "Hello there? Can I help you? Or are you just gonna keep staring at me?"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:39
translate chinese SR2_AS3_vibrator_label_5d094af5:

    # MC "I- uh... I... wanted to buy a vibrator."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:43
translate chinese SR2_AS3_vibrator_label_d6dc1853:

    # S "Ooh, a guy buying a vibrator... Kinky."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:45
translate chinese SR2_AS3_vibrator_label_9c1b7d16:

    # MC "No! It’s not for me! It’s for my sister!"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:46
translate chinese SR2_AS3_vibrator_label_87a00e99:

    # S "Your sister?!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:48
translate chinese SR2_AS3_vibrator_label_55e56b72:

    # MC "No! It’s not for me! It’s for my friend!"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:49
translate chinese SR2_AS3_vibrator_label_3a53b688:

    # S "Your friend?!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:50
translate chinese SR2_AS3_vibrator_label_a70c5cab:

    # MC "(FUCK!)"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:51
translate chinese SR2_AS3_vibrator_label_ebfa7cd9:

    # MC "S-Sorry! I mean, my... uh... my girlfriend. I’m sorry, I’m just really nervous right now."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:55
translate chinese SR2_AS3_vibrator_label_c881362c:

    # S "Hehe... It’s okay. So, has your sister- I mean, “girlfriend”, used a vibrator before?"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:57
translate chinese SR2_AS3_vibrator_label_d418af0f:

    # S "Hehe... It’s okay. So, has your friend- I mean, “girlfriend”, used a vibrator before?"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:58
translate chinese SR2_AS3_vibrator_label_d568dc50:

    # MC "Yes... I mean I think so.. My GIRLFRIEND is very shy about that kind of thing so maybe something small?"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:59
translate chinese SR2_AS3_vibrator_label_6f355eb8:

    # MC "Y’know, one that isn’t too strong and maybe smaller than average?"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:63
translate chinese SR2_AS3_vibrator_label_893c7e9c:

    # S "Oh no, honey. You don’t want to do that."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:64
translate chinese SR2_AS3_vibrator_label_a251265d:

    # S "Go big or go home! That’s what I always say."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:68
translate chinese SR2_AS3_vibrator_label_fba26fd6:

    # MC "Err... Are you sure?"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:69
translate chinese SR2_AS3_vibrator_label_7c701ccd:

    # S "Ab-so-lutely!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:70
translate chinese SR2_AS3_vibrator_label_283cc19d:

    # S "You sit tight, honey. I'm just gonna check what I still have in stock."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:71
translate chinese SR2_AS3_vibrator_label_d177c2be:

    # S "Hmm... Too small... Too thin..."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:72
translate chinese SR2_AS3_vibrator_label_8c3fe27b:

    # S "AHA!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:76
translate chinese SR2_AS3_vibrator_label_372046e9:

    # S "This baby is the Double Deluxe 9000. Made in California, from the highest quality materials."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:77
translate chinese SR2_AS3_vibrator_label_fe15f24e:

    # MC "(Jesus Christ... That thing’s massive!)"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:78
translate chinese SR2_AS3_vibrator_label_4f497db3:

    # MC "I... uh..."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:79
translate chinese SR2_AS3_vibrator_label_72c0386a:

    # S "Here, hold it!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:84
translate chinese SR2_AS3_vibrator_label_49cee31a:

    # MC "It’s... um... very pink."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:85
translate chinese SR2_AS3_vibrator_label_ae75d2d2:

    # S "Your girlfriend will love it!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:86
translate chinese SR2_AS3_vibrator_label_2ad46268:

    # S "It’s also one of the most intense vibrators on the market."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:87
translate chinese SR2_AS3_vibrator_label_98da997b:

    # MC "Just how powerful IS this thing?"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:88
translate chinese SR2_AS3_vibrator_label_1d733f32:

    # S "Well, if the average vibrator on the market is a five out of then, this thing is an eight or nine."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:92
translate chinese SR2_AS3_vibrator_label_0344e4c7:

    # MC "Are you sure I shouldn’t settle for a less powerful one?"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:93
translate chinese SR2_AS3_vibrator_label_65a884b5:

    # S "Trust me, honey. She’ll appreciate, you going big! Get some courage!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:94
translate chinese SR2_AS3_vibrator_label_8c08f705:

    # MC "*Gulp* If you’re sure. How much do I owe you?"
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:95
translate chinese SR2_AS3_vibrator_label_7981bc2d:

    # S "That’ll be 80$."
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:98
translate chinese SR2_AS3_vibrator_label_5f6999b6_1:

    # S "Thank you very much! Come again!"
    S ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:104
translate chinese SR2_AS3_vibrator_label_1fd0378c:

    # MC "I don't have enough money now."
    MC ""

# game/scripts/sex_shop/scenes/SR2_AS3_vibrator.rpy:105
translate chinese SR2_AS3_vibrator_label_603711dd:

    # MC "I'll come back later."
    MC ""

