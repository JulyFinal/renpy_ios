﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/sex_shop/sex_shop.rpy:13
translate chinese sex_shop_label_2631a8a4:

    # MC "Closed. It's open only in the evening."
    MC ""

# game/scripts/sex_shop/sex_shop.rpy:18
translate chinese sex_shop_label_2631a8a4_1:

    # MC "Closed. It's open only in the evening."
    MC ""

# game/scripts/sex_shop/sex_shop.rpy:104
translate chinese sex_shop_table_label_a48a4021:

    # S "Oh! New customer! Nice. Just look what I have for sale."
    S ""

# game/scripts/sex_shop/sex_shop.rpy:110
translate chinese sex_shop_table_label_fd913c4c:

    # S "Welcome."
    S ""

# game/scripts/sex_shop/sex_shop.rpy:197
translate chinese dildo_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/sex_shop/sex_shop.rpy:216
translate chinese sexy_cloth_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/sex_shop/sex_shop.rpy:236
translate chinese vibrator_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/sex_shop/sex_shop.rpy:257
translate chinese lube_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

