﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:100
translate chinese MLR3_beach_ice_e186e0fe:

    # MC "Fancy an ice lolly?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:101
translate chinese MLR3_beach_ice_91b46a33:

    # Mom "Sure! Why not?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:113
translate chinese MLR3_beach_ice_83888390:

    # MC "There you go! One strawberry ice lolly."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:114
translate chinese MLR3_beach_ice_ea9e1c03:

    # Mom "Thanks! How much do I owe you?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:115
translate chinese MLR3_beach_ice_6bec2bb8:

    # MC "Relax - you paid for the holiday, remember?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:119
translate chinese MLR3_beach_ice_8c20f667:

    # Mom "*Lick*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:120
translate chinese MLR3_beach_ice_37ac34f0:

    # MC "So, how did you find this place? You’ve never told me about it before."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:121
translate chinese MLR3_beach_ice_7b8d30c4:

    # MC "In fact, I don’t think I’ve ever heard you talk about this place to any of us. Unless you maybe mentioned it to [Dad_name] in private?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:125
translate chinese MLR3_beach_ice_2008dd12:

    # Mom "No one except me knows about this place. Well... I guess you do too now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:127
translate chinese MLR3_beach_ice_2893602b:

    # Mom "But I want you to keep that a secret. I need a getaway from everything. From family, from work, from everything."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:129
translate chinese MLR3_beach_ice_bccad28c:

    # Mom "But I want you to keep that a secret. I need a getaway from everything."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:130
translate chinese MLR3_beach_ice_2597d429:

    # Mom "I hope you realise the significance of me inviting you to this beach. It’s the most private place I have in the world."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:134
translate chinese MLR3_beach_ice_8c20f667_1:

    # Mom "*Lick*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:135
translate chinese MLR3_beach_ice_1ccb084d:

    # MC "I understand, [Mom_name]. Don’t worry, I won’t tell a soul."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:139
translate chinese MLR3_beach_ice_40f65bd5:

    # Mom "Not even Sara or Caroline. I know you and them sometimes hang out."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:140
translate chinese MLR3_beach_ice_c1cb2e89:

    # MC "Relax! I promise, I won’t tell ANYONE!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:141
translate chinese MLR3_beach_ice_59490071:

    # Mom "Hmm, good."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:145
translate chinese MLR3_beach_ice_e437bace:

    # MC "Can you really call it your secret place, when there are so many other people around, though?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:146
translate chinese MLR3_beach_ice_512d0b2e:

    # Mom "They’re mostly locals who live around the area. They’re quiet, for the most part. They don’t harass me or bother me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:147
translate chinese MLR3_beach_ice_18b46e08:

    # MC "Hmm, fair enough. How’s the ice lolly?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:151
translate chinese MLR3_beach_ice_02b638f8:

    # Mom "Mmm! It’s good. Thanks again for buying it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:152
translate chinese MLR3_beach_ice_68e35a44:

    # Mom "That sun feels so good on my back right now. Ah..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:153
translate chinese MLR3_beach_ice_bd07b1bb:

    # MC "(I love the way the sun makes her skin shimmer.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:157
translate chinese MLR3_beach_ice_31e3a3ea:

    # MC "[Mom_name], do you mind if I ask you a bit of a... personal question?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:158
translate chinese MLR3_beach_ice_e6bb5574:

    # Mom "Hmm? It depends what the question is."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:159
translate chinese MLR3_beach_ice_c25c6b55:

    # MC "It was... um... Did you start coming here to get away from [Dad_name]? I know you two haven’t been getting on, for some time."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:163
translate chinese MLR3_beach_ice_9cc68256:

    # Mom "*Sigh* Let’s not spoil today with talk of your father. Okay?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:165
translate chinese MLR3_beach_ice_74ecf5ec:

    # Mom "*Sigh* Let’s not spoil today with talk of Bob. Okay?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:166
translate chinese MLR3_beach_ice_8ba1a356:

    # MC "Sorry, [Mom_name]. Yeah, we can talk about other stuff."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:170
translate chinese MLR3_beach_ice_a2496aa2:

    # Mom "Mmm... Delicious!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:171
translate chinese MLR3_beach_ice_072b223e:

    # MC "Pass me the stick and I’ll toss it in the trash for you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:172
translate chinese MLR3_beach_ice_0f1b10c6:

    # Mom "Thanks! I’ll just be hanging out here. Give me a shout if you think of anything else we can do together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:186
translate chinese MLR3_beach_sun_7230253c:

    # MC "Hey, [Mom_name]! Do you want me to rub some suncream on your back for you?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:187
translate chinese MLR3_beach_sun_9576b81b:

    # Mom "Sure! Go ahead. Do my whole body, if you want. I should really take better care of my skin."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:188
translate chinese MLR3_beach_sun_f3832c08:

    # MC "No problem, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:199
translate chinese MLR3_beach_sun_2cc23038:

    # MC "(She looks so beautiful, just lying there in the sun.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:200
translate chinese MLR3_beach_sun_116dde09:

    # MC "(Of course, she’d look even hotter, lying the other way - but this isn’t half bad at all!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:204
translate chinese MLR3_beach_sun_b1b7c50a:

    # Mom "How strong is it?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:205
translate chinese MLR3_beach_sun_d4cd9520:

    # MC "Hmm.. Wait a minute. Let me find it..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:206
translate chinese MLR3_beach_sun_04cbc937:

    # MC "Ah! There it is!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:210
translate chinese MLR3_beach_sun_1060e0c3:

    # MC "Factor thirty."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:211
translate chinese MLR3_beach_sun_d7bbf402:

    # Mom "Yeah, that’ll do fine. I’ll still get a nice tan with that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:215
translate chinese MLR3_beach_sun_35396cb4:

    # MC "(Okay, let’s get this started! I’ll get a nice dollop of this in my hand.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:216
translate chinese MLR3_beach_sun_efde277e:

    # MC "I’m gonna put it on now, [Mom_name]. It might be a little chilly, at first - just a heads up!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:217
translate chinese MLR3_beach_sun_da258171:

    # Mom "No problem."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:221
translate chinese MLR3_beach_sun_0732b1ec:

    # MC "(Damn, she is so sexy!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:222
translate chinese MLR3_beach_sun_bc921a5a:

    # MC "(I love the way her skin glistens in the sunlight.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:223
translate chinese MLR3_beach_sun_864545f8:

    # MC "(Now, where should I start applying the suncream?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:231
translate chinese MLR3_beach_sun_menu_2d59573f:

    # MC "Okay, I’m gonna start with your back, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:232
translate chinese MLR3_beach_sun_menu_275874cc:

    # Mom "Uh huh, Honey..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:236
translate chinese MLR3_beach_sun_menu_50f0275e:

    # MC "How’s that, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:237
translate chinese MLR3_beach_sun_menu_f02d2331:

    # Mom "Mmm... that’s really relaxing..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:238
translate chinese MLR3_beach_sun_menu_cbd704d5:

    # MC "(Her skin is so smooth! I’m glad she’s enjoying this.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:242
translate chinese MLR3_beach_sun_menu_4962a89d:

    # Mom "Oohhh... Right there! That’s a knot!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:243
translate chinese MLR3_beach_sun_menu_c3e4edd5:

    # Mom "Ah... Perrrfect!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:247
translate chinese MLR3_beach_sun_menu_ff7747d6:

    # Mom "Just... could you go down a couple of inches?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:248
translate chinese MLR3_beach_sun_menu_a2978dac:

    # MC "Sure, no problem."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:251
translate chinese MLR3_beach_sun_menu_d15cb462:

    # MC "Here?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:252
translate chinese MLR3_beach_sun_menu_c54fde9d:

    # Mom "Mmm! That’s it! Ahh... It’s been months since I last got a proper massage."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:262
translate chinese MLR3_beach_sun_menu_f3fdcd58:

    # MC "I’m gonna do your thighs now, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:263
translate chinese MLR3_beach_sun_menu_59db9061:

    # Mom "Sure, sure..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:267
translate chinese MLR3_beach_sun_menu_433a39ef:

    # MC "(Her thighs are so smooth, my fingers are just gliding over them.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:268
translate chinese MLR3_beach_sun_menu_81b2bb97:

    # Mom "Mmm, you can be a little harder, if you want. I don’t mind if you REALLY want to dig your fingers in."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:272
translate chinese MLR3_beach_sun_menu_f1c4d4d0:

    # Mom "Oh! I meant into my skin, but I guess in there is okay too. Hehe!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:273
translate chinese MLR3_beach_sun_menu_9176528d:

    # MC "Haha! Sorry, [Mom_name]. I misinterpreted what you said."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:274
translate chinese MLR3_beach_sun_menu_098f06d8:

    # Mom "Of course you did. Haha!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:278
translate chinese MLR3_beach_sun_menu_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:279
translate chinese MLR3_beach_sun_menu_71e723e5:

    # Mom "You’re so good with your fingers..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:283
translate chinese MLR3_beach_sun_menu_471ac0b1:

    # MC "I’m gonna do your glutes as well, while I’m here."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:284
translate chinese MLR3_beach_sun_menu_c48a95ba:

    # Mom "Uh huh... "
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:285
translate chinese MLR3_beach_sun_menu_6d5fcdcc:

    # Mom "(This is so relaxing, I could almost fall asleep while he rubs my body like this.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:289
translate chinese MLR3_beach_sun_menu_837d7835:

    # Mom "Huh?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:290
translate chinese MLR3_beach_sun_menu_f6dd4311:

    # MC "Sorry, they got in the way of my massage. I’ll pull them back up later."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:291
translate chinese MLR3_beach_sun_menu_c31ef301:

    # Mom "Is there anyone nearby to see us?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:295
translate chinese MLR3_beach_sun_menu_45aad2d2:

    # MC "Nah, nobody is close enough."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:297
translate chinese MLR3_beach_sun_menu_c4c2f459:

    # Mom "As long as you’re sure. Keep an eye out. I don’t want to get caught having my son rub my ass. Or WORSE, get banned from my favourite beach for public indecency!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:298
translate chinese MLR3_beach_sun_menu_e2a241be:

    # MC "(I would have thought that getting caught in an incestuous relationship was more embarrassing than getting banned from a beach - I guess we have different priorities!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:300
translate chinese MLR3_beach_sun_menu_dfa511a1:

    # Mom "As long as you’re sure. Keep an eye out. I don’t want to get caught having you rub my ass. Or WORSE, get banned from my favourite beach for public indecency!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:301
translate chinese MLR3_beach_sun_menu_b2638336:

    # MC "(I would have thought that getting caught in an extramarital relationship was more embarrassing than getting banned from a beach - I guess we have different priorities!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:305
translate chinese MLR3_beach_sun_menu_9898d277:

    # MC "There we go. Now your ass won’t get burnt either."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:306
translate chinese MLR3_beach_sun_menu_081f69f5:

    # Mom "Were you actually concerned about my ass, or did you just want an excuse to feel it?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:307
translate chinese MLR3_beach_sun_menu_cb00b734:

    # MC "Both are perfectly acceptable reasons."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:311
translate chinese MLR3_beach_sun_menu_aa53fb63:

    # Mom "Haha, I knew it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:312
translate chinese MLR3_beach_sun_menu_e87eb055:

    # MC "You can’t blame a guy for trying, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:316
translate chinese MLR3_beach_sun_menu_19da057b:

    # Mom "Alright, alright, you’ve had your fun. Time to pull my panties back up now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:317
translate chinese MLR3_beach_sun_menu_44abd9d8:

    # MC "Aww, okay. Haha!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:328
translate chinese MLR3_beach_sun_menu_b09277cd:

    # MC "Okay, I’m gonna massage your calf muscles for you now."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:329
translate chinese MLR3_beach_sun_menu_cc95be42:

    # Mom "Thanks, [player_name]. I spend so long standing up and walking around the office at work each day. I could do with a good deep tissue massage down there."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:330
translate chinese MLR3_beach_sun_menu_fb19aa9d:

    # MC "Well, it’s your lucky day, then!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:334
translate chinese MLR3_beach_sun_menu_30181835:

    # Mom "Mmm... Oh..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:335
translate chinese MLR3_beach_sun_menu_05cbc714:

    # MC "Sounds like you’re enjoying this!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:336
translate chinese MLR3_beach_sun_menu_89228325:

    # Mom "Oh yeah... Your hands are magical."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:340
translate chinese MLR3_beach_sun_menu_296ff892:

    # Mom "Mmm, that’s sooo good...."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:341
translate chinese MLR3_beach_sun_menu_7a191a20:

    # MC "(I’m glad I’m able to make her happy like this.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:345
translate chinese MLR3_beach_sun_menu_c3067d40:

    # Mom "That’ll do. Thank you so much, [player_name]."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:346
translate chinese MLR3_beach_sun_menu_eda86eba:

    # MC "No problem, [Mom_name]! Glad you enjoyed it!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:357
translate chinese MLR3_beach_sun2_4164a118:

    # Mom "Hey, it’s not fair that I have all the fun! If you keep that up, I’m just going to fall asleep, relaxing on the beach."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:358
translate chinese MLR3_beach_sun2_58ff4b2b:

    # MC "It’s okay, I don’t mind."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:359
translate chinese MLR3_beach_sun2_22b90c80:

    # Mom "Well, I do. This was a holiday for BOTH of us!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:363
translate chinese MLR3_beach_sun2_4f77b96e:

    # Mom "Lie down for me. I’ll give YOU a massage now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:364
translate chinese MLR3_beach_sun2_bb53f9f1:

    # MC "Are you sure, [Mom_name]? You don’t have to."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:365
translate chinese MLR3_beach_sun2_214cf8c0:

    # Mom "I insist on it!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:366
translate chinese MLR3_beach_sun2_3b3aab85:

    # MC "Do you want me face down?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:370
translate chinese MLR3_beach_sun2_44406fc1:

    # Mom "No, just like this, is perfect."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:371
translate chinese MLR3_beach_sun2_8c88c8fe:

    # Mom "I’m gonna start off by rubbing my hands all over your chest."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:372
translate chinese MLR3_beach_sun2_ac507234:

    # Mom "(Mmm... He looks so fit. I wish it was just us on the beach.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:376
translate chinese MLR3_beach_sun2_7cafef06:

    # Mom "(If that was the case I’d strip those swim shorts off him and straddle his cock right now.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:377
translate chinese MLR3_beach_sun2_808a3f32:

    # Mom "(God, I’m getting so wet just imagining it.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:381
translate chinese MLR3_beach_sun2_7fa10c2b:

    # MC "Ow! Cold!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:382
translate chinese MLR3_beach_sun2_4ef3b53c:

    # Mom "Hehe! Sorry! Let me rub it in, to warm it up for you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:386
translate chinese MLR3_beach_sun2_51c5570e:

    # MC "Mmm... That’s nice, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:387
translate chinese MLR3_beach_sun2_7fce24af:

    # Mom "Well, you gave me a very lovely massage. It’s only proper that I return the favour."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:391
translate chinese MLR3_beach_sun2_b336dc87:

    # MC "Ahh... That’s perfect..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:392
translate chinese MLR3_beach_sun2_1f9b2df3:

    # Mom "(I can feel his cock stiffening, under his shorts.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:393
translate chinese MLR3_beach_sun2_76b3e98f:

    # Mom "(Every time I rub up and down his chest, it grinds against my pussy.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:397
translate chinese MLR3_beach_sun2_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:398
translate chinese MLR3_beach_sun2_b9068c80:

    # Mom "What?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:399
translate chinese MLR3_beach_sun2_5bebced9:

    # MC "Your eyes. They’re... indescribable."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:403
translate chinese MLR3_beach_sun2_059cb9cf:

    # Mom "Hehe, you’re just putting on the charm. Aren’t you?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:404
translate chinese MLR3_beach_sun2_648ec7b4:

    # MC "No, I’m serious. They’re so, so beautiful. The way they twinkle in the sunlight - is just mystical."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:408
translate chinese MLR3_beach_sun2_975cc138:

    # Mom "Aww, thank you, Sweetie."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:409
translate chinese MLR3_beach_sun2_ea9b40f9:

    # Mom "That’s your chest all done. Shall we do something else together now?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:410
translate chinese MLR3_beach_sun2_d74cf381:

    # MC "Yeah, sure!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:433
translate chinese MLR3_beach_wait_for_e_524be518:

    # MC "God... I’m exhausted. That was a REALLY busy day."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:434
translate chinese MLR3_beach_wait_for_e_2c36d73e:

    # Mom "Yeah, we sure did a lot of stuff."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:435
translate chinese MLR3_beach_wait_for_e_be09ac06:

    # MC "What was your favourite part?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:439
translate chinese MLR3_beach_wait_for_e_38ebffc7:

    # Mom "Haha, the part you didn’t like! The cliff jumping!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:440
translate chinese MLR3_beach_wait_for_e_486e3ace:

    # MC "I never knew you were into that."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:441
translate chinese MLR3_beach_wait_for_e_ff2ebbc9:

    # Mom "I used to do mountain climbing and then abseiling in my teenage years. I overcame any fear of heights I had, back then."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:445
translate chinese MLR3_beach_wait_for_e_7224d012:

    # Mom "I just love the adrenaline rush, from the moment you leap."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:446
translate chinese MLR3_beach_wait_for_e_d3717fa4:

    # Mom "How about you? Did you have a favourite part?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:447
translate chinese MLR3_beach_wait_for_e_3d77164e:

    # MC "I loved it all. This whole day with you was just... perfect."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:451
translate chinese MLR3_beach_wait_for_e_1db3b01f:

    # Mom "I know. *Sigh*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:452
translate chinese MLR3_beach_wait_for_e_87ee91d6:

    # Mom "I love this time of the day. The moment when the sun isn’t singeing your skin anymore, but it still isn’t cold or dark."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:453
translate chinese MLR3_beach_wait_for_e_c82fa5a3:

    # MC "Do you wanna head on soon?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:457
translate chinese MLR3_beach_wait_for_e_a81c7a0d:

    # Mom "Wait another hour with me here. I want to show you something magical."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:458
translate chinese MLR3_beach_wait_for_e_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:459
translate chinese MLR3_beach_wait_for_e_d4e8106e:

    # Mom "Do you see those rocky hills? Keep your eyes on them."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:464
translate chinese MLR3_beach_wait_for_e_8a15c77c:

    # "***One Hour Later***"
    ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:469
translate chinese MLR3_beach_wait_for_e_a22a368f:

    # Mom "[player_name]! Come and see!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:470
translate chinese MLR3_beach_wait_for_e_79f21d3f:

    # MC "Huh? Oh wow..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:471
translate chinese MLR3_beach_wait_for_e_ebfb467b:

    # Mom "It’s beautiful, isn’t it?!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:475
translate chinese MLR3_beach_wait_for_e_ee21adc9:

    # Mom "I sometimes pretend I have business trips, just so I can get away here, by myself. It’s my own private getaway from the world."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:476
translate chinese MLR3_beach_wait_for_e_70e55ef2:

    # MC "You’re lucky to have found this place! Where do you usually stay?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:477
translate chinese MLR3_beach_wait_for_e_6e100d69:

    # Mom "There’s a small chalet, I rent fairly often. I keep it well maintained, so the landlord gives me good rates on it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:481
translate chinese MLR3_beach_wait_for_e_55840950:

    # Mom "Speaking of which... that’s where we’re heading now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:482
translate chinese MLR3_beach_wait_for_e_3b1cfc06:

    # Mom "Grab your stuff and we’ll go inside, to relax and unwind for the night."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:483
translate chinese MLR3_beach_wait_for_e_a966a1cb:

    # MC "Awesome! Thanks for planning this for us, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:493
translate chinese MLR3_beach_wait_for_e_3c808592:

    # Mom "Ahh, finally! Here at last!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:494
translate chinese MLR3_beach_wait_for_e_a03231c5:

    # MC "We made it just as the sun finished setting."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:495
translate chinese MLR3_beach_wait_for_e_83d201f3:

    # Mom "Yeah, I must have done that walk to the beach, two dozen times now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:499
translate chinese MLR3_beach_wait_for_e_b43cf6b5:

    # Mom "What do you think of the place, then?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:500
translate chinese MLR3_beach_wait_for_e_c8403ca8:

    # MC "It’s really stylish and modern!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:501
translate chinese MLR3_beach_wait_for_e_43d2a190:

    # Mom "Not what you were expecting?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:505
translate chinese MLR3_beach_wait_for_e_0842f661:

    # MC "Honestly? No. I was having visions of this run down, cheap chalet. Y’know, the kind they stick tourists on package holidays in."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:506
translate chinese MLR3_beach_wait_for_e_32924666:

    # Mom "Haha! I’m insulted that you think I’d stay in somewhere like THAT!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:507
translate chinese MLR3_beach_wait_for_e_4fe77fc8:

    # MC "Haha, sorry!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:511
translate chinese MLR3_beach_wait_for_e_a657b66f:

    # MC "I gotta hand it to you though, you chose well!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:512
translate chinese MLR3_beach_wait_for_e_3fdfd487:

    # Mom "Thanks. I’ve tried a few different places around this area. This is the best value for money out of them all."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:513
translate chinese MLR3_beach_wait_for_e_9497f4cd:

    # Mom "Plus, it’s always clean and tidy. What more can you ask for?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:517
translate chinese MLR3_beach_wait_for_e_8373c99c:

    # Mom "I’ve got to do a couple of quick checks around the house. Would you be a dear and take my bag into the bedroom for me?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:518
translate chinese MLR3_beach_wait_for_e_9700a678:

    # MC "Sure, [Mom_name]. No problem."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:519
translate chinese MLR3_beach_wait_for_e_f42b6c84:

    # Mom "Thanks, Honey."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:523
translate chinese MLR3_beach_wait_for_e_3b3e7136:

    # MC "(Okay, now where is the bedroom?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:524
translate chinese MLR3_beach_wait_for_e_9ce4be47:

    # Mom "Give me a shout when you’ve finished!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:525
translate chinese MLR3_beach_wait_for_e_f2907102:

    # MC "Okay, [Mom_name]!"
    MC ""

translate chinese strings:

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:72
    old "Give her icecream. (disabled)"
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:72
    old "Give her icecream."
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:72
    old "Propose a massage. (disabled)"
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:72
    old "Propose a massage."
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:72
    old "Wait for the night. (disabled)"
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:72
    old "Wait for the night. "
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:227
    old "Rub the suncream onto her back."
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:227
    old "Rub the suncream into her thighs."
    new ""

    # game/scripts/beach/Beach_Event/MLR3_beach_event3.rpy:227
    old "Massage her calf muscles."
    new ""

