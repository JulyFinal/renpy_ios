﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:21
translate chinese MLR3_b_house_leaving_05789ceb:

    # Mom "Okay, I think that’s all my stuff packed up in the car. Have you got all your clothes?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:22
translate chinese MLR3_b_house_leaving_1782f48c:

    # MC "Yeah, everything’s in my bag."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:23
translate chinese MLR3_b_house_leaving_7752233e:

    # Mom "You haven’t left any underwear or socks lying around?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:24
translate chinese MLR3_b_house_leaving_05390589:

    # MC "No, [Mom_name]. I’ve got everything."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:26
translate chinese MLR3_b_house_leaving_60807fa9:

    # Mom "Good - I just don’t want the landlord finding men’s clothes in here, after I’ve been staying over. I don’t know if he’s the kind of man who would try to get in touch with your father, but it’s not worth the risk."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:28
translate chinese MLR3_b_house_leaving_6999a9ff:

    # Mom "Good - I just don’t want the landlord finding men’s clothes in here, after I’ve been staying over. I don’t know if he’s the kind of man who would try to get in touch with Bob, but it’s not worth the risk."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:32
translate chinese MLR3_b_house_leaving_3127bd76:

    # MC "You look amazing, by the way, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:33
translate chinese MLR3_b_house_leaving_4ef36e2e:

    # Mom "Aww, you’re very sweet. *Sigh* I’m going to miss these past two days."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:34
translate chinese MLR3_b_house_leaving_d8f80143:

    # Mom "I loved the scent of you, lying in bed beside me, while my eyes were closed. And the rustle of the sheets, as you moved during the night."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:36
translate chinese MLR3_b_house_leaving_89626796:

    # Mom "I don’t know why - but when I’m sleeping with your father, it always feels like I’m sleeping alone. Last night, was the first time in years, that it’s felt like another man is sleeping beside me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:38
translate chinese MLR3_b_house_leaving_328185d5:

    # Mom "I don’t know why - but when I’m sleeping with Bob, it always feels like I’m sleeping alone. Last night, was the first time in years, that it’s felt like another man is sleeping beside me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:39
translate chinese MLR3_b_house_leaving_78263d10:

    # Mom "Anyway, I’m rambling and being silly. We should hit the road."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:46
translate chinese MLR3_b_house_leaving_a342c779:

    # Mom "Got your seatbelt on?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:47
translate chinese MLR3_b_house_leaving_523b8820:

    # MC "Yes, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:48
translate chinese MLR3_b_house_leaving_2c406e32:

    # Mom "And both suitcases in the car?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:49
translate chinese MLR3_b_house_leaving_a188ec08:

    # MC "All bags are in the car, [Mom_name]. You’re worrying too much!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:50
translate chinese MLR3_b_house_leaving_9222cbc4:

    # Mom "*Sigh* I know, I know."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:51
translate chinese MLR3_b_house_leaving_f60f7b6f:

    # Mom "I guess... I guess I just want to make excuses, to stay here a while longer. I know we can’t though."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:59
translate chinese MLR3_b_house_leaving_d5160ae8:

    # Mom "And... that’s us home."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:60
translate chinese MLR3_b_house_leaving_20dc50f5:

    # MC "Why are we in the alley?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:61
translate chinese MLR3_b_house_leaving_b3da96a3:

    # Mom "You’re gonna need to walk, a bit. It’ll look suspicious if I drive home with you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:65
translate chinese MLR3_b_house_leaving_621d022b:

    # MC "Ahh, that makes sense. Good point."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:66
translate chinese MLR3_b_house_leaving_6440ae2b:

    # Mom "Just wait one or two minutes, after I drive off. You should make it home about fifteen minutes after me. That’ll eliminate any suspicion."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:67
translate chinese MLR3_b_house_leaving_0110ab48:

    # MC "No problem, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:71
translate chinese MLR3_b_house_leaving_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:72
translate chinese MLR3_b_house_leaving_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:73
translate chinese MLR3_b_house_leaving_aa8185b7:

    # Mom "I just want you to know that... yesterday was the best day, of my whole life."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:77
translate chinese MLR3_b_house_leaving_0b38eae9:

    # Mom "I haven’t felt so much excitement and joy in life, since I was a little girl. It was like Christmas, all over again."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:78
translate chinese MLR3_b_house_leaving_06f2cf1e:

    # Mom "Except, this wasn’t all Santa and magic because... everything we had was SO real."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:79
translate chinese MLR3_b_house_leaving_bb2d1ba2:

    # MC "I love you, [Mom_name]. I really do."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_leaving.rpy:80
translate chinese MLR3_b_house_leaving_1b3beb64:

    # Mom "I know. Right, I better drive on. I’ll see you when we both get home."
    Mom ""

