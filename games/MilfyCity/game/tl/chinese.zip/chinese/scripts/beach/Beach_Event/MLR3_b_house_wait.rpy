﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:25
translate chinese MLR3_b_house_wait_3fce195d:

    # MC "(Damn, that looks like a REALLY comfy bed.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:26
translate chinese MLR3_b_house_wait_3b9421b6:

    # MC "(This is where I’ll be sleeping with [Mom_name] tonight, then.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:30
translate chinese MLR3_b_house_wait_4386e9d2:

    # MC "(After all these weeks, it’s FINALLY going to happen. And there is no one around to interrupt us.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:31
translate chinese MLR3_b_house_wait_bbafe1a2:

    # MC "(We’ll make the most of tonight.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:35
translate chinese MLR3_b_house_wait_49f9be1e:

    # MC "(Hmm, very soft! This will be perfect for fucking on, together!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:36
translate chinese MLR3_b_house_wait_bae897dc:

    # MC "(I wonder what she needs ten minutes to do, before we meet?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:40
translate chinese MLR3_b_house_wait_cd2daeb0:

    # MC "Pfft... "
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:41
translate chinese MLR3_b_house_wait_54ad0153:

    # MC "(Ugh... It’s been like two minutes, and I’m already bored!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:45
translate chinese MLR3_b_house_wait_51a4ea6c:

    # MC "([Mom_name] was talking, earlier on... about time going faster, the older you got.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:46
translate chinese MLR3_b_house_wait_66e5367d:

    # MC "(I sure wish it would speed up right now, so we could both get started!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:50
translate chinese MLR3_b_house_wait_cb6cacb2:

    # MC "(I wonder if this will be the night that I finally fuck her?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:51
translate chinese MLR3_b_house_wait_44b05a0a:

    # MC "(What position will we do it in, for the first time?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:52
translate chinese MLR3_b_house_wait_eb163a9f:

    # MC "(I still have that condom with me, that [Dad_name] gave me too. So I’ve got protection. There’s nothing that should be in the way of us getting together.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:53
translate chinese MLR3_b_house_wait_5813b8d6:

    # MC "(I guess I’ll check out the bathroom while I’m waiting.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:63
translate chinese MLR3_b_house_wait_fdff423b:

    # MC "Wow! This place is huge!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:64
translate chinese MLR3_b_house_wait_6771e92a:

    # MC "Holy shit... It looks like it belongs in a mansion!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:68
translate chinese MLR3_b_house_wait_669b9d71:

    # MC "(This is like the most modern bathroom I’ve ever seen!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:69
translate chinese MLR3_b_house_wait_c3520300:

    # MC "(No wonder [Mom_name] loves renting this place)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:73
translate chinese MLR3_b_house_wait_8ff630e8:

    # MC "(A walk-in shower? It would be so fun to fuck [Mom_name], in that!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:74
translate chinese MLR3_b_house_wait_21e172f0:

    # MC "(I’m getting all excited at the thought of screwing her up against the wall while the hot water rushes over us.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:78
translate chinese MLR3_b_house_wait_e1df93e3:

    # MC "(Alright, it’s been WAY over ten minutes. Let’s go and see what [Mom_name] has been up to.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_wait.rpy:79
translate chinese MLR3_b_house_wait_0461f398:

    # MC "(I have to admit, I’m starting to feel a little bit nervous!)"
    MC ""

