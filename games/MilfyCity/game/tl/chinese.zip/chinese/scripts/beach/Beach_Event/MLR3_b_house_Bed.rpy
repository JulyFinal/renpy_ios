﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:182
translate chinese MLR3_b_house_Bed_22e53ad1:

    # MC "Hello, [Mom_name]? Are you ready yet?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:183
translate chinese MLR3_b_house_Bed_f7908098:

    # Mom "Oh yes, come on in, Sweetie."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:190
translate chinese MLR3_b_house_Bed_b7f585e7:

    # MC "Oh wow!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:191
translate chinese MLR3_b_house_Bed_4d60f952:

    # Mom "I’m gonna assume you like the new bra?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:192
translate chinese MLR3_b_house_Bed_51be40c4:

    # MC "It’s so hot!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:196
translate chinese MLR3_b_house_Bed_acb55453:

    # MC "And those stockings and panties are gorgeous too!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:201
translate chinese MLR3_b_house_Bed_c985747e:

    # Mom "I hope you like them. I picked them up, especially for you. I thought that these were the most erotic ones in the store."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:202
translate chinese MLR3_b_house_Bed_dbabad72:

    # MC "You chose well!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:203
translate chinese MLR3_b_house_Bed_9a46b5cc:

    # Mom "So, let’s get you all warmed up, before the main show. Do you want me to keep these high heels on?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:208
translate chinese MLR3_b_house_Bed_2b050c1f:

    # MC "Oh, hell yeah!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:209
translate chinese MLR3_b_house_Bed_897d119e:

    # Mom "Haha! I thought you’d like them."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:213
translate chinese MLR3_b_house_Bed_08155d96:

    # Mom "Before we go any further, I just wanted to make sure that you want to do it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:214
translate chinese MLR3_b_house_Bed_96684144:

    # MC "Do it, as in, fuck you?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:215
translate chinese MLR3_b_house_Bed_9f1b435d:

    # Mom "Yes, I wanted to make sure. I don’t want to force you into something if you’re not comfortable with it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:219
translate chinese MLR3_b_house_Bed_6d5d2baf:

    # MC "I’m completely comfortable with this! I’ve been looking forward to it for WEEKS!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:220
translate chinese MLR3_b_house_Bed_b6aa9c74:

    # Mom "Promise?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:221
translate chinese MLR3_b_house_Bed_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:225
translate chinese MLR3_b_house_Bed_167ff9d2:

    # Mom "You’re not gonna chicken out on me halfway through, are you?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:226
translate chinese MLR3_b_house_Bed_cea225ce:

    # MC "N-No!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:227
translate chinese MLR3_b_house_Bed_110ca993:

    # Mom "Not gonna blow your load early either?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:228
translate chinese MLR3_b_house_Bed_0cdc39fc:

    # MC "Of course not!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:232
translate chinese MLR3_b_house_Bed_a405ecf6:

    # Mom "Hehe, sorry. I just can’t resist teasing you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:233
translate chinese MLR3_b_house_Bed_e9e2e5ae:

    # Mom "I can’t wait to feel your cock, buried deep inside me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:234
translate chinese MLR3_b_house_Bed_faa00001:

    # MC "I love you so much, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:238
translate chinese MLR3_b_house_Bed_488626ce:

    # Mom "I love you too, [player_name]."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:239
translate chinese MLR3_b_house_Bed_4ab8f498:

    # Mom "This is going to be the best night of your life. I promise you that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:243
translate chinese MLR3_b_house_Bed_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:244
translate chinese MLR3_b_house_Bed_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:245
translate chinese MLR3_b_house_Bed_472a77a7:

    # MC "(God, she is such a great kisser!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:249
translate chinese MLR3_b_house_Bed_905aa1c7:

    # Mom "C’mon, let’s take this into the bedroom now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:250
translate chinese MLR3_b_house_Bed_35225448:

    # MC "Okay, do you want me to get undressed or-"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:254
translate chinese MLR3_b_house_Bed_57622ad2:

    # Mom "Just get in there! I’m not waiting another minute longer than I have to!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:255
translate chinese MLR3_b_house_Bed_e542ff87:

    # MC "(She must be REALLY turned on right now!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:259
translate chinese MLR3_b_house_Bed_9f7af486:

    # Mom "Get back on the bed there!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:260
translate chinese MLR3_b_house_Bed_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:267
translate chinese MLR3_b_house_Bed_0947429c:

    # Mom "I’m locking this door. I know that we’re the only two people here, but fate has a nasty way of keeping your cock from getting inside me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:268
translate chinese MLR3_b_house_Bed_1ab7794a:

    # Mom "And I’m not going to be tempting fate tonight."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:272
translate chinese MLR3_b_house_Bed_09d06ab8:

    # "*Click*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:275
translate chinese MLR3_b_house_Bed_e09a30b1:

    # Mom "No Bob, no sisters, no goddamn phones."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:277
translate chinese MLR3_b_house_Bed_edfe26ac:

    # Mom "No Bob, no interruptions, no goddamn phones."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:280
translate chinese MLR3_b_house_Bed_eb13297e:

    # Mom "Tonight is ONLY you and me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:281
translate chinese MLR3_b_house_Bed_fbec5f83:

    # Mom "I’m going to fuck you, over and over, until we’re both exhausted."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:282
translate chinese MLR3_b_house_Bed_0dd4b952:

    # MC "(I’ve never seen her this horny before!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:286
translate chinese MLR3_b_house_Bed_011c021c:

    # MC "(I guess there’s a lot of pent up sexual tension, when you get cockblocked every single time you try to screw your son.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:288
translate chinese MLR3_b_house_Bed_5e89be08:

    # MC "(I guess there’s a lot of pent up sexual tension when you get cockblocked every single time you try to screw someone.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:290
translate chinese MLR3_b_house_Bed_b80d2791:

    # MC "What are you waiting for then, [Mom_name]? I’m all ready for you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:294
translate chinese MLR3_b_house_Bed_5b4e88d0:

    # Mom "Strip off your clothes. "
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:295
translate chinese MLR3_b_house_Bed_f7795790:

    # MC "Yes, Ma’am."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:296
translate chinese MLR3_b_house_Bed_fa359a96:

    # Mom "Nice and slowly for me. I want to watch every inch of you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:300
translate chinese MLR3_b_house_Bed_4abb565e:

    # Mom "Mmm... Perfect."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:301
translate chinese MLR3_b_house_Bed_4bb799cf:

    # Mom "You look so delicious. I’m going to have SO much fun with you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:305
translate chinese MLR3_b_house_Bed_682d231b:

    # Mom "I love your massive cock. It’s so fucking huge. You know that?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:306
translate chinese MLR3_b_house_Bed_98c66beb:

    # Mom "God... I just want to climb on top of you and ride you silly."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:307
translate chinese MLR3_b_house_Bed_6d22433b:

    # MC "Well, what are you waiting for?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:311
translate chinese MLR3_b_house_Bed_e02a0f24:

    # Mom "I’m still debating how to kick this, all off."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:312
translate chinese MLR3_b_house_Bed_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:313
translate chinese MLR3_b_house_Bed_0d5935c9:

    # Mom "Well, we could start with a blowjob, to warm your cock up?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:317
translate chinese MLR3_b_house_Bed_4672dc8b:

    # Mom "Or maybe you’d prefer fucking my tits?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:318
translate chinese MLR3_b_house_Bed_102a6017:

    # MC "Or you could give me a footjob?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:319
translate chinese MLR3_b_house_Bed_dc2f7b0d:

    # Mom "If that’s what you’d like, we can."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:326
translate chinese MLR3_b_house_Bed_466d2285:

    # MC "Can we start with a blowjob?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:327
translate chinese MLR3_b_house_Bed_ce74793c:

    # Mom "Of course, Sweetie."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:328
translate chinese MLR3_b_house_Bed_b3a2dbb8:

    # Mom "You know I love sucking your big cock, don’t you?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:332
translate chinese MLR3_b_house_Bed_f1e73f4a:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:333
translate chinese MLR3_b_house_Bed_f4864c18:

    # MC "Mmm... Oh..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:337
translate chinese MLR3_b_house_Bed_8c74bce9:

    # Mom "*SHLUURRP*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:338
translate chinese MLR3_b_house_Bed_d0c8ed23:

    # MC "Fuck... Mmm! Yes..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:339
translate chinese MLR3_b_house_Bed_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:343
translate chinese MLR3_b_house_Bed_34ae0d56:

    # Mom "*GAG*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:345
translate chinese MLR3_b_house_Bed_616baf66:

    # MC "Mmm! (I love it when she deepthroats me like this!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:347
translate chinese MLR3_b_house_Bed_d653d47b:

    # MC "God, your mouth feels... ahh.. so good, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:351
translate chinese MLR3_b_house_Bed_f1e73f4a_1:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:352
translate chinese MLR3_b_house_Bed_d5c844f8:

    # MC "Ahh! Mmm!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:356
translate chinese MLR3_b_house_Bed_4187a265:

    # MC "Ohh... yes! Yes!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:357
translate chinese MLR3_b_house_Bed_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:361
translate chinese MLR3_b_house_Bed_78e65097:

    # MC "Fuck... This is so good!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:363
translate chinese MLR3_b_house_Bed_83b3acc7:

    # MC "Your tongue is amazing."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:367
translate chinese MLR3_b_house_Bed_af790ecb:

    # Mom "Hehe, I’m gonna have to stop now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:368
translate chinese MLR3_b_house_Bed_83841d6f:

    # MC "Aww, why?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:369
translate chinese MLR3_b_house_Bed_253927f4:

    # Mom "Because if I keep going, you’re going to cum!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:370
translate chinese MLR3_b_house_Bed_2b6c021b:

    # MC "Heh... yeah, I guess you’re right."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:375
translate chinese MLR3_b_house_Bed_1182f08c:

    # MC "Can I get a footjob?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:376
translate chinese MLR3_b_house_Bed_79cb0d4d:

    # Mom "Hehe, of course. I know how much you love having your cock rubbed by my feet."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:380
translate chinese MLR3_b_house_Bed_8c09c0e6:

    # Mom "How does it feel... with these fishnet tights on?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:381
translate chinese MLR3_b_house_Bed_5ede8089:

    # MC "Mmm... so good, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:385
translate chinese MLR3_b_house_Bed_c706a12d:

    # Mom "Hehe... I thought you’d like them like this."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:386
translate chinese MLR3_b_house_Bed_ac8d67bf:

    # Mom "(I can feel his cock, twitching between my feet.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:387
translate chinese MLR3_b_house_Bed_71c24fdc:

    # Mom "(I think he’s started leaking a little bit of precum. I better not tease him too much - I don’t want him cumming, before we begin.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:391
translate chinese MLR3_b_house_Bed_41b268f8:

    # MC "Hnng... Oh... fuck yeah..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:394
translate chinese MLR3_b_house_Bed_0d70508a:

    # Mom "It must feel SO good having mommy’s feet rub all over your shaft like this."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:396
translate chinese MLR3_b_house_Bed_74867174:

    # Mom "It must feel SO good having my feet rub all over your shaft like this."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:400
translate chinese MLR3_b_house_Bed_42c2f212:

    # Mom "Let’s do some really BIG strokes, up and down."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:401
translate chinese MLR3_b_house_Bed_af3ea908:

    # MC "Ahh... Mmm..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:405
translate chinese MLR3_b_house_Bed_69a5c97a:

    # MC "Oh God... That’s so fucking good..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:406
translate chinese MLR3_b_house_Bed_b078b3b7:

    # MC "Just like that, [Mom_name]! Ahh... Oh..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:410
translate chinese MLR3_b_house_Bed_229bc572:

    # Mom "Hehe, you’re adorable when you’re squirming like that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:412
translate chinese MLR3_b_house_Bed_d462d6cd:

    # Mom "(I love having control over a man, like this. It’s so sexy, being able to control every pleasure receptor in his body, with nothing more than your toes.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:416
translate chinese MLR3_b_house_Bed_96a4a686:

    # MC "Ah... Okay, I think ah... you better stop now... before I cum."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:417
translate chinese MLR3_b_house_Bed_d5960fcd:

    # Mom "Aww, what a shame. I was rather enjoying that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:421
translate chinese MLR3_b_house_Bed_e97a949c:

    # Mom "Now, what shall we do next?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:422
translate chinese MLR3_b_house_Bed_864d1acd:

    # MC "Just give me a minute to calm down. I might jizz, if you try anything else, right now! Haha!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:426
translate chinese MLR3_b_house_Bed_242de747:

    # MC "How about you give me a boobjob now?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:428
translate chinese MLR3_b_house_Bed_31062835:

    # Mom "A boobjob? Mmm, that does sound fun!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:429
translate chinese MLR3_b_house_Bed_318453c1:

    # Mom "Just lie back and relax. Let me do all the work."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:433
translate chinese MLR3_b_house_Bed_0428a2d0:

    # Mom "How does it feel, having your cock in between my cleavage? Good, right?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:434
translate chinese MLR3_b_house_Bed_1f5c7b17:

    # MC "Ahh... Uh huh!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:438
translate chinese MLR3_b_house_Bed_c9914191:

    # MC "Mmm... Your breasts are so tight!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:440
translate chinese MLR3_b_house_Bed_94e0486f:

    # Mom "Hehe, your cock feels SO good, tucked in between them."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:444
translate chinese MLR3_b_house_Bed_05f49eb5:

    # Mom "God, you’re handsome."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:445
translate chinese MLR3_b_house_Bed_30d723ef:

    # MC "You tell me that ah... all the time, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:446
translate chinese MLR3_b_house_Bed_791b8690:

    # Mom "Hehe, too often?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:450
translate chinese MLR3_b_house_Bed_2f44b307:

    # MC "Nah, I like it when you say it."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:452
translate chinese MLR3_b_house_Bed_4a6858d6:

    # MC "Mmm... Oh, keep going like that! It felt really good there."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:456
translate chinese MLR3_b_house_Bed_0b137027:

    # Mom "When I move like this?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:457
translate chinese MLR3_b_house_Bed_178f3556:

    # MC "Ohh... fuck... Mmm hmm!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:461
translate chinese MLR3_b_house_Bed_84f056d7:

    # MC "Ah... Fuck... This is go good!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:462
translate chinese MLR3_b_house_Bed_aed737d5:

    # Mom "Okay, I’ll slow down now. I don’t want you getting TOO excited before the main event!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:467
translate chinese MLR3_b_house_Bed2_119cb08d:

    # Mom "Now for the part we’ve both been waiting for!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:468
translate chinese MLR3_b_house_Bed2_f4e4d118:

    # Mom "(God, I’m so fucking wet right now. His dick will just slip, right inside me!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:469
translate chinese MLR3_b_house_Bed2_9d9268cf:

    # MC "(Oh shit! I almost forgot! I’ve got a condom ready!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:473
translate chinese MLR3_b_house_Bed2_fbed4928:

    # MC "Wait - [Mom_name], I’ve got a condom here. I’ll put it on quickly."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:474
translate chinese MLR3_b_house_Bed2_20a6f65f:

    # Mom "Hmm?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:475
translate chinese MLR3_b_house_Bed2_601f3546:

    # MC "I’ll be able to cum inside you if I wear it."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:479
translate chinese MLR3_b_house_Bed2_e2ee028f:

    # Mom "You seriously want to wear a condom on your first time with me?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:480
translate chinese MLR3_b_house_Bed2_d700c889:

    # MC "Y-Yeah? Is that not a good thing?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:481
translate chinese MLR3_b_house_Bed2_1feb0c2f:

    # Mom "It won’t feel as intense for you, or me! Trust me, your first time should be done bareback."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:485
translate chinese MLR3_b_house_Bed2_10e14605:

    # Mom "We won’t be needing this."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:486
translate chinese MLR3_b_house_Bed2_2d3db45f:

    # MC "(Oh wow, I thought she would want to be more careful than this!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:490
translate chinese MLR3_b_house_Bed2_16ecec48:

    # MC "What if I accidentally cum inside you?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:491
translate chinese MLR3_b_house_Bed2_82be019a:

    # Mom "Relax... We’ll have you pull out."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:492
translate chinese MLR3_b_house_Bed2_bd750275:

    # MC "But precum also has-"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:496
translate chinese MLR3_b_house_Bed2_8e4a31ac:

    # Mom "Shush, you’re killing the mood."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:497
translate chinese MLR3_b_house_Bed2_d8f9963e:

    # Mom "Just try to relax and enjoy this. Turn your brain off for a while... if you have to. Okay, Sweetie?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:498
translate chinese MLR3_b_house_Bed2_af714d7c:

    # MC "*Sigh* Okay, [Mom_name]. Let’s do this."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:502
translate chinese MLR3_b_house_Bed2_73f1b680:

    # MC "Mmm! (Oh fuck! I can feel her vulva wrapping around the tip of my cock.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:507
translate chinese MLR3_b_house_Bed2_261ca4fe:

    # Mom "Ah... Yes... God... yes!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:508
translate chinese MLR3_b_house_Bed2_64a7490a:

    # Mom "(It’s finally happening! I’m finally going to fuck him!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:512
translate chinese MLR3_b_house_Bed2_0b711c05:

    # MC "OHHHH!!!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:514
translate chinese MLR3_b_house_Bed2_0b25d077:

    # Mom "AHHHH!!! YES!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:516
translate chinese MLR3_b_house_Bed2_f103d22d:

    # MC "(Wow! Her pussy feels so tight and hot and wet! I don’t think I’ll be able to last long if I’m fucking her like this!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:520
translate chinese MLR3_b_house_Bed2_db907582:

    # Mom "Oh! Oh God! Mmm! Fuck..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:522
translate chinese MLR3_b_house_Bed2_ee927f7f:

    # Mom "(It feels so wrong doing this to my son... but it only makes this so much hotter!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:524
translate chinese MLR3_b_house_Bed2_591fae95:

    # Mom "(It feels so wrong doing this with him... He could be around the age of my son if I had one... but it only adds to the intensity of the situation!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:525
translate chinese MLR3_b_house_Bed2_8456c38f:

    # MC "(Her pussy is quivering around my cock! She must be REALLY loving this!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:529
translate chinese MLR3_b_house_Bed2_828b3a88:

    # Mom "Ah... Ah...."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:530
translate chinese MLR3_b_house_Bed2_e80edc2b:

    # Mom "Y-Your cock is so huge! I haven’t been stretched like this in a LONG time! Wow..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:531
translate chinese MLR3_b_house_Bed2_40efbc3c:

    # MC "If it’s too big you can slow down. I don’t want to hurt you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:535
translate chinese MLR3_b_house_Bed2_a4f60b9f:

    # Mom "Ah! Y-You’re not hurting me! This is... heavenly!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:537
translate chinese MLR3_b_house_Bed2_e4c8b63d:

    # MC "Your pussy feels so good, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:539
translate chinese MLR3_b_house_Bed2_a7d22198:

    # Mom "Ah! Ahhh!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:543
translate chinese MLR3_b_house_Bed2_e0357856:

    # Mom "Oh! Ohh! Yes! Just like that!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:544
translate chinese MLR3_b_house_Bed2_adf42d95:

    # MC "(It feels so good when she’s bouncing up and down on me like this.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:545
translate chinese MLR3_b_house_Bed2_7d4cd6a1:

    # MC "(It’s kinda like a tighter, warmer blowjob.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:549
translate chinese MLR3_b_house_Bed2_2dd90851:

    # MC "Ohhh! YES!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:551
translate chinese MLR3_b_house_Bed2_491ac654:

    # MC "(It’s gonna be REALLY difficult to remember not to cum inside her. I’m gonna have to try and keep my wits about me!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:552
translate chinese MLR3_b_house_Bed2_5da8de01:

    # Mom "Fuck! Fuck! MMM!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:556
translate chinese MLR3_b_house_Bed2_bd6c2c27:

    # Mom "Mmm! I love you, [player_name]!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:558
translate chinese MLR3_b_house_Bed2_19f4cfe3:

    # MC "Ahh! I love you too! Faster, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:559
translate chinese MLR3_b_house_Bed2_989f8628:

    # Mom "AH! AHHHH!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:563
translate chinese MLR3_b_house_Bed2_74ed0c08:

    # Mom "Oh shit! I’m cumming! AHHHH!!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:565
translate chinese MLR3_b_house_Bed2_987a1422:

    # MC "(I can feel her pussy clamping down around my cock as she climaxes!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:567
translate chinese MLR3_b_house_Bed2_8b0bc1a2:

    # MC "Hnnnng! AHHH!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:571
translate chinese MLR3_b_house_Bed2_6b8df6ac:

    # MC "I’m gonna play with your tits, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:572
translate chinese MLR3_b_house_Bed2_c90fdfb1:

    # Mom "Mmm! Uh huh! Do it!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:576
translate chinese MLR3_b_house_Bed2_4fd2e238:

    # Mom "Oohhh! Grope them, [player_name]! Grope your mommy’s big breasts!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:578
translate chinese MLR3_b_house_Bed2_0c46bb03:

    # Mom "Oohhh! Grope them, [player_name]! Grope my big breasts!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:579
translate chinese MLR3_b_house_Bed2_6d4fc987:

    # MC "Ahh... (Mmm... It feels so good playing with these while she rides me!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:583
translate chinese MLR3_b_house_Bed2_7d78c4cb:

    # Mom "Are you enjoying this, Sweetie? Ah... Oh..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:584
translate chinese MLR3_b_house_Bed2_7ecdbb23:

    # MC "Y-Yeah, Mmm... this is perfect, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:588
translate chinese MLR3_b_house_Bed2_3fff33d7:

    # Mom "I’m... ohh.. glad I was able to give you a first time that you enjoyed."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:590
translate chinese MLR3_b_house_Bed2_3c75f7ec:

    # MC "Thanks, [Mom_name]. I’m so lucky to have you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:591
translate chinese MLR3_b_house_Bed2_3eb9d9ee:

    # Mom "Hehe, I know."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:595
translate chinese MLR3_b_house_Bed2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:596
translate chinese MLR3_b_house_Bed2_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:600
translate chinese MLR3_b_house_Bed2_ec7ed6ca:

    # MC "(Her pussy is so fucking tight! I’m gonna blow my load inside her, if she isn’t careful!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:601
translate chinese MLR3_b_house_Bed2_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:605
translate chinese MLR3_b_house_Bed2_2b0ab22e:

    # MC "I’m going to cum soon, [Mom_name]. I need to pull out."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:606
translate chinese MLR3_b_house_Bed2_7282c566:

    # Mom "Don’t worry about pulling out, just enjoy fucking me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:607
translate chinese MLR3_b_house_Bed2_b5220f88:

    # MC "But what about-"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:611
translate chinese MLR3_b_house_Bed2_a94ab541:

    # MC "Oooohhh...."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:612
translate chinese MLR3_b_house_Bed2_3b88f9f5:

    # Mom "I’m just going to keep rocking my hips at this angle."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:613
translate chinese MLR3_b_house_Bed2_e2b5b653:

    # Mom "I want you to relax and shoot your cum inside me, whenever you’re ready."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:617
translate chinese MLR3_b_house_Bed2_a806123e:

    # Mom "Don’t worry or panic. Just give in to the moment, and blow your hot sticky semen, deep in my pussy."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:618
translate chinese MLR3_b_house_Bed2_3960360a:

    # Mom "I want this, [player_name]."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:619
translate chinese MLR3_b_house_Bed2_c7e9f21c:

    # Mom "I want your cum inside me!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:623
translate chinese MLR3_b_house_Bed2_5583b56c:

    # MC "Hnng... Oh fuck..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:624
translate chinese MLR3_b_house_Bed2_658fdc55:

    # MC "(This seems like such a bad idea... but it feels SOOOO good!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:625
translate chinese MLR3_b_house_Bed2_eaccaa10:

    # MC "(Dammit, I’m not gonna be able to hold on much longer!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:629
translate chinese MLR3_b_house_Bed2_795afa26:

    # MC "Ah! Ahhh! AHHHH!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:631
translate chinese MLR3_b_house_Bed2_14ad0ee6:

    # Mom "Ohh! Yes! Yes!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:635
translate chinese MLR3_b_house_Bed2_ae569b10:

    # Mom "That’s it, baby! That’s it! Cum for Mommy!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:636
translate chinese MLR3_b_house_Bed2_8b04c70b:

    # Mom "Let it all go! Shoot your hot jizz into Mommy’s tight pussy! Mmm..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:638
translate chinese MLR3_b_house_Bed2_17998c3b:

    # Mom "That’s it, baby! That’s it! Cum for me!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:639
translate chinese MLR3_b_house_Bed2_c00c548d:

    # Mom "Let it all go! Shoot your hot jizz into my tight pussy! Mmm..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:641
translate chinese MLR3_b_house_Bed2_b04535b0:

    # MC "(Shit, I can’t hold on any longer!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:645
translate chinese MLR3_b_house_Bed2_549c785a:

    # MC "Ah! AHHH!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:646
translate chinese MLR3_b_house_Bed2_e7e647c4:

    # Mom "Ohh! Fuck! Mmm!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:650
translate chinese MLR3_b_house_Bed2_7845c85c:

    # Mom "Yes! Thrust inside me, [player_name]!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:652
translate chinese MLR3_b_house_Bed2_2af0d45f:

    # Mom "Fuck your mommy’s wet pussy!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:654
translate chinese MLR3_b_house_Bed2_876bafd9:

    # Mom "Fuck my wet pussy!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:655
translate chinese MLR3_b_house_Bed2_9029b9da:

    # MC "Ahhhh!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:659
translate chinese MLR3_b_house_Bed2_c3db44a4:

    # MC "Hnnnngg! GAHHHHHHH!!!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:661
translate chinese MLR3_b_house_Bed2_80463187:

    # Mom "AAHHHHHH! I’M CUMMMINNGG!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:662
translate chinese MLR3_b_house_Bed2_ff8ccc72:

    # Mom "(I can feel his hot jizz blasting inside me. It feels incredible!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:666
translate chinese MLR3_b_house_Bed2_a6f284a8:

    # MC "Ahhhhh.... Hnnng.... Ugh... Wow..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:674
translate chinese MLR3_b_house_Bed2_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:675
translate chinese MLR3_b_house_Bed2_597a0286:

    # Mom "*Gasp*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:679
translate chinese MLR3_b_house_Bed2_034502df:

    # MC "F-Fuck... That was... intense..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:680
translate chinese MLR3_b_house_Bed2_f1fca48c:

    # Mom "Good, right?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:681
translate chinese MLR3_b_house_Bed2_a9e91670:

    # MC "Y-Yeah... *Pant*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:685
translate chinese MLR3_b_house_Bed2_36f3abd3:

    # MC "Ohh... Two minutes. I need to catch *pant* my breath..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:686
translate chinese MLR3_b_house_Bed2_a8ed22e5:

    # MC "That’s the hardest I’ve ever *pant* came, in my life."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:687
translate chinese MLR3_b_house_Bed2_f4e938d6:

    # Mom "Yeah, that was really something else!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:691
translate chinese MLR3_b_house_Bed2_38a7e404:

    # Mom "Is that you all floppy now?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:692
translate chinese MLR3_b_house_Bed2_bb7a93da:

    # MC "Yeah, that’s me spent... *Pant*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:693
translate chinese MLR3_b_house_Bed2_17c611fa:

    # Mom "Aww, are you sure?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:697
translate chinese MLR3_b_house_Bed2_6873bcf8:

    # MC "Yeah, that’s me done, [Mom_name]. Guys only have one good orgasm in them."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:698
translate chinese MLR3_b_house_Bed2_112a726d:

    # MC "I’ll need some time to-"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:702
translate chinese MLR3_b_house_Bed2_4c238146:

    # Mom "*Whispered* A guy your age should be able to get it up again though. Right?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:703
translate chinese MLR3_b_house_Bed2_f1045be1:

    # MC "I don’t know, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:704
translate chinese MLR3_b_house_Bed2_5cb305f0:

    # Mom "*Whispered* C’mon, you must have masturbated multiple times in a row sometimes?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:705
translate chinese MLR3_b_house_Bed2_fb2114f5:

    # MC "Yeah, but only when I was really turned on!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:709
translate chinese MLR3_b_house_Bed2_2918c2dd:

    # Mom "Hehe, that’s okay, then. Let’s take a breather together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:710
translate chinese MLR3_b_house_Bed2_cc6e5423:

    # Mom "Your heart was racing so fast, at the end there!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:711
translate chinese MLR3_b_house_Bed2_16c7db4c:

    # MC "Yeah, I know... it was so intense."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:715
translate chinese MLR3_b_house_Bed2_e670273d:

    # MC "Was your first time this good, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:716
translate chinese MLR3_b_house_Bed2_7675019c:

    # Mom "Honestly? Not really."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:717
translate chinese MLR3_b_house_Bed2_a4516acb:

    # Mom "The guy I was with didn’t care very much about me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:721
translate chinese MLR3_b_house_Bed2_0ce9bf8f:

    # Mom "I guess that’s one of the reasons why I was so... obsessed with giving you a perfect first time with me. I wanted you to experience as much pleasure as possible."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:722
translate chinese MLR3_b_house_Bed2_d2df8144:

    # Mom "That’s why I got rid of that stupid condom."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:723
translate chinese MLR3_b_house_Bed2_bcdcdc3d:

    # Mom "Where did you get that thing from, by the way?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:724
translate chinese MLR3_b_house_Bed2_9b35889d:

    # MC "Err... the shops."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:728
translate chinese MLR3_b_house_Bed2_34b0c34f:

    # Mom "Haha! That must have been awkward to ask for."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:729
translate chinese MLR3_b_house_Bed2_2fe2a362:

    # MC "Haha, it was, actually."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:730
translate chinese MLR3_b_house_Bed2_203f95c4:

    # MC "(I don’t like lying to her - but now is NOT the time to bring up [Dad_name]!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:734
translate chinese MLR3_b_house_Bed2_faf9bc97:

    # Mom "How are you feeling now? A bit more relaxed?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:735
translate chinese MLR3_b_house_Bed2_33594401:

    # MC "Yeah... much better."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:736
translate chinese MLR3_b_house_Bed2_ec66f1b3:

    # MC "Your pussy feels amazing, by the way. Seriously, it’s like it was designed for my cock! It just fits so perfectly in there."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:740
translate chinese MLR3_b_house_Bed2_a9c74869:

    # Mom "Y’know, you’re talking like you’re still horny."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:741
translate chinese MLR3_b_house_Bed2_bebcbdf6:

    # MC "I guess I am, a little bit?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:742
translate chinese MLR3_b_house_Bed2_e5678a39:

    # Mom "In that case..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:746
translate chinese MLR3_b_house_Bed2_425e16b4:

    # Mom "Are you up for round two?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:747
translate chinese MLR3_b_house_Bed2_98d02e23:

    # Mom "I’m still wet and raring to go!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:751
translate chinese MLR3_b_house_Bed2_c94f63e2:

    # MC "Already?!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:752
translate chinese MLR3_b_house_Bed2_f315e447:

    # Mom "Yeah, why not?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:753
translate chinese MLR3_b_house_Bed2_70c2f1ba:

    # MC "You’re insatiable!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:754
translate chinese MLR3_b_house_Bed2_dde2cf08:

    # Mom "Hehe, I know I am! And I’m willing to bet ANY amount of money that I can get that cock of yours, all hard again!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:758
translate chinese MLR3_b_house_Bed2_71b0d290:

    # Mom "Let’s see... How shall I play with him?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:759
translate chinese MLR3_b_house_Bed2_fa708ea5:

    # Mom "Maybe I’ll suck on him, till you get all stiff? Or perhaps I could massage it with my boobs?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:760
translate chinese MLR3_b_house_Bed2_f6755899:

    # Mom "Or even a double handjob?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:764
translate chinese MLR3_b_house_Bed2_c49947f2:

    # Mom "Hmm... the options are endless!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:765
translate chinese MLR3_b_house_Bed2_afb25f5c:

    # Mom "(I hope I can get this little guy hard again! I was kinda hoping to do it AT LEAST twice tonight!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:769
translate chinese MLR3_b_house_Bed2_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:770
translate chinese MLR3_b_house_Bed2_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:771
translate chinese MLR3_b_house_Bed2_e3c9ab96:

    # MC "Ohhh... (I can feel her hot breath blowing across the tip of my cock.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:775
translate chinese MLR3_b_house_Bed2_cdfb052a:

    # Mom "*Suck* *Shlurp*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:776
translate chinese MLR3_b_house_Bed2_aea523e6:

    # MC "Fuck... Ah... "
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:777
translate chinese MLR3_b_house_Bed2_7a1f6468:

    # MC "(My dick’s extra sensitive after, just having been fucked by her!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:781
translate chinese MLR3_b_house_Bed2_308a2e04:

    # MC "Damn, you’re good at giving blowjobs, [Mom_name]. Mmm... Ah..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:782
translate chinese MLR3_b_house_Bed2_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:783
translate chinese MLR3_b_house_Bed2_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:787
translate chinese MLR3_b_house_Bed2_972a5cd8:

    # Mom "(Yes! I can feel it starting to stiffen up, in my mouth. I’ll have him ready to fuck again, in no time at all!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:789
translate chinese MLR3_b_house_Bed2_59c2fa8d:

    # Mom "(Round two is going to be better than the first!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:790
translate chinese MLR3_b_house_Bed2_86d90296:

    # Mom "(Let’s just deepthroat him, for good measure!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:794
translate chinese MLR3_b_house_Bed2_6053356b:

    # Mom "*MPPFFF* *GAG*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:795
translate chinese MLR3_b_house_Bed2_622128ac:

    # MC "Hnnnnng! Oh FUCK! Ahh..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:799
translate chinese MLR3_b_house_Bed2_9a76990b:

    # MC "Ahh! Yes, it’s so good!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:800
translate chinese MLR3_b_house_Bed2_be705605:

    # Mom "*GAG* *SUCK SUCK SUCK*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:801
translate chinese MLR3_b_house_Bed2_ffd7d614:

    # Mom "*SHLURRRRRP*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:805
translate chinese MLR3_b_house_Bed2_4650d3c2:

    # Mom "*Cough Cough* There we go! Told you I’d get it hard again!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:806
translate chinese MLR3_b_house_Bed2_552f38a6:

    # MC "You certainly did! Now, how do you want to fuck, this time?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:807
translate chinese MLR3_b_house_Bed2_a8585ff2:

    # Mom "Let’s do doggy style, that’s when I’m down on all fours-"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:811
translate chinese MLR3_b_house_Bed2_da1d197e:

    # MC "I know what doggy style is, [Mom_name]! Haha!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:812
translate chinese MLR3_b_house_Bed2_cf0d270c:

    # Mom "Well, if you’re so confident, let’s see if you’re any good at it!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:813
translate chinese MLR3_b_house_Bed2_a53f6e8d:

    # MC "Oh, is that a challenge?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:817
translate chinese MLR3_b_house_Bed2_578538d6:

    # Mom "Bet that you can’t make me cum."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:818
translate chinese MLR3_b_house_Bed2_58b91903:

    # MC "It’s on! You’ll be cumming on my cock in seconds!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:819
translate chinese MLR3_b_house_Bed2_96ef69be:

    # Mom "Haha, we’ll see."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:823
translate chinese MLR3_b_house_Bed2_0df5743b:

    # Mom "Make sure you get the right hole, okay?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:824
translate chinese MLR3_b_house_Bed2_53775ad9:

    # Mom "No surprise anal! There’s a reason lube exists!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:828
translate chinese MLR3_b_house_Bed2_73495fe5:

    # MC "Relax, [Mom_name]. I’m not going to fuck you in the ass."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:829
translate chinese MLR3_b_house_Bed2_295b5b66:

    # MC "(At least, not tonight!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:830
translate chinese MLR3_b_house_Bed2_ad92fa68:

    # MC "I’ll just begin by grinding my cock between your ass cheeks."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:834
translate chinese MLR3_b_house_Bed2_833cb0ca:

    # MC "And, here we go..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:835
translate chinese MLR3_b_house_Bed2_bc137aab:

    # Mom "Ohhh! Ah..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:836
translate chinese MLR3_b_house_Bed2_59ff7cd2:

    # MC "That was quite a loud moan there, [Mom_name]! Are you sure you aren’t going to cum soon?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:840
translate chinese MLR3_b_house_Bed2_067448fc:

    # Mom "Y-Yeah, I’m WAY more experienced at ahh... this, than you. I’ll EASILY outlast you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:841
translate chinese MLR3_b_house_Bed2_28641d81:

    # MC "Let’s see if you change your tune when I start thrusting."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:845
translate chinese MLR3_b_house_Bed2_a7d1081f_2:

    # MC "Mmm!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:846
translate chinese MLR3_b_house_Bed2_32ec9a43:

    # Mom "AH! Ohh! Fuck! Ahhh!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:850
translate chinese MLR3_b_house_Bed2_151477f0:

    # Mom "OH GOD! YES! AHHH!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:853
translate chinese MLR3_b_house_Bed2_4d4902bf:

    # MC "(My cock must feel really good inside her! I wonder what it feels like for a woman, to be fucked?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:855
translate chinese MLR3_b_house_Bed2_7bca750d:

    # MC "(Similar to how a guy feels when he has his cock sucked? Maybe? I dunno.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:860
translate chinese MLR3_b_house_Bed2_70846ce2:

    # Mom "Ohh... yes..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:861
translate chinese MLR3_b_house_Bed2_64445cb4:

    # Mom "Yes! Don’t stop, Baby! Keep going!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:865
translate chinese MLR3_b_house_Bed2_7f2ff8ae:

    # MC "(My dick is extra sensitive, after the first round! I don’t know if I’ll be able to last as long, this time!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:866
translate chinese MLR3_b_house_Bed2_cdf84ac7:

    # Mom "Ah! Ahh! Ahhhh!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:870
translate chinese MLR3_b_house_Bed2_1c4f15be:

    # Mom "Oh God! Yes! Harder, [player_name]!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:871
translate chinese MLR3_b_house_Bed2_84b0d73a:

    # Mom "Shove your cock in deeper! I want to feel ALL of you, inside me!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:872
translate chinese MLR3_b_house_Bed2_d4949791:

    # MC "Mmmm! Ugh! Ah!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:876
translate chinese MLR3_b_house_Bed2_eb1c58da:

    # Mom "OHHH YES! YES! AHHH! I’M CUMMING!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:878
translate chinese MLR3_b_house_Bed2_2e721796:

    # MC "(Look like [Mom_name] lost that challenge - I’ll probably be cumming soon too though!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:879
translate chinese MLR3_b_house_Bed2_a09b3426:

    # MC "Mmm! Ah!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:883
translate chinese MLR3_b_house_Bed2_24467c2c:

    # Mom "Oh fuck! Holy fuck! It’s so sensitive! Ahhh! AHHHHHH!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:884
translate chinese MLR3_b_house_Bed2_232f6b8d:

    # Mom "(He’s rubbing up against my g-spot with each thrust of his hips!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:885
translate chinese MLR3_b_house_Bed2_e1992e05:

    # Mom "(Oh God! I’m gushing wet, right now!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:889
translate chinese MLR3_b_house_Bed2_453e8df5:

    # Mom "AHHH! AHHHHH! FUCK! I’M CUMMING AGAIN!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:890
translate chinese MLR3_b_house_Bed2_72812aff:

    # MC "Ugh! Yes! Take it!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:894
translate chinese MLR3_b_house_Bed2_cccefab5:

    # MC "Tell me you love my cock, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:895
translate chinese MLR3_b_house_Bed2_133b335d:

    # Mom "I love your... ahh.. fucking cock! It’s so fucking good!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:899
translate chinese MLR3_b_house_Bed2_3fe93ec5:

    # MC "Telll me how it feels inside you!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:901
translate chinese MLR3_b_house_Bed2_6c8ffbbf:

    # Mom "AHH! It’s so b-big and hard! AND SO HOT! AHHHH!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:903
translate chinese MLR3_b_house_Bed2_91e1251c:

    # Mom "FUCK ME HARDER, [player_name]!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:908
translate chinese MLR3_b_house_Bed2_da78279d:

    # MC "(I hope I’m not being too rough with her, but she really seems to enjoy me doing this!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:910
translate chinese MLR3_b_house_Bed2_db407298:

    # Mom "AHHH! AHHHH! OH GODDDDD!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:912
translate chinese MLR3_b_house_Bed2_344a7087:

    # Mom "FASTER!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:918
translate chinese MLR3_b_house_Bed2_85fae656:

    # Mom "AYAAAHHH! Cum inside me! I want to feel my boy’s cum inside me!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:920
translate chinese MLR3_b_house_Bed2_19582016:

    # Mom "AYAAAHHH! Cum inside me! I want to feel your cum inside me!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:922
translate chinese MLR3_b_house_Bed2_16ab8094:

    # MC "(I’m not even sure if I have any left in the tank! I think I drained my balls, the last time I came!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:924
translate chinese MLR3_b_house_Bed2_15999fcb:

    # MC "(Ah well, I might as well cum inside. If the worst was to happen, she’d have already been impregnated by now anyway!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:928
translate chinese MLR3_b_house_Bed2_d841ae2b:

    # MC "Hnnnnnng! UGH! YESSSSS!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:929
translate chinese MLR3_b_house_Bed2_24b7abe2:

    # Mom "Oooohhhhh...."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:938
translate chinese MLR3_b_house_Bed2_1830a48e:

    # MC "Oh fuck... *pant* That was so good..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:939
translate chinese MLR3_b_house_Bed2_46c3f130:

    # Mom "Uh huh... *gasp* *pant*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:940
translate chinese MLR3_b_house_Bed2_76c28611:

    # MC "(Her pussy looks fucking amazing. I can’t believe that I get to fuck that.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:947
translate chinese MLR3_b_house_Bed2_bd26dc35:

    # MC "Oh wow... I’m exhausted."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:948
translate chinese MLR3_b_house_Bed2_f0d9d2a0:

    # Mom "You did good to keep up with me, for a full two rounds."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:949
translate chinese MLR3_b_house_Bed2_7c208e98:

    # Mom "You’ve got, some stamina, for a man!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:953
translate chinese MLR3_b_house_Bed2_5001f8ba:

    # MC "Haha, you think so? *Pant*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:954
translate chinese MLR3_b_house_Bed2_b63b1690:

    # MC "I don’t feel like I do right now. I just want to flop down on this bed, close my eyes, and sleep for a month!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:955
translate chinese MLR3_b_house_Bed2_29bb7178:

    # Mom "Haha! Although, spending a month in a bed with you, doesn’t sound too bad at all."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:959
translate chinese MLR3_b_house_Bed2_40846beb:

    # MC "Heh, I love you, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:960
translate chinese MLR3_b_house_Bed2_2b4de539:

    # Mom "I love you too."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:961
translate chinese MLR3_b_house_Bed2_90f48373:

    # Mom "C’mon closer to me and we’ll cuddle up and go to sleep together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:965
translate chinese MLR3_b_house_Bed2_8c00fcb4:

    # MC "Thanks again for everything, [Mom_name]. You’re amazing."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:966
translate chinese MLR3_b_house_Bed2_0f96e24d:

    # Mom "Hehe, I know I am."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:967
translate chinese MLR3_b_house_Bed2_d4a4ea27:

    # MC "Seriously, this holiday has been absolutely perfect so far. I loved hanging out on the beach with you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:970
translate chinese MLR3_b_house_Bed2_37ac97ec:

    # MC "I loved going swimming and diving off the cliffs. I loved rubbing that sunscreen on your body."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:971
translate chinese MLR3_b_house_Bed2_4a534d55:

    # MC "I loved our date earlier on, even if both our phones wouldn’t stop ringing!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:972
translate chinese MLR3_b_house_Bed2_adb8e8e6:

    # Mom "Haha!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:976
translate chinese MLR3_b_house_Bed2_696aa2e6:

    # Mom "I loved it all too, [player_name]."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:977
translate chinese MLR3_b_house_Bed2_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:978
translate chinese MLR3_b_house_Bed2_da854989:

    # Mom "You sound tired. Close your eyes and get some rest, Sweetie."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:982
translate chinese MLR3_b_house_Bed2_cd950068:

    # MC "Goodnight, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:983
translate chinese MLR3_b_house_Bed2_208e565f:

    # Mom "Goodnight, [player_name]. Sweet dreams."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:987
translate chinese MLR3_b_house_Bed2_acdce1cd:

    # MC "Zzz..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:988
translate chinese MLR3_b_house_Bed2_b5096577:

    # Mom "*Whispered* I can’t wait to wake up beside you tomorrow."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:995
translate chinese MLR3_b_house_Bed2_acdce1cd_1:

    # MC "Zzz..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:998
translate chinese MLR3_b_house_Bed2_0b3cb52b:

    # Mom "Wakey wakey, sleepyhead!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1002
translate chinese MLR3_b_house_Bed2_1e0011ec:

    # MC "Hmm... *YAWN*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1003
translate chinese MLR3_b_house_Bed2_68e2fa61:

    # Mom "Time to get up! We’re burning daylight!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1007
translate chinese MLR3_b_house_Bed2_bcb56d4b:

    # MC "(Where am I? This isn’t my room.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1008
translate chinese MLR3_b_house_Bed2_6f798b3b:

    # MC "(Where the hell am I?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1012
translate chinese MLR3_b_house_Bed2_9cd49150:

    # Mom "Yoohoo! Over here."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1013
translate chinese MLR3_b_house_Bed2_a4d3cd9e:

    # MC "[Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1017
translate chinese MLR3_b_house_Bed2_f5fbb135:

    # MC "(Oh yeah! I spent the night at the beach house. I completely forgot about that.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1018
translate chinese MLR3_b_house_Bed2_038edf25:

    # MC "(God, I slept like a baby, all night.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1019
translate chinese MLR3_b_house_Bed2_4348850b:

    # Mom "Good morning, Prince Charming. Will you join me for a coffee?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1023
translate chinese MLR3_b_house_Bed2_bc75fb3c:

    # MC "Y-Yeah, sure..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1024
translate chinese MLR3_b_house_Bed2_c736d557:

    # Mom "Hehe, you look like you need it, to wake you up!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1028
translate chinese MLR3_b_house_Bed2_7e392f59:

    # Mom "I’ll tell you what. I’ll give you five more minutes in bed. Come on into the lounge whenever you’re ready. Okay?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:1029
translate chinese MLR3_b_house_Bed2_a507d8df:

    # MC "Yeah, no problem, [Mom_name]. *YAWN*"
    MC ""

translate chinese strings:

    # game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:321
    old "Let’s begin with a blowjob."
    new ""

    # game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:321
    old "Can I have a footjob, [Mom_name]?"
    new ""

    # game/scripts/beach/Beach_Event/MLR3_b_house_Bed.rpy:321
    old "How about you give me a boobjob?"
    new ""

