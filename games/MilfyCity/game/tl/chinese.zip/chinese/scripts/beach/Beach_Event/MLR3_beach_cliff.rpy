﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:39
translate chinese MLR3_beach_cliff_bb4343b3:

    # Mom "Have you ever been cliff jumping before?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:40
translate chinese MLR3_beach_cliff_202c8595:

    # MC "Cliff jumping?!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:41
translate chinese MLR3_beach_cliff_b45c9d42:

    # MC "Please tell me that isn’t what it sounds like."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:45
translate chinese MLR3_beach_cliff_20436847:

    # Mom "What else could it possibly be? You jump off a cliff into the ocean! It’s amazing!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:46
translate chinese MLR3_beach_cliff_d08c53c3:

    # MC "Err... is it not really dangerous?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:47
translate chinese MLR3_beach_cliff_d7c111d7:

    # MC "I mean, there’s gotta be rocks and stuff in the water?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:51
translate chinese MLR3_beach_cliff_7f6c5994:

    # Mom "Some places can be dangerous, but these cliffs are very safe. The water’s deep and there’s no rocks to worry about."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:52
translate chinese MLR3_beach_cliff_b62fdc6a:

    # MC "Hmm, as long as you’re sure. Sorry, I’m not great with heights."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:56
translate chinese MLR3_beach_cliff_9a520fc1:

    # Mom "C’mon, take my hand and we’ll go up there together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:57
translate chinese MLR3_beach_cliff_d2580a2e:

    # MC "Okay, sure."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:61
translate chinese MLR3_beach_cliff_cdc5dac6:

    # MC "(I guess I’m just gonna have to trust her. She’s done this before.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:62
translate chinese MLR3_beach_cliff_84ae89dc:

    # Mom "This way!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:66
translate chinese MLR3_beach_cliff_bffde6bb:

    # Mom "Wow! Just look at the view... It takes my breath away every time I come up here."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:67
translate chinese MLR3_beach_cliff_044d3a09:

    # MC "Do you come here often?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:68
translate chinese MLR3_beach_cliff_dad207c0:

    # Mom "Every chance I get. I like to get away here, by myself, some days."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:72
translate chinese MLR3_beach_cliff_82000a03:

    # MC "(Yikes... that’s quite the drop.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:73
translate chinese MLR3_beach_cliff_013b1d8d:

    # MC "H-How high is this cliff, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:74
translate chinese MLR3_beach_cliff_d50abb55:

    # Mom "Sixty, maybe seventy feet?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:78
translate chinese MLR3_beach_cliff_aef1a5c7:

    # MC "(Damn, I’ve got butterflies in my stomach now...)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:79
translate chinese MLR3_beach_cliff_08b7d206:

    # Mom "The trick is to not spend too long looking down. You’ll only freak yourself out."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:80
translate chinese MLR3_beach_cliff_8c2da12d:

    # MC "Y-Yeah..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:84
translate chinese MLR3_beach_cliff_a4ce4492:

    # Mom "You don’t really want to do this, do you?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:85
translate chinese MLR3_beach_cliff_4f52db6f:

    # MC "Honestly? Given how high it is, not really..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:86
translate chinese MLR3_beach_cliff_f10a5f05:

    # Mom "That’s okay. The first time is always the scariest. Once you get over your initial fears, it becomes much easier."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:90
translate chinese MLR3_beach_cliff_2efe559b:

    # Mom "Think about how scary it was, the first time you ever had to ride a bike, or do an exam."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:91
translate chinese MLR3_beach_cliff_129789c6:

    # Mom "What we fear the most is the unknown, and you don’t know how it’s going to feel, jumping off a cliff."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:92
translate chinese MLR3_beach_cliff_ebebac2c:

    # Mom "Once you’ve done it, you’ll feel much more confident about it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:96
translate chinese MLR3_beach_cliff_dc18a223:

    # Mom "I’ll go first, to prove everything is safe. You can come, after me, if you want to."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:97
translate chinese MLR3_beach_cliff_d776c8c1:

    # MC "O-Okay..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:98
translate chinese MLR3_beach_cliff_678c3dc8:

    # MC "(Now I do not have, really any other choice, but to follow her.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:102
translate chinese MLR3_beach_cliff_75324227:

    # Mom "Ahhha-ha-ha!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:103
translate chinese MLR3_beach_cliff_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:107
translate chinese MLR3_beach_cliff_77566b7d:

    # Mom "Haha! Woohoo!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:108
translate chinese MLR3_beach_cliff_211eab04:

    # MC "SHIIIITTT! AHHHHH!!!!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:109
translate chinese MLR3_beach_cliff_d9d1c70f:

    # MC "(THIS WAS A TERRIBLE IDEA!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:113
translate chinese MLR3_beach_cliff_0e9f6e7a:

    # Mom "Woooo!!!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:114
translate chinese MLR3_beach_cliff_a7d9642d:

    # MC "AHHHH!!!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:117
translate chinese MLR3_beach_cliff_9ee0bfab:

    # "*SPLASH*"
    ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:124
translate chinese MLR3_beach_cliff_07572e7e:

    # Mom "Well? How was your first time cliff-diving? Ready for round two?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:125
translate chinese MLR3_beach_cliff_1536bf9b:

    # MC "N-No! It was horrifying!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:126
translate chinese MLR3_beach_cliff_dfa4efef:

    # Mom "Oh, you’ll get used to it!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:130
translate chinese MLR3_beach_cliff_67621895:

    # Mom "I’ve never heard ANYONE scream that loud before - I didn’t know you had acrophobia."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:131
translate chinese MLR3_beach_cliff_dd0792ce:

    # MC "I don’t - it’s just... no sane person should go jumping off cliffs! Haha!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:135
translate chinese MLR3_beach_cliff_407bb581:

    # Mom "Thank you for coming out with me today. I’d been looking forward to this for a long, long time."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:136
translate chinese MLR3_beach_cliff_78cf2489:

    # MC "You don’t need to thank me, [Mom_name]. I’ve wanted to come out with you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:140
translate chinese MLR3_beach_cliff_4541fe7f:

    # Mom "You really have made so many of my dreams come true. I’m such a lucky woman."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:141
translate chinese MLR3_beach_cliff_71c22544:

    # MC "You’ve made a few of my dreams come true too. I’ll admit, I never knew I had such fantasies, before you started making your advances on me."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:142
translate chinese MLR3_beach_cliff_d1074317:

    # MC "I’m glad you did though."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:146
translate chinese MLR3_beach_cliff_0b5f13e7:

    # Mom "Can you hold me for a while here?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:147
translate chinese MLR3_beach_cliff_626f891f:

    # MC "Of course."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:148
translate chinese MLR3_beach_cliff_0d43e076:

    # MC "(The water is so warm, with the sun beating down on it.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:152
translate chinese MLR3_beach_cliff_fb61e0ec:

    # Mom "God, you’re handsome. I love your eyes."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:153
translate chinese MLR3_beach_cliff_aa9ddb49:

    # MC "Your eyes are beautiful too, [Mom_name]. Their blue puts the ocean to shame."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:154
translate chinese MLR3_beach_cliff_19492e83:

    # Mom "Mmm, that was rather poetic."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:158
translate chinese MLR3_beach_cliff_5a8e0422:

    # MC "Heh, thank you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:159
translate chinese MLR3_beach_cliff_2b0618e7:

    # Mom "Even the weather turned out to be perfect. I couldn’t have asked for this to be any better."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:163
translate chinese MLR3_beach_cliff_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:164
translate chinese MLR3_beach_cliff_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:165
translate chinese MLR3_beach_cliff_03bc1172:

    # Mom "(I wonder if any of those people on the beach can see us. What are they thinking right now?)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:170
translate chinese MLR3_beach_cliff_13ffb71c:

    # Mom "(Could they see the resemblance between [player_name] and I?)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:171
translate chinese MLR3_beach_cliff_5f331dfa:

    # Mom "(Could any of them work out that I’m actually his mother? Or would they just think I’m a cougar dating a teenager?)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:172
translate chinese MLR3_beach_cliff_b9bb15be:

    # Mom "(Then again, it would be pretty hot if they suspected me of being his mom.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:174
translate chinese MLR3_beach_cliff_f97b5c8b:

    # Mom "(I wonder what people would think of us. Do I look like a cougar beside him?)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:175
translate chinese MLR3_beach_cliff_063dfc83:

    # Mom "(God, the age gap difference is really hot.) "
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:179
translate chinese MLR3_beach_cliff_286d3279:

    # MC "What’s on your mind, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:183
translate chinese MLR3_beach_cliff_8198d149:

    # Mom "Hmm? Oh, nothing at all. Just enjoying being here with you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:184
translate chinese MLR3_beach_cliff_c33e8af4:

    # MC "Okay, shall we swim back to shore now?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_cliff.rpy:185
translate chinese MLR3_beach_cliff_192e5d46:

    # Mom "Yeah, let’s get back before the sun sets."
    Mom ""

