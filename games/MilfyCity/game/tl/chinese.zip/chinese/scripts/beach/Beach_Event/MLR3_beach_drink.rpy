﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:22
translate chinese MLR3_beach_drink_ed384174:

    # MC "Do you fancy grabbing something to drink, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:23
translate chinese MLR3_beach_drink_7f1d07b9:

    # Mom "Yeah, I’m parched. There’s a little shop just at the end of the beach. We could go there together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:32
translate chinese MLR3_beach_drink_e1b070ef:

    # MC "Take a seat, I’ll grab us drinks."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:33
translate chinese MLR3_beach_drink_45756770:

    # Mom "No, don’t you worry, I’ll get them."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:34
translate chinese MLR3_beach_drink_0c6045b7:

    # MC "[Mom_name] - you paid for this whole holiday! Let me get us drinks at the very least! Now, what do you want?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:38
translate chinese MLR3_beach_drink_aa5ea41a:

    # Mom "Well... if you insist. Hmm... I think I’ll just take a Cocka Cola."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:39
translate chinese MLR3_beach_drink_099593f0:

    # MC "That’s two Cocka Colas, then. I’ll be back in a minute, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:40
translate chinese MLR3_beach_drink_44b9b50c:

    # Mom "Sure thing!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:49
translate chinese MLR3_beach_drink_b0b2df7c:

    # MC "(I have to buy drinks from the beach shop.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:66
translate chinese MLR3_beach_drink2_7c9b9e97:

    # MC "There you go! One ice cold Cocka Cola."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:67
translate chinese MLR3_beach_drink2_919ee343:

    # Mom "Thanks! God, I didn’t realise how hot it actually was out here until you handed me this."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:68
translate chinese MLR3_beach_drink2_753c9227:

    # MC "I know! It must be at least eighty degrees today."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:72
translate chinese MLR3_beach_drink2_fc1145d2:

    # Mom "What’s that in celsius? Twenty eight?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:73
translate chinese MLR3_beach_drink2_d9a9b459:

    # MC "Around that maybe, I use Fahrenheit more often."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:74
translate chinese MLR3_beach_drink2_b58ddeb3:

    # MC "You look fantastic in that bikini, by the way. You should wear it more often."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:75
translate chinese MLR3_beach_drink2_8a6121b5:

    # Mom "Haha! Like around the house or in my office?! That’s the only two places I ever seem to be! At least, it feels that way sometimes, with how damn busy I am."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:79
translate chinese MLR3_beach_drink2_e8b6d299:

    # Mom "*Glug Glug*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:80
translate chinese MLR3_beach_drink2_a8d9db3c:

    # MC "You could always go sunbathing in the garden, or we could hit the local pool together."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:81
translate chinese MLR3_beach_drink2_87d127cc:

    # MC "It gives you an excuse to wear it."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:85
translate chinese MLR3_beach_drink2_c0e5890b:

    # Mom "But MORE importantly, it gives YOU the chance to see me wear it. Am I right?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:86
translate chinese MLR3_beach_drink2_e8d661c9:

    # MC "Haha! You got me there!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:87
translate chinese MLR3_beach_drink2_19b8dd23:

    # Mom "Of course I did. Although... if it was in our back garden, I guess I could sunbathe topless."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:89
translate chinese MLR3_beach_drink2_e41ec322:

    # Mom "How could I possibly know that you’d be peeping down at me from your bedroom window? There’s no way your sisters or Bob would suspect anything."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:91
translate chinese MLR3_beach_drink2_6415138b:

    # Mom "How could I possibly know that you’d be peeping down at me from your bedroom window? There’s no way Sara, Caroline or Bob would suspect anything."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:94
translate chinese MLR3_beach_drink2_201b19f1:

    # Mom "I could casually just roll over and flash my sunscreen soaked tits up at you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:95
translate chinese MLR3_beach_drink2_e322e911:

    # Mom "If there was no one else around, I might even take a selfie or two for you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:99
translate chinese MLR3_beach_drink2_e53265a7:

    # MC "Mmm, that DOES sound good!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:100
translate chinese MLR3_beach_drink2_f83fb98d:

    # Mom "The only downside about staying back home, is that there’s no water to go swimming in, to cool down. "
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:101
translate chinese MLR3_beach_drink2_e4fa73ce:

    # Mom "Ah well, I guess that’s the price I have to pay for topless sunbathing."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:105
translate chinese MLR3_beach_drink2_d8ecba0b:

    # MC "You could lose your bikini bottoms too. That would REALLY give me something to enjoy!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:106
translate chinese MLR3_beach_drink2_c48c3b52:

    # Mom "[player_name]!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:107
translate chinese MLR3_beach_drink2_90c804f1:

    # MC "Aww, c’mon! I know you love being watched. It’s hardly a surprise! Remember how hot and bothered you got during our restaurant date?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:111
translate chinese MLR3_beach_drink2_3167a540:

    # Mom "Haha! True..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:112
translate chinese MLR3_beach_drink2_92d3e199:

    # MC "I’m sure you would be soaking wet within seconds if you took your bottoms off. Just knowing that I’m watching you from my window would really turn you on-"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:113
translate chinese MLR3_beach_drink2_5005f7a4:

    # Mom "Okay! Enough! Haha, you’re gonna turn me on right NOW if you don’t cut it out."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:117
translate chinese MLR3_beach_drink2_c28b69d7:

    # MC "Haha, sorry [Mom_name], I couldn’t resist."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:118
translate chinese MLR3_beach_drink2_e8b6d299_1:

    # Mom "*Glug Glug*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:122
translate chinese MLR3_beach_drink2_47c36a66:

    # Mom "Ahh, thanks for the Cocka Cola. That was really refreshing."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:123
translate chinese MLR3_beach_drink2_2406e717:

    # MC "Glad you enjoyed it!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:124
translate chinese MLR3_beach_drink2_b6827d54:

    # Mom "Shall we head back to the beach now?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_drink.rpy:125
translate chinese MLR3_beach_drink2_c25c6e85:

    # MC "Yeah, let’s go."
    MC ""

