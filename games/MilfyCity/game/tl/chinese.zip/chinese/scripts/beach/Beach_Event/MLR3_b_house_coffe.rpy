﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:26
translate chinese MLR3_b_house_coffe_4f9bd81e:

    # Mom "*Sniff*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:27
translate chinese MLR3_b_house_coffe_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:28
translate chinese MLR3_b_house_coffe_3ca9ee29:

    # Mom "(The landlord always buys good coffee for this place. This new Colombian variety is excellent!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:32
translate chinese MLR3_b_house_coffe_3e05e81e:

    # Mom "Ah, you’re finally awake. How are you feeling?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:33
translate chinese MLR3_b_house_coffe_3b620894:

    # MC "Honestly? Absolutely drained..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:34
translate chinese MLR3_b_house_coffe_7640d123:

    # Mom "Hehe, you really did give it your all last night. Grab a cup and help yourself to some coffee. I filled up a pot on the table."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:38
translate chinese MLR3_b_house_coffe_2b5d76f7:

    # MC "Thanks, [Mom_name]. This smells really strong."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:39
translate chinese MLR3_b_house_coffe_1531275d:

    # Mom "Trust me, it’s exactly what you need, to pick you up after last night."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:40
translate chinese MLR3_b_house_coffe_bff9a9a0:

    # MC "I hope it’s not too bitter..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:44
translate chinese MLR3_b_house_coffe_61db4107:

    # Mom "It’s fine, honestly, it’s only the first couple of sips that taste bitter. After that your senses adjust."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:45
translate chinese MLR3_b_house_coffe_84697a71:

    # Mom "Mine’s a tad hot though. Kinda like you last night."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:49
translate chinese MLR3_b_house_coffe_c624dc47:

    # MC "Haha... okay..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:50
translate chinese MLR3_b_house_coffe_dbc40de4:

    # Mom "God you were so hot. I loved bouncing up and down on that big fat cock of yours."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:51
translate chinese MLR3_b_house_coffe_8e29022e:

    # MC "Umm, can I at least finish my coffee before we start thinking about a round three?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:55
translate chinese MLR3_b_house_coffe_c07fbb33:

    # MC "If you keep this up, there’ll be nothing left of me! Haha!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:56
translate chinese MLR3_b_house_coffe_26b8e129:

    # Mom "Think of it as good exercise."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:57
translate chinese MLR3_b_house_coffe_330480c5:

    # Mom "And on that subject, I think you and I will be doing A LOT more exercise together in future."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:61
translate chinese MLR3_b_house_coffe_e064df48:

    # MC "Mmm, I’ll be looking forward to that. It’s a shame that we won’t have as much free time together when we get back home."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:62
translate chinese MLR3_b_house_coffe_0d7b6982:

    # Mom "Yeah, I know..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:63
translate chinese MLR3_b_house_coffe_d4e2e220:

    # Mom "I’m trying not to think about that right now, to be honest."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:67
translate chinese MLR3_b_house_coffe_f9429bb5:

    # MC "*Sip*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:68
translate chinese MLR3_b_house_coffe_f327ce0a:

    # Mom "*Sip*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:69
translate chinese MLR3_b_house_coffe_12aea938:

    # MC "(Huh, this stuff isn’t actually that bad!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:73
translate chinese MLR3_b_house_coffe_2ba02848:

    # Mom "Well, that’s me done. I’ll leave you here to finish yours - make sure you drink it all."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:74
translate chinese MLR3_b_house_coffe_0b48d2de:

    # MC "Don’t worry, I will."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:75
translate chinese MLR3_b_house_coffe_a27088f2:

    # Mom "There’s extra in the pot if you want a second round."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:79
translate chinese MLR3_b_house_coffe_cf538f86:

    # Mom "In the meantime, I’ll be washing down my body in the shower."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:80
translate chinese MLR3_b_house_coffe_6481e7f7:

    # Mom "Lathering up my big breasts with soap and scrubbing them clean."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:84
translate chinese MLR3_b_house_coffe_ff7ca128:

    # Mom "Enjoying the hot water flowing over my naked voluptuous body."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:85
translate chinese MLR3_b_house_coffe_e3ea7b22:

    # Mom "Trying not to think about you and your hard dick, as I feel the shower blast against me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:89
translate chinese MLR3_b_house_coffe_c58c0cef:

    # Mom "Well, I’ll see you after you finish your coffee."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:90
translate chinese MLR3_b_house_coffe_5a332008:

    # MC "(Huh, that was weird... why was [Mom_name] being so descriptive about her shower? Is she just trying to turn me on again?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:94
translate chinese MLR3_b_house_coffe_a96e8fad:

    # MC "(Wait a minute - maybe she wants me to shower WITH her?!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:95
translate chinese MLR3_b_house_coffe_c4335137:

    # MC "(I’m not certain, but I think I should go and check. What’s the worst thing that could happen? She might laugh and kick me out of the shower.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_coffe.rpy:96
translate chinese MLR3_b_house_coffe_c9e991cf:

    # MC "(If I’m right that she wants to have shower sex, then I better down a second cup of coffee quickly!)"
    MC ""

