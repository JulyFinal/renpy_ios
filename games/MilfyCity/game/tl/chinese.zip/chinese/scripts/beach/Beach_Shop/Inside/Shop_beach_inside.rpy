﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Shop/Inside/Shop_beach_inside.rpy:24
translate chinese b_shop_inside_a52516c7:

    # MC "It's closed now."
    MC ""

# game/scripts/beach/Beach_Shop/Inside/Shop_beach_inside.rpy:98
translate chinese beach_buy_B2_0ab730b3:

    # MC "(I don't have enough money.)"
    MC ""

# game/scripts/beach/Beach_Shop/Inside/Shop_beach_inside.rpy:113
translate chinese beach_buy_B3_0ab730b3:

    # MC "(I don't have enough money.)"
    MC ""

# game/scripts/beach/Beach_Shop/Inside/Shop_beach_inside.rpy:128
translate chinese beach_buy_B4_0ab730b3:

    # MC "(I don't have enough money.)"
    MC ""

