﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:57
translate chinese MLR3_b_house_bag_91c5a6af:

    # MC "(Okay, this looks like the bedroom. I guess I’ll just leave the bag sitting in here somewhere.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:58
translate chinese MLR3_b_house_bag_c8641304:

    # MC "(Hmm, over by that chair looks good.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:62
translate chinese MLR3_b_house_bag_e64dd3f4:

    # MC "(There we go. That’ll sit nicely there.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:64
translate chinese MLR3_b_house_bag_2f941897:

    # MC "Okay, that’s me done, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:65
translate chinese MLR3_b_house_bag_6247422c:

    # Mom "Great! C’mon back into the lounge, Sweetie!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:85
translate chinese MLR3_b_house_bag2_32ca875b:

    # MC "Where are you, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:86
translate chinese MLR3_b_house_bag2_cf9050c5:

    # Mom "Here, in the lounge!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:87
translate chinese MLR3_b_house_bag2_66c45684:

    # MC "Yeah, I know that - but which room is the lounge?!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:91
translate chinese MLR3_b_house_bag2_9dd6ba6e:

    # MC "Oh... I guess this must be it."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:92
translate chinese MLR3_b_house_bag2_73dc3bd0:

    # MC "(That’s quite a nice selection of wine! I wonder if the landlord left this for us.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:93
translate chinese MLR3_b_house_bag2_6e2e5ad0:

    # Mom "I’ll just be a minute. Come on in and take a seat."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:97
translate chinese MLR3_b_house_bag2_a2978dac:

    # MC "Sure, no problem."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:98
translate chinese MLR3_b_house_bag2_273bd91b:

    # MC "(Fresh fruit too? This couldn’t have been left by the landlord.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:99
translate chinese MLR3_b_house_bag2_f888e17d:

    # MC "([Mom_name] must have prepared it when I was putting the luggage away in her room.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:103
translate chinese MLR3_b_house_bag2_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:104
translate chinese MLR3_b_house_bag2_fe56292a:

    # MC "Did you make all this?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:105
translate chinese MLR3_b_house_bag2_650d4228:

    # Mom "Hehe... I snuck the wine with me in the car and prepared the fruit while you were in the bedroom."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:109
translate chinese MLR3_b_house_bag2_ee2c9d27:

    # Mom "The night is still young, so I wanted you and me to enjoy it together... with a proper romantic date."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:110
translate chinese MLR3_b_house_bag2_f5adce5a:

    # Mom "We’ll sit back, cuddle, nibble on some fresh fruit, and maybe get a little tipsy."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:111
translate chinese MLR3_b_house_bag2_0324e38e:

    # MC "That sounds great, [Mom_name]! Thanks for planning this."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:112
translate chinese MLR3_b_house_bag2_2e6d00e4:

    # Mom "Help yourself to a glass, and join me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:116
translate chinese MLR3_b_house_bag2_ce696b17:

    # Mom "So, what do you think of the wine? I’ve never noticed you drinking much before."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:117
translate chinese MLR3_b_house_bag2_102b25cb:

    # MC "It’s alright, I guess. I’m not very used to it."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:118
translate chinese MLR3_b_house_bag2_cba976d4:

    # Mom "Yeah, it can take a couple of years to develop an appreciation for a good wine. If you want some pointers, try to use all your senses when drinking it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:122
translate chinese MLR3_b_house_bag2_0473ce55:

    # Mom "Focus on the smell and the visuals - as well as the taste."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:123
translate chinese MLR3_b_house_bag2_866d418a:

    # MC "*Sniff*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:124
translate chinese MLR3_b_house_bag2_b4cfcbc6:

    # MC "I think I see what you mean."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:125
translate chinese MLR3_b_house_bag2_564d61a4:

    # Mom "Don’t worry if you don’t get it yet - it’s a skill that comes with age."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:129
translate chinese MLR3_b_house_bag2_c27a83bc:

    # Mom "Speaking of skills: have you ever thought about what job you’d like to do after you graduate?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:130
translate chinese MLR3_b_house_bag2_e72e17e9:

    # MC "Hmm... I haven’t actually."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:131
translate chinese MLR3_b_house_bag2_c1e1c18c:

    # Mom "You should probably put some thought into that. It’ll come around much quicker than you think."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:135
translate chinese MLR3_b_house_bag2_9149c2e7:

    # Mom "It’s hard to describe, but time is a lot like a car sitting at the top of a hill with the handbrake left off."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:136
translate chinese MLR3_b_house_bag2_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:137
translate chinese MLR3_b_house_bag2_f8d86ad7:

    # Mom "One day, that car will start to move. It’ll begin rolling its way down the hill. At the start, it’ll be slow and steady. Yet, with each passing minute it’ll become faster and faster."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:138
translate chinese MLR3_b_house_bag2_4e62b95b:

    # MC "I’m not following you, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:139
translate chinese MLR3_b_house_bag2_14bf7ad3:

    # Mom "A person’s perception of time grows faster as they grow older. Each year goes quicker than the last."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:143
translate chinese MLR3_b_house_bag2_604bad51:

    # MC "(I’m sure [Mom_name] is building up to quite a heavy point here. I’m not entirely sure what it is yet though.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:144
translate chinese MLR3_b_house_bag2_f9429bb5:

    # MC "*Sip*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:145
translate chinese MLR3_b_house_bag2_d009c186:

    # MC "(Hmm, it’s not that bad actually.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:149
translate chinese MLR3_b_house_bag2_ed72814b:

    # Mom "Listen... What I’m trying to say is... Well, I’m trying to say a couple of things actually."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:150
translate chinese MLR3_b_house_bag2_73fc9bcc:

    # Mom "Firstly, make plans for yourself, and commit to doing them before it’s too late."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:151
translate chinese MLR3_b_house_bag2_7a9728d6:

    # Mom "Secondly... I... I wish I hadn’t waited so long to tell you how I felt about you. Every memory that we had before our relationship started, feels like a wasted day. A day we could have spent together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:155
translate chinese MLR3_b_house_bag2_781877ae:

    # Mom "I’m sorry, I know this is heavy. I just wanted to get it out of the way, at the start of the night."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:156
translate chinese MLR3_b_house_bag2_6029a691:

    # Mom "I envy you, [player_name]. I envy how young you are. I envy how each minute you spend with me, feels longer than the minutes I spend with you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:157
translate chinese MLR3_b_house_bag2_4256a2eb:

    # MC "[Mom_name]..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:161
translate chinese MLR3_b_house_bag2_01b1962d:

    # Mom "I thought I’d be content, once I had you. I thought you were everything I wanted."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:162
translate chinese MLR3_b_house_bag2_321421c7:

    # Mom "But... I don’t know. I guess I’m just scared of losing you to someone younger. Someone your age."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:163
translate chinese MLR3_b_house_bag2_5cd6ce20:

    # MC "[Mom_name], you’re not gonna lose me. I love you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:167
translate chinese MLR3_b_house_bag2_9aad979d:

    # Mom "I know... I love you too, [player_name]."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:168
translate chinese MLR3_b_house_bag2_81bb6278:

    # MC "Are you sure you’re okay, [Mom_name]? You seem a little more... dour than usual."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:169
translate chinese MLR3_b_house_bag2_f95aceb0:

    # Mom "It’s just, I’m not really able to talk about any of this stuff when I’m in the house. I can’t risk myself getting too emotional."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:173
translate chinese MLR3_b_house_bag2_f327ce0a:

    # Mom "*Sip*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:174
translate chinese MLR3_b_house_bag2_1d49959f:

    # MC "(I guess she wanted to go on this holiday with me for more than just sex. It seems she genuinely wants to have a deep and meaningful conversation.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:175
translate chinese MLR3_b_house_bag2_4364f0fa:

    # MC "[Mom_name], c’mon and sit on my lap."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:179
translate chinese MLR3_b_house_bag2_7a44018f:

    # Mom "No! I’m too heavy!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:180
translate chinese MLR3_b_house_bag2_b2382c2f:

    # MC "Nonsense, you’re not at all! See? I lifted you up here, didn’t I?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:181
translate chinese MLR3_b_house_bag2_c7e8fe5b:

    # Mom " Well... as long as I’m not hurting you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:185
translate chinese MLR3_b_house_bag2_097fe9a0:

    # Mom " I really love you, [player_name]."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:186
translate chinese MLR3_b_house_bag2_17850f18:

    # Mom "I’m sorry for being so heavy at the start of the night. I just... had to get all this crap out of my system."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:187
translate chinese MLR3_b_house_bag2_c284f8bc:

    # MC "It’s okay, I understand, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:191
translate chinese MLR3_b_house_bag2_d7fdd035:

    # MC "Everyone has crap that they need to clear, now and then. Just let it out - I’ll be here to listen."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:192
translate chinese MLR3_b_house_bag2_93430739:

    # Mom "Are you sure? I don’t want you getting fed up with me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:193
translate chinese MLR3_b_house_bag2_0fe01409:

    # MC "I’m not gonna get fed up with you. Now, what’s on your mind?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:197
translate chinese MLR3_b_house_bag2_c80401ec:

    # Mom "Well, apart from your father, I’m worried about our age difference. I’ll be at the peak of my career when you’re starting yours."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:199
translate chinese MLR3_b_house_bag2_abb3755d:

    # Mom "Well, apart from Bob, I’m worried about our age difference. I’ll be at the peak of my career when you’re starting yours."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:200
translate chinese MLR3_b_house_bag2_de2fcac1:

    # MC "That’s not a problem at all, [Mom_name]! That’s a good thing?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:201
translate chinese MLR3_b_house_bag2_31c6b41b:

    # Mom "How?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:205
translate chinese MLR3_b_house_bag2_02cae080:

    # MC "Think about it - you’ll be at the top of your career. So, when I need advice on how to manage staff, or how to balance my accounts, who am I gonna turn to?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:206
translate chinese MLR3_b_house_bag2_49c6eec9:

    # MC "I’m get advice from the woman I love - who also happens to be an expert in those areas."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:207
translate chinese MLR3_b_house_bag2_07cbef3d:

    # MC "And when you are introducing new technology to your workplace, you can always rely on me. I’m part of the younger generation. I can keep you up to speed with what’s going on."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:211
translate chinese MLR3_b_house_bag2_d36fe53d:

    # Mom "Ah, I see."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:212
translate chinese MLR3_b_house_bag2_c940b212:

    # MC "These aren’t bad things, [Mom_name]. We just have to make the most of the hand we’ve been dealt."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:213
translate chinese MLR3_b_house_bag2_14882452:

    # MC "We can turn this unusual situation of ours, into an asset."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:217
translate chinese MLR3_b_house_bag2_d9a06138:

    # Mom "God, I love a man with a brain. You look so sexy when you’re concentrating like that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:218
translate chinese MLR3_b_house_bag2_00d6e538:

    # Mom "Thanks for reassuring me. I know I’m being silly."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:219
translate chinese MLR3_b_house_bag2_b7b6c587:

    # MC "It’s okay, [Mom_name]. That’s what people do in a relationship, right? They support each other."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:223
translate chinese MLR3_b_house_bag2_268e9d87:

    # Mom "How the heck did I get so lucky?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:224
translate chinese MLR3_b_house_bag2_6bf18d37:

    # Mom "You’re like a knight in shining armour, who’s arrived to brighten up my life."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:225
translate chinese MLR3_b_house_bag2_3d6ceef3:

    # Mom "I really love-"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:229
translate chinese MLR3_b_house_bag2_796b53c1:

    # "*BZZT*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:231
translate chinese MLR3_b_house_bag2_796b53c1_1:

    # "*BZZT*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:232
translate chinese MLR3_b_house_bag2_03b9cf62:

    # Mom "Who the-?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:237
translate chinese MLR3_b_house_bag2_7089aa30:

    # Mom "Oh shit. It’s your father."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:239
translate chinese MLR3_b_house_bag2_23794cb5:

    # Mom "Oh shit. It’s Bob."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:240
translate chinese MLR3_b_house_bag2_2993918a:

    # MC "Fuck. Are you going to answer it?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:242
translate chinese MLR3_b_house_bag2_796b53c1_2:

    # "*BZZT*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:244
translate chinese MLR3_b_house_bag2_796b53c1_3:

    # "*BZZT*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:248
translate chinese MLR3_b_house_bag2_b368b5e8:

    # Mom "*Sigh* I guess I better. [Dad_name] will start texting every five minutes, if I don’t."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:250
translate chinese MLR3_b_house_bag2_796b53c1_4:

    # "*BZZT*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:251
translate chinese MLR3_b_house_bag2_24495ff8:

    # Mom "He’s such a clingy piece of-"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:255
translate chinese MLR3_b_house_bag2_f3b978b4:

    # Mom "Hello, Bob. What’s up?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:256
translate chinese MLR3_b_house_bag2_a7fcab98:

    # MC "(I wonder what he’s calling for. Maybe just to catch up?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:257
translate chinese MLR3_b_house_bag2_c7120bd7:

    # Mom "Uh huh."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:261
translate chinese MLR3_b_house_bag2_aaf8fb1c:

    # Mom "Yes, Bob. In the freezer."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:262
translate chinese MLR3_b_house_bag2_1d6022af:

    # MC "([Dad_name] must just be home from work and wondering where dinner is.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:263
translate chinese MLR3_b_house_bag2_164d7916:

    # Mom "Everyone knows how to work an oven, Bob. Get Sara or Caroline to show you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:267
translate chinese MLR3_b_house_bag2_60937337:

    # Mom "No, Bob! Don’t just order a pizza! This is WHY you are putting on so much weight!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:268
translate chinese MLR3_b_house_bag2_ed905715:

    # Mom "And just because I’m not there doesn’t give you an excuse to smoke your damn cigars in the bedroom. I can NEVER get the stench out of my bedsheets!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:269
translate chinese MLR3_b_house_bag2_5b14484b:

    # MC "(Yikes!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:273
translate chinese MLR3_b_house_bag2_6050b76a:

    # Mom "Ugh! Goodnight, Bob."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:274
translate chinese MLR3_b_house_bag2_0fac66b9:

    # Mom "I said, goodnight."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:275
translate chinese MLR3_b_house_bag2_87585cc2:

    # Mom "No, I am NOT going to say those words back to you. Now, GOODNIGHT, BOB."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:277
translate chinese MLR3_b_house_bag2_09d06ab8:

    # "*Click*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:281
translate chinese MLR3_b_house_bag2_ba20752d:

    # Mom "*Sigh* I’m sorry about that, [player_name]. I completely forgot about him."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:282
translate chinese MLR3_b_house_bag2_8975175c:

    # Mom "The blithering imbecile can’t even prepare a frozen dinner for himself. He doesn’t know how to operate an oven. Can you believe that?! A man not knowing how to work an oven - in the 21st Century!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:283
translate chinese MLR3_b_house_bag2_79749448:

    # MC "Easy, [Mom_name]. Don’t let him get to you. Just take some deep breaths and-"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:287
translate chinese MLR3_b_house_bag2_1c165173:

    # "*Deedle le Deedle le Deedle*"
    ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:288
translate chinese MLR3_b_house_bag2_aeed8739:

    # Mom "Please tell me that isn’t your phone?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:289
translate chinese MLR3_b_house_bag2_abb05f2c:

    # MC "*Groan* It is."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:293
translate chinese MLR3_b_house_bag2_eb35d441:

    # Mom "You don’t have to answer it. Just hang up and let it go to voicemail."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:294
translate chinese MLR3_b_house_bag2_f95e0b47:

    # MC "I’ll just check who it is, first."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:295
translate chinese MLR3_b_house_bag2_6a9f9cdc:

    # MC "It might be Sara or Caroline needing help with something."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:299
translate chinese MLR3_b_house_bag2_56dc53a1:

    # Mom "OR it could just be your dad."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:302
translate chinese MLR3_b_house_bag2_ce48e25d:

    # Mom "OR it could just be Bob."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:303
translate chinese MLR3_b_house_bag2_84ea767b:

    # MC "Umm..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:309
translate chinese MLR3_b_house_bag2_1bcccbd3:

    # MC "Uh, hello?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:310
translate chinese MLR3_b_house_bag2_9c251249:

    # Bob "Hello there, champ! What’s up?"
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:311
translate chinese MLR3_b_house_bag2_b9257bb9:

    # MC "Uh, nothing much, [Dad_name]. I’m a little busy right now though."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:315
translate chinese MLR3_b_house_bag2_8534ea12:

    # Mom "*Whispered* Hang up."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:316
translate chinese MLR3_b_house_bag2_209726df:

    # Bob "Listen, I need your help here. I’ve just gotten one of those frozen dinners out of the freezer. I can’t figure out how to work this ruddy oven though!"
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:317
translate chinese MLR3_b_house_bag2_36086277:

    # Bob "Am I supposed to use celsius or fahrenheit?"
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:318
translate chinese MLR3_b_house_bag2_b6e3ce30:

    # MC "I, um..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:322
translate chinese MLR3_b_house_bag2_b3bcdd2e:

    # Bob "Hello? You still there?"
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:323
translate chinese MLR3_b_house_bag2_721a9643:

    # MC "Y-Yeah, I’m just... Have you tried just putting it in and hoping for the best?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:324
translate chinese MLR3_b_house_bag2_f9876c27:

    # Mom "*Whispered* Hang. Up. Now."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:328
translate chinese MLR3_b_house_bag2_88974e9d:

    # Bob "Hello? Hello?"
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:329
translate chinese MLR3_b_house_bag2_3d5a4157:

    # Bob "Are you there, champ?"
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:330
translate chinese MLR3_b_house_bag2_2cdf83e4:

    # Bob "There must be a bad signal where you are, I’ll try calling you tomorrow! Sara! Sara! C’mon down and help me fix the oven."
    Bob ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:335
translate chinese MLR3_b_house_bag2_31a0b365:

    # MC "I’ll just let it go to voicemail."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:336
translate chinese MLR3_b_house_bag2_c1abcfb6:

    # MC "If he really needs help he can speak to Sara or Caroline. They’re both at home."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:337
translate chinese MLR3_b_house_bag2_7a0be470:

    # Mom "Thanks, Sweetie."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:345
translate chinese MLR3_b_house_bag3_81c6b6fd:

    # Mom "Now, I have a little surprise for you. Go and make yourself comfortable in the bedroom and wait for me there."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:346
translate chinese MLR3_b_house_bag3_70f4ca9b:

    # MC "Okay, how long will you be?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:347
translate chinese MLR3_b_house_bag3_62c6d454:

    # Mom "Ten-ish minutes."
    Mom ""

translate chinese strings:

    # game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:305
    old "Answer the phone."
    new ""

    # game/scripts/beach/Beach_Event/MLR3_b_house_bag2.rpy:305
    old "Let it go to voicemail."
    new ""

