﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_beach_money.rpy:9
translate chinese MLR3_beach_money_4c20a0f4:

    # MC "(Hmm... Let's see if there's something interesting in the bag.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_money.rpy:11
translate chinese MLR3_beach_money_9042a130:

    # MC "(Ah! Nice. There's some cash. {color=#00ff00}(+38$){/color})"
    MC ""

