﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:56
translate chinese MLR3_beach_event_48c1e588:

    # "*Creak*"
    ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:61
translate chinese MLR3_beach_event_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:63
translate chinese MLR3_beach_event_acdce1cd:

    # MC "Zzz..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:66
translate chinese MLR3_beach_event_91ea4cf9_1:

    # "*Thud*"
    ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:67
translate chinese MLR3_beach_event_0f88698f:

    # MC "Hmm? (What the hell is all that banging?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:72
translate chinese MLR3_beach_event_7831c5c2:

    # MC "Huh? [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:73
translate chinese MLR3_beach_event_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:74
translate chinese MLR3_beach_event_9f0e9a75:

    # MC "(What’s she doing in my room, this early in the morning?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:78
translate chinese MLR3_beach_event_d3c509a1:

    # MC "(Not that I’m complaining - the view is great!)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:79
translate chinese MLR3_beach_event_5b01766a:

    # MC "(Why is she rummaging through my drawers? Maybe she’s putting some ironing away?)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:83
translate chinese MLR3_beach_event_2e228476:

    # Mom "Ah, you’re finally awake."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:84
translate chinese MLR3_beach_event_ff2271d1:

    # MC "Ugh... morning. *YAWN*"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:85
translate chinese MLR3_beach_event_dcd552ff:

    # Mom "You looked tired, so I let you sleep in, and packed your clothes for you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:89
translate chinese MLR3_beach_event_92abe16f:

    # MC "Sweet! Thanks, [Mom_name]!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:90
translate chinese MLR3_beach_event_00d666aa:

    # Mom "No problem, Honey. That’s us, all ready to go to the beach now. I was thinking that we should probably leave in the next five minutes, before people start waking up."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:91
translate chinese MLR3_beach_event_e5adc3e9:

    # Mom "I don’t want them to see us leaving the house together, and get suspicious."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:95
translate chinese MLR3_beach_event_dc253e34:

    # MC "Yeah, no problem. I understand. Let me get dressed quickly and I’ll meet you out by the car."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:96
translate chinese MLR3_beach_event_f8c84e96:

    # Mom "Great, thanks. We’re going to have an amazing time together - I promise!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:100
translate chinese MLR3_beach_event_6e6d3ea6:

    # Mom "*Mwah*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:102
translate chinese MLR3_beach_event_86456ed8:

    # MC "([Mom_name] just kissed my forehead there. She used to do that, when I was really young, before I went to sleep.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:104
translate chinese MLR3_beach_event_283fbc03:

    # MC "(I never appreciated the view that came with those kisses, when I was that age.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:108
translate chinese MLR3_beach_event_4715e47b:

    # Mom "Throw some clothes on and creep out to the car. I’ll be waiting in the driver’s seat."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:109
translate chinese MLR3_beach_event_785de004:

    # MC "Sure. No problem."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:110
translate chinese MLR3_beach_event_bd37212e:

    # Mom "And don’t forget your luggage! It’d be awful if you didn't have any clothes to wear."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:111
translate chinese MLR3_beach_event_351723fa:

    # Mom "(Actually... that would be kind of fucking hot.)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:119
translate chinese MLR3_beach_event_3c02b746:

    # "*Brummm*"
    ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:124
translate chinese MLR3_beach_event_20341c58:

    # Mom "This is the first time you’ve been on holiday this year, isn't it?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:126
translate chinese MLR3_beach_event_15c77cef:

    # MC "Yeah, the last time I think I went was... Hmm... Where did we all go last year, as a family?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:129
translate chinese MLR3_beach_event_a7585327:

    # Mom "It was Peurto Rico. Remember we all went camping in the El Yunque national forest?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:131
translate chinese MLR3_beach_event_88b87762:

    # MC "Yeah, the last time I think I went was... Hmm... Where was that place we all headed the last time?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:133
translate chinese MLR3_beach_event_78e6e4eb:

    # Mom "It was Peurto Rico. Remember Bob got the big bonus and invited all your tenants along too?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:135
translate chinese MLR3_beach_event_86ebcea0:

    # MC "Oh yeah! Was that a year ago? It seems so much longer."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:137
translate chinese MLR3_beach_event_718e98c1:

    # Mom "It was a year. I went hiking with the girls while you hung out with your father. What did you two end up doing?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:139
translate chinese MLR3_beach_event_41cfa6c2:

    # Mom "It was a year, I went hiking with the girls while you hung out with Bob. What did you two end up doing?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:142
translate chinese MLR3_beach_event_bb2f8f7b:

    # MC "[Dad_name] snuck his rod with him, so we ended up illegally fishing. He kept throwing them back in after he caught them."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:144
translate chinese MLR3_beach_event_3815d2a3:

    # Mom "Haha! That’s so your father. Nothing can get between him and his fishing."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:146
translate chinese MLR3_beach_event_bde56d80:

    # Mom "Haha! That’s so Bob: Nothing can get between him and his fishing."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:147
translate chinese MLR3_beach_event_b078ab1a:

    # MC "It wasn’t amazing fun, but I did kinda enjoy hanging out with him."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:148
translate chinese MLR3_beach_event_8e9812ea:

    # Mom "It’ll be quite a long drive. I’d suggest closing your eyes and catching up on your sleep. I’ll wake you up when we get there."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:149
translate chinese MLR3_beach_event_0755c8da:

    # MC "*Yawn* Thanks, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:202
translate chinese MLR3_beach_event2_acdce1cd:

    # MC "Zzz..."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:204
translate chinese MLR3_beach_event2_2fa529f3:

    # Mom "Hey [player_name]! Wake up, we’re almost there."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:205
translate chinese MLR3_beach_event2_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:206
translate chinese MLR3_beach_event2_841926fd:

    # MC "Oh cool! Wow, it’s stunning!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:207
translate chinese MLR3_beach_event2_edb505df:

    # Mom "Let’s pull up and get changed into our swimwear."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:217
translate chinese MLR3_beach_event2_8dc8e8f1:

    # MC "The views are spectacular!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:218
translate chinese MLR3_beach_event2_946e9f8d:

    # Mom "Yup! The first time I ever came to this place, I thought, I have to bring [player_name] here someday."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:219
translate chinese MLR3_beach_event2_9322657e:

    # MC "Really? You thought that?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:223
translate chinese MLR3_beach_event2_86f2fcec:

    # Mom "Honestly? I’ve had a lot of thoughts about you and me visiting this place together."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:224
translate chinese MLR3_beach_event2_11ba2841:

    # MC "That’s so sweet, [Mom_name]."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:225
translate chinese MLR3_beach_event2_90325633:

    # Mom "Well, if you knew ALL my thoughts, you’d probably not think of me as ‘sweet’. Some of them were pretty dirty."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:229
translate chinese MLR3_beach_event2_800303a0:

    # MC "Haha, I already know that."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:230
translate chinese MLR3_beach_event2_6d04b79e:

    # Mom "This was where I was planning to make my move on you for the first time. I wanted to bring you here one day..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:231
translate chinese MLR3_beach_event2_4614cdd7:

    # MC "Oh yeah? How were you planning to do that?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:235
translate chinese MLR3_beach_event2_776cd54f:

    # Mom "I had a couple of tricks... Most of them were just silly fantasies that would have scared you off though."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:236
translate chinese MLR3_beach_event2_3555c815:

    # MC "Aww, c’mon! I wanna hear them!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:237
translate chinese MLR3_beach_event2_c9afe2b6:

    # Mom "No, they’re embarrassing!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:241
translate chinese MLR3_beach_event2_93d3b51d:

    # MC "Please tell me! I really wanna know!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:242
translate chinese MLR3_beach_event2_c21ee25b:

    # Mom "Haha, fine! You have to promise not to laugh, though. These were SILLY ideas!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:243
translate chinese MLR3_beach_event2_963a7199:

    # MC "Okay, I swear I’m not going to laugh."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:244
translate chinese MLR3_beach_event2_cf5ea12d:

    # Mom "Alright... *Deep breath*"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:248
translate chinese MLR3_beach_event2_fe918599:

    # Mom "I had a few plans. My original goal was to get you SO turned on that you needed to fool around with a girl, even if it meant your own mother."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:250
translate chinese MLR3_beach_event2_c1ef3ad9:

    # Mom "I had a few plans. My original goal was to get you SO turned on that you needed to fool around with a girl, even if it meant your landlady."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:251
translate chinese MLR3_beach_event2_10c4af04:

    # Mom "I was planning to take you away on a holiday up here, but deliberately leave my bikini top behind. I was going to act all disappointed about not being able to go swimming."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:252
translate chinese MLR3_beach_event2_cebfeeb7:

    # Mom "Eventually, I was hoping you’d cave and agree to let me swim topless with you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:256
translate chinese MLR3_beach_event2_f066990b:

    # Mom "You’d see my naked breasts, but you would be too nervous to say anything. The longer we swam around together, the hornier you would get."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:257
translate chinese MLR3_beach_event2_8eba9992:

    # Mom "I was planning to tease you throughout the day too. Seductively eating a banana, sucking a drink through a straw, showering with the door open. Stuff like that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:258
translate chinese MLR3_beach_event2_1f140734:

    # Mom "I had to get you SO horny that you couldn’t resist my advances that would happen that night."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:262
translate chinese MLR3_beach_event2_a620684f:

    # MC "How were you actually going to initiate something with me though? I mean, were you not worried I’d freak out and run away?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:263
translate chinese MLR3_beach_event2_39ad3d07:

    # Mom "Of course, I was! Sometimes... Sometimes I still am."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:264
translate chinese MLR3_beach_event2_c050afbc:

    # MC "You’re still scared I’ll run away?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:268
translate chinese MLR3_beach_event2_12a98d81:

    # Mom "I guess so... Not very often, just sometimes. It’s not normal for a mother to be dating her son like this. I’m scared peer pressure might get to you, and you’ll just freak out and leave me someday."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:270
translate chinese MLR3_beach_event2_29f4d06a:

    # Mom "I guess so... Not very often, just sometimes. It’s not normal for a landlady to be dating her tenant like this. I’m scared peer pressure might get to you, and you’ll just freak out and leave me someday."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:271
translate chinese MLR3_beach_event2_82dac4cc:

    # MC "[Mom_name], that’s not going to happen. I’m in love with you."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:272
translate chinese MLR3_beach_event2_c40b2acf:

    # Mom "Thank you, [player_name]. It’s reassuring to hear you say that."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:276
translate chinese MLR3_beach_event2_f03ade48:

    # MC "(Her hand is so warm against mine. I love just lying beside her like this. No fear of who sees us, or worries about getting caught.)"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:277
translate chinese MLR3_beach_event2_47cd05bd:

    # MC "So yeah, how were you planning to kick things off with me?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:278
translate chinese MLR3_beach_event2_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:282
translate chinese MLR3_beach_event2_3c82b881:

    # Mom "Well... once I knew you were extremely horny I was going to give you some time alone. I know that a guy your age couldn’t resist an opportunity to start masturbating."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:283
translate chinese MLR3_beach_event2_076c9468:

    # MC "Oh, c’mon! We’re not THAT bad!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:284
translate chinese MLR3_beach_event2_0db75d0a:

    # Mom "Haha! Yes you are!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:288
translate chinese MLR3_beach_event2_37e146a4:

    # Mom "Are you gonna let me finish the story?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:289
translate chinese MLR3_beach_event2_03a66d93:

    # MC "Sorry, my bad."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:290
translate chinese MLR3_beach_event2_a2d10f8e:

    # Mom "C’mon closer beside me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:294
translate chinese MLR3_beach_event2_d9686a86:

    # Mom "Anyway, I’d planned to give you some time alone. I knew you’d start masturbating."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:295
translate chinese MLR3_beach_event2_593f8017:

    # Mom "My plan was to walk in on you, completely topless, and act surprised."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:296
translate chinese MLR3_beach_event2_76fc8f23:

    # Mom "As for what happens next... I’ve had a dozen different fantasies play through my head while I finger myself and think about it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:300
translate chinese MLR3_beach_event2_02a70634:

    # Mom "In some of them, I sit down and spread my legs for you, letting you gaze at me while I masturbate in front of you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:301
translate chinese MLR3_beach_event2_5e6278ae:

    # Mom "You’re a little hesitant at first, but you soon get into it."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:302
translate chinese MLR3_beach_event2_4d689300:

    # MC "Mmm, I like that one."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:306
translate chinese MLR3_beach_event2_b0af1cdb:

    # Mom "Another one of my fantasies is that I pretend to trip when I catch you masturbating, accidentally falling face-first into your lap."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:307
translate chinese MLR3_beach_event2_ac34c52a:

    # Mom "I’d ‘accidentally’ let your cock slip into my mouth, and you just wouldn’t be able to resist the sudden pleasure it gave you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:308
translate chinese MLR3_beach_event2_8fa0bed6:

    # MC "You’ve got a really dirty mind, you know that, [Mom_name]?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:309
translate chinese MLR3_beach_event2_a7e11af1:

    # Mom "Hehe, I know. It’s filthy."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:310
translate chinese MLR3_beach_event2_13817c47:

    # MC "So, what if I didn’t like this sudden blowjob out of nowhere?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:311
translate chinese MLR3_beach_event2_adf1c3c0:

    # Mom "Whether you wanted it or not, I was probably going to pin you down and keep sucking, and sucking, and sucking until you came."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:315
translate chinese MLR3_beach_event2_f47d602f:

    # MC "Mmm... Fuck... that’s so hot."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:316
translate chinese MLR3_beach_event2_c7fd0507:

    # Mom "I know, right?"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:317
translate chinese MLR3_beach_event2_02115e29:

    # Mom "I’ve got YEARS of pent up sexual frustration, and tonight I’m taking them all out on you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:318
translate chinese MLR3_beach_event2_56b16c1d:

    # Mom "You lucky bastard."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:322
translate chinese MLR3_beach_event2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:323
translate chinese MLR3_beach_event2_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:324
translate chinese MLR3_beach_event2_bb17fa6c:

    # Mom "(My fantasies are finally coming true!)"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:328
translate chinese MLR3_beach_event2_7f70e021:

    # MC "Y’know, I’m really enjoying these fantasies about how you planned to seduce me. Could you tell me a couple more?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:329
translate chinese MLR3_beach_event2_070553c8:

    # Mom "Haha, sure. Hmm..."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:331
translate chinese MLR3_beach_event2_e18f5200:

    # Mom "Another favourite of mine was a little... rapey."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:333
translate chinese MLR3_beach_event2_de5a56cb:

    # Mom "Another favourite of mine was a little... out there."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:337
translate chinese MLR3_beach_event2_04b855b0:

    # MC "Rapey?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:339
translate chinese MLR3_beach_event2_3cc0a58b:

    # MC "Out there?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:340
translate chinese MLR3_beach_event2_2f40af2d:

    # Mom "Y’know... tying your wrists and ankles to the bed, riding your cock, just jumping at you and taking what I wanted."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:341
translate chinese MLR3_beach_event2_f4da8a0e:

    # MC "Yeah, I’m kinda glad you didn’t open with that idea."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:342
translate chinese MLR3_beach_event2_0f2128f3:

    # Mom "Haha, me too!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:346
translate chinese MLR3_beach_event2_373205ee:

    # Mom "I also thought about paying a girl about your age to seduce you."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:347
translate chinese MLR3_beach_event2_c2b84059:

    # MC "Huh?! Why?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:348
translate chinese MLR3_beach_event2_19a23795:

    # Mom "She’d get you all turned on, then blindfold you. Once that was all done I’d pay her the money and take over myself."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:352
translate chinese MLR3_beach_event2_4f556775:

    # Mom "I’d be able to suck and fuck you all I wanted and you’d never know that you were fooling around with your own mother."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:354
translate chinese MLR3_beach_event2_529713b4:

    # Mom "I’d be able to suck and fuck you all I wanted and you’d never know that you were fooling around with your landlady."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:355
translate chinese MLR3_beach_event2_cb053b12:

    # Mom "After you climaxed I’d bring the girl back in and you’d think nothing was out of the ordinary."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:356
translate chinese MLR3_beach_event2_9ac9f95a:

    # Mom "The best part about this idea was that I could have kept it going, over and over. At least until you got fed up with the blindfold."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:357
translate chinese MLR3_beach_event2_422242ba:

    # MC "You’ve put WAY too much time into thinking about this stuff!"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:361
translate chinese MLR3_beach_event2_967fdc72:

    # Mom "I know, tell me about it. Sometimes I get so damn horny that I even have to masturbate at work!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:362
translate chinese MLR3_beach_event2_de7df622:

    # MC "You finger yourself at work?"
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:366
translate chinese MLR3_beach_event2_c30752a4:

    # Mom "Sometimes. I’ve got my own private office, so I can do it without people noticing me."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:367
translate chinese MLR3_beach_event2_ca317de5:

    # Mom "The hardest part is, keeping my voice down."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:368
translate chinese MLR3_beach_event2_76f39ae3:

    # Mom "I don't know why, but something about having sex in public places and the thrill of getting caught gets me SOOOO wet."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:372
translate chinese MLR3_beach_event2_96ff8a18:

    # MC "Thanks again for bringing me to the beach, [Mom_name]. It’s really nice here."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:373
translate chinese MLR3_beach_event2_c4b24d69:

    # MC "And for the record, I love the other ideas you had for seducing me. They were really hot."
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:374
translate chinese MLR3_beach_event2_6db9dcf3:

    # Mom "Hehe, I’m glad you enjoyed them. I know I have!"
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:378
translate chinese MLR3_beach_event2_6d7cf82e:

    # Mom "Okay, let’s check other stuff at the beach, unless you're trying to keep me in the full sun until evening."
    Mom ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:379
translate chinese MLR3_beach_event2_c79b94f2:

    # MC "What? Of course not. "
    MC ""

# game/scripts/beach/Beach_Event/MLR3_beach_event.rpy:380
translate chinese MLR3_beach_event2_4cf0353b:

    # Mom "I’ll be just behind you."
    Mom ""

