﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ne_home/Corridor/M/Ne_corridor_M.rpy:21
translate chinese Ne_Corridor_M1_aeb91391:

    # MC "(It's locked.)"
    MC ""

