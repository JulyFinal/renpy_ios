﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ne_home/Kitchen/M/Ne_Kitchen_M.rpy:2
translate chinese Ne_Kitchen_M1_aeb91391:

    # MC "(It's locked.)"
    MC ""

