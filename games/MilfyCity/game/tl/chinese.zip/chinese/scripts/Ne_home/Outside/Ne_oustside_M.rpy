﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ne_home/Outside/Ne_oustside_M.rpy:26
translate chinese Ne_outside_M1_49deaba2:

    # MC "(I should try at night or evening.)"
    MC ""

