﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:67
translate chinese Zv2_ES4_truth_label_946f9916:

    # Zuri "Well, [player_name], it seems like I made the right decision to trust you."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:69
translate chinese Zv2_ES4_truth_label_de127828:

    # Suri "Yeah, you really pulled through for us, kid."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:71
translate chinese Zv2_ES4_truth_label_f417904d:

    # Suri "Yeah, you really pulled through for us, pal."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:72
translate chinese Zv2_ES4_truth_label_ca85e44d:

    # Zuri "Those names have made us a WHOLE lotta money."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:76
translate chinese Zv2_ES4_truth_label_9d1cbb4b:

    # MC "Hey, I’m just happy I could be of help."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:77
translate chinese Zv2_ES4_truth_label_c813105e:

    # Zuri "Well, we’re grateful."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:78
translate chinese Zv2_ES4_truth_label_46bd04fc:

    # Suri "Very grateful."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:79
translate chinese Zv2_ES4_truth_label_1fab15bd:

    # Zuri "Take a seat and we’ll show you just how grateful we are."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:83
translate chinese Zv2_ES4_truth_label_d09b945b:

    # Zuri "You may not have realised it yet, but what you did for us, means we will never need to work another day in our lives."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:84
translate chinese Zv2_ES4_truth_label_caad7d5e:

    # MC "R-Really?!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:85
translate chinese Zv2_ES4_truth_label_bcf4c897:

    # Zuri "Oh, yes. The mortgage on this house has been fully paid. All our debts are gone, and the interest we get from our investments is more than the average salary in this country!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:86
translate chinese Zv2_ES4_truth_label_cbee4c43:

    # MC "Wow... That’s insane!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:91
translate chinese Zv2_ES4_truth_label_292f9e52:

    # Suri "You better enjoy every last moment of this, kid. You earned it!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:93
translate chinese Zv2_ES4_truth_label_9cc782bb:

    # Suri "You better enjoy every last moment of this, pal. You earned it!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:94
translate chinese Zv2_ES4_truth_label_1c018eb7:

    # Suri "This is a multi-million dollar ass, right here!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:95
translate chinese Zv2_ES4_truth_label_accd44b2:

    # Suri "You’ll probably never see a pussy this expensive again, in your whole life!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:99
translate chinese Zv2_ES4_truth_label_45e087b4:

    # Suri "Sit back, relax, and take it ALL in."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:100
translate chinese Zv2_ES4_truth_label_673b3295:

    # Zuri "Take your pants off, [player_name]. We need your cock out for the next part."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:101
translate chinese Zv2_ES4_truth_label_29af55f8:

    # MC "Oh yeah... I’ll do that now."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:105
translate chinese Zv2_ES4_truth_label_0f550d04:

    # Suri "Mmm! Hard, as always! I’m looking forward to riding this boner!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:106
translate chinese Zv2_ES4_truth_label_f8eb3beb:

    # MC "D-Do you want me to use a condom or-"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:107
translate chinese Zv2_ES4_truth_label_d6cf3b01:

    # Zuri "Relax - we’re both on the pill."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:111
translate chinese Zv2_ES4_truth_label_91acbaa4:

    # MC "*Phew* Good, I just had to check. Don’t want a surprise to bite me in the ass, in nine months!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:112
translate chinese Zv2_ES4_truth_label_b5627913:

    # Suri "Haha! You’re cute!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:113
translate chinese Zv2_ES4_truth_label_1307a953:

    # Zuri "Line your cock up with her pussy, and get ready for some fun!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:117
translate chinese Zv2_ES4_truth_label_1e20d78e:

    # MC "(I can feel the warmth, from her body against mine...)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:118
translate chinese Zv2_ES4_truth_label_c78bcef1:

    # MC "(The tip of my dick is pressing, right against her vulva! She’s so wet right now!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:119
translate chinese Zv2_ES4_truth_label_66bf3aca:

    # MC "(I don’t know if I can last very long, with such a hot girl riding my dick!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:123
translate chinese Zv2_ES4_truth_label_e94d9fff:

    # Suri "That’s it! You can do it..."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:124
translate chinese Zv2_ES4_truth_label_f325a4a6:

    # Suri "Rub it on my pussy a little, before putting it in.."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:126
translate chinese Zv2_ES4_truth_label_50579f4a:

    # Suri "Mmm...Good.. Your cock is so big... Push it inside me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:127
translate chinese Zv2_ES4_truth_label_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:131
translate chinese Zv2_ES4_truth_label_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:132
translate chinese Zv2_ES4_truth_label_280ab3a6:

    # Suri "God... Yessssss!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:133
translate chinese Zv2_ES4_truth_label_d83384ae:

    # Zuri "You look like you’re enjoying that, Suri!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:134
translate chinese Zv2_ES4_truth_label_6eddced4:

    # Suri "It’s sooo thick! Mmm!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:138
translate chinese Zv2_ES4_truth_label_05641a8c:

    # Suri "Oh God! I love your cock, [player_name]!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:139
translate chinese Zv2_ES4_truth_label_8b0d2fd2:

    # Suri "Ah! Ahh!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:140
translate chinese Zv2_ES4_truth_label_e603e888:

    # MC "(She’s so tight and wet! It feels like her pussy is sucking my cock, every time she bounces!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:144
translate chinese Zv2_ES4_truth_label_ed577c3e:

    # MC "(And her breasts are just incredible! She couldn’t be any more than a B Cup, but they’re so perky!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:145
translate chinese Zv2_ES4_truth_label_c2632e0c:

    # Suri "Ah! Ah! Ahh!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:147
translate chinese Zv2_ES4_truth_label_5c27af67:

    # Suri "Why are you looking at my tits, kid?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:149
translate chinese Zv2_ES4_truth_label_e71637b0:

    # Suri "Why are you looking at my tits, pal?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:153
translate chinese Zv2_ES4_truth_label_ba238991:

    # MC "I- uh... S-sorry."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:155
translate chinese Zv2_ES4_truth_label_a8bfdddd:

    # Suri "Hehe, I’m just teasing you. You look as much as you want to."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:156
translate chinese Zv2_ES4_truth_label_bba1100f:

    # Suri "You’ve made Zuri and me very rich women. You can do whatever you want to our bodies."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:160
translate chinese Zv2_ES4_truth_label_4489c4fa:

    # Zuri "She’s right, you know. If you want to fuck both of us, you can."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:161
translate chinese Zv2_ES4_truth_label_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:162
translate chinese Zv2_ES4_truth_label_9465d496:

    # Zuri "Uh huh."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:163
translate chinese Zv2_ES4_truth_label_bd561b01:

    # Suri "I think he’d- ahh... like that, Zuri! Oooh!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:167
translate chinese Zv2_ES4_truth_label_f1fee296:

    # Zuri "Well, [player_name], how would you like to fuck twins at the same time?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:169
translate chinese Zv2_ES4_truth_label_8bdb6d35:

    # Zuri "Well, [player_name], how would you like to fuck both us girls at the same time?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:170
translate chinese Zv2_ES4_truth_label_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:171
translate chinese Zv2_ES4_truth_label_9ce89404:

    # Suri "Hehe, ooh! Let’s blow his mind, Zuri!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:175
translate chinese Zv2_ES4_truth_label_d9310047:

    # Suri "How do you want to do this?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:176
translate chinese Zv2_ES4_truth_label_82d43ce6:

    # Zuri "Remember that time in university, at the gymnastics club?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:177
translate chinese Zv2_ES4_truth_label_f755038e:

    # Suri "Was that the one with the football team or the hockey team?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:178
translate chinese Zv2_ES4_truth_label_983df367:

    # Zuri "The football team."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:179
translate chinese Zv2_ES4_truth_label_f313295d:

    # Suri "Oooh! Yes! Let’s do that for him!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:183
translate chinese Zv2_ES4_truth_label_ea7f9876:

    # Zuri "Well? What do you think?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:184
translate chinese Zv2_ES4_truth_label_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:185
translate chinese Zv2_ES4_truth_label_603ae27d:

    # Suri "I think he likes it, Zuri!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:189
translate chinese Zv2_ES4_truth_label_148fa1e0:

    # Suri "Why do I always have to be on the bottom though?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:191
translate chinese Zv2_ES4_truth_label_8ff9da53:

    # Zuri "It’s tradition at this point, I guess. Plus, since I’m the older twin..."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:192
translate chinese Zv2_ES4_truth_label_04958e4f:

    # Suri "Oh c’mon! You came out thirty minutes before me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:194
translate chinese Zv2_ES4_truth_label_57d209ba:

    # Zuri "It’s tradition at this point, I guess. Plus, I’m older."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:195
translate chinese Zv2_ES4_truth_label_90c88740:

    # Suri "Oh, c'mon! You're not THAT much older than me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:196
translate chinese Zv2_ES4_truth_label_83a88e59:

    # Zuri "Still technically older!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:201
translate chinese Zv2_ES4_truth_label_aff64af2:

    # Zuri "So, which of us would you like to ram your hard cock into first?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:202
translate chinese Zv2_ES4_truth_label_30169569:

    # MC "It’s a tough decision! You both look so fucking hot!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:203
translate chinese Zv2_ES4_truth_label_e128dbe8:

    # Suri "Pick me! Pick me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:207
translate chinese Zv2_ES4_truth_label_b7025ab5:

    # Zuri "MmM! Ahh!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:209
translate chinese Zv2_ES4_truth_label_9f8be114:

    # Suri "Aww... He chose you, didn’t he!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:210
translate chinese Zv2_ES4_truth_label_ec812339:

    # Zuri "Deeper! Get it right in there!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:214
translate chinese Zv2_ES4_truth_label_fdba097b:

    # Zuri "AHH! AHHH! OHHH! GOD! MMMM!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:216
translate chinese Zv2_ES4_truth_label_a9381830:

    # Suri "Fuck her as hard as you can, kid!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:218
translate chinese Zv2_ES4_truth_label_dcd7912f:

    # Suri "Fuck her as hard as you can, pal!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:220
translate chinese Zv2_ES4_truth_label_a61d8b0f:

    # Suri "I love hearing her scream in pleasure!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:222
translate chinese Zv2_ES4_truth_label_f0f66584:

    # MC "(Damn! These twins are kinky!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:224
translate chinese Zv2_ES4_truth_label_5cff4640:

    # MC "(Damn, these gals are kinky!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:228
translate chinese Zv2_ES4_truth_label_3b6dd77a:

    # Zuri "AH! AHHH! OOOHHH! FUCK! FUCK!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:230
translate chinese Zv2_ES4_truth_label_11f1f6fb:

    # Suri "You should have heard her, back in university, kid. Last time we did this position, she had a cock in her ass, and two guys sucking her tits."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:231
translate chinese Zv2_ES4_truth_label_06335757:

    # Suri "They drove my sister INSANE with pleasure, that night!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:233
translate chinese Zv2_ES4_truth_label_5d1303f4:

    # Suri "You should have heard her, back in university, pal. Last time we did this position, she had a cock in her ass, and two guys sucking her tits."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:234
translate chinese Zv2_ES4_truth_label_0052e911:

    # Suri "They drove Zuri INSANE with pleasure, that night!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:238
translate chinese Zv2_ES4_truth_label_a8cbee4a:

    # Zuri "Yes! Yes! Yes! Mmm! Oh God!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:239
translate chinese Zv2_ES4_truth_label_4fac0264:

    # Zuri "I’m cumming! I’m cumming!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:241
translate chinese Zv2_ES4_truth_label_8d9e2a57:

    # MC "Mmm! Hnnng! (Damn, her pussy is as good as her sister’s! But then again, that’s to be expected!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:243
translate chinese Zv2_ES4_truth_label_ff24601b:

    # MC "Mmm! Hnnng! (Damn, her pussy is as good as Suri’s is! But then again, that’s to be expected!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:247
translate chinese Zv2_ES4_truth_label_0c20da2f:

    # Zuri "Holy fuck! It’s sooooo goood! Ahhh!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:249
translate chinese Zv2_ES4_truth_label_8ff3af41:

    # MC "I’m gonna cum soon!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:253
translate chinese Zv2_ES4_truth_label_0e9fe658:

    # Zuri "Cum wherever you want! Ohh fuck!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:257
translate chinese Zv2_ES4_truth_label_a709c253:

    # MC "(I might as well enjoy this pussy until the very last second!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:258
translate chinese Zv2_ES4_truth_label_5ac2d0d5:

    # Zuri "Ah! Ahh! AHHHH!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:259
translate chinese Zv2_ES4_truth_label_5bd8808d:

    # MC "(Let’s fuck her as hard as I can!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:263
translate chinese Zv2_ES4_truth_label_c2d61e28:

    # Zuri "OH GOD! I’M CUMMING AGAIN!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:264
translate chinese Zv2_ES4_truth_label_246a7bf8:

    # MC "UGH! HNNNG!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:265
translate chinese Zv2_ES4_truth_label_18f3c509:

    # MC "(I can feel my cum shooting, deep inside her pussy!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:274
translate chinese Zv2_ES4_truth_label_8ac54b0a:

    # Zuri "(Holy fuck! He’s filling me up!)"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:275
translate chinese Zv2_ES4_truth_label_a0d761f8:

    # Zuri "(God! It’s so hot! Mmm!)"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:276
translate chinese Zv2_ES4_truth_label_739881d1:

    # Zuri "OOOHHHHHH.... Yesss....."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:282
translate chinese Zv2_ES4_truth_label_227eef91:

    # MC "Here we go, ladies! I’m about to cum!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:283
translate chinese Zv2_ES4_truth_label_14d24d01:

    # MC "Hnnnng!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:284
translate chinese Zv2_ES4_truth_label_0e01a1cd:

    # Suri "Make sure you get both of us!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:294
translate chinese Zv2_ES4_truth_label_4bf96f58:

    # MC "HNNNNG! Ugh! Uh!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:295
translate chinese Zv2_ES4_truth_label_e7d9e5a0:

    # Suri "(Ohh! It’s all warm and sticky!)"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:296
translate chinese Zv2_ES4_truth_label_e2fdeea5:

    # Zuri "Nice shooting. There’s A LOT there..."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:306
translate chinese Zv2_ES4_truth_aftermenu_7d38f75c:

    # Suri "Well, kid? Did you enjoy fucking twins?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:308
translate chinese Zv2_ES4_truth_aftermenu_8f5fd3a5:

    # Suri "Well, pal. Did you enjoy fucking two women at once?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:309
translate chinese Zv2_ES4_truth_aftermenu_68ecf43c:

    # MC "It was amazing!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:310
translate chinese Zv2_ES4_truth_aftermenu_e0484ac0:

    # Zuri "I knew it would be."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:311
translate chinese Zv2_ES4_truth_aftermenu_e09fc3e6:

    # Zuri "Thank you again, for everything. You’ve made us both a shit-ton of money."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:312
translate chinese Zv2_ES4_truth_aftermenu_6c0fca2f:

    # Suri "We’ll be sure to come to you again if we can use your help."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:341
translate chinese Zv2_ES4_lie_label_c05fd351:

    # MC "(Huh? Where is everyone?)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:342
translate chinese Zv2_ES4_lie_label_f05d7954:

    # MC "Zuri? Suri?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:343
translate chinese Zv2_ES4_lie_label_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:344
translate chinese Zv2_ES4_lie_label_3f0a6fef:

    # MC "(What the hell is going on? Why would they just leave their front door unlocked like that?)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:348
translate chinese Zv2_ES4_lie_label_7bef0240:

    # Zuri "You deceptive piece of shit!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:349
translate chinese Zv2_ES4_lie_label_007dcd03:

    # MC "AHHH!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:350
translate chinese Zv2_ES4_lie_label_efeab18b:

    # Zuri "Come here, you little fucker!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:357
translate chinese Zv2_ES4_lie_label_0a4dee60:

    # MC "OOOF!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:358
translate chinese Zv2_ES4_lie_label_00dfef65:

    # Zuri "Did you seriously think you could just lie to me - and get away with it?!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:359
translate chinese Zv2_ES4_lie_label_1dd396bc:

    # MC "(Shit! She caught on to me!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:363
translate chinese Zv2_ES4_lie_label_70af2929:

    # Zuri "I... invested... everything in those... worthless pieces of garbage you told me!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:364
translate chinese Zv2_ES4_lie_label_ed121d49:

    # MC "I-I’m sorry, I-"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:365
translate chinese Zv2_ES4_lie_label_7b46f04e:

    # Zuri "EVERYTHING!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:366
translate chinese Zv2_ES4_lie_label_d895eba9:

    # Zuri "MY WHOLE FUCKING LIFE SAVINGS! MY DEAD FATHER’S INHERITANCE!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:370
translate chinese Zv2_ES4_lie_label_8b1fdc0d:

    # Zuri "I lost EVERY cent to my name!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:371
translate chinese Zv2_ES4_lie_label_c0e7ed38:

    # Zuri "I remortgaged this freaking house!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:372
translate chinese Zv2_ES4_lie_label_a515fc3b:

    # Zuri "All because a little rat decided to give me fake company names..."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:376
translate chinese Zv2_ES4_lie_label_d4264c88:

    # Zuri "So, here’s what’s going to happen now."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:377
translate chinese Zv2_ES4_lie_label_47595217:

    # Zuri "I’m going to cut you open. Slowly."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:378
translate chinese Zv2_ES4_lie_label_e9f74d26:

    # Zuri "I’m going to watch as you slowly bleed to death, in the middle of my fucking living room."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:379
translate chinese Zv2_ES4_lie_label_4e6ebbdc:

    # MC "P-Please! D-Don’t!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:383
translate chinese Zv2_ES4_lie_label_60da4abc:

    # Zuri "I’ll begin with your belly, and I’ll slice down. All the way to your pathetic little cock."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:384
translate chinese Zv2_ES4_lie_label_e2b8b3f3:

    # Zuri "When I’m finished with you, they won’t recognise the body."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:385
translate chinese Zv2_ES4_lie_label_300cd198:

    # Zuri "Goodbye... you pathetic little shitstain!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:392
translate chinese Zv2_ES4_lie_label_6b917c5c:

    # "*CLAAANNG*"
    ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:394
translate chinese Zv2_ES4_lie_label_d435c852:

    # Zuri "OOOOHHHH!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:395
translate chinese Zv2_ES4_lie_label_cded424e:

    # MC "Jesus Christ!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:400
translate chinese Zv2_ES4_lie_label_460932f7:

    # MC "Oh fuck... Oh fuck... She’s dead..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:401
translate chinese Zv2_ES4_lie_label_f950eb82:

    # Suri "Relax. She’s not dead, pal. I just knocked her out."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:402
translate chinese Zv2_ES4_lie_label_1e81afbe:

    # MC "R-Really?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:406
translate chinese Zv2_ES4_lie_label_108c3164:

    # Suri "You better get the heck out of here though. She’s gonna murder you if she sees you again."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:407
translate chinese Zv2_ES4_lie_label_5dbccab3:

    # MC "W-Why don’t you want to kill me too?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:408
translate chinese Zv2_ES4_lie_label_a3d408aa:

    # Suri "I do. But you’ve already ruined us financially. There’s no sense in either of us going to prison over you."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:410
translate chinese Zv2_ES4_lie_label_ce82e0df:

    # Suri "Zuri and I will rebuild. We’ll find some other rich CEO’s son and screw him for personal details."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:411
translate chinese Zv2_ES4_lie_label_c47e5d9f:

    # Suri "Now, get the hell out of here, kid. And let me take care of my sister."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:413
translate chinese Zv2_ES4_lie_label_bd972056:

    # Suri "Zuri and I will rebuild. We’ll find some other rich CEO and screw him for personal details."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:414
translate chinese Zv2_ES4_lie_label_f29973c9:

    # Suri "Now, get the hell out of here, pal. And let me take care of Zuri."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:417
translate chinese Zv2_ES4_lie_label_1b856611:

    # MC "Y-Yeah, okay."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:418
translate chinese Zv2_ES4_lie_label_f140c54b:

    # Suri "And, [player_name]?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:419
translate chinese Zv2_ES4_lie_label_489929a1:

    # MC "Yes...?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:420
translate chinese Zv2_ES4_lie_label_8659b42f:

    # Suri "I’m sure it goes without saying, but don’t you DARE show your face at this house again."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:424
translate chinese Zv2_ES4_lie_label_5709f2f1:

    # Suri "Hey.. Zuri.. Wake up!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:425
translate chinese Zv2_ES4_lie_label_3748865e:

    # Suri "I’m sorry.."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:426
translate chinese Zv2_ES4_lie_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:427
translate chinese Zv2_ES4_lie_label_28cc6d56:

    # MC "(Why do I feel like an asshole...)"
    MC ""

translate chinese strings:

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:255
    old "Blow your cum, deep inside Zuri’s pussy."
    new ""

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES4.rpy:255
    old "Pull out and spray your cum over the two women."
    new ""

