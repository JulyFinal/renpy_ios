﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/home/E/zuri_home_E.rpy:20
translate chinese zuri_inhome_E_label_0cc2e222:

    # Zuri "I'm busy now, [player_name]"
    Zuri ""

# game/scripts/Zuri_home/home/E/zuri_home_E.rpy:36
translate chinese zuri_home_E_label2_4e8cd948:

    # MC "(Should I sit on the couch as Zuri wants or should I try speak to her?)"
    MC ""

