﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:32
translate chinese Zv2_ES2_label_bf13bc86:

    # MC "Well, I did exactly what you asked for. I got you the company name."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:33
translate chinese Zv2_ES2_label_85f6f72c:

    # Zuri "And you did excellently. We have already begun buying up shares, in order to assume a voting majority within the company."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:34
translate chinese Zv2_ES2_label_17d91eb8:

    # Suri "And we couldn’t have done it without your help."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:35
translate chinese Zv2_ES2_label_26569d30:

    # MC "Well... What’s the reward you have in mind?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:36
translate chinese Zv2_ES2_label_b0b7253e:

    # Zuri "Follow me. "
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:44
translate chinese Zv2_ES2_label_23e120ea:

    # Zuri "Suri is all yours tonight, [player_name]. Go ahead and play with her breasts."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:46
translate chinese Zv2_ES2_label_68d8b31b:

    # Suri "You can do whatever you want with my tits, [player_name]."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:47
translate chinese Zv2_ES2_label_5f5f47a3:

    # MC "(This is gonna be awesome!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:53
translate chinese Zv2_ES2_label_d58c6326:

    # Suri "So, what do you think, kid?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:55
translate chinese Zv2_ES2_label_2c3f979b:

    # Suri "So, what do you think, pal?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:56
translate chinese Zv2_ES2_label_c2a329e4:

    # MC "They’re amazing!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:57
translate chinese Zv2_ES2_label_efa951b6:

    # Suri "Hehe... I thought so."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:61
translate chinese Zv2_ES2_label_fafeb22f:

    # Suri "You want to play with them, don’t you?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:62
translate chinese Zv2_ES2_label_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:63
translate chinese Zv2_ES2_label_10b8d1ea:

    # Suri "They’re all yours. And there will be, much much more to come, if you give us more names."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:67
translate chinese Zv2_ES2_label_905acadb:

    # Suri "Now, let’s get started with your reward."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:68
translate chinese Zv2_ES2_label_e0fd6ce1:

    # Suri "Try to relax - don’t be shy."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:69
translate chinese Zv2_ES2_label_cfdf7417:

    # MC "(God! I wish I could fuck both of them at the same time! That would be the hottest thing ever!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:73
translate chinese Zv2_ES2_label_1365e2d5:

    # Suri "Ooh, I can feel your hard cock through your jeans. It seems like someone is getting excited by this!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:74
translate chinese Zv2_ES2_label_9f82186b:

    # MC "It’s hard not to get excited, when I’ve got a sexy girl like you on my lap."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:75
translate chinese Zv2_ES2_label_3e34699b:

    # Suri "Hehe! Okay, so what do you want to do to my titties?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:79
translate chinese Zv2_ES2_label_a2382cf5:

    # MC "I can do anything?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:81
translate chinese Zv2_ES2_label_b8703291:

    # Suri "Anything you want, kid."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:83
translate chinese Zv2_ES2_label_62689eff:

    # Suri "Anything you want, pal."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:84
translate chinese Zv2_ES2_label_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:97
translate chinese Zv2_ES2_menu_7621447b:

    # MC "(I think I’ll start by pinching and squeezing her nipples a bit.)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:98
translate chinese Zv2_ES2_menu_a60ce5c2:

    # Suri "Mmm, you naughty boy."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:99
translate chinese Zv2_ES2_menu_b1c9d332:

    # Suri "Do you like teasing my nipples like that?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:103
translate chinese Zv2_ES2_menu_0edf117d:

    # Suri "Oooh! That’s good...."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:105
translate chinese Zv2_ES2_menu_25d59f8f:

    # Zuri "My sister LOVES having her nipples played with. She can turn into a real slut if a guy turns her on enough."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:106
translate chinese Zv2_ES2_menu_37efe3c9:

    # Suri "Ignore her, kid. She’s just trying to embarrass me."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:108
translate chinese Zv2_ES2_menu_535b1bef:

    # Zuri "My partner LOVES having her nipples played with. She can turn into a real slut if a guy turns her on enough."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:109
translate chinese Zv2_ES2_menu_76f1aaee:

    # Suri "Ignore her, pal. She’s just trying to embarrass me."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:119
translate chinese Zv2_ES2_menu_b7b33907:

    # MC "(Let’s grope and squeeze Suri’s breasts!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:120
translate chinese Zv2_ES2_menu_b13b9b72:

    # MC "These are really soft, Suri!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:121
translate chinese Zv2_ES2_menu_c5ba390e:

    # Suri "Hehe. I know. Zuri likes to use them as a pillow, some nights."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:122
translate chinese Zv2_ES2_menu_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:126
translate chinese Zv2_ES2_menu_ae2011fc:

    # Zuri "SURI! That’s supposed to be a secret!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:127
translate chinese Zv2_ES2_menu_f3c848b7:

    # Suri "Oh, come on. You’ve done MUCH more to me than simply using my breasts as a pillow."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:128
translate chinese Zv2_ES2_menu_3a470961:

    # Zuri "*Sigh* That’s very true."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:129
translate chinese Zv2_ES2_menu_92951942:

    # MC "(These girls are total nymphos!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:139
translate chinese Zv2_ES2_menu_35fc745c:

    # MC "(Okay, let’s see how she likes it when I suck on her nipples.)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:140
translate chinese Zv2_ES2_menu_f33aedd6:

    # Suri "Ooooh! Hehe! That really tickles!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:141
translate chinese Zv2_ES2_menu_f600c631:

    # Zuri "Don’t be afraid to bite a little with your teeth. She’s kinky like that!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:142
translate chinese Zv2_ES2_menu_30bad7ed:

    # Suri "Zuri! Stop it! Hehe!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:146
translate chinese Zv2_ES2_menu_faad3775:

    # Suri "Oooh! Ahhh! Oh, my God! Mmm!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:147
translate chinese Zv2_ES2_menu_c9fc2b71:

    # MC "*Suck suck!*"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:148
translate chinese Zv2_ES2_menu_5ca78cfc:

    # Suri "Ooohhh...."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:159
translate chinese Zv2_ES2_continue_9631c2b0:

    # Zuri "(The fuck is she doing...?)"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:160
translate chinese Zv2_ES2_continue_85501078:

    # Zuri "Oh, come on, Suri. You’re not seducing him at all!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:161
translate chinese Zv2_ES2_continue_f6050b5b:

    # Suri "I’m trying, Zuri!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:163
translate chinese Zv2_ES2_continue_6701f971:

    # Zuri "Please, you’re acting like a mom with her child! Let me help."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:165
translate chinese Zv2_ES2_continue_443a4ab3:

    # Zuri "Please... Your technique is pathetic! Let me help. "
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:169
translate chinese Zv2_ES2_continue_69cebba7:

    # Suri "Hey! I had this!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:170
translate chinese Zv2_ES2_continue_3c311a4d:

    # Zuri "SURE you did - I’m just here to give you a hand."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:171
translate chinese Zv2_ES2_continue_25372ed4:

    # Suri "Ugh! Fine..."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:175
translate chinese Zv2_ES2_continue_7c262d04:

    # Zuri "I was able to get us the first name. If we work together, I’m sure we can convince [player_name] to give us some more."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:176
translate chinese Zv2_ES2_continue_596e0704:

    # Suri "Ahh... yes!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:181
translate chinese Zv2_ES2_continue_776dae75:

    # Suri "So, what do you say, kid?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:183
translate chinese Zv2_ES2_continue_d4f6ff7e:

    # Suri "So, what do you say, pal?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:184
translate chinese Zv2_ES2_continue_e25f74ae:

    # Suri "Next time you get us a company name, you’ll get to enjoy both of us at the same time. How does that sound?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:185
translate chinese Zv2_ES2_continue_7fb0b22f:

    # MC "Fucking amazing!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:186
translate chinese Zv2_ES2_continue_c9ef3e60:

    # Zuri "I thought so too."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:190
translate chinese Zv2_ES2_continue_b7de8e81:

    # Zuri "I have to promise you - you are in for a night you will NEVER forget."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:191
translate chinese Zv2_ES2_continue_638e5209:

    # Suri "All you have to do is get us that name."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:193
translate chinese Zv2_ES2_continue_c333d7e9:

    # Suri "And then we’ll suck and fuck your brains out, kid."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:195
translate chinese Zv2_ES2_continue_d42084a7:

    # Suri "And then we’ll suck and fuck your brains out, pal."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:199
translate chinese Zv2_ES2_continue_9e753d86:

    # Zuri "Do we have a deal?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:200
translate chinese Zv2_ES2_continue_0600e471:

    # MC "(God... They’re irresistible!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:201
translate chinese Zv2_ES2_continue_d400b2f8:

    # MC "Hell yeah..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:202
translate chinese Zv2_ES2_continue_ef6f07f6:

    # Zuri "That’s what we like to hear!"
    Zuri ""

translate chinese strings:

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:93
    old "Pinch her nipples."
    new ""

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:93
    old "Grope her breasts."
    new ""

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES2.rpy:93
    old "Suck on her nipples."
    new ""

