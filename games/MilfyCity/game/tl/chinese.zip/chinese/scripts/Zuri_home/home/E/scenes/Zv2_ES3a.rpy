﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:31
translate chinese Zv2_ES3a_label_8ea7df0f:

    # Zuri "Welcome back, [player_name]."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:32
translate chinese Zv2_ES3a_label_94769793:

    # Zuri "Thanks again for your help! Let’s go to our - room of pleasure."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:40
translate chinese Zv2_ES3a_label_2ceb05d6:

    # Zuri "You’ve done another excellent job for us."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:42
translate chinese Zv2_ES3a_label_ee0f969d:

    # Suri "Yeah, you really came through, kid. You’re gonna make us super rich!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:44
translate chinese Zv2_ES3a_label_96a274eb:

    # Suri "Yeah, you really came through, pal. You’re gonna make us super rich!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:45
translate chinese Zv2_ES3a_label_4e1fad0f:

    # MC "I get another reward now, right?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:46
translate chinese Zv2_ES3a_label_c22e842c:

    # Suri "Hehe... You do. I believe we promised you a blowjob."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:51
translate chinese Zv2_ES3a_label_a5dfc68c:

    # Suri "Mmm, I can’t wait to suck on his cock. It looked sooo delicious, last time we did it!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:52
translate chinese Zv2_ES3a_label_662924ae:

    # Zuri "Well? What are we waiting for? Let’s get these pants off him."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:53
translate chinese Zv2_ES3a_label_24ffa1d3:

    # MC "(This is gonna be great!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:57
translate chinese Zv2_ES3a_label_e1e75030:

    # Suri "So, which of us gets to suck it first?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:58
translate chinese Zv2_ES3a_label_0520c2f1:

    # MC "I’m not fussy!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:59
translate chinese Zv2_ES3a_label_8d735901:

    # Zuri "Be my guest, Suri!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:63
translate chinese Zv2_ES3a_label_85aa98a0:

    # Zuri "If you enjoy us doing this, then just wait till you see what we have in store for you, for the grand finale!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:64
translate chinese Zv2_ES3a_label_58168956:

    # Suri "Yeah, we’ll blow your cock today, but next time - we’ll blow your mind!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:68
translate chinese Zv2_ES3a_label_7f56b20a:

    # Suri "Are you always this hard, kid?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:70
translate chinese Zv2_ES3a_label_e460abf1:

    # Suri "Are you always this hard, pal?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:71
translate chinese Zv2_ES3a_label_dfa3538d:

    # Suri "I don't think I've ever seen you without a massive erection!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:72
translate chinese Zv2_ES3a_label_c18a7f20:

    # MC "It’s hard not to have one, when I’m near someone as beautiful as you."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:76
translate chinese Zv2_ES3a_label_703977fc:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:77
translate chinese Zv2_ES3a_label_619d9b75:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:78
translate chinese Zv2_ES3a_label_f2e8de7c:

    # MC "Mmm... That’s good. RIght there..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:82
translate chinese Zv2_ES3a_label_fe9e5f00:

    # Suri "*Suuuuck*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:83
translate chinese Zv2_ES3a_label_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:84
translate chinese Zv2_ES3a_label_826cf9ed:

    # MC "(I can feel Suri’s mouth, wrapped around the tip of my cock. It’s so hot and wet!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:88
translate chinese Zv2_ES3a_label_8aebcbb8:

    # MC "God... Mmmm..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:90
translate chinese Zv2_ES3a_label_619d9b75_1:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:92
translate chinese Zv2_ES3a_label_dd163d14:

    # Suri "*Shluuurrrp*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:96
translate chinese Zv2_ES3a_label_975cd7e9:

    # MC "(This is too much! Their tongues are so good!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:97
translate chinese Zv2_ES3a_label_f9b52d56:

    # MC "(Who knew, corporate espionage could feel so right?)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:98
translate chinese Zv2_ES3a_label_6e28ed50:

    # Zuri "Mmmm..."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:99
translate chinese Zv2_ES3a_label_703977fc_1:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:103
translate chinese Zv2_ES3a_label_e5cdb1e6:

    # Zuri "*Suck Suck*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:106
translate chinese Zv2_ES3a_label_ea2be631:

    # MC "(Damn, Zuri is just as good at sucking cock, as her twin sister is!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:108
translate chinese Zv2_ES3a_label_3a5fe5b2:

    # MC "(Damn, Zuri is just as good at sucking cock as Suri!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:109
translate chinese Zv2_ES3a_label_df1e2b98:

    # MC "(The two of them together, are fucking incredible!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:113
translate chinese Zv2_ES3a_label_0ba9371f:

    # Zuri "*GULP*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:114
translate chinese Zv2_ES3a_label_634d50a1:

    # MC "Fuck! Mmm!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:115
translate chinese Zv2_ES3a_label_259ca6cf:

    # MC "(I can feel Zuri’s tight throat around my glans!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:119
translate chinese Zv2_ES3a_label_9da31cb4:

    # MC "(If she keeps this up, I’m gonna cum! It’s too intense!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:120
translate chinese Zv2_ES3a_label_a8a8b750:

    # MC "Hnnng! Ahh!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:121
translate chinese Zv2_ES3a_label_a267a93e:

    # Zuri "*Shluuuuuurrrrp*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:125
translate chinese Zv2_ES3a_label_58b6bc32:

    # Suri "MMPPFFF!!!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:126
translate chinese Zv2_ES3a_label_cc37b6d2:

    # Zuri "Oops! Sorry, Suri!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:127
translate chinese Zv2_ES3a_label_1aa0401f:

    # MC "Ahhh! Huh?"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:131
translate chinese Zv2_ES3a_label_d7996665:

    # Zuri "Sorry, it looks like my sister’s head has... accidentally fallen on your cock."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:133
translate chinese Zv2_ES3a_label_4453a5b4:

    # Zuri "Sorry, it looks like Suri’s head has accidentally fallen on your cock."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:134
translate chinese Zv2_ES3a_label_1b5ee3e8:

    # Suri "Mmmpfff! *SHLURRRRP*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:135
translate chinese Zv2_ES3a_label_be8fb162:

    # MC "Oh! Ahhhh!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:139
translate chinese Zv2_ES3a_label_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:140
translate chinese Zv2_ES3a_label_e519e8a9:

    # Zuri "Drink it ALL up, Suri!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:141
translate chinese Zv2_ES3a_label_6ad09894:

    # Suri "*SHLURRRP!* COUGH!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:142
translate chinese Zv2_ES3a_label_13deecc1:

    # MC "HNNNNNGGG!!! UGH! YES!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:150
translate chinese Zv2_ES3a_label_4d81992e:

    # MC "(I can feel my cock twitching in her mouth! She’s drinking me dry!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:154
translate chinese Zv2_ES3a_label_9ca5634d:

    # MC "Wow... That was amazing..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:155
translate chinese Zv2_ES3a_label_c7377f31:

    # Suri "Zuri! You naughty bitch!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:156
translate chinese Zv2_ES3a_label_42702283:

    # Zuri "Hehe! I couldn’t resist!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:157
translate chinese Zv2_ES3a_label_de249513:

    # Suri "I’m gonna have to spank you later on tonight, for that!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3a.rpy:158
translate chinese Zv2_ES3a_label_51240ede:

    # Zuri "Feel free to go now, [player_name]."
    Zuri ""

