﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:50
translate chinese Zv2_ES3_label_8ea7df0f:

    # Zuri "Welcome back, [player_name]."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:52
translate chinese Zv2_ES3_label_846a0e33:

    # Suri "It’s good to see you again, kid."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:54
translate chinese Zv2_ES3_label_d3f07b92:

    # Suri "It’s good to see you again, pal."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:55
translate chinese Zv2_ES3_label_0bb677d8:

    # MC "I’m glad to see you too."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:56
translate chinese Zv2_ES3_label_21c74d28:

    # Zuri "Thanks again for your help with the company name. We’ll both make sure you are adequately rewarded."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:57
translate chinese Zv2_ES3_label_9d94c452:

    # Suri "How about we head into the back room and get this party started?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:65
translate chinese Zv2_ES3_label_fc4e5adb:

    # Suri "So, what were you thinking?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:66
translate chinese Zv2_ES3_label_ff53ccdf:

    # Zuri "We could give you a footjob."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:67
translate chinese Zv2_ES3_label_f31899b8:

    # Suri "Or we could lick your cock until you cum."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:73
translate chinese Zv2_ES3_label_09eea99a:

    # MC "I’d love to see the two of you lick my cock."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:78
translate chinese Zv2_ES3_label_6ba5d9ee:

    # Suri "Is that so, kid?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:80
translate chinese Zv2_ES3_label_e4ce1190:

    # Suri "Is that so, pal?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:81
translate chinese Zv2_ES3_label_61f28a82:

    # Zuri "I imagine you must enjoy the sight of two pretty girls, on their knees before you."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:82
translate chinese Zv2_ES3_label_a3105d90:

    # Zuri "Let’s get these jeans undone."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:86
translate chinese Zv2_ES3_label_14b45453:

    # MC "(This is gonna be awesome! Double blowjobs are incredible!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:87
translate chinese Zv2_ES3_label_bcbc0ce4:

    # Zuri "Now, we’re only going to lick you today. But if you get us more names, we can certainly think about giving you a proper sucking. Deal?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:88
translate chinese Zv2_ES3_label_8ce16276:

    # MC "Yeah, deal."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:92
translate chinese Zv2_ES3_label_f01ea8fc:

    # Zuri "Wow! It’s pretty big, Suri!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:95
translate chinese Zv2_ES3_label_a78a58d6:

    # Suri "This kid surprises me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:96
translate chinese Zv2_ES3_label_f1501b47:

    # MC "(God, why am I just letting them do this? They’re seducing me into ruining Dad’s company!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:98
translate chinese Zv2_ES3_label_c8024b95:

    # Suri "TThis guy surprises me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:99
translate chinese Zv2_ES3_label_35777e6d:

    # MC "(God, why am I just letting them do this? They’re seducing me into ruining Bob’s company!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:102
translate chinese Zv2_ES3_label_e03c586b:

    # MC "(I have to make a stand and say “No more”.)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:103
translate chinese Zv2_ES3_label_716220ff:

    # Zuri "It’s sooo thick too!"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:104
translate chinese Zv2_ES3_label_c79d1eca:

    # Suri "That would feel REALLY good inside me!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:108
translate chinese Zv2_ES3_label_320f6fbe:

    # MC "Oooh...."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:109
translate chinese Zv2_ES3_label_703977fc:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:110
translate chinese Zv2_ES3_label_619d9b75:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:114
translate chinese Zv2_ES3_label_7a9a6a9c:

    # MC "(On the other hand, maybe Dad’s company isn’t worth a blowjob THIS good!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:116
translate chinese Zv2_ES3_label_60b13944:

    # MC "(On the other hand, maybe Bob’s company isn’t worth a blowjob THIS good!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:117
translate chinese Zv2_ES3_label_703977fc_1:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:118
translate chinese Zv2_ES3_label_7d757fa8:

    # MC "(They’re teasing every inch of my dick! I’ll be cumming in no time!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:122
translate chinese Zv2_ES3_label_029f09cf:

    # Zuri "*Lick! Slurp!*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:123
translate chinese Zv2_ES3_label_061b6594:

    # MC "Ahh... Ohh..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:124
translate chinese Zv2_ES3_label_e3dde0db:

    # Suri "*Lick! Lick!*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:128
translate chinese Zv2_ES3_label_92e767ac:

    # MC "(God, her eyes are stunning!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:130
translate chinese Zv2_ES3_label_fc220e33:

    # MC "(The way she looks at me while she licks my cock, is heart-melting!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:134
translate chinese Zv2_ES3_label_ce40556e:

    # Suri "*Suck! Shlurp! Suck!*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:135
translate chinese Zv2_ES3_label_9e77a3f1:

    # Zuri "*Suck Suck!*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:136
translate chinese Zv2_ES3_label_31314dae:

    # MC "Ooohhh God! Mmmmm!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:140
translate chinese Zv2_ES3_label_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:142
translate chinese Zv2_ES3_label_408b41bc:

    # Zuri "*Shluuuurrrrp!*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:143
translate chinese Zv2_ES3_label_848628b1:

    # Suri "*SUCK SUCK!*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:147
translate chinese Zv2_ES3_label_14d24d01:

    # MC "Hnnnng!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:148
translate chinese Zv2_ES3_label_77225479:

    # MC "I’m gonna cum! It’s too intense! AHHHH!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:150
translate chinese Zv2_ES3_label_546f9a94:

    # Suri "*SHLURP! SUCK SUCK!*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:155
translate chinese Zv2_ES3_label_cbfecc66:

    # MC "I’m cumming! Hnnnnggg!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:156
translate chinese Zv2_ES3_label_703977fc_2:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:157
translate chinese Zv2_ES3_label_619d9b75_1:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:166
translate chinese Zv2_ES3_label_43a06055:

    # MC "AYAAAAAHHHHH!!!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:167
translate chinese Zv2_ES3_label_49b5500c:

    # MC "Oh God..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:168
translate chinese Zv2_ES3_label_7fd86971:

    # Suri "Mmm... Salty!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:172
translate chinese Zv2_ES3_label_c48a9090:

    # Zuri "You’ve seen what we can do now. How about you get us that third name?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:173
translate chinese Zv2_ES3_label_1830a4fb:

    # Suri "Yeah, if you do that we’ll take your WHOLE cock in our mouths. Sound good?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:174
translate chinese Zv2_ES3_label_faa6f0f7:

    # MC "Absolutely! You girls are incredible!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:191
translate chinese Zv2_ES3_label_c96d59b1:

    # MC "I’ll go for the footjob."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:192
translate chinese Zv2_ES3_label_9c193590:

    # Zuri "Mmm... Good choice. Go ahead and take your trousers off, then lie back on the bed."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:196
translate chinese Zv2_ES3_label_3cbb8f41:

    # Suri "His cock is so big, Zuri! Hehe!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:197
translate chinese Zv2_ES3_label_04dddf1e:

    # Zuri "It REALLY is! I hope he’s going to enjoy us rubbing our feet ALL over it."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:199
translate chinese Zv2_ES3_label_7b181785:

    # MC "(Twins rubbing their feet over my cock? It’s my lucky day!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:201
translate chinese Zv2_ES3_label_34b3541c:

    # MC "(Two girls rubbing their feet over my cock? It’s my lucky day!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:206
translate chinese Zv2_ES3_label_e3a07d04:

    # Suri "And here we go. Hehe! I can feel it twitching beneath my toes!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:208
translate chinese Zv2_ES3_label_482a2537:

    # Suri "I think he’s enjoying this!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:209
translate chinese Zv2_ES3_label_ec1c995b:

    # MC "Mmm! Oh yeah..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:214
translate chinese Zv2_ES3_label_605760d3:

    # Zuri "There’s going to be MANY more things we can do for you. "
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:215
translate chinese Zv2_ES3_label_c84a8a0f:

    # Suri "We can give you sooo much pleasure."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:216
translate chinese Zv2_ES3_label_4ed66755:

    # Zuri "And the only thing you have to do, is lie back and enjoy it."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:220
translate chinese Zv2_ES3_label_73049590:

    # MC "Mmm! Ah..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:222
translate chinese Zv2_ES3_label_862ead3e:

    # MC "(This feels so fucking good...)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:223
translate chinese Zv2_ES3_label_b57afe7c:

    # Suri "Maybe we’ll even let you fuck our pussies someday."
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:227
translate chinese Zv2_ES3_label_25db98a6:

    # Zuri "And the only thing you need to do - to keep earning these rewards - is get us those names."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:228
translate chinese Zv2_ES3_label_d4a1a6dc:

    # Zuri "Simple, right?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:229
translate chinese Zv2_ES3_label_80e3caf3:

    # MC "Ah... uh huh..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:233
translate chinese Zv2_ES3_label_90fab4dc:

    # Suri "What’s wrong, kid? Would you like us to go faster?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:235
translate chinese Zv2_ES3_label_0f2a9d67:

    # Suri "What’s wrong, pal? Would you like us to go faster?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:237
translate chinese Zv2_ES3_label_76f21560:

    # MC "God yes!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:238
translate chinese Zv2_ES3_label_fdcbcfd4:

    # Zuri "Let’s speed things up, Suri."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:242
translate chinese Zv2_ES3_label_2b3f583a:

    # MC "Ooh! God... That’s amazing..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:244
translate chinese Zv2_ES3_label_6bd7cea4:

    # MC "(I shouldn’t be doing this to Dad’s company... but they’re so fucking sexy...)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:246
translate chinese Zv2_ES3_label_36c414ff:

    # MC "(I shouldn’t be doing this to Bob’s company... but they’re so fucking sexy...)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:247
translate chinese Zv2_ES3_label_b46540b1:

    # MC "(My cock is so hard right now!)"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:251
translate chinese Zv2_ES3_label_f4473d30:

    # MC "AH! Ahhh!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:253
translate chinese Zv2_ES3_label_67a30b90:

    # Suri "Sounds like this kid isn’t gonna last much longer!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:255
translate chinese Zv2_ES3_label_866080cb:

    # Suri "Sounds like this guy isn’t gonna last much longer!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:256
translate chinese Zv2_ES3_label_8bd4b9c5:

    # Zuri "Aww, what a shame."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:261
translate chinese Zv2_ES3_label_e50d7037:

    # Suri "Are you gonna cum, kid?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:263
translate chinese Zv2_ES3_label_542994e9:

    # Suri "Are you gonna cum, pal?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:264
translate chinese Zv2_ES3_label_8d81c052:

    # Zuri "Yeah, are you gonna cum all over our feet?"
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:265
translate chinese Zv2_ES3_label_7e167dcc:

    # MC "Mmmm! Ahhh..."
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:269
translate chinese Zv2_ES3_label_39da96e9:

    # MC "Fuck! I’m cumming!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:270
translate chinese Zv2_ES3_label_a22443d9:

    # MC "Hnnnnnngggg!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:271
translate chinese Zv2_ES3_label_d27690de:

    # Suri "That’s it, cum for me! Cum for me now!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:275
translate chinese Zv2_ES3_label_0bd7c4d4:

    # Suri "Squirt your cum all over my toes!"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:276
translate chinese Zv2_ES3_label_cb559623:

    # MC "AHH! AHHHHHH!"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:285
translate chinese Zv2_ES3_label_c469efae:

    # MC "Oooh.... *Pant Pant*"
    MC ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:287
translate chinese Zv2_ES3_label_8e9728d9:

    # Zuri "Wow! That’s A LOT of cum, kid."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:288
translate chinese Zv2_ES3_label_61940e2e:

    # Suri "We can do this again, kid. All you have to do is get us more names. Okay?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:290
translate chinese Zv2_ES3_label_c83fee11:

    # Zuri "Wow! That’s A LOT of cum, pal."
    Zuri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:291
translate chinese Zv2_ES3_label_b0cb966f:

    # Suri "We can do this again, pal. All you have to do is get us more names. Okay?"
    Suri ""

# game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:292
translate chinese Zv2_ES3_label_98da0aa8:

    # MC "*Pant* Y-Yeah, okay..."
    MC ""

translate chinese strings:

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:69
    old "Can you lick my cock?"
    new ""

    # game/scripts/Zuri_home/home/E/scenes/Zv2_ES3.rpy:69
    old "Could you give me a footjob?"
    new ""

