﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:36
translate chinese Z_ES1_label_7c6494f0:

    # MC "(Well, this looks like the place. It’s a REALLY nice house!)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:38
translate chinese Z_ES1_label_d75e1941:

    # MC "(I wonder if this was a date. Zuri did seem kinda flirty with me, every time I went to visit Dad.)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:40
translate chinese Z_ES1_label_75df82cc:

    # MC "(I wonder if this was a date. Zuri did seem kinda flirty with me, every time I went to visit Bob.)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:41
translate chinese Z_ES1_label_d08d417a:

    # MC "(Maybe I’m just overthinking things right now.)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:44
translate chinese Z_ES1_label_98fe1475:

    # "*KNOCK KNOCK KNOCK*"
    ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:47
translate chinese Z_ES1_label_c6671f4e:

    # Zuri "COOOOOMMMIINNGGGGGGGG!"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:54
translate chinese Z_ES1_label_02faddc1:

    # Zuri "Oh! Hey! Is that you!?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:55
translate chinese Z_ES1_label_d8b99a15:

    # MC "(Holy shit! She’s almost naked!)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:56
translate chinese Z_ES1_label_54a5bc31:

    # MC "I- Uh- Hi-"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:57
translate chinese Z_ES1_label_c4aea247:

    # Zuri "Well, what are you waiting for? Come on in? Just don’t stand out there like a big dumbo!"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:61
translate chinese Z_ES1_label_8cfee184:

    # Zuri "What’s wrong? You look shell-shocked, kid."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:63
translate chinese Z_ES1_label_5c1d258a:

    # Zuri "What’s wrong? You look shell-shocked, pal."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:64
translate chinese Z_ES1_label_3752f111:

    # MC "Y-You’re... bottoms... You’re.."
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:66
translate chinese Z_ES1_label_cba2c1cb:

    # Zuri "What’s wrong, kid? You’re stammering on me."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:68
translate chinese Z_ES1_label_d2e586dd:

    # Zuri "What’s wrong, pal? You’re stammering on me."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:69
translate chinese Z_ES1_label_e738b4fd:

    # MC "You’ve got... bottom..."
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:73
translate chinese Z_ES1_label_799c9dcf:

    # Zuri "Is there something on me?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:74
translate chinese Z_ES1_label_63b89334:

    # MC "You’re only wearing panties!"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:75
translate chinese Z_ES1_label_f65e0f22:

    # Zuri "What do you mean?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:79
translate chinese Z_ES1_label_64dc21ba:

    # MC "I... uh (Jesus! Why am I so nervous right now!)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:80
translate chinese Z_ES1_label_d3cbc940:

    # MC "(Why is Zuri acting so weird! She’s NEVER like this in the office!)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:81
translate chinese Z_ES1_label_349f3872:

    # Zuri "I don’t see anything down me."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:85
translate chinese Z_ES1_label_d73125a4:

    # Zuri "Oooh! Are you just shocked that I’m only wearing panties?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:86
translate chinese Z_ES1_label_a6fbf3fc:

    # MC "Y-Yes!"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:87
translate chinese Z_ES1_label_bab9750d:

    # Zuri "Haha! How cute! Are you a virgin, or something?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:88
translate chinese Z_ES1_label_2c9a62fe:

    # MC "Wh-What?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:89
translate chinese Z_ES1_label_4dd0bc22:

    # Zuri "Go ahead and take a seat on the couch."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:109
translate chinese Z_ES1_q2_label_0072bd0e:

    # MC "So, uh... You wanted me to come over tonight?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:110
translate chinese Z_ES1_q2_label_fabcffa6:

    # MC "What did you, um... plan to do? Dinner? Or a movie?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:112
translate chinese Z_ES1_q2_label_1f3208ea:

    # Zuri "You talk a lot, kid."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:114
translate chinese Z_ES1_q2_label_35b4575b:

    # Zuri "You talk a lot, pal."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:118
translate chinese Z_ES1_q2_label_8d5271fc:

    # Zuri "Just breathe and try to relax. You’re making ME feel nervous now."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:119
translate chinese Z_ES1_q2_label_e7bd8086:

    # Zuri "Have you never seen a girl dressed like a slut before?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:120
translate chinese Z_ES1_q2_label_825ceef3:

    # MC "Y-Yes. I mean..."
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:124
translate chinese Z_ES1_q2_label_134143d7:

    # Zuri "Then you shouldn’t be this nervous around me."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:125
translate chinese Z_ES1_q2_label_3b6a5657:

    # Zuri "Now go and sit on the couch."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:139
translate chinese Z_ES1_q1_label_e61a0026:

    # MC "(What the hell is going on?)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:140
translate chinese Z_ES1_q1_label_e8985e56:

    # MC "(Zuri isn’t acting like herself, at all. And I have NO idea what she even invited me over here for.)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:141
translate chinese Z_ES1_q1_label_42177649:

    # MC "(She’s dressed really scantily, so perhaps she wants to have sex?)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:145
translate chinese Z_ES1_q1_label_5542acb6:

    # Zuri "Ahh, there you are."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:146
translate chinese Z_ES1_q1_label_08a197b4:

    # MC "Wow! You got dressed quickly!"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:147
translate chinese Z_ES1_q1_label_773b3cd9:

    # Zuri "Hmm?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:151
translate chinese Z_ES1_q1_label_ca1810d8:

    # MC "You really scared me when you opened the front door, almost naked!"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:152
translate chinese Z_ES1_q1_label_f216fbdb:

    # Zuri "Uh huh..."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:153
translate chinese Z_ES1_q1_label_17bbc33f:

    # MC "Seriously, what if it wasn’t me? What if it was like the postman or someone?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:157
translate chinese Z_ES1_q1_label_016859d1:

    # Zuri "I didn’t open the door for you."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:158
translate chinese Z_ES1_q1_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:159
translate chinese Z_ES1_q1_label_e30e7a2b:

    # Zuri "And I’ve been wearing these clothes all night."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:160
translate chinese Z_ES1_q1_label_8f23d90c:

    # MC "Then who-"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:164
translate chinese Z_ES1_q1_label_b199e456:

    # Suri "Boo!"
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:165
translate chinese Z_ES1_q1_label_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:167
translate chinese Z_ES1_q1_label_eba04b21:

    # Zuri "[player_name], meet my twin sister, Suri."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:169
translate chinese Z_ES1_q1_label_7267eac8:

    # Zuri "[player_name], meet my partner, Suri."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:172
translate chinese Z_ES1_q1_label_a7621493:

    # Suri "Sorry I didn’t tell you earlier. I just couldn’t resist, winding you up a bit."
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:176
translate chinese Z_ES1_q1_label_37c12b3b:

    # MC "There’s two of you?!"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:178
translate chinese Z_ES1_q1_label_8b87aabd:

    # Zuri "Oh yes. Suri doesn’t work at your dad’s company though."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:180
translate chinese Z_ES1_q1_label_ffb0aa91:

    # Zuri "Oh yes. Suri doesn’t work at Bob’s company though."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:181
translate chinese Z_ES1_q1_label_db53d3ee:

    # MC "Why did you want me to come over tonight, then?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:185
translate chinese Z_ES1_q1_label_752b5d4c:

    # Zuri "This isn’t a date. I’m sure you know that much by now."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:187
translate chinese Z_ES1_q1_label_4b14051b:

    # Zuri "It’s a business proposition. Your father is currently building an investment portfolio of very wealthy companies. If he acquires a majority of their shares, his company could be set to earn millions."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:189
translate chinese Z_ES1_q1_label_d8bb8db7:

    # Zuri "It’s a business proposition. Bob is currently building an investment portfolio of very wealthy companies. If he acquires a majority of their shares, his company could be set to earn millions."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:190
translate chinese Z_ES1_q1_label_9870d4a5:

    # Zuri "This is where you come in."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:194
translate chinese Z_ES1_q1_label_38c7efe6:

    # Suri "We want you to get us the company names."
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:196
translate chinese Z_ES1_q1_label_5e0a0d97:

    # MC "Wh-Why would I do that? Wouldn’t that hurt my dad’s company?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:198
translate chinese Z_ES1_q1_label_44eecc62:

    # MC "Wh-Why would I do that? Wouldn’t that hurt Bob’s company?"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:199
translate chinese Z_ES1_q1_label_42033a5e:

    # Suri "Of course! Big time!"
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:200
translate chinese Z_ES1_q1_label_f1602b4b:

    # Suri "But we’re offering you something REALLY fun."
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:204
translate chinese Z_ES1_q1_label_8c7b6846:

    # Zuri "This may be the ONLY time in your life you will ever be with twins."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:206
translate chinese Z_ES1_q1_label_d41b2fba:

    # Zuri "This may be the ONLY time in your life you will ever be with two women at the SAME TIME."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:207
translate chinese Z_ES1_q1_label_fd38260e:

    # Zuri "That’s right. For every company name you give us, we’ll give you some sexual rewards."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:208
translate chinese Z_ES1_q1_label_eb005aaf:

    # Zuri "How does that sound?"
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:209
translate chinese Z_ES1_q1_label_c167e952:

    # MC "(Holy shit... I’m so conflicted right now.)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:213
translate chinese Z_ES1_q1_label_2b0498d6:

    # Zuri "I’ll leave you alone now to make up your mind."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:214
translate chinese Z_ES1_q1_label_9315253f:

    # Zuri "In the meantime, I’m sure that Suri can... help convince you of the right decision."
    Zuri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:216
translate chinese Z_ES1_q1_label_2480a933:

    # Suri "I certainly can, Sis."
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:218
translate chinese Z_ES1_q1_label_61d2d866:

    # Suri "I certainly can."
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:222
translate chinese Z_ES1_q1_label_75efb5f2:

    # Suri "This is just a taste of what will come if you help us."
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:223
translate chinese Z_ES1_q1_label_5635cfb7:

    # Suri "What do you say?"
    Suri ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:224
translate chinese Z_ES1_q1_label_22dae5bb:

    # MC "(Wow! Those tits are amazing!)"
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:225
translate chinese Z_ES1_q1_label_4f497db3:

    # MC "I... uh..."
    MC ""

# game/scripts/Zuri_home/outside/E/scenes/Zv2_ES1.rpy:226
translate chinese Z_ES1_q1_label_c4c98751:

    # Suri "Take some time to think about it. Then speak with Zuri when you’re ready to make a decision."
    Suri ""

