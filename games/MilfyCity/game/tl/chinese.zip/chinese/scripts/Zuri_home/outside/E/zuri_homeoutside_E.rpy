﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/outside/E/zuri_homeoutside_E.rpy:41
translate chinese Z_home_doorknock_E_label_abd715bd:

    # Zuri "Doors are open! Come inside!"
    Zuri ""

# game/scripts/Zuri_home/outside/E/zuri_homeoutside_E.rpy:49
translate chinese Z_home_doorknock_E_label_673491de:

    # MC "(Hmm.. I guess there’s no one inside.)"
    MC ""

