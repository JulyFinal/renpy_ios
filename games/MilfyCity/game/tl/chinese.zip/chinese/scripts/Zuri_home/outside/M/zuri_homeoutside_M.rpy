﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Zuri_home/outside/M/zuri_homeoutside_M.rpy:14
translate chinese zuri_homeoutside_M1_cf66c46a:

    # MC "(It’s too late.)"
    MC ""

# game/scripts/Zuri_home/outside/M/zuri_homeoutside_M.rpy:67
translate chinese Z_home_doorlocked_M_label_673491de:

    # MC "(Hmm.. I guess there’s no one inside.)"
    MC ""

