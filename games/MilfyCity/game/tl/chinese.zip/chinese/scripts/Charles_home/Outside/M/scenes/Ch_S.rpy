﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:44
translate chinese Ch_doors_lab_b5862e2e:

    # MC "(Okay, here goes nothing...)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:46
translate chinese Ch_doors_lab_4075fb47:

    # MC "*Knock Knock*"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:48
translate chinese Ch_doors_lab_5f9b772e:

    # "...."
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:49
translate chinese Ch_doors_lab_b70780d2:

    # MC "(Hmm, nobody seems to be answering.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:59
translate chinese Ch_doors_lab_b5862e2e_1:

    # MC "(Okay, here goes nothing...)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:61
translate chinese Ch_doors_lab_4075fb47_1:

    # MC "*Knock Knock*"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:63
translate chinese Ch_doors_lab_5f9b772e_1:

    # "...."
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:64
translate chinese Ch_doors_lab_b70780d2_1:

    # MC "(Hmm, nobody seems to be answering.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:74
translate chinese Ch_doors_lab_bea6c43b:

    # MC "(I wonder if Charles will be around in the evening.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:76
translate chinese Ch_doors_lab_4075fb47_2:

    # MC "*Knock Knock*"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:78
translate chinese Ch_doors_lab_c6cf4d2f:

    # MC "(Still no answer. Bugger.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:88
translate chinese Ch_doors_lab_e0a43d80:

    # MC "(I can understand Charles not being here during the day. Perhaps he’s at work. But if he isn’t answering now, I have no idea what is going on!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:90
translate chinese Ch_doors_lab_4075fb47_3:

    # MC "*Knock Knock*"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:92
translate chinese Ch_doors_lab_a20cefa7:

    # "..."
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:93
translate chinese Ch_doors_lab_df67c2ae:

    # MC "Goddammit!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:112
translate chinese Ch_window_lab_ebea3e7c:

    # MC "(Let’s give this window a go. Maybe I can jimmy it open?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:113
translate chinese Ch_window_lab_18efd262:

    # MC "Ugh... Gah!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:114
translate chinese Ch_window_lab_84f1ef31:

    # MC "(Nope, this thing isn’t budging a single inch! Perhaps I should come back later on in the day?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:124
translate chinese Ch_window_lab_ebea3e7c_1:

    # MC "(Let’s give this window a go. Maybe I can jimmy it open?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:125
translate chinese Ch_window_lab_18efd262_1:

    # MC "Ugh... Gah!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:126
translate chinese Ch_window_lab_84f1ef31_1:

    # MC "(Nope, this thing isn’t budging a single inch! Perhaps I should come back later on in the day?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:136
translate chinese Ch_window_lab_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:137
translate chinese Ch_window_lab_20e2f914:

    # MC "(Dammit, the window isn’t shifting. Maybe I should try another time of the day?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:149
translate chinese Ch_window_lab_d1a0c2fc:

    # MC "(If you’re not going to let me in, then I’ll just have to make an entrance myself!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:150
translate chinese Ch_window_lab_433bd8d6:

    # MC "Hnnnng... Come on!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:151
translate chinese Ch_window_lab_d89e2497:

    # MC "Ugh! (Just a few more inches!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:161
translate chinese Ch_window_lab_22146f33:

    # MC "(Please be open!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:162
translate chinese Ch_window_lab_e771924b:

    # MC "Gah! Come on!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:163
translate chinese Ch_window_lab_ed4b3200:

    # MC "Let me in Charles! Open up the door, you bastard!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:166
translate chinese Ch_window_lab_a4095d50:

    # MC "(There must be a way to reach this window. Perhaps I should use the crowbar. I believe I saw one in the garage.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:207
translate chinese Ch_inside_lab_74e6f621:

    # "*CRACK*"
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:208
translate chinese Ch_inside_lab_3d2bc4b3:

    # MC "Yes!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:209
translate chinese Ch_inside_lab_94d4fcd1:

    # MC "(I’m gonna get you now, you bastard!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:212
translate chinese Ch_inside_lab_10fb8a4e:

    # Television "Suck my fucking cock, you whore!"
    Television ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:213
translate chinese Ch_inside_lab_012c674a:

    # Charles "Ugh... Yeah... Mmm..."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:214
translate chinese Ch_inside_lab_0185816a:

    # MC "(Huh... It looks like he didn’t hear me break into his place. The TV must be too loud for him to hear.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:217
translate chinese Ch_inside_lab_866d418a:

    # MC "*Sniff*"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:218
translate chinese Ch_inside_lab_55ac7dec:

    # MC "(Ugh, this place stinks of stale beer. He must be drunk.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:219
translate chinese Ch_inside_lab_28e115b0:

    # MC "(This could be my chance to take this bastard down. I probably wouldn’t win a one on one fight, but him being drunk might be the advantage I need!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:222
translate chinese Ch_inside_lab_fe67b348:

    # Charles "Oh yeah, deepthroat that big dick! Woo!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:223
translate chinese Ch_inside_lab_d40a9852:

    # Charles "Mmm!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:226
translate chinese Ch_inside_lab_8424ab5f:

    # Television "*SHLURP* *GAG* *SPLUTTER*"
    Television ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:227
translate chinese Ch_inside_lab_2a447fe3:

    # Television "Hnnng! Swallow it all! Don’t you dare spill a drop!"
    Television ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:228
translate chinese Ch_inside_lab_76f198cf:

    # Charles "Ah... Shit! Ugh!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:231
translate chinese Ch_inside_lab_76267811:

    # Television "Turn around, bitch! I’m gonna plough your tight asshole now!"
    Television ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:232
translate chinese Ch_inside_lab_3ce14164:

    # Charles "*Glug Glug*"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:233
translate chinese Ch_inside_lab_f7f0692b:

    # MC "(He’s distracted. Now’s my chance!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:236
translate chinese Ch_inside_lab_64f778e4:

    # MC "(I’m gonna bring you down, you piece of shit.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:237
translate chinese Ch_inside_lab_687fc745:

    # MC "(I’m gonna get Caroline her necklace back, and I’m gonna make you pay for treating her like shit for all those years.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:254
translate chinese Ch_inside_lab2_c5a8c406:

    # MC "Hyah!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:255
translate chinese Ch_inside_lab2_4b2b106b:

    # Charles "AAARGGHHH!!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:256
translate chinese Ch_inside_lab2_af91a1c6:

    # Charles "*Hack* *Cough*"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:257
translate chinese Ch_inside_lab2_4b623da9:

    # Charles "Th-There’s no *Hack* m-money here... "
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:260
translate chinese Ch_inside_lab2_484f805a:

    # MC "I’m not after money, you pathetic excuse for a human being."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:261
translate chinese Ch_inside_lab2_469f0ca2:

    # Charles "Wait- I recognise that voice. Y-You?!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:264
translate chinese Ch_inside_lab2_06d746a8:

    # Charles "What the... *Hack* fuck do you want?!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:265
translate chinese Ch_inside_lab2_405fff63:

    # MC "I want that necklace you stole from Caroline. I’m not leaving here empty-handed."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:266
translate chinese Ch_inside_lab2_d96f8b4e:

    # MC "I don’t care if I have to choke you out - I WILL get it back!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:269
translate chinese Ch_inside_lab2_48bb1754:

    # Charles "Caroline’s necklace?"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:270
translate chinese Ch_inside_lab2_ca062f6e:

    # Charles "I already fucking *cough* sold it."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:271
translate chinese Ch_inside_lab2_d9ab25bf:

    # MC "Wh-What?!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:274
translate chinese Ch_inside_lab2_e634b761:

    # Charles "Haha *cough* haha... It’s gone."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:275
translate chinese Ch_inside_lab2_e191e98b:

    # MC "WHERE?! Who did you sell it to?!"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:276
translate chinese Ch_inside_lab2_50b9e594:

    # Charles "The... *cough* nightclub owner. *Hack* Paid of my whole debt..."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:279
translate chinese Ch_inside_lab2_c6ac0d37:

    # MC "You’re lying..."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:280
translate chinese Ch_inside_lab2_5bb2ca85:

    # Charles "Do you think I’d be relaxing here right now if I was still in debt to that sociopath?! I’m a free man, baby!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:283
translate chinese Ch_inside_lab2_bdb35597:

    # Charles "Haha! I really should kick your ass for trying that shit on me."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:284
translate chinese Ch_inside_lab2_18b4d2a7:

    # Charles "But I gave that arrogant bitch Caroline, enough beatings for the two of you."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:285
translate chinese Ch_inside_lab2_0e77373f:

    # Charles "She must be saving a fortune on concealer now - a wimp like you couldn’t give her a proper shiner if he tried! AHAHAHA!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:293
translate chinese Ch_inside_lab2_e12d0e68:

    # MC "(I want to kill this fucker right now...)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:294
translate chinese Ch_inside_lab2_a0877b95:

    # MC "(...but if I don’t win I might not ever see Caroline again. I should just focus on finding her necklace.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:295
translate chinese Ch_inside_lab2_1cd9981c:

    # MC "(Maybe I can find this nightclub owner and take things from there.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:296
translate chinese Ch_inside_lab2_828504a3:

    # Charles "Yeah! Just walk away, you fucking chicken! Get the fuck outta my place and let me finish my porn in peace."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:306
translate chinese Ch_inside_lab2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:311
translate chinese Ch_inside_lab2_74e6f621:

    # "*CRACK*"
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:312
translate chinese Ch_inside_lab2_f568de0e:

    # Charles "AHHHHHH!!!!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:318
translate chinese Ch_inside_lab2_29898e32:

    # "*CRASH*"
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:319
translate chinese Ch_inside_lab2_8f59324a:

    # Charles "Ow... M-My neck... Aaaarrghhh... C-Call an ambulance!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:320
translate chinese Ch_inside_lab2_05ce9e3c:

    # MC "I’m going to leave you now, Charles."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:321
translate chinese Ch_inside_lab2_aacf8092:

    # Charles "P-Please! Ahh..."
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:322
translate chinese Ch_inside_lab2_94c97c2a:

    # MC "I don’t think I broke your neck, but even if I did, it wouldn’t be a fraction of the punishment you actually deserved."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:325
translate chinese Ch_inside_lab2_b70aa9a7:

    # MC "Goodbye, Charles. I don’t expect to ever see you again."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:326
translate chinese Ch_inside_lab2_b4dad0d1:

    # Charles "Ahhhhh!!!!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:329
translate chinese Ch_inside_lab2_cc2351e7:

    # MC "(That’s Charles dealt with, for good. I don’t think he has any reason to bother me or Caroline ever again.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:330
translate chinese Ch_inside_lab2_aa37e1e4:

    # MC "(I didn’t get what I came for though. He still sold the necklace before I could get it.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:333
translate chinese Ch_inside_lab2_65635e8d:

    # MC "(I can’t go back to Caroline empty handed. She’ll just think I put my life at risk for no reason at all!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:334
translate chinese Ch_inside_lab2_100d2c62:

    # MC "(Dammit... I should have come over here quicker. Maybe I could have caught him before he sold it?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:337
translate chinese Ch_inside_lab2_0efb9733:

    # MC "(He said he gave it to the owner of the nightclub. I should probably drop by there and see if I can arrange a meeting with the club owner.)"
    MC ""

translate chinese strings:

    # game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:289
    old "Caroline was worried about you. Leave safely while you still have the chance. It isn’t work putting your future with her at risk over a pointless fight."
    new ""

    # game/scripts/Charles_home/Outside/M/scenes/Ch_S.rpy:289
    old "Charles can NOT go unpunished for what he did to Caroline. It’s time to take the fight back to him."
    new ""

