﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:26
translate chinese Ch_last_scene_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:27
translate chinese Ch_last_scene_0d20b0b8:

    # MC "(There’s a black van outside Charles’s place. Who the hell are those guys?)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:30
translate chinese Ch_last_scene_a12e3f2e:

    # Charles "Mppf! NMMPFFF!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:31
translate chinese Ch_last_scene_0b130716:

    # Bodyguard1 "Stop struggling, sir. Get in the van."
    Bodyguard1 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:32
translate chinese Ch_last_scene_c2400f3d:

    # Charles "AHHHMMMMMMM!! HMMMM!!!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:35
translate chinese Ch_last_scene_54c47801:

    # Bodyguard2 "Shut up and get your arse in the fecking car, fella! Yer making this far more difficult than it has to be!"
    Bodyguard2 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:36
translate chinese Ch_last_scene_9fb554e5:

    # MC "(Holy shit, is Charles getting kidnapped?!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:37
translate chinese Ch_last_scene_07809dff:

    # MC "(Shit, I better hide.)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:40
translate chinese Ch_last_scene_d4ead910:

    # MC "(Fuck me... they must be from the nightclub’s organised crime gang!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:41
translate chinese Ch_last_scene_ee2f67f2:

    # MC "(I wonder what’s going to happen!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:44
translate chinese Ch_last_scene_ed41dbad:

    # Bodyguard1 "Get that trunk open."
    Bodyguard1 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:45
translate chinese Ch_last_scene_a1bbe03e:

    # Bodyguard2 "Aye, gaffer. Will do."
    Bodyguard2 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:46
translate chinese Ch_last_scene_6d631e5a:

    # MC "(That bald one has a strange accent...)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:47
translate chinese Ch_last_scene_aba9cd95:

    # Charles "MMM!! NMMFFPFF!!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:50
translate chinese Ch_last_scene_c480e064:

    # Charles "HNMMMPFFF!!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:51
translate chinese Ch_last_scene_145c82f3:

    # Bodyguard2 "That’s him in, gaffer. Do it."
    Bodyguard2 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:52
translate chinese Ch_last_scene_c1b92bfe:

    # Bodyguard1 "Stand back."
    Bodyguard1 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:55
translate chinese Ch_last_scene_08bab3d6:

    # Charles "Nmpfff!"
    Charles ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:56
translate chinese Ch_last_scene_98b35b88:

    # Bodyguard2 "I can’t see any people about, gaffer. Yeh can do him now."
    Bodyguard2 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:59
translate chinese Ch_last_scene_cfdc7624:

    # MC "*Gulp* No way..."
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:60
translate chinese Ch_last_scene_2f2d5602:

    # MC "(They’re not going to shoot him, are they?!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:68
translate chinese Ch_last_scene_cb759232:

    # "*BLAM*"
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:69
translate chinese Ch_last_scene_16e10c18:

    # MC "(HOLY FUCK!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:72
translate chinese Ch_last_scene_ff7932ba:

    # MC "(I have to get out of here!)"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:73
translate chinese Ch_last_scene_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:77
translate chinese Ch_last_scene_6f050731:

    # "*Clunk*"
    ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:78
translate chinese Ch_last_scene_e328c462:

    # Bodyguard2 "Yeh never feel any guilt doing that, gaffer?"
    Bodyguard2 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:79
translate chinese Ch_last_scene_09153128:

    # Bodyguard1 "Sometimes. This one was an especially... nasty subject though. He had a long history of domestic violence, according to the boss."
    Bodyguard1 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:80
translate chinese Ch_last_scene_cd65ca0e:

    # Bodyguard2 "Ugh, fuckin’ nonce. Y’know, if this was back in Belfast, we’d save taken the wee shite out into an alley and just done his kneecaps in."
    Bodyguard2 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:81
translate chinese Ch_last_scene_5cfa081b:

    # Bodyguard1 "True. The boss wants this one dead though. Now, let’s take this to the usual burial spot."
    Bodyguard1 ""

# game/scripts/Charles_home/Outside/M/scenes/Ch_last.rpy:82
translate chinese Ch_last_scene_718b1bc3:

    # Bodyguard2 "Aye, gaffer."
    Bodyguard2 ""

