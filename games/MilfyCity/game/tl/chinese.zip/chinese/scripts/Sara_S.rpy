﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Sara_S.rpy:73
translate chinese money_less10_951364de:

    # MC "+10$"
    MC ""

