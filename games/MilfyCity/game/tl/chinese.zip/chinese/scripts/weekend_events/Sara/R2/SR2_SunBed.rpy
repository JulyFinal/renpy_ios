﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:14
translate chinese SR2_SunBed_label_258fa26c:

    # MC "We've already been there."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:27
translate chinese SR2_SunBed_label_5b3660cc:

    # MC "How about we chill out on the lounge chairs for a while?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:28
translate chinese SR2_SunBed_label_f327fcce:

    # Sara "Cool. Works for me."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:29
translate chinese SR2_SunBed_label_d8b774a8:

    # Sara "Ahh! There’s a couple of free ones over there! Hurry! Follow me!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:33
translate chinese SR2_SunBed_label_d69c9f7a:

    # MC "Ahh... These are perfect. You got a great spot."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:34
translate chinese SR2_SunBed_label_80f3ff1f:

    # MC "Most of the other chairs were stuck in the shade."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:35
translate chinese SR2_SunBed_label_d5aec391:

    # Sara "Yeah, when you come here as often as I do, you learn where the best spots are!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:36
translate chinese SR2_SunBed_label_e504e289:

    # Sara "We’ll get - at least - two good hours of sunlight here."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:40
translate chinese SR2_SunBed_label_e27bfa8a:

    # MC "Awesome."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:41
translate chinese SR2_SunBed_label_285ee799:

    # Sara "Mmm... Do you mind if I doze off for a few minutes?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:42
translate chinese SR2_SunBed_label_8f0394c2:

    # MC "Do whatever you want, Sara. Just chill out and relax."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:43
translate chinese SR2_SunBed_label_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:47
translate chinese SR2_SunBed_label_0f94f8cc:

    # MC "(Damn, I never realised how thin her swimsuit was, until now.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:48
translate chinese SR2_SunBed_label_001f8309:

    # MC "(Just look at how little it leaves to the imagination, between her thighs.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:49
translate chinese SR2_SunBed_label_00955dda:

    # MC "(Another half inch, and I’d be able to see her pussy!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:53
translate chinese SR2_SunBed_label_3244dcbe:

    # Sara "Are you not going to sleep too?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:54
translate chinese SR2_SunBed_label_aed68143:

    # MC "I was just admiring how beautiful you are."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:55
translate chinese SR2_SunBed_label_bcbf7274:

    # Sara "[player_name]..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:56
translate chinese SR2_SunBed_label_3eae6599:

    # Sara "You’re gonna make me blush in public."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:57
translate chinese SR2_SunBed_label_a670b810:

    # Sara "Can... Can I hold your hand while I sleep?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:58
translate chinese SR2_SunBed_label_1d76cd93:

    # MC "Of course, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:62
translate chinese SR2_SunBed_label_dde06fca:

    # MC "(She’s so adorable. I love how she thought she needed to ask my permission.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:63
translate chinese SR2_SunBed_label_b8439cc6:

    # MC "(Her hands are so soft against mine. I could very easily fall asleep right now too.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:64
translate chinese SR2_SunBed_label_e171e5d1:

    # MC "Sara, I love you."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:65
translate chinese SR2_SunBed_label_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:69
translate chinese SR2_SunBed_label_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:70
translate chinese SR2_SunBed_label_b33cb7ac:

    # Sara "Zzz...."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:71
translate chinese SR2_SunBed_label_71d8b698:

    # MC "(Aww... it looks like she’s so content, that she has gone straight to sleep.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_SunBed.rpy:72
translate chinese SR2_SunBed_label_0fda9f58:

    # MC "Sweet dreams, Sara."
    MC ""

