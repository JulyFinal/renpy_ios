﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:21
translate chinese CR3_WE_G1_label_28497d09:

    # MC "(Oh yeah! She looks perfect! I’ll try my luck with her now!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:22
translate chinese CR3_WE_G1_label_6d2c965c:

    # MC "(I think this is the first time in my life, I’ve seen denim shorts THAT small! They may as well be - denim panties!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:28
translate chinese CR3_WE_G1_label_6a353e18:

    # MC "Hey there. I’m [player_name]. Nice to meet you."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:30
translate chinese CR3_WE_G1_label_f423d7aa:

    # Juliett "Hi, I’m Juliett. What brings you out tonight?"
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:34
translate chinese CR3_WE_G1_label_6cab0c27:

    # MC "I’m out, celebrating with my sister."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:36
translate chinese CR3_WE_G1_label_6e7d6be8:

    # MC "I’m out, celebrating with my friend."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:40
translate chinese CR3_WE_G1_label_e0d19962:

    # Juliett "That’s cool. Is it a birthday or something?"
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:41
translate chinese CR3_WE_G1_label_6829b7a9:

    # MC "Nah, she runs her own business - and finally started making a profit."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:42
translate chinese CR3_WE_G1_label_9dc01d95:

    # Juliett "Awesome! Congrats to her."
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:46
translate chinese CR3_WE_G1_label_70a1aee3:

    # MC "Say, would you fancy joining me for a few drinks?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:47
translate chinese CR3_WE_G1_label_2f6e4a79:

    # Juliett "Eh... not really. I’m not gonna be here, much longer tonight."
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:48
translate chinese CR3_WE_G1_label_ed78516a:

    # MC "Aww c’mon - just one drink!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:52
translate chinese CR3_WE_G1_label_4cc8c9c2:

    # Juliett "Perhaps you didn’t hear me properly, over the loud music - I said I’m heading out soon."
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:53
translate chinese CR3_WE_G1_label_4fb80981:

    # MC "Yeah, but-"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:57
translate chinese CR3_WE_G1_label_b59863c7:

    # Juliett "Listen - maybe another time, if I see you here again. But right now, I’m not interested, and don’t have a whole lotta free time. Capiche?"
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:58
translate chinese CR3_WE_G1_label_abdecc55:

    # MC "*Sigh* Yeah, I got it."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:62
translate chinese CR3_WE_G1_label_32568b39:

    # Juliett "Hey - keep your chin up. I didn’t say ‘no’ - just not tonight."
    Juliett ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G1.rpy:63
translate chinese CR3_WE_G1_label_6c83180d:

    # Juliett "See you around, [player_name]."
    Juliett ""

