﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:20
translate chinese CR3_WE_G2_label_53084ffa:

    # MC "(Oh wow! She’s pretty damn sexy! I reckon I should ask her out!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:21
translate chinese CR3_WE_G2_label_0e59ba74:

    # MC "(Her breasts look fucking amazing!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:25
translate chinese CR3_WE_G2_label_c0ed6bf5:

    # MC "(Okay, let’s open this with a totally original chat up line, that she’s never heard before, in her life!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:26
translate chinese CR3_WE_G2_label_7d91857a:

    # MC "(Hmm... Aha! Got one!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:27
translate chinese CR3_WE_G2_label_d9252311:

    # MC "Hey there - are you superglue? Because my eyes are stuck to you."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:31
translate chinese CR3_WE_G2_label_236cacf6:

    # Woman "Did you just make that line up, there, now?"
    Woman ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:32
translate chinese CR3_WE_G2_label_395c7b0f:

    # MC "Yeah, I did!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:33
translate chinese CR3_WE_G2_label_f5d4955f:

    # Woman "I can tell - just because it’s orignal, doesn’t stop it being shit."
    Woman ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:34
translate chinese CR3_WE_G2_label_45b145ce:

    # MC "(Ouch! I’ll try again!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:35
translate chinese CR3_WE_G2_label_3f73b143:

    # MC "I’m [player_name] - it’s nice to meet you."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:36
translate chinese CR3_WE_G2_label_2c5c4e35:

    # Woman "Yeah, you’re about twenty shades too pale to ride this. I ain’t spending my weekend with some tiny-dicked white dude."
    Woman ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:40
translate chinese CR3_WE_G2_label_8adfb52c:

    # MC "Huh?! What? You haven’t even seen my-"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:41
translate chinese CR3_WE_G2_label_a1a2b2b6:

    # Woman "Bubye, honey."
    Woman ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:42
translate chinese CR3_WE_G2_label_094b4a22:

    # MC "I, uh..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:46
translate chinese CR3_WE_G2_label_0725db86:

    # Woman "I said, “goodbye”. That means you can walk away now and leave me alone."
    Woman ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:47
translate chinese CR3_WE_G2_label_bbe6ecea:

    # MC "*Sigh* Fine..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_G2.rpy:48
translate chinese CR3_WE_G2_label_e7122637:

    # MC "(Yeah, there was no way I stood a chance with her. I’m not her type, at all!)"
    MC ""

