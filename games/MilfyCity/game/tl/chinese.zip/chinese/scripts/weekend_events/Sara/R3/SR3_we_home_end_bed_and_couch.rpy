﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:78
translate chinese SR3_we_home_end_bed_71e0ae56:

    # MC "How about we head over to the bed? I’ll sit down and you can suck my cock."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:80
translate chinese SR3_we_home_end_bed_4b63d6eb:

    # Sara "Will that get me wet enough so it won’t hurt when you try to put it in?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:82
translate chinese SR3_we_home_end_bed_e63ab8f4:

    # Sara "I hope that will get me wet enough..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:84
translate chinese SR3_we_home_end_bed_2885c239:

    # MC "Well, that depends. Does it turn you on when you give head?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:85
translate chinese SR3_we_home_end_bed_1832501e:

    # Sara "Umm... Yeah, it kinda does. Actually a lot as I think of that now..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:86
translate chinese SR3_we_home_end_bed_ce96497f:

    # MC "Well, that’s your answer right there! It’ll get me hard and get you wet!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:88
translate chinese SR3_we_home_end_bed_066d590f:

    # Sara "Alright. How do you want to do this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:89
translate chinese SR3_we_home_end_bed_5228c5f8:

    # MC "C’mon over here and take my jeans off."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:91
translate chinese SR3_we_home_end_bed_9b3b29c6:

    # MC "Mmm, love the view, Sara!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:92
translate chinese SR3_we_home_end_bed_92548314:

    # Sara "Hehe, I knew you were going to like this dress, but I didn’t realise just how much!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:93
translate chinese SR3_we_home_end_bed_62d0f7d0:

    # MC "What can I say? You’ve got great taste in fashion."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:95
translate chinese SR3_we_home_end_bed_0f1b1b44:

    # Sara "I’m going to suck your cock so fucking hard, you won’t be able to stand."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:96
translate chinese SR3_we_home_end_bed_2feb8789:

    # MC "Mmm, as hot as that sounds, just remember - I still need to fuck you too."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:97
translate chinese SR3_we_home_end_bed_976897b5:

    # MC "Men aren’t as lucky as women are. We only get to cum once before we need to recharge. We can’t just go again and again like you!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:98
translate chinese SR3_we_home_end_bed_39bfa45a:

    # Sara "Hehe, I’ll make sure to stop before you cum, then. Let me know when you’re getting close."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:100
translate chinese SR3_we_home_end_bed_b503a57b:

    # Sara "Hey there, big guy!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:101
translate chinese SR3_we_home_end_bed_676817a4:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:102
translate chinese SR3_we_home_end_bed_d9303071:

    # MC "(Haha, she is still adorable. How the hell did I get so lucky?)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:104
translate chinese SR3_we_home_end_bed_4a9b6eba:

    # Sara "(He got so hard so quickly! I wonder if he’s excited to finally fuck my pussy.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:106
translate chinese SR3_we_home_end_bed_f5a69fd0:

    # Sara "(Does it feel the same as when he puts his dick in my mouth? Maybe it feels better?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:108
translate chinese SR3_we_home_end_bed_2a113386:

    # Sara "(I hope my pussy will feel much better for [player_name], than my mouth.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:110
translate chinese SR3_we_home_end_bed_676817a4_1:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:111
translate chinese SR3_we_home_end_bed_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:112
translate chinese SR3_we_home_end_bed_0ec26d7c:

    # MC "Alright, ready whenever you are, Sara. Show me the best you can do."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:114
translate chinese SR3_we_home_end_bed_f2b0b304:

    # Sara "*Glompf*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:116
translate chinese SR3_we_home_end_bed_fa95d150:

    # MC "Oh, fuck! Mmm!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:117
translate chinese SR3_we_home_end_bed_10aaf249:

    # Sara "(Heh, he didn’t expect me to go that quickly!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:119
translate chinese SR3_we_home_end_bed_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:120
translate chinese SR3_we_home_end_bed_af3ea908:

    # MC "Ahh... Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:122
translate chinese SR3_we_home_end_bed_e40f8f67:

    # MC "(I can feel her teenage mouth wrapped tightly around my shaft. Her tongue is swirling over the tip of my cock.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:124
translate chinese SR3_we_home_end_bed_fef692a7:

    # MC "(I can feel her mouth wrapped tightly around my shaft. Her tongue is swirling over the tip of my cock.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:126
translate chinese SR3_we_home_end_bed_79ab639d:

    # MC "Ohh... Don’t stop, Sara!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:128
translate chinese SR3_we_home_end_bed_5d0d3abe:

    # Sara "*Suck* *Shlurp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:129
translate chinese SR3_we_home_end_bed_51a2aeea:

    # MC "Ah... Ahh... Ohhh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:131
translate chinese SR3_we_home_end_bed_1833ce98:

    # MC "Oh yeah, suck my fucking cock. Mmm! I want to feel it slide down your tight little throat."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:132
translate chinese SR3_we_home_end_bed_3cad6a41:

    # Sara "*Shlurp* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:133
translate chinese SR3_we_home_end_bed_9ce87233:

    # Sara "(Having his cock in my mouth is getting me horny. My panties are starting to get wet.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:135
translate chinese SR3_we_home_end_bed_9bcc8fed:

    # MC "Ughhh... Ohhh! Yes... "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:136
translate chinese SR3_we_home_end_bed_40486528:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:137
translate chinese SR3_we_home_end_bed_434825c8:

    # MC "You’re so good at giving head, Sara. Mmm!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:139
translate chinese SR3_we_home_end_bed_e4e2dd97:

    # MC "Ahh... yes... Mmm!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:140
translate chinese SR3_we_home_end_bed_85c5686a:

    # Sara "*Shlurp* *Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:141
translate chinese SR3_we_home_end_bed_aeed7fae:

    # MC "(It’s so tempting to just blow my load deep in her mouth right now. It would be so easy to just wrap my hands around her head, hold it in place, and fuck her face until I emptied my balls into her throat.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:143
translate chinese SR3_we_home_end_bed_31eae5ab:

    # MC "(I have to hold on though. If I cum in her mouth then I just waste an opportunity to finally fuck Sara’s tight virgin pussy.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:144
translate chinese SR3_we_home_end_bed_dacd8cbe:

    # MC "Ugh.. .Ah..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:146
translate chinese SR3_we_home_end_bed_91b3f327:

    # MC "Oh fuck, Sara. Yes! Keep sucking... Ahh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:148
translate chinese SR3_we_home_end_bed_3c4b2635:

    # Sara "*Suck* *Gag* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:150
translate chinese SR3_we_home_end_bed_b14f1a32:

    # MC "Do you *ugh* think you can go deeper, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:151
translate chinese SR3_we_home_end_bed_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:152
translate chinese SR3_we_home_end_bed_1cb75114:

    # Sara "*Shlurrrp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:154
translate chinese SR3_we_home_end_bed_7958a750:

    # Sara "(He wants me to take his cock deeper? I could try deepthroating it for him now and see if he likes that.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:155
translate chinese SR3_we_home_end_bed_3cad6a41_1:

    # Sara "*Shlurp* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:156
translate chinese SR3_we_home_end_bed_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:158
translate chinese SR3_we_home_end_bed_f7697cac:

    # MC "Holy fuck... Your mouth is just *pant* perfect, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:159
translate chinese SR3_we_home_end_bed_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:160
translate chinese SR3_we_home_end_bed_c6756ff7:

    # Sara "(Okay, here goes nothing! Let’s see how deep I can take this dick!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:162
translate chinese SR3_we_home_end_bed_79a8f4dd:

    # Sara "*Glompff*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:163
translate chinese SR3_we_home_end_bed_968b03a2:

    # MC "Hnnnggg... Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:164
translate chinese SR3_we_home_end_bed_84ae1537:

    # MC "(I can feel her tight throat clinging to the tip of my dick. Holy shit that’s good.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:166
translate chinese SR3_we_home_end_bed_e9a0152a:

    # Sara "*Gag* *Splutter* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:168
translate chinese SR3_we_home_end_bed_5c537c33:

    # Sara "(Crap! This is MUCH more difficult than it was when I was practicing on bananas! How the heck do girls do this in porn without choking?!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:170
translate chinese SR3_we_home_end_bed_68cf8852:

    # Sara "(Crap! This is MUCH more difficult than I thought! How the heck do girls do this in porn without choking?!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:171
translate chinese SR3_we_home_end_bed_1ce2f5f9:

    # MC "(Jesus, it’s taking every fibre of my being to not blow my load down her throat right now! Focus, [player_name], if you hold on you get to pound her pussy instead - and that’s gonna feel SO much better than this!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:173
translate chinese SR3_we_home_end_bed_c5f4060a:

    # MC "Ahh... Ohhh... Shit... Mmmm!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:174
translate chinese SR3_we_home_end_bed_4e319494:

    # Sara "*Shlurp* *Gag*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:175
translate chinese SR3_we_home_end_bed_d453f449:

    # Sara "(I wonder if he’s getting close to cumming. Maybe I should start slowing down now?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:177
translate chinese SR3_we_home_end_bed_a63399fa:

    # MC "Oh my God! Sara, you’re amazing! Hnnnggg! Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:179
translate chinese SR3_we_home_end_bed_094cb53f:

    # MC "(She’s managed to take almost five inches in her mouth there! She’s really improving at this!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:180
translate chinese SR3_we_home_end_bed_3c4b2635_1:

    # Sara "*Suck* *Gag* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:182
translate chinese SR3_we_home_end_bed_5f0cfde5:

    # MC "Mmm! Yes, Sara! God... I’m getting close. Oh fuck...If you keep doing that I’m gonna cum."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:183
translate chinese SR3_we_home_end_bed_f2266814:

    # Sara "*Suck* *Shluuuurrrrp* *GAG* *SPLUTTER* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:184
translate chinese SR3_we_home_end_bed_dda714c7:

    # MC "(Every time she gags I feel her little throat tightening around my cock. It’s like she’s trying to milk me dry right now!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:186
translate chinese SR3_we_home_end_bed_f85cdf89:

    # MC "Ahh.. Ahh! S-Sara, I’m about to cum! Fuck, fuck! I’m on the edge!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:187
translate chinese SR3_we_home_end_bed_bd1c6d83_2:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:188
translate chinese SR3_we_home_end_bed_ce963264:

    # Sara "(Oops! I got carried away, there and forgot to slow down.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:190
translate chinese SR3_we_home_end_bed_1af53fed:

    # MC "*Pant* Phew... that was close! Haha, you had me right on the verge of cumming."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:191
translate chinese SR3_we_home_end_bed_dbe7cd32:

    # Sara "Sorry, [player_name]. I got lost in the moment there."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:192
translate chinese SR3_we_home_end_bed_ef03104f:

    # MC "So, I take it you’re horny, then?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:193
translate chinese SR3_we_home_end_bed_4bf009b3:

    # Sara "Well.. my panties are soaked... very soaked, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:195
translate chinese SR3_we_home_end_bed_5a0eae64:

    # MC "Are you ready to try sex now, then?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:197
translate chinese SR3_we_home_end_bed_8e732692:

    # Sara "I... I guess so. I’m still a little scared. Anal with you wasn’t... It wasn't pleasant at all, the first time we did it. It really hurt."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:198
translate chinese SR3_we_home_end_bed_8e49167f:

    # Sara "I’m kinda terrified that this is going to be like that again, or maybe even worse."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:200
translate chinese SR3_we_home_end_bed_b3307a02:

    # Sara "I... I guess so. I'm still a little nervous, but I trust you, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:201
translate chinese SR3_we_home_end_bed_d97da364:

    # Sara "I'm wet and ready for your big boy... Just promise to stop when I ask you, okay?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:202
translate chinese SR3_we_home_end_bed_41f59c61:

    # MC "Listen, Sara. I promise. We’ll take it slow and if you find yourself not enjoying it, we can just stop, okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:203
translate chinese SR3_we_home_end_bed_1fa73e39:

    # Sara "Alright."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:223
translate chinese SR3_we_home_end_couch_9b2438e1:

    # Sara "Is here okay?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:224
translate chinese SR3_we_home_end_couch_9c4732ce:

    # MC "That’s perfect, Sara. Just sit back there, relax, and let me do the work."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:226
translate chinese SR3_we_home_end_couch_c855ddda:

    # MC "That dress is really cute, by the way. Where did you get it from?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:228
translate chinese SR3_we_home_end_couch_e57e130e:

    # Sara "I ordered it online. I knew [Mom_name] would kill me if she saw me going out dressed like this. Haha, she’d probably try and ground me again."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:230
translate chinese SR3_we_home_end_couch_aa116b8b:

    # Sara "I ordered it online. I know you would like it... but I was a little shy wearing it knowing that others will look at me with desire..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:231
translate chinese SR3_we_home_end_couch_624bc30f:

    # MC "(Her feet are so small and adorable.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:233
translate chinese SR3_we_home_end_couch_7dc4f1d0:

    # Sara "What are you doing, [player_name]?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:234
translate chinese SR3_we_home_end_couch_ccebd06c:

    # MC "Just admiring every last inch of your body. I didn’t think you could get much sexier than you were in the ice cream parlour, but... wow! You’re blowing my mind again right now."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:236
translate chinese SR3_we_home_end_couch_37505ed3:

    # MC "Are you still feeling nervous about sex?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:237
translate chinese SR3_we_home_end_couch_729f908a:

    # Sara "Y-Yeah, just a bit. My heart’s kinda racing right now."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:238
translate chinese SR3_we_home_end_couch_1ffa3f7e:

    # MC "That’s okay, we’ll get your body warmed up, so my cock will just slide in, nice and easy."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:240
translate chinese SR3_we_home_end_couch_2490b741:

    # Sara "O-Okay, thanks [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:241
translate chinese SR3_we_home_end_couch_8d974fbc:

    # MC "Just sit back, relax, and let me take care of your body. You’re in expert hands right now, I promise."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:243
translate chinese SR3_we_home_end_couch_9203a0c1:

    # Sara "Really? Expert hands? You’ve done this a lot?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:244
translate chinese SR3_we_home_end_couch_d1a8f266:

    # MC "Haha, that’s not what I meant! I just mean that I’m going to take good care of you."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:245
translate chinese SR3_we_home_end_couch_9a8ef999:

    # MC "(Sara seems to be very jealous at the thought of me being with someone else. I’ll have to choose my words carefully.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:247
translate chinese SR3_we_home_end_couch_bbdfd9f8:

    # MC "Now, let’s peel this dress back and see what I’ve been missing out on all day!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:248
translate chinese SR3_we_home_end_couch_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:249
translate chinese SR3_we_home_end_couch_a9222631:

    # Sara "(I can’t believe it wasn’t that long ago that we were stripping each other while playing video games in my room. Look how far we’ve come since then.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:251
translate chinese SR3_we_home_end_couch_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:252
translate chinese SR3_we_home_end_couch_175750d0:

    # MC "I never get tired of seeing your boobs, Sara. They look as amazing as they did the first time I laid eyes on them."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:253
translate chinese SR3_we_home_end_couch_a0688371:

    # Sara "Hehe... You’re just saying that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:255
translate chinese SR3_we_home_end_couch_7b375101:

    # MC "I’m serious, Sara. Your breasts are beautiful."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:256
translate chinese SR3_we_home_end_couch_35bf580f:

    # Sara "Are they better than Lily’s...?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:257
translate chinese SR3_we_home_end_couch_3eeb5c9b:

    # MC "Of course! You need to stop comparing yourself to other women, Sara. You are beautiful just the way that you are."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:259
translate chinese SR3_we_home_end_couch_30176200:

    # MC "Now, get Lily out of your head and just focus on the sensation of my fingertips teasing your sensitive nipples."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:260
translate chinese SR3_we_home_end_couch_16d178f1:

    # Sara "O-Okay, [player_name]..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:262
translate chinese SR3_we_home_end_couch_bab0a73c:

    # Sara "Oooohh..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:263
translate chinese SR3_we_home_end_couch_ba2754b7:

    # MC "I’m not pinching too hard, am I?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:264
translate chinese SR3_we_home_end_couch_25aebcdc:

    # Sara "No... that’s... perfect. Mmm..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:266
translate chinese SR3_we_home_end_couch_60847d7e:

    # Sara "Ohhh! God... your fingers are warm..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:267
translate chinese SR3_we_home_end_couch_375ce866:

    # Sara "Push a little more... ah! Yes, just like that! My chest feels all... tingly!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:269
translate chinese SR3_we_home_end_couch_a79a00c2:

    # MC "(Let’s try gently tugging on her nipples and see if she likes that.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:271
translate chinese SR3_we_home_end_couch_fcf4e1b1:

    # Sara "Ahh! Ooooohhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:272
translate chinese SR3_we_home_end_couch_5b6e50d9:

    # MC "(Look like I’m onto a winner! She’s clenching her fists in excitement!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:274
translate chinese SR3_we_home_end_couch_6011c574:

    # Sara "*Pant* [player_name], where did you *gasp* learn to use your fingers like this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:275
translate chinese SR3_we_home_end_couch_bcd96de2:

    # MC "Honestly? You’d be amazed at how much stuff you can learn from watching porn."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:276
translate chinese SR3_we_home_end_couch_e530da28:

    # Sara "Ohhh wow..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:278
translate chinese SR3_we_home_end_couch_8b776c6a:

    # MC "Do you want me to speed up or go harder?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:280
translate chinese SR3_we_home_end_couch_e2d4988a:

    # Sara "J-Just keep it *pant* like that... Wow..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:281
translate chinese SR3_we_home_end_couch_c876f818:

    # Sara "(I can feel my panties starting to get wet. It looks like whatever [player_name] was doing is working.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:283
translate chinese SR3_we_home_end_couch_47d236bc:

    # MC "Okay, let’s escalate things a bit."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:284
translate chinese SR3_we_home_end_couch_b51d1f81:

    # Sara "What do you mean?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:285
translate chinese SR3_we_home_end_couch_9e0bfcef:

    # MC "If you’re getting this excited from having your nipples rubbed, then I can only imagine how much you’re going to enjoy..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:287
translate chinese SR3_we_home_end_couch_b83cfe69:

    # MC "...having them sucked."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:288
translate chinese SR3_we_home_end_couch_da40e8b6:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:289
translate chinese SR3_we_home_end_couch_4c894c7f:

    # Sara "[player_name], I-"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:291
translate chinese SR3_we_home_end_couch_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:292
translate chinese SR3_we_home_end_couch_16cb829e:

    # Sara "Mmmm! Ohhh fuuuck! That feels sooo goood!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:293
translate chinese SR3_we_home_end_couch_d1c07ef5:

    # Sara "Just like *pant* that! Keep flicking your tongue like that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:295
translate chinese SR3_we_home_end_couch_0a778461:

    # Sara "Oh my God... Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:296
translate chinese SR3_we_home_end_couch_192ec1e8:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:297
translate chinese SR3_we_home_end_couch_b80e1a13:

    # Sara "(God, my chest feels so weird right now. There’s so much pleasure rushing through my body I can barely focus.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:299
translate chinese SR3_we_home_end_couch_a022ce36:

    # Sara "Ah... Ahh..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:300
translate chinese SR3_we_home_end_couch_71269125:

    # MC "(Let’s speed things up a bit.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:301
translate chinese SR3_we_home_end_couch_9c269129:

    # MC "*Lick* *Lick* *Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:303
translate chinese SR3_we_home_end_couch_0fb1ae41:

    # Sara "Mmm! God..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:304
translate chinese SR3_we_home_end_couch_f0799478:

    # Sara "Ah! Yes... Yes, [player_name], right there... Ahh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:306
translate chinese SR3_we_home_end_couch_ee76253e:

    # Sara "Ooohh... Fuuuccck..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:307
translate chinese SR3_we_home_end_couch_192ec1e8_1:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:309
translate chinese SR3_we_home_end_couch_0769b740:

    # Sara "W-Wow... *Pant* This is... amazing, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:310
translate chinese SR3_we_home_end_couch_47b6bd16:

    # MC "(Sara’s getting more and more excited. I wonder if I should increase the intensity of things even further?)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:312
translate chinese SR3_we_home_end_couch_192ec1e8_2:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:313
translate chinese SR3_we_home_end_couch_e1d61a6d:

    # Sara "Mmm! Y-Yes, [player_name]! Lick my tits! Ah... Just like that!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:314
translate chinese SR3_we_home_end_couch_70316717:

    # MC "(I wonder how Sara will react to me sucking on them.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:316
translate chinese SR3_we_home_end_couch_496b593d:

    # MC "*Suck*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:317
translate chinese SR3_we_home_end_couch_910b7c78:

    # Sara "*GASP*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:318
translate chinese SR3_we_home_end_couch_26bc4036:

    # MC "*Suuuck*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:319
translate chinese SR3_we_home_end_couch_d31f1bcc:

    # Sara "Wh-What are... Oooohhh! That’s soooo good!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:321
translate chinese SR3_we_home_end_couch_48dcb775:

    # Sara "Mmm! My panties are soaking, [player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:322
translate chinese SR3_we_home_end_couch_496b593d_1:

    # MC "*Suck*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:323
translate chinese SR3_we_home_end_couch_9431feb9:

    # Sara "*Gasp* Ooohh, yes! Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:325
translate chinese SR3_we_home_end_couch_261adc9f:

    # Sara "Fuck, yes! Just like that! I want to feel you inside me, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:326
translate chinese SR3_we_home_end_couch_617daf30:

    # MC "(She’s getting really horny now! It’s probably a good time for me to make my move on her pussy.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:328
translate chinese SR3_we_home_end_couch_f69dcaa4:

    # Sara "Hnnngg... Mmm... Wow... You’re the *pant* best!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:329
translate chinese SR3_we_home_end_couch_496b593d_2:

    # MC "*Suck*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:330
translate chinese SR3_we_home_end_couch_ea907d5a:

    # Sara "(His lips feel so warm wrapped around my nipple like that.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:332
translate chinese SR3_we_home_end_couch_6cd26bea:

    # Sara "Ooohh! Yes... suck on it! Ah! *Gasp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:333
translate chinese SR3_we_home_end_couch_eba00c86:

    # MC "*SUCK*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:334
translate chinese SR3_we_home_end_couch_6b3422a0:

    # Sara "Aaahh! I’m gonna cum! AAAHHHH!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:335
translate chinese SR3_we_home_end_couch_0a12db9f:

    # Sara "Yeeeesssss! *Pant* Aaaaahhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:337
translate chinese SR3_we_home_end_couch_6d64492e:

    # Sara "*Pant* *Pant*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:338
translate chinese SR3_we_home_end_couch_000481ca:

    # MC "I’m gonna guess you’re ready for sex now?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:339
translate chinese SR3_we_home_end_couch_1aa1b18e:

    # Sara "Uh huh *pant* Wh-What made you *pant* think that? Haha..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:341
translate chinese SR3_we_home_end_couch_4ef4b60c:

    # Sara "A-Are you sure I’m going to be wet enough?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:342
translate chinese SR3_we_home_end_couch_ee015863:

    # MC "Well, you just came, so you’re going to be about as wet as you can possibly get."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:344
translate chinese SR3_we_home_end_couch_73549b6d:

    # Sara "And it won’t hurt?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:346
translate chinese SR3_we_home_end_couch_2cde5186:

    # Sara "I guess so... It's will be that weird feeling again only at the beginning? Am I right?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:347
translate chinese SR3_we_home_end_couch_fe31887f:

    # MC "It will. But not much, and not for very long. I promise."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:349
translate chinese SR3_we_home_end_couch_73f244c1:

    # Sara "*Sigh* Okay... I think I’m ready, [player_name]. Let’s do this."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:350
translate chinese SR3_we_home_end_couch_ea376940:

    # MC "You’re going to be fine, Sara, I promise. Think about it, tens of millions of people are constantly going out and hooking up with each other every day via apps."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:352
translate chinese SR3_we_home_end_couch_284958d7:

    # MC "People wouldn’t be doing that if sex was a really painful unpleasant experience, would they?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:354
translate chinese SR3_we_home_end_couch_2c6917be:

    # MC "People wouldn't be doing that if sex wasn't an extremely pleasant experience, would they?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_we_home_end_bed_and_couch.rpy:355
translate chinese SR3_we_home_end_couch_893fcbf5:

    # Sara "Y-Yeah, that makes sense. You’re right. I’m overthinking things. Okay, let’s do this."
    Sara ""

