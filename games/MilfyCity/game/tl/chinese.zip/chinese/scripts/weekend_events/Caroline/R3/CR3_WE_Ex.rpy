﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:19
translate chinese CR3_WE_Ex_label_e5806e3b:

    # MC "(There’s Caroline’s ex at the center of the dancefloor.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:20
translate chinese CR3_WE_Ex_label_746f4c75:

    # MC "(Jesus Christ, that guy’s perfect. Just look at his sense of fashion, his haircut, his confidence!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:21
translate chinese CR3_WE_Ex_label_163d9c41:

    # MC "(How could I possibly compare against that?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:25
translate chinese CR3_WE_Ex_label_3dbad677:

    # MC "Hey there, Charles!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:26
translate chinese CR3_WE_Ex_label_2b692b85:

    # Charles "Who are you?"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:27
translate chinese CR3_WE_Ex_label_2a98ecb7:

    # MC "I’m [player_name] - we literally just spoke, like two minutes ago."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:31
translate chinese CR3_WE_Ex_label_f33f3dfc:

    # Charles "Sorry pal, it’s not ringing a bell."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:32
translate chinese CR3_WE_Ex_label_903b6891:

    # MC "(Look how fit he is, as well! If Caroline had to choose between me and him - there wouldn’t be any contest!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:33
translate chinese CR3_WE_Ex_label_5b8db1d7:

    # MC "*Sigh* I was sitting, right over there."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:37
translate chinese CR3_WE_Ex_label_8f0a70f4:

    # Charles "Listen, pal - I really don’t remember you."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:38
translate chinese CR3_WE_Ex_label_8ae37dc5:

    # MC "(He’s either being obtuse, or simply cares so little about me, that he has genuinely forgotten who I am.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:40
translate chinese CR3_WE_Ex_label_1b863cd8:

    # MC "I’m Caroline's brother!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:42
translate chinese CR3_WE_Ex_label_1526b1b8:

    # MC "I’m Caroline's friend!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:46
translate chinese CR3_WE_Ex_label_beacc4b6:

    # Charles "Oh shit! What was your name, pal? Humphrey or something?"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:47
translate chinese CR3_WE_Ex_label_808add9c:

    # MC "[player_name]."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:48
translate chinese CR3_WE_Ex_label_ec1c94a8:

    # Charles "Yeah, I knew I was close!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:49
translate chinese CR3_WE_Ex_label_d6cf3d58:

    # MC "(What a fucking tool...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:53
translate chinese CR3_WE_Ex_label_437868bd:

    # Charles "Whoa! Hottie alert!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:54
translate chinese CR3_WE_Ex_label_19570c32:

    # MC "What?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:55
translate chinese CR3_WE_Ex_label_5972e339:

    # Charles "I gotta bail, pal. Catch you around! Woohoo!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:56
translate chinese CR3_WE_Ex_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:58
translate chinese CR3_WE_Ex_label_51a66f55:

    # MC "(My sister has dreadful taste in men.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE_Ex.rpy:60
translate chinese CR3_WE_Ex_label_2344aa05:

    # MC "(Caroline has dreadful taste in men.)"
    MC ""

