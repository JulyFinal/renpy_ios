﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:52
translate chinese SR2_jacuzzi_label_e620ea7d:

    # Sara "[player_name]... It’s too soon for a jacuzzi! Relaxing should come last."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:88
translate chinese SR2_jacuzzi_scene_label_47ab2f0b:

    # MC "I saw a sign when I was coming in that mentioned something about jacuzzis."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:89
translate chinese SR2_jacuzzi_scene_label_dc162563:

    # MC "Do they actually have jacuzzis in here?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:90
translate chinese SR2_jacuzzi_scene_label_3b7cf157:

    # Sara "Oh yeah! They’re awesome!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:91
translate chinese SR2_jacuzzi_scene_label_e38626ed:

    # Sara "Plus, we get private access for 30 minutes each day with our VIP membership cards!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:92
translate chinese SR2_jacuzzi_scene_label_9fa81dda:

    # MC "What are we waiting for, then? Let’s go!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:96
translate chinese SR2_jacuzzi_scene_label_3da6d22c:

    # MC "This is even better than I thought it would be."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:97
translate chinese SR2_jacuzzi_scene_label_cb0de5eb:

    # MC "A warm jacuzzi, a beautiful woman, and a private room. It’s brilliant!."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:98
translate chinese SR2_jacuzzi_scene_label_f93e6668:

    # Sara "Aww... I’m glad you like it."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:102
translate chinese SR2_jacuzzi_scene_label_07c34aaf:

    # Sara "(Sigh...)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:103
translate chinese SR2_jacuzzi_scene_label_75558c95:

    # MC "(Huh? What’s gotten into her?)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:104
translate chinese SR2_jacuzzi_scene_label_71418457:

    # MC "Are you okay, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:105
translate chinese SR2_jacuzzi_scene_label_57dd146c:

    # Sara "I guess so..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:106
translate chinese SR2_jacuzzi_scene_label_3fa8c3eb:

    # MC "What’s wrong?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:107
translate chinese SR2_jacuzzi_scene_label_c2de3849:

    # Sara "Our date today... I mean.. Is it even a date? ...We haven’t really done anything."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:110
translate chinese SR2_jacuzzi_scene_label_cf905e3b:

    # Sara "It kinda feels like we’ve reverted back to brother and sister, when we’re out."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:111
translate chinese SR2_jacuzzi_scene_label_a625aa9c:

    # MC "Well, to be honest. It would be very risky to act like we’re dating."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:113
translate chinese SR2_jacuzzi_scene_label_e65da256:

    # Sara "It kinda feels like we’ve reverted back to just being friends when we’re out."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:115
translate chinese SR2_jacuzzi_scene_label_5ac3fd4c:

    # MC "Well, to be honest. I have the same thought..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:119
translate chinese SR2_jacuzzi_scene_label_10084b86:

    # Sara "Screw it!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:120
translate chinese SR2_jacuzzi_scene_label_ccd43c58:

    # MC "Huh?!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:121
translate chinese SR2_jacuzzi_scene_label_6e55051f:

    # Sara "It’s just you and me. Nobody else can come in for twenty five more minutes."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:122
translate chinese SR2_jacuzzi_scene_label_ab81b15d:

    # Sara "That’s enough time, right?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:123
translate chinese SR2_jacuzzi_scene_label_aeebee8a:

    # MC "Enough time for what?!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:130
translate chinese SR2_jacuzzi_scene_label_34f9fb7f:

    # Sara "I want to feel the way I did when I gave you that first blowjob."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:131
translate chinese SR2_jacuzzi_scene_label_cf4e28e2:

    # MC "Sara, I-"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:132
translate chinese SR2_jacuzzi_scene_label_ba0aef6a:

    # Sara "Kiss me."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:136
translate chinese SR2_jacuzzi_scene_label_ca1b9cc3:

    # MC "(I thought Sara was happy, taking things slowly - especially when we are in public... Maybe she isn't that kind of girl?)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:137
translate chinese SR2_jacuzzi_scene_label_86d1be08:

    # MC "(It looks like she’s been repressing her sex drive though!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:138
translate chinese SR2_jacuzzi_scene_label_52eee43b:

    # Sara "You can touch wherever you want."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:142
translate chinese SR2_jacuzzi_scene_label_b58f5d1c:

    # MC "(I guess that’s an open invitation to hold her ass while I make out with her.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:143
translate chinese SR2_jacuzzi_scene_label_a949ab56:

    # MC "(I wonder how far Sara is willing to go today. Maybe I’ll get to finger her?)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:144
translate chinese SR2_jacuzzi_scene_label_c6630e4f:

    # MC "(I’m overthinking this now. I should just lie back and enjoy whatever happens.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:150
translate chinese SR2_jacuzzi_scene_label_1f793de6:

    # Sara "Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:151
translate chinese SR2_jacuzzi_scene_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:152
translate chinese SR2_jacuzzi_scene_label_db18e485:

    # MC "(Sounds like she’s enjoying having her ass groped!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:156
translate chinese SR2_jacuzzi_scene_label_b2add03b:

    # MC "(Let’s give it a hard squeeze and see how she reacts!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:160
translate chinese SR2_jacuzzi_scene_label_ac74ff9b:

    # Sara "MMMMM!!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:164
translate chinese SR2_jacuzzi_scene_label_a075259e:

    # Sara "(Holy shit, that felt good!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:165
translate chinese SR2_jacuzzi_scene_label_c719a38b:

    # MC "(Yup! Looks like I found the right spot there!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:171
translate chinese SR2_jacuzzi_scene_label_a7a0e40e:

    # Sara "[player_name], I want you to... It’s embarrassing... Nevermind."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:172
translate chinese SR2_jacuzzi_scene_label_d7d08108:

    # MC "Go ahead. I promise I won’t laugh."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:173
translate chinese SR2_jacuzzi_scene_label_afd06edc:

    # Sara "Can you... pinch my nipples?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:174
translate chinese SR2_jacuzzi_scene_label_de052a1d:

    # MC "Sure! Sit up for me."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:178
translate chinese SR2_jacuzzi_scene_label_5e9bd2ae:

    # MC "How’s that?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:179
translate chinese SR2_jacuzzi_scene_label_4037d50f:

    # Sara "Ah... it’s g-good..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:180
translate chinese SR2_jacuzzi_scene_label_8623c3b2:

    # Sara "Ooh..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:184
translate chinese SR2_jacuzzi_scene_label_db624372:

    # MC "Should I keep going?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:185
translate chinese SR2_jacuzzi_scene_label_726e13a1:

    # Sara "Yeah, don’t s-stop."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:186
translate chinese SR2_jacuzzi_scene_label_ea03dc0b:

    # MC "Harder?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:187
translate chinese SR2_jacuzzi_scene_label_cf9a1c2b:

    # Sara "Could... you use your whole hand?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:191
translate chinese SR2_jacuzzi_scene_label_365afdc9:

    # MC "Like this?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:192
translate chinese SR2_jacuzzi_scene_label_23cf9c67:

    # Sara "Oooh yeah... That’s amazing..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:193
translate chinese SR2_jacuzzi_scene_label_90010a49:

    # MC "See, smaller breasts like yours are MUCH more sensitive."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:194
translate chinese SR2_jacuzzi_scene_label_f8d24112:

    # Sara "Mmm... I’m glad they’re smaller now."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:201
translate chinese after_menu_SR2_jacuzzi_scene_label_c9800c8b:

    # Sara "I love you so much, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:202
translate chinese after_menu_SR2_jacuzzi_scene_label_488a1c7a:

    # MC "I love you too, Sara. Thanks again for buying me the VIP pass."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:203
translate chinese after_menu_SR2_jacuzzi_scene_label_383736d1:

    # Sara "You don’t need to thank me. It’s been an amazing present for me too."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:207
translate chinese after_menu_SR2_jacuzzi_scene_label_cdac3e44:

    # Sara "Oooh! It feels like someone’s all hard again!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:208
translate chinese after_menu_SR2_jacuzzi_scene_label_96a1d94a:

    # MC "Oops... Sorry! Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:209
translate chinese after_menu_SR2_jacuzzi_scene_label_cadb2ea1:

    # Sara "I’m gonna go pay [player_name] Junior a visit!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:210
translate chinese after_menu_SR2_jacuzzi_scene_label_4f52553d:

    # Sara "Let’s get these swim shorts off you."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:218
translate chinese after_menu_SR2_jacuzzi_scene_label_28d9a258:

    # Sara "Wow... I forgot how big it was!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:219
translate chinese after_menu_SR2_jacuzzi_scene_label_3d181b53:

    # Sara "Hey [player_name], how does it feel if I touch your balls?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:221
translate chinese after_menu_SR2_jacuzzi_scene_label_9d8cc077:

    # MC "Go ahead and find out. Just... be gentle!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:225
translate chinese after_menu_SR2_jacuzzi_scene_label_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:226
translate chinese after_menu_SR2_jacuzzi_scene_label_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:227
translate chinese after_menu_SR2_jacuzzi_scene_label_bd82311b:

    # Sara "(Aha! So it DOES feel good when a guy has his balls played with!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:231
translate chinese after_menu_SR2_jacuzzi_scene_label_1b02c6fc:

    # MC "Oh yeah, that’s it. Keep going, Sara..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:233
translate chinese after_menu_SR2_jacuzzi_scene_label_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:234
translate chinese after_menu_SR2_jacuzzi_scene_label_274c8a80:

    # Sara "(Wow! He’s wanking himself off while I suck on his balls.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:238
translate chinese after_menu_SR2_jacuzzi_scene_label_84c23800:

    # MC "Ugh! Mmm.... Ah...."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:239
translate chinese after_menu_SR2_jacuzzi_scene_label_440fabd2:

    # Sara "(Sounds like he’s REALLY enjoying this!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:240
translate chinese after_menu_SR2_jacuzzi_scene_label_ad257cbf:

    # Sara "(I just hope he doesn’t cum too quickly!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:244
translate chinese after_menu_SR2_jacuzzi_scene_label_c7c782a8:

    # Sara "Would you like me to give you a blowjob now?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:245
translate chinese after_menu_SR2_jacuzzi_scene_label_2b515de7:

    # MC "Definitely!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:246
translate chinese after_menu_SR2_jacuzzi_scene_label_e7c77185:

    # Sara "Okay, let me get into position."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:250
translate chinese after_menu_SR2_jacuzzi_scene_label_8e637806:

    # Sara "How’s this?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:252
translate chinese after_menu_SR2_jacuzzi_scene_label_2a6d1cf3:

    # MC "Perfect!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:253
translate chinese after_menu_SR2_jacuzzi_scene_label_02780c98:

    # MC "Your eyes are amazing, you know that?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:254
translate chinese after_menu_SR2_jacuzzi_scene_label_cfd61e11:

    # Sara "Hehe... Thanks. I’m ready whenever you are."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:258
translate chinese after_menu_SR2_jacuzzi_scene_label_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:260
translate chinese after_menu_SR2_jacuzzi_scene_label_4aa11010:

    # MC "(She’s so cute. I love the way she begins her blowjobs with a kiss.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:261
translate chinese after_menu_SR2_jacuzzi_scene_label_5d4b6339:

    # Sara "(Okay, I’ll have to do everything I can, to make sure he REALLY enjoys this one!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:265
translate chinese after_menu_SR2_jacuzzi_scene_label_bd1c6d83_2:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:266
translate chinese after_menu_SR2_jacuzzi_scene_label_30ef4338:

    # MC "Mmm... Oh... That’s good..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:267
translate chinese after_menu_SR2_jacuzzi_scene_label_de65b490:

    # Sara "(It tastes a little bit salty!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:271
translate chinese after_menu_SR2_jacuzzi_scene_label_f07dbcbe:

    # Sara "(Okay - time to start taking his cock in my mouth.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:272
translate chinese after_menu_SR2_jacuzzi_scene_label_4bbd37ca:

    # MC "That feels great, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:273
translate chinese after_menu_SR2_jacuzzi_scene_label_ef9d17d2:

    # MC "Ahh... Wow..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:277
translate chinese after_menu_SR2_jacuzzi_scene_label_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:279
translate chinese after_menu_SR2_jacuzzi_scene_label_0a149ea6:

    # MC "(The feeling of her hot mouth - wrapped tightly around my glans - is indescribable.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:280
translate chinese after_menu_SR2_jacuzzi_scene_label_5cc46926:

    # MC "(I’m having to fight off the urge to blow my load, straight away!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:284
translate chinese after_menu_SR2_jacuzzi_scene_label_38543c33:

    # MC "Ohh... Ohhhh... Mmm...."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:286
translate chinese after_menu_SR2_jacuzzi_scene_label_4bbf63e0:

    # Sara "*Suck* *Shlurp* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:287
translate chinese after_menu_SR2_jacuzzi_scene_label_2f5cf862:

    # Sara "*SHLUUUURRRRP*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:291
translate chinese after_menu_SR2_jacuzzi_scene_label_ed901280:

    # MC "(Fuck! I’m not gonna last much longer! I wonder if she’ll mind taking it deeper!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:292
translate chinese after_menu_SR2_jacuzzi_scene_label_696f3331:

    # MC "(Let’s thrust my hips forward and see.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:293
translate chinese after_menu_SR2_jacuzzi_scene_label_bd1c6d83_3:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:297
translate chinese after_menu_SR2_jacuzzi_scene_label_9f7a3bf8:

    # Sara "*Suck* *GAG*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:298
translate chinese after_menu_SR2_jacuzzi_scene_label_6930e14d:

    # MC "AHHHH! SHIT! YES!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:299
translate chinese after_menu_SR2_jacuzzi_scene_label_5854f660:

    # MC "Fuck! I’m gonna cum!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:306
translate chinese after_menu_SR2_jacuzzi_scene_label_79c1a2ad:

    # MC "Open wide, Sara!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:307
translate chinese after_menu_SR2_jacuzzi_scene_label_ce2205dc:

    # Sara "Ahhhh...."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:308
translate chinese after_menu_SR2_jacuzzi_scene_label_8e6587c7:

    # MC "HNNNNNGGG! YES!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:318
translate chinese after_menu_SR2_jacuzzi_scene_label_0c7c8882:

    # MC "AHHHHHHHHH!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:319
translate chinese after_menu_SR2_jacuzzi_scene_label_22ebb65a:

    # MC "Ugh!! Ahhh...."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:320
translate chinese after_menu_SR2_jacuzzi_scene_label_217ca1f0:

    # MC "Phew... That was incredible!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:321
translate chinese after_menu_SR2_jacuzzi_scene_label_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:325
translate chinese after_menu_SR2_jacuzzi_scene_label_db5385c6:

    # Sara "(I wonder why it always tastes so salty.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:326
translate chinese after_menu_SR2_jacuzzi_scene_label_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:327
translate chinese after_menu_SR2_jacuzzi_scene_label_4ef2a264:

    # MC "Thanks, Sara. You’re amazing at that!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:333
translate chinese after_menu_SR2_jacuzzi_scene_label_79c1a2ad_1:

    # MC "Open wide, Sara!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:334
translate chinese after_menu_SR2_jacuzzi_scene_label_ce2205dc_1:

    # Sara "Ahhhh...."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:335
translate chinese after_menu_SR2_jacuzzi_scene_label_8e6587c7_1:

    # MC "HNNNNNGGG! YES!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:345
translate chinese after_menu_SR2_jacuzzi_scene_label_0c7c8882_1:

    # MC "AHHHHHHHHH!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:346
translate chinese after_menu_SR2_jacuzzi_scene_label_22ebb65a_1:

    # MC "Ugh!! Ahhh...."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:347
translate chinese after_menu_SR2_jacuzzi_scene_label_217ca1f0_1:

    # MC "Phew... That was incredible!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:348
translate chinese after_menu_SR2_jacuzzi_scene_label_db8a1ec0_1:

    # Sara "Mmm..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:352
translate chinese after_menu_SR2_jacuzzi_scene_label_db5385c6_1:

    # Sara "(I wonder why it always tastes so salty.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:353
translate chinese after_menu_SR2_jacuzzi_scene_label_ff1b9a4a_1:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:354
translate chinese after_menu_SR2_jacuzzi_scene_label_4ef2a264_1:

    # MC "Thanks, Sara. You’re amazing at that!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:360
translate chinese after_menu_SR2_jacuzzi_scene_label_9f8d3b3b:

    # Sara "You don’t want me to keep sucking?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:361
translate chinese after_menu_SR2_jacuzzi_scene_label_90ebd644:

    # MC "Just stay like that! Hnnnnng!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:362
translate chinese after_menu_SR2_jacuzzi_scene_label_55d83c5f:

    # Sara "Are you sur-"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:371
translate chinese after_menu_SR2_jacuzzi_scene_label_d12b933c:

    # Sara "Eww!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:372
translate chinese after_menu_SR2_jacuzzi_scene_label_df608fa5:

    # MC "AHHHH! Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:373
translate chinese after_menu_SR2_jacuzzi_scene_label_0e6a4c62:

    # MC "Fuck! That’s good!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:374
translate chinese after_menu_SR2_jacuzzi_scene_label_b287caa5:

    # Sara "Yuck! (I almost got it in my eye!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:380
translate chinese after_menu_SR2_jacuzzi_scene_label_9f8d3b3b_1:

    # Sara "You don’t want me to keep sucking?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:381
translate chinese after_menu_SR2_jacuzzi_scene_label_90ebd644_1:

    # MC "Just stay like that! Hnnnnng!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:382
translate chinese after_menu_SR2_jacuzzi_scene_label_55d83c5f_1:

    # Sara "Are you sur-"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:391
translate chinese after_menu_SR2_jacuzzi_scene_label_d12b933c_1:

    # Sara "Eww!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:392
translate chinese after_menu_SR2_jacuzzi_scene_label_df608fa5_1:

    # MC "AHHHH! Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:393
translate chinese after_menu_SR2_jacuzzi_scene_label_0e6a4c62_1:

    # MC "Fuck! That’s good!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:394
translate chinese after_menu_SR2_jacuzzi_scene_label_b287caa5_1:

    # Sara "Yuck! (I almost got it in my eye!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:401
translate chinese after_menu2_SR2_jacuzzi_scene_label_2063a91c:

    # MC "Well? How was this date?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:402
translate chinese after_menu2_SR2_jacuzzi_scene_label_538ed21d:

    # Sara "The BEST so far!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:403
translate chinese after_menu2_SR2_jacuzzi_scene_label_611a8691:

    # MC "Really? You honestly mean that?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:404
translate chinese after_menu2_SR2_jacuzzi_scene_label_6b33cacf:

    # Sara "Yeah, [player_name]. I was kinda hoping to get intimate with you again sooner."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:408
translate chinese after_menu2_SR2_jacuzzi_scene_label_504177bf:

    # Sara "I really do love you."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:409
translate chinese after_menu2_SR2_jacuzzi_scene_label_ce4208a1:

    # Sara "But I want more than just words... I need an intimate physical relationship with you. Like what we just did today."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:410
translate chinese after_menu2_SR2_jacuzzi_scene_label_d6e946f9:

    # MC "Let me think about it and I'll see if I can think of ways we can do it more often from now on."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:411
translate chinese after_menu2_SR2_jacuzzi_scene_label_1a79ce5e:

    # Sara "Thanks, [player_name]. You’re the best!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:412
translate chinese after_menu2_SR2_jacuzzi_scene_label_02102ed4:

    # MC "I love you, Sara."
    MC ""

translate chinese strings:

    # game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:146
    old "Touch her ass."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:146
    old "Wait for her move."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:302
    old "Blow your hot load deep inside your younger sister’s mouth."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:302
    old "Blow your hot load deep inside Sara’s mouth."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:302
    old "Spray your seed over your younger sister’s pretty face."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_jacuzzi.rpy:302
    old "Spray your seed over Sara’s pretty face."
    new ""

