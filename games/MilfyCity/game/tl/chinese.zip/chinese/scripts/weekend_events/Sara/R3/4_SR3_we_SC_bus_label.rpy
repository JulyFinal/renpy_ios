﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:28
translate chinese SR3_we_SC_bus_label_dffcc123:

    # MC "Well, this is the place. Do you know what you want?"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:29
translate chinese SR3_we_SC_bus_label_207af032:

    # Sara "Hmm... Caroline always used to buy orange sorbet every time we went out. And I’d always pick the mint."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:30
translate chinese SR3_we_SC_bus_label_021397df:

    # MC "Okay, mint it is, then."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:32
translate chinese SR3_we_SC_bus_label_4bcd1b17:

    # Sara "Two seconds, I just want to check the menu."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:33
translate chinese SR3_we_SC_bus_label_5abed8af:

    # MC "Do you know if the strawberry is good?"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:34
translate chinese SR3_we_SC_bus_label_a5be00c6:

    # Sara "Dunno, never tried it. Their other flavours are all amazing though, so I don’t think you can go wrong."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:36
translate chinese SR3_we_SC_bus_label_7f31a834:

    # MC "I haven’t seen you this excited in years. Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:37
translate chinese SR3_we_SC_bus_label_f1994719:

    # Sara "I know, I’m getting major nostalgia right now. I haven’t had one of these since I was a kid."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:39
translate chinese SR3_we_SC_bus_label_b9bc0886:

    # Salesman "Hello there, what can I get for you?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:40
translate chinese SR3_we_SC_bus_label_c8b1c7f1:

    # MC "Uhh... I’ll take one strawberry, and Sara will take..."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:41
translate chinese SR3_we_SC_bus_label_db7f5ff2:

    # Sara "Can I get a double, [player_name]?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:42
translate chinese SR3_we_SC_bus_label_690b7417:

    # MC "Sure."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:43
translate chinese SR3_we_SC_bus_label_ad341dd5:

    # Sara "In that case I’ll take one scoop or orange and one scoop of mint."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:49
translate chinese SR3_we_SC_bus_label_ed5c8735:

    # Salesman "Ah... right. I'm afraid that we've run out of the mint."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:50
translate chinese SR3_we_SC_bus_label_2559106b:

    # Salesman "I do have a wide selection of other flavours though. Perhaps you’d like to try coffee or raspberry?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:51
translate chinese SR3_we_SC_bus_label_011f043f:

    # Sara "Aww..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:53
translate chinese SR3_we_SC_bus_label_34ced161:

    # Salesman "I really am sorry, madam. It’s been extremely busy ever since we opened today."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:54
translate chinese SR3_we_SC_bus_label_242cf384:

    # Salesman "There’s a freezer to the left of my van, if you take a look in that there MIGHT be some mint ice lollies left, if you fancy one of those instead?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:55
translate chinese SR3_we_SC_bus_label_820e7a18:

    # Sara "Better than nothing, I guess."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:57
translate chinese SR3_we_SC_bus_label_a838addf:

    # MC "I can’t believe you’ve sold out already."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:58
translate chinese SR3_we_SC_bus_label_5eb5a85c:

    # Salesman "Honestly, we got far bigger crowds than anyone was expecting. Do you still want me to make you a strawberry cone?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:59
translate chinese SR3_we_SC_bus_label_837ac8a9:

    # MC "Hold off one minute."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:61
translate chinese SR3_we_SC_bus_label_d9ed337a:

    # MC "Any luck, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:62
translate chinese SR3_we_SC_bus_label_be9483e4:

    # Sara "Umm... Vanilla, vanilla, more vanilla... lemon, vanilla again..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:64
translate chinese SR3_we_SC_bus_label_595a81d3:

    # Salesman "I am terribly sorry, madam. It appears that our selection of ice lollies is also running low as well."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:65
translate chinese SR3_we_SC_bus_label_12fad69e:

    # Sara "Aww... This sucks..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:66
translate chinese SR3_we_SC_bus_label_05f0438f:

    # MC "(Wow! Sara’s ass looks so fucking hot in that mini dress.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:68
translate chinese SR3_we_SC_bus_label_4854e02a:

    # MC "(Those panties she’s wearing are a size too small! I can see the edges of her vulva spilling out the sides! If I got her to lean over a bit more, I could get a better view.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:69
translate chinese SR3_we_SC_bus_label_f89f316c:

    # MC "Hey Sara, try deeper in the freezer. Search way down at the bottom."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:70
translate chinese SR3_we_SC_bus_label_7e13e5e8:

    # Salesman "Mmm, yes! That’s a good idea. And take your time... no rush at all."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:72
translate chinese SR3_we_SC_bus_label_20933219:

    # MC "Oh yeah..."
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:73
translate chinese SR3_we_SC_bus_label_818460cf:

    # MC "(Her asshole’s barely covered at all right now! If her panties slip, even a little bit, I should be able to see her tight little asshole.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:74
translate chinese SR3_we_SC_bus_label_2c0b7f83:

    # Salesman "(This is the best shift ever!)"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:76
translate chinese SR3_we_SC_bus_label_81f70de0:

    # Sara "I can’t find any, [player_name]..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:77
translate chinese SR3_we_SC_bus_label_084f2fa8:

    # Sara "Ugh... Nope, this freezer is like a Catholic’s browser history - nothing but vanilla."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:79
translate chinese SR3_we_SC_bus_label_86a0b1d8:

    # MC "(God, that ass is to die for. I still can’t believe that I got to fuck that.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:80
translate chinese SR3_we_SC_bus_label_808a0337:

    # MC "(AND I was the first one too! If there was no one else here, I’d tug those panties down to her ankles and ram my dick into her little virgin pussy while she was bent over the freezer.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:82
translate chinese SR3_we_SC_bus_label_4df52d4c:

    # MC "(She’d be screaming in ecstasy as my thick cock made her cum again and again.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:84
translate chinese SR3_we_SC_bus_label_c522193f:

    # MC "(And then I’d finish by filling up her teenage pussy with a thick creamy load.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:86
translate chinese SR3_we_SC_bus_label_6d7f876f:

    # MC "(And then I’d finish by filling up her pussy with a thick creamy load.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:88
translate chinese SR3_we_SC_bus_label_09904909:

    # Sara "Hello? [player_name]?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:89
translate chinese SR3_we_SC_bus_label_e09d97de:

    # Sara "[player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:90
translate chinese SR3_we_SC_bus_label_e4c5dc6d:

    # MC "Huh? W-What?"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:91
translate chinese SR3_we_SC_bus_label_cfeabb7d:

    # Sara "I was talking to you - you’d spaced out on me. I was saying that there’s no mint left."
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:93
translate chinese SR3_we_SC_bus_label_593dd158:

    # Salesman "Y’know, if you guys are okay sitting in for your ice cream, our parlour is still open. They probably have a tonne of different flavours still in stock."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:94
translate chinese SR3_we_SC_bus_label_3cc38a4b:

    # MC "Should we check out the parlour then, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:96
translate chinese SR3_we_SC_bus_label_7d6f2f70:

    # Sara "I would have preferred to walk around and explore the new mall, but that’s okay. Thanks for your help!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:97
translate chinese SR3_we_SC_bus_label_5d9b0005:

    # Salesman "My pleasure, thanks for the view."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:98
translate chinese SR3_we_SC_bus_label_2887c358:

    # Sara "The view?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:99
translate chinese SR3_we_SC_bus_label_0e5624da:

    # Salesman "I... uh... I mean, thank you for viewing my store!"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:100
translate chinese SR3_we_SC_bus_label_28be5f50:

    # Sara "Oh... No problem!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/4_SR3_we_SC_bus_label.rpy:101
translate chinese SR3_we_SC_bus_label_d280d1d8:

    # MC "C’mon Sara, let’s go and see what the parlour is like."
    MC ""

