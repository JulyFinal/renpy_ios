﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:15
translate chinese SR2_swimming_label_258fa26c:

    # MC "We've already been there."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:29
translate chinese SR2_swimming_label_e4e37442:

    # MC "How about, I go swimming, and you can sit, safely in the pink flamingo toy?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:30
translate chinese SR2_swimming_label_c7b9d099:

    # Sara "Hmm... I don’t know. It’s pretty scary."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:31
translate chinese SR2_swimming_label_c4311b8b:

    # MC "Relax - I’ll stay beside you the whole time, to make sure you don’t fall off."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:32
translate chinese SR2_swimming_label_3368d698:

    # Sara "Err... Okay then."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:36
translate chinese SR2_swimming_label_4601ab1c:

    # MC "See? Nothing to worry about."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:37
translate chinese SR2_swimming_label_9de8115f:

    # Sara "I... I guess so..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:38
translate chinese SR2_swimming_label_e92e47e8:

    # MC "You still look a little nervous."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:39
translate chinese SR2_swimming_label_8957ef79:

    # Sara "Yeah, I’m a bit scared of the water."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:43
translate chinese SR2_swimming_label_2144f69a:

    # MC "Oh, so it would be really scary if the float started to tip over?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:44
translate chinese SR2_swimming_label_e3702367:

    # Sara "NO! Don’t you dare!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:45
translate chinese SR2_swimming_label_ecf49d3f:

    # MC "Uh oh! Mayday! Mayday! We’re going down!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:46
translate chinese SR2_swimming_label_ab868a52:

    # Sara "STOP THAT, [player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:51
translate chinese SR2_swimming_label_736a2d71:

    # Sara "AAAHHHH!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:52
translate chinese SR2_swimming_label_e57aae5f:

    # MC "This is the USS Pink Flamingo. We have taken on water and are sinking!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:54
translate chinese SR2_swimming_label_649ebc62:

    # Sara "STOP! STOP! NOOOO!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:55
translate chinese SR2_swimming_label_cd9be2ff:

    # MC "Hahahahaha!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:59
translate chinese SR2_swimming_label_c054d8d0:

    # Sara "Grrr! That’s NOT funny, [player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:60
translate chinese SR2_swimming_label_cbbf038e:

    # Sara "I could have LITERALLY drowned!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:61
translate chinese SR2_swimming_label_37481a87:

    # MC "The pool is like six feet deep!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:63
translate chinese SR2_swimming_label_9fe18535:

    # Sara "And I’m only five foot four on a GOOD day!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:65
translate chinese SR2_swimming_label_1eec9260:

    # Sara "That’s not the case!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:66
translate chinese SR2_swimming_label_cad2f92c:

    # MC "Alright. I’m sorry, Sara. I won’t do it again."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:67
translate chinese SR2_swimming_label_162ccacc:

    # Sara "You better not."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:68
translate chinese SR2_swimming_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:69
translate chinese SR2_swimming_label_ae69aa73:

    # Sara "I said, you better not do it again!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:70
translate chinese SR2_swimming_label_91d04286:

    # MC "I can’t hear you. It’s too loud in here now. Can you lean in closer?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:74
translate chinese SR2_swimming_label_7325e6b8:

    # MC "(Hehe. She fell for it!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:75
translate chinese SR2_swimming_label_81272d24:

    # Sara "I said, you better not try and tip the float aga-"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:79
translate chinese SR2_swimming_label_efe8aed1:

    # Sara "Mmpff!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:80
translate chinese SR2_swimming_label_2319e1b4:

    # MC "Mwah..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:81
translate chinese SR2_swimming_label_4de25d1a:

    # Sara "(Bastard! He tricked me!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:82
translate chinese SR2_swimming_label_b40a54e1:

    # MC "Hehe. Gotcha!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:86
translate chinese SR2_swimming_label_923671cb:

    # Sara "Bro..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:87
translate chinese SR2_swimming_label_be9c7d22:

    # MC "Maybe don’t call me ‘Bro’ too loudly. We are in a public place, after all."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:89
translate chinese SR2_swimming_label_490b64a6:

    # Sara "Y-You kissed me!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:90
translate chinese SR2_swimming_label_b048497e:

    # MC "I hope you liked that small surprise! Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:91
translate chinese SR2_swimming_label_f09e0684:

    # Sara "Hehe... Oh yeah."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:92
translate chinese SR2_swimming_label_278bf9c1:

    # MC "Still angry at me?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:93
translate chinese SR2_swimming_label_c38aa4b8:

    # Sara "No. Apology accepted. Just... don’t do it again, okay?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:94
translate chinese SR2_swimming_label_615eedc7:

    # MC "Okay."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:98
translate chinese SR2_swimming_label_db5f69f5:

    # MC "Mwah!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:99
translate chinese SR2_swimming_label_04cb941e:

    # Sara "(OH MY GOD! AGAIN?!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:103
translate chinese SR2_swimming_label_a6c844b0:

    # MC "Haha! Sorry! I couldn’t resist. I love that cute, shocked expression you get, every time I kiss you."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:104
translate chinese SR2_swimming_label_c5d86e00:

    # Sara "Hehe... You’re bad, you know that?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:105
translate chinese SR2_swimming_label_a2b125dd:

    # MC "I know."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming.rpy:106
translate chinese SR2_swimming_label_409a390e:

    # Sara "Haha! Okay, let’s call it a day."
    Sara ""

