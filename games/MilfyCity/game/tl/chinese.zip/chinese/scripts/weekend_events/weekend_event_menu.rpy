﻿# TODO: Translation updated at 2023-11-20 15:50

translate chinese strings:

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}Meet with Celia{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}Go with Sara to the swimming pool{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}Sara's Mall event{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{color=#f00}{alpha=0.4} [Mom_name] weekend event (Required: Red Wine){/alpha}{/color} (disabled)"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}[Mom_name] weekend event{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#f00}{alpha=0.4} Meet up with Caroline (Required: 200$){/alpha}{/color} {image=images/NS_B/New1.png}(disabled)"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}Caroline's weekend event{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}Meet with Judy at the college{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "{image=images/NS_B/New1.png} {color=#00ff00}Celia's weekend event{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/scripts/weekend_events/weekend_event_menu.rpy:13
    old "Celia's weekend event"
    new ""

