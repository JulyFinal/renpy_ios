﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:91
translate chinese SR3_we_label_21d8cdb1:

    # Sara "Wakey wakey! Rise and shine!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:92
translate chinese SR3_we_label_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:94
translate chinese SR3_we_label_af209d0d:

    # Sara "Boop! Hehe!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:95
translate chinese SR3_we_label_d06223ce:

    # MC "Ugh... Stop poking my nose!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:97
translate chinese SR3_we_label_63d1d500:

    # Sara "Time to get up, sleepy head! It’s our big day."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:98
translate chinese SR3_we_label_a781e90f:

    # MC "Our big... day?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:99
translate chinese SR3_we_label_72b3854b:

    # Sara "It’s the grand opening of the mall! It’s OUR date! C’mon! Hurry up and get ready, we’re gonna be late!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:101
translate chinese SR3_we_label_a067d070_1:

    # MC "*Yawn*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:102
translate chinese SR3_we_label_9d58c663:

    # MC "Yea, I’m coming... just give me a couple more minutes..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:103
translate chinese SR3_we_label_6c84fac6:

    # Sara "You’re just gonna go straight back to sleep, and then I’m gonna have to wake you up all over again! I know you too well, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:105
translate chinese SR3_we_label_0c84a36d:

    # MC "Yeah, you’re right. Fine, I’m getting up."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:106
translate chinese SR3_we_label_e8a4ba53:

    # Sara "C’mon, get your ass in the shower and let’s hit the road."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:108
translate chinese SR3_we_label_4404f276:

    # MC "Heh, what time have you been awake from?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:109
translate chinese SR3_we_label_eabf12da:

    # Sara "I BARELY slept. I’m so EXCITED! It’s gonna be amazing!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:110
translate chinese SR3_we_label_88f0e181:

    # MC "I can’t believe you’re this excited about the mall."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:112
translate chinese SR3_we_label_3a383e27:

    # Sara "It’s not the mall I’m excited about, silly! "
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:114
translate chinese SR3_we_label_673103c9:

    # Sara "It’s getting to spend the day with you!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:115
translate chinese SR3_we_label_6e16685b:

    # MC "Aww, in that case I’ll get ready as quickly as I can."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:117
translate chinese SR3_we_label_d7693b65:

    # Sara "That’s the spirit!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:118
translate chinese SR3_we_label_24434e21:

    # MC "Just give me five minutes to have a quick bath and I’ll be done."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:123
translate chinese SR3_we_label_77f328c1:

    # Sara "Hey [player_name], are you awake?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:124
translate chinese SR3_we_label_456248d2:

    # MC "Zzz... Hmm?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:125
translate chinese SR3_we_label_8833e9dc:

    # Sara "Morning..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:127
translate chinese SR3_we_label_d2d54e56:

    # MC "Oh, morning Sara, what’s up?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:128
translate chinese SR3_we_label_6cf5ab7d:

    # Sara "I... uh... It’s the grand opening of the mall today."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:130
translate chinese SR3_we_label_2194e4ba:

    # Sara "You know, the way you sorta agreed to go on a date with me."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:131
translate chinese SR3_we_label_6d04bcd1:

    # MC "Yeah, a date, but we keep it on the down low. Don’t make it too obvious?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:132
translate chinese SR3_we_label_38fa078a:

    # Sara "*Sigh* Yeah... "
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:133
translate chinese SR3_we_label_d73a622d:

    # Sara "Well, the mall is opening today. Do you still want to go with me?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:135
translate chinese SR3_we_label_90bc43b1:

    # MC "Yeah, of course, Sara. I’ll just hit the bathroom and we’ll be ready to go."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:137
translate chinese SR3_we_label_07257183:

    # Sara "I’d been thinking... Do we really need to keep this date a secret?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:138
translate chinese SR3_we_label_564d2604:

    # MC "Sorry, Sara. It’s too risky otherwise. We talked about this - just imagine what would happen if someone from our college saw us. (Or any other girl I'm dating not just from college...)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:139
translate chinese SR3_we_label_138332f3:

    # Sara "*Sigh*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:141
translate chinese SR3_we_label_608106c1:

    # Sara "([player_name] didn’t worry about this kind of stuff when he asked our Ms. Celia in college.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:142
translate chinese SR3_we_label_a2027f12:

    # Sara "(I mean, sure, he embarrassed himself, but if he could pick up the courage to ask a professor out in public, why can’t he do the same for me?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:143
translate chinese SR3_we_label_e50848fc:

    # Sara "(Do I honestly mean less to him than Ms. Celia?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:144
translate chinese SR3_we_label_a22a1eb6:

    # Sara "(Maybe I am just his side piece to be fucked and used until someone better comes along...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:146
translate chinese SR3_we_label_3d0fbc59:

    # Sara "(I need to prove to [player_name] that I’m worthy of being his girlfriend. Then he’ll love me and actually want to be a proper couple in public!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:147
translate chinese SR3_we_label_d4bf7ccc:

    # Sara "(I’ll begin right now by marching into the bathroom and showing him EXACTLY what he will get with me as his official girlfriend!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:167
translate chinese SR3_bath_time_e0478002:

    # MC "(Not now, it's time for a bath.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:177
translate chinese SR3_bath_time_corr_e0478002:

    # MC "(Not now, it's time for a bath.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:187
translate chinese SR3_bath_time_living_e0478002:

    # MC "(Not now, it's time for a bath.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:196
translate chinese SR3_bath_time_kitchen_e0478002:

    # MC "(Not now, it's time for a bath.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:213
translate chinese SR3_we_bath_91368a27:

    # MC "(The mall’s grand opening is going to attract a big crowd. There’s definitely going to be a few people from our college there.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:214
translate chinese SR3_we_bath_d352e2a4:

    # MC "(I wonder how they’ll react to seeing Sara and me on a date?)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:216
translate chinese SR3_we_bath_4b2b63e0:

    # MC "(At the end of the day, the thing that matters the most is that she is happy.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:217
translate chinese SR3_we_bath_67b9e0b4:

    # MC "(God, she was so nervous when she was trying to ask me out. I’ll do my best to make today as special as I can for her.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:218
translate chinese SR3_we_bath_69bcab67:

    # MC "(Okay, time to run myself a bath and get washed.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:220
translate chinese SR3_we_bath_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:221
translate chinese SR3_we_bath_361d8973:

    # MC "(There’s no better way to wake up on the weekend, than a relaxing hot bath.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:223
translate chinese SR3_we_bath_c5b8c611:

    # Sara "(Oh wow! I’ve been grounded for so long, I forgot how hot [player_name] looks when he’s naked.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:224
translate chinese SR3_we_bath_e48b7e87:

    # Sara "(When was the last time I saw him like this? It must have been when we were both up on the roof trying anal.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:226
translate chinese SR3_we_bath_33b0aca0:

    # Sara "(God... His cock is massive.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:227
translate chinese SR3_we_bath_073805ea:

    # Sara "(I still can’t believe he agreed to go on a date with me. I really want to do something for him, to show how grateful I am.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:230
translate chinese SR3_we_bath_9f952e04:

    # Sara "Hey, mind if I join you?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:231
translate chinese SR3_we_bath_6a128959:

    # MC "Oh, hey Sara. Sure, c’mon in!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:234
translate chinese SR3_we_bath_3439b248:

    # MC "Just be careful. [Mom_name] or [Dad_name] didn’t see you come in here, did they?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:236
translate chinese SR3_we_bath_69c0310a:

    # MC "No one's at home? Can we be loud?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:237
translate chinese SR3_we_bath_1200f56d:

    # Sara "Relax, [Mom_name] just went out to the shops, and [Dad_name] probably went to the office for overtime."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:239
translate chinese SR3_we_bath_f4d7e3a8:

    # MC "*Phew* That’s a relief. I’m a little too old now to plausibly be sharing a bath with you."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:241
translate chinese SR3_we_bath_d9150041:

    # MC "*Phew* That’s a relief."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:243
translate chinese SR3_we_bath_2f3e44f7:

    # Sara "Hehe! Stop worrying, we’ll be fine. The only other person in the home is Caroline, and I think she’s just moping around in her room right now."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:244
translate chinese SR3_we_bath_55db7ccf:

    # MC "Okay, that’s good."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:245
translate chinese SR3_we_bath_360809c8:

    # MC "(Sara looks so fucking sexy, wearing nothing but those tight little denim shorts.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:247
translate chinese SR3_we_bath_c449d7f8:

    # MC "Y’know, if you’re planning on joining me in here, you’re gonna have to lose those shorts."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:248
translate chinese SR3_we_bath_abb9a0e1:

    # Sara "Oh, you mean these?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:250
translate chinese SR3_we_bath_31d4926a:

    # Sara "Enjoying the view, [player_name]?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:251
translate chinese SR3_we_bath_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:253
translate chinese SR3_we_bath_07e47dd9:

    # MC "(Damn, her teenage ass is stunning!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:255
translate chinese SR3_we_bath_001248e3:

    # MC "(Damn, her tight ass is stunning!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:257
translate chinese SR3_we_bath_d19cd756:

    # Sara "I’ll join you in a second, [player_name]. I just have to grab my shampoo and a spare towel."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:258
translate chinese SR3_we_bath_b8b14f5a:

    # MC "Uh huh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:260
translate chinese SR3_we_bath_5eb044d6:

    # MC "(I can’t just wait in the bath! That ass is just begging to be pounded right now!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:261
translate chinese SR3_we_bath_ca68bf8c:

    # MC "(God, I’d love to just bend her over the sink, bury my shaft in her pussy and fuck her until her tight little hole cums around my cock.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:262
translate chinese SR3_we_bath_8c483c03:

    # Sara "Did you see where I left my-"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:264
translate chinese SR3_we_bath_efe8aed1:

    # Sara "Mmpff!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:265
translate chinese SR3_we_bath_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:267
translate chinese SR3_we_bath_9b96cfe0:

    # Sara "W-What happened to us bathing together? Hehe."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:268
translate chinese SR3_we_bath_8d46c167:

    # MC "You were tempting me. I couldn’t resist."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:269
translate chinese SR3_we_bath_6839f872:

    # Sara "So you thought you’d just surprise me with a passionate kiss?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:270
translate chinese SR3_we_bath_f2dbdc9a:

    # MC "Did it work?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:272
translate chinese SR3_we_bath_76be4c21:

    # Sara "Yeah... I liked it."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:274
translate chinese SR3_we_bath_d4f7fcbc:

    # MC "I missed you when you were grounded, you know that, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:276
translate chinese SR3_we_bath_884382f4:

    # MC "I missed you when you were at room reading books all day, you know that, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:277
translate chinese SR3_we_bath_37fe985f:

    # Sara "I missed seeing you too, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:279
translate chinese SR3_we_bath_27b4aec6:

    # Sara "Oh wow, I can feel your big guy between my thighs. You REALLY did miss me, huh?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:280
translate chinese SR3_we_bath_2910d3e5:

    # MC "Hmm? Oh, he isn’t even that big yet. Give him a moment."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:282
translate chinese SR3_we_bath_1aa768d3:

    # Sara "Oh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:283
translate chinese SR3_we_bath_e9a6d98d:

    # MC "Haha! See what I mean?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:284
translate chinese SR3_we_bath_f391bdf1:

    # Sara "Y-Yeah!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:285
translate chinese SR3_we_bath_7c68ae52:

    # MC "Do you fancy doing something naughty together before our date?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:287
translate chinese SR3_we_bath_a8457368:

    # MC "How does it feel when I slide my dick back and forth across your pussy like that?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:288
translate chinese SR3_we_bath_093e89f6:

    # Sara "Ah... It’s... It’s really nice..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:289
translate chinese SR3_we_bath_15973e11:

    # MC "I could just slip it inside right now. How about even just the tip?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:291
translate chinese SR3_we_bath_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:292
translate chinese SR3_we_bath_1523d466:

    # MC "C’mon, you know you want it."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:293
translate chinese SR3_we_bath_7889b06a:

    # Sara "I do... but..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:294
translate chinese SR3_we_bath_5d0a696a:

    # Sara "(I can feel his cock brushing up against my vulva... If he really wanted to, he could plunge it into my pussy and pop my cherry right now.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:295
translate chinese SR3_we_bath_98ac3c45:

    # Sara "(I’m not ready for that yet. I don’t want my first time to be a quickie in a bathroom.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:297
translate chinese SR3_we_bath_a7f09b1f:

    # Sara "W-Wait, I’m not ready for sex. I don’t want my first time to be in the bathroom."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:298
translate chinese SR3_we_bath_57cd70fe:

    # MC "Heh, I understand that."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:303
translate chinese SR3_we_bath_def0a97b:

    # MC "How about you get down on your knees and suck my cock instead?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:305
translate chinese SR3_we_bath_29292df8:

    # Sara "Yeah! I can do that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:306
translate chinese SR3_we_bath_a10b7f35:

    # Sara "(That’s a relief. I was worried he was going to want sex really badly right now.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:307
translate chinese SR3_we_bath_55171825:

    # MC "You look so sexy, Sara. God, your freckles are just adorable."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:308
translate chinese SR3_we_bath_835ebd28:

    # Sara "Hehe, thanks."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:310
translate chinese SR3_we_bath_ff1b9a4a_1:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:311
translate chinese SR3_we_bath_a123aa35:

    # MC "You okay there?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:312
translate chinese SR3_we_bath_ad23083a:

    # Sara "I... uh... kinda forgot how big your guy was up close."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:313
translate chinese SR3_we_bath_8d7f4393:

    # MC "Haha, don’t worry. We can do this another time if you want."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:315
translate chinese SR3_we_bath_d3437b0f:

    # Sara "No way! Do you not think I’m up to the challenge?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:316
translate chinese SR3_we_bath_6e3035ee:

    # MC "Mmm... "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:317
translate chinese SR3_we_bath_0d84dc08:

    # MC "(Her palm feels so warm wrapped around my shaft.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:318
translate chinese SR3_we_bath_3eb577c0:

    # MC "Go ahead, but don’t push yourself if you don’t want to."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:320
translate chinese SR3_we_bath_2307048b:

    # Sara "I’ve been practicing, you know?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:321
translate chinese SR3_we_bath_f5f9d61d:

    # MC "Practicing giving head?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:322
translate chinese SR3_we_bath_15562df7:

    # Sara "I’d been asking [Mom_name] for cucumbers and bananas to eat while I studied. Remember when I first started giving you blowjobs I could barely fit an inch in my mouth?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:324
translate chinese SR3_we_bath_6dc2d41b:

    # MC "Yeah, I remember. It was adorable though."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:326
translate chinese SR3_we_bath_8f963817:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe! The best part was, [Mom_name] never suspected a thing."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:328
translate chinese SR3_we_bath_a3e27abe:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:329
translate chinese SR3_we_bath_664028f3:

    # MC "Okay then, Sara. Let’s see what you’ve got."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:331
translate chinese SR3_we_bath_995d9e27:

    # Sara "(Okay Sara, deep breaths... You can do this. It’s just like a banana...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:332
translate chinese SR3_we_bath_1b0c0dea:

    # Sara "(You’ve practiced for this. You've read porn magazines and watched a lot of porn videos!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:333
translate chinese SR3_we_bath_bdd8cf62:

    # MC "Mmm... God that’s good... Keep stroking my cock like that."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:335
translate chinese SR3_we_bath_1d81783e:

    # Sara "Are you enjoying this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:337
translate chinese SR3_we_bath_b1e68492:

    # MC "Mmm... Oh yeah, it’s so good."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:338
translate chinese SR3_we_bath_73b9b423:

    # Sara "Well, it’s about to get a whole lot better."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:340
translate chinese SR3_we_bath_acbf6f41:

    # Sara "You’re so big and hard, [player_name]. I can feel it pulsing against my fingers."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:342
translate chinese SR3_we_bath_e3ade2cb:

    # MC "That just means I’m super excited."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:344
translate chinese SR3_we_bath_09d8181c:

    # MC "Alright, let’s see what you’ve taught yourself."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:345
translate chinese SR3_we_bath_64d8a6c2:

    # Sara "I’m about to blow your mind, [player_name]. Just close your eyes, relax, and enjoy the sensation of my mouth wrapped around your cock."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:347
translate chinese SR3_we_bath_676817a4:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:349
translate chinese SR3_we_bath_5800eb5b:

    # MC "Ohhh... fuck..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:350
translate chinese SR3_we_bath_a9389210:

    # Sara "Haha! I’m glad you like it!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:352
translate chinese SR3_we_bath_0111514d:

    # Sara "(Remember what you read on Judy’s Blog: the glans is the most sensitive part of the guy’s cock. If I focus my efforts on the tip of his dick, I’ll make him cum so much harder!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:353
translate chinese SR3_we_bath_9c363fd7:

    # Sara "*Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:354
translate chinese SR3_we_bath_327a84b0:

    # MC "Ahh... just like that... Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:356
translate chinese SR3_we_bath_40486528:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:357
translate chinese SR3_we_bath_4e6b387c:

    # MC "Mmm! Ugh... I missed your little mouth so fucking much, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:358
translate chinese SR3_we_bath_5ba0a8c7:

    # MC "(Her tongue is so wet and warm against my cock. Sara’s blowjobs are fuckin' incredible.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:360
translate chinese SR3_we_bath_4a4fc314:

    # Sara "*Mwah* *Lick*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:361
translate chinese SR3_we_bath_d17a2701:

    # MC "Hnnng... Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:362
translate chinese SR3_we_bath_315fcdd8:

    # MC "(She’s so cute, down there on her knees sucking my dick.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:364
translate chinese SR3_we_bath_6e3198d2:

    # Sara "(What was the next piece of advice that blog gave... Oh yeah! Move your head back and forth, allowing your lips to glide over the head of the penis.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:366
translate chinese SR3_we_bath_fb284e00:

    # Sara "*Shlurp* *Suck* *Shluuuurrrp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:368
translate chinese SR3_we_bath_63b87947:

    # MC "Ahhh... You definitely ARE getting better. Mmm!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:370
translate chinese SR3_we_bath_30554186:

    # MC "(Sara’s breasts were never the biggest, but they look so perky and perfect. Her skin looks phenomenal when the sunlight caresses it like that.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:371
translate chinese SR3_we_bath_9c363fd7_1:

    # Sara "*Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:372
translate chinese SR3_we_bath_ab7362ea:

    # MC "God, you’re fucking amazing, Sara... Don’t stop!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:374
translate chinese SR3_we_bath_259cb936:

    # MC "Mmm, please don’t stop!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:376
translate chinese SR3_we_bath_40486528_1:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:377
translate chinese SR3_we_bath_090c1266:

    # Sara "(His dick is starting to throb in my mouth. He must be REALLY enjoying this!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:379
translate chinese SR3_we_bath_79a290ea:

    # MC "This is brilliant, Sara, but do you think you can try going a bit deeper?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:381
translate chinese SR3_we_bath_00db2170:

    # Sara "Mmm hmm! *Shlurp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:383
translate chinese SR3_we_bath_77ffa74b:

    # Sara "*Glompfff*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:384
translate chinese SR3_we_bath_cf38225b:

    # MC "Mmm... That’s right. Just like that, Sara. Ugh! Fuck..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:385
translate chinese SR3_we_bath_e4bf86f3:

    # Sara "(What did Judy write next? Create a vacuum by sucking your cheeks in? I think that was it.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:387
translate chinese SR3_we_bath_196e8da8:

    # Sara "*Suuuuuccck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:388
translate chinese SR3_we_bath_8b2f405a:

    # MC "Oooohhh fuuucck... Oh Sara, that’s so fucking good!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:389
translate chinese SR3_we_bath_3e93c595:

    # MC "(I’m lucky [Mom_name] and [Dad_name] aren’t home. There’s no way I’ll be able to keep my voice down for the whole blowjob!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:391
translate chinese SR3_we_bath_f59a84ed:

    # Sara "*Suck* *Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:392
translate chinese SR3_we_bath_0808dcbb:

    # MC "Oh! Oh fuck! Arrrghhh! Ugh! Yes! Yes Sara, don’t stop!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:393
translate chinese SR3_we_bath_957abfd8:

    # Sara "*Shlurp* *Slluurrrp* *SUCK*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:395
translate chinese SR3_we_bath_216e4bf0:

    # MC "I... *Hnnnhhh* I... I’m gonna..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:397
translate chinese SR3_we_bath_cf07efe5:

    # Sara "(What was I supposed to do after sucking my cheeks in? I can’t remember now. I think I’m supposed to start ‘deepthroating’ now, aren’t I?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:399
translate chinese SR3_we_bath_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:401
translate chinese SR3_we_bath_7f790225:

    # Sara "(Yeah, I’ll try taking his dick deeper into my mouth. I mean, he seems to be enjoying whatever I’m doing right now!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:402
translate chinese SR3_we_bath_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:403
translate chinese SR3_we_bath_b38e805b:

    # MC "Fuuuck! Hnnnnggg!! Ugghhh! I’m cumming!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:405
translate chinese SR3_we_bath_c50ac75f:

    # Sara "Hmm?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:413
translate chinese SR3_we_bath_ff51b3ec:

    # Sara "Mmpplllfff! *Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:414
translate chinese SR3_we_bath_c33108ff:

    # MC "Ughhhh! Ohhh God, that’s amazing..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:415
translate chinese SR3_we_bath_834c250f:

    # Sara "(H-Holy shit! I was NOT expecting him to cum yet! I got WAY too distracted thinking about what to do next!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:417
translate chinese SR3_we_bath_6d184773:

    # Sara "(I think I accidentally swallowed the first bit of cum he shot in my mouth, but there’s more and more coming!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:418
translate chinese SR3_we_bath_a8eb67c1:

    # Sara "(Oh shit, there’s waaaayyy too much!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:419
translate chinese SR3_we_bath_3cd76510:

    # MC "Ohh... Fuck... That was amazing, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:421
translate chinese SR3_we_bath_af10e58b:

    # MC "Jesus, you look so fucking hot right now. Do you think you can do me a favour, Sara? Can you swallow it for me?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:422
translate chinese SR3_we_bath_301b6e6e:

    # Sara "Mmm hmm."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:423
translate chinese SR3_we_bath_18bd41c0:

    # Sara "*Gulp* *Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:424
translate chinese SR3_we_bath_d2006bfe:

    # MC "Open wide, let me see."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:426
translate chinese SR3_we_bath_e18805dc:

    # Sara "Ahh..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:427
translate chinese SR3_we_bath_e1b2b7a0:

    # MC "Fuck, you’re amazing. Thanks for letting me cum inside. It was amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:429
translate chinese SR3_we_bath_2c6079e3:

    # Sara "*Cough* N-No problem. Sorry I never got the chance to go deeper. I was about to try taking you down my throat, and then you suddenly came."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:430
translate chinese SR3_we_bath_d83a6f94:

    # MC "Haha, don’t worry about it. Your mouth felt fucking amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:433
translate chinese SR3_we_bath_55fd1381:

    # Sara "Thanks. Now, I seriously need to have a bath too. I’m all sweaty after that!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:435
translate chinese SR3_we_bath_63d42553:

    # Sara "I’ll get washed and dressed here. Head on over to the new shopping mall. I’ll meet you there when I’m ready."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:436
translate chinese SR3_we_bath_6e10d321:

    # MC "Sounds good to me! Where exactly do you want to meet?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:437
translate chinese SR3_we_bath_107c5be9:

    # Sara "Just in the main foyer will be fine."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:438
translate chinese SR3_we_bath_82a1676a:

    # MC "Great. I’ll see you there, Sara. I’m really looking forward to our date."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:439
translate chinese SR3_we_bath_b6afb773:

    # Sara "Me too. I’m so excited!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:440
translate chinese SR3_we_bath_36bae83a:

    # Sara "Apologies for not going deeper. We will try again in the future."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:444
translate chinese SR3_we_bath_91368a27_1:

    # MC "(The mall’s grand opening is going to attract a big crowd. There’s definitely going to be a few people from our college there.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:445
translate chinese SR3_we_bath_05f56a48:

    # MC "(It’s a good thing I told her to keep the date on the down low. It’s not worth risking the attention we could generate as a couple. Some other girl I’m dating could see us!) "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:447
translate chinese SR3_we_bath_e95e95be:

    # MC "(At the end of the day, the thing that matters the most is that we’re both safe.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:448
translate chinese SR3_we_bath_5e37870f:

    # MC "(God, she was so nervous when she was trying to ask me out. It might not be a formal date, but I’ll do my best to make today as special as I can for her.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:449
translate chinese SR3_we_bath_69bcab67_1:

    # MC "(Okay, time to run myself a bath and get washed.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:451
translate chinese SR3_we_bath_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:452
translate chinese SR3_we_bath_361d8973_1:

    # MC "(There’s no better way to wake up on the weekend, than a relaxing hot bath.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:454
translate chinese SR3_we_bath_8ec422c9:

    # Sara "(I still can’t believe he didn’t want to be seen dating me in public...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:455
translate chinese SR3_we_bath_5367f059:

    # Sara "(Is there someone else he has his eyes on? Or am I just being paranoid? Maybe I’m just not good enough for him?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:457
translate chinese SR3_we_bath_1649c203:

    # Sara "(What do I have to do to make him proud enough for him to call me his girlfriend in front of other people?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:458
translate chinese SR3_we_bath_10480b82:

    # Sara "(Maybe I should be more sexual? I’ve given him a couple of blowjobs and some anal - but maybe it isn’t enough for a horny guy like him.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:463
translate chinese SR3_we_bath_9f952e04_1:

    # Sara "Hey, mind if I join you?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:464
translate chinese SR3_we_bath_6a128959_1:

    # MC "Oh, hey Sara. Sure, c’mon in!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:467
translate chinese SR3_we_bath_3439b248_1:

    # MC "Just be careful. [Mom_name] or [Dad_name] didn’t see you come in here, did they?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:469
translate chinese SR3_we_bath_69c0310a_1:

    # MC "No one's at home? Can we be loud?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:470
translate chinese SR3_we_bath_1200f56d_1:

    # Sara "Relax, [Mom_name] just went out to the shops, and [Dad_name] probably went to the office for overtime."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:472
translate chinese SR3_we_bath_f4d7e3a8_1:

    # MC "*Phew* That’s a relief. I’m a little too old now to plausibly be sharing a bath with you."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:474
translate chinese SR3_we_bath_0960be1f:

    # MC "*Phew* That’s a relief. "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:476
translate chinese SR3_we_bath_2f3e44f7_1:

    # Sara "Hehe! Stop worrying, we’ll be fine. The only other person in the home is Caroline, and I think she’s just moping around in her room right now."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:477
translate chinese SR3_we_bath_55db7ccf_1:

    # MC "Okay, that’s good."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:478
translate chinese SR3_we_bath_360809c8_1:

    # MC "(Sara looks so fucking sexy, wearing nothing but those tight little denim shorts.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:480
translate chinese SR3_we_bath_c449d7f8_1:

    # MC "Y’know, if you’re planning on joining me in here, you’re gonna have to lose those shorts."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:481
translate chinese SR3_we_bath_abb9a0e1_1:

    # Sara "Oh, you mean these?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:483
translate chinese SR3_we_bath_ef8a3e29:

    # Sara "Enjoying the view?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:484
translate chinese SR3_we_bath_b39ef889_1:

    # MC "*Whistle*"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:486
translate chinese SR3_we_bath_07e47dd9_1:

    # MC "(Damn, her teenage ass is stunning!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:488
translate chinese SR3_we_bath_d1a3895e:

    # MC "(Damn, her ass is stunning!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:490
translate chinese SR3_we_bath_d19cd756_1:

    # Sara "I’ll join you in a second, [player_name]. I just have to grab my shampoo and a spare towel."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:491
translate chinese SR3_we_bath_b8b14f5a_1:

    # MC "Uh huh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:493
translate chinese SR3_we_bath_5eb044d6_1:

    # MC "(I can’t just wait in the bath! That ass is just begging to be pounded right now!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:494
translate chinese SR3_we_bath_ca68bf8c_1:

    # MC "(God, I’d love to just bend her over the sink, bury my shaft in her pussy and fuck her until her tight little hole cums around my cock.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:495
translate chinese SR3_we_bath_8c483c03_1:

    # Sara "Did you see where I left my-"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:497
translate chinese SR3_we_bath_efe8aed1_1:

    # Sara "Mmpff!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:498
translate chinese SR3_we_bath_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:500
translate chinese SR3_we_bath_9b96cfe0_1:

    # Sara "W-What happened to us bathing together? Hehe."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:501
translate chinese SR3_we_bath_8d46c167_1:

    # MC "You were tempting me. I couldn’t resist."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:502
translate chinese SR3_we_bath_6839f872_1:

    # Sara "So you thought you’d just surprise me with a passionate kiss?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:503
translate chinese SR3_we_bath_f2dbdc9a_1:

    # MC "Did it work?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:505
translate chinese SR3_we_bath_76be4c21_1:

    # Sara "Yeah... I liked it."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:507
translate chinese SR3_we_bath_d4f7fcbc_1:

    # MC "I missed you when you were grounded, you know that, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:509
translate chinese SR3_we_bath_884382f4_1:

    # MC "I missed you when you were at room reading books all day, you know that, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:510
translate chinese SR3_we_bath_37fe985f_1:

    # Sara "I missed seeing you too, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:512
translate chinese SR3_we_bath_27b4aec6_1:

    # Sara "Oh wow, I can feel your big guy between my thighs. You REALLY did miss me, huh?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:513
translate chinese SR3_we_bath_2910d3e5_1:

    # MC "Hmm? Oh, he isn’t even that big yet. Give him a moment."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:515
translate chinese SR3_we_bath_1aa768d3_1:

    # Sara "Oh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:516
translate chinese SR3_we_bath_e9a6d98d_1:

    # MC "Haha! See what I mean?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:517
translate chinese SR3_we_bath_f391bdf1_1:

    # Sara "Y-Yeah!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:518
translate chinese SR3_we_bath_7c68ae52_1:

    # MC "Do you fancy doing something naughty together before our date?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:520
translate chinese SR3_we_bath_a8457368_1:

    # MC "How does it feel when I slide my dick back and forth across your pussy like that?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:521
translate chinese SR3_we_bath_093e89f6_1:

    # Sara "Ah... It’s... It’s really nice..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:522
translate chinese SR3_we_bath_15973e11_1:

    # MC "I could just slip it inside right now. How about even just the tip?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:524
translate chinese SR3_we_bath_ff1b9a4a_2:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:525
translate chinese SR3_we_bath_1523d466_1:

    # MC "C’mon, you know you want it."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:526
translate chinese SR3_we_bath_7889b06a_1:

    # Sara "I do... but..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:527
translate chinese SR3_we_bath_5d0a696a_1:

    # Sara "(I can feel his cock brushing up against my vulva... If he really wanted to, he could plunge it into my pussy and pop my cherry right now.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:528
translate chinese SR3_we_bath_98ac3c45_1:

    # Sara "(I’m not ready for that yet. I don’t want my first time to be a quickie in a bathroom.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:530
translate chinese SR3_we_bath_a7f09b1f_1:

    # Sara "W-Wait, I’m not ready for sex. I don’t want my first time to be in the bathroom."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:531
translate chinese SR3_we_bath_57cd70fe_1:

    # MC "Heh, I understand that."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:536
translate chinese SR3_we_bath_def0a97b_1:

    # MC "How about you get down on your knees and suck my cock instead?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:538
translate chinese SR3_we_bath_29292df8_1:

    # Sara "Yeah! I can do that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:539
translate chinese SR3_we_bath_5039cdf2:

    # Sara "(I think it’s pretty clear he wants to fuck me. Maybe that’s why he’s holding off on making us official? Does he worry that I’m never going to let him do me?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:540
translate chinese SR3_we_bath_55171825_1:

    # MC "You look so sexy, Sara. God, your freckles are just adorable."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:541
translate chinese SR3_we_bath_5f188ab5:

    # Sara "Hehe, thanks.."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:543
translate chinese SR3_we_bath_ff1b9a4a_3:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:544
translate chinese SR3_we_bath_a123aa35_1:

    # MC "You okay there?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:545
translate chinese SR3_we_bath_ad23083a_1:

    # Sara "I... uh... kinda forgot how big your guy was up close."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:546
translate chinese SR3_we_bath_8d7f4393_1:

    # MC "Haha, don’t worry. We can do this another time if you want."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:548
translate chinese SR3_we_bath_d3437b0f_1:

    # Sara "No way! Do you not think I’m up to the challenge?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:549
translate chinese SR3_we_bath_6e3035ee_1:

    # MC "Mmm... "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:550
translate chinese SR3_we_bath_0d84dc08_1:

    # MC "(Her palm feels so warm wrapped around my shaft.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:551
translate chinese SR3_we_bath_3eb577c0_1:

    # MC "Go ahead, but don’t push yourself if you don’t want to."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:553
translate chinese SR3_we_bath_2307048b_1:

    # Sara "I’ve been practicing, you know?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:554
translate chinese SR3_we_bath_f5f9d61d_1:

    # MC "Practicing giving head?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:555
translate chinese SR3_we_bath_15562df7_1:

    # Sara "I’d been asking [Mom_name] for cucumbers and bananas to eat while I studied. Remember when I first started giving you blowjobs I could barely fit an inch in my mouth?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:557
translate chinese SR3_we_bath_6dc2d41b_1:

    # MC "Yeah, I remember. It was adorable though."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:559
translate chinese SR3_we_bath_8f963817_1:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe! The best part was, [Mom_name] never suspected a thing."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:561
translate chinese SR3_we_bath_a3e27abe_1:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:562
translate chinese SR3_we_bath_664028f3_1:

    # MC "Okay then, Sara. Let’s see what you’ve got."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:564
translate chinese SR3_we_bath_995d9e27_1:

    # Sara "(Okay Sara, deep breaths... You can do this. It’s just like a banana...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:566
translate chinese SR3_we_bath_1b0c0dea_1:

    # Sara "(You’ve practiced for this. You've read porn magazines and watched a lot of porn videos!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:567
translate chinese SR3_we_bath_bdd8cf62_1:

    # MC "Mmm... God that’s good... Keep stroking my cock like that."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:569
translate chinese SR3_we_bath_1d81783e_1:

    # Sara "Are you enjoying this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:571
translate chinese SR3_we_bath_b1e68492_1:

    # MC "Mmm... Oh yeah, it’s so good."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:572
translate chinese SR3_we_bath_73b9b423_1:

    # Sara "Well, it’s about to get a whole lot better."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:574
translate chinese SR3_we_bath_acbf6f41_1:

    # Sara "You’re so big and hard, [player_name]. I can feel it pulsing against my fingers."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:576
translate chinese SR3_we_bath_e3ade2cb_1:

    # MC "That just means I’m super excited."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:578
translate chinese SR3_we_bath_09d8181c_1:

    # MC "Alright, let’s see what you’ve taught yourself."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:579
translate chinese SR3_we_bath_df4e3519:

    # Sara "I’m about to blow your mind. Just close your eyes, relax, and enjoy the sensation of my mouth wrapped around your cock."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:581
translate chinese SR3_we_bath_676817a4_1:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:583
translate chinese SR3_we_bath_5800eb5b_1:

    # MC "Ohhh... fuck..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:584
translate chinese SR3_we_bath_a9389210_1:

    # Sara "Haha! I’m glad you like it!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:586
translate chinese SR3_we_bath_0111514d_1:

    # Sara "(Remember what you read on Judy’s Blog: the glans is the most sensitive part of the guy’s cock. If I focus my efforts on the tip of his dick, I’ll make him cum so much harder!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:587
translate chinese SR3_we_bath_9c363fd7_2:

    # Sara "*Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:588
translate chinese SR3_we_bath_327a84b0_1:

    # MC "Ahh... just like that... Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:590
translate chinese SR3_we_bath_40486528_2:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:591
translate chinese SR3_we_bath_4e6b387c_1:

    # MC "Mmm! Ugh... I missed your little mouth so fucking much, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:592
translate chinese SR3_we_bath_5ba0a8c7_1:

    # MC "(Her tongue is so wet and warm against my cock. Sara’s blowjobs are fuckin' incredible.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:594
translate chinese SR3_we_bath_4a4fc314_1:

    # Sara "*Mwah* *Lick*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:595
translate chinese SR3_we_bath_d17a2701_1:

    # MC "Hnnng... Mmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:596
translate chinese SR3_we_bath_315fcdd8_1:

    # MC "(She’s so cute, down there on her knees sucking my dick.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:598
translate chinese SR3_we_bath_6e3198d2_1:

    # Sara "(What was the next piece of advice that blog gave... Oh yeah! Move your head back and forth, allowing your lips to glide over the head of the penis.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:600
translate chinese SR3_we_bath_fb284e00_1:

    # Sara "*Shlurp* *Suck* *Shluuuurrrp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:602
translate chinese SR3_we_bath_63b87947_1:

    # MC "Ahhh... You definitely ARE getting better. Mmm!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:604
translate chinese SR3_we_bath_30554186_1:

    # MC "(Sara’s breasts were never the biggest, but they look so perky and perfect. Her skin looks phenomenal when the sunlight caresses it like that.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:605
translate chinese SR3_we_bath_9c363fd7_3:

    # Sara "*Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:606
translate chinese SR3_we_bath_ab7362ea_1:

    # MC "God, you’re fucking amazing, Sara... Don’t stop!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:608
translate chinese SR3_we_bath_259cb936_1:

    # MC "Mmm, please don’t stop!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:610
translate chinese SR3_we_bath_40486528_3:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:611
translate chinese SR3_we_bath_090c1266_1:

    # Sara "(His dick is starting to throb in my mouth. He must be REALLY enjoying this!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:613
translate chinese SR3_we_bath_79a290ea_1:

    # MC "This is brilliant, Sara, but do you think you can try going a bit deeper?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:615
translate chinese SR3_we_bath_00db2170_1:

    # Sara "Mmm hmm! *Shlurp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:617
translate chinese SR3_we_bath_77ffa74b_1:

    # Sara "*Glompfff*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:618
translate chinese SR3_we_bath_cf38225b_1:

    # MC "Mmm... That’s right. Just like that, Sara. Ugh! Fuck..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:619
translate chinese SR3_we_bath_e4bf86f3_1:

    # Sara "(What did Judy write next? Create a vacuum by sucking your cheeks in? I think that was it.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:621
translate chinese SR3_we_bath_196e8da8_1:

    # Sara "*Suuuuuccck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:622
translate chinese SR3_we_bath_8b2f405a_1:

    # MC "Oooohhh fuuucck... Oh Sara, that’s so fucking good!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:624
translate chinese SR3_we_bath_cb45b6d9:

    # MC "(I’m lucky [Mom_name] and [Dad_name] aren’t home, there’s no way I’ll be able to keep my voice down for the whole blowjob!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:626
translate chinese SR3_we_bath_0c0910c9:

    # MC "(I’m lucky nobody isn’t home! There’s no way I’ll be able to keep my voice down for the whole blowjob!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:628
translate chinese SR3_we_bath_f59a84ed_1:

    # Sara "*Suck* *Suck* *Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:629
translate chinese SR3_we_bath_0808dcbb_1:

    # MC "Oh! Oh fuck! Arrrghhh! Ugh! Yes! Yes Sara, don’t stop!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:630
translate chinese SR3_we_bath_957abfd8_1:

    # Sara "*Shlurp* *Slluurrrp* *SUCK*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:632
translate chinese SR3_we_bath_216e4bf0_1:

    # MC "I... *Hnnnhhh* I... I’m gonna..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:634
translate chinese SR3_we_bath_cf07efe5_1:

    # Sara "(What was I supposed to do after sucking my cheeks in? I can’t remember now. I think I’m supposed to start ‘deepthroating’ now, aren’t I?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:636
translate chinese SR3_we_bath_bd1c6d83_2:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:638
translate chinese SR3_we_bath_33044a28:

    # Sara "(Yeah, I’ll try taking his dick deeper into my mouth. I mean, he seems to be enjoying whatever I’m doing right now! I’m gonna do it! I’m gonna prove to him I’m the best girl he could possibly have!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:639
translate chinese SR3_we_bath_bd1c6d83_3:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:640
translate chinese SR3_we_bath_b38e805b_1:

    # MC "Fuuuck! Hnnnnggg!! Ugghhh! I’m cumming!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:642
translate chinese SR3_we_bath_c50ac75f_1:

    # Sara "Hmm?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:650
translate chinese SR3_we_bath_ff51b3ec_1:

    # Sara "Mmpplllfff! *Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:651
translate chinese SR3_we_bath_c33108ff_1:

    # MC "Ughhhh! Ohhh God, that’s amazing..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:652
translate chinese SR3_we_bath_834c250f_1:

    # Sara "(H-Holy shit! I was NOT expecting him to cum yet! I got WAY too distracted thinking about what to do next!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:654
translate chinese SR3_we_bath_6d184773_1:

    # Sara "(I think I accidentally swallowed the first bit of cum he shot in my mouth, but there’s more and more coming!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:655
translate chinese SR3_we_bath_a8eb67c1_1:

    # Sara "(Oh shit, there’s waaaayyy too much!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:656
translate chinese SR3_we_bath_3cd76510_1:

    # MC "Ohh... Fuck... That was amazing, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:658
translate chinese SR3_we_bath_af10e58b_1:

    # MC "Jesus, you look so fucking hot right now. Do you think you can do me a favour, Sara? Can you swallow it for me?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:659
translate chinese SR3_we_bath_301b6e6e_1:

    # Sara "Mmm hmm."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:660
translate chinese SR3_we_bath_18bd41c0_1:

    # Sara "*Gulp* *Gulp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:661
translate chinese SR3_we_bath_d2006bfe_1:

    # MC "Open wide, let me see."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:663
translate chinese SR3_we_bath_e18805dc_1:

    # Sara "Ahh..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:664
translate chinese SR3_we_bath_e1b2b7a0_1:

    # MC "Fuck, you’re amazing. Thanks for letting me cum inside. It was amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:666
translate chinese SR3_we_bath_2c6079e3_1:

    # Sara "*Cough* N-No problem. Sorry I never got the chance to go deeper. I was about to try taking you down my throat, and then you suddenly came."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:667
translate chinese SR3_we_bath_d83a6f94_1:

    # MC "Haha, don’t worry about it. Your mouth felt fucking amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:672
translate chinese SR3_we_bath_55fd1381_1:

    # Sara "Thanks. Now, I seriously need to have a bath too. I’m all sweaty after that!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:674
translate chinese SR3_we_bath_63d42553_1:

    # Sara "I’ll get washed and dressed here. Head on over to the new shopping mall. I’ll meet you there when I’m ready."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:675
translate chinese SR3_we_bath_6e10d321_1:

    # MC "Sounds good to me! Where exactly do you want to meet?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:676
translate chinese SR3_we_bath_107c5be9_1:

    # Sara "Just in the main foyer will be fine."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:677
translate chinese SR3_we_bath_c622b0d2:

    # MC "Great. I’ll see you there, Sara. I’m really looking forward to our day out."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:678
translate chinese SR3_we_bath_b6afb773_1:

    # Sara "Me too. I’m so excited!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:680
translate chinese SR3_we_bath_d81f8842:

    # MC "Just remember, don’t run up and kiss me or anything. We don’t want to look too romantic when we go out, okay? We’re supposed to be keeping this on the down low. You don’t want your whole class bullying you for dating your brother, do you?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:682
translate chinese SR3_we_bath_12a18112:

    # MC "Just remember, don’t run up and kiss me or anything. We don’t want to look too romantic when we go out, okay? We’re supposed to be keeping this on the down low. You don’t want your whole gossiping about your new relationship, do you?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_weekend_event.rpy:683
translate chinese SR3_we_bath_6af4b9f5:

    # Sara "*Sigh* Okay, [player_name]."
    Sara ""

