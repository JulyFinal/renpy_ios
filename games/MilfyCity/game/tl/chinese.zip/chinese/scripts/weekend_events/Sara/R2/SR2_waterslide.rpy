﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:25
translate chinese SR2_waterslide_label_258fa26c:

    # MC "We've already been there."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:38
translate chinese SR2_waterslide_label_8e7cace5:

    # MC "How about we try out the waterslides?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:39
translate chinese SR2_waterslide_label_50a9bef9:

    # Sara "Eh... I don’t know... I can’t swim very well."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:40
translate chinese SR2_waterslide_label_609d73ad:

    # MC "Relax. We’ll go down it together, and I’ll hold you when we go into the pool, okay?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:41
translate chinese SR2_waterslide_label_815432b2:

    # Sara "Promise?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:42
translate chinese SR2_waterslide_label_56130bdc:

    # MC "I promise."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:43
translate chinese SR2_waterslide_label_a22340ce:

    # Sara "*Gulp* I... I guess so, then..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:47
translate chinese SR2_waterslide_label_3530328c:

    # MC "Here we go. Do you want to climb up first?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:48
translate chinese SR2_waterslide_label_e6a6e00f:

    # Sara "It’s really high..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:49
translate chinese SR2_waterslide_label_3c0ec116:

    # MC "I can be right behind you."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:50
translate chinese SR2_waterslide_label_78821540:

    # Sara "And you’ll definitely hold onto me when we get into the water?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:57
translate chinese SR2_waterslide_label_6b247c23:

    # MC "Would you prefer it if I climbed up first?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:58
translate chinese SR2_waterslide_label_d226ab44:

    # Sara "Honestly? Yeah."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:59
translate chinese SR2_waterslide_label_bcca47df:

    # MC "No problem. I’ll start climbing the ladder now."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:63
translate chinese SR2_waterslide_label_3eaf4581:

    # MC "See? It’s perfectly safe."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:64
translate chinese SR2_waterslide_label_4bf37837:

    # MC "You aren’t scared of heights as well, are ya?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:65
translate chinese SR2_waterslide_label_997879ae:

    # Sara "Only when the heights are over water."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:69
translate chinese SR2_waterslide_label_4d3fc411:

    # MC "Like I said - I’ll be here and I’ll hold onto you once we get into the pool."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:70
translate chinese SR2_waterslide_label_7574043d:

    # Sara "(Wow... Those shorts are so tight on him. I can almost see the outline of his junk.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:71
translate chinese SR2_waterslide_label_2acee771:

    # MC "Is that okay, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:72
translate chinese SR2_waterslide_label_8dc8227c:

    # Sara "Huh?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:73
translate chinese SR2_waterslide_label_0a69679a:

    # MC "I said, I’ll hold onto you when we get into the pool."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:74
translate chinese SR2_waterslide_label_cd7cddef:

    # Sara "Oh yeah! That’s okay."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:79
translate chinese SR2_waterslide_label_92dbcacc:

    # MC "Go ahead - start climbing. I’ll be right behind you, to catch you if you fall."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:84
translate chinese SR2_waterslide_label_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:85
translate chinese SR2_waterslide_label_fbb46a4d:

    # Sara "I’ve been here so many times with friends, but I’ve never actually been in the deep part of the pool."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:86
translate chinese SR2_waterslide_label_2b511e77:

    # Sara "And I’ve definitely NEVER been on these slides before."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:87
translate chinese SR2_waterslide_label_6235f5b7:

    # MC "There’s a first time for everything."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:91
translate chinese SR2_waterslide_label_a380bb78:

    # MC "(Damn, she’s got a cute little ass.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:92
translate chinese SR2_waterslide_label_bde3ad79:

    # MC "(I’d love to squeeze and grope those asscheeks!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:93
translate chinese SR2_waterslide_label_269a93db:

    # Sara "I hope you’re not staring at my ass! Haha!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:94
translate chinese SR2_waterslide_label_bf16b103:

    # MC "Err... nope!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:100
translate chinese SR2_after_waterslide_menu_044df3b4:

    # MC "Okay, here we are. You’re holding onto my arm pretty tightly. Are you feeling okay?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:101
translate chinese SR2_after_waterslide_menu_57958c74:

    # Sara "J-Just a little n-n-nauseous."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:102
translate chinese SR2_after_waterslide_menu_8bdd1f11:

    # MC "Try to relax. Take some deep breaths."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:106
translate chinese SR2_after_waterslide_menu_559b9d16:

    # MC "You’re going to be fine. This isn’t a very deep pool, and you’re with one of the best swimmers in the world."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:107
translate chinese SR2_after_waterslide_menu_2867a290:

    # Sara "YOU are one of the best swimmers in the world?!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:108
translate chinese SR2_after_waterslide_menu_98805d2d:

    # MC "Of course I am! Haven’t you heard of [player_name] the fish?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:109
translate chinese SR2_after_waterslide_menu_52172029:

    # Sara "Hahaha!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:110
translate chinese SR2_after_waterslide_menu_b4fcb8f6:

    # MC "(I’ve got her laughing. Hopefully that takes her mind off her fears.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:114
translate chinese SR2_after_waterslide_menu_502a5aca:

    # MC "Just hold my hand and we’ll get into a position you feel safe with."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:115
translate chinese SR2_after_waterslide_menu_14943dce:

    # Sara "Umm... Am I too heavy to sit on your knee?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:116
translate chinese SR2_after_waterslide_menu_65178f5d:

    # MC "Of course not. You’re light as a feather."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:120
translate chinese SR2_after_waterslide_menu_2e84e7f8:

    # MC "See? You fit on my knee perfectly."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:121
translate chinese SR2_after_waterslide_menu_43417f87:

    # Sara "Hehe..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:122
translate chinese SR2_after_waterslide_menu_16dfab7d:

    # Sara "(I love the feeling of his warm hands wrapped around my belly.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:123
translate chinese SR2_after_waterslide_menu_011e8533:

    # Sara "(I just wish I could cuddle him like that every night.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:124
translate chinese SR2_after_waterslide_menu_fd69f28b:

    # MC "Ready to go?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:129
translate chinese SR2_after_waterslide_menu_49ca0a6a:

    # Sara "Yup!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:130
translate chinese SR2_after_waterslide_menu_96ade29f:

    # MC "I’ll hold on tight - don’t worry!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:131
translate chinese SR2_after_waterslide_menu_1f0258a6:

    # Sara "(Huh? What’s that hard thing poking at my ass?)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:135
translate chinese SR2_after_waterslide_menu_d3b35277:

    # MC "Wooo!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:136
translate chinese SR2_after_waterslide_menu_4995a412:

    # Sara "Woo-oooohhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:137
translate chinese SR2_after_waterslide_menu_406c7870:

    # Sara "(Oh my God! He’s got a boner again! It’s pressing into my vulva!)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:138
translate chinese SR2_after_waterslide_menu_4c639f8e:

    # MC "(Sounds like she’s enjoying this, waaaay more than I am!)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:142
translate chinese SR2_after_waterslide_menu_43d24b0e:

    # MC "(Hopefully she hasn’t noticed my hard cock.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:143
translate chinese SR2_after_waterslide_menu_2bcd0cd5:

    # MC "(I haven’t been able to shift it since I first saw her in her tight pink swimsuit.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:144
translate chinese SR2_after_waterslide_menu_8261b442:

    # Sara "Gulp!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:145
translate chinese SR2_after_waterslide_menu_8efd5795:

    # Sara "The water! Don’t let gooo!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:149
translate chinese SR2_after_waterslide_menu_86debd4d:

    # "SPLASH!"
    ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:150
translate chinese SR2_after_waterslide_menu_3311014c:

    # Sara "Ahh! Cold!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:151
translate chinese SR2_after_waterslide_menu_04784fa9:

    # MC "There we go! That’s your first time sliding into the pool!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:152
translate chinese SR2_after_waterslide_menu_7fed5d8d:

    # Sara "Don’t let go! Don’t let go!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:153
translate chinese SR2_after_waterslide_menu_0740b7a4:

    # MC "Relax! This is the shallow end! You can probably touch the bottom with your toes."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:154
translate chinese SR2_after_waterslide_menu_8dc8227c:

    # Sara "Huh?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:158
translate chinese SR2_after_waterslide_menu_5db553a9:

    # MC "See? Your nose is still above water."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:159
translate chinese SR2_after_waterslide_menu_b0734300:

    # Sara "(Thank God... That was scary.)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:160
translate chinese SR2_after_waterslide_menu_a0db9e96:

    # Sara "(I should probably confront him about his boner...)"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:166
translate chinese SR2_after_waterslide_menu_2b3013af:

    # Sara "Umm... going down the slide, I felt something hard."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:167
translate chinese SR2_after_waterslide_menu_1292b001:

    # MC "(Uh oh...)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:168
translate chinese SR2_after_waterslide_menu_16ea0d4b:

    # Sara "[player_name]... did you have an erection?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:172
translate chinese SR2_after_waterslide_menu_6cbbb813:

    # MC "Yeah... and I still do."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:173
translate chinese SR2_after_waterslide_menu_bd95fb16:

    # Sara "Is it because... because..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:174
translate chinese SR2_after_waterslide_menu_c78382eb:

    # MC "Because I’m with you?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:175
translate chinese SR2_after_waterslide_menu_7d6d77ec:

    # Sara "Yeah?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:176
translate chinese SR2_after_waterslide_menu_e463807b:

    # MC "Yeah, it is."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:180
translate chinese SR2_after_waterslide_menu_95858722:

    # Sara "But I'm not even naked... Didn't you look at some other girl?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:181
translate chinese SR2_after_waterslide_menu_77d25981:

    # MC "What!? No! Whenever I see something really sexy, my cock decides to go hard. I have no control over it around you..."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:182
translate chinese SR2_after_waterslide_menu_e4d4d453:

    # MC "It’s basically got a mind of its own."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:183
translate chinese SR2_after_waterslide_menu_29733cc1:

    # Sara "Huh?! You're making fun of me right now, am I right? Or are you just winding me up?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:184
translate chinese SR2_after_waterslide_menu_19ddfafb:

    # MC "No, it’s true. I am assuring you that I wasn't looking at any other girl."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:185
translate chinese SR2_after_waterslide_menu_267aa7cf:

    # Sara "Huh... That’s really strange."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:186
translate chinese SR2_after_waterslide_menu_9111be26:

    # MC "Is it? Can you control when you get wet?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:190
translate chinese SR2_after_waterslide_menu_10534591:

    # Sara "[player_name]...."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:191
translate chinese SR2_after_waterslide_menu_4e7b1bf7:

    # MC "Haha! You’re adorable when you get shy."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:192
translate chinese SR2_after_waterslide_menu_3d4217f4:

    # MC "Alright, let’s get out of the pool now before we both turn into prunes."
    MC ""

translate chinese strings:

    # game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:53
    old "Offer to climb up first."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_waterslide.rpy:53
    old "Tell Sara to start climbing, and that you’ll be right behind her."
    new ""

