﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:15
translate chinese SR2_Lemonade_label_258fa26c:

    # MC "We've already been there."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:29
translate chinese SR2_Lemonade_label_f1577324:

    # MC "Come to think of it, I’m actually quite thirsty."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:30
translate chinese SR2_Lemonade_label_02b547b1:

    # MC "Do you fancy grabbing something to drink?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:31
translate chinese SR2_Lemonade_label_0aaad7e7:

    # Sara "Sure! There’s a lemonade stand on the other side of the complex."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:32
translate chinese SR2_Lemonade_label_5dbd8299:

    # MC "Awesome! Let’s go."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:36
translate chinese SR2_Lemonade_label_890f7f93:

    # MC "Good call, Sara. I haven’t had a decent lemonade in months."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:37
translate chinese SR2_Lemonade_label_9b5fd26e:

    # Sara "Yeah, I’ve been here with Lily. It’s really good!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:38
translate chinese SR2_Lemonade_label_d32f9301:

    # Sara "Hey, when was the last time you went to the swimming pool?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:39
translate chinese SR2_Lemonade_label_5b0b1dd9:

    # MC "Damn... Years ago? I can’t even remember."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:40
translate chinese SR2_Lemonade_label_d0ec8707:

    # MC "All I know for certain, is that the last time I was there, I didn’t have a gorgeous girl sitting opposite me, in a cute swimsuit."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:44
translate chinese SR2_Lemonade_label_deaf6f99:

    # Sara "Hehe... Stop it! You’re gonna make me blush."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:45
translate chinese SR2_Lemonade_label_745beae5:

    # Sara "And weren’t you the one who said to cut back on flirting, in case we get caught?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:46
translate chinese SR2_Lemonade_label_4062a410:

    # MC "Relax. There’s nobody else here. We’ll be fine."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:56
translate chinese lemonade_menu_86871d96:

    # MC "Actually, Sara, can we talk about what happened with Lily in your bedroom the other day?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:60
translate chinese lemonade_menu_dceb2163:

    # Sara "W-What?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:61
translate chinese lemonade_menu_bf35c5f3:

    # MC "You threw a bottle across the room. It was quite clear that something we did pissed you off."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:65
translate chinese lemonade_menu_20455002:

    # Sara "I... Um...."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:66
translate chinese lemonade_menu_8139a16a:

    # MC "Actually, if you’re feeling too anxious to talk about it, don’t worry. We can chat about something else."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:67
translate chinese lemonade_menu_47a5e2f4:

    # Sara "N-No, it’s fine."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:68
translate chinese lemonade_menu_19f672d0:

    # Sara "I guess I just couldn’t stand the thought of you being with her. I might not seem to appear that way, but I can get very... jealous."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:69
translate chinese lemonade_menu_9e03f56a:

    # MC "Huh? Why?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:73
translate chinese lemonade_menu_24560a9e:

    # Sara "Why?! Just look at them with their perfect golden blonde hair and their big, beautiful breasts."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:74
translate chinese lemonade_menu_35903af6:

    # Sara "Then, take a look at me. What do I have? An A-cup, dull brown hair, and freckles."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:78
translate chinese lemonade_menu_63ed2c10:

    # Sara "I know that this thing between you and me won’t last forever."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:79
translate chinese lemonade_menu_915621eb:

    # Sara "You’re gonna move on to one of those big boobed, blonde haired bimbos someday. And then you’ll forget about plain little me."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:80
translate chinese lemonade_menu_d823c5dd:

    # MC "(Damn... I never realised she had confidence issues with her body. That’s another reason for her overreaction to Lily kissing me.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:81
translate chinese lemonade_menu_409d30da:

    # MC "Sara... You’re not plain."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:87
translate chinese lemonade_menu_8abe9292:

    # MC "There’s more to life than looks. Most of those ‘bimbos’ that you talk about have terrible personalities."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:88
translate chinese lemonade_menu_f54a78f0:

    # MC "You’re sweet, kind, and very very caring. I wouldn’t change you for the world."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:89
translate chinese lemonade_menu_60095dda:

    # Sara "... thanks. They’re still prettier than me though - and looks have to count for something."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:99
translate chinese lemonade_menu_304992a6:

    # MC "I don’t know why you’re so worried about the size of your breasts."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:100
translate chinese lemonade_menu_87c99393:

    # Sara "They’re tiny. Why do you think I wear a one piece swimsuit instead of a bikini?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:101
translate chinese lemonade_menu_c8892123:

    # Sara "I’ve got nothing to show off."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:102
translate chinese lemonade_menu_c9f38e8b:

    # MC "What are you talking about? Your breasts are amazing!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:103
translate chinese lemonade_menu_9a8c4029:

    # MC "Some guys like big boobs - I’ll give you that."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:107
translate chinese lemonade_menu_c266d54f:

    # MC "Other guys LOVE small tits though, and yours are fucking adorable."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:108
translate chinese lemonade_menu_021c0ac5:

    # MC "Plus, smaller breasts tend to have more sensitive nipples."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:109
translate chinese lemonade_menu_e09d97de:

    # Sara "[player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:110
translate chinese lemonade_menu_05512731:

    # MC "It’s just a fact! Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:114
translate chinese lemonade_menu_8fd0e99a:

    # Sara "Well... maybe someday we can try out your small breast sensitivity theory."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:115
translate chinese lemonade_menu_03a0c6cd:

    # MC "I’m looking forward to that."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:126
translate chinese lemonade_menu_a298a9ca:

    # MC "Sara, look up at me."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:127
translate chinese lemonade_menu_2c04d20e:

    # Sara "Hmm?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:131
translate chinese lemonade_menu_36245511:

    # MC "They’re absolutely perfect."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:132
translate chinese lemonade_menu_375a1990:

    # Sara "Don’t lie. I’ve always wanted, AT LEAST a C-cup."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:133
translate chinese lemonade_menu_b834ecda:

    # MC "I’m not talking about your breasts. I’m talking about your eyes."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:137
translate chinese lemonade_menu_8dc8227c:

    # Sara "Huh?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:138
translate chinese lemonade_menu_d6f05572:

    # MC "They’re the most stunning shade of emerald green."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:139
translate chinese lemonade_menu_8ba45b93:

    # MC "I think you’re focusing so much on the parts of you that you don’t like, that you don’t realise how amazing other parts of you actually are."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:140
translate chinese lemonade_menu_a87e6b06:

    # MC "You’ve got the most beautiful irises I’ve ever seen."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:141
translate chinese lemonade_menu_34f5f756:

    # Sara "Th-thank you, [player_name]..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:151
translate chinese lemonade_menu_57b6b455:

    # MC "Can we talk about that blowjob you gave me?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:155
translate chinese lemonade_menu_79a774b8:

    # Sara "We’re in public! Shush!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:156
translate chinese lemonade_menu_614c9f12:

    # Sara "What if someone from college hears us right now?!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:157
translate chinese lemonade_menu_e87653e0:

    # Sara "It would be even more embarrassing than when you tried to ask your professor out!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:158
translate chinese lemonade_menu_f67022e9:

    # MC "Can we try not to talk about that?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:159
translate chinese lemonade_menu_fd15952b:

    # Sara "Haha! Okay..."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:163
translate chinese lemonade_menu_55fd1c98:

    # Sara "We can talk about the blowjob in private someday."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:164
translate chinese lemonade_menu_03a0c6cd_1:

    # MC "I’m looking forward to that."
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:174
translate chinese after_lemonade_menu_4632ead0:

    # Sara "Anyway! We’ve spent long enough here."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:175
translate chinese after_lemonade_menu_f1ac1ffa:

    # Sara "I’ll race you to finish your drink!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:176
translate chinese after_lemonade_menu_695b9b9e:

    # MC "Sure! Ready whenever you-"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:180
translate chinese after_lemonade_menu_b7d6218f:

    # Sara "*SHLURP SHLURP*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:181
translate chinese after_lemonade_menu_59a35a91:

    # Sara "*GULP GULP*"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:185
translate chinese after_lemonade_menu_81093956:

    # Sara "I win!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:186
translate chinese after_lemonade_menu_bba05c64:

    # MC "(Holy shit! I barely had a chance to bring the straw to my mouth.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:187
translate chinese after_lemonade_menu_e3e0379a:

    # MC "Fine, you win! "
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:188
translate chinese after_lemonade_menu_fa553ba3:

    # Sara "Yay! I’ll let you finish off there, then we can head elsewhere whenever you’re ready to go."
    Sara ""

translate chinese strings:

    # game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:52
    old "Can I talk to you about what happened with Lily?"
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:52
    old "Can we talk about that blowjob you gave me?"
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:83
    old "Compliment her personality."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:83
    old "Compliment her breasts."
    new ""

    # game/scripts/weekend_events/Sara/R2/SR2_Lemonade.rpy:83
    old "Compliment her eyes."
    new ""

