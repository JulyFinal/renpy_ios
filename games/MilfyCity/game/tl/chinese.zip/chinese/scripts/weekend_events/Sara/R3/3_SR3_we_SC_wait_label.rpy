﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:17
translate chinese SR3_SC_floor2_wait_locked_aee66e3a:

    # MC "(Sara is waiting for me.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:33
translate chinese SR3_we_SC_wait_label_171ca2d5:

    # MC "(Oh wow! That dress is so skimpy! Sara looks really hot in it!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:34
translate chinese SR3_we_SC_wait_label_0a05a0ab:

    # MC "Sara! You look incredible!"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:36
translate chinese SR3_we_SC_wait_label_712233a5:

    # Sara "[player_name]! I’m glad you like it! I chose it especially for you. It isn’t too revealing, is it?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:37
translate chinese SR3_we_SC_wait_label_549582f7:

    # MC "That’s the best part about it!"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:38
translate chinese SR3_we_SC_wait_label_9ccb9eeb:

    # Sara "Haha, you perv!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:40
translate chinese SR3_we_SC_wait_label_9404b57d:

    # MC "Seriously though, you look absolutely amazing right now. You’re the cutest person in the whole mall."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:41
translate chinese SR3_we_SC_wait_label_bd80a77a:

    # Sara "Aww, stooop... You’re gonna make me blush."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:43
translate chinese SR3_we_SC_wait_label_72ac9ddb:

    # MC "Haha, it’s true though. You look good."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:44
translate chinese SR3_we_SC_wait_label_a84d5f18:

    # Sara "Thanks for coming today, [player_name]. This date really means a lot to me."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:45
translate chinese SR3_we_SC_wait_label_433b502a:

    # MC "I know. It means a lot to me too, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:46
translate chinese SR3_we_SC_wait_label_31ef9923:

    # Sara "I’m glad to hear you say that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:48
translate chinese SR3_we_SC_wait_label_08d744a1:

    # MC "So, where do you want to head first? I remember you mentioned something about an ice cream parlour opening up here."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:50
translate chinese SR3_we_SC_wait_label_546b7a64:

    # Sara "Yeah! It’s the same chain Caroline used to take me to when I was just a kid, Thick n’ Creamy!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:52
translate chinese SR3_we_SC_wait_label_e82d5d30:

    # Sara "Yeah, it's the same chain Caroline and I used to go to when we first moved in to Linda's place together - Thick n' Creamy!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:53
translate chinese SR3_we_SC_wait_label_06e1c025:

    # MC "They actually named their brand ‘Thick n’ Creamy’?"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:54
translate chinese SR3_we_SC_wait_label_0eb58beb:

    # Sara "I mean, why not? It describes it perfectly!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:56
translate chinese SR3_we_SC_wait_label_5afbadde:

    # MC "(Sara’s outfit is super cute, but it’s also a wardrobe malfunction waiting to happen.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:57
translate chinese SR3_we_SC_wait_label_36a27893:

    # MC "(I mean, her skirt is so short that I can practically see her panties. And if that dress slips even a little bit, she’ll be exposing her boobs to the whole mall!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:58
translate chinese SR3_we_SC_wait_label_654866d2:

    # MC "How long has it been since you last went to Thick n’ Creamy?"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:61
translate chinese SR3_we_SC_wait_label_bf93662e:

    # Sara "Oh geez... It must be... five or six years since Caroline and I last went out together."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:62
translate chinese SR3_we_SC_wait_label_ad2bdfe6:

    # MC "Come to think of it, I hardly ever see you two hanging out. What happened?"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:64
translate chinese SR3_we_SC_wait_label_76a6d0a4:

    # Sara "Oh geez... It must be... Five or six months since Caroline and I last went out together."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:65
translate chinese SR3_we_SC_wait_label_18fdf8ef:

    # MC "She was older than I am, so we had different interests and hobbies."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:66
translate chinese SR3_we_SC_wait_label_c6f1ac89:

    # Sara "We just grew apart, y’know? She’s older than I am, so she matured quicker and found her own hobbies and interests."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:68
translate chinese SR3_we_SC_wait_label_86e83a05:

    # Sara "She’s been focused on her relationships, education, and starting a business, these past few years. I think I just sorta fell off her radar."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:70
translate chinese SR3_we_SC_wait_label_219ac96c:

    # MC "I’m sorry, Sara. Y’know, [Dad_name] gave me some advice once. It’s never too late to try and reconnect with family if you ever lose touch."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:72
translate chinese SR3_we_SC_wait_label_c84e5288:

    # MC "I’m sorry, Sara. Y’know, [Dad_name] gave me some advice once. It’s never too late to try and reconnect with people if you ever lose touch."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:73
translate chinese SR3_we_SC_wait_label_9eb923ed:

    # MC "I mean, the fact that this mall has opened so close to our home, gives you the perfect opportunity to ask Caroline out for the day. Go and spend some time together with her. Do some shopping, grab an ice cream together, for old time’s sake."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:75
translate chinese SR3_we_SC_wait_label_085b30b2:

    # Sara "Thanks, [player_name]. I think you’re right. I’ll speak with her later this week."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:76
translate chinese SR3_we_SC_wait_label_f756f9d4:

    # MC "Good to hear."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:78
translate chinese SR3_we_SC_wait_label_5d4f6a9e:

    # Sara "Anyway! Thick n’ Creamy have their parlour and an ice cream van today! How about we get it from the van and walk around the mall?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:79
translate chinese SR3_we_SC_wait_label_9879a67c:

    # MC "Sounds good to me!"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:80
translate chinese SR3_we_SC_wait_label_dc8bca7d:

    # Sara "C’mon! This way!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:84
translate chinese SR3_we_SC_wait_label_68b26251:

    # Sara "(I hope [player_name] shows up...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:85
translate chinese SR3_we_SC_wait_label_a3213430:

    # Sara "(He said he wanted our date to be kept on the down low so people wouldn’t notice us together. Maybe he was just saying that because I put too much pressure on him in my room?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:86
translate chinese SR3_we_SC_wait_label_37cf3fcb:

    # Sara "(Maybe he just won’t come at all...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:87
translate chinese SR3_we_SC_wait_label_ee9abf02:

    # MC "Hey, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:89
translate chinese SR3_we_SC_wait_label_3bc76220:

    # Sara "[player_name]! You came!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:90
translate chinese SR3_we_SC_wait_label_1eb546b5:

    # MC "Haha, of course I did. I wasn’t gonna miss the opening of the new mall after all!"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:92
translate chinese SR3_we_SC_wait_label_db895cea:

    # Sara "Oh, right... Yeah..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:93
translate chinese SR3_we_SC_wait_label_30f10e63:

    # Sara "Umm, are we still doing the ‘secret date’? Do you think we could maybe make it official and just let everyone know we’re together?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:94
translate chinese SR3_we_SC_wait_label_20fad66d:

    # MC "Sorry Sara, half our college looks like they’re here today. (Other girls could be here too...)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:95
translate chinese SR3_we_SC_wait_label_3e06a7f0:

    # MC "(Plus, it would be super awkward if someone else I’m romantically interested in saw me dating Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:97
translate chinese SR3_we_SC_wait_label_5b5f7c04:

    # Sara "*Sigh* That’s okay..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:98
translate chinese SR3_we_SC_wait_label_9c8f7ed5:

    # Sara "(I was really hoping he’d change his mind about this. I guess I just haven’t proven myself worthy to be his girlfriend in public yet...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:99
translate chinese SR3_we_SC_wait_label_1f126c32:

    # Sara "(Maybe I need to do more, or treat him better? I guess the blowjob I gave him in the bathroom wasn’t good enough.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:101
translate chinese SR3_we_SC_wait_label_fb8691e9:

    # MC "So, where’s this great ice cream parlour you were talking about? The one you and Caroline used to go to?"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:102
translate chinese SR3_we_SC_wait_label_396b5a40:

    # Sara "The one we used to go to was in a different city. She used to drive us over there after college. This is just another franchise opening."
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:103
translate chinese SR3_we_SC_wait_label_0dcee81e:

    # MC "Ahh, fair enough."
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:105
translate chinese SR3_we_SC_wait_label_339d6eec:

    # Sara "They’ve actually got the ice cream parlour set up as well as a van. Do you want to sit in and grab an ice cream, or get one to take away and we’ll walk around the mall?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:106
translate chinese SR3_we_SC_wait_label_cc8fdaa2:

    # MC "(It’s gonna look less like a date if we’re just walking together.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:107
translate chinese SR3_we_SC_wait_label_4a9ce177:

    # MC "How about we just grab a couple of cones from the van and walk around?"
    MC ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:109
translate chinese SR3_we_SC_wait_label_1cde300a:

    # Sara "Sure, no problem. It’s over this way!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:110
translate chinese SR3_we_SC_wait_label_ca39c3ff:

    # Sara "(I shouldn’t beat myself up too much. [player_name] still showed up today! That means he’s still interested in me. If he didn’t want to date me, he never would have come at all! I think he just needs some time before making this public.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:111
translate chinese SR3_we_SC_wait_label_34d120ec:

    # Sara "(I just have to focus on being the most awesome girlfriend I can be, then he’ll want EVERYONE to know we’re together!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/3_SR3_we_SC_wait_label.rpy:112
translate chinese SR3_we_SC_wait_label_6a953d02:

    # Sara "Hurry up! Let’s go! You’re buying! Hehe!"
    Sara ""

