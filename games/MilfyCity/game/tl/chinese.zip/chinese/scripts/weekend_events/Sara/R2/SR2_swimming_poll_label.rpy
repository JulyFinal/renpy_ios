﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:35
translate chinese SR2_weekend_swimming_pool_label_bf6b8989:

    # MC "(Alright, that’s me changed and ready to swim.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:36
translate chinese SR2_weekend_swimming_pool_label_8059b626:

    # MC "(Now... where the heck is Sara?)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:37
translate chinese SR2_weekend_swimming_pool_label_d0a49b33:

    # MC "(It’s not even that busy today.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:41
translate chinese SR2_weekend_swimming_pool_label_db67ec8f:

    # Sara "Hi, [player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:42
translate chinese SR2_weekend_swimming_pool_label_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:43
translate chinese SR2_weekend_swimming_pool_label_23cbb995:

    # Sara "Sorry! Did I scare you, there?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:44
translate chinese SR2_weekend_swimming_pool_label_8eaf984b:

    # MC "Just a bit!"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:45
translate chinese SR2_weekend_swimming_pool_label_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:49
translate chinese SR2_weekend_swimming_pool_label_a96510c6:

    # Sara "MWAH!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:50
translate chinese SR2_weekend_swimming_pool_label_360d5ece:

    # MC "(Wow! I’ve never seen her this giddy before. She must be really happy to go on this date with me.)"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:51
translate chinese SR2_weekend_swimming_pool_label_8980272d:

    # Sara "I’m so happy you’re here!"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:52
translate chinese SR2_weekend_swimming_pool_label_fa85375d:

    # MC "Me too, Sara. Were you waiting long?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:56
translate chinese SR2_weekend_swimming_pool_label_910a2123:

    # Sara "Just a few minutes."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:57
translate chinese SR2_weekend_swimming_pool_label_d8b3e6a4:

    # Sara "What do you want to do together?"
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:58
translate chinese SR2_weekend_swimming_pool_label_ae33f34d:

    # MC "Want to dip in the pool?"
    MC ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:59
translate chinese SR2_weekend_swimming_pool_label_151f13e0:

    # Sara "Umm... I can’t swim."
    Sara ""

# game/scripts/weekend_events/Sara/R2/SR2_swimming_poll_label.rpy:60
translate chinese SR2_weekend_swimming_pool_label_edde4676:

    # MC "Oh yeah, I totally forgot. Sorry."
    MC ""

