﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/shopping_centre.rpy:6
translate chinese SC_label_M1_09078f31:

    # MC "Closed. It's open only at the morning and in the afternoon."
    MC ""

