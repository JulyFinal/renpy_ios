﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:389
translate chinese CR4_WE_dinner_lab_fd643454:

    # Caroline "And... here we are!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:390
translate chinese CR4_WE_dinner_lab_0e9fbb43:

    # Caroline "(I really hope he likes this place. Not everyone is keen on Japanese cuisine.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:393
translate chinese CR4_WE_dinner_lab_ab42ad12:

    # MC "Oh wow... It’s gorgeous here!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:394
translate chinese CR4_WE_dinner_lab_bbc53379:

    # MC "This place looks super expensive. How much does it cost here?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:395
translate chinese CR4_WE_dinner_lab_51b32bd9:

    # Caroline "Hehe, let me put it this way... they don’t put prices on the menu."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:398
translate chinese CR4_WE_dinner_lab_594615b4:

    # MC "Yikes..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:399
translate chinese CR4_WE_dinner_lab_383aceb6:

    # Caroline "Relax [player_name], I can afford it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:400
translate chinese CR4_WE_dinner_lab_3935df40:

    # MC "Are you sure? I mean-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:403
translate chinese CR4_WE_dinner_lab_b16b1c03:

    # Caroline "Business is booming. What you see in store is only a FRACTION of my total sales."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:404
translate chinese CR4_WE_dinner_lab_670deea2:

    # Caroline "The online half has really taken off - especially with those photos you helped take for my advertisements."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:405
translate chinese CR4_WE_dinner_lab_c3450311:

    # Caroline "Tonight is on me, okay? Think of it as a way for me to say thank you for everything you’ve done."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:408
translate chinese CR4_WE_dinner_lab_3f97b4c3:

    # MC "Caroline... That’s far too generous."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:409
translate chinese CR4_WE_dinner_lab_8a6e9cb1:

    # Caroline "Nonsense. Relax and enjoy tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:410
translate chinese CR4_WE_dinner_lab_d6a343e2:

    # Caroline "Oh, I hope you like Japanese food, by the way. I absolutely LOVE the stuff!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:411
translate chinese CR4_WE_dinner_lab_a1989960:

    # MC "Yeah, I love Japanese food too..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:414
translate chinese CR4_WE_dinner_lab_0b2342ef:

    # MC "Not as much as I love you, of course."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:415
translate chinese CR4_WE_dinner_lab_4b0eb6a4:

    # Caroline "Hehe, you’re a charmer, aren’t you?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:418
translate chinese CR4_WE_dinner_lab_60f07548:

    # Caroline "How about we go and sit down over there?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:419
translate chinese CR4_WE_dinner_lab_8c7c13e1:

    # MC "Ladies first."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:422
translate chinese CR4_WE_dinner_lab_3ecc52e4:

    # MC "The ambience here is amazing - I love the candles."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:423
translate chinese CR4_WE_dinner_lab_71093702:

    # Caroline "Well, for the best Japanese restaurant in town, I wouldn’t expect any less."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:424
translate chinese CR4_WE_dinner_lab_59f2fa8d:

    # MC "Have you been here before?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:427
translate chinese CR4_WE_dinner_lab_4f6391fe:

    # Caroline "Yes, I come here every now and then, when things are going especially well in my life."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:428
translate chinese CR4_WE_dinner_lab_266479d2:

    # Caroline "Some people take pick-me-ups when they’re feeling down. I like to take small rewards when I’m feeling good."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:429
translate chinese CR4_WE_dinner_lab_0e48c2c7:

    # MC "Huh, why don’t you come here when you’re down? Surely that would help cheer you up?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:432
translate chinese CR4_WE_dinner_lab_9d203405:

    # Caroline "A couple of reasons actually... Firstly, I don’t want to have this place tainted with loads of unhappy memories."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:433
translate chinese CR4_WE_dinner_lab_66397daf:

    # Caroline "I like keeping this place special. It means a lot to me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:434
translate chinese CR4_WE_dinner_lab_6fca4061:

    # MC "Thank you for inviting me here, then."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:437
translate chinese CR4_WE_dinner_lab_5e7fb38f:

    # Caroline "I just hope you enjoy it here as much as I do. The salmon is to die for!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:438
translate chinese CR4_WE_dinner_lab_7ed9b5af:

    # MC "And the second reason?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:439
translate chinese CR4_WE_dinner_lab_bc4628d7:

    # Caroline "Hmm?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:440
translate chinese CR4_WE_dinner_lab_8f0810bc:

    # MC "You said there were two reasons you didn’t come to this place when you were feeling sad."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:443
translate chinese CR4_WE_dinner_lab_594ff6b7:

    # Caroline "Oh, haha... yeah."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:444
translate chinese CR4_WE_dinner_lab_04a54c0c:

    # Caroline "I used to feel like shit, A LOT of the time. I couldn’t exactly afford to come here, three or four nights per week."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:445
translate chinese CR4_WE_dinner_lab_4bfdf3a0:

    # Caroline "Sometimes it’s just cheaper to see your doctor and take your antidepressants."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:448
translate chinese CR4_WE_dinner_lab_7ce9c59d:

    # MC "You were on antidepressants? Sorry, I never realised."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:449
translate chinese CR4_WE_dinner_lab_6ae76c0f:

    # Caroline "It’s okay. There’s a lot of things I kept to myself when I was dating Charles. I’m better now though, okay?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:450
translate chinese CR4_WE_dinner_lab_ae95ddba:

    # MC "Do you promise?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:453
translate chinese CR4_WE_dinner_lab_a7f659ca:

    # Caroline "Hehe, don’t look so worried. It’s fine."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:454
translate chinese CR4_WE_dinner_lab_0c122e17:

    # MC "I just never imagined you as the kind of person who-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:455
translate chinese CR4_WE_dinner_lab_0fdcb924:

    # Caroline "It can happen to anyone. Besides, I got better. And you helped. I took my last pill a few days after our photography sessions began."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:458
translate chinese CR4_WE_dinner_lab_515ac2ad:

    # MC "Even still... I wish I was aware, so I could at least talk to you about it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:459
translate chinese CR4_WE_dinner_lab_4ed4523e:

    # Caroline "How about we talk about this another time? Let’s just enjoy dinner together, and leave the past where it belongs."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:460
translate chinese CR4_WE_dinner_lab_566041b8:

    # MC "Oh, speaking of putting something back where it belongs..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:463
translate chinese CR4_WE_dinner_lab_e22e9cd5:

    # Caroline "Hmm? What is it [player_name]?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:464
translate chinese CR4_WE_dinner_lab_e55b2935:

    # MC "I... uh... I have something for you here. A small gift."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:465
translate chinese CR4_WE_dinner_lab_2dd316fb:

    # Caroline "Aww, you shouldn’t have."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:468
translate chinese CR4_WE_dinner_lab_9cdb6a44:

    # Caroline "I hope you didn’t spend TOO much money on it, now."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:469
translate chinese CR4_WE_dinner_lab_07ceb1df:

    # MC "I didn’t spend a single cent."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:470
translate chinese CR4_WE_dinner_lab_34c8a04a:

    # Caroline "Now I’m intrigued!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:473
translate chinese CR4_WE_dinner_lab_69fb97b4:

    # MC "Ta-da!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:474
translate chinese CR4_WE_dinner_lab_3aa268d9:

    # Caroline "What is it?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:475
translate chinese CR4_WE_dinner_lab_81b189c9:

    # MC "Go on, take it. Open it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:478
translate chinese CR4_WE_dinner_lab_231dcb39:

    # Caroline "(Huh... rectangular box? I wonder what it is.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:479
translate chinese CR4_WE_dinner_lab_7a502ef5:

    # Caroline "(A mobile phone perhaps? Nah... too narrow to be that.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:480
translate chinese CR4_WE_dinner_lab_a9f4a0b4:

    # MC "You’ll love it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:487
translate chinese CR4_WE_dinner_lab_129fb178:

    # Caroline "Oh, my God!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:488
translate chinese CR4_WE_dinner_lab_203b04b8:

    # MC "I told you that you’d love it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:489
translate chinese CR4_WE_dinner_lab_a29dadb3:

    # Caroline "Oh, my God... Oh, my God! How did you-"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:492
translate chinese CR4_WE_dinner_lab_439d57b1:

    # MC "Are you happy?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:493
translate chinese CR4_WE_dinner_lab_5e9bb12c:

    # Caroline "Oh, my God..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:494
translate chinese CR4_WE_dinner_lab_24613cac:

    # MC "I’ll take that as a yes?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:497
translate chinese CR4_WE_dinner_lab_faff02f1:

    # Caroline "How did you- How did you FIND this?!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:498
translate chinese CR4_WE_dinner_lab_88698b19:

    # MC "Not easily! Haha, I’m glad you have it back now though."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:501
translate chinese CR4_WE_dinner_lab_8d1bfb66:

    # Caroline "I LOVE YOU! I love you so so much!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:502
translate chinese CR4_WE_dinner_lab_99832371:

    # Caroline "Thank you, thank you, thank you!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:503
translate chinese CR4_WE_dinner_lab_8697cb9b:

    # MC "Haha, whoa!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:506
translate chinese CR4_WE_dinner_lab_7c591e7d:

    # Caroline "*Sniff* You’re the best!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:507
translate chinese CR4_WE_dinner_lab_6abefe3a:

    # MC "I know I am."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:508
translate chinese CR4_WE_dinner_lab_21ba8e15:

    # Caroline "Haha! God, I love you so much. This is the BEST present I could have ever asked for."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:511
translate chinese CR4_WE_dinner_lab_4dbbd621:

    # Caroline "How did you get it back?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:512
translate chinese CR4_WE_dinner_lab_966ed59d:

    # MC "I’ll tell you some other time. It’s a long story."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:513
translate chinese CR4_WE_dinner_lab_23176ce1:

    # MC "Now, how about we get you back into your chair and we’ll put your necklace back on you, where it belongs."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:516
translate chinese CR4_WE_dinner_lab_c7d05cc9:

    # Caroline "How did I get so lucky? You’re the best, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:517
translate chinese CR4_WE_dinner_lab_f9f950f6:

    # Caroline "Ahh! I’m so excited, I just want to kiss you!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:518
translate chinese CR4_WE_dinner_lab_49e0d993:

    # MC "(I don’t think I’ve ever seen someone so elated, in my life!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:521
translate chinese CR4_WE_dinner_lab_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:522
translate chinese CR4_WE_dinner_lab_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:523
translate chinese CR4_WE_dinner_lab_1b53bc1a:

    # Caroline "(I knew [player_name] was the right guy... I just wish I’d seen it sooner.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:526
translate chinese CR4_WE_dinner_lab_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:527
translate chinese CR4_WE_dinner_lab_ec259635:

    # MC "(Wow, I knew Caroline would be happy getting her necklace back. I never imagined she would be THIS excited though!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:530
translate chinese CR4_WE_dinner_lab_634c1ab6:

    # Caroline "Mwah!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:531
translate chinese CR4_WE_dinner_lab_6f08c543:

    # Caroline "(This is so perfect! I thought I had planned the best evening possible for [player_name]. He’s done more for me than I could have ever done for him.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:534
translate chinese CR4_WE_dinner_lab_ef3a27d9:

    # MC "That was spontaneous! Haha!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:535
translate chinese CR4_WE_dinner_lab_3ed235e8:

    # Caroline "S-Sorry about that, I got a little carried away in heat of the moment."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:536
translate chinese CR4_WE_dinner_lab_e91191ed:

    # MC "It’s okay. How about we sit back down?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:539
translate chinese CR4_WE_dinner_lab_107d22bc:

    # Caroline "Are you not sitting down too?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:540
translate chinese CR4_WE_dinner_lab_2447c043:

    # MC "Just one moment. Sit right there."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:541
translate chinese CR4_WE_dinner_lab_347429bd:

    # Caroline "Huh?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:544
translate chinese CR4_WE_dinner_lab_de68e802:

    # MC "I’m just putting your necklace back where it belongs."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:545
translate chinese CR4_WE_dinner_lab_09d06ab8:

    # "*Click*"
    ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:546
translate chinese CR4_WE_dinner_lab_ff6402f6:

    # Caroline "Thank you, [player_name]. You didn’t have to do that."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:549
translate chinese CR4_WE_dinner_lab_6fb6fab0:

    # MC "And there we go. That should be it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:550
translate chinese CR4_WE_dinner_lab_a7ead6d3:

    # MC "Let’s turn around and get a look at you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:553
translate chinese CR4_WE_dinner_lab_6c875c17:

    # Caroline "It’s perfect... not even damaged."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:554
translate chinese CR4_WE_dinner_lab_e49d37d5:

    # MC "I guess we’re lucky."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:555
translate chinese CR4_WE_dinner_lab_739e0131:

    # Caroline "I like the box it came in. Where did you get that?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:558
translate chinese CR4_WE_dinner_lab_3126c501:

    # MC "(I can’t exactly tell her that I got it from the Dean who is also a major Milfy City crime lord!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:559
translate chinese CR4_WE_dinner_lab_3ba8ff3c:

    # MC "Ahh... I can’t remember now. Some shop, here or there."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:560
translate chinese CR4_WE_dinner_lab_8b17a4d5:

    # Caroline "Well, it suits the necklace very nicely."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:563
translate chinese CR4_WE_dinner_lab_142ec6f4:

    # Caroline " Seriously, [player_name], you’re amazing."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:565
translate chinese CR4_WE_dinner_lab_75efeb46:

    # Caroline "I can’t even begin to imagine what kind of detective work you had to do to track Gran’s necklace down."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:567
translate chinese CR4_WE_dinner_lab_f2dd5684:

    # Caroline "I can’t even begin to imagine what kind of detective work you had to do to track my gran’s necklace down."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:569
translate chinese CR4_WE_dinner_lab_6319c9b8:

    # Caroline "You, sir, are going to get such a great blowjob tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:570
translate chinese CR4_WE_dinner_lab_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:571
translate chinese CR4_WE_dinner_lab_c9b062df:

    # Caroline "Like, seriously, I’m talking deepthroat with plenty of tongue play. You can even cum in my-"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:572
translate chinese CR4_WE_dinner_lab_b2ce7c60:

    # MC "Caroline-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:573
translate chinese CR4_WE_dinner_lab_1c83fdc6:

    # Caroline "mouth and I’ll swallow every, last-"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:576
translate chinese CR4_WE_dinner_lab_cd38b988:

    # Waiter "*AHEM* May I take your order, Madam?"
    Waiter ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:577
translate chinese CR4_WE_dinner_lab_24a574c8:

    # MC "I tried to warn you..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:578
translate chinese CR4_WE_dinner_lab_5d3c62bd:

    # Caroline "*Cough* Th-The usual... double portions..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:579
translate chinese CR4_WE_dinner_lab_66314f5e:

    # Waiter "Certainly, madam. I hope you two have a lovely evening after your meal. It certainly sounds... thrilling."
    Waiter ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:583
translate chinese CR4_WE_dinner_lab_1134061b:

    # "***Some time later***"
    ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:589
translate chinese CR4_WE_dinner_lab_65d6cc55:

    # MC "Ahahaha!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:590
translate chinese CR4_WE_dinner_lab_d5e05c8f:

    # Caroline "Oh, come on! Are you STILL laughing about that waiter thing?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:591
translate chinese CR4_WE_dinner_lab_9db4962c:

    # MC "S-Sorry, it was just- haha- so funny..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:592
translate chinese CR4_WE_dinner_lab_5df533f9:

    # MC "This actually smells really good, by the way. What did you say it was called?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:595
translate chinese CR4_WE_dinner_lab_900b6ddb:

    # Caroline "Tonkatsu Ramen."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:596
translate chinese CR4_WE_dinner_lab_17df389e:

    # MC "Mmm... And what’s the swirly thing?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:597
translate chinese CR4_WE_dinner_lab_f7970741:

    # Caroline "The noodles?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:598
translate chinese CR4_WE_dinner_lab_bfa1d93c:

    # MC "No, the one that... it looks like someone gave a pink tattoo to an egg."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:599
translate chinese CR4_WE_dinner_lab_793446a5:

    # Caroline "Ahahaha! Try it. You’ll like it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:602
translate chinese CR4_WE_dinner_lab_0f99c8f6:

    # MC "*Slurp* Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:603
translate chinese CR4_WE_dinner_lab_944ca66b:

    # MC "This is delicious, Caroline!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:604
translate chinese CR4_WE_dinner_lab_63499aa5:

    # Caroline "I’m glad you like it. Now, how exactly did you get my necklace back?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:605
translate chinese CR4_WE_dinner_lab_049fbefc:

    # MC "*COUGH*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:608
translate chinese CR4_WE_dinner_lab_89a66e6a:

    # Caroline "You promised me you wouldn’t put yourself in danger to save that necklace."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:609
translate chinese CR4_WE_dinner_lab_5cba1cd2:

    # Caroline "I never wanted you risking your life to save me or my stuff from Charles."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:610
translate chinese CR4_WE_dinner_lab_1c0ede4c:

    # MC "I wasn’t in any danger. We got the necklace back and I’m unharmed. It’s probably best to leave it at that."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:613
translate chinese CR4_WE_dinner_lab_ea68a5a4:

    # MC "And that asshole, Charles, got exactly what he deserved."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:614
translate chinese CR4_WE_dinner_lab_d6d7131b:

    # Caroline "Hearing that is the second best thing to happen to me tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:615
translate chinese CR4_WE_dinner_lab_774394cb:

    # MC "Heh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:618
translate chinese CR4_WE_dinner_lab_a7516da8:

    # MC "I didn’t save you, by the way."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:619
translate chinese CR4_WE_dinner_lab_43cdc422:

    # Caroline "What do you mean?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:620
translate chinese CR4_WE_dinner_lab_57cc9096:

    # MC "Charles. I never saved you from him."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:621
translate chinese CR4_WE_dinner_lab_308db770:

    # Caroline "Of course you did. You fought him twice. I mean, you lost, but at least you put up a fight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:622
translate chinese CR4_WE_dinner_lab_cf8016c1:

    # MC "That’s not what I’m talking about. When you were with Charles, there wasn’t some knight in shining armour that came along."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:625
translate chinese CR4_WE_dinner_lab_4d401af6:

    # Caroline "Wh-What do you mean?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:626
translate chinese CR4_WE_dinner_lab_af82eed1:

    # MC "It was you who broke up with that asshole. You’re the one who escaped. You’re the one who beat him and got away."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:627
translate chinese CR4_WE_dinner_lab_2706c6a2:

    # MC "All I did was help you pick up the pieces and get you back on your feet."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:630
translate chinese CR4_WE_dinner_lab_426766c8:

    # MC "I didn’t save you from Charles. Nobody did."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:631
translate chinese CR4_WE_dinner_lab_7f2dbb64:

    # MC "You saved yourself."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:634
translate chinese CR4_WE_dinner_lab_e766d185:

    # Caroline "I... I never thought about it that way."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:635
translate chinese CR4_WE_dinner_lab_5d184052:

    # MC "This was never a rescue story about some damsel in distress. It was one of recovery."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:636
translate chinese CR4_WE_dinner_lab_7a95d63c:

    # Caroline "...thank you, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:639
translate chinese CR4_WE_dinner_lab_f733f981:

    # Caroline "*Slurp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:640
translate chinese CR4_WE_dinner_lab_f4c49b98:

    # MC "You’re smiling."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:641
translate chinese CR4_WE_dinner_lab_14b8c0c3:

    # Caroline "Mmm hmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:644
translate chinese CR4_WE_dinner_lab_825f88b3:

    # Caroline "I’m just so happy right now. Being here with you... it’s just perfect."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:645
translate chinese CR4_WE_dinner_lab_5a8a7dd5:

    # MC "Thanks, Caroline. I love you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:646
translate chinese CR4_WE_dinner_lab_88520fcd:

    # Caroline "I love you too, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:649
translate chinese CR4_WE_dinner_lab_ac0cc65e:

    # MC "Say, how am I supposed to get the soup with just these chopsticks?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:650
translate chinese CR4_WE_dinner_lab_4edbe53c:

    # MC "Want me to ask the waiter for a couple of spoons?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:651
translate chinese CR4_WE_dinner_lab_3c4c9a61:

    # Caroline "Hehe, you can just tip the bowl back."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:652
translate chinese CR4_WE_dinner_lab_504578bb:

    # MC "Is that not rude?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:653
translate chinese CR4_WE_dinner_lab_b83569eb:

    # Caroline "It’s just you and me here. I’ll be doing it that way, so don’t stress about it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:656
translate chinese CR4_WE_dinner_lab_7b69daa2:

    # MC "*Shluuurrp*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:657
translate chinese CR4_WE_dinner_lab_13b307d8:

    # MC "(Mmm... This stuff is sooo delicious! I can’t believe I’ve never had Japanese food like this before, in my life!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:660
translate chinese CR4_WE_dinner_lab_461d5d46:

    # Caroline "Well? How was dinner?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:661
translate chinese CR4_WE_dinner_lab_01eac677:

    # MC "Mmm... SO good! Like, literally incredible!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:662
translate chinese CR4_WE_dinner_lab_fc4d6386:

    # Caroline "Hehe, I knew you’d like it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:665
translate chinese CR4_WE_dinner_lab_9c2ea808:

    # MC "Is that us heading back home now?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:666
translate chinese CR4_WE_dinner_lab_a4e1e637:

    # Caroline "I have one more surprise for us tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:667
translate chinese CR4_WE_dinner_lab_62e1d2eb:

    # MC "You do?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:670
translate chinese CR4_WE_dinner_lab_9a1bf956:

    # Caroline "We’re not going home."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:671
translate chinese CR4_WE_dinner_lab_991a98c8:

    # MC "Where are-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:672
translate chinese CR4_WE_dinner_lab_cac53b09:

    # Caroline "I booked us the penthouse suite in one of the classiest hotels in the city."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:673
translate chinese CR4_WE_dinner_lab_2550bd62:

    # MC "REALLY?!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:676
translate chinese CR4_WE_dinner_lab_14bab393:

    # Caroline "We’re spending the night, way up on the very top floor."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:677
translate chinese CR4_WE_dinner_lab_a305f67d:

    # Caroline "Just you, me, and a whole lot of steamy sex."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:678
translate chinese CR4_WE_dinner_lab_94cc3ca9:

    # MC "Thank you so much, Caroline! This is amazing!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:679
translate chinese CR4_WE_dinner_lab_bb2b595a:

    # Caroline "Hehe, c’mon! Let’s go! We’re allowed to access our room in thirty minutes time, and at the price I’m paying, I don’t want to miss a single second!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:684
translate chinese CR4_WE_dinner_lab_1134061b_1:

    # "***Some time later***"
    ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:693
translate chinese CR4_love_hotel_lab_22a1c58f:

    # Caroline "Ta da! What do you think?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:694
translate chinese CR4_love_hotel_lab_c9661363:

    # MC "Wow! This hotel is incredible!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:696
translate chinese CR4_love_hotel_lab_37e402df:

    # Caroline "It’s five stars. The last time I was here was a few years ago, with [Mom_name]. Wecame here together on a girly night out."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:698
translate chinese CR4_love_hotel_lab_539ed27b:

    # Caroline "It’s five stars. The last time I was here was a few years ago with my friend. We went together on a girly night out."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:701
translate chinese CR4_love_hotel_lab_b6301bf1:

    # Caroline "I have a feeling I’m going to enjoy tonight MUCH more than last time though."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:702
translate chinese CR4_love_hotel_lab_8a935e75:

    # MC "I’m sure you will."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:703
translate chinese CR4_love_hotel_lab_302d14a3:

    # MC "Look! They’ve even left us a bowl of fresh berries!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:706
translate chinese CR4_love_hotel_lab_6b6d1de9:

    # MC "What do you want to do first?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:707
translate chinese CR4_love_hotel_lab_8ccafa5e:

    # Caroline "How about we sit down and have a little drink together?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:708
translate chinese CR4_love_hotel_lab_c098eb92:

    # MC "Sounds good to me! Want me to call down to the hotel bar and grab us some wine?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:711
translate chinese CR4_love_hotel_lab_ef152305:

    # Caroline "Don’t worry, I came prepared."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:712
translate chinese CR4_love_hotel_lab_5cd7689e:

    # MC "Cool, that’s fine then. HOLY SHIT! This bathroom is massive!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:713
translate chinese CR4_love_hotel_lab_309ce8f4:

    # Caroline "Hehe, you’re so easily distracted!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:716
translate chinese CR4_love_hotel_lab_aeee8af4:

    # Caroline "C’mon, we can try the bath out later on. "
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:717
translate chinese CR4_love_hotel_lab_38330a88:

    # MC "Haha, no problem. Sorry, this is all just so exciting! I’ve never been in a hotel as amazing as this before!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:720
translate chinese CR4_love_hotel_lab_bc00cb15:

    # Caroline "Let’s head over to the couch over there."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:721
translate chinese CR4_love_hotel_lab_0c226a54:

    # MC "Sure, no problem!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:724
translate chinese CR4_love_hotel_lab_29675113:

    # MC "(Wow! Her dress is so short, I can almost see her asscheeks!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:725
translate chinese CR4_love_hotel_lab_b3925d2c:

    # MC "(I can’t wait to tear it off her and spread those later on.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:728
translate chinese CR4_love_hotel_lab_f5b7abc6:

    # Caroline "Enjoying the view, [player_name]?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:729
translate chinese CR4_love_hotel_lab_191878a7:

    # MC "Haha, how’d you know I was looking?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:730
translate chinese CR4_love_hotel_lab_2d1ecb19:

    # Caroline "[Mom_name] caught me leaving the house earlier. She was shocked by how short my dress was, so I had to tell her I’m going out on a date."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:731
translate chinese CR4_love_hotel_lab_672761e2:

    # Caroline "If [Mom_name] noticed my short skirt, then you’re DEFINITELY going to notice!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:734
translate chinese CR4_love_hotel_lab_f5f9d512:

    # MC "Does [Mom_name] know you’re dating me?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:735
translate chinese CR4_love_hotel_lab_eb2882d7:

    # Caroline "I told her it was just some guy - and that I’d introduce her to us when I felt ready."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:736
translate chinese CR4_love_hotel_lab_da6bab00:

    # MC "I wonder how she’ll take it. It won’t make things awkward, right?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:739
translate chinese CR4_love_hotel_lab_b3f7ec70:

    # Caroline "Let’s try not to think about any of that tonight. I just want to have a fun time with you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:740
translate chinese CR4_love_hotel_lab_1a3929c2:

    # Caroline "Say, can you go into my bag? I have a bottle of vodka in there that I’ve been saving for a special occasion."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:743
translate chinese CR4_love_hotel_lab_707f4789:

    # MC "No problem. I’ll get it now."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:744
translate chinese CR4_love_hotel_lab_71da1e06:

    # Caroline "Thanks, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:745
translate chinese CR4_love_hotel_lab_7ef9ada0:

    # MC "You look really amazing tonight, Caroline. You know that?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:748
translate chinese CR4_love_hotel_lab_307f53f0:

    # Caroline "Hehe, thank you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:749
translate chinese CR4_love_hotel_lab_d52884d6:

    # Caroline "Now, you’ll have all night to leer at my body. Can we get something to drink? I’m parched after that meal."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:883
translate chinese CR4_love_hotel_handbag_9cb00310:

    # MC "(Okay, this looks like her bag. How the hell do I get into this thing?)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:884
translate chinese CR4_love_hotel_handbag_0ac57e37:

    # MC "(Ahh, there’s the clasp!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:887
translate chinese CR4_love_hotel_handbag_4ec23f9d:

    # MC "Milfy City Vodka? Cute name. Is it a local brand?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:888
translate chinese CR4_love_hotel_handbag_8bc86cb4:

    # Caroline "Yeah, it’s a small producer from just outside the city limits. I got it a couple of years ago."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:889
translate chinese CR4_love_hotel_handbag_c6414783:

    # Caroline "I swore I wouldn’t open it until I had someone that I knew I wanted to share it with."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:890
translate chinese CR4_love_hotel_handbag_22ccd6b9:

    # Caroline "Now that you’re my boyfriend, I think... I think it’s the right time to open it up."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:903
translate chinese CR4_love_hotel_lab2_d813a557:

    # MC "(I should take the bottle of vodka from her bag.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:916
translate chinese CR4_love_hotel_lab2_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:917
translate chinese CR4_love_hotel_lab2_4a0cfece:

    # Caroline "I’m more than certain, [player_name]. I really am. You’re the one I want to spend my life with."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:918
translate chinese CR4_love_hotel_lab2_52bf71e3:

    # Caroline "You don’t raise your voice or shout at me. You’ve never hit me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:921
translate chinese CR4_love_hotel_lab2_b138e4dc:

    # MC "That’s not exactly a high bar..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:922
translate chinese CR4_love_hotel_lab2_a0c68c5e:

    # Caroline "All I want is to feel safe in a relationship with someone, who I know cares about me. You’ve already given me that, [player_name]. I’m sorry I was pushing you away at the beginning."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:923
translate chinese CR4_love_hotel_lab2_0d7e5ce3:

    # MC "It’s okay. I understand now. "
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:926
translate chinese CR4_love_hotel_lab2_ace5df19:

    # MC "When I was... When I visited Charles to try and get your necklace back, he said some things."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:927
translate chinese CR4_love_hotel_lab2_6ecec50f:

    # Caroline "Oh yeah? Like what?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:928
translate chinese CR4_love_hotel_lab2_5a8bc10d:

    # MC "He mentioned how you used to have to buy foundation to cover the bruises he gave you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:931
translate chinese CR4_love_hotel_lab2_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:932
translate chinese CR4_love_hotel_lab2_e5ce135d:

    # MC "I mean, I knew he was a first class asshole. But I never realised JUST how much of a scumbag he really was."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:933
translate chinese CR4_love_hotel_lab2_7b823929:

    # MC "[Mom_name] and Sara never knew, did they?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:934
translate chinese CR4_love_hotel_lab2_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:937
translate chinese CR4_love_hotel_lab2_8edb8451:

    # MC "I’ll pour us some drinks."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:938
translate chinese CR4_love_hotel_lab2_ee627fcd:

    # Caroline "I got... good at hiding it from everyone. You, [Dad_name], Sara..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:939
translate chinese CR4_love_hotel_lab2_815a6f2c:

    # Caroline "I felt like what was happening was my fault. Because I wasn’t good enough for him."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:942
translate chinese CR4_love_hotel_lab2_9074c722:

    # MC "It’s alright. We should have been paying more attention. You weren’t yourself back then."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:943
translate chinese CR4_love_hotel_lab2_18a50a60:

    # Caroline "I know... Walking away from him was one of the hardest things I ever did. He stalked me for months after that."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:946
translate chinese CR4_love_hotel_lab2_a6c1a72a:

    # MC "Do you want to hear a story that will cheer you up?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:947
translate chinese CR4_love_hotel_lab2_3061091e:

    # Caroline "Shoot."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:948
translate chinese CR4_love_hotel_lab2_acba1008:

    # MC "When I went over to visit him, his place was a complete dump. He had a single room with a mattress on the floor, empty beer bottles everywhere, and some shitty television that looked like it belonged in the eighties."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:949
translate chinese CR4_love_hotel_lab2_aeffa0bc:

    # MC "And while he’s living in squalor, you’re living it up in a five star hotel. It’s as you said during dinner - you beat the bastard, and you did it without anyone’s help."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:950
translate chinese CR4_love_hotel_lab2_082672f1:

    # MC "Now you run your own hugely successful business, you’ve gotten your confidence back, and you’ve got a new partner who really, really loves you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:953
translate chinese CR4_love_hotel_lab2_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:955
translate chinese CR4_love_hotel_lab2_7ac5e0c1:

    # MC "So here’s to your continued success!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:956
translate chinese CR4_love_hotel_lab2_09aeb9fc:

    # Caroline "Thanks, [player_name]. I’ll drink to that."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:959
translate chinese CR4_love_hotel_lab2_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:960
translate chinese CR4_love_hotel_lab2_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:961
translate chinese CR4_love_hotel_lab2_c9b5e2eb:

    # MC "*Cough* That’s strong stuff!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:964
translate chinese CR4_love_hotel_lab2_38232d0f:

    # Caroline "I wish it could have been us, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:965
translate chinese CR4_love_hotel_lab2_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:966
translate chinese CR4_love_hotel_lab2_b4af6450:

    # Caroline "I mean, you and me. I wish I’d never met Charles."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:969
translate chinese CR4_love_hotel_lab2_7b26b862:

    # MC "You can’t change the past, Caroline. It isn’t worth wasting your time imagining what could have been."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:970
translate chinese CR4_love_hotel_lab2_4cc5358a:

    # MC "Heck, if you hadn’t dated Charles then you may never have learnt how strong you actually are. You might not have launched your own business!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:971
translate chinese CR4_love_hotel_lab2_0a2e032c:

    # MC "And if you hadn’t done that, we’d not be romantically involved."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:972
translate chinese CR4_love_hotel_lab2_89342902:

    # Caroline "I guess you’re right."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:975
translate chinese CR4_love_hotel_lab2_a4f55ba3_1:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:976
translate chinese CR4_love_hotel_lab2_f00403c4:

    # MC "Thanks again for organising this night, Caroline. I really love it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:979
translate chinese CR4_love_hotel_lab2_4416246b:

    # Caroline "Thanks for talking me through all this."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:980
translate chinese CR4_love_hotel_lab2_16b5d566:

    # Caroline "I’ve never really opened up much to anyone. It’s nice to have someone I can talk to and trust. Someone who isn’t going to belittle me or mock me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:983
translate chinese CR4_love_hotel_lab2_dfb5d643:

    # Caroline "You’re perfect."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:984
translate chinese CR4_love_hotel_lab2_35346dd6:

    # MC "That necklace really suits you, you know that?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:985
translate chinese CR4_love_hotel_lab2_292cc5b0:

    # Caroline "You think so?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:988
translate chinese CR4_love_hotel_lab2_c6529bd8:

    # Caroline "For a sixty year old piece of jewelry, it’s aged pretty damn well."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:989
translate chinese CR4_love_hotel_lab2_cbab8be2:

    # MC "I’m just glad it’s back where it belongs."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:990
translate chinese CR4_love_hotel_lab2_fdc673a1:

    # Caroline "I still need to properly thank you for that."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:993
translate chinese CR4_love_hotel_lab2_c9b20f0a:

    # MC "Mmm, and how do you plan to do that?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:994
translate chinese CR4_love_hotel_lab2_2478291c:

    # Caroline "Why don’t you set down your drink, and I’ll show you?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:995
translate chinese CR4_love_hotel_lab2_90c52b84:

    # MC "Okay!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1002
translate chinese CR4_love_hotel_lab2_7585dd65:

    # Caroline "I’m going to rock your world tonight, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1003
translate chinese CR4_love_hotel_lab2_971e5c5c:

    # MC "Mmm, I’m looking forward to that."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1004
translate chinese CR4_love_hotel_lab2_858ab27a:

    # Caroline "I’ve got a few little tricks I’ve been yearning to try out with you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1007
translate chinese CR4_love_hotel_lab2_c53a58bc:

    # MC "Oh yeah? And what tricks would those be?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1008
translate chinese CR4_love_hotel_lab2_39d96062:

    # Caroline "We’ll have to get you out of these restrictive clothes first. Hehe!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1011
translate chinese CR4_love_hotel_lab2_5d52f7a3:

    # Caroline "How many times do you think you can go in one night?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1012
translate chinese CR4_love_hotel_lab2_1a641e20:

    # MC "I don’t know. Maybe three?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1013
translate chinese CR4_love_hotel_lab2_d8245487:

    # Caroline "Mmm, let’s see if we can hit three, then. We’re going to need to make you cum before we have sex though."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1014
translate chinese CR4_love_hotel_lab2_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1015
translate chinese CR4_love_hotel_lab2_7a357d0e:

    # Caroline "I want you lasting longer for the main event!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1016
translate chinese CR4_love_hotel_lab2_eb56053d:

    # MC "Sweet! Sounds good to me!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1019
translate chinese CR4_love_hotel_lab2_f314a52b:

    # Caroline "But first, we’re going to have to get you all nice and hard."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1020
translate chinese CR4_love_hotel_lab2_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1021
translate chinese CR4_love_hotel_lab2_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1024
translate chinese CR4_love_hotel_lab2_2338451b:

    # MC "I love you, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1025
translate chinese CR4_love_hotel_lab2_88520fcd:

    # Caroline "I love you too, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1028
translate chinese CR4_love_hotel_lab2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1029
translate chinese CR4_love_hotel_lab2_05d1b90c_1:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1030
translate chinese CR4_love_hotel_lab2_806cf2ac:

    # MC "(Her lips are so soft.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1033
translate chinese CR4_love_hotel_lab2_cd115f60:

    # Caroline "(He’s beginning to get hard now. I wonder what he’ll want to do first.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1034
translate chinese CR4_love_hotel_lab2_a9fd3cf0:

    # Caroline "(Maybe I should warm him up with a boobjob? Perhaps he’d prefer me to just suck his cock?)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1037
translate chinese CR4_love_hotel_lab2_a1bb61b2:

    # Caroline "Oh my! You’ve gotten hard REALLY quickly!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1038
translate chinese CR4_love_hotel_lab2_2a341311:

    # MC "Mmm, keep moving your hand like that!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1041
translate chinese CR4_love_hotel_lab2_1c62dcfa:

    # Caroline "Like this?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1042
translate chinese CR4_love_hotel_lab2_8392b3d7:

    # MC "Uh huh... Ohh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1043
translate chinese CR4_love_hotel_lab2_609185f6:

    # Caroline "Do you like it when I rub your shaft like this?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1044
translate chinese CR4_love_hotel_lab2_2048b593:

    # MC "Yes, mmm! Don’t stop!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1047
translate chinese CR4_love_hotel_lab2_2f3df3d8:

    # Caroline "Why settle for just a handjob though, when you could have SO MUCH more?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1048
translate chinese CR4_love_hotel_lab2_ca2052c1:

    # MC "I’m listening... and watching."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1049
translate chinese CR4_love_hotel_lab2_673d143f:

    # Caroline "Hehe, make sure you don’t blink."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1052
translate chinese CR4_love_hotel_lab2_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1053
translate chinese CR4_love_hotel_lab2_55a3b307:

    # Caroline "As I was saying, why settle for a handjob, when you could have these babies wrapped around your cock?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1054
translate chinese CR4_love_hotel_lab2_e5f70504:

    # MC "Very tempting. How about you lose the rest of that dress while I think about it?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1057
translate chinese CR4_love_hotel_lab2_c4328cfe:

    # Caroline "Alternatively, I could take that thick cock of yours into my mouth and suck on it until you are trembling in orgasm."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1058
translate chinese CR4_love_hotel_lab2_b01a8c3f:

    # MC "That is ALSO very tempting! You’re giving me a really difficult choice right now."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1061
translate chinese CR4_love_hotel_lab2_dcb5c5fc:

    # Caroline "Well, perhaps THIS can help you make up your mind."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1062
translate chinese CR4_love_hotel_lab2_37125ea0:

    # Caroline "I know I’m hot, but try not to drool."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1065
translate chinese CR4_love_hotel_lab2_b39ef889_1:

    # MC "*Whistle*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1066
translate chinese CR4_love_hotel_lab2_3b7e182b:

    # MC "You look fucking incredible right now!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1069
translate chinese CR4_love_hotel_lab2_cb6a5f24:

    # Caroline "Well? What’s it going to be, [player_name]? "
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1070
translate chinese CR4_love_hotel_lab2_5011ac5b:

    # Caroline "Do you want my breasts massaging your dick until you blow your load over them?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1071
translate chinese CR4_love_hotel_lab2_b1710161:

    # Caroline "Or would you like another one of my, unbeatable, blowjobs?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1077
translate chinese CR4_love_hotel_lab2_dad5eb3a:

    # MC "Let’s go for a blowjob."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1078
translate chinese CR4_love_hotel_lab2_77514df9:

    # Caroline "Mmm, good choice. Lie back - and I’ll take care of everything."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1081
translate chinese CR4_love_hotel_lab2_dce35bfb:

    # MC "(Her eyes are so damn sexy...)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1082
translate chinese CR4_love_hotel_lab2_9ad499dc:

    # Caroline "You’re really going to enjoy this. I hope you’ve got a big load of cum saved up for me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1083
translate chinese CR4_love_hotel_lab2_fb218847:

    # MC "There might be - there’s only one way you’re gonna find out though."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1086
translate chinese CR4_love_hotel_lab2_f3c7eee7:

    # Caroline "Hehe, I was thinking about doing something a little bit different tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1087
translate chinese CR4_love_hotel_lab2_699b732e:

    # Caroline "Normally, when a girl gives a guy a blowjob she uses her hands. Just like this."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1088
translate chinese CR4_love_hotel_lab2_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1091
translate chinese CR4_love_hotel_lab2_8f5f90aa:

    # Caroline "I was thinking that tonight, I would try and get you off with just my mouth."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1092
translate chinese CR4_love_hotel_lab2_71958523:

    # MC "Sounds fun! Do you think you’re up to it though?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1093
translate chinese CR4_love_hotel_lab2_50554145:

    # Caroline "Oh please... If anyone isn’t going to be “up to it”, it’ll be you. I’ll have you creaming in my mouth in no time at all."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1094
translate chinese CR4_love_hotel_lab2_fbea9c52:

    # MC "It sounds to me like someone is waaaay too confident!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1095
translate chinese CR4_love_hotel_lab2_1bc66e6b:

    # Caroline "Oh yeah? I bet you won’t last three minutes."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1096
translate chinese CR4_love_hotel_lab2_6a3ff038:

    # MC "You’re on!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1097
translate chinese CR4_love_hotel_lab2_e9f92542:

    # Caroline "Let me just wet it with my tongue. Feel free to start counting when I let go."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1098
translate chinese CR4_love_hotel_lab2_ca64c9f7:

    # Caroline "That is... if you even CAN focus on counting."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1101
translate chinese CR4_love_hotel_lab2_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1103
translate chinese CR4_love_hotel_lab2_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1106
translate chinese CR4_love_hotel_lab2_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1108
translate chinese CR4_love_hotel_lab2_47800f0b:

    # MC "Mmm... fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1109
translate chinese CR4_love_hotel_lab2_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1112
translate chinese CR4_love_hotel_lab2_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1113
translate chinese CR4_love_hotel_lab2_44e61699:

    # Caroline "(Okay, that’s [player_name] nice and hard now! Three minutes starts now!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1114
translate chinese CR4_love_hotel_lab2_a95f976c:

    # MC "(Dammit, the tip is so sensitive!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1117
translate chinese CR4_love_hotel_lab2_41842b5d:

    # MC "(One... Two... Three...)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1118
translate chinese CR4_love_hotel_lab2_43b8826f_2:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1119
translate chinese CR4_love_hotel_lab2_a22cbf0a:

    # MC "(Damn, it feels so good when she licks at my balls like that.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1122
translate chinese CR4_love_hotel_lab2_10b4b18f:

    # MC "(Seven... eight...)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1123
translate chinese CR4_love_hotel_lab2_e2c07e81_1:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1124
translate chinese CR4_love_hotel_lab2_c39bd83c:

    # MC "Ohhhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1127
translate chinese CR4_love_hotel_lab2_45982ded:

    # Caroline "*Suck Shlurp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1128
translate chinese CR4_love_hotel_lab2_18f876ac:

    # MC "Mmm! Oh fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1129
translate chinese CR4_love_hotel_lab2_b5848e66:

    # MC "(Was I on fifteen? Shit, I can’t even keep track.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1132
translate chinese CR4_love_hotel_lab2_05d1b90c_2:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1133
translate chinese CR4_love_hotel_lab2_a88acabb:

    # Caroline "*Shluurrrp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1134
translate chinese CR4_love_hotel_lab2_b52e91a4:

    # MC "God... Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1137
translate chinese CR4_love_hotel_lab2_7357f4f3:

    # Caroline "I make that twenty seconds so far. Didn’t lose count, did you?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1138
translate chinese CR4_love_hotel_lab2_a42508c7:

    # MC "No, not at all. Haha, that sounds about right."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1139
translate chinese CR4_love_hotel_lab2_e7fae07d:

    # Caroline "Ready for the main event, then? As I promised: absolutely no hands."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1142
translate chinese CR4_love_hotel_lab2_a88acabb_1:

    # Caroline "*Shluurrrp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1143
translate chinese CR4_love_hotel_lab2_c7e44b87:

    # MC "Ohhhh... fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1144
translate chinese CR4_love_hotel_lab2_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1147
translate chinese CR4_love_hotel_lab2_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1148
translate chinese CR4_love_hotel_lab2_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1150
translate chinese CR4_love_hotel_lab2_e441b104:

    # MC "(I can feel her tongue swirling around my glans - she’s so damn good at this!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1153
translate chinese CR4_love_hotel_lab2_444a25d5:

    # Caroline "*Mpppf!* *GAG*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1155
translate chinese CR4_love_hotel_lab2_17827721:

    # MC "Ohhh! Fuck, yes! Just like that! Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1157
translate chinese CR4_love_hotel_lab2_6ca75877:

    # Caroline "(One minute down, two to go. Time to up my game!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1160
translate chinese CR4_love_hotel_lab2_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1161
translate chinese CR4_love_hotel_lab2_c7efe113:

    # Caroline "([player_name] has started breathing pretty heavily now! I’ve got him on the ropes!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1162
translate chinese CR4_love_hotel_lab2_cdf43328:

    # Caroline "(He’ll be shooting his hot cum into my mouth, any second now!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1165
translate chinese CR4_love_hotel_lab2_05d1b90c_3:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1166
translate chinese CR4_love_hotel_lab2_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1167
translate chinese CR4_love_hotel_lab2_2660f2a6:

    # MC "(When she moans like that, I can feel intense little vibrations travelling down my shaft! She must be doing that on purpose!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1170
translate chinese CR4_love_hotel_lab2_23da9308_1:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1172
translate chinese CR4_love_hotel_lab2_22b13036:

    # MC "Mmm! Yes... Oh fuck, you’re so good!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1173
translate chinese CR4_love_hotel_lab2_0dbec2e3:

    # Caroline "*Shluuurrrrp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1176
translate chinese CR4_love_hotel_lab2_8272aedb:

    # Caroline "(Let’s see if he enjoys me rubbing his glans against the side of my cheek.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1178
translate chinese CR4_love_hotel_lab2_76c9d1f1:

    # MC "Ohhh... Keep going! That’s so good!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1180
translate chinese CR4_love_hotel_lab2_922ea5d9:

    # Caroline "*Suck Suuuuucccck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1182
translate chinese CR4_love_hotel_lab2_5b528ba6:

    # MC "Hnnng...."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1184
translate chinese CR4_love_hotel_lab2_0dbec2e3_1:

    # Caroline "*Shluuurrrrp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1186
translate chinese CR4_love_hotel_lab2_31f8a2b9:

    # MC "(Shit! There’s no way I’m gonna last three minutes! I’m already edging!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1187
translate chinese CR4_love_hotel_lab2_8e1baa4d:

    # MC "(I should just grab her head and fuck her mouth!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1190
translate chinese CR4_love_hotel_lab2_bc4628d7:

    # Caroline "Hmm?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1191
translate chinese CR4_love_hotel_lab2_111c5b8c:

    # MC "Ugh! Don’t stop! Keep sucking my cock!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1192
translate chinese CR4_love_hotel_lab2_d06119ca:

    # MC "Ahhh fuck!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1196
translate chinese CR4_love_hotel_lab2_7d31255b:

    # Caroline "*SUCK SUCK SUCK*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1197
translate chinese CR4_love_hotel_lab2_65c2b70e:

    # MC "Ahhhhhh! Shit, I’m cumming!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1198
translate chinese CR4_love_hotel_lab2_535409ab:

    # Caroline "(Hehe, I knew he wouldn’t last long when I put my mouth to work!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1199
translate chinese CR4_love_hotel_lab2_1bf35705:

    # MC "Ugh! Hnnnnnggg!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1209
translate chinese CR4_love_hotel_lab2_7c6277ae:

    # Caroline "MPFPFF!!! *GAG*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1210
translate chinese CR4_love_hotel_lab2_fb364c13:

    # Caroline "(Oh wow! There really was A LOT of cum! It’s filling up my mouth!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1213
translate chinese CR4_love_hotel_lab2_95176477:

    # Caroline "*Gulp Gulp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1214
translate chinese CR4_love_hotel_lab2_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1215
translate chinese CR4_love_hotel_lab2_88907b62:

    # Caroline "*Suck* *Gulp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1216
translate chinese CR4_love_hotel_lab2_19fe42b1:

    # MC "W-Wow... That was... *pant* ...fucking amazing."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1219
translate chinese CR4_love_hotel_lab2_1b603d17:

    # MC "How long did I last?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1220
translate chinese CR4_love_hotel_lab2_91e3bed9:

    # Caroline "I sort of lost count too, but I think it was around the two and a half minute mark."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1221
translate chinese CR4_love_hotel_lab2_fd7ef196:

    # MC "Aww, seriously?!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1222
translate chinese CR4_love_hotel_lab2_c3fb8944:

    # Caroline "Don’t worry, that’s what this pre-sex climax was for. It means you’ll last longer when I finally get to ride you tonight!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1227
translate chinese CR4_love_hotel_lab2_8f8b31d9:

    # MC "I’d like to fuck your tits first, tonight."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1228
translate chinese CR4_love_hotel_lab2_11d9f617:

    # Caroline "Sounds fun! I think you’re REALLY going to enjoy this!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1231
translate chinese CR4_love_hotel_lab2_962f1ffc:

    # Caroline "How does that feel? Are you comfy?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1232
translate chinese CR4_love_hotel_lab2_7eeaaa96:

    # MC "Oh yeah, that’s great..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1233
translate chinese CR4_love_hotel_lab2_30d0803c:

    # MC "(Her breasts are so warm, wrapped around my cock.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1236
translate chinese CR4_love_hotel_lab2_65357032:

    # Caroline "Hehe, you have such a cute expression on your face. You look like you’re really enjoying it when I bounce up and down like this."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1237
translate chinese CR4_love_hotel_lab2_86a2cbdb:

    # MC "It feels so great, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1240
translate chinese CR4_love_hotel_lab2_6f64e512:

    # MC "Mmm! Just like that..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1242
translate chinese CR4_love_hotel_lab2_971023ac:

    # Caroline "Do you want me to speed up?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1243
translate chinese CR4_love_hotel_lab2_d9a2d6ea:

    # MC "No, it’s perfect - just like that. Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1246
translate chinese CR4_love_hotel_lab2_f7b3ab67:

    # Caroline "Do you like it when I squeeze them really tight, around your cock like that?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1247
translate chinese CR4_love_hotel_lab2_d595c335:

    # MC "Ohh... That’s so good."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1248
translate chinese CR4_love_hotel_lab2_94e44052:

    # Caroline "(I love watching him squirm in pleasure, as I tease him with my breasts!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1251
translate chinese CR4_love_hotel_lab2_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1252
translate chinese CR4_love_hotel_lab2_3eaf82ea:

    # Caroline "(His cock is pulsing between my boobs - I can feel him quivering each time I massage his dick with them.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1253
translate chinese CR4_love_hotel_lab2_5c3e2e39:

    # Caroline "I’m going to speed things up a notch now, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1256
translate chinese CR4_love_hotel_lab2_2dfade31:

    # MC "Uh, yes please!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1258
translate chinese CR4_love_hotel_lab2_ac6d5d68_1:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1261
translate chinese CR4_love_hotel_lab2_b987e77d_2:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1262
translate chinese CR4_love_hotel_lab2_41ac5776:

    # MC "(Holy fuck, this feels incredible. I love how good she is with her breasts!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1263
translate chinese CR4_love_hotel_lab2_fadde8b8:

    # Caroline "Would you like to hold my tits while you fuck them?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1266
translate chinese CR4_love_hotel_lab2_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1267
translate chinese CR4_love_hotel_lab2_508b0e7a:

    # Caroline "You can squeeze harder than that if you want. Don’t worry, you’re not going to hurt me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1269
translate chinese CR4_love_hotel_lab2_ee272317:

    # MC "Hnng... No, this is perfect... ahh.."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1272
translate chinese CR4_love_hotel_lab2_ac6d5d68_2:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1274
translate chinese CR4_love_hotel_lab2_b0d0a416:

    # MC "I think I’m gonna blow my load soon!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1276
translate chinese CR4_love_hotel_lab2_3b2848e7:

    # Caroline "I want you to cum over my tits, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1279
translate chinese CR4_love_hotel_lab2_2ffee189:

    # Caroline "I want to feel your hot sticky seed, coat my boobs."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1280
translate chinese CR4_love_hotel_lab2_d27440e5:

    # Caroline "Can you do that for me?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1281
translate chinese CR4_love_hotel_lab2_70b8de63:

    # MC "Y-Yes, hnnnng... Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1284
translate chinese CR4_love_hotel_lab2_af2d5043:

    # Caroline "That’s it, cum for me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1285
translate chinese CR4_love_hotel_lab2_5dc5861b:

    # MC "Ahhhhh! Fuck!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1288
translate chinese CR4_love_hotel_lab2_57e4d2fd:

    # MC "I’m cumming! Hnnnnggg! Ugh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1290
translate chinese CR4_love_hotel_lab2_70b8de63_1:

    # MC "Y-Yes, hnnnng... Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1292
translate chinese CR4_love_hotel_lab2_edde419f:

    # MC "Ohhh! Fuck! Aaarrrghhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1302
translate chinese CR4_love_hotel_lab2_3ef74e14:

    # Caroline "Oh wow! That’s A LOT of cum!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1303
translate chinese CR4_love_hotel_lab2_65723723:

    # MC "*Pant Pant* Thanks, Caroline... That was... *Pant* incredible..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1304
translate chinese CR4_love_hotel_lab2_d9c70231:

    # Caroline "Well, now that we’ve got that out of the way, you should last MUCH longer during the main event!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1305
translate chinese CR4_love_hotel_lab2_39585864:

    # Caroline "At least, I hope you will - I plan to fuck you A LOT tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1311
translate chinese CR4_love_hotel_lab3_e7fcb8d1:

    # Caroline "How about you and me take a bath together before we head to bed?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1312
translate chinese CR4_love_hotel_lab3_05875b4b:

    # MC "Sure! Sounds good to me. Want me to go run the hot water?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1315
translate chinese CR4_love_hotel_lab3_a64c2743:

    # Caroline "That would be lovely. I’ll just freshen up, here. And I’ll join you in a couple of minutes. Okay?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1316
translate chinese CR4_love_hotel_lab3_12ff6969:

    # MC "Perfect. See you soon."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1328
translate chinese CR4_love_hotel_lab4_03993845:

    # MC "(I have to prepare the bath.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1341
translate chinese CR4_love_hotel_lab4_fc60bfed:

    # MC "(Alright, that’s the bath filled up. The water’s nice and hot!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1342
translate chinese CR4_love_hotel_lab4_ad1f0a27:

    # MC "(I guess I’ll just hop straight in while I wait for Caroline.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1345
translate chinese CR4_love_hotel_lab4_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1346
translate chinese CR4_love_hotel_lab4_bc72340e:

    # MC "(Oh, that’s good...)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1349
translate chinese CR4_love_hotel_lab4_f2e95454:

    # MC "(It feels so much larger than the bath we have back home.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1350
translate chinese CR4_love_hotel_lab4_1d9c86eb:

    # MC "(Whenever I move out and get a home of my own, I’d love to get one of those large, square jacuzzi baths. The ones with the water jets.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1351
translate chinese CR4_love_hotel_lab4_289c1903:

    # MC "(That’d be the life...)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1354
translate chinese CR4_love_hotel_lab4_7269e167:

    # MC "(Ohh, it looks like Caroline is preparing drinks for the two of us.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1355
translate chinese CR4_love_hotel_lab4_fad6009c:

    # MC "Need a hand, there?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1356
translate chinese CR4_love_hotel_lab4_94423e20:

    # Caroline "I got it! Just give me a minute!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1359
translate chinese CR4_love_hotel_lab4_1d8856cd:

    # MC "(Damn, her ass is so fucking hot. I hope I get a chance to plunge my cock in it tonight.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1360
translate chinese CR4_love_hotel_lab4_6b9fe8bc:

    # Caroline "Do you take ice in your brandy?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1361
translate chinese CR4_love_hotel_lab4_0106dff0:

    # MC "Does anyone?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1362
translate chinese CR4_love_hotel_lab4_6206b643:

    # Caroline "Hehe, I’ve no idea. I’ve never drank it before."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1363
translate chinese CR4_love_hotel_lab4_3e622bbc:

    # MC "Let’s skip the ice then. Haha!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1366
translate chinese CR4_love_hotel_lab4_d44499e7:

    # MC "Where’d you get brandy, by the way?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1367
translate chinese CR4_love_hotel_lab4_9bcffe64:

    # Caroline "Compliments of booking a room with this hotel. It’s a nice place to stay!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1368
translate chinese CR4_love_hotel_lab4_2796e830:

    # MC "It really is!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1371
translate chinese CR4_love_hotel_lab4_e5103960:

    # MC "That’s A LOT of brandy... Are you sure you’re supposed to fill the glass up that much?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1372
translate chinese CR4_love_hotel_lab4_ae1cb100:

    # Caroline "I mean, it’s just like a strong wine, isn’t it?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1373
translate chinese CR4_love_hotel_lab4_8cfc5135:

    # MC "I think so?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1376
translate chinese CR4_love_hotel_lab4_ec589135:

    # Caroline "It’ll be fine. Alcohol is alcohol - however they decide to dress it up!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1377
translate chinese CR4_love_hotel_lab4_85a029a3:

    # MC "Fair enough."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1378
translate chinese CR4_love_hotel_lab4_f1b01d7b:

    # Caroline "How’s the water?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1381
translate chinese CR4_love_hotel_lab4_d83b2d1b:

    # MC "Absolutely perfect. You’ll love it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1382
translate chinese CR4_love_hotel_lab4_b82801b5:

    # Caroline "Mmm, you’re right. That’s really warm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1383
translate chinese CR4_love_hotel_lab4_9a83b325:

    # Caroline "Shift your legs a bit, and I’ll squeeze in too."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1386
translate chinese CR4_love_hotel_lab4_56421aec:

    # Caroline "Ohh... That’s nice."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1387
translate chinese CR4_love_hotel_lab4_5c2e271b:

    # MC "Thanks for pouring me the drink. I wasn’t expecting that."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1388
translate chinese CR4_love_hotel_lab4_1516391e:

    # Caroline "Come on, it’s hardly a romantic bath without a drink to relax with."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1391
translate chinese CR4_love_hotel_lab4_97628a4e:

    # MC "Shall we make a toast?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1392
translate chinese CR4_love_hotel_lab4_fb8bf7be:

    # Caroline "What would you like to toast to?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1393
translate chinese CR4_love_hotel_lab4_d21e4ff9:

    # MC "To us, to one of the best nights of a long and happy relationship."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1394
translate chinese CR4_love_hotel_lab4_f3e24eaf:

    # Caroline "Hehe, I’ll drink to that."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1397
translate chinese CR4_love_hotel_lab4_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1398
translate chinese CR4_love_hotel_lab4_ecd5a79e:

    # MC "(Holy shit, this stuff is strong! Maybe topping these glasses to the brim was the wrong decision.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1399
translate chinese CR4_love_hotel_lab4_17e8a8ec:

    # MC "(It’s kinda got a peppery, caramel taste.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1402
translate chinese CR4_love_hotel_lab4_ed8ea072:

    # MC "(Fuck... she looks so hot right now. Her breasts are amazing!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1403
translate chinese CR4_love_hotel_lab4_14477400:

    # MC "(I love the way I can just about make out her pussy through the water.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1406
translate chinese CR4_love_hotel_lab4_0e159e4e:

    # Caroline "I know where you’re looking."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1407
translate chinese CR4_love_hotel_lab4_4cda7266:

    # MC "Haha, caught me?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1408
translate chinese CR4_love_hotel_lab4_a56d0540:

    # Caroline "Please. It wasn’t hard to notice. Your eyes were walking their way all over my body."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1409
translate chinese CR4_love_hotel_lab4_29cbdce9:

    # MC "Can you blame me?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1410
translate chinese CR4_love_hotel_lab4_3ecb8197:

    # Caroline "Hehe, not at all."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1413
translate chinese CR4_love_hotel_lab4_5524ad2e:

    # Caroline "Umm... During that toast. You said a “long and happy relationship”."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1414
translate chinese CR4_love_hotel_lab4_6930eada:

    # MC "Yeah, I did."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1415
translate chinese CR4_love_hotel_lab4_b76b8cd6:

    # Caroline "How long do you think we’ll be together?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1416
translate chinese CR4_love_hotel_lab4_b0655be0:

    # MC "As many years as my heart can give you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1419
translate chinese CR4_love_hotel_lab4_6baa51a3:

    # Caroline "You’ve always been good with your words, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1420
translate chinese CR4_love_hotel_lab4_1fc7b593:

    # Caroline "When you say that, do you mea-"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1421
translate chinese CR4_love_hotel_lab4_a61b0707:

    # MC "I mean, forever. I’m in this until the final words of the final chapter of this book we’re writing together."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1424
translate chinese CR4_love_hotel_lab4_29c1674b:

    # MC "I love you, Caroline. We get one shot at life on Earth, and I want to spend the rest of mine with you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1425
translate chinese CR4_love_hotel_lab4_88520fcd:

    # Caroline "I love you too, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1426
translate chinese CR4_love_hotel_lab4_fec9f6f6:

    # Caroline "*Hic*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1429
translate chinese CR4_love_hotel_lab4_d99f61be:

    # Caroline "Hehe, sorry. Way to ruin a moment, Caroline! It’s just the drink talking."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1430
translate chinese CR4_love_hotel_lab4_21a5af4d:

    # MC "Haha, don’t worry about it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1433
translate chinese CR4_love_hotel_lab4_c8d9040b:

    # Caroline "Say, this kind of conversation is best kept for bed. How about we spice things up a bit before they get too heavy?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1434
translate chinese CR4_love_hotel_lab4_8ab2029c:

    # MC "Sure. What are you thinking of?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1435
translate chinese CR4_love_hotel_lab4_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1441
translate chinese CR4_love_hotel_lab4_2685510a:

    # Caroline "I want to watch you play with yourself for me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1442
translate chinese CR4_love_hotel_lab4_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1443
translate chinese CR4_love_hotel_lab4_ee35a1e3:

    # Caroline "Yeah. Just reach under the water and-"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1444
translate chinese CR4_love_hotel_lab4_a40a40f4:

    # Caroline "Mmm, exactly like that..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1445
translate chinese CR4_love_hotel_lab4_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1448
translate chinese CR4_love_hotel_lab4_385f4818:

    # MC "Mmm, are you enjoying watching me rub my cock, like this?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1449
translate chinese CR4_love_hotel_lab4_94f1337f:

    # Caroline "Oh yeah, I think I’m going to have to join you... Let me just get my drink out of the way. *Hic*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1450
translate chinese CR4_love_hotel_lab4_b101197d:

    # Caroline "Hehe, sorry!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1453
translate chinese CR4_love_hotel_lab4_31590db7:

    # Caroline "Okay... Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1454
translate chinese CR4_love_hotel_lab4_3c807e07:

    # Caroline "I love your chest... I love watching the muscles on your body. Ahh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1455
translate chinese CR4_love_hotel_lab4_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1458
translate chinese CR4_love_hotel_lab4_0840a2ad:

    # Caroline "I get so wet every time I see you naked. I get so excited when you are looking at my body."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1459
translate chinese CR4_love_hotel_lab4_28ef7884:

    # Caroline "Every time you took photographs of me in my cosplay outfits, you’d ALWAYS leave my panties soaking wet. Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1460
translate chinese CR4_love_hotel_lab4_f81f0d8e:

    # MC "Thank you for letting me, helping you with your business was some of the best fun I’ve ever had."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1466
translate chinese CR4_love_hotel_lab4_b95ca4e5:

    # MC "C’mon, let’s get out of the bath and head to bed."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1467
translate chinese CR4_love_hotel_lab4_f38a57e1:

    # Caroline "Mmm, alright. I’ll grab some towels for us."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1470
translate chinese CR4_love_hotel_lab4_c4493be7:

    # Caroline "Thanks for the bath, [player_name]. I’ll catch you in bed when you finish drying yourself off."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1471
translate chinese CR4_love_hotel_lab4_271197a5:

    # MC "Two minutes and I’ll be there!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1481
translate chinese CR4_love_hotel_lab4_13e1a392:

    # MC "Would you be able to help me finish off, Caroline?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1482
translate chinese CR4_love_hotel_lab4_223c7336:

    # Caroline "Hehe, sure. Would you like me to use my mouth?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1483
translate chinese CR4_love_hotel_lab4_102b1dc6:

    # MC "Can you try your feet, for a change?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1486
translate chinese CR4_love_hotel_lab4_1e88bd99:

    # Caroline "My feet?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1487
translate chinese CR4_love_hotel_lab4_6db5f32d:

    # MC "Yeah, if that’s okay with you?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1488
translate chinese CR4_love_hotel_lab4_1fb2a615:

    # Caroline "Not a problem. I hope you’ll enjoy this."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1491
translate chinese CR4_love_hotel_lab4_ca1450fe:

    # Caroline "I’m going to massage all of your cock with my feet. You’ll be quivering with pleasure, in no time at all."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1492
translate chinese CR4_love_hotel_lab4_eb64e296:

    # MC "That’s a bold claim to make."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1495
translate chinese CR4_love_hotel_lab4_3a840e25:

    # Caroline "Do you not believe I can do it?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1496
translate chinese CR4_love_hotel_lab4_5f979920:

    # MC "I’ll wait and see."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1497
translate chinese CR4_love_hotel_lab4_0724151f:

    # Caroline "Hehe, let’s see how this plays out."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1500
translate chinese CR4_love_hotel_lab4_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1501
translate chinese CR4_love_hotel_lab4_624a3e08:

    # Caroline "Enjoying that?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1502
translate chinese CR4_love_hotel_lab4_465f8ac0:

    # MC "Ohh... That’s good."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1505
translate chinese CR4_love_hotel_lab4_a5f4daba:

    # Caroline "I’ll keep stroking my feet up and down your long, hard cock."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1506
translate chinese CR4_love_hotel_lab4_9fd5033c:

    # MC "Mmm, just like that. Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1508
translate chinese CR4_love_hotel_lab4_147dc962:

    # Caroline "(I love how stiff his cock feels under the soles of my feet.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1511
translate chinese CR4_love_hotel_lab4_c477e361:

    # Caroline "Do you enjoy it when I rub the tip of your cock with my toes?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1513
translate chinese CR4_love_hotel_lab4_2f6fda2f:

    # MC "Ohh... It’s amazing. Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1514
translate chinese CR4_love_hotel_lab4_d0398e22:

    # Caroline "That’s it. Keep moaning for me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1517
translate chinese CR4_love_hotel_lab4_cb0801cd:

    # MC "Ahhh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1518
translate chinese CR4_love_hotel_lab4_2528567a:

    # Caroline "(It seems he’s very sensitive when I do THIS around the tip! Perhaps I should focus more on that area.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1521
translate chinese CR4_love_hotel_lab4_ecceb611:

    # Caroline "(I don’t know why, but I feel so... powerful when I do this to [player_name].)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1522
translate chinese CR4_love_hotel_lab4_398bec32:

    # Caroline "(It’s not like giving a blowjob or handjob. They feel unusually submissive compared to using my feet.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1525
translate chinese CR4_love_hotel_lab4_b976556f:

    # MC "Oh God, don’t stop! Mmm! Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1526
translate chinese CR4_love_hotel_lab4_e232cb64:

    # Caroline "Are you going to cum? I want you to cum for me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1527
translate chinese CR4_love_hotel_lab4_d1616c2c:

    # MC "Ahhh... fuck!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1530
translate chinese CR4_love_hotel_lab4_73250c5b:

    # Caroline "I want you to ejaculate all over my feet."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1531
translate chinese CR4_love_hotel_lab4_c55fd56d:

    # MC "Fuck! Mmm! Ahh"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1534
translate chinese CR4_love_hotel_lab4_82587c48:

    # Caroline "That’s it, let me milk your hard cock with my soles."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1535
translate chinese CR4_love_hotel_lab4_6a83268a:

    # MC "Ahh - I’m cumnming!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1536
translate chinese CR4_love_hotel_lab4_0d8b9876:

    # Caroline "Cum for me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1539
translate chinese CR4_love_hotel_lab4_68376c81:

    # MC "Hnnnnggg! Aaahhhhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1540
translate chinese CR4_love_hotel_lab4_1417f8f5:

    # Caroline "Yes! That’s it!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1541
translate chinese CR4_love_hotel_lab4_804dfb9f:

    # MC "Ugh! Arrrghhh!!!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1551
translate chinese CR4_love_hotel_lab4_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1552
translate chinese CR4_love_hotel_lab4_290821a8:

    # Caroline "Wow... that’s a lot of cum! It’s a good thing we’re in the bath! Haha!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1553
translate chinese CR4_love_hotel_lab4_4ef60181:

    # Caroline "I’ll wash myself up and then meet you in the bedroom? Okay? You better have enough juice in you for another round."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1554
translate chinese CR4_love_hotel_lab4_dfdcd904:

    # MC "Y-Yeah *pant* Sure, I’ll see you *pant* there..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1566
translate chinese CR4_love_hotel_lab5_f9d51f67:

    # Caroline "Wait for me in the bed."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1578
translate chinese CR4_love_hotel_lab5_af4e7a38:

    # MC "Caroline? Where are you?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1579
translate chinese CR4_love_hotel_lab5_d10e9b0f:

    # Caroline "Just wait on the bed - I’ll be ready in a second!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1582
translate chinese CR4_love_hotel_lab5_ad6dfa1e:

    # MC "(I wonder what she’s doing now.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1583
translate chinese CR4_love_hotel_lab5_14fc9381:

    # Caroline "I got one final surprise for tonight that I wanted to share with you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1584
translate chinese CR4_love_hotel_lab5_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1591
translate chinese CR4_love_hotel_lab5_7fdece30:

    # Caroline "Ta-da! What do you think?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1592
translate chinese CR4_love_hotel_lab5_aee4159e:

    # MC "W-Wow! I think you look amazing!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1593
translate chinese CR4_love_hotel_lab5_786586ce:

    # Caroline "The woman in the lingerie shop recommended it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1596
translate chinese CR4_love_hotel_lab5_725b0cda:

    # Caroline "She might have actually been a lesbian... She was very insistent on helping me try it on..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1597
translate chinese CR4_love_hotel_lab5_4b27b5fb:

    # Caroline "Anyway! I’m glad you like it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1598
translate chinese CR4_love_hotel_lab5_9a5a119f:

    # MC "Your boobs look great in that!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1601
translate chinese CR4_love_hotel_lab5_a1ff1429:

    # Caroline "You really think so? How about I come a bit closer, so you can properly check them out."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1602
translate chinese CR4_love_hotel_lab5_0ce0527b:

    # MC "Mmm, I’d like that!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1603
translate chinese CR4_love_hotel_lab5_3e05366e:

    # MC "You get hotter every time I see you, Caroline. You know that?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1606
translate chinese CR4_love_hotel_lab5_a5e4a726:

    # Caroline "Really? I was kinda worrying you’d get bored with me someday."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1607
translate chinese CR4_love_hotel_lab5_151273ae:

    # MC "Never, Caroline. You’re the best thing I have in my life, right now."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1608
translate chinese CR4_love_hotel_lab5_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1611
translate chinese CR4_love_hotel_lab5_278d5957:

    # MC "I love you too, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1612
translate chinese CR4_love_hotel_lab5_1c5324c1:

    # Caroline "How about we warm up with a blowjob?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1613
translate chinese CR4_love_hotel_lab5_29e82a89:

    # MC "Wow, it really is my lucky night, isn’t it?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1616
translate chinese CR4_love_hotel_lab5_7879d84f:

    # MC "Do you not want me going down on you, for a change? Or-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1617
translate chinese CR4_love_hotel_lab5_6b061beb:

    # Caroline "Relax, I LOVE sucking your cock. And now I have a place I can do it without worrying about Linda or Sara walking in!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1618
translate chinese CR4_love_hotel_lab5_13245e10:

    # MC "Well, if you’re sure."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1621
translate chinese CR4_love_hotel_lab5_9fe39070:

    # Caroline "Of course I am, dummy! Now, just lie back and relax."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1623
translate chinese CR4_love_hotel_lab5_6e79f5ad:

    # Caroline "Let take your sister care of your big problem. Okay?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1625
translate chinese CR4_love_hotel_lab5_58302159:

    # Caroline "Let your girlfriend take care of your big problem. Okay?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1626
translate chinese CR4_love_hotel_lab5_90c52b84:

    # MC "Okay!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1629
translate chinese CR4_love_hotel_lab5_d0722184:

    # Caroline "I’m going to suck your fat cock until I’ve drained your balls, of every last drop."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1630
translate chinese CR4_love_hotel_lab5_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1633
translate chinese CR4_love_hotel_lab5_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1634
translate chinese CR4_love_hotel_lab5_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1637
translate chinese CR4_love_hotel_lab5_b0fe80b8:

    # MC "(This is going to be awesome! I can’t wait to fuck Caroline, all night long!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1639
translate chinese CR4_love_hotel_lab5_beb7ec2d:

    # MC "(I wish this night could just last forever, or even loop on repeat. That would be Heaven on Earth.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1642
translate chinese CR4_love_hotel_lab5_3b1121c2:

    # Caroline "I’m going to slip out of this nightgown now - but you just lie exactly where you are."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1643
translate chinese CR4_love_hotel_lab5_7c3ed074:

    # Caroline "I’ll be getting back to you very, very soon."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1646
translate chinese CR4_love_hotel_lab5_40a45763:

    # MC "*Whistle* You look stunning."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1647
translate chinese CR4_love_hotel_lab5_a7d0b09b:

    # Caroline "Hehe, I know."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1648
translate chinese CR4_love_hotel_lab5_252915d1:

    # Caroline "I love that bulge you’ve got going on in your pants. It’s a really hot look for you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1651
translate chinese CR4_love_hotel_lab5_7967eeca:

    # Caroline "However, they’re getting in the way. I’m going to need to take them off."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1652
translate chinese CR4_love_hotel_lab5_30e3323e:

    # MC "Be my guest."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1655
translate chinese CR4_love_hotel_lab5_19fa8835:

    # Caroline "(Wow, he’s so massive! I’m so excited to feel him inside my pussy again tonight.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1656
translate chinese CR4_love_hotel_lab5_914d5b6b:

    # Caroline "(Our first time at the lake was unbelievable. I hadn’t felt that much pleasure, in my life, before.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1659
translate chinese CR4_love_hotel_lab5_ab958b19:

    # Caroline "Hello, [player_name] Junior, you’re about to get licked and sucked so, so hard..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1660
translate chinese CR4_love_hotel_lab5_ac581b5f:

    # MC "(My heart is racing with excitement right now!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1663
translate chinese CR4_love_hotel_lab5_6ee340ee:

    # Caroline "Get ready, I’m about to blow, so much more than just your mind."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1664
translate chinese CR4_love_hotel_lab5_35cf4e87:

    # MC "Mmm, I can’t wait."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1667
translate chinese CR4_love_hotel_lab5_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1668
translate chinese CR4_love_hotel_lab5_6305452a:

    # MC "Ohhh, fuck... Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1669
translate chinese CR4_love_hotel_lab5_6047c7f5:

    # MC "(Holy shit, that feels so good.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1672
translate chinese CR4_love_hotel_lab5_8a0481c2:

    # MC "(It’s so hot watching her make eye contact with me as she licks my cock.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1673
translate chinese CR4_love_hotel_lab5_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1674
translate chinese CR4_love_hotel_lab5_f7fbce5f:

    # MC "Mmm... Ah... Oh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1677
translate chinese CR4_love_hotel_lab5_eec57016:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1678
translate chinese CR4_love_hotel_lab5_e016b0dc:

    # MC "Yes... Mmm... Just like that, Caroline. Ahh.."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1679
translate chinese CR4_love_hotel_lab5_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1682
translate chinese CR4_love_hotel_lab5_b180c7f9:

    # Caroline "*Shluuuurrrp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1683
translate chinese CR4_love_hotel_lab5_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1684
translate chinese CR4_love_hotel_lab5_535c9877:

    # MC "(Her mouth is so hot and wet, right now.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1687
translate chinese CR4_love_hotel_lab5_7f304be3:

    # Caroline "*SHLURP SUCK SUCK*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1688
translate chinese CR4_love_hotel_lab5_12d482e6:

    # Caroline "Mmm! Mmm... "
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1689
translate chinese CR4_love_hotel_lab5_027813fb:

    # MC "Ohhh... Ahhh! "
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1692
translate chinese CR4_love_hotel_lab5_7ba0b6ae:

    # Caroline "*Slurp Suck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1693
translate chinese CR4_love_hotel_lab5_7ce1ac67:

    # Caroline "*Suck Suck Suck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1694
translate chinese CR4_love_hotel_lab5_2a3dd532:

    # MC "Hnnng... Mmmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1697
translate chinese CR4_love_hotel_lab5_6f0268c3:

    # Caroline "Mppf! Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1698
translate chinese CR4_love_hotel_lab5_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1699
translate chinese CR4_love_hotel_lab5_2619ef3a:

    # MC "Ahh... shit... I’m gonna cum soon!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1702
translate chinese CR4_love_hotel_lab5_e0d1bc4f:

    # Caroline "*Suck* *Slurp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1703
translate chinese CR4_love_hotel_lab5_9bbc457e:

    # Caroline "(I should probably stop now, and make sure he has at least SOME cum left!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1704
translate chinese CR4_love_hotel_lab5_b54a2991:

    # Caroline "(I would like to get a nice warm creampie at the end of this, after all!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1707
translate chinese CR4_love_hotel_lab5_63d417a6:

    # MC "Fuck... *Pant* That was amazing."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1708
translate chinese CR4_love_hotel_lab5_7d4370a0:

    # Caroline "I’m glad you enjoyed it. How about we stop the blowjob now - and make sure you still have enough mojo for the main event?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1709
translate chinese CR4_love_hotel_lab5_1b0cbe21:

    # MC "Y-Yeah, *pant* I think that’s a good call."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1712
translate chinese CR4_love_hotel_lab5_b382b618:

    # Caroline "So, how would you like to do this? Any preference?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1713
translate chinese CR4_love_hotel_lab5_3780552d:

    # MC "I’m not fussy. Any way at all, works for me."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1714
translate chinese CR4_love_hotel_lab5_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1717
translate chinese CR4_love_hotel_lab5_c3e092c5:

    # Caroline "How about I kneel down, at the end of the bed?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1718
translate chinese CR4_love_hotel_lab5_fa71544b:

    # Caroline "Then you can fuck me doggy-style from behind."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1719
translate chinese CR4_love_hotel_lab5_b087a138:

    # MC "Yeah, that sounds good to me!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1722
translate chinese CR4_love_hotel_lab5_0321f2b1:

    # Caroline "Okay, ready when you are."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1723
translate chinese CR4_love_hotel_lab5_04f6b647:

    # Caroline "Don’t worry about being gentle - I’m already soaking wet. I’ve been waiting for this since dinner!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1726
translate chinese CR4_love_hotel_lab5_36e90c73:

    # MC "Okay, but if it hurts at all, please let me know. I want you to enjoy this too."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1727
translate chinese CR4_love_hotel_lab5_34fc4d0e:

    # Caroline "Relax, I’ll be fine. Okay?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1728
translate chinese CR4_love_hotel_lab5_51fa7e2c:

    # MC "Alright. (This is going to be amazing!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1731
translate chinese CR4_love_hotel_lab5_da1816a3:

    # Caroline "Are you enjoying the view?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1732
translate chinese CR4_love_hotel_lab5_19d68c11:

    # MC "Haha, of course."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1733
translate chinese CR4_love_hotel_lab5_cda397d5:

    # Caroline "Hurry up, I want to feel you inside me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1736
translate chinese CR4_love_hotel_lab5_26e3e5cd:

    # MC "I’m coming, Caroline. Just give me a minute."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1737
translate chinese CR4_love_hotel_lab5_8c4fef2d:

    # Caroline "(I’m so fucking horny right now. I feel like I could cum, the second he penetrates my pussy!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1740
translate chinese CR4_love_hotel_lab5_8f3948c3:

    # Caroline "C’mon, [player_name]. Don’t keep a girl waiting!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1741
translate chinese CR4_love_hotel_lab5_95421889:

    # MC "Easy. It’s going in now."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1742
translate chinese CR4_love_hotel_lab5_609432c2_1:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1745
translate chinese CR4_love_hotel_lab5_b256155c:

    # Caroline "Oh God... Yes..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1747
translate chinese CR4_love_hotel_lab5_e1e12506:

    # MC "(She wasn’t lying when she said she was wet! Her pussy is drenched with her juices, right now!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1748
translate chinese CR4_love_hotel_lab5_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1751
translate chinese CR4_love_hotel_lab5_c747894d:

    # Caroline "Oh, my God! YES! AHHH!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1752
translate chinese CR4_love_hotel_lab5_66397836:

    # MC "Mmm! Fuck... That’s good."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1753
translate chinese CR4_love_hotel_lab5_abe2a2c0:

    # Caroline "(His cock is so thick! It feels so good inside my pussy!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1756
translate chinese CR4_love_hotel_lab5_38a39d31:

    # Caroline "Yes, [player_name]! Fill me up! Ahh! Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1758
translate chinese CR4_love_hotel_lab5_f6e3d64d:

    # Caroline "Go deeper! I want to feel ALL of you inside me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1760
translate chinese CR4_love_hotel_lab5_3246853b:

    # MC "Hnng... "
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1763
translate chinese CR4_love_hotel_lab5_3a48011f:

    # Caroline "Ayaaaahhhh!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1764
translate chinese CR4_love_hotel_lab5_5e0df602:

    # MC "Hnnngg... Ohhh... Fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1765
translate chinese CR4_love_hotel_lab5_292d2eaf:

    # MC "(Her pussy is so damn tight! It feels like she’s massaging my cock with it!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1768
translate chinese CR4_love_hotel_lab5_72e16008:

    # Caroline "Oh! Oh, [player_name], I love you!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1769
translate chinese CR4_love_hotel_lab5_642e1fc4:

    # Caroline "Oh fuck! It’s so fucking good! Stir up my pussy with your big fucking cock!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1770
translate chinese CR4_love_hotel_lab5_44b6ee70:

    # MC "Ahh... Ugh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1773
translate chinese CR4_love_hotel_lab5_6869f612:

    # Caroline "Yes, [player_name]! Harder! Harder!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1774
translate chinese CR4_love_hotel_lab5_4742d564:

    # Caroline "Ahh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1775
translate chinese CR4_love_hotel_lab5_2ff1f26d:

    # MC "Oh! God! Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1778
translate chinese CR4_love_hotel_lab5_7f491a35:

    # MC "Your pussy is awesome! It feels so good plunging, my dick deep into you!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1779
translate chinese CR4_love_hotel_lab5_38b5500f:

    # Caroline "Mmm! Don’t stop!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1780
translate chinese CR4_love_hotel_lab5_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1783
translate chinese CR4_love_hotel_lab5_0f11c0f3:

    # Caroline "OHHHH!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1784
translate chinese CR4_love_hotel_lab5_d4184b43:

    # MC "Aaaaaahhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1787
translate chinese CR4_love_hotel_lab5_5efb9106:

    # Caroline "*Pant Pant* W-Wow! *Gasp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1788
translate chinese CR4_love_hotel_lab5_d1a9119c:

    # MC "(I think I’ve sent her pleasure receptors into overdrive! She can barely speak right now!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1791
translate chinese CR4_love_hotel_lab5_fd1f1aa6:

    # Caroline "[player_name]... *Pant* S-Soooo g-good! Ahh! AHH! *GASP*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1792
translate chinese CR4_love_hotel_lab5_e36235e9:

    # MC "(I can feel her pussy walls clamping down around my cock. She must have already climaxed a couple of times!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1794
translate chinese CR4_love_hotel_lab5_12780878:

    # Caroline "AHHHH! I’M CUMMING AGAIN!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1797
translate chinese CR4_love_hotel_lab5_34967343:

    # Caroline "*PANT* P-POUND MY SLUTTY LITTLE PUSSY!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1798
translate chinese CR4_love_hotel_lab5_12597dbe:

    # Caroline "MMM! YES! YES! Ahhh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1799
translate chinese CR4_love_hotel_lab5_9db20aa4:

    # MC "(I hope this hotel room has thick walls!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1802
translate chinese CR4_love_hotel_lab5_b8d97736:

    # Caroline "Ah! Ahhh! Ayyaaahhhh!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1803
translate chinese CR4_love_hotel_lab5_295f8c08:

    # Caroline "I love your cock! Yes! Mmmm! Harder! *Gasp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1804
translate chinese CR4_love_hotel_lab5_69ed3f41:

    # MC "Oh fuck... Hnnngg.... Ugh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1807
translate chinese CR4_love_hotel_lab5_7d40403f:

    # Caroline "Ah... Ah.... Ohhh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1808
translate chinese CR4_love_hotel_lab5_cbf9492d:

    # Caroline "Ohh... It’s so fucking good..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1809
translate chinese CR4_love_hotel_lab5_ccb6a6ff:

    # MC "Ahhh... I love you!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1812
translate chinese CR4_love_hotel_lab5_93d4c5ad:

    # MC "Ugh! Mmm! Ahh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1813
translate chinese CR4_love_hotel_lab5_6e6c4da2:

    # Caroline "Oh! OHHH! YESSSS!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1816
translate chinese CR4_love_hotel_lab5_092a1a65:

    # Caroline "D-Do you want to *pant* swap positions?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1817
translate chinese CR4_love_hotel_lab5_52143cf5:

    # MC "Ugh, sure! What were you thinking?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1818
translate chinese CR4_love_hotel_lab5_c5036271:

    # Caroline "Let’s try... this!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1821
translate chinese CR4_love_hotel_lab5_25ca52b1:

    # MC "Oh wow! Yoga classes really paid off, huh?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1822
translate chinese CR4_love_hotel_lab5_58bf4fec:

    # Caroline "Hehe, they sure did!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1823
translate chinese CR4_love_hotel_lab5_2668a438:

    # MC "I’ve never seen anyone spread their legs that wide before!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1826
translate chinese CR4_love_hotel_lab5_23c78ec4:

    # Caroline "Pound me really hard, [player_name]. I want to feel you slam my pussy and make me cum!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1827
translate chinese CR4_love_hotel_lab5_ce52ed49:

    # MC "(Damn, she’s got a really nice asshole. I wish I could fuck that too, right now.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1828
translate chinese CR4_love_hotel_lab5_723ce289:

    # MC "(I should probably stick to her cunt, for the time being.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1831
translate chinese CR4_love_hotel_lab5_5093672b:

    # MC "I’ll go as hard as I can, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1832
translate chinese CR4_love_hotel_lab5_7e6eada2:

    # Caroline "(This is going to feel so good!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1835
translate chinese CR4_love_hotel_lab5_b39e109b:

    # Caroline "Ohhh! Push it deep inside me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1836
translate chinese CR4_love_hotel_lab5_b987e77d_2:

    # MC "Ahh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1839
translate chinese CR4_love_hotel_lab5_ec19fa09:

    # Caroline "MMMM!!! Just like that! Ohhh God..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1840
translate chinese CR4_love_hotel_lab5_068d636f:

    # Caroline "(I can feel his hard dick, pushing up against my g-spot!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1843
translate chinese CR4_love_hotel_lab5_020644d5:

    # Caroline "Ah! Ahh! Yes! Fuck me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1844
translate chinese CR4_love_hotel_lab5_347505e7:

    # MC "Ahh... Ohhh... "
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1845
translate chinese CR4_love_hotel_lab5_310034b3:

    # MC "(Her pussy feels even tighter, with her legs spread like that, it’s like her vagina is sucking on my dick, every time I try to pull out!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1848
translate chinese CR4_love_hotel_lab5_21db2b22:

    # Caroline "Oooohhhh yeeeaaahhh! Harder, [player_name]! Fuck me harder!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1849
translate chinese CR4_love_hotel_lab5_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1850
translate chinese CR4_love_hotel_lab5_163f6ab5:

    # MC "(Her legs are trembling now! She’s clearly loving this!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1853
translate chinese CR4_love_hotel_lab5_6546f7c5:

    # Caroline "AAAAAAHHHHHHH!!!! I’m cumming! I’m fucking cumming!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1854
translate chinese CR4_love_hotel_lab5_9246f825:

    # Caroline "(Holy shit! I can barely hold my legs apart! My entire body is trembling with an orgasm!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1855
translate chinese CR4_love_hotel_lab5_c7b67557:

    # MC "(I’m going to cum too!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1862
translate chinese CR4_love_hotel_lab5_26b28d94:

    # MC "Hnnng! I’m cumming!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1863
translate chinese CR4_love_hotel_lab5_a1bd9fcd:

    # Caroline "Oh yes! Fill me up! Fill me up! Ahhh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1865
translate chinese CR4_love_hotel_lab5_0ded8d58:

    # MC "UGHHH! AHHHH!!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1873
translate chinese CR4_love_hotel_lab5_6288f048:

    # Caroline "(I can feel his hot cum, flooding inside me!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1880
translate chinese CR4_love_hotel_lab5_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1881
translate chinese CR4_love_hotel_lab5_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1882
translate chinese CR4_love_hotel_lab5_e6dfb30c:

    # MC "Hnnnnggg! Gahhh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1890
translate chinese CR4_love_hotel_lab5_44e75a12:

    # Caroline "(Aww, I wish he’d cum inside me. Oh well, there'll be other opportunities tonight.)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1895
translate chinese CR4_love_hotel_lab6_9ce99a84:

    # MC "*Pant* That was... really good work..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1896
translate chinese CR4_love_hotel_lab6_56a039be:

    # Caroline "You weren’t half bad yourself! That was REALLY good sex..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1897
translate chinese CR4_love_hotel_lab6_86303a2b:

    # Caroline "Like, seriously mind blowing!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1900
translate chinese CR4_love_hotel_lab6_6bd922e5:

    # MC "Haha, you were shaking and trembling so much, I thought there was an earthquake, for a second."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1901
translate chinese CR4_love_hotel_lab6_91bf12bd:

    # Caroline "Haha! Says the guy who was moaning so loudly, the entire hotel could hear him!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1902
translate chinese CR4_love_hotel_lab6_2317ba68:

    # MC "You’re not seriously trying to blame that on me. Did you hear how loud you were?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1903
translate chinese CR4_love_hotel_lab6_54bb9c9e:

    # Caroline "Haha! I couldn’t hear myself, over your grunting!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1906
translate chinese CR4_love_hotel_lab6_95289020:

    # Caroline "Say, do you think I’ll be able to get another round later on?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1907
translate chinese CR4_love_hotel_lab6_8c04384d:

    # MC "Sure, I don’t see why not."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1910
translate chinese CR4_love_hotel_lab6_ddc8d31a:

    # Caroline "How long until he is hard again?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1911
translate chinese CR4_love_hotel_lab6_c72bbb3d:

    # MC "Maybe an hour? Two at most?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1912
translate chinese CR4_love_hotel_lab6_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1915
translate chinese CR4_love_hotel_lab6_f63378c3:

    # Caroline "What if I offered you the chance to fuck ANY hole you wanted, of my body? Would that encourage your guy to get stiff again sooner?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1916
translate chinese CR4_love_hotel_lab6_6b9f9273:

    # MC "Any hole? Even anal?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1917
translate chinese CR4_love_hotel_lab6_afb9e7af:

    # Caroline "If that’s what you want."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1920
translate chinese CR4_love_hotel_lab6_514ace2f:

    # MC "Hmm, I think that sounds like a VERY tempting offer."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1921
translate chinese CR4_love_hotel_lab6_66f65d60:

    # Caroline "In fact, I’ll go one step further."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1922
translate chinese CR4_love_hotel_lab6_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1925
translate chinese CR4_love_hotel_lab6_568b06cb:

    # Caroline "Not only can you fuck whatever hole you want - but you can creampie it too."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1926
translate chinese CR4_love_hotel_lab6_da14d9e8:

    # MC "Now, that is enticing."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1927
translate chinese CR4_love_hotel_lab6_856341a0:

    # Caroline "No condoms. Just raw, unprotected fucking."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1928
translate chinese CR4_love_hotel_lab6_74c504ff:

    # MC "Let me just refresh with a drink, and then we’ll get back to it."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1931
translate chinese CR4_love_hotel_lab6_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1932
translate chinese CR4_love_hotel_lab6_b0e9580c:

    # Caroline "*Glug Glug*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1933
translate chinese CR4_love_hotel_lab6_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1936
translate chinese CR4_love_hotel_lab6_4c536e71:

    # MC "He’s probably going to need at least another twenty minutes, to get hard."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1937
translate chinese CR4_love_hotel_lab6_ddb2f738:

    # MC "Do you want to cuddle or nap for a little bit, while we wait?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1938
translate chinese CR4_love_hotel_lab6_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1941
translate chinese CR4_love_hotel_lab6_f30134d3:

    # Caroline "Does the thought of plunging your naked cock, into my soaking wet pussy, not get you hard?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1942
translate chinese CR4_love_hotel_lab6_4eeda26a:

    # Caroline "If it doesn’t, then perhaps the thought of ejaculating, balls-deep, inside me might."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1943
translate chinese CR4_love_hotel_lab6_7e868121:

    # Caroline "Think about yourself grabbing my ass as you bury your shaft, as deep as it will go. Imagine the sensation of my pussy, milking your cock, of every last drop of your cum."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1946
translate chinese CR4_love_hotel_lab6_770ffb5f:

    # Caroline "Well... that did the trick!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1947
translate chinese CR4_love_hotel_lab6_bec2ab11:

    # MC "It certainly did. Haha!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1948
translate chinese CR4_love_hotel_lab6_0a889f8e:

    # MC "Shall we get things started, then?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1949
translate chinese CR4_love_hotel_lab6_54aa39fc:

    # Caroline "Let me just make sure he STAYS hard first."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1952
translate chinese CR4_love_hotel_lab6_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1953
translate chinese CR4_love_hotel_lab6_3b109c95:

    # MC "Mmm, fuck... You’re so good at that, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1956
translate chinese CR4_love_hotel_lab6_f6d34698:

    # Caroline "Mmm... *Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1957
translate chinese CR4_love_hotel_lab6_38b20d2e:

    # MC "Oh... Fuck... Wow..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1960
translate chinese CR4_love_hotel_lab6_57cac9a1:

    # Caroline "*Shlurp* *Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1961
translate chinese CR4_love_hotel_lab6_2c780c23:

    # MC "AH! Ahh... God..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1962
translate chinese CR4_love_hotel_lab6_b93b7455:

    # MC "(My cock is so sensitive right now!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1966
translate chinese CR4_love_hotel_lab6_8507d6be:

    # MC "You’re amazing mmm... at that, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1967
translate chinese CR4_love_hotel_lab6_e2c07e81_1:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1968
translate chinese CR4_love_hotel_lab6_77b9344f:

    # MC "Oh fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1971
translate chinese CR4_love_hotel_lab6_7808d7e8:

    # Caroline "*SHLURP* *SUCK*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1972
translate chinese CR4_love_hotel_lab6_c9c76242:

    # MC "Ahh... Yes! Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1975
translate chinese CR4_love_hotel_lab6_e0cee18c:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1976
translate chinese CR4_love_hotel_lab6_13186e8e:

    # MC "Ohhhh! Ahhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1977
translate chinese CR4_love_hotel_lab6_62fc944c:

    # Caroline "Hehe, okay, I think that’s you guaranteed to be hard for a LONG time!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1980
translate chinese CR4_love_hotel_lab6_122033ca:

    # Caroline "Now, how does this angle work for you?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1981
translate chinese CR4_love_hotel_lab6_2ef37352:

    # MC "Looks hot to me, Caroline. I’m ready whenever you are."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1982
translate chinese CR4_love_hotel_lab6_f1bc3444:

    # Caroline "Great!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1985
translate chinese CR4_love_hotel_lab6_ce5b7f11:

    # Caroline "Are you enjoying tonight so far?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1986
translate chinese CR4_love_hotel_lab6_3a112969:

    # MC "Of course I am! This is, like, the best night I have ever had in my whole life!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1987
translate chinese CR4_love_hotel_lab6_f4d91aed:

    # Caroline "Really?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1988
translate chinese CR4_love_hotel_lab6_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1991
translate chinese CR4_love_hotel_lab6_c206d120:

    # Caroline "I’m glad you’re enjoying it that much."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1992
translate chinese CR4_love_hotel_lab6_57766d33:

    # Caroline "It’s the best night I’ve ever had too. You have really made me feel so special today, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1993
translate chinese CR4_love_hotel_lab6_2338451b:

    # MC "I love you, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1996
translate chinese CR4_love_hotel_lab6_7da9fa5c:

    # Caroline "I love you too. Now, would you rather fuck me pussy or my ass tonight?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:1997
translate chinese CR4_love_hotel_lab6_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2002
translate chinese CR4_love_hotel_lab6_1f46f43e:

    # MC "I just can’t get enough of your pussy, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2003
translate chinese CR4_love_hotel_lab6_1c33864a:

    # Caroline "Hehe, I’m glad you’re enjoying it. It’s all yours."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2006
translate chinese CR4_love_hotel_lab6_94d044b6:

    # Caroline "Mmm... Ohhh fuck..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2007
translate chinese CR4_love_hotel_lab6_f5c09c75:

    # MC "Ahh... It’s so good."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2008
translate chinese CR4_love_hotel_lab6_45f1580b:

    # Caroline "Ohh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2011
translate chinese CR4_love_hotel_lab6_5a5d6077:

    # Caroline "Just like that, [player_name]... Ah..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2012
translate chinese CR4_love_hotel_lab6_09680cc5:

    # MC "Fuck... I don’t know if I’ll last very long, Caroline. I’ve already cum far too many times today!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2013
translate chinese CR4_love_hotel_lab6_1ee665ae:

    # Caroline "Hehe, don’t worry. I’ve enjoyed it."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2016
translate chinese CR4_love_hotel_lab6_efd0c315:

    # Caroline "Just fuck me as fast and as hard as you can. Okay?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2017
translate chinese CR4_love_hotel_lab6_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2020
translate chinese CR4_love_hotel_lab6_9a554c15:

    # MC "Ohh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2021
translate chinese CR4_love_hotel_lab6_3ca93e03:

    # Caroline "AHHH!! Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2024
translate chinese CR4_love_hotel_lab6_58f1820e:

    # Caroline "Oh, my God, you’re so thick! Ah..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2025
translate chinese CR4_love_hotel_lab6_738da62d:

    # Caroline "Wow, you're mmm... stretching my pussy, to the limit! *Gasp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2028
translate chinese CR4_love_hotel_lab6_2b033dd4:

    # Caroline "Oh yes, yes, yes! Holy shit, yes! MMM! FUCK! Ahhhh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2029
translate chinese CR4_love_hotel_lab6_cc78f9a1:

    # MC "Ugh! Hnnngg! Aaaahhhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2030
translate chinese CR4_love_hotel_lab6_6eecb1c1:

    # Caroline "Harder! Harder! *GASP*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2033
translate chinese CR4_love_hotel_lab6_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2034
translate chinese CR4_love_hotel_lab6_f5b6b7c9:

    # Caroline "I’m cumming! I’m cumming! AAYAAAAHHHH!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2037
translate chinese CR4_love_hotel_lab6_9674362e:

    # MC "Mmm! Oh God, yes! Hnnng!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2038
translate chinese CR4_love_hotel_lab6_b2ed607b:

    # Caroline "AHHH! AHHH!!! *GASP*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2041
translate chinese CR4_love_hotel_lab6_fd359ebe:

    # Caroline "Don’t stop! *PANT* D-DON’T STOP! MMM!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2042
translate chinese CR4_love_hotel_lab6_093716d2:

    # MC "Hnnnggg... I’m gonna cum soon!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2045
translate chinese CR4_love_hotel_lab6_5996c27f:

    # MC "(Where should I finish this time? In Caroline’s pussy or on her ass?)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2050
translate chinese CR4_love_hotel_lab6_375ba8ef:

    # MC "(Fuck it, I’ll cum inside her!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2051
translate chinese CR4_love_hotel_lab6_ad1b6c11:

    # MC "I’m cumming! Hnngg!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2052
translate chinese CR4_love_hotel_lab6_b29d9ef6:

    # Caroline "Ah yes! Cum inside me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2055
translate chinese CR4_love_hotel_lab6_dd889bbe:

    # MC "Hnnnngggg!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2056
translate chinese CR4_love_hotel_lab6_c17dcd08:

    # Caroline "Ahh! Fuck me really *Gasp* fast at the end!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2057
translate chinese CR4_love_hotel_lab6_6737f8ad:

    # Caroline "AAAYAAAAAHHHHH!!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2060
translate chinese CR4_love_hotel_lab6_a5cc5cab:

    # MC "Oh! Oh fuck! Yes! Hnng! Mmm!! Ahhhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2061
translate chinese CR4_love_hotel_lab6_e9ac151a:

    # Caroline "Ahh! AHHHH!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2064
translate chinese CR4_love_hotel_lab6_7345a86b:

    # Caroline "Oh fuck!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2066
translate chinese CR4_love_hotel_lab6_cdfe4848:

    # Caroline "(I’ve never climaxed this hard in my life, before!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2069
translate chinese CR4_love_hotel_lab6_08fe4cb2:

    # MC "Hnnnnnggg! UGH! Ahhhh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2079
translate chinese CR4_love_hotel_lab6_5525b914:

    # Caroline "Ohhh... wow... *Pant*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2080
translate chinese CR4_love_hotel_lab6_079d60d2:

    # MC "(I think that’s the last time I’m going to cum tonight. I’ve got nothing left...)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2081
translate chinese CR4_love_hotel_lab6_4bb87903:

    # MC "*Pant* Ohh... Caroline..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2084
translate chinese CR4_love_hotel_lab6_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2085
translate chinese CR4_love_hotel_lab6_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2086
translate chinese CR4_love_hotel_lab6_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2087
translate chinese CR4_love_hotel_lab6_1be968eb:

    # Caroline "I love you too..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2090
translate chinese CR4_love_hotel_lab6_282bbec6:

    # Caroline "*Gasp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2091
translate chinese CR4_love_hotel_lab6_b5ccd5c8:

    # MC "How does it feel?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2092
translate chinese CR4_love_hotel_lab6_4813a6d9:

    # Caroline "Really... warm. I love how it feels when it blasts, up against my cervix. It’s so hot."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2098
translate chinese CR4_love_hotel_lab6_06eb979e:

    # MC "I’m going to pull out and cum over your ass."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2100
translate chinese CR4_love_hotel_lab6_29d7b69b:

    # Caroline "Uh huh! Ahh... Oh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2111
translate chinese CR4_love_hotel_lab6_461793f8:

    # MC "Ugh! Ahhh... *Pant*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2112
translate chinese CR4_love_hotel_lab6_e8ba4d44:

    # MC "HNNNNGGGG!!! Ohhh!! Fuck!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2113
translate chinese CR4_love_hotel_lab6_2e44c4f7:

    # Caroline "Ohh... That was incredible, [player_name]. Thank you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2118
translate chinese CR4_love_hotel_lab6_ec479efd:

    # MC "I’m going to fuck you in the ass."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2119
translate chinese CR4_love_hotel_lab6_45408895:

    # Caroline "Okay, we probably won’t need lube. Your cock should be wet enough, with my juices."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2120
translate chinese CR4_love_hotel_lab6_309e581a:

    # Caroline "Just go slow at first, until you get it in!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2123
translate chinese CR4_love_hotel_lab6_f686530a:

    # Caroline "OHHH!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2124
translate chinese CR4_love_hotel_lab6_49d68aa4:

    # MC "Sorry, did that hurt?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2125
translate chinese CR4_love_hotel_lab6_3ff6c8a3:

    # Caroline "N-Not really. Ah... Just a bit surprising."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2128
translate chinese CR4_love_hotel_lab6_76737861:

    # MC "That’s the tip in your ass. I’m going to thrust the rest in now."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2129
translate chinese CR4_love_hotel_lab6_3d0d6699:

    # Caroline "*Gulp* O-Okay."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2130
translate chinese CR4_love_hotel_lab6_266a4790:

    # Caroline "(Please don’t hurt too much...)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2133
translate chinese CR4_love_hotel_lab6_1d05a90b:

    # MC "Mmm... Ahhh..."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2134
translate chinese CR4_love_hotel_lab6_268403d9:

    # Caroline "Ohh... Ah...."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2135
translate chinese CR4_love_hotel_lab6_2ded5ed6:

    # Caroline "(Deep breaths, you can do this!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2138
translate chinese CR4_love_hotel_lab6_74cf8956:

    # Caroline "Ahh.. Ohh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2139
translate chinese CR4_love_hotel_lab6_390d8745:

    # MC "(It sounds like she’s starting to moan in pleasure now! This must be feeling pretty good for her!)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2140
translate chinese CR4_love_hotel_lab6_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2143
translate chinese CR4_love_hotel_lab6_e44f01c4:

    # Caroline "Oh fuck... Ah... Shit..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2144
translate chinese CR4_love_hotel_lab6_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2145
translate chinese CR4_love_hotel_lab6_c4517cea:

    # Caroline "Y-Yeah, it’s just really intense."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2148
translate chinese CR4_love_hotel_lab6_1e7ec8f4:

    # Caroline "OHHH! Mmm! Ahh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2149
translate chinese CR4_love_hotel_lab6_dc52c2f7:

    # Caroline "(Wow, this feels amazing. I’m so damn wet right now!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2150
translate chinese CR4_love_hotel_lab6_0ed0ee2d:

    # MC "God, your ass is soooo tight! It feels amazing to fuck!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2153
translate chinese CR4_love_hotel_lab6_2144771f:

    # MC "Ah! Ahhh! Mmm!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2154
translate chinese CR4_love_hotel_lab6_98d47bed:

    # Caroline "*Gasp* Oh! Oh, [player_name]! Ahh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2155
translate chinese CR4_love_hotel_lab6_4f5d4b33:

    # MC "Ugh! I’m gonna cum!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2158
translate chinese CR4_love_hotel_lab6_75374d79:

    # Caroline "Mmm! Cum inside my ass!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2159
translate chinese CR4_love_hotel_lab6_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2161
translate chinese CR4_love_hotel_lab6_8290b60b:

    # Caroline "Fill your sister’s ass with cum! AHHHH!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2163
translate chinese CR4_love_hotel_lab6_84bf1e2c:

    # Caroline "Fill your girlfriend’s ass with cum! AHHHH!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2166
translate chinese CR4_love_hotel_lab6_617b11f7:

    # MC "Aaayaaahhhh! HNNNNGGG!"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2176
translate chinese CR4_love_hotel_lab6_b2c9e4a1:

    # Caroline "It’s so hot! Oh God! Yes!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2177
translate chinese CR4_love_hotel_lab6_bae9df66:

    # MC "Ughhhh... Ahhh.... *Pant*"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2178
translate chinese CR4_love_hotel_lab6_5fae972b:

    # MC "W-Wow, that was the best... Thank you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2186
translate chinese CR4_love_hotel_lab7_f2c82357:

    # Caroline "That was... absolutely phenomenal..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2187
translate chinese CR4_love_hotel_lab7_ccbdca25:

    # Caroline "I’d been imagining what this day might be like, for a long time now."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2188
translate chinese CR4_love_hotel_lab7_45d8a747:

    # Caroline "It had always been amazing when I dreamt about it, as I slept."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2191
translate chinese CR4_love_hotel_lab7_7a2b51f3:

    # Caroline "But I always knew, deep down, that reality wouldn’t live up to my dreams and fantasies."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2192
translate chinese CR4_love_hotel_lab7_76090a69:

    # MC "Did tonight, at least come close to how you imagined it would be?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2195
translate chinese CR4_love_hotel_lab7_36fd1fc7:

    # Caroline "Here’s the strange thing..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2196
translate chinese CR4_love_hotel_lab7_17b73922:

    # Caroline "...it was better than I’d ever imagined it would be. It was better than any dream I’d ever had, about us being together like this."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2197
translate chinese CR4_love_hotel_lab7_af0ceeff:

    # MC "I’m so happy to hear that."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2200
translate chinese CR4_love_hotel_lab7_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2201
translate chinese CR4_love_hotel_lab7_8f692224:

    # MC "(I never got the chance to tell her that I feel the same way, before she kissed me.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2202
translate chinese CR4_love_hotel_lab7_890577de:

    # MC "(Tonight was absolutely incredible. Indescribable actually.)"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2205
translate chinese CR4_love_hotel_lab7_3168010c:

    # MC "It was like that for me too."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2206
translate chinese CR4_love_hotel_lab7_daa14446:

    # MC "And it’ll be like this every day, for the rest of our lives together, Caroline. I promise."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2207
translate chinese CR4_love_hotel_lab7_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2210
translate chinese CR4_love_hotel_lab7_4e280471:

    # MC "I love you too, Car-"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2211
translate chinese CR4_love_hotel_lab7_7af033e3:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2212
translate chinese CR4_love_hotel_lab7_4a074974:

    # MC "Sweet dreams."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2215
translate chinese CR4_love_hotel_lab7_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2216
translate chinese CR4_love_hotel_lab7_c1b7500e:

    # MC "And I always will."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2217
translate chinese CR4_love_hotel_lab7_8993c011:

    # Caroline "Zzz... me... too..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2225
translate chinese CR4_love_hotel_lab7_875c7c25:

    # Caroline "YAWN!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2226
translate chinese CR4_love_hotel_lab7_0465d0a3:

    # Caroline "(Clear skies. God, what a beautiful day!)"
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2227
translate chinese CR4_love_hotel_lab7_b0c98b47:

    # MC "Hmm... Zzz.."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2230
translate chinese CR4_love_hotel_lab7_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2231
translate chinese CR4_love_hotel_lab7_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2232
translate chinese CR4_love_hotel_lab7_ba3bba91:

    # Caroline "Hey, sleepyhead. You’re finally awake. It doesn't surprise me, you slept in late. You kinda used up most of your energy last night."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2235
translate chinese CR4_love_hotel_lab7_3e3259a1:

    # MC "Mmm... Morning... Heh, I guess I did"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2236
translate chinese CR4_love_hotel_lab7_5f210e0f:

    # MC "How’d you sleep?"
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2237
translate chinese CR4_love_hotel_lab7_d3106d0d:

    # Caroline "Like a baby. I felt so... safe, lying beside you."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2239
translate chinese CR4_love_hotel_lab7_147c0569:

    # Caroline "I really wish... It’s a shame the rest of the family can’t know about us being together."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2241
translate chinese CR4_love_hotel_lab7_1e9c765c:

    # Caroline "I really wish... We should think about telling Bob, Linda, and Sara about us."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2242
translate chinese CR4_love_hotel_lab7_0a5be413:

    # MC "Not yet, but someday soon."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2245
translate chinese CR4_love_hotel_lab7_4d3c20fb:

    # MC "Someday soon, you’ll be able to feel the way you felt last night, for the rest of your life. I’m here till the very end, Caroline."
    MC ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2246
translate chinese CR4_love_hotel_lab7_f628643a:

    # Caroline "I know..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R4/CR4_WE.rpy:2247
translate chinese CR4_love_hotel_lab7_77d8677e:

    # Caroline "...and it’s the happy ending I’ve always wanted."
    Caroline ""

