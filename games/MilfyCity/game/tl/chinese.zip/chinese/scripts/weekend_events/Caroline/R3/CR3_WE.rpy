﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:129
translate chinese CR3_WE_label_0c7f8c29:

    # MC "(Alright, I’m going out with Caroline tonight. I’ll have to pick something smart to wear.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:130
translate chinese CR3_WE_label_ca20fbbd:

    # MC "Hmm... (Maybe this will look good?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:134
translate chinese CR3_WE_label_03225ad4:

    # MC "(It doesn’t look bad - but if we’re going, clubbing and dancing, then I’m gonna be sweating like crazy in a jumper. I should probably settle for something lighter.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:135
translate chinese CR3_WE_label_94f618a6:

    # MC "(Let’s take another look, and see what else I have...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:143
translate chinese CR3_WE_label_0483967c:

    # MC "(Dammit... Too preppy, too heavy, that’s for the winter..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:144
translate chinese CR3_WE_label_329c21d9:

    # MC "(There’s nothing good here!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:148
translate chinese CR3_WE_label_55556cab:

    # MC "(I’m stressing too much, over this, right?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:150
translate chinese CR3_WE_label_6b2e7a4f:

    # MC "(I mean, we’re not even going on a date - it’s just a brother and sister, going out clubbing.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:152
translate chinese CR3_WE_label_fa028626:

    # MC "(I mean, we’re not even going on a date - it’s just a pair of friends going out clubbing.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:153
translate chinese CR3_WE_label_d776cf63:

    # MC "(I should just go as I am!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:186
translate chinese CR3_WE_label_con1_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:187
translate chinese CR3_WE_label_con1_96473eb5:

    # MC "(She looks incredible! I feel guilty about not dressing up now!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:188
translate chinese CR3_WE_label_con1_d82af5aa:

    # MC "(It looks like she even spent time doing her makeup. She was quite adamant that this WASN’T a date though. She said we’re both supposed to be looking for new partners tonight...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:192
translate chinese CR3_WE_label_con1_a4b459a9:

    # MC "Hey, Caroline! You’re looking great in that dress!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:193
translate chinese CR3_WE_label_con1_1719fba6:

    # Caroline "Hi, [player_name]! Glad you finally made it!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:194
translate chinese CR3_WE_label_con1_ed2c941d:

    # Caroline "I’m already regretting wearing high heels... My feet are going to be DEAD by the end of tonight! Haha!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:198
translate chinese CR3_WE_label_con1_f1970c1a:

    # MC "Ouch! Well, if you need me to give you a piggy back later on, I can."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:199
translate chinese CR3_WE_label_con1_8440131c:

    # Caroline "Ahaha! In this dress?! That is NEVER gonna happen. Nice try, though..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:200
translate chinese CR3_WE_label_con1_8a578763:

    # MC "How about we grab a table? This place is already starting to fill up."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:204
translate chinese CR3_WE_label_con1_e110817e:

    # Caroline "Yeah, I saw a good one over there - right beside the bar."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:205
translate chinese CR3_WE_label_con1_f26d9b73:

    # MC "Sweet! Let’s get it before someone else does!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:209
translate chinese CR3_WE_label_con1_51501d1a:

    # MC "Here, let me get that chair for you."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:210
translate chinese CR3_WE_label_con1_7de9df2e:

    # Caroline "Aww, thanks."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:211
translate chinese CR3_WE_label_con1_958112d7:

    # Caroline "You DO remember that this isn’t a date between us, right?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:212
translate chinese CR3_WE_label_con1_4f658c6c:

    # MC "I know. I know. We’re looking for other people."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:216
translate chinese CR3_WE_label_con1_cc30aa8d:

    # Caroline "Good, I just wanted to clear that up."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:217
translate chinese CR3_WE_label_con1_2bf131ce:

    # MC "(I’ll just linger here, for a few extra seconds, to enjoy looking at her cleavage.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:218
translate chinese CR3_WE_label_con1_c0d028c0:

    # MC "(She’s the sexiest girl in the whole club, with that little black dress on!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:222
translate chinese CR3_WE_label_con1_837492ae:

    # MC "I’m gonna grab myself something to drink - What can I get you?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:223
translate chinese CR3_WE_label_con1_371ac784:

    # Caroline "Take a seat, [player_name] - I already ordered for us both."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:224
translate chinese CR3_WE_label_con1_d52dd3fe:

    # MC "Really?! How much do I owe you?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:229
translate chinese CR3_WE_label_con1_4cafc149:

    # Caroline "Relax! I’ve got plenty to spend, right now. We’ve done all - the hard work - establishing my business. Now it’s time to enjoy - the fruits of our labour!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:230
translate chinese CR3_WE_label_con1_893fdfc8:

    # MC "Cheers to that! Thanks!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:231
translate chinese CR3_WE_label_con1_6771e042:

    # Caroline "Ahh! Here comes the waiter now!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:235
translate chinese CR3_WE_label_con1_92ff4f8e:

    # MC "H-Holy shit! Did you order, half the freaking bar?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:236
translate chinese CR3_WE_label_con1_168d088c:

    # Caroline "What? You’ve never been drinking before?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:237
translate chinese CR3_WE_label_con1_4eee5289:

    # MC "Caroline! There’s enough here to get a frat house drunk!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:238
translate chinese CR3_WE_label_con1_ccd8d10e:

    # Caroline "Lucky us, then!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:251
translate chinese CR3_WE_label_con1_menu_feb298e6:

    # MC "Do you usually drink this much, on a night out?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:252
translate chinese CR3_WE_label_con1_menu_8f3af60e:

    # Caroline "Yeah - Do you not?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:253
translate chinese CR3_WE_label_con1_menu_7de7c79b:

    # MC "N-No, not really... It just seems like... an unhealthy amount of liquor."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:257
translate chinese CR3_WE_label_con1_menu_352fc936:

    # Caroline "This is how you CELEBRATE, [player_name]! Now c’mon - let’s clink glasses, and get this party started!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:259
translate chinese CR3_WE_label_con1_menu_5c1c7a7f:

    # Caroline "This is how you CELEBRATE! Now c’mon, let’s clink glasses and get this party started!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:260
translate chinese CR3_WE_label_con1_menu_7b8fd8d0:

    # MC "(I wonder if she’s drinking to celebrate, or because she’s upset about something.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:264
translate chinese CR3_WE_label_con1_menu_4c87f434:

    # MC "Cheers, I guess!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:265
translate chinese CR3_WE_label_con1_menu_15785a70:

    # Caroline "There we go!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:276
translate chinese CR3_WE_label_con1_menu_454113c9:

    # MC "This stuff looks pretty strong! What is it?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:277
translate chinese CR3_WE_label_con1_menu_d328cae1:

    # Caroline "You mean, your drink?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:278
translate chinese CR3_WE_label_con1_menu_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:282
translate chinese CR3_WE_label_con1_menu_e0d7838c:

    # Caroline "Well, I ordered us some, red wine, vodka, and whiskey. We’re both - kicking it off - with a glass of bourbon."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:283
translate chinese CR3_WE_label_con1_menu_5f5878f2:

    # MC "Is bourbon not like... super strong? I mean, this looks like - a really big glass - of it."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:284
translate chinese CR3_WE_label_con1_menu_5c85d1de:

    # Caroline "It’s only forty percent..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:288
translate chinese CR3_WE_label_con1_menu_abba8cc1:

    # MC "Forty percent?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:289
translate chinese CR3_WE_label_con1_menu_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:293
translate chinese CR3_WE_label_con1_menu_b1af2522:

    # Caroline "What? You look shocked."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:294
translate chinese CR3_WE_label_con1_menu_79cb9604:

    # MC "It’s nothing..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:295
translate chinese CR3_WE_label_con1_menu_0fb8dafd:

    # MC "(I guess we’re both getting wasted tonight, then...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:306
translate chinese CR3_WE_label_con1_menu_83589882:

    # MC "Do you still want me to help you find a boyfriend tonight?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:307
translate chinese CR3_WE_label_con1_menu_a176ad57:

    # Caroline "Absolutely! I’ve had terrible luck picking guys, for my past three relationships. I figured I’d just drink up and let someone else take the wheel tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:308
translate chinese CR3_WE_label_con1_menu_d44059ee:

    # MC "So... What kind of guys do you like?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:312
translate chinese CR3_WE_label_con1_menu_69921054:

    # Caroline "Hmm... I guess I’m kinda fed up with the jock type - so nobody who is a real loudmouth or a dickhead."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:313
translate chinese CR3_WE_label_con1_menu_1ff9fc20:

    # MC "How about hair colour?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:314
translate chinese CR3_WE_label_con1_menu_e7a3b5dd:

    # Caroline "Dark. Line mine. I dated a ginger guy once who was the world’s biggest asshole. He ruined all other guys with bright hair for me."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:318
translate chinese CR3_WE_label_con1_menu_1fbc1757:

    # MC "What about fashion sense? Can you give me a hint of what kinda clothing you like?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:319
translate chinese CR3_WE_label_con1_menu_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:320
translate chinese CR3_WE_label_con1_menu_fe833861:

    # Caroline "Just avoid any dickheads who are wearing - shirts or jumpers - to a club. They’re bad news."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:321
translate chinese CR3_WE_label_con1_menu_5cac0dcd:

    # MC "(It’s good that I didn’t wear that jumper tonight, then!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:325
translate chinese CR3_WE_label_con1_menu_a80f46af:

    # MC "So, by process of elimination, you’re looking for a dark haired guy, wearing a T-shirt, and someone who isn’t terribly popular - like a jock."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:326
translate chinese CR3_WE_label_con1_menu_9499fae6:

    # Caroline "I guess so."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:327
translate chinese CR3_WE_label_con1_menu_06b253ab:

    # MC "You do realise, you’ve just described me. Haha!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:331
translate chinese CR3_WE_label_con1_menu_b6b21d67:

    # Caroline "Not funny..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:332
translate chinese CR3_WE_label_con1_menu_2b5a039a:

    # MC "(Eh, I thought it was pretty hilarious! I better change the subject though!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:350
translate chinese CR3_WE_label_con2_c93ffa72:

    # Caroline "My turn! What type of girls are you into?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:356
translate chinese CR3_WE_label_con2_cd139171:

    # MC "I like girls who dress really sexy. Y’know, short skirts and high heels."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:357
translate chinese CR3_WE_label_con2_c375e173:

    # Caroline "Pfft! Everyone likes THEM!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:358
translate chinese CR3_WE_label_con2_2bccc887:

    # MC "Hey, it’s the truth."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:364
translate chinese CR3_WE_label_con2_a5d26c20:

    # MC "I like, strong independent women, who can take care of themselves."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:368
translate chinese CR3_WE_label_con2_824872af:

    # Caroline "Oh yeah? What do you mean by that?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:369
translate chinese CR3_WE_label_con2_1a400c66:

    # MC "I mean, I like someone who is mature enough, that I don’t have to constantly babysit them. Someone who has a bit of ‘get up and go’."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:373
translate chinese CR3_WE_label_con2_c799527f:

    # Caroline "Hmm, I like the way you think, there. I can get behind that. Good answer."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:379
translate chinese CR3_WE_label_con2_39d30382:

    # MC "Honestly? I’d love to meet someone like you."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:383
translate chinese CR3_WE_label_con2_c32bf2b7:

    # Caroline "[player_name]..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:384
translate chinese CR3_WE_label_con2_284e4d2e:

    # MC "Wait - hear me out. I know that you and I can't be together - the deal is off, that ship has sailed."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:385
translate chinese CR3_WE_label_con2_fe2c6b91:

    # MC "However, there was A LOT of chemistry between us. You can’t deny that?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:389
translate chinese CR3_WE_label_con2_080df26e:

    # MC "What I need to do, is meet a girl, just like you!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:390
translate chinese CR3_WE_label_con2_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:391
translate chinese CR3_WE_label_con2_64003326:

    # MC "Someone who is, bubbly, fun, outgoing! Y’know what I mean?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:396
translate chinese CR3_WE_label_con2_86ec0010:

    # Caroline "I know what you mean... I wish you the best of luck, but you’re not gonna find someone like me tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:397
translate chinese CR3_WE_label_con2_45013756:

    # MC "Why not?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:398
translate chinese CR3_WE_label_con2_5aba603a:

    # Caroline "Because I’ve already scanned the club, and it looks like it’s filled with, your usual tarts and gold diggers, tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:399
translate chinese CR3_WE_label_con2_9aff983d:

    # MC "Ah damn..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:408
translate chinese CR3_WE_label_con3_933aa022:

    # "*THUD*"
    ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:410
translate chinese CR3_WE_label_con3_5a43d501:

    # Charles "My, my! If it isn’t Caroline! It’s been a year since I last saw you! How’ve you been keeping, baby?"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:412
translate chinese CR3_WE_label_con3_1ffb7c57:

    # Caroline "Huh?!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:414
translate chinese CR3_WE_label_con3_2063a22a:

    # MC "(Who the hell is this?!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:418
translate chinese CR3_WE_label_con3_6ecf0904:

    # Caroline "Piss off, Charles. I’m just trying to enjoy my night out."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:419
translate chinese CR3_WE_label_con3_edc924cd:

    # Charles "Geez, that’s a shitload of drink, you got there! Are you still, struggling to get over me?"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:420
translate chinese CR3_WE_label_con3_4b9d86ba:

    # Caroline "I’m the one who dumped YOU!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:421
translate chinese CR3_WE_label_con3_1d0ad9ed:

    # Charles "Yeah, well, I remember it the other way around."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:425
translate chinese CR3_WE_label_con3_43907db7:

    # Charles "And this must be your pathetic new excuse of a man."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:427
translate chinese CR3_WE_label_con3_cdbfdace:

    # Caroline "Hey! That’s my brother! Leave him out of this!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:428
translate chinese CR3_WE_label_con3_7f5a68bd:

    # MC "Uh, yeah, I’m her brother. My name’s [player_name]."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:430
translate chinese CR3_WE_label_con3_c7f77439:

    # Caroline "Hey! That’s my best friend! Leave him out of this!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:431
translate chinese CR3_WE_label_con3_526beaf8:

    # MC "Uh, yeah, I’m her friend. My name’s [player_name]."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:435
translate chinese CR3_WE_label_con3_1663d176:

    # Charles "Ooh, so you’re her brother. Hmm, that must mean she’s still single, then."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:436
translate chinese CR3_WE_label_con3_52056f0a:

    # Charles "You better keep an eye on your sister, [player_name], because if I get my hands on her, I’m gonna fuck her silly."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:438
translate chinese CR3_WE_label_con3_cbc9310c:

    # Charles "Ooh, so you’re her friend. Hmm, that must mean she’s still single, then."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:439
translate chinese CR3_WE_label_con3_58b9ba3a:

    # Charles "You better keep an eye on your best friend, [player_name], because if I get my hands on her I’m gonna fuck her silly."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:440
translate chinese CR3_WE_label_con3_11cce474:

    # Caroline "CHARLES!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:441
translate chinese CR3_WE_label_con3_8e3595b0:

    # Charles "She’s into that, y’know? Put her on top, turn her on - and she gets too horny to resist you."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:445
translate chinese CR3_WE_label_con3_13aa44d9:

    # Charles "Have a good night, you two. I’ll be back later, to check on you both."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:446
translate chinese CR3_WE_label_con3_2654a62c:

    # Caroline "Oh fuck off, you dickhead!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:450
translate chinese CR3_WE_label_con3_c21abff1:

    # Caroline "Arrghh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:451
translate chinese CR3_WE_label_con3_da1c7108:

    # MC "Caroline, sit down. Don’t let him, ruin your night like that."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:452
translate chinese CR3_WE_label_con3_85653c1c:

    # Caroline "I swear to God, I could fucking kill him right now!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:459
translate chinese CR3_WE_label_con3_45f1580b:

    # Caroline "Ohh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:460
translate chinese CR3_WE_label_con3_10e2d3ad:

    # MC "Listen - I don’t know what happened between the two of you - but it’s ancient history now."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:461
translate chinese CR3_WE_label_con3_d4b35226:

    # MC "Let’s just move on, and enjoy the rest of our night out. Okay?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:465
translate chinese CR3_WE_label_con3_c19d6dc7:

    # Caroline "Just give me a minute..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:466
translate chinese CR3_WE_label_con3_08a38e12:

    # MC "Sure - no problem. Do you need me to get you a glass for that?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:467
translate chinese CR3_WE_label_con3_90d73164:

    # Caroline "Nah, I’ll be fine."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:471
translate chinese CR3_WE_label_con3_f54102ce:

    # Caroline "*GLUG GLUG GLUG*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:472
translate chinese CR3_WE_label_con3_711d261f:

    # MC "(Jesus! She’s necking the whole bottle! She’s gonna be - completely WASTED - by the time this night is over!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:473
translate chinese CR3_WE_label_con3_31a85a32:

    # MC "(I guess it is one way to forget about, bumping into a hated ex though!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:477
translate chinese CR3_WE_label_con3_718037be:

    # Caroline "Ahh... *hic* Okay, I’m good to *hic* go!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:478
translate chinese CR3_WE_label_con3_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:479
translate chinese CR3_WE_label_con3_eb653506:

    # Caroline "Yeah! -Lesh hith the danshfloor! Wooo!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:483
translate chinese CR3_WE_label_con3_0e2245b4:

    # "*HISSSSS*"
    ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:484
translate chinese CR3_WE_label_con3_e6e9ba5d:

    # MC "Huh? Do you hear that?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:485
translate chinese CR3_WE_label_con3_d684ca25:

    # Caroline "Uh huh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:489
translate chinese CR3_WE_label_con3_904085f3:

    # Caroline "Ish just the shmoke mashine... *Hic!*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:490
translate chinese CR3_WE_label_con3_8cd08ffe:

    # MC "Okay - let’s get you, up onto the dancefloor. I don’t want you, falling asleep at this table!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:491
translate chinese CR3_WE_label_con3_7c2afd53:

    # MC "(Hopefully she’ll, sober up quicker, by moving around!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:495
translate chinese CR3_WE_label_con3_ad891ba3:

    # MC "(If I get her away from the table it also means that she won't be tempted to drink any more of the mountain of bottles she ordered!) "
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:496
translate chinese CR3_WE_label_con3_b4294d28:

    # MC "(It looks like everyone is beginning to, pile on to the dancefloor now.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:500
translate chinese CR3_WE_label_con3_2b94b6bf:

    # Caroline "Woohoo! This is *hic* awesome!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:501
translate chinese CR3_WE_label_con3_e79d6806:

    # MC "C’mon, Caroline! Let’s go and dance!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:502
translate chinese CR3_WE_label_con3_d684ca25_1:

    # Caroline "Uh huh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:506
translate chinese CR3_WE_label_con3_74962020:

    # Caroline "I’ll tell you something... Go and find yourself *hic* a girlfriend, okay? There’s loads of pretty girls, here tonight."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:510
translate chinese CR3_WE_label_con3_0c85d70b:

    # MC "(I don’t really want to look for other women. The only girl I want - is Caroline.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:511
translate chinese CR3_WE_label_con3_6a5bc036:

    # MC "I think I’ll just sit down - you go and enjoy yourself, dancing."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:512
translate chinese CR3_WE_label_con3_cee88731:

    # Caroline "No! Go and get a *hic* girlfriend! Find yourself a REALLY hot one!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:513
translate chinese CR3_WE_label_con3_bbe6ecea:

    # MC "*Sigh* Fine..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:526
translate chinese CR3_WE_label_con3_39aeb93e:

    # MC "(I guess looking for other women, is probably for the best, right now. My fling with Caroline is over.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:527
translate chinese CR3_WE_label_con3_8739bfba:

    # MC "Alright - I’ll go and scout the local talent. Do you want me to keep an eye out for a - potential boyfriend - for you?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:528
translate chinese CR3_WE_label_con3_7592a3ad:

    # Caroline "Oh! *hic* Yes please!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:552
translate chinese CR3_WE_label_con4_0bbf0818:

    # MC "Ah well... (I had shit luck, getting a date for me OR Caroline.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:553
translate chinese CR3_WE_label_con4_6c1c6590:

    # MC "(I guess, I’ll just go back over to her, and start dancing. I might as well, try to enjoy myself tonight.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:554
translate chinese CR3_WE_label_con4_9bba0c42:

    # MC "(I only hope she’s stayed away from the alcohol...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:555
translate chinese CR3_WE_label_con4_9a1d6a7e:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:560
translate chinese CR3_WE_label_con4_ccd43c58:

    # MC "Huh?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:561
translate chinese CR3_WE_label_con4_da3014fb:

    # Caroline "Get off me, you asshole! *Hic*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:562
translate chinese CR3_WE_label_con4_fa40bf6a:

    # Charles "Calm down, baby. You’re just a bit drunk!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:566
translate chinese CR3_WE_label_con4_3d5164bb:

    # Charles "I’m gonna take you out, back here. Then we’ll go back to my place and bone. Sounds good?"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:567
translate chinese CR3_WE_label_con4_fbf8b0a0:

    # Caroline "No! *Hic* Let go of me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:568
translate chinese CR3_WE_label_con4_a00af86c:

    # Charles "C’mon. This way, baby."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:570
translate chinese CR3_WE_label_con4_5e161c0d:

    # MC "(FUCK! He’s trying to take Caroline out of the club! I’ve got to stop him, or he’ll rape her!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:572
translate chinese CR3_WE_label_con4_3ed5a648:

    # MC "(FUCK! He’s trying to take Caroline out of the club! I’ve got to stop him, or he’ll hurt her!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:578
translate chinese CR3_WE_label_con4_ecda1b08:

    # Charles "You’ve got no idea, how much I missed these tits, darling."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:579
translate chinese CR3_WE_label_con4_3d0957b7:

    # MC "Hey Caroline! Over here!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:580
translate chinese CR3_WE_label_con4_3b287f29:

    # Charles "Hey! You AGAIN?!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:584
translate chinese CR3_WE_label_con4_1b226785:

    # Caroline "[player_name]!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:585
translate chinese CR3_WE_label_con4_70c73458:

    # Caroline "You came back for me!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:586
translate chinese CR3_WE_label_con4_0a5d1e45:

    # MC "Of course I did! Did that asshole hurt you at all?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:590
translate chinese CR3_WE_label_con4_8637ddf4:

    # Caroline "N-No, you came... just in *hic* time..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:591
translate chinese CR3_WE_label_con4_7d356f45:

    # Caroline "I never imagined, you’d actually come back for me... I figured you’d have *hic* got yourself a date and gone off, into the night."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:592
translate chinese CR3_WE_label_con4_7192b839:

    # MC "Of course not! I wouldn’t leave you here on your own - not with a dickhead like that around."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:596
translate chinese CR3_WE_label_con4_79da9db5:

    # Caroline "*Sniff*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:597
translate chinese CR3_WE_label_con4_f673df04:

    # MC "Hey, it’s okay... You don’t need to cry."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:598
translate chinese CR3_WE_label_con4_48194d36:

    # Caroline "I’m not *sniff* crying.... I’ve just had too much to drink..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:602
translate chinese CR3_WE_label_con4_e1211e59:

    # Charles "(Huh, so this little shit, thinks he can play the hero, and cockblock me?)"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:603
translate chinese CR3_WE_label_con4_63f59b0d:

    # Charles "(Not today!)"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:604
translate chinese CR3_WE_label_con4_7ba5582f:

    # Charles "Hyaaaah!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:609
translate chinese CR3_WE_label_con4_bc269711:

    # Caroline "[player_name]!!!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:612
translate chinese CR3_WE_label_con4_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:618
translate chinese CR3_WE_label_con4_bbe1b7fe:

    # MC "Hey, dickhead! Get your hands off her!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:623
translate chinese CR3_WE_label_con4_7b3ebabd:

    # "*THWACK*"
    ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:624
translate chinese CR3_WE_label_con4_1a71d501:

    # Charles "Argghh!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:628
translate chinese CR3_WE_label_con4_7a682356:

    # Charles "Ooof..."
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:629
translate chinese CR3_WE_label_con4_d62483e7:

    # MC "(OUCH! That probably hurt ME more than it hurt him!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:630
translate chinese CR3_WE_label_con4_1b226785_1:

    # Caroline "[player_name]!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:634
translate chinese CR3_WE_label_con4_7e165438:

    # MC "Are you okay, Caroline?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:635
translate chinese CR3_WE_label_con4_414a742e:

    # Caroline "Y-Yeah, I’m fine... *hic*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:636
translate chinese CR3_WE_label_con4_4addb699:

    # MC "He didn’t hurt you, did he?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:640
translate chinese CR3_WE_label_con4_e4334ea0:

    # Caroline "No. You came just in time. *Hic* Another few minutes, and he would have dragged me out of here."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:641
translate chinese CR3_WE_label_con4_e49d3d22:

    # Caroline "God knows what he *Hic* would have done to me, if that happened..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:642
translate chinese CR3_WE_label_con4_20b686f6:

    # MC "Well, you’re safe now - That’s all that matters."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:643
translate chinese CR3_WE_label_con4_fff9014a:

    # Caroline "You were so brave, there... I’ve never had a guy *hic* stand up for me like that, before."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:644
translate chinese CR3_WE_label_con4_ee035b60:

    # MC "It was nothing, Caroline. I’d have done the same for Sara."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:645
translate chinese CR3_WE_label_con4_53fedf57:

    # Caroline "*Sniff* You’re a good guy, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:646
translate chinese CR3_WE_label_con4_b1f10bc9:

    # MC "(Are Caroline’s eyes getting wet? It sounds like she’s about to cry.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:650
translate chinese CR3_WE_label_con4_bad2e406:

    # Charles "YOU FUCKING PIECE OF SHIT! "
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:651
translate chinese CR3_WE_label_con4_3070cf30:

    # Charles "I’m gonna - break open - your fucking head!"
    Charles ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:652
translate chinese CR3_WE_label_con4_ba2eaad5:

    # Caroline "LOOK OUT!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:653
translate chinese CR3_WE_label_con4_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:658
translate chinese CR3_WE_label_con4_3c726d8a_1:

    # "*WHACK*"
    ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:661
translate chinese CR3_WE_label_con4_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:662
translate chinese CR3_WE_label_con4_1a25a796:

    # Caroline "[player_name]! NO!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:675
translate chinese CR3_WE_label_con5_5b407a62:

    # MC "Ugh... Where am I?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:676
translate chinese CR3_WE_label_con5_bd72dd0d:

    # MC "(God, everything’s all blurry...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:677
translate chinese CR3_WE_label_con5_b01fd167:

    # Caroline "Hey there... Are you finally waking up?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:681
translate chinese CR3_WE_label_con5_620e6f40:

    # MC "I... What happened?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:682
translate chinese CR3_WE_label_con5_9518fb06:

    # Caroline "Charles hit you on the head. You passed out, on the dancefloor."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:683
translate chinese CR3_WE_label_con5_f137ee16:

    # MC "Charles?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:684
translate chinese CR3_WE_label_con5_5d155dc7:

    # Caroline "Yeah - my ex-boyfriend, who *hic* showed up?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:685
translate chinese CR3_WE_label_con5_b657ccc8:

    # MC "Ohhh right... I remember now..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:689
translate chinese CR3_WE_label_con5_320264f4:

    # MC "Christ... my head feels like it’s on fire. There’s gonna be a bruise there, tomorrow."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:690
translate chinese CR3_WE_label_con5_f70f7686:

    # MC "Wait! What happened, after I passed out?! Charles didn’t hurt you, did he?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:691
translate chinese CR3_WE_label_con5_e4857c33:

    # Caroline "Relax! The police showed up and took that asshole away. He’s gone."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:695
translate chinese CR3_WE_label_con5_171e2371:

    # MC "Oh, thank God. The thought of him doing something to you, because I wasn’t able to protect you, just makes me feel... sick."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:696
translate chinese CR3_WE_label_con5_fe6248bc:

    # Caroline "Relax - it’s okay. I understand."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:697
translate chinese CR3_WE_label_con5_6762661e:

    # MC "Are you still drinking?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:701
translate chinese CR3_WE_label_con5_f54102ce:

    # Caroline "*GLUG GLUG GLUG*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:702
translate chinese CR3_WE_label_con5_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:706
translate chinese CR3_WE_label_con5_1ef42fd5:

    # Caroline "Can you blame me? You were passed out, for almost an hour, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:707
translate chinese CR3_WE_label_con5_a84f3919:

    # Caroline "A girl has to find SOME way to keep herself entertained."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:708
translate chinese CR3_WE_label_con5_48233bf8:

    # Caroline "That glass was the *hic* last of it, anyway..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:709
translate chinese CR3_WE_label_con5_85ce6eb6:

    # MC "You drank it all?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:713
translate chinese CR3_WE_label_con5_6c8dbe02:

    # Caroline "Hehe *Hic* Yup! Every last drop..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:714
translate chinese CR3_WE_label_con5_776604bc:

    # MC "Great... Just don’t pass out, on me. I don’t want to have to, take care of a quadriplegic, tonight."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:715
translate chinese CR3_WE_label_con5_785328fd:

    # Caroline "I won’t..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:719
translate chinese CR3_WE_label_con5_03ddece1:

    # Caroline "You didn’t *Hic* find a girlfriend tonight, did you? *Hic*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:720
translate chinese CR3_WE_label_con5_6a7fee94:

    # MC "Nah, unfortunately not."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:721
translate chinese CR3_WE_label_con5_e18042f2:

    # Caroline "Good!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:725
translate chinese CR3_WE_label_con5_d6a1b630:

    # MC "Haha! Why’s that a good thing?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:726
translate chinese CR3_WE_label_con5_f70d48ff:

    # Caroline "Because... Because I have you all for myself..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:727
translate chinese CR3_WE_label_con5_19570c32:

    # MC "What?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:731
translate chinese CR3_WE_label_con5_d967b988:

    # Caroline "You still *Hic* don’t know why I ended the deal... do you?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:732
translate chinese CR3_WE_label_con5_fa019de8:

    # MC "No, I don’t."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:736
translate chinese CR3_WE_label_con5_1e24e100:

    # Caroline "It’s because... *gulp*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:740
translate chinese CR3_WE_label_con5_08959e69:

    # Caroline "... I was falling in love with you, [player_name]."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:741
translate chinese CR3_WE_label_con5_82c4c929:

    # Caroline "Things were getting *Hic* too... much, for just a fling..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:742
translate chinese CR3_WE_label_con5_d9ab25bf:

    # MC "Wh-What?!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:746
translate chinese CR3_WE_label_con5_8d3b2ca0:

    # Caroline "I’m feeling sleepy, [player_name]. Take me home..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:747
translate chinese CR3_WE_label_con5_33e46cd4:

    # MC "(Wow... she actually loves me!? This is amazing!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:748
translate chinese CR3_WE_label_con5_a5d0563a:

    # MC "No problem, Caroline. Just close your eyes - I’ll take you home."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:752
translate chinese CR3_WE_label_con5_7af033e3:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:754
translate chinese CR3_WE_label_con5_e982054d:

    # MC "(She really has had too much to drink. Hopefully she’ll have sobered up a bit by the time we get back home.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:763
translate chinese CR3_WE_label_con5_018e44ae:

    # Caroline "Ahaha! Wheeee! I’m flying!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:764
translate chinese CR3_WE_label_con5_8f3da137:

    # MC "Ugh... (You’re also very heavy after ten minutes of sitting on my back!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:765
translate chinese CR3_WE_label_con5_a2594c59:

    # Caroline "We should do this *hic* again, tomorrow night!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:769
translate chinese CR3_WE_label_con5_32ba5df4:

    # MC "Maybe not tomorrow night, but we will do it again, together."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:770
translate chinese CR3_WE_label_con5_3bfe8528:

    # Caroline "*Hic* We’re home!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:772
translate chinese CR3_WE_label_con5_99ff3cc2:

    # MC "Please try to keep your voice down! Mom and Dad are probably asleep!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:774
translate chinese CR3_WE_label_con5_a1b47814:

    # MC "Please try to keep your voice down! Linda and Bob are probably asleep!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:777
translate chinese CR3_WE_label_con5_b9dedc52:

    # Caroline "Hehe *Hic* S-Sorrry!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:778
translate chinese CR3_WE_label_con5_8c7aed05:

    # MC "It’s fine... Let’s just get you, tucked into bed."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:782
translate chinese CR3_WE_label_con5_4e82a4b9:

    # Caroline "Hey [player_name]... Do you wanna know a secret?"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:783
translate chinese CR3_WE_label_con5_4073650e:

    # MC "Go on."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:784
translate chinese CR3_WE_label_con5_fc8fa07a:

    # Caroline "I *Hic* might be in love with you!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:788
translate chinese CR3_WE_label_con5_2dc29017:

    # MC "I know, Caroline. You’ve told me like five times now since you woke up."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:789
translate chinese CR3_WE_label_con5_f9ff1b3c:

    # Caroline "It’s true, y’know... *hic*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:795
translate chinese CR3_WE_label_con5_e8ceb4f9:

    # Caroline "Ooh, I’m feeling dizzy..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:796
translate chinese CR3_WE_label_con5_bc438603:

    # MC "Do you need me to get you a glass or water? Or some aspirin?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:797
translate chinese CR3_WE_label_con5_23c355bc:

    # Caroline "No - I’ll just..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:802
translate chinese CR3_WE_label_con5_933aa022:

    # "*THUD*"
    ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:806
translate chinese CR3_WE_label_con5_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:807
translate chinese CR3_WE_label_con5_7af033e3_1:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:808
translate chinese CR3_WE_label_con5_b07db30a:

    # MC "(She’s exhausted, after that night out. I should tuck her in properly.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:812
translate chinese CR3_WE_label_con5_4fd4f095:

    # Caroline "*Snore*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:813
translate chinese CR3_WE_label_con5_cd220f9b:

    # MC "(She’s so beautiful, lying there. I wish I could just, crawl in beside her, and cuddle her, all night long.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:814
translate chinese CR3_WE_label_con5_9e9c93b6:

    # MC "(I really shouldn’t though...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:818
translate chinese CR3_WE_label_con5_c431dcbe:

    # MC "Goodnight, Caroline. Sweet dreams."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:819
translate chinese CR3_WE_label_con5_559a7d59:

    # MC "(She looks so peaceful there. Hopefully she won’t have too bad a hangover in the morning.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:820
translate chinese CR3_WE_label_con5_b8a156df:

    # MC "(I guess this maybe means the deal is back on again!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:824
translate chinese CR3_WE_label_con5_7af033e3_2:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:825
translate chinese CR3_WE_label_con5_cd3dce87:

    # MC "(I’ll have to talk to her about the deal, when she wakes up.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:826
translate chinese CR3_WE_label_con5_ec3b3b3a:

    # MC "(For tonight though. I’ll just enjoy knowing the fact that she is in love with me.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:832
translate chinese CR3_WE_label_con5_0bf5a726:

    # MC "(Hmm... The deal is off right now. I might as well get one final night of fun with her.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:833
translate chinese CR3_WE_label_con5_44e9cfc4:

    # MC "(After all, I’m probably never going to see her this drunk again!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:834
translate chinese CR3_WE_label_con5_6544711e:

    # MC "(This could be my ONLY chance! Let’s get this dress off her!))"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:838
translate chinese CR3_WE_label_con5_263abce8:

    # MC "(Hehe... Perfect! God... she’s so fucking sexy!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:839
translate chinese CR3_WE_label_con5_7af033e3_3:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:840
translate chinese CR3_WE_label_con5_4e8351c3:

    # MC "(How can someone be so beautiful, even when they’re passed out drunk?!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:844
translate chinese CR3_WE_label_con5_704d75b0:

    # MC "(Well, I’ve already stripped her top off, without waking her. I might as well, pull her panties down too!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:845
translate chinese CR3_WE_label_con5_78d12aed:

    # MC "(She seems to be far too drunk, to wake up any time soon.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:849
translate chinese CR3_WE_label_con5_f4397ce5:

    # MC "(Okay - slowly does it...)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:850
translate chinese CR3_WE_label_con5_668dd70e:

    # MC "(I’ll just roll them down - bit by bit - until I get there.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:851
translate chinese CR3_WE_label_con5_4fd4f095_1:

    # Caroline "*Snore*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:855
translate chinese CR3_WE_label_con5_6debb865:

    # MC "Hehe..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:857
translate chinese CR3_WE_label_con5_ccb90474:

    # MC "(Just look at that pussy! It’s good enough to eat! Now, what should I do to my sister tonight?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:859
translate chinese CR3_WE_label_con5_fcb81faf:

    # MC "(Just look at that pussy! It’s good enough to eat! Now, what should I do to Caroline tonight?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:860
translate chinese CR3_WE_label_con5_0e6529c7:

    # MC "(I don’t want to risk fucking her tonight, in case I accidentally cum inside. It would be almost impossible to hide the evidence, if that happened.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:864
translate chinese CR3_WE_label_con5_b6871a26:

    # MC "(I guess I could just start, by exploring her pussy and ass.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:865
translate chinese CR3_WE_label_con5_786ac9c2:

    # MC "(Yeah, let’s do that!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:869
translate chinese CR3_WE_label_con5_599a656c:

    # MC "(Okay, time to spread your vulva, and see what’s inside, Caroline!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:870
translate chinese CR3_WE_label_con5_4476f413:

    # MC "(It’s a shame she’s not wet right now, or I could have SO much more fun!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:871
translate chinese CR3_WE_label_con5_ceb948aa:

    # MC "*Sigh* (Maybe someday, if I’m lucky!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:875
translate chinese CR3_WE_label_con5_256648a6:

    # MC "(Damn! That pink pussy of hers, looks fucking perfect!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:876
translate chinese CR3_WE_label_con5_b5815301:

    # MC "(She hasn’t woken up, so far - perhaps I can get away with, fingering her too?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:877
translate chinese CR3_WE_label_con5_93304bbd:

    # MC "(Let’s finger, both her holes, while she’s still unconscious!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:882
translate chinese CR3_WE_label_con5_27715f14:

    # MC "Mmm... (Her pussy is so warm! I’d love to have my cock, snugly buried, in there.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:883
translate chinese CR3_WE_label_con5_1351e63f:

    # MC "(Her asshole is a LOT tighter than her cunt. Much tighter than I expected it to be! I wonder how often she’s done anal with her ex?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:884
translate chinese CR3_WE_label_con5_3edb2038:

    # Caroline "Mmm... Oh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:888
translate chinese CR3_WE_label_con5_1ffbd00d:

    # MC "(She’s moaning in her sleep, but I don’t think there’s any real chance of her waking up.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:889
translate chinese CR3_WE_label_con5_11e14c98:

    # Caroline "Ahmm... Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:890
translate chinese CR3_WE_label_con5_b785fe14:

    # MC "(Ohh, I could really go balls deep into her ass. It would feel so good, just blowing my load, deep inside her bowels.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:894
translate chinese CR3_WE_label_con5_06431405:

    # MC "(Right! Time to switch things up a bit.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:895
translate chinese CR3_WE_label_con5_5887d0f6:

    # MC "(That’s it - ass up in the air. Now... what else can I do to her?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:899
translate chinese CR3_WE_label_con5_9f9d85b1:

    # MC "Aha! (I know!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:900
translate chinese CR3_WE_label_con5_cda332aa:

    # MC "(I’ll eat out her pussy for a few minutes. I wonder if she’ll, actually get horny from this?)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:901
translate chinese CR3_WE_label_con5_fd891a5c:

    # MC "(There’s one way to find out!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:905
translate chinese CR3_WE_label_con5_c37b3bd8:

    # MC "(This is gonna be great! I don’t think she would last very long, having me eat her out, while she was awake.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:906
translate chinese CR3_WE_label_con5_c49a9b05:

    # MC "(Being asleep, might pose a little bit more of a challenge - but I’ll see what I can do, to make her cum!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:910
translate chinese CR3_WE_label_con5_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:911
translate chinese CR3_WE_label_con5_7af033e3_4:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:912
translate chinese CR3_WE_label_con5_dedee3b2:

    # MC "*Shlurp Suck*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:913
translate chinese CR3_WE_label_con5_4ac2ae40:

    # Caroline "Zzz... ah... oh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:914
translate chinese CR3_WE_label_con5_0adf84e1:

    # MC "(It sounds like things are - going to plan! She’s already moaning, from me licking her clitoris!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:918
translate chinese CR3_WE_label_con5_84828c3d:

    # MC "(Let’s speed things up, a bit!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:919
translate chinese CR3_WE_label_con5_8e319243:

    # MC "*Lick Lick Lick*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:921
translate chinese CR3_WE_label_con5_03f2db6b:

    # Caroline "Ah... Ah..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:923
translate chinese CR3_WE_label_con5_37c48310:

    # MC "(Yup! And now she’s starting to get wet too!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:927
translate chinese CR3_WE_label_con5_ea251269:

    # MC "*Suck Shlurp*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:928
translate chinese CR3_WE_label_con5_e94e7c44:

    # Caroline "Mmm... Ahh... Oh..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:929
translate chinese CR3_WE_label_con5_a9412655:

    # MC "(God, she tastes so good!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:933
translate chinese CR3_WE_label_con5_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:935
translate chinese CR3_WE_label_con5_7baa8f90:

    # Caroline "Ah! Ahhhhh!"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:936
translate chinese CR3_WE_label_con5_4f5ab17a:

    # MC "(She’s trembling like crazy as I lick her! Have I made her cum when she’s asleep?!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:940
translate chinese CR3_WE_label_con5_dedee3b2_1:

    # MC "*Shlurp Suck*"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:941
translate chinese CR3_WE_label_con5_3109fbfe:

    # Caroline "Ooohhhhh... Ah... Mmm... Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:942
translate chinese CR3_WE_label_con5_16a99f32:

    # MC "(It looks like I actually made her cum! Heh... She’ll probably just think it was a wet dream.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:946
translate chinese CR3_WE_label_con5_f5a5cb0b:

    # MC "(Okay - Caroline’s had her fun. It’s only fair that I get myself off too!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:947
translate chinese CR3_WE_label_con5_7af033e3_5:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:948
translate chinese CR3_WE_label_con5_57a0b5d2:

    # MC "(It isn’t worth the risk of fucking her tonight - even though I REALLY want to!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:952
translate chinese CR3_WE_label_con5_2ec3fc28:

    # MC "(If I slip my cock, between her asscheeks, I should be able to get myself off, by rubbing back and forth.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:953
translate chinese CR3_WE_label_con5_8d07106c:

    # MC "(I just need to squeeze it in there, first.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:954
translate chinese CR3_WE_label_con5_4fd4f095_2:

    # Caroline "*Snore*"
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:958
translate chinese CR3_WE_label_con5_44cd3e83:

    # MC "Ohhh... That’s it..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:959
translate chinese CR3_WE_label_con5_beb25ef7:

    # MC "Ugh! Ah... "
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:960
translate chinese CR3_WE_label_con5_995dd613:

    # MC "(I can squeeze her asscheeks together, to control the pressure, around my cock!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:964
translate chinese CR3_WE_label_con5_a5664973:

    # MC "(Damn, this is incredible!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:965
translate chinese CR3_WE_label_con5_ae1b8a29:

    # MC "(It’s a shame, she’d never let me do this to her while she’s awake!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:966
translate chinese CR3_WE_label_con5_1b633c9e:

    # MC "(I’d give anything to be able to pound her doggystyle.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:970
translate chinese CR3_WE_label_con5_08caf92e:

    # MC "Oh... Ugh... Fuck..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:971
translate chinese CR3_WE_label_con5_a1b4fa12:

    # MC "(Fuck, this is so good!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:972
translate chinese CR3_WE_label_con5_7af033e3_6:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:976
translate chinese CR3_WE_label_con5_fbbd58e1:

    # MC "(Time to start, thrusting a bit faster - as much as I’d like to, I can’t keep this going, all night.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:977
translate chinese CR3_WE_label_con5_7815d3a2:

    # MC "(Sooner or later, Caroline is going to sober up and wake up.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:978
translate chinese CR3_WE_label_con5_bdc3d807:

    # MC "(I’ll have to be out of the room, by the time that happens!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:982
translate chinese CR3_WE_label_con5_1363f172:

    # MC "Ugh, fuck... Yes..."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:983
translate chinese CR3_WE_label_con5_6da55347:

    # MC "(I’m getting close to cumming! I think I’ll blow my load, all over her ass and naked back!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:987
translate chinese CR3_WE_label_con5_aed55322:

    # MC "Hnnng... ugh!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:988
translate chinese CR3_WE_label_con5_988a5baf:

    # Caroline "Hmm... Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:989
translate chinese CR3_WE_label_con5_d33a0868:

    # MC "(Fuck! I’m cumming!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:999
translate chinese CR3_WE_label_con5_267db642:

    # MC "Ugh! Aahhhhh!"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1000
translate chinese CR3_WE_label_con5_0e055c94:

    # MC "(Wow... I never knew I could cum this much!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1001
translate chinese CR3_WE_label_con5_8b56ad0a:

    # MC "(Right - I better get out of here before she sobers up. I’ll throw the sheets over her and dash away!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1005
translate chinese CR3_WE_label_con5_45634561:

    # MC "(Hehe... Goodnight Caroline! Even if our deal isn’t on, you and I can still have a little fun together!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1006
translate chinese CR3_WE_label_con5_7af033e3_7:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1007
translate chinese CR3_WE_label_con5_40c9cac6:

    # MC "(See you tomorrow, Caroline.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1013
translate chinese CR3_WE_label_con5_4c6552e1:

    # MC "(No, I really shouldn’t do anything to her, while she’s drunk. I’ll let her sleep this hangover off.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1016
translate chinese CR3_WE_label_con5_c431dcbe_1:

    # MC "Goodnight, Caroline. Sweet dreams."
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1017
translate chinese CR3_WE_label_con5_559a7d59_1:

    # MC "(She looks so peaceful there. Hopefully she won’t have too bad a hangover in the morning.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1018
translate chinese CR3_WE_label_con5_b8a156df_1:

    # MC "(I guess this maybe means the deal is back on again!)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1022
translate chinese CR3_WE_label_con5_7af033e3_8:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1023
translate chinese CR3_WE_label_con5_cd3dce87_1:

    # MC "(I’ll have to talk to her about the deal, when she wakes up.)"
    MC ""

# game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:1024
translate chinese CR3_WE_label_con5_ec3b3b3a_1:

    # MC "(For tonight though. I’ll just enjoy knowing the fact that she is in love with me.)"
    MC ""

translate chinese strings:

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:247
    old "Do you usually drink this much, on a night out?"
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:247
    old "This stuff looks pretty strong! What is it?"
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:247
    old "Do you still want me to help you find a boyfriend tonight?"
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:352
    old "I like girls who dress really sexy."
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:352
    old "I like, strong independent women, who can take care of themselves."
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:352
    old "Honestly? I’d love to meet someone like you."
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:508
    old "(I don’t really want to look for other women. The only girl I want - is Caroline.)"
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:508
    old "(I guess, looking for other women, is probably for the best, right now. My fling with Caroline is over.)"
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:574
    old "Grab Caroline away from him."
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:574
    old "Punch him in the face."
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:828
    old "Hmm... Maybe I could play with her body, just a little bit?"
    new ""

    # game/scripts/weekend_events/Caroline/R3/CR3_WE.rpy:828
    old "No, I really shouldn’t."
    new ""

