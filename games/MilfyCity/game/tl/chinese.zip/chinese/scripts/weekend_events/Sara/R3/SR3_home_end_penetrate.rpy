﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:112
translate chinese SR3_home_end_penetrate_128ebc87:

    # Sara "Are you okay if I lie back like this? I think I’ll feel safer if I’m facing you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:114
translate chinese SR3_home_end_penetrate_993a175f:

    # Sara "Are you okay if I lie back like this? I think I'll feel better if I'm facing you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:115
translate chinese SR3_home_end_penetrate_13d0c6ca:

    # MC "No problem at all, Sara. Just stay in whatever position makes you feel most comfortable."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:116
translate chinese SR3_home_end_penetrate_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:119
translate chinese SR3_home_end_penetrate_31600954:

    # Sara "If... If I ask you to stop... are you going to hate me?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:120
translate chinese SR3_home_end_penetrate_f85ed88a:

    # MC "What? Why would I hate you?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:121
translate chinese SR3_home_end_penetrate_21d19e9d:

    # Sara "I know you’ve really wanted to have sex with me for a long time now... and if I get scared or it hurts... I might need some more time."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:122
translate chinese SR3_home_end_penetrate_e24fae1a:

    # MC "Don’t worry, Sara. We’ll take things at your pace. I’m not going to be angry with you or hate you. I promise."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:124
translate chinese SR3_home_end_penetrate_b692f6b0:

    # Sara "If... If I ask you to stop... Are you going to be sad?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:125
translate chinese SR3_home_end_penetrate_41ac4f7e:

    # MC "What? Why would I be sad?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:126
translate chinese SR3_home_end_penetrate_c26f0597:

    # Sara "I know you've really wanted to have sex with me for a long time now... and if I get nervous... I could say that I need some more time."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:127
translate chinese SR3_home_end_penetrate_c562febf:

    # MC "Don’t worry, Sara. We’ll take things at your pace. I’m not going to be sad with you or anything. I promise."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:129
translate chinese SR3_home_end_penetrate_5f42c4a9:

    # Sara "Okay... Let’s try this..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:130
translate chinese SR3_home_end_penetrate_f091d6e1:

    # MC "Your pussy looks really beautiful, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:131
translate chinese SR3_home_end_penetrate_213fd67c:

    # Sara "You’re just saying that to make me feel better..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:133
translate chinese SR3_home_end_penetrate_860ea985:

    # MC "I’m not! It really is gorgeous. It’s so smooth and your vulva is amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:134
translate chinese SR3_home_end_penetrate_c12333f2:

    # MC "It looks so ready for me to just slide my cock right inside you."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:135
translate chinese SR3_home_end_penetrate_5212ad7e:

    # MC "(I’m one hell of a lucky guy to fuck a pussy looking this pristine! Her body’s impeccable.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:137
translate chinese SR3_home_end_penetrate_3f2bc93c:

    # MC "Alright, I’m just going to line myself up here. If you need me to slow down or stop, just let me know, okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:138
translate chinese SR3_home_end_penetrate_3734572c:

    # Sara "*Gulp* Okay... I think... Go ahead."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:140
translate chinese SR3_home_end_penetrate_da40e8b6:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:141
translate chinese SR3_home_end_penetrate_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:142
translate chinese SR3_home_end_penetrate_6d1c1b47:

    # Sara "Y-Yeah, I just felt... it was nice when your dick brushed against my clitoris there. Like a sharp burst of pleasure. It's completely different than with a cold vibrator."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:144
translate chinese SR3_home_end_penetrate_6900e9f9:

    # MC "I promise you Sara, this is going to feel amazing. We just have to get past the first hurdle and then you’ll be enjoying it."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:145
translate chinese SR3_home_end_penetrate_3466bc0b:

    # MC "That feeling of my dick touching your clit? It will pale in comparison to the sensation of it plunging deep inside you."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:147
translate chinese SR3_home_end_penetrate_b46fa9a9:

    # Sara "O-Okay... I can’t look. C-Can you just do it slowly?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:148
translate chinese SR3_home_end_penetrate_d64727db:

    # MC "Are you sure you don’t want to see me?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:150
translate chinese SR3_home_end_penetrate_8bae13d6:

    # Sara "J-Just do it before I chicken out."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:152
translate chinese SR3_home_end_penetrate_6f421df3:

    # Sara "Just do it! [player_name]! "
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:154
translate chinese SR3_home_end_penetrate_d53160ee:

    # MC "Okay, Sara. I want you to take some deep breaths for me. This is going to be fun."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:155
translate chinese SR3_home_end_penetrate_0df973fe:

    # Sara "*Gulp* A-Alright, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:156
translate chinese SR3_home_end_penetrate_5dbe4851:

    # Sara "(I’m going to enjoy this... I’m going to enjoy this...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:159
translate chinese SR3_home_end_penetrate_334d2cfc:

    # MC "Do you remember that time [Mom_name], you, and me all went to Xtremeland together?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:161
translate chinese SR3_home_end_penetrate_79cc5634:

    # MC "Do you remember that time we all went to Xtremeland together?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:162
translate chinese SR3_home_end_penetrate_c9e69812:

    # Sara "Y-Yeah..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:163
translate chinese SR3_home_end_penetrate_57beeace:

    # MC "That was some time ago. Do you remember the big roller coasters?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:165
translate chinese SR3_home_end_penetrate_5a9bf7e4:

    # Sara "Ah!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:166
translate chinese SR3_home_end_penetrate_d79b5923:

    # MC "Do you remember the roller coasters, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:167
translate chinese SR3_home_end_penetrate_c9e69812_1:

    # Sara "Y-Yeah..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:169
translate chinese SR3_home_end_penetrate_40ee629b:

    # MC "You were so so scared when we were in the queue. You were clinging to [Mom_name]’s arm the entire time."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:171
translate chinese SR3_home_end_penetrate_593500f1:

    # MC "You were so hyped when we were in the queue!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:173
translate chinese SR3_home_end_penetrate_da40e8b6_1:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:176
translate chinese SR3_home_end_penetrate_9afbc9e2:

    # MC "And by the time we got you locked into your seat you were trembling in terror."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:178
translate chinese SR3_home_end_penetrate_50ceddd2:

    # MC "And by the time we got you locked into your seat, you were so excited!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:179
translate chinese SR3_home_end_penetrate_2536b745:

    # MC "Do you remember what happened next, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:181
translate chinese SR3_home_end_penetrate_19241e69:

    # Sara "I- I- I-"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:182
translate chinese SR3_home_end_penetrate_fcfffff2:

    # MC "Easy, deep breaths. Nice and calm. You’re safe."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:184
translate chinese SR3_home_end_penetrate_d510b434:

    # Sara "I... I..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:186
translate chinese SR3_home_end_penetrate_59d78907:

    # MC "The roller coaster started going, and as we went down the first big dip you screamed in excitement."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:188
translate chinese SR3_home_end_penetrate_baa4f1cb:

    # MC "Ugh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:190
translate chinese SR3_home_end_penetrate_da87d088:

    # Sara "Ohhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:191
translate chinese SR3_home_end_penetrate_be768ec6:

    # MC "Because, as soon as you were on that ride you discovered that you REALLY loved it. "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:193
translate chinese SR3_home_end_penetrate_7224268b:

    # Sara "Oohh... oh, [player_name]... This feels..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:195
translate chinese SR3_home_end_penetrate_e5410465:

    # MC "We had to take you back to that roller coaster five times. [Mom_name] and I took it in turns bringing you on it. Once you had a taste of the excitement the roller coaster offered, you never wanted it to end."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:197
translate chinese SR3_home_end_penetrate_889c69d2:

    # MC "We had to take you back to that roller coaster five times. Once you had a taste of the excitement the roller coaster offered, you never wanted it to end. "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:198
translate chinese SR3_home_end_penetrate_3cba20d2:

    # Sara "It’s... so big..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:200
translate chinese SR3_home_end_penetrate_27fcebbb:

    # MC "You were having so much fun, you were squealing your little lungs out. And you know what, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:201
translate chinese SR3_home_end_penetrate_3cd7ed60:

    # MC "You’re about to experience the same thing again now."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:202
translate chinese SR3_home_end_penetrate_f5551280:

    # Sara "*Gasp* Ooohhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:204
translate chinese SR3_home_end_penetrate_e68f2701:

    # Sara "AHHHH!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:205
translate chinese SR3_home_end_penetrate_6f145f48:

    # Sara "(Holy shit! [player_name] went all the way in! I can feel his fat cock buried deep inside my pussy!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:207
translate chinese SR3_home_end_penetrate_a5741998:

    # MC "Mmm! God, you’re really tight. I mean, I expected your pussy to be good, but this is fucking amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:208
translate chinese SR3_home_end_penetrate_260599e7:

    # Sara "Oohhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:210
translate chinese SR3_home_end_penetrate_d1bf2919:

    # MC "Are you in pain?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:211
translate chinese SR3_home_end_penetrate_c429df9e:

    # Sara "It- It doesn’t hurt much... There was a little prick of pain, but it wasn’t like that time you, ahh... put it in my butt."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:213
translate chinese SR3_home_end_penetrate_55f77075:

    # MC "Are you feeling okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:214
translate chinese SR3_home_end_penetrate_c680c2f7:

    # Sara "It- It doesn't feel weird... There was a little prick at the beginning, but it's a completely different feeling... Then that time when you.. put it in my butt."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:216
translate chinese SR3_home_end_penetrate_bf84ce92:

    # MC "I’m going to start moving it now, okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:217
translate chinese SR3_home_end_penetrate_ab8fd624:

    # Sara "Uh huh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:219
translate chinese SR3_home_end_penetrate_6590ac97:

    # Sara "Oh! Ahh... H-Holy crap... Oooh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:220
translate chinese SR3_home_end_penetrate_492a820d:

    # MC "Feeling good?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:221
translate chinese SR3_home_end_penetrate_f391bdf1:

    # Sara "Y-Yeah!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:227
translate chinese SR3_home_end_penetrate_318a9580:

    # Sara "I-Is there any blood?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:228
translate chinese SR3_home_end_penetrate_ba2c6ed9:

    # MC "Probably if it was your first time."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:229
translate chinese SR3_home_end_penetrate_96855617:

    # Sara "That’s so embarrassing... Can you check and wash if that’s the case?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:231
translate chinese SR3_home_end_penetrate_bba81930:

    # MC "Yeah, there’s a small amount. I’ll go and wash it off now."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:232
translate chinese SR3_home_end_penetrate_f3b8fc37:

    # Sara "I’m sorry..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:233
translate chinese SR3_home_end_penetrate_32ef795c:

    # MC "Shush, it’s not your fault. You didn’t do anything wrong."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:235
translate chinese SR3_home_end_penetrate_38f1bc5e:

    # Sara "Do you find it disgusting?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:236
translate chinese SR3_home_end_penetrate_8ba65b4e:

    # MC "There’s nothing disgusting about you at all. It’s just part of your bodily function."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:238
translate chinese SR3_home_end_penetrate_071b04f8:

    # MC "Sara, you were a virgin! Most virgins are going to bleed after their first time having sex. It’s perfectly natural as the hymen tears."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:240
translate chinese SR3_home_end_penetrate_1298f043:

    # Sara "R-Really?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:241
translate chinese SR3_home_end_penetrate_d424ab6d:

    # MC "I promise. "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:243
translate chinese SR3_home_end_penetrate_a56f19fe:

    # Sara "I know that, [player_name]... It’s just nasty..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:244
translate chinese SR3_home_end_penetrate_e181bed7:

    # MC "I don't care about that. Don’t worry, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:246
translate chinese SR3_home_end_penetrate_a42b3399:

    # Sara "*Phew* That’s a relief."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:247
translate chinese SR3_home_end_penetrate_eaae6822:

    # Sara "Y’know, this wasn’t even half as bad as I thought it was going to be."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:248
translate chinese SR3_home_end_penetrate_96f92bce:

    # MC "Yeah, you really got yourself worked up. Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:250
translate chinese SR3_home_end_penetrate_f135394a:

    # MC "Just give me one minute to wash this. I’ll be right back and we can pick up where we left off."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:251
translate chinese SR3_home_end_penetrate_6849c12c:

    # MC "Stay right there, I won’t be long!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:253
translate chinese SR3_home_end_penetrate_fcf4cd1d:

    # Sara "(I really did blow this out of proportion in my mind...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:254
translate chinese SR3_home_end_penetrate_2b439eb7:

    # Sara "(I guess I have a habit of doing things like that. Especially when [player_name] hangs around with other women like Lily.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:255
translate chinese SR3_home_end_penetrate_c540c60c:

    # Sara "(Maybe I just need to take a step back, relax, and chill the fuck out every now and then.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:273
translate chinese SR3_we_home_end_penetrate_con1_6fbe92b5:

    # Sara "(Yeah... that’s right. Not everything is going to hurt me, and not every girl is trying to steal [player_name] away from me.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:275
translate chinese SR3_we_home_end_penetrate_con1_9774bdb7:

    # Sara "(Yeah... that's right. [player_name] wants the best for me, and it's not like every girl is trying to steal him away from me.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:276
translate chinese SR3_we_home_end_penetrate_con1_3fad2e8d:

    # Sara "God... Haha... I’m an idiot."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:278
translate chinese SR3_we_home_end_penetrate_con1_100c1bcb:

    # MC "What was that?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:279
translate chinese SR3_we_home_end_penetrate_con1_de4131cf:

    # Sara "I was just laughing that I’m an idiot. I see how ridiculous my reaction was now."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:281
translate chinese SR3_we_home_end_penetrate_con1_fc0035a1:

    # MC "Haha, it’s alright, Sara. You were scared. I understand. Shall we get back to it?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:283
translate chinese SR3_we_home_end_penetrate_con1_ca9f2f6b:

    # MC "Haha, it’s alright, Sara. You were nervous. I understand. Shall we get back to it?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:284
translate chinese SR3_we_home_end_penetrate_con1_c3eacd8a:

    # Sara "Mmm, yes please!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:286
translate chinese SR3_we_home_end_penetrate_con1_4a3593d6:

    # Sara "Oohh... That’s nice, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:287
translate chinese SR3_we_home_end_penetrate_con1_90e6e921:

    # MC "Mmm... Your pussy really is fucking perfect, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:288
translate chinese SR3_we_home_end_penetrate_con1_7ba253e6:

    # MC "Are you okay if I plunge my cock in all the way now?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:290
translate chinese SR3_we_home_end_penetrate_con1_1435b319:

    # Sara "Yes, [player_name]! Do it. Fuck me hard!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:292
translate chinese SR3_we_home_end_penetrate_con1_73601410:

    # Sara "Ahh! Ah! Ah! Yes! This feels amazing!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:294
translate chinese SR3_we_home_end_penetrate_con1_8eba8007:

    # Sara "Oh [player_name]! I love you! You’re amazing!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:296
translate chinese SR3_we_home_end_penetrate_con1_1f4aab86:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:297
translate chinese SR3_we_home_end_penetrate_con1_058fa951:

    # MC "(Her pussy feels like it’s grabbing onto my cock, she’s so tight! This is phenomenal!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:299
translate chinese SR3_we_home_end_penetrate_con1_c6ce6b7b:

    # Sara "Your cock *gasp* is so massive! Ohh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:300
translate chinese SR3_we_home_end_penetrate_con1_8f45c6c0:

    # MC "How does it hnngg... feel now, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:302
translate chinese SR3_we_home_end_penetrate_con1_0b62ad51:

    # Sara "It’s like oohh.. it’s like that time I came when ah.. ah... you were fucking my butt with the lube on. Ahh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:303
translate chinese SR3_we_home_end_penetrate_con1_499e6d52:

    # MC "Do you want to try some other positions?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:305
translate chinese SR3_we_home_end_penetrate_con1_6a9c9419:

    # Sara "Can we do it with you behind me? Like we did on the roof?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:306
translate chinese SR3_we_home_end_penetrate_con1_c0ebc05b:

    # MC "Sure, Sara. It might be easier if you stand up though. Try leaning against the couch."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:308
translate chinese SR3_we_home_end_penetrate_con1_8e637806:

    # Sara "How’s this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:309
translate chinese SR3_we_home_end_penetrate_con1_612e3fa9:

    # MC "Absolutely perfect. God, your butt is fucking amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:311
translate chinese SR3_we_home_end_penetrate_con1_bac819f4:

    # Sara "You’re not going to put it in my ass again, are you?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:312
translate chinese SR3_we_home_end_penetrate_con1_c0663349:

    # MC "Haha, no. Not today. I was just admiring it. You’ve got this perfect bubble butt."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:313
translate chinese SR3_we_home_end_penetrate_con1_5cef2c67:

    # Sara "Hehe, thanks!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:315
translate chinese SR3_we_home_end_penetrate_con1_6549257f:

    # MC "I’m gonna go a bit faster and harder now. You’ll see just how good sex can be."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:316
translate chinese SR3_we_home_end_penetrate_con1_542b1fec:

    # Sara "Hurry up and put it in! Don’t keep me waiting!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:318
translate chinese SR3_we_home_end_penetrate_con1_39a1464a:

    # Sara "Mmm! Yes... Just like that, [player_name]. Plunge your thick cock deep inside me!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:319
translate chinese SR3_we_home_end_penetrate_con1_8b9866ea:

    # Sara "(I’m soaking wet right now!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:321
translate chinese SR3_we_home_end_penetrate_con1_1547b503:

    # MC "Here we go, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:322
translate chinese SR3_we_home_end_penetrate_con1_9068bb6c:

    # MC "I’m going to pound your pussy until you’re cumming so hard you can barely stand."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:323
translate chinese SR3_we_home_end_penetrate_con1_8e93edb0:

    # Sara "(Oh wow, that sounds so hot!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:325
translate chinese SR3_we_home_end_penetrate_con1_22adba9e:

    # MC "Hnngg..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:327
translate chinese SR3_we_home_end_penetrate_con1_cca43758:

    # Sara "Ohhh! Yes! Fill me up with your big cock, [player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:329
translate chinese SR3_we_home_end_penetrate_con1_1f4aab86_1:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:331
translate chinese SR3_we_home_end_penetrate_con1_700ab215:

    # MC "Mmm! Your little fuckhole is so damn tight."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:333
translate chinese SR3_we_home_end_penetrate_con1_5df79537:

    # Sara "Ah! God, yes! Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:335
translate chinese SR3_we_home_end_penetrate_con1_a5dbdc50:

    # Sara "Pound me, [player_name]! Fuck me harder! Ahh! AHHHHH!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:337
translate chinese SR3_we_home_end_penetrate_con1_71039872:

    # Sara "Smash your thick OOHHHHH... cock into my tight teen pussy! AAAAHHH!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:339
translate chinese SR3_we_home_end_penetrate_con1_7d936ca3:

    # Sara "Smash your thick OOHHHHH... cock into my tight pussy! AAAAHHH!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:341
translate chinese SR3_we_home_end_penetrate_con1_c5dcf0b9:

    # MC "Ohh... fuck! Ugh! Hnnngg..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:342
translate chinese SR3_we_home_end_penetrate_con1_1492a2ae:

    # Sara "Ohhhh myyyy Godddd! It’s soooo fucking good! Mmmmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:344
translate chinese SR3_we_home_end_penetrate_con1_f02dd5ba:

    # Sara "T-Talk dirty to me! I want to ahh... hear your voice!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:346
translate chinese SR3_we_home_end_penetrate_con1_f4d550d6:

    # MC "(She wants me to talk dirty to her? I guess I could start with some tamer stuff to see if she enjoys it.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:348
translate chinese SR3_we_home_end_penetrate_con1_4bf2da7d:

    # MC "Ohh... fuck! Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:350
translate chinese SR3_we_home_end_penetrate_con1_450c2d85:

    # MC "I’m going to slam my cock into your tight little cunt again and again."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:351
translate chinese SR3_we_home_end_penetrate_con1_a5b56a9e:

    # Sara "Yeeesssss!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:352
translate chinese SR3_we_home_end_penetrate_con1_d767f067:

    # MC "I’m not gonna stop until you’re cumming your brains out."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:354
translate chinese SR3_we_home_end_penetrate_con1_60920b31:

    # Sara "Ahh! Ahhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:355
translate chinese SR3_we_home_end_penetrate_con1_ca60ec0d:

    # MC "And when you start begging me to stop fucking you because you can’t take it any more, I’m going to speed up."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:357
translate chinese SR3_we_home_end_penetrate_con1_a64d397c:

    # Sara "Ohhhh Hoooolyyy shit! Ayyaaaaahhhh!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:359
translate chinese SR3_we_home_end_penetrate_con1_4bf2da7d_1:

    # MC "Ohh... fuck! Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:361
translate chinese SR3_we_home_end_penetrate_con1_77aaa918:

    # MC "Whenever you’re-"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:362
translate chinese SR3_we_home_end_penetrate_con1_d6883394:

    # Sara "Oh fuck! It’s happening! I’m cumming! I’m cumming! AAAHHH!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:364
translate chinese SR3_we_home_end_penetrate_con1_6a0c5786:

    # Sara "Ahhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:365
translate chinese SR3_we_home_end_penetrate_con1_b3cd62b0:

    # Sara "(My whole body is contracting and twitching! It feels like electricity is running through my veins right now!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:367
translate chinese SR3_we_home_end_penetrate_con1_3ea1b7a3:

    # MC "That’s it, Sara. Cum for me. I want you to cum for me again."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:368
translate chinese SR3_we_home_end_penetrate_con1_d4727c09:

    # Sara "Hnnnggg... Ohhhh!!!!! GOD! It’s t-too intense!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:369
translate chinese SR3_we_home_end_penetrate_con1_51cef0ff:

    # MC "Cum again! I want to feel your wet hole clamping down around my dick."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:371
translate chinese SR3_we_home_end_penetrate_con1_9c647c9a:

    # Sara "Haaaahhhhhh! AAAAHHHH!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:372
translate chinese SR3_we_home_end_penetrate_con1_a57c537b:

    # Sara "(It isn’t stopping! The pleasure just keeps coming and coming in waves!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:373
translate chinese SR3_we_home_end_penetrate_con1_aeef0cb5:

    # MC "Are you enjoying my cock forcing you to cum over and over? Of course you are."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:375
translate chinese SR3_we_home_end_penetrate_con1_82f5b4a9:

    # Sara "I...ahhhh... love it! Sooo goood!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:376
translate chinese SR3_we_home_end_penetrate_con1_99bfe986:

    # MC "You’ve cum so hard you can barely string a sentence together. Look up at me. I want to look into your beautiful green eyes as you climax."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:378
translate chinese SR3_we_home_end_penetrate_con1_2b490aee:

    # Sara "[player_name].... Aaahhhhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:379
translate chinese SR3_we_home_end_penetrate_con1_700247fb:

    # MC "You’re going to cum again for me now. Do it."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:381
translate chinese SR3_we_home_end_penetrate_con1_711a1213:

    # Sara "AHHHHH!!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:382
translate chinese SR3_we_home_end_penetrate_con1_c3541316:

    # MC "(Her pussy is contacting around my cock with each orgasmic convulsion! I’m gonna cum inside her if she keeps this up!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:384
translate chinese SR3_we_home_end_penetrate_con1_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:385
translate chinese SR3_we_home_end_penetrate_con1_b26bbb44:

    # Sara "(Holy crap! He’s balls deep inside me now! I’m so sensitive down there, I can feel his veiny cock stirring me up!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:387
translate chinese SR3_we_home_end_penetrate_con1_a268ed85:

    # MC "Now, where should I cum? Ugh! Ah..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:388
translate chinese SR3_we_home_end_penetrate_con1_5857e55e:

    # Sara "Ah! Ah! Ahhhh! Ahh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:389
translate chinese SR3_we_home_end_penetrate_con1_b3a0f0f6:

    # MC "Should I pull out and blow my hot load all over your ass?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:391
translate chinese SR3_we_home_end_penetrate_con1_8bef11d5:

    # MC "Or should I just keep fucking you until I empty my balls deep into your womb?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:393
translate chinese SR3_we_home_end_penetrate_con1_37d74855:

    # Sara "Ahhh! Yessss! Please! I want your cuummmmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:395
translate chinese SR3_we_home_end_penetrate_con1_b9b3a994:

    # Sara "Ah! Ah! Ahhhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:397
translate chinese SR3_we_home_end_penetrate_con1_c5dcf0b9_1:

    # MC "Ohh... fuck! Ugh! Hnnngg..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:399
translate chinese SR3_we_home_end_penetrate_con1_a58e563d:

    # MC "It’s probably dangerous for me to cum inside you right now. You’re not on the pill, and we didn’t use a condom, did we Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:401
translate chinese SR3_we_home_end_penetrate_con1_09efefb2:

    # Sara "Ah! Ahh! N-No, we didn’t! Ohhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:402
translate chinese SR3_we_home_end_penetrate_con1_b689119a:

    # MC "But you’re too horny to resist right now, aren't you? You’re going to let me dump a thick creamy load deep inside your pussy if I want to, aren’t you?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:404
translate chinese SR3_we_home_end_penetrate_con1_ca4e1078:

    # Sara "(I... I have to resist... I can’t let... I might get pregnant... I...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:405
translate chinese SR3_we_home_end_penetrate_con1_6760fb90:

    # MC "I can tell you’re trying to resist it, but deep down you’re wondering what it feels like to have your pussy pumped full of hot, sticky cum."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:406
translate chinese SR3_we_home_end_penetrate_con1_0887e71c:

    # Sara "(No... I... I shouldn’t let... It’s too risky... I...)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:407
translate chinese SR3_we_home_end_penetrate_con1_7c26bd02:

    # Sara "Cum inside me! PLEASE! I want to feel your hot cum fill me up!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:412
translate chinese SR3_we_home_end_penetrate_con1_85c7bdc7:

    # MC "Aaahh! Fuck! I’m cumming!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:413
translate chinese SR3_we_home_end_penetrate_con1_06429b9c:

    # Sara "Oohh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:421
translate chinese SR3_we_home_end_penetrate_con1_77e8401a:

    # MC "Hnnngg! Ugh!! Aaaahhh!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:422
translate chinese SR3_we_home_end_penetrate_con1_35836c8f:

    # Sara "Oh... wow... Mmm! It’s so warm..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:423
translate chinese SR3_we_home_end_penetrate_con1_2a92540a:

    # MC "*Pant* Fuck... That was... intense."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:424
translate chinese SR3_we_home_end_penetrate_con1_44ff1d0a:

    # Sara "Haha... You can say that again... *Phew*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:429
translate chinese SR3_we_home_end_penetrate_con1_65729f1c:

    # MC "Ugh! I’m gonna cum, Sara. I’m gonna cum!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:431
translate chinese SR3_we_home_end_penetrate_con1_d7f0a805:

    # Sara "(F-Fuck, this is so unsafe! I... I need to stop him... I need to... It’s so good... I should tell him to cum outside!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:433
translate chinese SR3_we_home_end_penetrate_con1_5bc4ddaa:

    # Sara "(F-Fuck, this is so unsafe! I... I need to... It's so good... But maybe I should tell him to cum outside!?)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:434
translate chinese SR3_we_home_end_penetrate_con1_39c9421d:

    # Sara "Ah! Ahhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:435
translate chinese SR3_we_home_end_penetrate_con1_fa19d982:

    # MC "Hnnngg! Get ready, Sara. Your fertile pussy is about to be aaahh... filled with semen!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:437
translate chinese SR3_we_home_end_penetrate_con1_18026de7:

    # Sara "(N-No! He might get me pregnant! His sperm are going to fertilise my eggs and... oh God, why am I getting even more turned on thinking about that?! Shit! I think I’m gonna cum again!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:439
translate chinese SR3_we_home_end_penetrate_con1_a8e661c1:

    # Sara "(Y-Yes! He might get me pregnant! His sperm is going to fertilize my eggs and... Oh God! Why am I getting, even more, turned on thinking about that?! Shit! I think I'm gonna cum again!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:440
translate chinese SR3_we_home_end_penetrate_con1_d7a902c5:

    # Sara "I... I... Ohhh!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:441
translate chinese SR3_we_home_end_penetrate_con1_1d2724e3:

    # MC "Aarggghhh! I’m cumming!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:442
translate chinese SR3_we_home_end_penetrate_con1_a9d8923b:

    # Sara "(Holy shit! I can feel his cock pulsating. There’s a hot sensation flooding my pussy!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:443
translate chinese SR3_we_home_end_penetrate_con1_4810a788:

    # Sara "YESSS [player_name]! CUM INSIDE ME! FILL ME UP! AAHHHH!!! I’m cuuummmmiiinnnnggg! Ayaaaahhhhh!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:451
translate chinese SR3_we_home_end_penetrate_con1_c1f8c6f4:

    # MC "*Pant* *Pant* That was... fucking... amazing!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:452
translate chinese SR3_we_home_end_penetrate_con1_038b3936:

    # Sara "W-Wow... I’m still... *Gasp* trembling..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:453
translate chinese SR3_we_home_end_penetrate_con1_12aae51a:

    # MC "Did you enjoy your first time?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:455
translate chinese SR3_we_home_end_penetrate_con1_6f47a162:

    # Sara "It was *pant* so... so hot when you came inside me. I wasn’t expecting that. It really turned me on."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:457
translate chinese SR3_we_home_end_penetrate_con1_f8d531a2:

    # Sara "It was *pant* so... so hot when you came inside me. It really turned me on, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:458
translate chinese SR3_we_home_end_penetrate_con1_e27aed97:

    # MC "Heh, I’m glad you enjoyed it. I love you, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:459
translate chinese SR3_we_home_end_penetrate_con1_368b48b9:

    # Sara "I love you too, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:460
translate chinese SR3_we_home_end_penetrate_con1_ffcef8e4:

    # Sara "Hehe, I can feel it leaking out. I guess it’s my turn to wash now!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:470
translate chinese SR3_we_home_end_penetrate_con2_5d16d980:

    # MC "Mmm... It’s so relaxing cuddling you like this."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:471
translate chinese SR3_we_home_end_penetrate_con2_bd00cabf:

    # Sara "[player_name]? I have a question."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:472
translate chinese SR3_we_home_end_penetrate_con2_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:475
translate chinese SR3_we_home_end_penetrate_con2_d181acd1:

    # Sara "Was it actually good? The sex?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:477
translate chinese SR3_we_home_end_penetrate_con2_717f7f51:

    # Sara "Was it actually good? My pussy? It wasn’t too tight or something?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:478
translate chinese SR3_we_home_end_penetrate_con2_961c64eb:

    # MC "Of course it was! It was mind-blowing for me. Having my cock inside your pussy was just... Heaven on Earth."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:480
translate chinese SR3_we_home_end_penetrate_con2_232551ed:

    # Sara "Do you really mean that?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:481
translate chinese SR3_we_home_end_penetrate_con2_6621f834:

    # MC "Yes, Sara. I really mean that."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:482
translate chinese SR3_we_home_end_penetrate_con2_4637a626:

    # MC "In future we can try some other positions out. Like Cowgirl, where you’re on top, or the Full Nelson, where I hold you up in the air by your thighs when I fuck you."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:484
translate chinese SR3_we_home_end_penetrate_con2_83a0d7c9:

    # Sara "I enjoyed doggy style, but I’m looking forward to trying the other ones too."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:485
translate chinese SR3_we_home_end_penetrate_con2_7f5aad72:

    # MC "I’m glad to hear that. I enjoyed doggy too. It gave me a perfect view of that ass of yours."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:486
translate chinese SR3_we_home_end_penetrate_con2_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:488
translate chinese SR3_we_home_end_penetrate_con2_32dd4f7d:

    # Sara "Whenever we were having sex and you were about to cum I started panicking. I thought, ‘Oh no! He’s going to cum inside me and I’ll get pregnant.’"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:489
translate chinese SR3_we_home_end_penetrate_con2_8f9ec322:

    # MC "It’s perfectly natural to worry about that."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:490
translate chinese SR3_we_home_end_penetrate_con2_54ea8e69:

    # Sara "That’s the weird thing... I didn’t get worried. My pussy got wetter and then I came harder than ever before. The thought of your semen flowing into me just pushed me over the edge."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:491
translate chinese SR3_we_home_end_penetrate_con2_bdc5155c:

    # MC "That’s probably just a fetish you’ve got for being creampied or maybe impregna-"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:494
translate chinese SR3_we_home_end_penetrate_con2_1cb67dde:

    # "*BZZT BZZT*"
    ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:495
translate chinese SR3_we_home_end_penetrate_con2_aca2661a:

    # MC "Haha, is that your vibrator?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:499
translate chinese SR3_we_home_end_penetrate_con2_2d91d054:

    # Sara "...it’s your phone."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:500
translate chinese SR3_we_home_end_penetrate_con2_79149731:

    # MC "Who the hell is messaging me at this time?"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:502
translate chinese SR3_we_home_end_penetrate_con2_d475f46d:

    # Sara "Do you want to answer it?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:503
translate chinese SR3_we_home_end_penetrate_con2_3330692a:

    # MC "It’ll be fine."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:504
translate chinese SR3_we_home_end_penetrate_con2_3496c7af:

    # Sara "Go on, it could be Caroline or [Mom_name] needing help with something."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:505
translate chinese SR3_we_home_end_penetrate_con2_0d4520e9:

    # MC "*Sigh* Alright. "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:507
translate chinese SR3_we_home_end_penetrate_con2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:508
translate chinese SR3_we_home_end_penetrate_con2_73f2e65f:

    # Sara "[player_name]? You okay there?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:509
translate chinese SR3_we_home_end_penetrate_con2_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:515
translate chinese SR3_we_home_end_penetrate_con2_2bbbcd0b:

    # MC "I... I..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:516
translate chinese SR3_we_home_end_penetrate_con2_a9c75bb2:

    # Sara "Wh-What’s wrong?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:518
translate chinese SR3_we_home_end_penetrate_con2_7548d1ba:

    # Sara "Shit! Did someone in the house hear us? Was it [Mom_name]?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:520
translate chinese SR3_we_home_end_penetrate_con2_2709945d:

    # Sara "Shit! Did something bad happen? [player_name]?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:522
translate chinese SR3_we_home_end_penetrate_con2_e9340702:

    # MC "(Jesus Christ, Lily... What the fuck are you doing sending me nudes?!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:523
translate chinese SR3_we_home_end_penetrate_con2_65bb89a4:

    # Sara "[player_name]? [player_name]! Talk to me!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:525
translate chinese SR3_we_home_end_penetrate_con2_1ce67c91:

    # MC "I... I uh..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:526
translate chinese SR3_we_home_end_penetrate_con2_73bd7ef6:

    # MC "(Sara is going to freak the fuck out if she sees this! I have to delete it!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:528
translate chinese SR3_we_home_end_penetrate_con2_b1a2514b:

    # MC "(C’mon! Where’s the delete button?! Where is it?!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:529
translate chinese SR3_we_home_end_penetrate_con2_7d91db25:

    # Sara "[player_name]... What’s going on?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:532
translate chinese SR3_we_home_end_penetrate_con2_1cb67dde_1:

    # "*BZZT BZZT*"
    ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:536
translate chinese SR3_we_home_end_penetrate_con2_745374ee:

    # MC "No!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:537
translate chinese SR3_we_home_end_penetrate_con2_93e572fd:

    # MC "(Shit! She keeps sending more!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:539
translate chinese SR3_we_home_end_penetrate_con2_e39d5f42:

    # MC "I... I wasn’t... It just..."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:542
translate chinese SR3_we_home_end_penetrate_con2_1cb67dde_2:

    # "*BZZT BZZT*"
    ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:546
translate chinese SR3_we_home_end_penetrate_con2_8defa5f7:

    # Sara "Wh-Why are you getting nudes from Lily?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:547
translate chinese SR3_we_home_end_penetrate_con2_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:548
translate chinese SR3_we_home_end_penetrate_con2_e09d97de:

    # Sara "[player_name]!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:555
translate chinese SR3_we_home_end_penetrate_con2_6dae75cd:

    # Sara "How did she get your number, [player_name]?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:556
translate chinese SR3_we_home_end_penetrate_con2_58903701:

    # MC "I... I gave it to her! B-But I thought she just wanted to be friends or something!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:558
translate chinese SR3_we_home_end_penetrate_con2_9ddcb1df:

    # Sara "Liar! You’ve been sexting with her, haven’t you?! You’ve been playing both of us against each other!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:559
translate chinese SR3_we_home_end_penetrate_con2_6c4756bd:

    # Sara "That’s why she showed up at the date, isn’t it? She wanted to keep an eye on the competition!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:564
translate chinese SR3_we_home_end_penetrate_con2_6dae75cd_1:

    # Sara "How did she get your number, [player_name]?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:565
translate chinese SR3_we_home_end_penetrate_con2_b8d2987b:

    # MC "I...I don’t know! I swear!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:566
translate chinese SR3_we_home_end_penetrate_con2_809d1f2e:

    # Sara "She didn’t just guess it! You gave her it at Thick n’ Creamy when I wasn’t looking, didn’t you?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:568
translate chinese SR3_we_home_end_penetrate_con2_18b09d88:

    # MC "No! Sara, I wanted nothing to do with her!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:569
translate chinese SR3_we_home_end_penetrate_con2_f4a79d9a:

    # Sara "You just keep lying and lying to me! You’ve been stringing me along this whole time and playing me for a fool!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:570
translate chinese SR3_we_home_end_penetrate_con2_4a891239:

    # Sara "That’s why she showed up at the date, isn’t it? Lily just wanted to get in between us!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:572
translate chinese SR3_we_home_end_penetrate_con2_dcac4bf3:

    # MC "Sara! That isn’t it at all!"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:573
translate chinese SR3_we_home_end_penetrate_con2_31d89d9a:

    # Sara "GET OUT! GET OUT OF MY ROOM!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:574
translate chinese SR3_we_home_end_penetrate_con2_cf4e28e2:

    # MC "Sara, I-"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:576
translate chinese SR3_we_home_end_penetrate_con2_8bfa6c46:

    # Sara "Get out or I’m getting [Mom_name] and telling her!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:578
translate chinese SR3_we_home_end_penetrate_con2_162ffd1f:

    # Sara "Get out! I'm not joking! Get the FUCK outta here!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:580
translate chinese SR3_we_home_end_penetrate_con2_6457d12a:

    # Sara "H-How could you do this to *sob* me?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:581
translate chinese SR3_we_home_end_penetrate_con2_a18c62e1:

    # MC "(Lily... What the fuck are you playing at?!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:583
translate chinese SR3_we_home_end_penetrate_con2_45bbbde1:

    # Sara "Hurry up and leave, you cheating bastard!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:584
translate chinese SR3_we_home_end_penetrate_con2_81ace2e0:

    # MC "I’m sorry, I didn’t- I... I’ll go."
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:586
translate chinese SR3_we_home_end_penetrate_con2_14e0aed3:

    # Sara "*Sob* I loved you... "
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:587
translate chinese SR3_we_home_end_penetrate_con2_7df65225:

    # Sara "I gave you *sob* my virginity."
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:588
translate chinese SR3_we_home_end_penetrate_con2_bbd1d088:

    # Sara "Why aren’t I enough for you, [player_name]?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:594
translate chinese SR3_we_home_end_penetrate_con2_c92c8a6c:

    # MC "(I need to fix this as soon as possible. Lily seems intent on sabotaging my relationship with Sara any way she can. I’m gonna have to fight fire with fire.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:595
translate chinese SR3_we_home_end_penetrate_con2_d1717cbb:

    # MC "(Maybe I should visit Sara tomorrow morning after she has slept? It might give me an opportunity for her to hear me out clearly.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:597
translate chinese SR3_we_home_end_penetrate_con2_00dea25b:

    # MC "(And how the fuck did Lily get my phone number? She must have asked around my other friends at college. Gah! One of them must have been stupid enough to pass it on to her.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:599
translate chinese SR3_we_home_end_penetrate_con2_904732f4:

    # Sara "*Sob Sob*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:600
translate chinese SR3_we_home_end_penetrate_con2_6ba533bc:

    # MC "Jesus... "
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:601
translate chinese SR3_we_home_end_penetrate_con2_577382fe:

    # MC "(I can hear her bawling her eyes out through the walls.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/SR3_home_end_penetrate.rpy:602
translate chinese SR3_we_home_end_penetrate_con2_daf9e4cb:

    # MC "(Good fucking job, Lily. Well done ruining our first date twice.)"
    MC ""

