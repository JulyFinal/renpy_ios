﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:105
translate chinese MLR2_weekend_label_d11f76c1:

    # Mom "Good evening, Dear. Nice to see you finally made it."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:106
translate chinese MLR2_weekend_label_433e0b68:

    # MC "You started drinking without me?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:107
translate chinese MLR2_weekend_label_5c1e7de9:

    # Mom "Just a little bit. Hehe...! I was too excited, to contain myself any longer."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:110
translate chinese MLR2_weekend_label_6f45b5a3:

    # Mom "I kept you plenty of wine though. Take a glass and join me."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:112
translate chinese MLR2_weekend_label_bdbe97e5:

    # Mom "You have no idea how happy I am that this is finally happening. I have fantasised about this moment for AGES."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:114
translate chinese MLR2_weekend_label_5caafd6e:

    # Mom "You have no idea how happy I am that this is finally happening. I have fantasized about this moment for a while!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:115
translate chinese MLR2_weekend_label_97980eb0:

    # Mom "And now, tonight, you're all mine."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:118
translate chinese MLR2_weekend_label_bb4c8968:

    # Mom "God... it feels so liberating to have you this close..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:119
translate chinese MLR2_weekend_label_5787b519:

    # Mom "...to know that no one is going to interrupt us or take you away from me tonight."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:120
translate chinese MLR2_weekend_label_fe7b3cec:

    # Mom "I love you, [player_name]."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:122
translate chinese MLR2_weekend_label_d6d9f8bc:

    # MC "I love you too, Mom."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:124
translate chinese MLR2_weekend_label_4ac41469:

    # MC "I love you too, Linda."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:128
translate chinese MLR2_weekend_label_d0a975c8:

    # Mom "Whoops! Haha! Looks like I fell back on the bed."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:129
translate chinese MLR2_weekend_label_857668cc:

    # Mom "Now, what's that hard thing in your pants? It wouldn't be your cock, would it?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:131
translate chinese MLR2_weekend_label_efc2fd0d:

    # Mom "Do you have any idea how BAD it would be for a boy's cock to rub against his own mother's pussy?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:133
translate chinese MLR2_weekend_label_806807ad:

    # Mom "My, my... Do you have any idea how BAD it would be for a young man like you to have his cock rubbing up against a married woman’s pussy?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:134
translate chinese MLR2_weekend_label_e7589cc3:

    # MC "(Damn, I love it when she talks dirty!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:135
translate chinese MLR2_weekend_label_847b7851:

    # Mom "Hurry up and kiss me."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:139
translate chinese MLR2_weekend_label_ca588a8d:

    # MC "(This is gonna be the best night of my life!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:141
translate chinese MLR2_weekend_label_e739176a:

    # MC "(I'm gonna lose my virginity to the sexiest damn woman on Earth!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:142
translate chinese MLR2_weekend_label_495b6ffc:

    # MC "(I can already feel her panties are soaking wet – she clearly can't wait to have my dick shoved, deep inside her!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:146
translate chinese MLR2_weekend_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:147
translate chinese MLR2_weekend_label_c15d4045:

    # Mom "Mmmm...."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:148
translate chinese MLR2_weekend_label_bcc62e5f:

    # Mom "(I can feel [player_name]'s tongue in my mouth! God, this is so fucking hot!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:152
translate chinese MLR2_weekend_label_775b5085:

    # Mom "(I don't know why, but the fact this is wrong, is making it even hotter!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:154
translate chinese MLR2_weekend_label_10c1af4a:

    # MC "Mhm..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:155
translate chinese MLR2_weekend_label_e62d6d17:

    # Mom "Mhmm..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:156
translate chinese MLR2_weekend_label_e896e46a:

    # Mom "(I wonder, in what position we'll fuck in first? Perhaps me on top? Or maybe I'll lie back and let him take charge.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:157
translate chinese MLR2_weekend_label_9f7532a2:

    # Mom "(The thought of his cock plunging into me, over and over, is driving me crazy!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:158
translate chinese MLR2_weekend_label_eb35463f:

    # MC "(I can taste a little sweet wine from her tounge... It feels weird but.. good!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:162
translate chinese MLR2_weekend_label_008c854f:

    # Mom "Are you ready for tonight?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:164
translate chinese MLR2_weekend_label_2808bdea:

    # MC "Definitely, Mom. I can't wait."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:166
translate chinese MLR2_weekend_label_2a93348b:

    # MC "Definitely, Linda. I can't wait."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:167
translate chinese MLR2_weekend_label_8015028a:

    # Mom "Promise? I don't want to push you into something you're not absolutely comfortable with."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:171
translate chinese MLR2_weekend_label_3236d6d2:

    # MC "Relax, Mom. I'm with the most stunning woman I've ever met. There is nothing you could say or do right now, that would make me change my mind about tonight."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:172
translate chinese MLR2_weekend_label_3fe258ec:

    # MC "(Mom picked out some really hot lingerie for tonight!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:174
translate chinese MLR2_weekend_label_650e1922:

    # MC "Relax, Linda. I'm with the most stunning woman I've ever met. There is nothing you could say or do right now, that would make me change my mind about tonight."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:175
translate chinese MLR2_weekend_label_ce4323e6:

    # MC "(She picked out some really hot lingerie for tonight!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:176
translate chinese MLR2_weekend_label_b6010e1c:

    # MC "(The fun part, is going to be stripping her out of it!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:180
translate chinese MLR2_weekend_label_5bc29029:

    # Mom "Well, if you're sure. You're still my boy, at the end of the day. And I wouldn't want to do anything to hurt you."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:182
translate chinese MLR2_weekend_label_56dd4eb5:

    # Mom "Well, if you're sure. You're still my young man, at the end of the day. And I wouldn't want to do anything to hurt you."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:183
translate chinese MLR2_weekend_label_65299b3c:

    # MC "You're not going to hurt me. I've never felt so safe and relaxed in my life."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:184
translate chinese MLR2_weekend_label_27971f2e:

    # Mom "Me too."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:187
translate chinese MLR2_weekend_label_5173c387:

    # Mom "(Hmm? I wonder how I can move things along. I don't want this to descend into romantic cuddling yet.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:188
translate chinese MLR2_weekend_label_82b8a7bb:

    # Mom "(Okay, time to take charge. I think I've got a plan for this.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:191
translate chinese MLR2_weekend_label_0e5b2d35:

    # Mom "Let me slip out of these flimsy clothes – then you can tell me if you like what you see."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:192
translate chinese MLR2_weekend_label_c108ca6c:

    # MC "I'm already LOVING what I'm seeing!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:193
translate chinese MLR2_weekend_label_262ad363:

    # Mom "Oh yeah? Then perhaps you'd like to explore my body a bit more."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:194
translate chinese MLR2_weekend_label_2b515de7:

    # MC "Definitely!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:197
translate chinese MLR2_weekend_label_371fc248:

    # Mom "In that case - let’s play a little game. I'll go first."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:198
translate chinese MLR2_weekend_label_9cac5712:

    # Mom "Just lie on your back. I’m gonna pour some wine on you and lick it off."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:199
translate chinese MLR2_weekend_label_41be8a70:

    # MC "Mmm... I’m liking the sound of that."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:200
translate chinese MLR2_weekend_label_2437dfd0:

    # Mom "We'll take it in turns – I'll do three on your body – then you can do three on mine. Sound good?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:201
translate chinese MLR2_weekend_label_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:205
translate chinese MLR2_weekend_label_7ac9f207:

    # Mom "In that case, let’s begin here..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:206
translate chinese MLR2_weekend_label_34a59dd4:

    # MC "Oh!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:207
translate chinese MLR2_weekend_label_59939d87:

    # MC "(Jesus! That's chilly!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:208
translate chinese MLR2_weekend_label_9a3c2183:

    # Mom "Haha! Sorry, is that a little bit cold, Sweetie?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:212
translate chinese MLR2_weekend_label_816106c5:

    # Mom "Let me warm it back up for you."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:213
translate chinese MLR2_weekend_label_a70b9d7d:

    # MC "Mmm... Ooohh..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:214
translate chinese MLR2_weekend_label_8dfd7588:

    # MC "That's so good..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:218
translate chinese MLR2_weekend_label_7b729689:

    # Mom "Now, let's do your belly next."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:219
translate chinese MLR2_weekend_label_0d4cf71d:

    # MC "*Gasp!*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:220
translate chinese MLR2_weekend_label_82f6e36a:

    # Mom "(Hehe. I love the way he squirms!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:224
translate chinese MLR2_weekend_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:225
translate chinese MLR2_weekend_label_822d5ad4:

    # MC "(She's getting so close to my cock right now!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:226
translate chinese MLR2_weekend_label_f5358300:

    # MC "(Please pour the wine there next... PLEASE pour the wine there next!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:229
translate chinese MLR2_weekend_label_1c48e78b:

    # Mom "Hmm... I've used two of my goes. I wonder where I should pour the final bit of wine?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:230
translate chinese MLR2_weekend_label_823ff93c:

    # Mom "Have you any ideas?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:231
translate chinese MLR2_weekend_label_a7993435:

    # MC "I can think of one place, in particular."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:232
translate chinese MLR2_weekend_label_32ad0591:

    # Mom "So can I."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:236
translate chinese MLR2_weekend_label_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:237
translate chinese MLR2_weekend_label_baf453e2:

    # Mom "Such a big thick cock..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:238
translate chinese MLR2_weekend_label_0ab7dd56:

    # Mom "I can't wait to have you inside me."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:241
translate chinese MLR2_weekend_label_774e83a4:

    # Mom "*Lick Lick*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:242
translate chinese MLR2_weekend_label_8035612f:

    # MC "Ah! Ahh... Ah...."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:243
translate chinese MLR2_weekend_label_b600741f:

    # Mom "(Sounds like he's REALLY enjoying this!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:246
translate chinese MLR2_weekend_label_e277af7c:

    # Mom "*Suck Suck!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:247
translate chinese MLR2_weekend_label_f941cc5d:

    # MC "Oh! Ohhhh Oh ohh..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:248
translate chinese MLR2_weekend_label_15fcadb7:

    # Mom "*Shluuurrrrp*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:251
translate chinese MLR2_weekend_label_e3e8e728:

    # Mom "Ahem... That's enough of that. I don't want to get you off, TOO quickly."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:252
translate chinese MLR2_weekend_label_023cd8b7:

    # Mom "Besides - it’s your turn now. Pick three places on my body."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:254
translate chinese MLR2_weekend_label_5d86b5d0:

    # MC "Okay, Mom. Just lie back for me."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:256
translate chinese MLR2_weekend_label_dec17579:

    # MC "Okay, Linda. Just lie back for me."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:259
translate chinese MLR2_weekend_label_e46c2347:

    # MC "(Hmm... Where to begin?)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:337
translate chinese MLR2_weekend_feet_label_36de114b:

    # Mom "Hehe..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:338
translate chinese MLR2_weekend_feet_label_17fe5f16:

    # MC "Sorry, does that tickle?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:339
translate chinese MLR2_weekend_feet_label_d6f8e91d:

    # Mom "J-Just a little bit, as it trickles between my toes!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:340
translate chinese MLR2_weekend_feet_label_b7d9f3e2:

    # MC "Oh dear, we can't have that now."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:344
translate chinese MLR2_weekend_feet_label_338bad60:

    # MC "I'll have to clean this mess up with my tongue."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:345
translate chinese MLR2_weekend_feet_label_232320c5:

    # Mom "Ooohh.... Mmm...."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:346
translate chinese MLR2_weekend_feet_label_cec75792:

    # Mom "(God... this is incredible!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:350
translate chinese MLR2_weekend_feet_label_3b81ffa7:

    # MC "*Suck Suck!*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:351
translate chinese MLR2_weekend_feet_label_987874ad:

    # Mom "Ah! Ahh.... Ooooohhhh..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:352
translate chinese MLR2_weekend_feet_label_ff70b6ea:

    # MC "(She's absolutely loving having her toes sucked!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:365
translate chinese MLR2_weekend_shin_label_b6e159d3:

    # Mom "Ah! Cold..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:366
translate chinese MLR2_weekend_shin_label_7d4cff0a:

    # MC "Hehe... It’s only fair. You did it to me!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:367
translate chinese MLR2_weekend_shin_label_2d6861fa:

    # Mom "(My shins? I don't think I've ever been kissed there before.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:371
translate chinese MLR2_weekend_shin_label_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:372
translate chinese MLR2_weekend_shin_label_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:385
translate chinese MLR2_weekend_pussy_label_acd47b91:

    # MC "I think you'll enjoy this spot the most."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:386
translate chinese MLR2_weekend_pussy_label_20a6f65f:

    # Mom "Hmm?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:387
translate chinese MLR2_weekend_pussy_label_39237400:

    # Mom "(Ohh! The wine's on my pussy!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:391
translate chinese MLR2_weekend_pussy_label_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:392
translate chinese MLR2_weekend_pussy_label_32ca6eda:

    # Mom "Mmmm... Yes, Baby... Right there!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:394
translate chinese MLR2_weekend_pussy_label_0f4926ab:

    # MC "(Mom’s so wet I can barely taste the wine!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:396
translate chinese MLR2_weekend_pussy_label_e10697e0:

    # MC "(Linda’s so wet I can barely taste the wine!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:400
translate chinese MLR2_weekend_pussy_label_42a213b6:

    # MC "(Let’s focus on her clitoris for a bit, and see how she enjoys that!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:401
translate chinese MLR2_weekend_pussy_label_19ee5846:

    # Mom "Ooohhh! God... Yes... Mmm!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:402
translate chinese MLR2_weekend_pussy_label_adf49859:

    # Mom "Don’t stop, [player_name]! Yeeessssss!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:403
translate chinese MLR2_weekend_pussy_label_a599f521:

    # MC "(Hehe. I’ve teased her enough. I don’t want to make her cum, before we get to the main show!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:417
translate chinese MLR2_weekend_belly_label_1b10106a:

    # MC "(Let’s pour some wine on her belly. I’m sure she’ll love, having my hot tongue flick around her navel!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:418
translate chinese MLR2_weekend_belly_label_6cc8521d:

    # Mom "Ah... (I really should have warmed the red wine up a little...)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:422
translate chinese MLR2_weekend_belly_label_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:423
translate chinese MLR2_weekend_belly_label_ee9ce0eb:

    # Mom "Hehe... Ah- Hehe..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:424
translate chinese MLR2_weekend_belly_label_4ec6892f:

    # MC "(Haha! It sounds like this tickles her!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:425
translate chinese MLR2_weekend_belly_label_4b48c2cc:

    # Mom "Haha! Okay, you can- haha- stop that now!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:439
translate chinese MLR2_weekend_breasts_label_e9807979:

    # MC "(Okay, let’s try pouring some wine on Mom’s breasts. They’re erogenous zones, right?)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:441
translate chinese MLR2_weekend_breasts_label_6cbb6882:

    # MC "(Okay, let’s try pouring some wine on Linda’s breasts. They’re erogenous zones, right?)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:442
translate chinese MLR2_weekend_breasts_label_70157bb4:

    # Mom "Oooh...."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:443
translate chinese MLR2_weekend_breasts_label_3fd5f76d:

    # Mom "(I can’t wait to feel his mouth clamped over my nipple!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:447
translate chinese MLR2_weekend_breasts_label_c5890411:

    # Mom "Yes... Oh, yessss...."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:448
translate chinese MLR2_weekend_breasts_label_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:449
translate chinese MLR2_weekend_breasts_label_0c5f06b3:

    # Mom "Suck on it! Suck on my breasts!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:453
translate chinese MLR2_weekend_breasts_label_cd7f6e60:

    # MC "*Suck Suck*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:454
translate chinese MLR2_weekend_breasts_label_065df0fd:

    # Mom "Ahhhhh! God! Yes! Hnnnggg!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:468
translate chinese MLR2_weekend_mouth_label_a6b555a7:

    # MC "(It’s not the first place I thought of - but pouring some wine in Mom’s mouth and kissing her could work!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:470
translate chinese MLR2_weekend_mouth_label_ecd22d2d:

    # MC "(It’s not the first place I thought of - but pouring some wine in her mouth and kissing her could work!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:471
translate chinese MLR2_weekend_mouth_label_00090c18:

    # MC "(Let’s see how she likes it...)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:475
translate chinese MLR2_weekend_mouth_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:476
translate chinese MLR2_weekend_mouth_label_7eaa8ed1:

    # Mom "Hmm?! Mmmm..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:478
translate chinese MLR2_weekend_mouth_label_e180e001:

    # Mom "(Wow! Having my son kiss me, with the taste of my favourite red wine in my mouth, is incredible.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:480
translate chinese MLR2_weekend_mouth_label_be0dc870:

    # Mom "(Wow! Having [player_name] kiss me, with the taste of my favourite red wine in my mouth, is incredible.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:492
translate chinese MLR2_weekend_end_label_f834b121:

    # Mom "(God dammit... I’m so fucking wet!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:493
translate chinese MLR2_weekend_end_label_cf0bc12c:

    # Mom "(I don’t think I can contain myself any longer. It’s driving me MAD!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:494
translate chinese MLR2_weekend_end_label_22cd9f28:

    # Mom "(I HAVE to fuck him! I have to screw him RIGHT NOW!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:498
translate chinese MLR2_weekend_end_label_7d8dec28:

    # Mom "Okay! The game’s over!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:499
translate chinese MLR2_weekend_end_label_517c8109:

    # MC "Huh? Did I do something wr-"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:500
translate chinese MLR2_weekend_end_label_88091e5e:

    # Mom "Get on your back! Just lie down on the bed!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:504
translate chinese MLR2_weekend_end_label_c79ba12d:

    # MC "[Mom_name]! What’s going on?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:505
translate chinese MLR2_weekend_end_label_2ed0fba5:

    # Mom "I need your cock! I need it so fucking much right now!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:506
translate chinese MLR2_weekend_end_label_ed524567:

    # Mom "God, I just want to suck the cum out of you..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:507
translate chinese MLR2_weekend_end_label_52844a0b:

    # MC "How about you lie on top of me and we sixty-nine, then?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:511
translate chinese MLR2_weekend_end_label_f8acb940:

    # Mom "Perfect idea! Ahh... Yes..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:512
translate chinese MLR2_weekend_end_label_8008bb1f:

    # MC "*Lick!*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:513
translate chinese MLR2_weekend_end_label_bd2ac247:

    # Mom "Go deep with your tongue... Ahh..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:514
translate chinese MLR2_weekend_end_label_ea0a7340:

    # Mom "That’s it! Right... ugh... there! I love feeling a, hot, wet, muscle, writhing deep inside me."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:518
translate chinese MLR2_weekend_end_label_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:519
translate chinese MLR2_weekend_end_label_a6b75fb2:

    # Mom "*Shlurrrrp*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:520
translate chinese MLR2_weekend_end_label_67f5b606:

    # Mom "(I’m gonna suck him dry. [player_name] is about to have his cock sucked like he has NEVER had before!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:522
translate chinese MLR2_weekend_end_label_13ffa4a2:

    # MC "(Mmm... She’s started. This is gonna be fun! I don’t know how long I’ll be able to last, with the scent of Mom’s pussy in my face.)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:524
translate chinese MLR2_weekend_end_label_348b8bea:

    # MC "(Mmm, she’s started. This is gonna be fun! I don’t know how long I’ll be able to last with the scent of her pussy in my face.)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:527
translate chinese MLR2_weekend_end_label_e277af7c:

    # Mom "*Suck Suck!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:528
translate chinese MLR2_weekend_end_label_1072088e:

    # Mom "Mmm! MMM!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:529
translate chinese MLR2_weekend_end_label_b04ec4be:

    # Mom "(It’s so difficult to concentrate on sucking him off while he’s licking my pussy like that. The pleasure is just so... distracting.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:533
translate chinese MLR2_weekend_end_label_70d2fa8f:

    # Mom "(I guess this means I need to up my game! Time to take his shaft deeper in my mouth!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:534
translate chinese MLR2_weekend_end_label_02b7591c:

    # MC "*Lick Lick!*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:535
translate chinese MLR2_weekend_end_label_b8a1863f:

    # MC "Mmm! Ahhh!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:536
translate chinese MLR2_weekend_end_label_c41d8ba6:

    # MC "(Damn, she’s bobbing her head faster! I’ve never seen her this horny before!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:540
translate chinese MLR2_weekend_end_label_d0e81f00:

    # Mom "*GULP!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:542
translate chinese MLR2_weekend_end_label_e3af3dd8:

    # Mom "*Shluuuuuuurrrrp!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:543
translate chinese MLR2_weekend_end_label_4934c7dd:

    # MC "Hnnnnngggg!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:547
translate chinese MLR2_weekend_end_label_056542bc:

    # MC "(Oh God! She’s deepthroating my cock right now! Fuck! I’m not gonna last much longer!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:548
translate chinese MLR2_weekend_end_label_36b7bde7:

    # MC "(I’ve got to tell her to stop, or I’ll end up cumming before we have sex!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:552
translate chinese MLR2_weekend_end_label_30d058de:

    # MC "Mom! Stop! I’m gonna... ahhhh... cum!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:554
translate chinese MLR2_weekend_end_label_10bae71e:

    # MC "Linda! Stop! I’m gonna... ahhhh... cum!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:555
translate chinese MLR2_weekend_end_label_1e04cbc3:

    # Mom "*Suck suck!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:557
translate chinese MLR2_weekend_end_label_21d8cdf1:

    # MC "Mom! Ahhh! We’re supposed to have sex... hnnnng... remember?!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:559
translate chinese MLR2_weekend_end_label_59c7cdc3:

    # MC "Linda! Ahhh! We’re supposed to have sex... hnnnng... remember?!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:563
translate chinese MLR2_weekend_end_label_bfd92aec:

    # Mom "(Shit... I have to control myself.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:564
translate chinese MLR2_weekend_end_label_4ab80695:

    # Mom "(This happens every time I’m around him - I just can’t restrain myself.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:566
translate chinese MLR2_weekend_end_label_7ecceeae:

    # MC "Mom!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:568
translate chinese MLR2_weekend_end_label_fa3a6335:

    # MC "Linda!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:569
translate chinese MLR2_weekend_end_label_6e9f946b:

    # Mom "(Fuck... Time to stop.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:573
translate chinese MLR2_weekend_end_label_0294fb70:

    # Mom "(Just one last kiss.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:574
translate chinese MLR2_weekend_end_label_26e8a28e:

    # MC "Phew... *Pant*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:575
translate chinese MLR2_weekend_end_label_4f3614ee:

    # MC "(Thank God she’s stopping... That was too close.)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:579
translate chinese MLR2_weekend_end_label_c0401168:

    # MC "(I was right on the edge of cumming there. Just a couple more licks, and I would have been jizzing, deep down her throat!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:582
translate chinese MLR2_weekend_end_label_33b0a285:

    # MC "Thanks, Mom. That was... really close. Shall we get started on something else.. then?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:584
translate chinese MLR2_weekend_end_label_b8704fc9:

    # MC "Thanks, Linda. That was... really close. Shall we get started on something else.. then?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:587
translate chinese MLR2_weekend_end_label_1ee01a02:

    # Mom "(Dammit... I don’t want to stop... It’s just so alluring to suck on.)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:589
translate chinese MLR2_weekend_end_label_3ed22d27:

    # MC "What the hell is she doing"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:598
translate chinese MLR2_weekend_end_label_658880ff:

    # Mom "*SHLURRRRRP SUCK SUCK SUCK!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:599
translate chinese MLR2_weekend_end_label_0335d87c:

    # MC "Hnnnnnnggggg!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:600
translate chinese MLR2_weekend_end_label_d01b88b9:

    # MC "(What the hell is she doing?! Why did she start sucking again?!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:601
translate chinese MLR2_weekend_end_label_805ff8a5:

    # Mom "*SUCK SUCK!*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:603
translate chinese MLR2_weekend_end_label_099a1451:

    # Mom "(MMM! This feels sooo good!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:604
translate chinese MLR2_weekend_end_label_d56c81db:

    # MC "(I can’t hold it back anymore!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:605
translate chinese MLR2_weekend_end_label_e4e3378c:

    # MC "I’m cumming! AHHH!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:614
translate chinese MLR2_weekend_end_label_523cf011:

    # Mom "*Gulp Gulp*"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:615
translate chinese MLR2_weekend_end_label_a0a660c3:

    # MC "Ohhh... Fuck..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:616
translate chinese MLR2_weekend_end_label_4fca9ee4:

    # MC "(That was so intense... but what am I gonna do now?! There’s no way I’ll get it hard again, to fuck her...)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:620
translate chinese MLR2_weekend_end_label_173004a7:

    # Mom "*Gasp* Wow... You REALLY came hard there, didn’t you, [player_name]?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:622
translate chinese MLR2_weekend_end_label_95d4ad7b:

    # MC "*Pant* Y-Yeah, Mom..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:624
translate chinese MLR2_weekend_end_label_87d0e1e7:

    # MC "*Pant* Y-Yeah, Linda..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:625
translate chinese MLR2_weekend_end_label_fdbbf65d:

    # MC "But that’s me spent - we guy’s aren’t like you girls. We can’t just keep going and going. I need some time to recharge my batteries."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:626
translate chinese MLR2_weekend_end_label_96c936a2:

    # Mom "Hehe... I know, Sweetie. Come lie on the bed, beside me. We can cuddle until you’re ready."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:630
translate chinese MLR2_weekend_end_label_4c4d00d1:

    # Mom "So, your father usually takes a full day before he gets hard again."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:632
translate chinese MLR2_weekend_end_label_0c8ad334:

    # Mom "My husband usually takes a full day before he gets hard again."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:633
translate chinese MLR2_weekend_end_label_4af167dd:

    # Mom "How long does it take a strapping young lad like you?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:634
translate chinese MLR2_weekend_end_label_d3328888:

    # MC "Uh... I don’t know. I’ve never really counted."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:635
translate chinese MLR2_weekend_end_label_95da4efb:

    # Mom "Make a guess."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:636
translate chinese MLR2_weekend_end_label_33362dda:

    # MC "Maybe an hour or two?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:640
translate chinese MLR2_weekend_end_label_81f28d07:

    # Mom "Perhaps I could help speed this process along?"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:642
translate chinese MLR2_weekend_end_label_20069e9f:

    # MC "Haha! You’re hot, Mom - but I don’t think you’ll be able to beat biology."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:644
translate chinese MLR2_weekend_end_label_7b6d56ad:

    # MC "Haha! You’re hot, Linda - but I don’t think you’ll be able to beat biology."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:645
translate chinese MLR2_weekend_end_label_68f6c57b:

    # Mom "That’s a shame. I was soooo looking forward to having this big boy, deep inside, my tight wet pussy."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:649
translate chinese MLR2_weekend_end_label_c4483237:

    # MC "Nice try, Mom. I don’t think dirty talk is gonna cut it though."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:651
translate chinese MLR2_weekend_end_label_fda71852:

    # MC "Nice try, Linda. I don’t think dirty talk is gonna cut it though."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:652
translate chinese MLR2_weekend_end_label_24cefb26:

    # MC "Just give me an hour and I’ll be ready for round two."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:653
translate chinese MLR2_weekend_end_label_1cb6cf6c:

    # Mom "Aww, that’s a shame. I was kind of hoping, the mere thought of pushing your rock hard cock between my wet vulva, and deep into my pussy, would get you hard."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:654
translate chinese MLR2_weekend_end_label_50e412f0:

    # Mom "How about the thought of me bouncing up and down on your shaft, until you explode into my-"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:658
translate chinese MLR2_weekend_end_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:659
translate chinese MLR2_weekend_end_label_ac2756d6:

    # Mom "Well - it looks like that did the trick."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:660
translate chinese MLR2_weekend_end_label_0b7548a0:

    # MC "I guess you were right! I don’t have a condom though-"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:664
translate chinese MLR2_weekend_end_label_09e153cf:

    # Mom "Fuck the condom! I’ve waited FAR too long for this moment, for it to be put off any longer."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:665
translate chinese MLR2_weekend_end_label_e3a2039a:

    # MC "I don’t think that’s safe...?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:666
translate chinese MLR2_weekend_end_label_1313f775:

    # Mom "Hurry up and stick it in me!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:667
translate chinese MLR2_weekend_end_label_31a123ac:

    # MC "(I guess it’s alright if I don’t cum inside.)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:671
translate chinese MLR2_weekend_end_label_fbcced81:

    # Mom "Oooh..."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:672
translate chinese MLR2_weekend_end_label_be81b5a8:

    # Mom "(I can feel his cock pressing against me! It’s going in!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:673
translate chinese MLR2_weekend_end_label_5d259084:

    # Mom "(That naughty dream I had for a while, is FINALLY coming true!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:674
translate chinese MLR2_weekend_end_label_995338a3:

    # Mom "(I feel like I’m ready to burst! I’ll probably cum, the second that he thrusts it inside me!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:677
translate chinese MLR2_weekend_end_label_bb45be40:

    # "*CRREEEEEAAAAAAAK*"
    ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:681
translate chinese MLR2_weekend_end_label_5e4af2a5:

    # Mom "HUH?!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:682
translate chinese MLR2_weekend_end_label_485fd02e:

    # MC "Huh!?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:683
translate chinese MLR2_weekend_end_label_399bd247:

    # Mom "(FUCK! That’s the front door!)"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:686
translate chinese MLR2_weekend_end_label_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:692
translate chinese MLR2_weekend_end_label_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:693
translate chinese MLR2_weekend_end_label_5e907272:

    # MC "(What the hell?!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:697
translate chinese MLR2_weekend_end_label_99d2008c:

    # Dad "Hi, Honey! I’m home! How are-"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:698
translate chinese MLR2_weekend_end_label_75077c34:

    # Mom "Get out!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:699
translate chinese MLR2_weekend_end_label_5b3de812:

    # Dad "W-What?!"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:700
translate chinese MLR2_weekend_end_label_f3a6d9f0:

    # MC "(Oh fuck... please don’t find me. Please don’t find me...)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:704
translate chinese MLR2_weekend_end_label_b33537dd:

    # Dad "I’m just coming to bed! The trip got cancelled at short notice!"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:705
translate chinese MLR2_weekend_end_label_9fd95741:

    # Mom "Go and sleep on the couch tonight!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:706
translate chinese MLR2_weekend_end_label_0f7012bc:

    # Dad "Wh-Why?!"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:710
translate chinese MLR2_weekend_end_label_bcdbed89:

    # Mom "B-Because I said so, you great big... oaf!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:711
translate chinese MLR2_weekend_end_label_b451c737:

    # Dad "Have I... done something?"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:712
translate chinese MLR2_weekend_end_label_9d1465e1:

    # Dad "Can we talk about this?"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:713
translate chinese MLR2_weekend_end_label_a2d334e3:

    # Mom "We’ll talk in the morning."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:717
translate chinese MLR2_weekend_end_label_6e8787fc:

    # Mom "Just get out!"
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:718
translate chinese MLR2_weekend_end_label_79b54d08:

    # Dad "(Jesus Christ! What have I done?!)"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:720
translate chinese MLR2_weekend_end_label_1d2c109e:

    # Dad "(Fuck... did I forget to clear the browsing history on the family PC?)"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:722
translate chinese MLR2_weekend_end_label_79a683ee:

    # Dad "(Fuck... did I forget to clear the browsing history on the PC?)"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:723
translate chinese MLR2_weekend_end_label_be2ea63c:

    # Dad "(What was the last thing I watched... Something about tentacles maybe?)"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:724
translate chinese MLR2_weekend_end_label_873457d1:

    # Dad "(Damn... I’ll have to wait till the morning to find out.)"
    Dad ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:728
translate chinese MLR2_weekend_end_label_8926109c:

    # Mom "Okay, he’s gone now, [player_name]."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:729
translate chinese MLR2_weekend_end_label_07bd4a4f:

    # Mom "Quickly sneak back into your bedroom. I’ll speak with you tomorrow morning."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:730
translate chinese MLR2_weekend_end_label_d776c8c1:

    # MC "O-Okay..."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:731
translate chinese MLR2_weekend_end_label_429cfffa:

    # MC "(Jesus, my heart’s pounding like a drum right now!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:732
translate chinese MLR2_weekend_end_label_7aa3cda7:

    # MC "(I was THIS close to getting caught!)"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:743
translate chinese MLR2_weekend_end_label_3378d200:

    # Mom "Wakey wakey, Sweetie. Rise and shine."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:744
translate chinese MLR2_weekend_end_label_947a5f05:

    # Mom "It’s time to get up, Honey."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:745
translate chinese MLR2_weekend_end_label_0f4e660f:

    # MC "Hmmm...."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:749
translate chinese MLR2_weekend_end_label_744334a1:

    # Mom "Come on, [player_name]. If I can drag myself out of bed after ALL that wine I had last night, then so can you."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:751
translate chinese MLR2_weekend_end_label_d0fc37ab:

    # MC "Haha... Morning, Mom."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:753
translate chinese MLR2_weekend_end_label_a77a2d1d:

    # MC "Haha... Morning, Linda."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:754
translate chinese MLR2_weekend_end_label_02d608fc:

    # MC "*Yawn!*"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:758
translate chinese MLR2_weekend_end_label_16f08775:

    # Mom "I’m sorry about your father, last night. Just... try to put it out of your head."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:760
translate chinese MLR2_weekend_end_label_03301a7c:

    # Mom "I’m sorry about my husband last night. Just... try to put it out of your head."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:761
translate chinese MLR2_weekend_end_label_e55d8936:

    # Mom "He’d promised me- GUARANTEED ME - he would be gone. I don’t know why he came all the way back, rather than just enjoying a night away in a hotel somewhere."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:763
translate chinese MLR2_weekend_end_label_6b06312e:

    # MC "Hey, it’s okay, Mom. I was shitting myself at the time, but I’ve calmed down now. We didn’t get caught."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:765
translate chinese MLR2_weekend_end_label_8a59673f:

    # MC "Hey, it’s okay, Linda. I was shitting myself at the time, but I’ve calmed down now. We didn’t get caught."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:769
translate chinese MLR2_weekend_end_label_1a3fecc1:

    # Mom "I’ll handle this, don’t worry. We’ll have our night together."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:770
translate chinese MLR2_weekend_end_label_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:772
translate chinese MLR2_weekend_end_label_bc1531ae:

    # Mom "Really. As soon as I can get rid of your father for a while, we’ll actually have sex."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:774
translate chinese MLR2_weekend_end_label_21d69104:

    # Mom "Really. As soon as I can get rid of my husband for a while, we’ll actually have sex."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:778
translate chinese MLR2_weekend_end_label_99e35e67:

    # MC "I love you, Mom."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:780
translate chinese MLR2_weekend_end_label_e517d6c7:

    # MC "I love you, Linda."
    MC ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:781
translate chinese MLR2_weekend_end_label_488626ce:

    # Mom "I love you too, [player_name]."
    Mom ""

# game/scripts/weekend_events/ML/MLR2_weekend.rpy:782
translate chinese MLR2_weekend_end_label_a791f8ee:

    # Mom "*Mwah!*"
    Mom ""

