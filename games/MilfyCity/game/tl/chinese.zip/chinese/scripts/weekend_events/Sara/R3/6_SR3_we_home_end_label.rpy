﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:29
translate chinese SR3_we_home_end_label_b4919a7b:

    # Sara "She ruined everything..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:30
translate chinese SR3_we_home_end_label_3fec3843:

    # MC "Sara, c’mon, we had a lovely day up until she arrived. Just try and put Lily out of your mind."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:31
translate chinese SR3_we_home_end_label_2bbf0f9e:

    # Sara "I can’t! She’s just so... so... so brazen!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:33
translate chinese SR3_we_home_end_label_37be5e11:

    # MC "Everything is going to be fine, I promise. Look on the bright side. You got your mint ice cream, and we got to see the grand opening of the mall!"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:34
translate chinese SR3_we_home_end_label_ed0ddb4b:

    # MC "That was a pretty damn-good date, even if Lily made the end a bit awkward."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:37
translate chinese SR3_we_home_end_label_10150983:

    # MC "Plus, I got to enjoy seeing you in your brand new dress. You really were a sight to behold."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:42
translate chinese SR3_we_home_end_label_789aa257:

    # MC "Like, seriously, you were the hottest girl in the whole mall."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:44
translate chinese SR3_we_home_end_label_6c736292:

    # Sara "Hotter than Lily?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:45
translate chinese SR3_we_home_end_label_afedf248:

    # MC "Haha, much hotter."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:46
translate chinese SR3_we_home_end_label_f320de93:

    # Sara "You’re just saying that to make me feel better. Lily has bigger breasts, she dresses sexier, and knows how to wear makeup better."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:48
translate chinese SR3_we_home_end_label_bed2af18:

    # MC "I’m serious, Sara. You’re so much cuter than she is. I love your breasts the way they are, I love your freckles, I loved your dress today."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:49
translate chinese SR3_we_home_end_label_78d5d614:

    # MC "If I didn’t like you, I wouldn’t have said yes to making today a formal date, would I?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:50
translate chinese SR3_we_home_end_label_882f7cb7:

    # Sara "I... guess not."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:52
translate chinese SR3_we_home_end_label_80135010:

    # MC "See? This never had anything to do with Lily. All she did was show up and make a fool of herself."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:53
translate chinese SR3_we_home_end_label_61d660ca:

    # Sara "Yeah... I guess you’re right."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:55
translate chinese SR3_we_home_end_label_c19e6f40:

    # Sara "You don’t like her though, do you?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:56
translate chinese SR3_we_home_end_label_054db284:

    # MC "No, I don’t have any feelings for Lily. I promise you that."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:57
translate chinese SR3_we_home_end_label_40cc3395:

    # Sara "Okay... I feel better hearing you say that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:59
translate chinese SR3_we_home_end_label_77b6f1f7:

    # MC "I promise you, Sara, it’s only you and me. Okay? Just you and me until the end."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:60
translate chinese SR3_we_home_end_label_a68ba4d1:

    # Sara "I’m sorry, [player_name], I keep overreacting when she’s around..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:62
translate chinese SR3_we_home_end_label_866a0647:

    # MC "It’s alright, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:63
translate chinese SR3_we_home_end_label_b5006c3a:

    # MC "The day isn’t over yet, by the way. We can still give our first date a happy ending."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:65
translate chinese SR3_we_home_end_label_b51d1f81:

    # Sara "What do you mean?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:66
translate chinese SR3_we_home_end_label_1b9a41af:

    # MC "How about we do it for the first time, together?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:68
translate chinese SR3_we_home_end_label_713821a1:

    # Sara "Y-You mean... have sex?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:69
translate chinese SR3_we_home_end_label_cd45fcb6:

    # MC "Yeah, not anal this time. I’m talking real sex. We went out in public as a couple. Everyone who saw us should know you’re mine by now."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:71
translate chinese SR3_we_home_end_label_9f056e42:

    # Sara "*Gulp* I’m a little nervous."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:73
translate chinese SR3_we_home_end_label_22de12af:

    # Sara "Is it going to hurt as much as anal did?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:74
translate chinese SR3_we_home_end_label_92c96379:

    # MC "Absolutely not. Your pussy is going to produce a natural lube, like what we used the second time we tried anal."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:76
translate chinese SR3_we_home_end_label_5c881d18:

    # MC "You might feel a slight pang of pain for a second or two when my cock first goes in. That’s just what happens when your hymen tears."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:77
translate chinese SR3_we_home_end_label_d2878f72:

    # MC "There also might be a little bit of blood, but don’t worry about that. It’s perfectly normal."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:78
translate chinese SR3_we_home_end_label_25e909d0:

    # Sara "And then it will feel good?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:79
translate chinese SR3_we_home_end_label_a78fa262:

    # MC "It will feel good after that."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:81
translate chinese SR3_we_home_end_label_1c92e302:

    # Sara "I love you, [player_name]. I know that it has to be with you... But, that feeling won't go away that easily."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:82
translate chinese SR3_we_home_end_label_f06fd377:

    # MC "I love you too, Sara. I promise I'll do everything to make that day special for you."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:84
translate chinese SR3_we_home_end_label_01feb5d4:

    # MC "You don't have to be nervous. It's just the two of us... making love... Didn't you masturbate before, thinking about me doing it?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:85
translate chinese SR3_we_home_end_label_f1d8dfa0:

    # MC "If you change your mind at any time just tell me, Sara. I'll do whatever you want."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:86
translate chinese SR3_we_home_end_label_d3ffec9d:

    # Sara "Do you promise? I want to feel you inside me, [player_name]. That feeling is gonna be incredible isn't it?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:87
translate chinese SR3_we_home_end_label_547a2945:

    # MC "I promise. I'll make sure to make it the most pleasant for you my cutie nerd."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:89
translate chinese SR3_we_home_end_label_b51da96f:

    # MC "What do you say, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:90
translate chinese SR3_we_home_end_label_108b4b44:

    # Sara "I... I... yeah... Let’s do it."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:91
translate chinese SR3_we_home_end_label_4afd7796:

    # MC "Are you absolutely sure you want to? I’m happy to wait a bit longer if you need some time."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:94
translate chinese SR3_we_home_end_label_1413cca6:

    # Sara "N-No... I’m ready, [player_name]. I’m ready to have my first time with my boyfriend."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:96
translate chinese SR3_we_home_end_label_5c189165:

    # Sara "N-No... I'm ready, [player_name]. I'm ready to give my pussy to my boyfriend."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:97
translate chinese SR3_we_home_end_label_c861567e:

    # MC "I'm happy to hear that. Let's make this a perfect end to our mall date together."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:98
translate chinese SR3_we_home_end_label_27ebd2f2:

    # Sara "Thank you, [player_name]. I love you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:99
translate chinese SR3_we_home_end_label_361972d6:

    # MC "I love you too, Sara. You’re amazing."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:102
translate chinese SR3_we_home_end_label_b4919a7b_1:

    # Sara "She ruined everything..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:103
translate chinese SR3_we_home_end_label_3fec3843_1:

    # MC "Sara, c’mon, we had a lovely day up until she arrived. Just try and put Lily out of your mind."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:104
translate chinese SR3_we_home_end_label_2bbf0f9e_1:

    # Sara "I can’t! She’s just so... so... so brazen!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:106
translate chinese SR3_we_home_end_label_37be5e11_1:

    # MC "Everything is going to be fine, I promise. Look on the bright side. You got your mint ice cream, and we got to see the grand opening of the mall!"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:107
translate chinese SR3_we_home_end_label_5c20f10f:

    # MC "We had a really fun time going out together, even if Lily made the end a bit awkward."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:109
translate chinese SR3_we_home_end_label_10150983_1:

    # MC "Plus, I got to enjoy seeing you in your brand new dress. You really were a sight to behold."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:114
translate chinese SR3_we_home_end_label_789aa257_1:

    # MC "Like, seriously, you were the hottest girl in the whole mall."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:116
translate chinese SR3_we_home_end_label_6c736292_1:

    # Sara "Hotter than Lily?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:117
translate chinese SR3_we_home_end_label_afedf248_1:

    # MC "Haha, much hotter."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:118
translate chinese SR3_we_home_end_label_a666396f:

    # Sara "You’re just saying that to make me feel better. You didn’t even want us to be a public couple though."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:119
translate chinese SR3_we_home_end_label_bdfebd2b:

    # Sara "There’s other girls out there that you have your eyes on. Lily has bigger breasts, she dresses sexier, and knows how to wear makeup better."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:121
translate chinese SR3_we_home_end_label_bed2af18_1:

    # MC "I’m serious, Sara. You’re so much cuter than she is. I love your breasts the way they are, I love your freckles, I loved your dress today."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:122
translate chinese SR3_we_home_end_label_2f878ac6:

    # Sara "Then why do we have to pretend we aren’t a couple? I hate that..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:124
translate chinese SR3_we_home_end_label_1d7d7948:

    # MC "Sara... It’s complicated. A lot of people wouldn’t approve of a brother and sister dating. For your safety and mine, it’s best to keep ourselves out of the spotlight."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:126
translate chinese SR3_we_home_end_label_cdd127a5:

    # MC "Sara... It's complicated. A lot of people wouldn't like us to date. (Like my other girls...) It's best to keep ourselves out of the spotlight."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:128
translate chinese SR3_we_home_end_label_4b4d8ccb:

    # Sara "(I need to make myself MORE appealing to [player_name] than Lily is. That slut would do anything to get her claws into him.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:129
translate chinese SR3_we_home_end_label_dea1f77d:

    # MC "All Lily did was show up and make a fool of herself."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:130
translate chinese SR3_we_home_end_label_b7fde449:

    # Sara "Uh huh..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:132
translate chinese SR3_we_home_end_label_787cc56b:

    # Sara "Do you find Lily attractive?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:133
translate chinese SR3_we_home_end_label_ff173ecd:

    # MC "Of course, I mean, she’s an attractive girl. I like you more though."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:134
translate chinese SR3_we_home_end_label_fb81d8b6:

    # Sara "(It hurts to hear him say that... but at least I know where I stand. I’m in competition with that bitch.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:136
translate chinese SR3_we_home_end_label_4584e743:

    # Sara "What if... What if I could do... more for you?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:137
translate chinese SR3_we_home_end_label_241ea077:

    # MC "What do you mean, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:139
translate chinese SR3_we_home_end_label_3863e326:

    # Sara "I’ve already let you take my anal virginity. I know you really want to fuck my other place too."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:140
translate chinese SR3_we_home_end_label_ae56ca49:

    # MC "Are you suggesting what I think you are suggesting?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:141
translate chinese SR3_we_home_end_label_1866e7fb:

    # Sara "(That's the best choice I can make! If I want to keep [player_name] in my life I'm going to have to up my game. Blowjobs and anal aren't enough. I need to give him my virginity!)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:143
translate chinese SR3_we_home_end_label_f95e6d13:

    # Sara "Y-Yeah, let’s do it. Tonight. Actual sex - not anal, not a blowjob. Full... sex. I want to go all the way with you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:144
translate chinese SR3_we_home_end_label_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:145
translate chinese SR3_we_home_end_label_17b962ea:

    # Sara "Absolutely. We’ll do it now. It’ll mark the end of our first date."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:147
translate chinese SR3_we_home_end_label_2406b8e6:

    # MC "Mmm, that sounds like a wonderful end to the day."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:148
translate chinese SR3_we_home_end_label_09e769cf:

    # Sara "If we do this, do you think you’d want to make me your girlfriend in public?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:149
translate chinese SR3_we_home_end_label_71fc823e:

    # MC "Sara... I’ll think about it. Like I said, it’s complicated and very risky."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:151
translate chinese SR3_we_home_end_label_a6c20033:

    # Sara "*Sigh* Okay... Can I be honest with you? I’m a little nervous."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:153
translate chinese SR3_we_home_end_label_22de12af_1:

    # Sara "Is it going to hurt as much as anal did?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:154
translate chinese SR3_we_home_end_label_92c96379_1:

    # MC "Absolutely not. Your pussy is going to produce a natural lube, like what we used the second time we tried anal."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:156
translate chinese SR3_we_home_end_label_5c881d18_1:

    # MC "You might feel a slight pang of pain for a second or two when my cock first goes in. That’s just what happens when your hymen tears."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:157
translate chinese SR3_we_home_end_label_d2878f72_1:

    # MC "There also might be a little bit of blood, but don’t worry about that. It’s perfectly normal."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:158
translate chinese SR3_we_home_end_label_25e909d0_1:

    # Sara "And then it will feel good?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:159
translate chinese SR3_we_home_end_label_a78fa262_1:

    # MC "It will feel good after that."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:161
translate chinese SR3_we_home_end_label_1c92e302_1:

    # Sara "I love you, [player_name]. I know that it has to be with you... But, that feeling won't go away that easily."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:162
translate chinese SR3_we_home_end_label_f06fd377_1:

    # MC "I love you too, Sara. I promise I'll do everything to make that day special for you."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:164
translate chinese SR3_we_home_end_label_01feb5d4_1:

    # MC "You don't have to be nervous. It's just the two of us... making love... Didn't you masturbate before, thinking about me doing it?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:165
translate chinese SR3_we_home_end_label_f1d8dfa0_1:

    # MC "If you change your mind at any time just tell me, Sara. I'll do whatever you want."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:166
translate chinese SR3_we_home_end_label_d3ffec9d_1:

    # Sara "Do you promise? I want to feel you inside me, [player_name]. That feeling is gonna be incredible isn't it?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:167
translate chinese SR3_we_home_end_label_547a2945_1:

    # MC "I promise. I'll make sure to make it the most pleasant for you my cutie nerd."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:169
translate chinese SR3_we_home_end_label_b51da96f_1:

    # MC "What do you say, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:170
translate chinese SR3_we_home_end_label_108b4b44_1:

    # Sara "I... I... yeah... Let’s do it."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:171
translate chinese SR3_we_home_end_label_4afd7796_1:

    # MC "Are you absolutely sure you want to? I’m happy to wait a bit longer if you need some time."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:174
translate chinese SR3_we_home_end_label_1413cca6_1:

    # Sara "N-No... I’m ready, [player_name]. I’m ready to have my first time with my boyfriend."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:175
translate chinese SR3_we_home_end_label_3431b03a:

    # Sara "(This is how I’m going to keep you away from that harpy, Lily.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:176
translate chinese SR3_we_home_end_label_c861567e_1:

    # MC "I'm happy to hear that. Let's make this a perfect end to our mall date together."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:178
translate chinese SR3_we_home_end_label_5c189165_1:

    # Sara "N-No... I'm ready, [player_name]. I'm ready to give my pussy to my boyfriend."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:179
translate chinese SR3_we_home_end_label_3d9de255:

    # Sara "(After that I'm going to keep you away from that harpy bitch, Lily.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:180
translate chinese SR3_we_home_end_label_c861567e_2:

    # MC "I'm happy to hear that. Let's make this a perfect end to our mall date together."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:181
translate chinese SR3_we_home_end_label_b8be5cad:

    # Sara "I love you, [player_name]. You know that? I love you more than any other girl ever will."
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:182
translate chinese SR3_we_home_end_label_05cb903c:

    # Sara "Well, how should we warm up?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:183
translate chinese SR3_we_home_end_label_91929e77:

    # MC "I could play with your tits to get you nice and wet."
    MC ""

# game/scripts/weekend_events/Sara/R3/6_SR3_we_home_end_label.rpy:184
translate chinese SR3_we_home_end_label_05746731:

    # Sara "Or I could go down and suck your cock to get you hard. You pick."
    Sara ""

