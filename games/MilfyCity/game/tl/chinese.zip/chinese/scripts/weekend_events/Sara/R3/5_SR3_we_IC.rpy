﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:90
translate chinese SR3_we_IC_label_6ac37e85:

    # MC "Hey there, we were just over at the van looking for some ice cream, but they were running low on stock. The guy sent us over here instead."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:91
translate chinese SR3_we_IC_label_e4b615ca:

    # Salesman "Sure, what flavours ya lookin’ for?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:92
translate chinese SR3_we_IC_label_d4d7dfc6:

    # MC "I was thinking of going for a-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:94
translate chinese SR3_we_IC_label_dd0a99b7:

    # Sara "THEY HAVE MINT! Look [player_name], over there!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:95
translate chinese SR3_we_IC_label_056aa575:

    # MC "Haha, yeah, I see it."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:97
translate chinese SR3_we_IC_label_ed07eac4:

    # Sara "And orange, and strawberry, and... OMG, I want to try them all!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:98
translate chinese SR3_we_IC_label_5c10e7f9:

    # MC "I’ll order us a few different flavours to try. How does that sound?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:99
translate chinese SR3_we_IC_label_3c531684:

    # Sara "Yay!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:101
translate chinese SR3_we_IC_label_8b60e258:

    # Salesman "If you two wanna grab a booth, I’ll take yer order shortly."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:102
translate chinese SR3_we_IC_label_53be5b7e:

    # MC "Cool, shall we grab a seat, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:103
translate chinese SR3_we_IC_label_32811d4b:

    # Sara "Great!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:104
translate chinese SR3_we_IC_label_8878d19e:

    # MC "There’s a table free over here."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:156
translate chinese SR3_we_IC_shop_table_6fdd7364:

    # MC "What do you think? Happy with these seats?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:157
translate chinese SR3_we_IC_shop_table_415093e8:

    # Sara "Yeah, these are great. These pink and white chairs look EXACTLY the way I remember them. Well, these ones are a LOT cleaner, given that they’re brand new."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:158
translate chinese SR3_we_IC_shop_table_69e9cf1b:

    # MC "It seems like a nice place to relax."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:159
translate chinese SR3_we_IC_shop_table_6451c196:

    # Sara "What flavours do you want?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:161
translate chinese SR3_we_IC_shop_table_3e0473da:

    # MC "Just a strawberry will do."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:162
translate chinese SR3_we_IC_shop_table_a0153524:

    # Sara "No way! The ice cream here is too amazing to only take one! Get two!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:163
translate chinese SR3_we_IC_shop_table_3684e441:

    # MC "Honestly, just a strawber-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:164
translate chinese SR3_we_IC_shop_table_dd48edb0:

    # Sara "C’mon [player_name]! I’m gonna get a second scoop as well."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:166
translate chinese SR3_we_IC_shop_table_28593f1c:

    # MC "Fine, let me check the menu."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:168
translate chinese SR3_we_IC_shop_table_6ed7b4a8:

    # Sara "That’s the spirit, [player_name]! It was never difficult to get Caroline to go for a second scoop... or a third, haha! Remember when she went through her chubby phase?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:170
translate chinese SR3_we_IC_shop_table_0e26a2f8:

    # Sara "That's the spirit, [player_name]! It was never difficult to get Caroline to go for a second scoop... or a third! Haha! Remember when she went through that chubby phase shortly after we all started renting?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:171
translate chinese SR3_we_IC_shop_table_e6d0b8db:

    # MC "Heh, she wasn’t THAT big!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:174
translate chinese SR3_we_IC_shop_table_23fd88e2:

    # Sara "So, what do you think of the place so far? Amazing, right?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:175
translate chinese SR3_we_IC_shop_table_5ea163d1:

    # MC "It’s certainly very... pink."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:176
translate chinese SR3_we_IC_shop_table_0f1f7f3d:

    # Sara "Haha! Just wait till you try it! It’ll change your life!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:178
translate chinese SR3_we_IC_shop_table_52ac9b72:

    # MC "Let’s see... I’ll take a... Hmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:179
translate chinese SR3_we_IC_shop_table_fa5b574b:

    # MC "There isn’t a great selection here. I figured an ice cream parlour would have more variety than this."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:181
translate chinese SR3_we_IC_shop_table_3a7bbe4f:

    # Sara "There’s more flavours up at the counter. They only put a small selection on the menus."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:182
translate chinese SR3_we_IC_shop_table_31ea8d7c:

    # MC "Hmm, in that case, what do you recommend?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:184
translate chinese SR3_we_IC_shop_table_740d6b3e:

    # Sara "You like the fruity flavours, right? Maybe try cranberry or watermelon."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:185
translate chinese SR3_we_IC_shop_table_a951322a:

    # MC "Let’s go for a scoop of watermelon, and a scoop of strawberry then."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:186
translate chinese SR3_we_IC_shop_table_3ee9708c:

    # Sara "Hey! Can we get one scoop of watermelon, a scoop of strawberry, one mint supreme, and one juicy orange?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:187
translate chinese SR3_we_IC_shop_table_4735a3a1:

    # Salesman "Sure thing! I’ll bring it over shortly."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:189
translate chinese SR3_we_IC_shop_table_4d41a0b0:

    # Sara "Good call, [player_name]. You’re gonna love this!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:190
translate chinese SR3_we_IC_shop_table_fed840b6:

    # MC "Honestly, the ice cream was just a bonus. The best thing that’s going to happen to me today, is getting to spend the whole day on a date with you."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:192
translate chinese SR3_we_IC_shop_table_d7e7c323:

    # Sara "Aww, that’s so sweet."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:197
translate chinese SR3_we_IC_shop_table_23fd88e2_1:

    # Sara "So, what do you think of the place so far? Amazing, right?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:198
translate chinese SR3_we_IC_shop_table_5ea163d1_1:

    # MC "It’s certainly very... pink."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:199
translate chinese SR3_we_IC_shop_table_507be08a:

    # Sara "Haha! Just wait till you try the ice cream! It’ll change your life!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:201
translate chinese SR3_we_IC_shop_table_52ac9b72_1:

    # MC "Let’s see... I’ll take a... Hmm..."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:202
translate chinese SR3_we_IC_shop_table_fa5b574b_1:

    # MC "There isn’t a great selection here. I figured an ice cream parlour would have more variety than this."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:204
translate chinese SR3_we_IC_shop_table_3a7bbe4f_1:

    # Sara "There’s more flavours up at the counter. They only put a small selection on the menus."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:205
translate chinese SR3_we_IC_shop_table_31ea8d7c_1:

    # MC "Hmm, in that case, what do you recommend?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:207
translate chinese SR3_we_IC_shop_table_740d6b3e_1:

    # Sara "You like the fruity flavours, right? Maybe try cranberry or watermelon."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:208
translate chinese SR3_we_IC_shop_table_a951322a_1:

    # MC "Let’s go for a scoop of watermelon, and a scoop of strawberry then."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:209
translate chinese SR3_we_IC_shop_table_3ee9708c_1:

    # Sara "Hey! Can we get one scoop of watermelon, a scoop of strawberry, one mint supreme, and one juicy orange?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:210
translate chinese SR3_we_IC_shop_table_4735a3a1_1:

    # Salesman "Sure thing! I’ll bring it over shortly."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:212
translate chinese SR3_we_IC_shop_table_4d41a0b0_1:

    # Sara "Good call, [player_name]. You’re gonna love this!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:213
translate chinese SR3_we_IC_shop_table_130115d7:

    # MC "Thanks, it’s a really warm day, so I’m actually looking forward to this.."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:215
translate chinese SR3_we_IC_shop_table_bd20dfb3:

    # Sara "To be honest, it wasn’t the ice cream that I was most excited about today."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:216
translate chinese SR3_we_IC_shop_table_2792c22c:

    # MC "No?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:217
translate chinese SR3_we_IC_shop_table_04891599:

    # Sara "It was the chance to spend the whole day on a date with y-"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:219
translate chinese SR3_we_IC_shop_table_2c61492d:

    # MC "Shush, keep your voice down. This place is packed with people from our college."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:220
translate chinese SR3_we_IC_shop_table_8f0280c4:

    # Sara "*Sigh* I forgot... I wish it didn’t have to be like this."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:221
translate chinese SR3_we_IC_shop_table_10487048:

    # MC "(Maybe I should ask her some questions to take her mind off things.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:235
translate chinese SR3_we_IC_shop_table_romantic_menu_c790fe7c:

    # MC "So, tell me Sara, how are your grades coming along? I know you mentioned you got an A in your creative writing."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:236
translate chinese SR3_we_IC_shop_table_romantic_menu_81b832ff:

    # MC "It’s quite impressive, to be honest, that you managed to score an A in English. I know it was one of your least favourite subjects."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:238
translate chinese SR3_we_IC_shop_table_romantic_menu_23a101b2:

    # Sara "Oh... well, it’s a mixed bag, to be honest. My Maths and Physics are all up to B’s now."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:239
translate chinese SR3_we_IC_shop_table_romantic_menu_244b54a7:

    # MC "Well, that’s good!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:240
translate chinese SR3_we_IC_shop_table_romantic_menu_1deee38f:

    # Sara "Buuuut, my Geography and History are a C minus and a D plus. So, I still have a long way to go."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:242
translate chinese SR3_we_IC_shop_table_romantic_menu_eabfbba8:

    # MC "What matters most is that you’re going in the right direction."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:243
translate chinese SR3_we_IC_shop_table_romantic_menu_b426fceb:

    # Sara "Huh, I guess you’re right. Thanks, [player_name]."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:249
translate chinese SR3_we_IC_shop_table_romantic_menu_93eb651d:

    # MC "Do you miss hanging out here with Caroline?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:252
translate chinese SR3_we_IC_shop_table_romantic_menu_1be77d0c:

    # Sara "Y’know... when I was younger, like four or five years ago, and Caroline stopped hanging out with me I was kinda sad."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:254
translate chinese SR3_we_IC_shop_table_romantic_menu_edc08b4c:

    # Sara "Y’know, I was kinda sad when Caroline stopped hanging out with me as much as she used to."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:255
translate chinese SR3_we_IC_shop_table_romantic_menu_419b5d2b:

    # Sara "It wasn’t her fault though. She had her own stuff to deal with. Setting up her clothing shop. That dick of a boyfriend, Charles. Stuff like that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:256
translate chinese SR3_we_IC_shop_table_romantic_menu_680f07ca:

    # Sara "As time moved on, I just sort of drifted off and did my own thing."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:258
translate chinese SR3_we_IC_shop_table_romantic_menu_10fe6c7b:

    # MC "But you never came back here by yourself."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:259
translate chinese SR3_we_IC_shop_table_romantic_menu_24e1042d:

    # Sara "I guess not. It’s just... I never imagined myself sitting in this place alone. It’s kinda... depressing, in a way. Especially when I had so many happy memories with her here."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:260
translate chinese SR3_we_IC_shop_table_romantic_menu_941e5391:

    # MC "Make sure to speak to her. I’m sure she has just as many fond memories of here as you do."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:263
translate chinese SR3_we_IC_shop_table_romantic_menu_c55cbb7e:

    # Sara "You’re probably right, [player_name]. I’ll see if I can arrange a sisterly reunion."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:265
translate chinese SR3_we_IC_shop_table_romantic_menu_5bc66585:

    # Sara "You’re probably right, [player_name]. I’ll see if I can arrange a reunion."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:271
translate chinese SR3_we_IC_shop_table_romantic_menu_98752597:

    # MC "How long did [Mom_name] end up grounding you for? It feels like at least two years."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:272
translate chinese SR3_we_IC_shop_table_romantic_menu_97391ecb:

    # Sara "Oh, come on! The patrons don’t want to hear about this!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:273
translate chinese SR3_we_IC_shop_table_romantic_menu_43ba0773:

    # MC "Patrons? What are you talking about?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:274
translate chinese SR3_we_IC_shop_table_romantic_menu_78afdf32:

    # Sara "The patrons of this ice cream parlour! They don’t want to hear how long I was grounded by [Mom_name] and forced to wait for the next step in our relationship."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:275
translate chinese SR3_we_IC_shop_table_romantic_menu_d8605e81:

    # MC "Fair point."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:276
translate chinese SR3_we_IC_shop_table_romantic_menu_ad51e200:

    # Sara "But yeah, it does feel like at least two years."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:291
translate chinese SR3_we_IC_shop_table_not_romantic_menu_6fdf961a:

    # MC "How are you and [Mom_name] getting since that fight over bad grades?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:293
translate chinese SR3_we_IC_shop_table_not_romantic_menu_21fa5972:

    # Sara "Ehh... Things have been a bit rocky. It was especially awkward for a while when she caught me using a vibrator on camera with you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:294
translate chinese SR3_we_IC_shop_table_not_romantic_menu_f02f3e8a:

    # Sara "She thought I was, in her words “doing the cybersex” with boys."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:295
translate chinese SR3_we_IC_shop_table_not_romantic_menu_50e9583a:

    # MC "Ahaha! She actually said, “doing the cybersex”."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:297
translate chinese SR3_we_IC_shop_table_not_romantic_menu_2385e75a:

    # Sara "Yup! That made me cringe WAAAY harder than getting caught, to be honest. Haha!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:299
translate chinese SR3_we_IC_shop_table_not_romantic_menu_6edfbea8:

    # Sara "Anyway, things have started to settle down now. She’s started bringing me cups of coffee up to my room and doing some mother-daughter chats."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:300
translate chinese SR3_we_IC_shop_table_not_romantic_menu_81ab41a9:

    # MC "I think [Mom_name] was hurt by your grades dropping like that."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:302
translate chinese SR3_we_IC_shop_table_not_romantic_menu_5f80e83a:

    # Sara "Anyway, things have started to settle down now. She’s started bringing me cups of coffee up to my room and chatting with me as if she was my mother!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:303
translate chinese SR3_we_IC_shop_table_not_romantic_menu_1db0a198:

    # MC "I think Linda was hurt by your grades dropping like that. She doesn’t have a child of her own, so even though she’s your landlady you’re probably the closest thing she’ll get to a daughter."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:306
translate chinese SR3_we_IC_shop_table_not_romantic_menu_eba7803e:

    # Sara "You’re right, [player_name]. [Mom_name]’s an accomplished businesswoman. I don’t think she wants to see one of her daughters end up wasting away as a jobless loser playing video games."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:308
translate chinese SR3_we_IC_shop_table_not_romantic_menu_82b0c6d0:

    # Sara "You’re right, [player_name]. Linda’s an accomplished businesswoman. I don’t think she wants to see one me end up wasting away as a jobless loser playing video games."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:309
translate chinese SR3_we_IC_shop_table_not_romantic_menu_f59b0913:

    # Sara "I mean, she is already impressed with Caroline’s achievements so far. It's stressful trying to meet her expectations, y'know?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:310
translate chinese SR3_we_IC_shop_table_not_romantic_menu_8a6e92f9:

    # MC "Aye, I can understand that."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:316
translate chinese SR3_we_IC_shop_table_not_romantic_menu_de8d8e23:

    # MC "Listen, Sara... I understand it’s a touchy subject, but..."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:317
translate chinese SR3_we_IC_shop_table_not_romantic_menu_fbd1e372:

    # MC "*Whispered* ...do you understand why we can just make this a normal date?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:319
translate chinese SR3_we_IC_shop_table_not_romantic_menu_c29f5cfd:

    # Sara "*Sigh* I do... Social pressure, societal norms, yada yada."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:321
translate chinese SR3_we_IC_shop_table_not_romantic_menu_6f2caa97:

    # Sara "Just tell me one thing, [player_name]. If I wasn’t your sister, would you be proud to call me your girlfriend in public?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:322
translate chinese SR3_we_IC_shop_table_not_romantic_menu_0549257d:

    # MC "Yes, Sara. I would. It’s just... not socially acceptable. The last thing I want is for you to be bullied in college on Monday morning."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:323
translate chinese SR3_we_IC_shop_table_not_romantic_menu_63e04eb8:

    # MC "Plus, what the heck are we gonna say to [Mom_name]? What are we gonna tell [Dad_name] or Caroline? They’ll lose their shit!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:325
translate chinese SR3_we_IC_shop_table_not_romantic_menu_83c29e55:

    # Sara "Just tell me one thing. If we weren't living together and going to the same college... would you be proud to call me your girlfriend in public?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:327
translate chinese SR3_we_IC_shop_table_not_romantic_menu_f2189983:

    # MC "Yes, Sara. I would. People in other colleges would not know us. (And other girls I'm seeing with too...)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:328
translate chinese SR3_we_IC_shop_table_not_romantic_menu_535a5b2a:

    # MC "Plus, what the heck are we gonna say to Linda? She would for sure put us in one room just to rent your room to another tenant for more money. Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:329
translate chinese SR3_we_IC_shop_table_not_romantic_menu_bc49229f:

    # Sara "*Sigh* I know..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:331
translate chinese SR3_we_IC_shop_table_not_romantic_menu_467b4306:

    # Sara "But maybe someday, right?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:332
translate chinese SR3_we_IC_shop_table_not_romantic_menu_a949b873:

    # MC "Yeah, someday. I’ll let you know when the time is right."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:339
translate chinese SR3_we_IC_shop_table_not_romantic_menu_3fc01d86:

    # MC "How’s the gaming going? Last time I saw you playing, you were part of some clan or something."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:341
translate chinese SR3_we_IC_shop_table_not_romantic_menu_7c359b92:

    # Sara "Yeah, we were on a clan raid. I haven’t played in a while now though, Linda took my laptop charger a while back."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:343
translate chinese SR3_we_IC_shop_table_not_romantic_menu_f12ac3f2:

    # Sara "Yeah, we were on a clan raid. I haven’t played in a while now though. I was busy catching up college stuff and meeting with you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:344
translate chinese SR3_we_IC_shop_table_not_romantic_menu_254b90b7:

    # MC "Aww, I’m sorry."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:346
translate chinese SR3_we_IC_shop_table_not_romantic_menu_a5af32df:

    # Sara "It’s okay. I do miss fun times I had with my clan, but without the games to distract me my grades have massively improved."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:347
translate chinese SR3_we_IC_shop_table_not_romantic_menu_388d2a14:

    # Sara "*Whispered* Which meant I got to see you again much sooner."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:358
translate chinese SR3_we_IC_shop_table_romantic_con_f28d1be1:

    # MC "You know, Sara, that dress you’re wearing is extremely sexy. You honestly look amazing today."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:359
translate chinese SR3_we_IC_shop_table_romantic_con_38af6400:

    # Sara "Thanks, [player_name]. You don’t look so bad yourself."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:360
translate chinese SR3_we_IC_shop_table_romantic_con_40a10854:

    # MC "Are you not shy about wearing it in public?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:361
translate chinese SR3_we_IC_shop_table_romantic_con_f847bbbe:

    # Sara "Why would I be shy?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:362
translate chinese SR3_we_IC_shop_table_romantic_con_695e52e6:

    # MC "Like, what if it slips or something?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:363
translate chinese SR3_we_IC_shop_table_romantic_con_460c6a5d:

    # Sara "Haha, it’s not gonna slip. I’m not some clutz!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:369
translate chinese SR3_we_IC_shop_table_romantic_con_95d7bf93:

    # Salesman "And here’s your order. We have: one juicy orange, one mint supreme, and one fruity deluxe with watermelon and strawberry."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:370
translate chinese SR3_we_IC_shop_table_romantic_con_73ae15ad:

    # Salesman "Enjoy your meal, and may I add, you two make an adorable couple."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:371
translate chinese SR3_we_IC_shop_table_romantic_con_abe89ee4:

    # Sara "Aww, thank you! Did you hear that, [player_name]? He said we look like a couple! Eeeek!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:372
translate chinese SR3_we_IC_shop_table_romantic_con_846d0a7d:

    # MC "Haha! I heard him, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:374
translate chinese SR3_we_IC_shop_table_romantic_con_689fbdfe:

    # Sara "OMG OMG OMG! Which one should I try first?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:375
translate chinese SR3_we_IC_shop_table_romantic_con_61dfce2a:

    # MC "Go for the mint. It’s the one you’ve been raving about all day!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:376
translate chinese SR3_we_IC_shop_table_romantic_con_4dae4316:

    # Sara "I’m so excited!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:378
translate chinese SR3_we_IC_shop_table_romantic_con_2ca5fc65:

    # Sara "Thanks again for taking me here, [player_name]. Whenever I asked you out I was super scared that you were gonna say no."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:379
translate chinese SR3_we_IC_shop_table_romantic_con_fdcd1b31:

    # MC "How could I possibly say no to dating you?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:380
translate chinese SR3_we_IC_shop_table_romantic_con_7202d696:

    # Sara "Aww, but you aren’t worried about us being seen together in public?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:383
translate chinese SR3_we_IC_shop_table_romantic_con_e4805a42:

    # MC "Maybe a little bit. I mean, you are my sister, and people from college are DEFINITELY gonna talk."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:385
translate chinese SR3_we_IC_shop_table_romantic_con_3200a0e3:

    # MC "Maybe a little bit. I mean, you are my roommate, and people from college are DEFINITELY gonna talk."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:386
translate chinese SR3_we_IC_shop_table_romantic_con_f3b8fc37:

    # Sara "I’m sorry..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:388
translate chinese SR3_we_IC_shop_table_romantic_con_016c3c9c:

    # MC "But, the more I think about it, the more I realise that a little social embarrassment is a price I’m happy to pay, for the chance to date you."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:390
translate chinese SR3_we_IC_shop_table_romantic_con_1c64ba49:

    # Sara "Aww, I love you. You’re gonna make me cry if you keep talking like that."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:392
translate chinese SR3_we_IC_shop_table_romantic_con_5ae34984:

    # MC "I love you too, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:393
translate chinese SR3_we_IC_shop_table_romantic_con_e8987519:

    # MC "Besides, I’ve already destroyed my reputation at college, after the incident with Ms. Celia. At this point I’ve got no respect left to lose! Haha!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:394
translate chinese SR3_we_IC_shop_table_romantic_con_f74ce6e6:

    # Sara "I guess that’s one way to stay optimistic!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:396
translate chinese SR3_we_IC_shop_table_romantic_con_1f793de6:

    # Sara "Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:397
translate chinese SR3_we_IC_shop_table_romantic_con_5815b82c:

    # MC "As good as you remember?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:398
translate chinese SR3_we_IC_shop_table_romantic_con_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:400
translate chinese SR3_we_IC_shop_table_romantic_con_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:401
translate chinese SR3_we_IC_shop_table_romantic_con_9a7900bc:

    # MC "(This is actually pretty good ice cream!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:403
translate chinese SR3_we_IC_shop_table_romantic_con_9b4b739a:

    # MC "So, do you have any other plans for our date today? Or was getting Thick n’ Creamy ice cream your top priority?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:404
translate chinese SR3_we_IC_shop_table_romantic_con_92c50f02:

    # MC "I mean, I’m not complaining - this stuff is spectacular!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:406
translate chinese SR3_we_IC_shop_table_romantic_con_06a98373:

    # Sara "Hehe, how about we take a walk around the mall together after this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:407
translate chinese SR3_we_IC_shop_table_romantic_con_9ee883e5:

    # Sara "You might be able to help me pick out another new outfit."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:408
translate chinese SR3_we_IC_shop_table_romantic_con_381af76c:

    # MC "Oooh, I like the sound of that."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:409
translate chinese SR3_we_IC_shop_table_romantic_con_ea15f10f:

    # Sara "And then, maybe later on tonight I can..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:411
translate chinese SR3_we_IC_shop_table_romantic_con_1dd292c8:

    # Sara "*Lick* *Lick*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:412
translate chinese SR3_we_IC_shop_table_romantic_con_c95260e4:

    # MC "Mmm... I’m really looking forward to tonight now."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:414
translate chinese SR3_we_IC_shop_table_romantic_con_f2588f1b:

    # Sara "Hehe! Today’s been really nice so far, [player_name]. Thank you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:415
translate chinese SR3_we_IC_shop_table_romantic_con_407afdb3:

    # MC "It’s far from over, Sara. And there’s no reason why we can’t go out again next week, or the week after that. We’re both young and we’ve got our whole lives ahead of us."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:417
translate chinese SR3_we_IC_shop_table_romantic_con_3b6d72f5:

    # Sara "That’s true. Maybe we could do the Zoo or something next week?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:418
translate chinese SR3_we_IC_shop_table_romantic_con_c3625a64:

    # MC "How about the cinema?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:419
translate chinese SR3_we_IC_shop_table_romantic_con_be496e23:

    # Sara "Cinema sounds good!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:421
translate chinese SR3_we_IC_shop_table_romantic_con_1f793de6_1:

    # Sara "Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:422
translate chinese SR3_we_IC_shop_table_romantic_con_0735191e:

    # MC "I’ll check what’s on. There’s a few good movies coming out this summer."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:424
translate chinese SR3_we_IC_shop_table_romantic_con_3fd64def:

    # Sara "Sounds good to me!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:425
translate chinese SR3_we_IC_shop_table_romantic_con_c8892ef6:

    # Sara "Mmm! That was delicious."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:431
translate chinese SR3_we_IC_shop_table_romantic_con_986424ab:

    # Sara "Listen, I’m just gonna run to the bathroom here. I’ll be two minutes."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:432
translate chinese SR3_we_IC_shop_table_romantic_con_0a1f0000:

    # Sara "Don’t you DARE touch my orange ice cream when I’m gone!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:434
translate chinese SR3_we_IC_shop_table_romantic_con_59918bf7:

    # MC "Haha, I wouldn’t dream of it."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:435
translate chinese SR3_we_IC_shop_table_romantic_con_58197fe1:

    # MC "See you in a bit!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:437
translate chinese SR3_we_IC_shop_table_romantic_con_e9971667:

    # MC "(Damn, she looks good in that short dress. I’m one lucky-ass guy to be dating her.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:438
translate chinese SR3_we_IC_shop_table_romantic_con_63df96b1:

    # MC "(I wonder if there are any lingerie stores in the mall. I could buy her something sexy to wear tonight whenever we’re-)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:440
translate chinese SR3_we_IC_shop_table_romantic_con_5048aab4:

    # Sara "Whoa!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:441
translate chinese SR3_we_IC_shop_table_romantic_con_ec0e4e85:

    # MC "Huh? Watch out!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:447
translate chinese SR3_we_IC_shop_table_romantic_con_0d528bf6:

    # Sara "Ooof!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:448
translate chinese SR3_we_IC_shop_table_romantic_con_120152c4:

    # MC "Christ! Are you okay, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:449
translate chinese SR3_we_IC_shop_table_romantic_con_7f28d65c:

    # Sara "Ugh... yeah, all good..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:451
translate chinese SR3_we_IC_shop_table_romantic_con_33f80530:

    # Sara "I just slipped on a wet patch."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:452
translate chinese SR3_we_IC_shop_table_romantic_con_666b86bd:

    # MC "Heh, I saw. Do you need a hand?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:453
translate chinese SR3_we_IC_shop_table_romantic_con_94ee517d:

    # Sara "No, all... good."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:455
translate chinese SR3_we_IC_shop_table_romantic_con_2f74602f:

    # MC "(So much for not being a clutz...)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:456
translate chinese SR3_we_IC_shop_table_romantic_con_6ec9ced6:

    # MC "(Now half the restaurant has seen up your skirt!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:458
translate chinese SR3_we_IC_shop_table_romantic_con_d515be2d:

    # Salesman "May I give you a hand up, madam?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:459
translate chinese SR3_we_IC_shop_table_romantic_con_2f6f17e4:

    # Sara "Don’t worry, I’ve got it."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:460
translate chinese SR3_we_IC_shop_table_romantic_con_458e9acc:

    # Salesman "(Oooh, it looks like her dress has slipped. It’s my lucky day!)"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:462
translate chinese SR3_we_IC_shop_table_romantic_con_28c5937c:

    # MC "(Damn that ice cream looks good.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:463
translate chinese SR3_we_IC_shop_table_romantic_con_37eae670:

    # MC "(Would Sara notice if I took a couple of licks out of it?)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:465
translate chinese SR3_we_IC_shop_table_romantic_con_b225b01b:

    # MC "(Eh, probably not. Besides, I could always buy her another for when she gets back.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:466
translate chinese SR3_we_IC_shop_table_romantic_con_d27920cf:

    # MC "(Yeah, Sara’s not going to mind.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:472
translate chinese SR3_we_IC_shop_table_romantic_con_1901c6ca:

    # Lily2 "Boo! Guess who!"
    Lily2 ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:473
translate chinese SR3_we_IC_shop_table_romantic_con_2e0cd453:

    # MC "Uhh, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:474
translate chinese SR3_we_IC_shop_table_romantic_con_c0824e49:

    # Lily2 "Wrong! Ahaha!"
    Lily2 ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:476
translate chinese SR3_we_IC_shop_table_romantic_con_99be63ab:

    # MC "C-Caroline?!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:477
translate chinese SR3_we_IC_shop_table_romantic_con_e812d8db:

    # Lily2 "What?! No! It’s me, silly!"
    Lily2 ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:479
translate chinese SR3_we_IC_shop_table_romantic_con_a62ff004:

    # MC "L-Lily! What are you doing here?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:480
translate chinese SR3_we_IC_shop_table_romantic_con_05811073:

    # Lily "The same thing everyone else is doing here, dumbo! Checking out the new mall! This place is huuuuuge, isn’t it?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:481
translate chinese SR3_we_IC_shop_table_romantic_con_282ca265:

    # MC "Uh, y-yeah! It is. What are you..."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:483
translate chinese SR3_we_IC_shop_table_romantic_con_4a3a95a7:

    # Lily "I was feeling so hot. I decided to swing by this place to cool down."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:484
translate chinese SR3_we_IC_shop_table_romantic_con_325ac037:

    # MC "Yeah, it’s pretty... pretty warm out there today."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:490
translate chinese SR3_we_IC_shop_table_romantic_con_f7ad5eef:

    # Lily "Do you think I look hot?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:491
translate chinese SR3_we_IC_shop_table_romantic_con_7ce8e58b:

    # MC "Yes - I mean, no- I mean... you should probably get an ice cream to cool down."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:492
translate chinese SR3_we_IC_shop_table_romantic_con_e8ab94f1:

    # Lily "Ahaha, I agree."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:494
translate chinese SR3_we_IC_shop_table_romantic_con_deb014ad:

    # Lily "I really can't believe how many people showed up today. Like, my entire college class is here! Can you believe it?!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:495
translate chinese SR3_we_IC_shop_table_romantic_con_4d33eba8:

    # Lily "People keep saying online shopping is gonna, like, kill malls and stuff, but I think people still love walking around these places. There’s just so much life to them, y’know?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:497
translate chinese SR3_we_IC_shop_table_romantic_con_6ef87972:

    # Lily "What do you look so anxious about?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:498
translate chinese SR3_we_IC_shop_table_romantic_con_92feef01:

    # MC "N-Nothing, I’m just in the middle of a dat-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:500
translate chinese SR3_we_IC_shop_table_romantic_con_acd96632:

    # Lily "Oh yum! I see you got yourself some of the orange ice cream - that stuff rocks!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:501
translate chinese SR3_we_IC_shop_table_romantic_con_a7c6faaa:

    # MC "It isn’t for-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:502
translate chinese SR3_we_IC_shop_table_romantic_con_69bc5fac:

    # Lily "Mind if I have a taste?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:504
translate chinese SR3_we_IC_shop_table_romantic_con_394d4835:

    # MC "That isn’t my-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:505
translate chinese SR3_we_IC_shop_table_romantic_con_29dde9d0:

    # Lily "I love having creamy ice cream melt all over my tongue. It just feels sooo... seductive, doesn’t it?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:507
translate chinese SR3_we_IC_shop_table_romantic_con_257b872f:

    # MC "Lily, I-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:508
translate chinese SR3_we_IC_shop_table_romantic_con_9e0931b2:

    # Lily "Mmm... This looks delicious. Almost as tasty as you, [player_name]."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:509
translate chinese SR3_we_IC_shop_table_romantic_con_b6829ff9:

    # MC "Lily, Sara is going to c-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:511
translate chinese SR3_we_IC_shop_table_romantic_con_6bf66cad:

    # Lily "Ahaha, you’re, like, so jittery today! Calm down! I ain’t gonna bite you."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:512
translate chinese SR3_we_IC_shop_table_romantic_con_e6ace1dd:

    # Lily "That is... unless you want me to."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:514
translate chinese SR3_we_IC_shop_table_romantic_con_ee3e6bd8:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:515
translate chinese SR3_we_IC_shop_table_romantic_con_68c3e710:

    # MC "Nooo!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:516
translate chinese SR3_we_IC_shop_table_romantic_con_6bc31c2e:

    # Lily "Mmm!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:522
translate chinese SR3_we_IC_shop_table_romantic_con_f6056235:

    # MC "Lily, stop! That’s Sara’s!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:523
translate chinese SR3_we_IC_shop_table_romantic_con_ee3e6bd8_1:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:525
translate chinese SR3_we_IC_shop_table_romantic_con_952850a0:

    # Sara "[player_name]! What the hell is SHE doing here?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:526
translate chinese SR3_we_IC_shop_table_romantic_con_36f9d869:

    # MC "Sara, I- She just came over and sat down!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:528
translate chinese SR3_we_IC_shop_table_romantic_con_04c1977e:

    # Sara "You expect me to believe that you didn't invite her over?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:529
translate chinese SR3_we_IC_shop_table_romantic_con_e153fcb6:

    # MC "I’m serious! That’s the truth!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:530
translate chinese SR3_we_IC_shop_table_romantic_con_ee3e6bd8_2:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:532
translate chinese SR3_we_IC_shop_table_romantic_con_5b2c0d49:

    # Sara "Lily! I’m on a date right now!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:533
translate chinese SR3_we_IC_shop_table_romantic_con_ee3e6bd8_3:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:534
translate chinese SR3_we_IC_shop_table_romantic_con_c8c00e24:

    # Sara "And you’re eating MY ice cream!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:536
translate chinese SR3_we_IC_shop_table_romantic_con_97e40de9:

    # Lily "Mmm! Hey, Sara! This stuff is like totes delish!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:537
translate chinese SR3_we_IC_shop_table_romantic_con_911e2132:

    # Sara "I KNOW it is! That’s why I ordered it - for ME!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:538
translate chinese SR3_we_IC_shop_table_romantic_con_ab26677b:

    # MC "O-Okay everyone, let’s all take a deep breath and-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:540
translate chinese SR3_we_IC_shop_table_romantic_con_580a0fa4:

    # Sara "I LITERALLY cannot believe this is happening right now. What the hell are you playing at, Lily?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:541
translate chinese SR3_we_IC_shop_table_romantic_con_944190d4:

    # Lily "Chill out, Sara. Join us! [player_name] will buy you another cone if you’re that desperate, won'tcha, sexy?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:543
translate chinese SR3_we_IC_shop_table_romantic_con_b8f0f91a:

    # MC "M-Me?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:544
translate chinese SR3_we_IC_shop_table_romantic_con_3488781f:

    # Sara "Don’t call him “sexy”!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:545
translate chinese SR3_we_IC_shop_table_romantic_con_cc842777:

    # Lily "Aww, c’mon Sara! Just take a seat!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:547
translate chinese SR3_we_IC_shop_table_romantic_con_d8d69dec:

    # Sara "Grrr..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:548
translate chinese SR3_we_IC_shop_table_romantic_con_0cb35e1b:

    # Lily "What’s she pouting about, [player_name]?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:549
translate chinese SR3_we_IC_shop_table_romantic_con_ed229573:

    # MC "That’s what I was trying to tell you, Lily. We’re in the middle of a date right now."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:551
translate chinese SR3_we_IC_shop_table_romantic_con_08c20d15:

    # Lily "..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:552
translate chinese SR3_we_IC_shop_table_romantic_con_925e9ca9:

    # Lily "You two are dating?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:553
translate chinese SR3_we_IC_shop_table_romantic_con_7f2f2c6e:

    # Sara "Yes."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:554
translate chinese SR3_we_IC_shop_table_romantic_con_2d44249b:

    # Lily "Like, DATING dating?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:555
translate chinese SR3_we_IC_shop_table_romantic_con_07266d13:

    # MC "Yes."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:557
translate chinese SR3_we_IC_shop_table_romantic_con_e3c42c10:

    # Lily "But isn’t he, like, your... brother?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:559
translate chinese SR3_we_IC_shop_table_romantic_con_7e0b36b6:

    # Lily "But the two of you... Also what you were saying in the past... You're a nerdy girl who did not want a boyfriend..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:560
translate chinese SR3_we_IC_shop_table_romantic_con_88eade75:

    # Sara "Yes, Lily! Will you just fucking drop it?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:562
translate chinese SR3_we_IC_shop_table_romantic_con_1290f604:

    # Lily "Woo... I really shoulda seen this coming. The dick pics, the spin-the-bottle in your bedroom."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:564
translate chinese SR3_we_IC_shop_table_romantic_con_9197c06f:

    # Lily "So... you’re brother and sister... but you’re also going on dates. In public."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:566
translate chinese SR3_we_IC_shop_table_romantic_con_127af67a:

    # Lily "So... A nerdy girl who plays games all day and a handsome man... Going on dates... Something doesn't add right here."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:568
translate chinese SR3_we_IC_shop_table_romantic_con_b9004924:

    # Lily "And all those messages you sent me about doing anal with some guy."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:569
translate chinese SR3_we_IC_shop_table_romantic_con_484b3e2f:

    # Lily "That guy was [player_name], right?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:570
translate chinese SR3_we_IC_shop_table_romantic_con_fc287995:

    # Sara "Kill me now..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:572
translate chinese SR3_we_IC_shop_table_romantic_con_bb45d3bd:

    # Lily " I’m just sayin’, people are gonna talk. This is, like, prime gossip right here."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:574
translate chinese SR3_we_IC_shop_table_romantic_con_7aac603a:

    # Lily "BREAKING NEWS! Sara the Freshman has fucked a senior who just happens to be her own brother!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:576
translate chinese SR3_we_IC_shop_table_romantic_con_92c7081b:

    # Lily "BREAKING NEWS! Sara has just fucked [player_name]!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:577
translate chinese SR3_we_IC_shop_table_romantic_con_72eb0ffe:

    # MC "Jesus Christ, Lily! Do you have to shout it so loud?!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:583
translate chinese SR3_we_IC_shop_table_romantic_con_169713da:

    # Lily "This blows last month’s goss out of the water though. What was the big one we had a month ago?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:584
translate chinese SR3_we_IC_shop_table_romantic_con_f8a12669:

    # Lily "Oh yeah! Steph and Brian ended up hooking up during their dissertation viva voces while Mrs. Robinson watched. That was like, totally funny though."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:586
translate chinese SR3_we_IC_shop_table_romantic_con_a962e166:

    # Lily "She ended up getting suspended from teaching for, like, two semesters 'cause she filmed them."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:587
translate chinese SR3_we_IC_shop_table_romantic_con_b974dc02:

    # Lily "God - I’m ALWAYS the last one to find out about the best gossip, and now, here I am, smack in the middle of it!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:589
translate chinese SR3_we_IC_shop_table_romantic_con_5720fb65:

    # Lily "Anyway, the next hot thing is going to be Iris and June. Everyone knows those two are secretly lezzing out in the college gym..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:590
translate chinese SR3_we_IC_shop_table_romantic_con_ffaea1d5:

    # MC "*Whispered* Does she ever shut up?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:591
translate chinese SR3_we_IC_shop_table_romantic_con_736a11cb:

    # Sara "*Whispered* No..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:592
translate chinese SR3_we_IC_shop_table_romantic_con_6ac81628:

    # Sara "*Whispered* She. Is. Ruining. Our. Date."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:594
translate chinese SR3_we_IC_shop_table_romantic_con_4eea6d4d:

    # MC "Listen Lily, Sara and I have some important errands to run. So we’re gonna have to leave now, okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:595
translate chinese SR3_we_IC_shop_table_romantic_con_32879ae1:

    # MC "It was nice meeting you today."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:597
translate chinese SR3_we_IC_shop_table_romantic_con_83da8682:

    # MC "Isn’t that right?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:598
translate chinese SR3_we_IC_shop_table_romantic_con_3773e743:

    # Sara "Y-Yeah, loads and loads of... stuff that we have to catch up on."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:599
translate chinese SR3_we_IC_shop_table_romantic_con_dad5ffe6:

    # MC "Oh, and I’d prefer it if you didn’t tell anyone about us yet. People can find out when we’re both ready to tell them. Okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:601
translate chinese SR3_we_IC_shop_table_romantic_con_24216838:

    # Lily "Uh huh... Mmm!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:602
translate chinese SR3_we_IC_shop_table_romantic_con_b389e824:

    # Sara "Yeah, that’s for the best, Lily."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:603
translate chinese SR3_we_IC_shop_table_romantic_con_890cbf30:

    # Sara "*Whispered* Thank you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:605
translate chinese SR3_we_IC_shop_table_romantic_con_b62dbfc7:

    # Sara "Well, bye Lily! I’ll see you in College."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:606
translate chinese SR3_we_IC_shop_table_romantic_con_035b68e2:

    # MC "Yeah, nice catching up!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:607
translate chinese SR3_we_IC_shop_table_romantic_con_8c288737:

    # Lily "Mppf! Wait-"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:609
translate chinese SR3_we_IC_shop_table_romantic_con_e94dc9cf:

    # Sara "*Whispered* C’mon, let’s go before she starts talking again."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:610
translate chinese SR3_we_IC_shop_table_romantic_con_a6914650:

    # MC "*Whispered* Yup, I agree."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:616
translate chinese SR3_we_IC_shop_table_romantic_con_800adc30:

    # Lily "Hold up one minute!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:617
translate chinese SR3_we_IC_shop_table_romantic_con_21cf1d88:

    # MC "What, Lily?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:618
translate chinese SR3_we_IC_shop_table_romantic_con_fe8af8dd:

    # Lily "I just realised I never had your number."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:620
translate chinese SR3_we_IC_shop_table_romantic_con_c3a22fa2:

    # MC "What do you want my number for?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:621
translate chinese SR3_we_IC_shop_table_romantic_con_500578a8:

    # Lily "To keep in touch, dumbo. I don’t want to have to hope I randomly bump into you in a cafe to see you again."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:627
translate chinese SR3_MC_give_phone_choice_ef16e141:

    # MC "Uh, sure. It’s 421-6870-419."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:628
translate chinese SR3_MC_give_phone_choice_d33efd67:

    # Lily "Seriously? That’s like just one digit away from being awesome at every single instance."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:629
translate chinese SR3_MC_give_phone_choice_feb8e6d0:

    # MC "I know, don’t remind me."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:630
translate chinese SR3_MC_give_phone_choice_b8d1d80b:

    # Lily "I mean, you could have had 420-6969-420. That would have been the fucking bomb!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:631
translate chinese SR3_MC_give_phone_choice_f567101b:

    # Lily "Ahaha, anyway! Enjoy your day with Sara. If you ever fancy a girl with bigger... assets, then don’t wait to get in touch."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:636
translate chinese SR3_MC_give_phone_choice_a889165e:

    # MC "Sorry, Lily. No can do."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:637
translate chinese SR3_MC_give_phone_choice_bfc4dba0:

    # Lily "Aww, pleeease?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:639
translate chinese SR3_MC_give_phone_choice_1ccba1f2:

    # MC "Nope. Sara wouldn’t like it."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:640
translate chinese SR3_MC_give_phone_choice_321bb642:

    # Lily "Hmmph..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:648
translate chinese SR3_we_IC_shop_table_not_romantic_con_64fb9489:

    # MC "That’s a very nice dress you’re wearing, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:649
translate chinese SR3_we_IC_shop_table_not_romantic_con_91bc7808:

    # Sara "Thanks, [player_name]. I picked it up especially just for our dat-"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:650
translate chinese SR3_we_IC_shop_table_not_romantic_con_5a5d0352:

    # Sara "I mean, just for our day out."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:651
translate chinese SR3_we_IC_shop_table_not_romantic_con_802bf871:

    # MC "*Whispered* You look really hot, but maybe next time we should keep the sexy outfits for inside the house? I don’t want people getting the impression that we’re a romantic couple."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:652
translate chinese SR3_we_IC_shop_table_not_romantic_con_8fcde146:

    # Sara "*Sigh* Ugh, fine..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:653
translate chinese SR3_we_IC_shop_table_not_romantic_con_af71877d:

    # MC "Besides, what if your dress slips or something? You could expose yourself to the whole store."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:654
translate chinese SR3_we_IC_shop_table_not_romantic_con_460c6a5d:

    # Sara "Haha, it’s not gonna slip. I’m not some clutz!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:660
translate chinese SR3_we_IC_shop_table_not_romantic_con_95d7bf93:

    # Salesman "And here’s your order. We have: one juicy orange, one mint supreme, and one fruity deluxe with watermelon and strawberry."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:661
translate chinese SR3_we_IC_shop_table_not_romantic_con_73ae15ad:

    # Salesman "Enjoy your meal, and may I add, you two make an adorable couple."
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:662
translate chinese SR3_we_IC_shop_table_not_romantic_con_cb83a1c0:

    # Sara "Aww, thank you! Did you hear that, [player_name]?! Eeeek!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:664
translate chinese SR3_we_IC_shop_table_not_romantic_con_320c3a26:

    # MC "I, uh... we’re not a couple! She’s my sister."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:666
translate chinese SR3_we_IC_shop_table_not_romantic_con_7405c985:

    # MC "I, uh- we’re not a couple! She’s just a friend."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:667
translate chinese SR3_we_IC_shop_table_not_romantic_con_2caba57f:

    # Salesman "Oh! My apologies, sir!"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:669
translate chinese SR3_we_IC_shop_table_not_romantic_con_689fbdfe:

    # Sara "OMG OMG OMG! Which one should I try first?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:670
translate chinese SR3_we_IC_shop_table_not_romantic_con_61dfce2a:

    # MC "Go for the mint. It’s the one you’ve been raving about all day!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:671
translate chinese SR3_we_IC_shop_table_not_romantic_con_4dae4316:

    # Sara "I’m so excited!!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:673
translate chinese SR3_we_IC_shop_table_not_romantic_con_2941efe8:

    # Sara "Thanks again for coming to the mall with me today, [player_name]. I know you’re worried about people finding out about us, so I appreciate you taking a bit of a risk - even if it’s just a secret date today."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:675
translate chinese SR3_we_IC_shop_table_not_romantic_con_675d1e11:

    # MC "Listen, even if this wasn’t a date, Sara, I’d still be coming out here with you. You’re my sister, after all, and I love spending time with you."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:677
translate chinese SR3_we_IC_shop_table_not_romantic_con_0eabe7a7:

    # MC "Listen, even if this wasn't a date, Sara. I'd still be coming out here with you. I love spending time with you cutie!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:678
translate chinese SR3_we_IC_shop_table_not_romantic_con_ddc98266:

    # Sara "Thanks. I really enjoy spending time with you too."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:679
translate chinese SR3_we_IC_shop_table_not_romantic_con_2033f6dd:

    # Sara "*Whispered* I just wish we could be open about what we actually are, y’know?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:681
translate chinese SR3_we_IC_shop_table_not_romantic_con_112d8a99:

    # MC "*Whispered* I know, I just don’t know when that could possibly happen. Maybe when we both finish college?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:682
translate chinese SR3_we_IC_shop_table_not_romantic_con_a334b46d:

    # MC "I mean, at least then we won’t have to spend all day around people who might bully or mock us for being together."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:684
translate chinese SR3_we_IC_shop_table_not_romantic_con_2fb5539a:

    # MC "But, I am enjoying today so far, Sara."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:685
translate chinese SR3_we_IC_shop_table_not_romantic_con_4658e62d:

    # MC "And I really enjoyed the time we spent over the past few weeks. I’ve loved playing strip-video games with you, and I really love the time we spent on the roof of the house."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:686
translate chinese SR3_we_IC_shop_table_not_romantic_con_3c8f3c6f:

    # Sara "Haha, I still shiver when I think about the roof."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:688
translate chinese SR3_we_IC_shop_table_not_romantic_con_70e1e372:

    # Sara "*Whispered* We are NEVER doing anal without lube again. Haha!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:689
translate chinese SR3_we_IC_shop_table_not_romantic_con_05fb6869:

    # MC "Haha! Sorry..."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:691
translate chinese SR3_we_IC_shop_table_not_romantic_con_afc18413:

    # MC "*Whispered* I love you, Sara, but I’ve already destroyed my reputation at college, after the incident with Ms. Celia."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:693
translate chinese SR3_we_IC_shop_table_not_romantic_con_c730b8d8:

    # MC "*Whispered* Can you imagine what would happen if they also discovered I was dating my sister? My reputation would never recover."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:695
translate chinese SR3_we_IC_shop_table_not_romantic_con_f4694aef:

    # MC "*Whispered* I even had to talk with the college therapist. My reputation would never recover."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:696
translate chinese SR3_we_IC_shop_table_not_romantic_con_8449c9b7:

    # Sara "I get it, don’t worry. You don’t need to keep explaining yourself."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:698
translate chinese SR3_we_IC_shop_table_not_romantic_con_1f793de6:

    # Sara "Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:699
translate chinese SR3_we_IC_shop_table_not_romantic_con_89b34e10:

    # MC "Is the ice cream as good as you remember?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:700
translate chinese SR3_we_IC_shop_table_not_romantic_con_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:702
translate chinese SR3_we_IC_shop_table_not_romantic_con_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:703
translate chinese SR3_we_IC_shop_table_not_romantic_con_38950a0c:

    # MC "(This is actually pretty tasty stuff!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:705
translate chinese SR3_we_IC_shop_table_not_romantic_con_e6bd62e4:

    # MC "So, is there anything else you want to add to the agenda today? Or was getting Thick n’ Creamy ice cream your top priority?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:706
translate chinese SR3_we_IC_shop_table_not_romantic_con_5f02954d:

    # MC "Not that I’m complaining. This stuff is spectacular!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:708
translate chinese SR3_we_IC_shop_table_not_romantic_con_06a98373:

    # Sara "Hehe, how about we take a walk around the mall together after this?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:709
translate chinese SR3_we_IC_shop_table_not_romantic_con_9ee883e5:

    # Sara "You might be able to help me pick out another new outfit."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:710
translate chinese SR3_we_IC_shop_table_not_romantic_con_381af76c:

    # MC "Oooh, I like the sound of that."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:711
translate chinese SR3_we_IC_shop_table_not_romantic_con_443cc57f:

    # Sara "*Whispered* And then, maybe later on tonight I can..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:713
translate chinese SR3_we_IC_shop_table_not_romantic_con_1dd292c8:

    # Sara "*Lick* *Lick*"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:714
translate chinese SR3_we_IC_shop_table_not_romantic_con_c95260e4:

    # MC "Mmm... I’m really looking forward to tonight now."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:716
translate chinese SR3_we_IC_shop_table_not_romantic_con_f2588f1b:

    # Sara "Hehe! Today’s been really nice so far, [player_name]. Thank you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:717
translate chinese SR3_we_IC_shop_table_not_romantic_con_f46c489a:

    # MC "It's far from over, Sara. And there's no reason why we can't go out again next week or the week after that. We're both adults and we've got our whole lives ahead of us."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:718
translate chinese SR3_we_IC_shop_table_not_romantic_con_0886ded6:

    # Sara "*Whispered* And maybe we can start being a little more open about you being my boyfriend?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:720
translate chinese SR3_we_IC_shop_table_not_romantic_con_3015b766:

    # MC "Maybe. We’ll see how things go."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:721
translate chinese SR3_we_IC_shop_table_not_romantic_con_c6bc6dd0:

    # Sara "How about we do the Zoo or something next week?"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:722
translate chinese SR3_we_IC_shop_table_not_romantic_con_eeb23deb:

    # MC "Zoo is good. Or the cinema?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:723
translate chinese SR3_we_IC_shop_table_not_romantic_con_7189bfda:

    # Sara "Cinema works for me!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:724
translate chinese SR3_we_IC_shop_table_not_romantic_con_0e568aac:

    # Sara "*Whispered* It means I can cuddle you when it’s dark and nobody can see us.)"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:726
translate chinese SR3_we_IC_shop_table_not_romantic_con_1f793de6_1:

    # Sara "Mmm!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:727
translate chinese SR3_we_IC_shop_table_not_romantic_con_0735191e:

    # MC "I’ll check what’s on. There’s a few good movies coming out this summer."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:729
translate chinese SR3_we_IC_shop_table_not_romantic_con_3fd64def:

    # Sara "Sounds good to me!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:730
translate chinese SR3_we_IC_shop_table_not_romantic_con_c8892ef6:

    # Sara "Mmm! That was delicious."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:736
translate chinese SR3_we_IC_shop_table_not_romantic_con_69b3b9c4:

    # Sara "Listen, I’m just gonna run to the bathroom here. I’ll just be two minutes."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:737
translate chinese SR3_we_IC_shop_table_not_romantic_con_0a1f0000:

    # Sara "Don’t you DARE touch my orange ice cream when I’m gone!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:739
translate chinese SR3_we_IC_shop_table_not_romantic_con_59918bf7:

    # MC "Haha, I wouldn’t dream of it."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:740
translate chinese SR3_we_IC_shop_table_not_romantic_con_58197fe1:

    # MC "See you in a bit!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:742
translate chinese SR3_we_IC_shop_table_not_romantic_con_e9971667:

    # MC "(Damn, she looks good in that short dress. I’m one lucky-ass guy to be dating her.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:743
translate chinese SR3_we_IC_shop_table_not_romantic_con_63df96b1:

    # MC "(I wonder if there are any lingerie stores in the mall. I could buy her something sexy to wear tonight whenever we’re-)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:745
translate chinese SR3_we_IC_shop_table_not_romantic_con_5048aab4:

    # Sara "Whoa!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:746
translate chinese SR3_we_IC_shop_table_not_romantic_con_ec0e4e85:

    # MC "Huh? Watch out!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:750
translate chinese SR3_we_IC_shop_table_not_romantic_con_0d528bf6:

    # Sara "Ooof!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:751
translate chinese SR3_we_IC_shop_table_not_romantic_con_120152c4:

    # MC "Christ! Are you okay, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:752
translate chinese SR3_we_IC_shop_table_not_romantic_con_7f28d65c:

    # Sara "Ugh... yeah, all good..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:754
translate chinese SR3_we_IC_shop_table_not_romantic_con_33f80530:

    # Sara "I just slipped on a wet patch."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:755
translate chinese SR3_we_IC_shop_table_not_romantic_con_666b86bd:

    # MC "Heh, I saw. Do you need a hand?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:756
translate chinese SR3_we_IC_shop_table_not_romantic_con_94ee517d:

    # Sara "No, all... good."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:758
translate chinese SR3_we_IC_shop_table_not_romantic_con_2f74602f:

    # MC "(So much for not being a clutz...)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:759
translate chinese SR3_we_IC_shop_table_not_romantic_con_6ec9ced6:

    # MC "(Now half the restaurant has seen up your skirt!)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:761
translate chinese SR3_we_IC_shop_table_not_romantic_con_d515be2d:

    # Salesman "May I give you a hand up, madam?"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:762
translate chinese SR3_we_IC_shop_table_not_romantic_con_2f6f17e4:

    # Sara "Don’t worry, I’ve got it."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:763
translate chinese SR3_we_IC_shop_table_not_romantic_con_458e9acc:

    # Salesman "(Oooh, it looks like her dress has slipped. It’s my lucky day!)"
    Salesman ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:765
translate chinese SR3_we_IC_shop_table_not_romantic_con_28c5937c:

    # MC "(Damn that ice cream looks good.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:766
translate chinese SR3_we_IC_shop_table_not_romantic_con_37eae670:

    # MC "(Would Sara notice if I took a couple of licks out of it?)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:768
translate chinese SR3_we_IC_shop_table_not_romantic_con_b225b01b:

    # MC "(Eh, probably not. Besides, I could always buy her another for when she gets back.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:769
translate chinese SR3_we_IC_shop_table_not_romantic_con_d27920cf:

    # MC "(Yeah, Sara’s not going to mind.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:775
translate chinese SR3_we_IC_shop_table_not_romantic_con_1901c6ca:

    # Lily2 "Boo! Guess who!"
    Lily2 ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:776
translate chinese SR3_we_IC_shop_table_not_romantic_con_2e0cd453:

    # MC "Uhh, Sara?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:777
translate chinese SR3_we_IC_shop_table_not_romantic_con_c0824e49:

    # Lily2 "Wrong! Ahaha!"
    Lily2 ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:779
translate chinese SR3_we_IC_shop_table_not_romantic_con_99be63ab:

    # MC "C-Caroline?!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:780
translate chinese SR3_we_IC_shop_table_not_romantic_con_e812d8db:

    # Lily2 "What?! No! It’s me, silly!"
    Lily2 ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:782
translate chinese SR3_we_IC_shop_table_not_romantic_con_a62ff004:

    # MC "L-Lily! What are you doing here?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:783
translate chinese SR3_we_IC_shop_table_not_romantic_con_05811073:

    # Lily "The same thing everyone else is doing here, dumbo! Checking out the new mall! This place is huuuuuge, isn’t it?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:784
translate chinese SR3_we_IC_shop_table_not_romantic_con_282ca265:

    # MC "Uh, y-yeah! It is. What are you..."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:786
translate chinese SR3_we_IC_shop_table_not_romantic_con_4a3a95a7:

    # Lily "I was feeling so hot. I decided to swing by this place to cool down."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:787
translate chinese SR3_we_IC_shop_table_not_romantic_con_325ac037:

    # MC "Yeah, it’s pretty... pretty warm out there today."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:793
translate chinese SR3_we_IC_shop_table_not_romantic_con_f7ad5eef:

    # Lily "Do you think I look hot?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:794
translate chinese SR3_we_IC_shop_table_not_romantic_con_7ce8e58b:

    # MC "Yes - I mean, no- I mean... you should probably get an ice cream to cool down."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:795
translate chinese SR3_we_IC_shop_table_not_romantic_con_e8ab94f1:

    # Lily "Ahaha, I agree."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:797
translate chinese SR3_we_IC_shop_table_not_romantic_con_deb014ad:

    # Lily "I really can't believe how many people showed up today. Like, my entire college class is here! Can you believe it?!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:798
translate chinese SR3_we_IC_shop_table_not_romantic_con_4d33eba8:

    # Lily "People keep saying online shopping is gonna, like, kill malls and stuff, but I think people still love walking around these places. There’s just so much life to them, y’know?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:800
translate chinese SR3_we_IC_shop_table_not_romantic_con_6ef87972:

    # Lily "What do you look so anxious about?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:801
translate chinese SR3_we_IC_shop_table_not_romantic_con_fc7ea83d:

    # MC "N-Nothing, I’m just in the middle of a dat- I mean, just hanging out with Sar-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:803
translate chinese SR3_we_IC_shop_table_not_romantic_con_acd96632:

    # Lily "Oh yum! I see you got yourself some of the orange ice cream - that stuff rocks!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:804
translate chinese SR3_we_IC_shop_table_not_romantic_con_a7c6faaa:

    # MC "It isn’t for-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:805
translate chinese SR3_we_IC_shop_table_not_romantic_con_69bc5fac:

    # Lily "Mind if I have a taste?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:807
translate chinese SR3_we_IC_shop_table_not_romantic_con_394d4835:

    # MC "That isn’t my-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:808
translate chinese SR3_we_IC_shop_table_not_romantic_con_a59c92e5:

    # Lily "I love having creamy ice cream melt all over my tongue. The sensation of it trickling across the back of your tongue and down your throat is just soooo... seductive, isn’t it?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:810
translate chinese SR3_we_IC_shop_table_not_romantic_con_257b872f:

    # MC "Lily, I-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:811
translate chinese SR3_we_IC_shop_table_not_romantic_con_9e0931b2:

    # Lily "Mmm... This looks delicious. Almost as tasty as you, [player_name]."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:812
translate chinese SR3_we_IC_shop_table_not_romantic_con_b6829ff9:

    # MC "Lily, Sara is going to c-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:814
translate chinese SR3_we_IC_shop_table_not_romantic_con_6bf66cad:

    # Lily "Ahaha, you’re, like, so jittery today! Calm down! I ain’t gonna bite you."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:815
translate chinese SR3_we_IC_shop_table_not_romantic_con_e6ace1dd:

    # Lily "That is... unless you want me to."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:817
translate chinese SR3_we_IC_shop_table_not_romantic_con_ee3e6bd8:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:818
translate chinese SR3_we_IC_shop_table_not_romantic_con_68c3e710:

    # MC "Nooo!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:819
translate chinese SR3_we_IC_shop_table_not_romantic_con_6bc31c2e:

    # Lily "Mmm!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:825
translate chinese SR3_we_IC_shop_table_not_romantic_con_f6056235:

    # MC "Lily, stop! That’s Sara’s!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:826
translate chinese SR3_we_IC_shop_table_not_romantic_con_ee3e6bd8_1:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:828
translate chinese SR3_we_IC_shop_table_not_romantic_con_952850a0:

    # Sara "[player_name]! What the hell is SHE doing here?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:829
translate chinese SR3_we_IC_shop_table_not_romantic_con_36f9d869:

    # MC "Sara, I- She just came over and sat down!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:831
translate chinese SR3_we_IC_shop_table_not_romantic_con_04c1977e:

    # Sara "You expect me to believe that you didn't invite her over?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:832
translate chinese SR3_we_IC_shop_table_not_romantic_con_e153fcb6:

    # MC "I’m serious! That’s the truth!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:833
translate chinese SR3_we_IC_shop_table_not_romantic_con_ee3e6bd8_2:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:835
translate chinese SR3_we_IC_shop_table_not_romantic_con_5b2c0d49:

    # Sara "Lily! I’m on a date right now!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:836
translate chinese SR3_we_IC_shop_table_not_romantic_con_4e2954ad:

    # MC "*Whispered* S-Sara! Keep your voice down!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:837
translate chinese SR3_we_IC_shop_table_not_romantic_con_ee3e6bd8_3:

    # Lily "*Lick*"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:838
translate chinese SR3_we_IC_shop_table_not_romantic_con_8afa98da:

    # Sara "Don’t tell me to be quiet! This bitch is eating my ice cream!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:840
translate chinese SR3_we_IC_shop_table_not_romantic_con_97e40de9:

    # Lily "Mmm! Hey, Sara! This stuff is like totes delish!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:841
translate chinese SR3_we_IC_shop_table_not_romantic_con_911e2132:

    # Sara "I KNOW it is! That’s why I ordered it - for ME!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:842
translate chinese SR3_we_IC_shop_table_not_romantic_con_ab26677b:

    # MC "O-Okay everyone, let’s all take a deep breath and-"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:844
translate chinese SR3_we_IC_shop_table_not_romantic_con_580a0fa4:

    # Sara "I LITERALLY cannot believe this is happening right now. What the hell are you playing at, Lily?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:845
translate chinese SR3_we_IC_shop_table_not_romantic_con_944190d4:

    # Lily "Chill out, Sara. Join us! [player_name] will buy you another cone if you’re that desperate, won'tcha, sexy?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:847
translate chinese SR3_we_IC_shop_table_not_romantic_con_b8f0f91a:

    # MC "M-Me?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:848
translate chinese SR3_we_IC_shop_table_not_romantic_con_3488781f:

    # Sara "Don’t call him “sexy”!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:849
translate chinese SR3_we_IC_shop_table_not_romantic_con_cc842777:

    # Lily "Aww, c’mon Sara! Just take a seat!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:851
translate chinese SR3_we_IC_shop_table_not_romantic_con_d8d69dec:

    # Sara "Grrr..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:852
translate chinese SR3_we_IC_shop_table_not_romantic_con_0cb35e1b:

    # Lily "What’s she pouting about, [player_name]?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:853
translate chinese SR3_we_IC_shop_table_not_romantic_con_3ea1f722:

    # MC "That’s what I was trying to tell you, Lily. We’re in the middle of a da- a... a day out together."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:855
translate chinese SR3_we_IC_shop_table_not_romantic_con_08c20d15:

    # Lily "..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:856
translate chinese SR3_we_IC_shop_table_not_romantic_con_d2661337:

    # Lily "Are you two dating?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:857
translate chinese SR3_we_IC_shop_table_not_romantic_con_cea225ce:

    # MC "N-No!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:858
translate chinese SR3_we_IC_shop_table_not_romantic_con_7f2f2c6e:

    # Sara "Yes."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:859
translate chinese SR3_we_IC_shop_table_not_romantic_con_b255c664:

    # MC "(Oh shit, Sara’s glaring hard at me right now.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:861
translate chinese SR3_we_IC_shop_table_not_romantic_con_d86cbaa4:

    # Lily "Wooo... Awkward turtle! Haha..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:862
translate chinese SR3_we_IC_shop_table_not_romantic_con_67a1d61d:

    # Lily "*Whispered* Yikes..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:863
translate chinese SR3_we_IC_shop_table_not_romantic_con_90a9582f:

    # Sara "[player_name] and I are dating, Lily. So, just for your information, he is taken."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:865
translate chinese SR3_we_IC_shop_table_not_romantic_con_e3c42c10:

    # Lily "But isn’t he, like, your... brother?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:867
translate chinese SR3_we_IC_shop_table_not_romantic_con_7e0b36b6:

    # Lily "But the two of you... Also what you were saying in the past... You're a nerdy girl who did not want a boyfriend..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:868
translate chinese SR3_we_IC_shop_table_not_romantic_con_88eade75:

    # Sara "Yes, Lily! Will you just fucking drop it?!"
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:869
translate chinese SR3_we_IC_shop_table_not_romantic_con_1290f604:

    # Lily "Woo... I really shoulda seen this coming. The dick pics, the spin-the-bottle in your bedroom."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:871
translate chinese SR3_we_IC_shop_table_not_romantic_con_9197c06f:

    # Lily "So... you’re brother and sister... but you’re also going on dates. In public."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:873
translate chinese SR3_we_IC_shop_table_not_romantic_con_127af67a:

    # Lily "So... A nerdy girl who plays games all day and a handsome man... Going on dates... Something doesn't add right here."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:874
translate chinese SR3_we_IC_shop_table_not_romantic_con_a9fcc4f1:

    # MC "It was supposed to be secret, before you came along."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:876
translate chinese SR3_we_IC_shop_table_not_romantic_con_6b60508f:

    # Lily "And all those messages you sent me about trying anal with some guy."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:877
translate chinese SR3_we_IC_shop_table_not_romantic_con_484b3e2f:

    # Lily "That guy was [player_name], right?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:878
translate chinese SR3_we_IC_shop_table_not_romantic_con_bc6e53f0:

    # MC "*Groan*"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:879
translate chinese SR3_we_IC_shop_table_not_romantic_con_a651132b:

    # Lily "Did you cum in her bum, [player_name]?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:880
translate chinese SR3_we_IC_shop_table_not_romantic_con_fc287995:

    # Sara "Kill me now..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:882
translate chinese SR3_we_IC_shop_table_not_romantic_con_08481638:

    # Lily "I’m just sayin’, people are gonna talk. This is, like, prime gossip right here."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:884
translate chinese SR3_we_IC_shop_table_not_romantic_con_7aac603a:

    # Lily "BREAKING NEWS! Sara the Freshman has fucked a senior who just happens to be her own brother!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:886
translate chinese SR3_we_IC_shop_table_not_romantic_con_ffd8b2b8:

    # Lily "BREAKING NEWS! Sara has fucked [player_name]!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:887
translate chinese SR3_we_IC_shop_table_not_romantic_con_72eb0ffe:

    # MC "Jesus Christ, Lily! Do you have to shout it so loud?!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:893
translate chinese SR3_we_IC_shop_table_not_romantic_con_169713da:

    # Lily "This blows last month’s goss out of the water though. What was the big one we had a month ago?"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:894
translate chinese SR3_we_IC_shop_table_not_romantic_con_f8a12669:

    # Lily "Oh yeah! Steph and Brian ended up hooking up during their dissertation viva voces while Mrs. Robinson watched. That was like, totally funny though."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:896
translate chinese SR3_we_IC_shop_table_not_romantic_con_a962e166:

    # Lily "She ended up getting suspended from teaching for, like, two semesters 'cause she filmed them."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:897
translate chinese SR3_we_IC_shop_table_not_romantic_con_b974dc02:

    # Lily "God - I’m ALWAYS the last one to find out about the best gossip, and now, here I am, smack in the middle of it!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:899
translate chinese SR3_we_IC_shop_table_not_romantic_con_16bf4039:

    # Lily "Anyway, the next hot thing is going to be Iris and June. Everyone knows those two are secretly lezzing out in the changing rooms in the college gym..."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:900
translate chinese SR3_we_IC_shop_table_not_romantic_con_ffaea1d5:

    # MC "*Whispered* Does she ever shut up?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:901
translate chinese SR3_we_IC_shop_table_not_romantic_con_736a11cb:

    # Sara "*Whispered* No..."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:902
translate chinese SR3_we_IC_shop_table_not_romantic_con_6ac81628:

    # Sara "*Whispered* She. Is. Ruining. Our. Date."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:904
translate chinese SR3_we_IC_shop_table_not_romantic_con_4eea6d4d:

    # MC "Listen Lily, Sara and I have some important errands to run. So we’re gonna have to leave now, okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:905
translate chinese SR3_we_IC_shop_table_not_romantic_con_32879ae1:

    # MC "It was nice meeting you today."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:907
translate chinese SR3_we_IC_shop_table_not_romantic_con_83da8682:

    # MC "Isn’t that right?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:908
translate chinese SR3_we_IC_shop_table_not_romantic_con_3773e743:

    # Sara "Y-Yeah, loads and loads of... stuff that we have to catch up on."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:909
translate chinese SR3_we_IC_shop_table_not_romantic_con_dad5ffe6:

    # MC "Oh, and I’d prefer it if you didn’t tell anyone about us yet. People can find out when we’re both ready to tell them. Okay?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:911
translate chinese SR3_we_IC_shop_table_not_romantic_con_24216838:

    # Lily "Uh huh... Mmm!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:912
translate chinese SR3_we_IC_shop_table_not_romantic_con_b389e824:

    # Sara "Yeah, that’s for the best, Lily."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:913
translate chinese SR3_we_IC_shop_table_not_romantic_con_890cbf30:

    # Sara "*Whispered* Thank you."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:915
translate chinese SR3_we_IC_shop_table_not_romantic_con_7fb7149f:

    # Sara "Well, bye Lily! I’ll see you in college."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:916
translate chinese SR3_we_IC_shop_table_not_romantic_con_035b68e2:

    # MC "Yeah, nice catching up!"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:917
translate chinese SR3_we_IC_shop_table_not_romantic_con_8c288737:

    # Lily "Mppf! Wait-"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:919
translate chinese SR3_we_IC_shop_table_not_romantic_con_e94dc9cf:

    # Sara "*Whispered* C’mon, let’s go before she starts talking again."
    Sara ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:920
translate chinese SR3_we_IC_shop_table_not_romantic_con_a6914650:

    # MC "*Whispered* Yup, I agree."
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:926
translate chinese SR3_we_IC_shop_table_not_romantic_con_800adc30:

    # Lily "Hold up one minute!"
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:927
translate chinese SR3_we_IC_shop_table_not_romantic_con_21cf1d88:

    # MC "What, Lily?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:928
translate chinese SR3_we_IC_shop_table_not_romantic_con_fe8af8dd:

    # Lily "I just realised I never had your number."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:930
translate chinese SR3_we_IC_shop_table_not_romantic_con_c3a22fa2:

    # MC "What do you want my number for?"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:931
translate chinese SR3_we_IC_shop_table_not_romantic_con_500578a8:

    # Lily "To keep in touch, dumbo. I don’t want to have to hope I randomly bump into you in a cafe to see you again."
    Lily ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:954
translate chinese SR3_home_end_entrace_dialogue_e9b0014a:

    # MC "(I should talk to Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:964
translate chinese SR3_home_end_corridor_dialogue_4f562a21:

    # MC "(It's time to go back to Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:966
translate chinese SR3_home_end_corridor_dialogue_eb4fa794:

    # MC "(Now, It's time to clean myself.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:968
translate chinese SR3_home_end_corridor_dialogue_e9b0014a:

    # MC "(I should talk to Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:980
translate chinese SR3_home_end_living_dialogue_eb4fa794:

    # MC "(Now, It's time to clean myself.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:982
translate chinese SR3_home_end_living_dialogue_4f562a21:

    # MC "(It's time to go back to Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:992
translate chinese SR3_home_end_kitchen_dialogue_eb4fa794:

    # MC "(Now, It's time to clean myself.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:994
translate chinese SR3_home_end_kitchen_dialogue_4f562a21:

    # MC "(It's time to go back to Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:1004
translate chinese SR3_home_end_clean_4f562a21:

    # MC "(It's time to go back to Sara.)"
    MC ""

# game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:1012
translate chinese SR3_home_end_clean_060560ec:

    # "Five minutes later."
    ""

translate chinese strings:

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:232
    old "How are your grades doing now?"
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:232
    old "Do you miss hanging out here with Caroline?"
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:232
    old "How long did [Mom_name] ground you for?"
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:288
    old "How have you and [Mom_name] been getting on?"
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:288
    old "*Whispered* I know it’s a touchy subject, but can you understand why we can’t make this a proper date?"
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:288
    old "How’s the gaming going?"
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:624
    old "Give Lily your phone number."
    new ""

    # game/scripts/weekend_events/Sara/R3/5_SR3_we_IC.rpy:624
    old "Don’t give Lily your phone number."
    new ""

