﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:53
translate chinese Ci_S5_lab_360a3024:

    # MC "Hey, Cindy. How are you keeping?"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:54
translate chinese Ci_S5_lab_175cd5da:

    # MC "(I wonder where she stores all those lollies. She seems to have an unlimited supply of the damn things!)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:57
translate chinese Ci_S5_lab_69c87f55:

    # Cindy "*Suck Suck*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:58
translate chinese Ci_S5_lab_982463f2:

    # Cindy "(Hmm, this could be my chance to escape...)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:61
translate chinese Ci_S5_lab_3c1bcb2a:

    # Cindy "Hey there, baby. I’m kinda stuck back here. Feeling a bit shit - not gonna lie."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:62
translate chinese Ci_S5_lab_8cf89007:

    # MC "How’s the cheek?"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:63
translate chinese Ci_S5_lab_86aa5e75:

    # Cindy "I owe the Boss $1000 for the pink box of joints YOU stole. The cheek he slapped, isn’t my biggest concern right now."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:64
translate chinese Ci_S5_lab_1e07e848:

    # MC "WHAT?! You’re STILL blaming me for that?!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:67
translate chinese Ci_S5_lab_f9af95f7:

    # Cindy "Hehe, I’m just teasing you, baby. I’ve cooled off. It was my fault."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:68
translate chinese Ci_S5_lab_afed1742:

    # Cindy "Say, how do you fancy a blowjob? Only $1000."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:69
translate chinese Ci_S5_lab_9fdfc967:

    # MC "WHAT?! For that price I’d expect a glass of champagne to sip, while you’re sucking me off."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:70
translate chinese Ci_S5_lab_b57c9412:

    # Cindy "Meh. No grand, no blowjob. It’s the only way I’m getting out of here, baby."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:75
translate chinese Ci_S5_lab_f1f5c1ab:

    # MC "That’s far too expensive. No thanks, Cindy."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:76
translate chinese Ci_S5_lab_a9b679c6:

    # Cindy "B-But..."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:77
translate chinese Ci_S5_lab_46aedb79:

    # MC "Bye, Cindy!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:78
translate chinese Ci_S5_lab_0c75d12a:

    # Cindy "(Dammit! Now the only way I’m getting out of here is to have the boss screw me without a condom! I HATE getting creampied!)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:88
translate chinese Ci_S5_lab_d4155e85:

    # MC "I don’t have $1000 on me right now. Can I bring it later?"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:89
translate chinese Ci_S5_lab_38c7aaf3:

    # Cindy "Sure, baby. Don’t keep me waiting too long. I’ll just keep practicing on my lollipop."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:90
translate chinese Ci_S5_lab_798a3374:

    # MC "I’m looking forward to it! Catch you later, Cindy."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:103
translate chinese Ci_S5_lab_903a2cfd:

    # MC "Here you go! It’s a deal!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:104
translate chinese Ci_S5_lab_421d1c35:

    # Cindy "Ka-ching, baby!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:105
translate chinese Ci_S5_lab_64d79c7d:

    # MC "I’m expecting the best damn blowjob of my life, right now."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:108
translate chinese Ci_S5_lab_c9c3acb1:

    # Cindy "Well, I hope I can live up to your expectations, baby."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:109
translate chinese Ci_S5_lab_0d2b812f:

    # Cindy "Want me to lose my top?"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:110
translate chinese Ci_S5_lab_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:120
translate chinese Ci_S5_lab_676c0b15:

    # MC "Oh wow, you’re REALLY toned!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:121
translate chinese Ci_S5_lab_1dba80d7:

    # Cindy "I’d give credit to my workout regime... but it’s probably just my insanely high metabolism - on account of all the cocaine I take..."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:122
translate chinese Ci_S5_lab_a3a9cdae:

    # MC "(Yikes...)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:125
translate chinese Ci_S5_lab_bd38a975:

    # Cindy "You’ve got a really big dick, baby!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:126
translate chinese Ci_S5_lab_55af7f9b:

    # Cindy "I can’t wait to make you squirm, as I suck your balls dry!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:129
translate chinese Ci_S5_lab_bad30dfe:

    # Cindy "Mmm... *Suck Suck*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:130
translate chinese Ci_S5_lab_7c6bc164:

    # MC "Oh God... Yes... Ahh..."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:131
translate chinese Ci_S5_lab_129f1775:

    # MC "(It feels so good when she’s sucking my balls like that.)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:134
translate chinese Ci_S5_lab_326725ce:

    # Cindy "*Suuuuccck*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:136
translate chinese Ci_S5_lab_6e408f5a:

    # MC "Ahhh... Mmm!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:139
translate chinese Ci_S5_lab_c5763b10:

    # MC "(Mmm, she’s really good at this! I’m starting to feel a little less stung, on dropping a grand for this...)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:140
translate chinese Ci_S5_lab_21e9ec0c:

    # Cindy "*Shluurrrrp*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:143
translate chinese Ci_S5_lab_92808095:

    # MC "Oh yeah... Just like that, Cindy. Mmm!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:144
translate chinese Ci_S5_lab_69c87f55_1:

    # Cindy "*Suck Suck*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:145
translate chinese Ci_S5_lab_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:148
translate chinese Ci_S5_lab_bd4bfda4:

    # Cindy "Hehe, you’re really hard, baby!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:149
translate chinese Ci_S5_lab_a30f1362:

    # Cindy "Let’s get your cock in my mouth now. I want to feel your shaft slipping down my throat."
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:152
translate chinese Ci_S5_lab_82c227b8:

    # Cindy "*Suck*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:154
translate chinese Ci_S5_lab_e33637c2:

    # MC "Mmm! Holy fuck..."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:156
translate chinese Ci_S5_lab_026f2ea1:

    # MC "(Her mouth is so warm and wet!)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:159
translate chinese Ci_S5_lab_9995a02b:

    # MC "(I’ve paid so much, I think I have a right to a little more than just some head bobbing.)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:161
translate chinese Ci_S5_lab_a2d3e897:

    # Cindy "Nmmpff?!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:162
translate chinese Ci_S5_lab_1706e5f1:

    # MC "I hope you’ve done deepthroat before, Cindy."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:165
translate chinese Ci_S5_lab_f6718cd2:

    # Cindy "*SHLUURRRRP* *GAG*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:166
translate chinese Ci_S5_lab_9cef31ad:

    # MC "Ohhh fuuuuck! Ahhh!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:167
translate chinese Ci_S5_lab_1e73f88a:

    # Cindy "*SPLUTTER*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:170
translate chinese Ci_S5_lab_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:171
translate chinese Ci_S5_lab_fa58f707:

    # Cindy "*GAG* *SUUUCCCK*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:173
translate chinese Ci_S5_lab_2bcacb07:

    # MC "Ahhh... Yes!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:176
translate chinese Ci_S5_lab_cc34414f:

    # MC "Okay, time to actually begin!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:177
translate chinese Ci_S5_lab_974f7560:

    # Cindy "(Wait - he hadn’t started yet?!)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:178
translate chinese Ci_S5_lab_1d317a43:

    # MC "I’m gonna facefuck you, so hard!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:181
translate chinese Ci_S5_lab_103bca38:

    # Cindy "Hmmpff?!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:182
translate chinese Ci_S5_lab_b7649f44:

    # MC "Hnnnnggg..."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:183
translate chinese Ci_S5_lab_6cea4327:

    # Cindy "(Uh oh.)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:186
translate chinese Ci_S5_lab_ec68725e:

    # Cindy "*SHLUUURRRRRP*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:187
translate chinese Ci_S5_lab_5157a423:

    # MC "HNNNNGGGG! Oh YES!!!!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:188
translate chinese Ci_S5_lab_fed2e88f:

    # MC "Holy fuck! Ahhh!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:191
translate chinese Ci_S5_lab_0b6a6942:

    # Cindy "*SHLURP SUCK SHLURP*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:192
translate chinese Ci_S5_lab_717987c5:

    # MC "Mmm! Yes! Suck my cock, you fucking slut! Ahh!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:193
translate chinese Ci_S5_lab_ebbe6c06:

    # Cindy "*SUCK SUCK*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:196
translate chinese Ci_S5_lab_637a6192:

    # Cindy "(Oh God, his cock is slipping right down my throat! I can barely breathe!)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:197
translate chinese Ci_S5_lab_c73ec10e:

    # MC "I’m gonna fill up your slutty little mouth with my cum - and you’re going to swallow it all!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:198
translate chinese Ci_S5_lab_cdc75d04:

    # Cindy "*SHLURP*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:201
translate chinese Ci_S5_lab_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:202
translate chinese Ci_S5_lab_8db6b355:

    # Cindy "*GASP*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:203
translate chinese Ci_S5_lab_54c5f9cf:

    # Cindy "(He’s so domineering, the way he’s grabbing my head.)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:206
translate chinese Ci_S5_lab_3bfbafa5:

    # MC "(God, I’m not going to last much longer!)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:207
translate chinese Ci_S5_lab_c2c82934:

    # MC "Ugh! Ahh..."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:210
translate chinese Ci_S5_lab_e15d26db:

    # Cindy "NNMPPFFFF! MMMMMMMPPF!!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:211
translate chinese Ci_S5_lab_61af625a:

    # Cindy "*GAG* *SPLUTTER*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:213
translate chinese Ci_S5_lab_759223fe:

    # MC "Mmm! Choke on it! Ugh!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:216
translate chinese Ci_S5_lab_c732af31:

    # MC "Hnnnnng! Ahh! Yes!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:217
translate chinese Ci_S5_lab_a52b082a:

    # MC "(Her throat is so tight! I can feel it wrapped around my glans right now!)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:218
translate chinese Ci_S5_lab_ba224ba7:

    # MC "(There’s vibrations, every time she moans!)"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:221
translate chinese Ci_S5_lab_756524ec:

    # MC "Oh yeah! I’m cumming! HHNNNNNGGG!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:222
translate chinese Ci_S5_lab_aa9f13da:

    # MC "Gahhhh!!!!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:223
translate chinese Ci_S5_lab_208fc000:

    # Cindy "HMPPPFF!! Mmmm!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:224
translate chinese Ci_S5_lab_ebbe6c06_1:

    # Cindy "*SUCK SUCK*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:234
translate chinese Ci_S5_lab_1a7e7c33:

    # MC "Ahhh! OH YEAH! FUCK! MMMMM!!!"
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:235
translate chinese Ci_S5_lab_48ce9c91:

    # Cindy "*GAG* *SHLLUUURRRP*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:236
translate chinese Ci_S5_lab_657044e2:

    # Cindy "(Oh wow! There’s so much of his cum, flooding into my mouth!)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:239
translate chinese Ci_S5_lab_c1b672a1:

    # Cindy "*Cough Cough*"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:240
translate chinese Ci_S5_lab_2c95ef21:

    # MC "*Pant* That was *pant* amazing."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:241
translate chinese Ci_S5_lab_e4d2734e:

    # Cindy "*Cough* For you maybe! You asshole. You didn’t have to be so rough!"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:242
translate chinese Ci_S5_lab_878e8762:

    # MC "*Sigh* Sorry. I’ll head on now."
    MC ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:245
translate chinese Ci_S5_lab_2509ecae:

    # Cindy "(Wow... that was so intense!)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:246
translate chinese Ci_S5_lab_ecab11c9:

    # Cindy "(I just wish he had grabbed my pigtails.)"
    Cindy ""

# game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:247
translate chinese Ci_S5_lab_c13950e7:

    # Cindy "(I’m already gushing like a fountain down there! If he was any rougher, I would have probably let him pound my ass!)"
    Cindy ""

translate chinese strings:

    # game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:72
    old "That’s FAR too expensive. No thanks."
    new ""

    # game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:72
    old "I don’t have the money right now. Can I bring it later?"
    new ""

    # game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:72
    old "{color=#f00}It’s a deal! (required $1000){/color} (disabled)"
    new ""

    # game/scripts/Nightclub/Sexroom/scenes/Ci_S5.rpy:72
    old "{color=#00ff00}It’s a deal!{/color}"
    new ""

