﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:33
translate chinese CR4_Boss_necklace_05ba401c:

    # MC "Hi sir, you told me to come back today."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:34
translate chinese CR4_Boss_necklace_b671913f:

    # MC "Have you had a chance to look through the security footage yet?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:37
translate chinese CR4_Boss_necklace_cb23f7ac:

    # Headmaster "Yes, hello again."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:38
translate chinese CR4_Boss_necklace_b82a517f:

    # Headmaster "Please, step over to my desk. I have indeed reviewed the cameras."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:39
translate chinese CR4_Boss_necklace_4990b560:

    # MC "And? Did you see him?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:42
translate chinese CR4_Boss_necklace_36f9e1a0:

    # Headmaster "I did. Can you tell me something?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:43
translate chinese CR4_Boss_necklace_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:44
translate chinese CR4_Boss_necklace_36c626c1:

    # Headmaster "Was he drunk? Or is this Charles fellow always such a cunt?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:47
translate chinese CR4_Boss_necklace_283eba88:

    # MC "I think he’s just a cunt, sir."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:48
translate chinese CR4_Boss_necklace_d6d6e283:

    # MC "The girl that he stole it from, her name was Caroline. "
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:49
translate chinese CR4_Boss_necklace_06803d31:

    # Headmaster "Mmm hmm."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:52
translate chinese CR4_Boss_necklace_9639a563:

    # MC "They used to date. From what I understand, he would beat her fairly regularly."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:53
translate chinese CR4_Boss_necklace_b66d92c4:

    # Headmaster "Absolute scum."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:54
translate chinese CR4_Boss_necklace_1d82dfd8:

    # Headmaster "Forget about Charles. I’ll take care of that rabid dog."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:57
translate chinese CR4_Boss_necklace_b4e53b47:

    # MC "Thank you, sir."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:58
translate chinese CR4_Boss_necklace_8748d34b:

    # Headmaster "And I have something for you as well..."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:59
translate chinese CR4_Boss_necklace_b6bc8c32:

    # Headmaster "Where did I put it? Aha! There it is."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:62
translate chinese CR4_Boss_necklace_9b79a49e:

    # MC "Is that it?!"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:63
translate chinese CR4_Boss_necklace_76a9c605:

    # Headmaster "I added the box myself. I figured, returning such a priceless necklace, deserves a fitting wrapping."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:64
translate chinese CR4_Boss_necklace_963399cb:

    # MC "That’s very kind of you, sir. How much do I owe you?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:67
translate chinese CR4_Boss_necklace_aef1841d:

    # Headmaster "You owe me nothing."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:68
translate chinese CR4_Boss_necklace_ba31ba4c:

    # Headmaster "But someday in the future, a young man will come to you. He will need your help with something. It might be next week. It might be in ten years."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:69
translate chinese CR4_Boss_necklace_353038ee:

    # Headmaster "When that day comes, you’ll pass it on."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:72
translate chinese CR4_Boss_necklace_a47273b5:

    # MC "I can’t thank you enough. Caroline is going to be so happy with this."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:73
translate chinese CR4_Boss_necklace_2db20f7f:

    # Headmaster "Well, I shan’t keep you any longer. Take it to her. I can tell you really care about this girl. Go and make her week!"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:76
translate chinese CR4_Boss_necklace_9395f7f3:

    # MC "I will, sir."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:77
translate chinese CR4_Boss_necklace_3c90c79f:

    # MC "(I can’t believe I actually did it! I can’t tell Caroline any of the details about how this happened... She’d kill me if she knew I risked my life with an organised crime gang...)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:80
translate chinese CR4_Boss_necklace_b02055a9:

    # Headmaster "I hope to see you at college this week. I don’t want you flunking your education because you’re sleuthing around nightclubs."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:81
translate chinese CR4_Boss_necklace_9f417ce1:

    # MC "I’ll be at college, don’t worry, sir! And I won’t breathe a word about who you really are."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:83
translate chinese CR4_Boss_necklace_e0003e7d:

    # Headmaster "Good kid."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:85
translate chinese CR4_Boss_necklace_0da2d4a7:

    # Headmaster "Good."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:88
translate chinese CR4_Boss_necklace_c51a3b79:

    # MC "Oh wait - one more thing!"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:89
translate chinese CR4_Boss_necklace_686d0378:

    # Headmaster "Hmm?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:90
translate chinese CR4_Boss_necklace_ecca1148:

    # MC "Can I grab the key to Cindy’s room?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:91
translate chinese CR4_Boss_necklace_1fd70ad0:

    # Headmaster "Why on Earth would you want that?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:92
translate chinese CR4_Boss_necklace_1f68de6a:

    # MC "I wouldn’t have gotten this necklace back without her help. I just wanted to talk to her."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:95
translate chinese CR4_Boss_necklace_5043079b:

    # Headmaster "I have a few spare keys for that room. You can hold onto this one."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:96
translate chinese CR4_Boss_necklace_98fdb687:

    # MC "Thank you, I appreciate that."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:99
translate chinese CR4_Boss_necklace_27168bd0:

    # Headmaster "She’s in there until she clears her debt. I don’t expect her to be too happy about that."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:100
translate chinese CR4_Boss_necklace_727f9df6:

    # Headmaster "Just be careful. She doesn’t bite, but she can scratch."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:101
translate chinese CR4_Boss_necklace_73797a85:

    # MC "I’ll keep that in mind, sir. "
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Boss_necklase.rpy:124
translate chinese CR4_Boss_next_day_1e46c207:

    # MC "(I should come back tomorrow.)"
    MC ""

