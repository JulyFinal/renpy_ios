﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/N/nightclub_N.rpy:13
translate chinese nightclub_menu_050d80b8:

    # MC "(It's open in the night.)"
    MC ""

# game/scripts/Nightclub/N/nightclub_N.rpy:34
translate chinese nightclub_menu2_050d80b8:

    # MC "(It's open in the night.)"
    MC ""

# game/scripts/Nightclub/N/nightclub_N.rpy:46
translate chinese nightclub_menu2_6ae75d65:

    # MC "(I should go there in the morning.)"
    MC ""

translate chinese strings:

    # game/scripts/Nightclub/N/nightclub_N.rpy:22
    old "Nightclub"
    new ""

    # game/scripts/Nightclub/N/nightclub_N.rpy:22
    old "Warehouse"
    new ""

