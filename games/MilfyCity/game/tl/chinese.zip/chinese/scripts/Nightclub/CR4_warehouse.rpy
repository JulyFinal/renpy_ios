﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/CR4_warehouse.rpy:28
translate chinese CR4_warehouse_296a9743:

    # MC "(Christ almighty... Is this a warehouse? It looks like a damn supervillain’s lair!)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:29
translate chinese CR4_warehouse_44a985d7:

    # MC "Hmm... (Where the hell would I store a pink box in a place like this?)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:32
translate chinese CR4_warehouse_c1e58d33:

    # MC "(Shit... there’s security guards too.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:33
translate chinese CR4_warehouse_2fbf15a3:

    # MC "(I’m gonna have to be careful with how I proceed.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:63
translate chinese CR4_warehouse_con_2f4b1c9b:

    # MC "(Phew. I finally made it past those guys.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:64
translate chinese CR4_warehouse_con_6e4ba0e3:

    # MC "(This must be some serious operation they’re running here.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:69
translate chinese CR4_warehouse_con_bf3aa25a:

    # MC "*Whistle* Holy moly!"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:70
translate chinese CR4_warehouse_con_1297bffa:

    # MC "There’s NO way someone makes this much money running a nightclub..."
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:73
translate chinese CR4_warehouse_con_7ad30995:

    # MC "(Who the HELL have you gotten yourself involved with, Cindy?)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:74
translate chinese CR4_warehouse_con_262683fc:

    # MC "(I mean, there’s guns, drugs, bars of gold... Fuck me... This is insane.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:75
translate chinese CR4_warehouse_con_b1888dc4:

    # MC "(No wonder there is a password to speak with the Boss!)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:78
translate chinese CR4_warehouse_con_a7947d0a:

    # MC "(That must be... cocaine, right?)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:79
translate chinese CR4_warehouse_con_3c2634be:

    # MC "(Sweet Jesus, there’s dozens of bricks of the stuff! Whoever owns this would make Pablo Escobar jealous!)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:82
translate chinese CR4_warehouse_con_bf5c0aeb:

    # MC "(This place is a COD fanboy’s wet dream...)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:83
translate chinese CR4_warehouse_con_14287123:

    # MC "(This has to be an organised crime gang. There’s just no other explanation for it, right?)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:86
translate chinese CR4_warehouse_con_fcd6e2a3:

    # MC "(This must be where they prepare the bricks prior to shipping them out.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:87
translate chinese CR4_warehouse_con_fb79e1f7:

    # MC "(There’s no other explanation for it - I’m in the central hub of their operation right now.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:90
translate chinese CR4_warehouse_con_994d8617:

    # MC "If anyone catches me here, I’m a dead man..."
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:91
translate chinese CR4_warehouse_con_147f8a1b:

    # MC "I just have to find this pink box and get the fuck out of here as fast as possible."
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:94
translate chinese CR4_warehouse_con_ab3c9b46:

    # MC "(Delivery schedules? Yeah, this isn’t just some run-of-the-mill street corner drug dealer.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:95
translate chinese CR4_warehouse_con_a6d16dc1:

    # MC "(I wonder if Caroline’s necklace is hidden in this room.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:98
translate chinese CR4_warehouse_con_270183b4:

    # MC "(It’s probably not worth the risk, searching for it. If I can meet with the Boss I can probably talk him into returning it.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:99
translate chinese CR4_warehouse_con_7ecb36f3:

    # MC "(I just hope he doesn’t want me to buy it back. I don’t know if I could afford it...)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:126
translate chinese CR4_warehouse_box_04f3cd12:

    # MC "(Well, this looks like the box that Cindy was describing.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:127
translate chinese CR4_warehouse_box_c5ea1328:

    # MC "(I wonder what’s in here - it seems so out of place compared to the guns and gold.)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:128
translate chinese CR4_warehouse_box_14935956:

    # MC "(I guess it wouldn't hurt to take a peek...)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:131
translate chinese CR4_warehouse_box_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:132
translate chinese CR4_warehouse_box_6bf44d09:

    # MC "Blunts? Seriously? This is what I’m risking my life for?"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:135
translate chinese CR4_warehouse_box_15d6f634:

    # MC "(That girl, Cindy, is a nutcase!)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:136
translate chinese CR4_warehouse_box_c0196262:

    # MC "(There must be A HUNDRED safer ways to score some weed in this city!)"
    MC ""

# game/scripts/Nightclub/CR4_warehouse.rpy:137
translate chinese CR4_warehouse_box_502b3699:

    # MC "(Here’s hoping I don’t get shot to pieces, trying to escape this damn warehouse.)"
    MC ""

