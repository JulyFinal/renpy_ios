﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/Sexroom/Nc_sexroom_N.rpy:21
translate chinese sexroom_locked_4d7220ef:

    # MC "(I need a key.)"
    MC ""

