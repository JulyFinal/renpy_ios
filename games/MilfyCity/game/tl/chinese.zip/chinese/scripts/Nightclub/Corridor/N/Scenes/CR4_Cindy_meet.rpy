﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:34
translate chinese CR4_Cindy_S1_lab_b13ea0fa:

    # MC "(God dammit... I can’t believe this. I was SO fucking close!)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:35
translate chinese CR4_Cindy_S1_lab_3b30587b:

    # MC "(Caroline’s necklace could be right behind that door!)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:38
translate chinese CR4_Cindy_S1_lab_c2e09c08:

    # MC "(Why the hell does a nightclub require a password to speak with the manager? None of this makes any fucking sense!)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:39
translate chinese CR4_Cindy_S1_lab_e5bb328e:

    # MC "(And why was Charles so scared to repay this nightclub for the damages he caused?)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:48
translate chinese CR4_Cindy_S1_lab_43a44752:

    # Cindy "Why, hi there, baby!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:49
translate chinese CR4_Cindy_S1_lab_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:52
translate chinese CR4_Cindy_S1_lab_ddb35f04:

    # MC "I... uh... don’t I know you from somewhere? You seem familiar."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:53
translate chinese CR4_Cindy_S1_lab_2cab727f:

    # Cindy "The name’s Cindy! We go to the same college!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:55
translate chinese CR4_Cindy_S1_lab_bc39e7d0:

    # MC "Oh shit, yes! I remember you now! I knew I recognised you from somewhere."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:58
translate chinese CR4_Cindy_S1_lab_6a3ec5ee:

    # Cindy "Are you with anyone tonight?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:59
translate chinese CR4_Cindy_S1_lab_456bb608:

    # MC "Nah, just by myself."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:60
translate chinese CR4_Cindy_S1_lab_8cb5099d:

    # Cindy "Oh, you must be seeing the Ghos- *Ahem* I mean, the boss too!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:63
translate chinese CR4_Cindy_S1_lab_228718e5:

    # MC "You know the boss of this place!?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:64
translate chinese CR4_Cindy_S1_lab_87792b98:

    # Cindy "Uh, yeah. Do you not, baby?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:65
translate chinese CR4_Cindy_S1_lab_99424ab5:

    # MC "Not yet... But I want to."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:68
translate chinese CR4_Cindy_S1_lab_6fc20f58:

    # MC "Can you help me arrange a meeting? All I need is the password to the-"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:69
translate chinese CR4_Cindy_S1_lab_c847ce06:

    # Cindy "Hehehe! You think I’m just gonna give you the password like that, baby?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:72
translate chinese CR4_Cindy_S1_lab_db136bd6:

    # Cindy "I’ll cut you a deal - scratching two heads is better than one."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:73
translate chinese CR4_Cindy_S1_lab_f0d2dd20:

    # MC "I’m not sure that’s the correct expression... Do you mean you’ll scratch my back if I scratch yours?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:74
translate chinese CR4_Cindy_S1_lab_0739b476:

    # Cindy "No?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:75
translate chinese CR4_Cindy_S1_lab_518b829a:

    # MC "*Sigh* Fine, why not. What do you need?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:78
translate chinese CR4_Cindy_S1_lab_dbd88f4d:

    # Cindy "Great! There’s a warehouse nearby. Inside that you’ll find a bright pink box."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:79
translate chinese CR4_Cindy_S1_lab_b86a9b6a:

    # Cindy "Take these keys. You’ll need them to get in. Bring me back that pink box."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:80
translate chinese CR4_Cindy_S1_lab_e468a960:

    # Cindy "Easy, right?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:83
translate chinese CR4_Cindy_S1_lab_ec126a04:

    # MC "This isn’t legal, is it?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:84
translate chinese CR4_Cindy_S1_lab_c734290d:

    # Cindy "Of course not, baby. But if you’re not willing to get two birds dirty with one hand, then you-"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:85
translate chinese CR4_Cindy_S1_lab_a7d8b039:

    # MC "I don’t think that’s a real expression either..."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:88
translate chinese CR4_Cindy_S1_lab_4b60d8bf:

    # Cindy "Are you sure?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:89
translate chinese CR4_Cindy_S1_lab_739905a1:

    # MC "I’m... more certain of this than anything else in my life."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:90
translate chinese CR4_Cindy_S1_lab_d5e1848c:

    # Cindy "Hmm... I’d ask my English professor on Monday, but I always skip his classes."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:91
translate chinese CR4_Cindy_S1_lab_047f302d:

    # MC "(That explains a lot!)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:94
translate chinese CR4_Cindy_S1_lab_bd70ed59:

    # Cindy "Hit me up when you got that pink box, baby!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:95
translate chinese CR4_Cindy_S1_lab_746692c7:

    # MC "Stay right here. I’ll be back soon."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:118
translate chinese CR4_Cindy_S2_lab_fd9430b2:

    # MC "You almost got me killed! That was soooo fucking dangerous!"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:119
translate chinese CR4_Cindy_S2_lab_b611873e:

    # Cindy "Kinda hot, baby, ain’t it?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:120
translate chinese CR4_Cindy_S2_lab_4301b283:

    # MC "What?! NO! They had GUNS! What kinda place is that?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:121
translate chinese CR4_Cindy_S2_lab_48e22a5d:

    # Cindy "Aww, stop being a pussy! C’mon and pass the box over."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:122
translate chinese CR4_Cindy_S2_lab_e586cdb3:

    # MC "*Sigh* There you go."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:125
translate chinese CR4_Cindy_S2_lab_1532a7ce:

    # Cindy "Fine - I’m not gonna beat around the drawing board."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:126
translate chinese CR4_Cindy_S2_lab_14e3a339:

    # MC "(Christ almighty... Some people need to go back to college.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:127
translate chinese CR4_Cindy_S2_lab_80f6d2fe:

    # Cindy "This place is a front, baby. It ain’t just a nightclub."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:130
translate chinese CR4_Cindy_S2_lab_998b8ce2:

    # MC "Are you saying this is for money laundering?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:131
translate chinese CR4_Cindy_S2_lab_67b4ec7c:

    # Cindy "Uh huh! And so so much more, baby!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:132
translate chinese CR4_Cindy_S2_lab_df666348:

    # MC "(Shit, this could make getting Caroline’s necklace back, very difficult.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:135
translate chinese CR4_Cindy_S2_lab_d80a468d:

    # MC "I upheld my end of the bargain. I need the password."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:136
translate chinese CR4_Cindy_S2_lab_b09a213e:

    # Cindy "The password is... the name of this Nightclub!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:137
translate chinese CR4_Cindy_S2_lab_03444dfd:

    # MC "This club is called ‘Truth’."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:140
translate chinese CR4_Cindy_S2_lab_ed128262:

    # Cindy "SHUSH! You can’t just go around blurting out the password!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:141
translate chinese CR4_Cindy_S2_lab_98b8ddb9:

    # MC "But... that’s literally the name of the club. People are probably saying that all night long..."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:144
translate chinese CR4_Cindy_S2_lab_f6ac11ad:

    # Cindy "Huh... I guess you’re right! You’re, like, super smart, ain’tcha, baby?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:145
translate chinese CR4_Cindy_S2_lab_1330a749:

    # MC "*Sigh* If I say “Truth” to those bouncers, will they let me pass?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:146
translate chinese CR4_Cindy_S2_lab_c627c38c:

    # Cindy "Uh huh!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:149
translate chinese CR4_Cindy_S2_lab_4932d693:

    # Cindy "Catch ya later, baby! Good luck meeting the Boss!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Cindy_meet.rpy:150
translate chinese CR4_Cindy_S2_lab_70a1468b:

    # MC "Thanks, it sounds like I’ll need it. See you later."
    MC ""

