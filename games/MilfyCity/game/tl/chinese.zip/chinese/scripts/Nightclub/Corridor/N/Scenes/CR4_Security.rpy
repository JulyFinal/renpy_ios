﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:60
translate chinese CR4_sceurity_lab_aa63d751:

    # MC "(I need a password.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:78
translate chinese CR4_sceurity_lab_49f17c1d:

    # MC "(This looks like where the manager’s office is.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:79
translate chinese CR4_sceurity_lab_c7807bef:

    # MC "Hey, I’d like to speak with the manager."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:82
translate chinese CR4_sceurity_lab_73845875:

    # Bodyguard1 "Password?"
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:83
translate chinese CR4_sceurity_lab_a9ee9a91:

    # MC "Excuse me?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:84
translate chinese CR4_sceurity_lab_1e889448:

    # Bodyguard1 "Password."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:85
translate chinese CR4_sceurity_lab_8fe1a8ce:

    # MC "Umm... I just want to speak with the-"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:88
translate chinese CR4_sceurity_lab_052dd7c5:

    # Bodyguard1 "No password. No entry."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:89
translate chinese CR4_sceurity_lab_116b440a:

    # MC "How do I get a password?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:90
translate chinese CR4_sceurity_lab_05e1eb23:

    # Bodyguard1 "Sir, you clearly don’t know what you’re getting involved in. Please stay away."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:112
translate chinese CR4_sceurity_lab_47401138:

    # Bodyguard1 "*Groan* Look who it is again - I already told you, pal. No password, no entry."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:113
translate chinese CR4_sceurity_lab_384bc521:

    # Bodyguard1 "Stop wasting my time and go back onto the dancefloor."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:114
translate chinese CR4_sceurity_lab_ed547671:

    # Bodyguard1 "If you got a complaint about the establishment, then raise it with the bartender. Okay?"
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:117
translate chinese CR4_sceurity_lab_95f027ee:

    # MC "Truth."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:118
translate chinese CR4_sceurity_lab_4d688557:

    # Bodyguard1 "E-Excuse me?"
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:119
translate chinese CR4_sceurity_lab_95f027ee_1:

    # MC "Truth."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:126
translate chinese CR4_sceurity_lab_9dfe080c:

    # Bodyguard1 "I... uh... "
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:127
translate chinese CR4_sceurity_lab_c2eecafe:

    # MC "That IS the password, isn’t it?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:131
translate chinese CR4_sceurity_lab_e840ca3f:

    # Bodyguard1 "Just give me a minute, kid. I need to figure out what’s going on here."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:133
translate chinese CR4_sceurity_lab_770371ff:

    # Bodyguard1 "Just give me a minute, pal. I need to figure out what’s going on here."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:134
translate chinese CR4_sceurity_lab_e9952a64:

    # MC "Well? Are you going to let me in now?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:136
translate chinese CR4_sceurity_lab_42318dc6:

    # Bodyguard1 "Hold your horses, kiddo."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:138
translate chinese CR4_sceurity_lab_32445bfe:

    # Bodyguard1 "Hold your horses, pal."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:140
translate chinese CR4_sceurity_lab_ab8d0d15:

    # MC "Are you texting security to kick me out now?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:141
translate chinese CR4_sceurity_lab_4ee20d10:

    # Bodyguard1 "..."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:142
translate chinese CR4_sceurity_lab_39bb49e7:

    # MC "(Dammit, I’m NEVER getting past these guys.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:145
translate chinese CR4_sceurity_lab_dd6a2a7b:

    # Bodyguard1 "Well... hot damn."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:146
translate chinese CR4_sceurity_lab_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:147
translate chinese CR4_sceurity_lab_e5e33a6a:

    # Bodyguard1 "That’s a ‘yes’ from the Boss. He’s content to meet you."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:150
translate chinese CR4_sceurity_lab_549e0323:

    # Bodyguard1 "Usual rules apply: no touching him, no sudden moves, and we’ll be right here at the door just in case you try anything funny."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:151
translate chinese CR4_sceurity_lab_fc74f13c:

    # MC "Seriously? You’re letting me in now? This isn’t you pulling my leg?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:154
translate chinese CR4_sceurity_lab_b8501186:

    # Bodyguard2 "He’s not winding you up. My gaffer never jokes around. Head on in, fella."
    Bodyguard2 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:155
translate chinese CR4_sceurity_lab_62db51c3:

    # Bodyguard1 "The door’s unlocked."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:158
translate chinese CR4_sceurity_lab_9b153ff1:

    # MC "Um... Hey there, my name is [player_name]."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:159
translate chinese CR4_sceurity_lab_a20cefa7:

    # "..."
    ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:160
translate chinese CR4_sceurity_lab_fb566c19:

    # MC "I’m here to speak with you about a... about a necklace?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:163
translate chinese CR4_sceurity_lab_9c19e0b0:

    # MC "*Ahem* Did a guy named Charles give you a necklace a few days ago?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:165
translate chinese CR4_sceurity_lab_27302ab3:

    # MC "It’s a very precious piece of family memorabilia. It was stolen from someone."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:167
translate chinese CR4_sceurity_lab_4c25b3b9:

    # MC "It’s a very precious piece of memorabilia. It was stolen from-"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:170
translate chinese CR4_sceurity_lab_ab6307e6:

    # Cindy "Hush, baby. You’re yabbering WAY too much."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:171
translate chinese CR4_sceurity_lab_1dfb7cf5:

    # Cindy "The Boss will get to you when he gets to you, mmmkay?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:174
translate chinese CR4_sceurity_lab_1adf52c9:

    # MC "(Cindy is here too. I didn’t realise she was this close to whoever is running this show.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:175
translate chinese CR4_sceurity_lab_3d270053:

    # MC "Umm... sir? Hello?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:181
translate chinese CR4_sceurity_lab_6e88329b:

    # Headmaster "Why, hello - if it isn’t Iron Cajones himself."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:182
translate chinese CR4_sceurity_lab_ad21515c:

    # Headmaster "I see you’re still making your mark in the world after trying to ask out Ms. Celia."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:185
translate chinese CR4_sceurity_lab_a9fb06a2:

    # MC "Wh-What are you doing here?!"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:186
translate chinese CR4_sceurity_lab_12d3e7fd:

    # MC "Are you not supposed to be, like, running a college right now?!"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:189
translate chinese CR4_sceurity_lab_0b8cc85a:

    # Headmaster "I prefer to keep my professional life and my... other professional life separate."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:190
translate chinese CR4_sceurity_lab_df457268:

    # Headmaster "I can see... one connection - and ONLY one connection - that links you and me here today."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:191
translate chinese CR4_sceurity_lab_ac02294f:

    # Headmaster "Cindy."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:197
translate chinese CR4_sceurity_lab_9c17c7f4:

    # Cindy "Uh oh."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:198
translate chinese CR4_sceurity_lab_2e44a022:

    # Headmaster "How does one of my students know about my job here?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:199
translate chinese CR4_sceurity_lab_31ac016c:

    # Cindy "I uh..."
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:200
translate chinese CR4_sceurity_lab_5edb533d:

    # Headmaster "And, please tell me, how did they know the password?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:203
translate chinese CR4_sceurity_lab_2d6c7ff7:

    # Headmaster "Don’t think that I don’t know you sent him to steal those joints for you. Those were a special present from my favourite rapper - Soup Dog."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:204
translate chinese CR4_sceurity_lab_3b25cacd:

    # Headmaster "Do you know how much they were worth? Easily over a grand!"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:205
translate chinese CR4_sceurity_lab_d7c8c14d:

    # Headmaster "So, you’ve threatened my security, risked leaking my private life into my Milfy College, and had one of my favourite possessions stolen."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:208
translate chinese CR4_sceurity_lab_e8e90a22:

    # Cindy "Aww, c’mon! They’re just stupid joints!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:209
translate chinese CR4_sceurity_lab_cb0928e2:

    # Headmaster "And yet, you wanted them more than any of the other joints you could have had."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:210
translate chinese CR4_sceurity_lab_51c9646e:

    # Cindy "Because you forbid me from taking them! That only made me want to smoke them more! Duh!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:213
translate chinese CR4_sceurity_lab_ccde9e9f:

    # Headmaster "That’s it! You’re going to repay me for what you stole!"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:214
translate chinese CR4_sceurity_lab_0b92207c:

    # Cindy "Oh please, whatcha going to do? Cry about it?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:215
translate chinese CR4_sceurity_lab_93640df9:

    # Headmaster "Much worse than that."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:218
translate chinese CR4_sceurity_lab_12705937:

    # Cindy "H-Hey! No need to stand up or anything, b-baby!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:219
translate chinese CR4_sceurity_lab_3e83a90e:

    # Cindy "We’re cool! We cool, right?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:220
translate chinese CR4_sceurity_lab_29f9f45d:

    # Headmaster "We. Are. Not. Cool."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:224
translate chinese CR4_sceurity_lab_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:225
translate chinese CR4_sceurity_lab_9ea697f2:

    # Cindy "OW!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:228
translate chinese CR4_sceurity_lab_ae538d36:

    # Cindy "I’m sorry, okay? I shouldn’t have nicked your joints!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:229
translate chinese CR4_sceurity_lab_d16cbcdf:

    # Headmaster "You shouldn’t have given out MY password to MY office either!"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:232
translate chinese CR4_sceurity_lab_d93ccd66:

    # MC "(Fuck me... This is so awkward... )"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:233
translate chinese CR4_sceurity_lab_7d60b80e:

    # MC "(I’m watching my College Dean slap around one of his students for stealing his drugs... This must be what it feels like to go to school in Detroit.)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:236
translate chinese CR4_sceurity_lab_37b4e48b:

    # Headmaster "Take her away!"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:237
translate chinese CR4_sceurity_lab_f1ce368b:

    # Headmaster "Throw her in the back room until she repays her debt!"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:240
translate chinese CR4_sceurity_lab_f8e2b316:

    # Bodyguard1 "Sure thing, Boss!"
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:241
translate chinese CR4_sceurity_lab_d5ef131b:

    # Bodyguard1 "Can I just add, that you look fantastic in that suit, sir!"
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:242
translate chinese CR4_sceurity_lab_1d0b35c9:

    # Headmaster "Stop trying to get into my pants - and just take her away."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:243
translate chinese CR4_sceurity_lab_8a62a02d:

    # Bodyguard1 "Sorry, sir. Yes, sir."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:246
translate chinese CR4_sceurity_lab_81aa299f:

    # Cindy "HEEEYYY! Put me down, you big meanie!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:247
translate chinese CR4_sceurity_lab_c4efd4eb:

    # Headmaster "Apologies for this, [player_name]. This must seem very unprofessional of me."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:248
translate chinese CR4_sceurity_lab_b6420c78:

    # MC "It’s... alright."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:254
translate chinese CR4_sceurity_lab_4b003cc3:

    # Headmaster "That silly girl... if she’d only waited she would have gotten those joints anyway. I was going to give them to her for her birthday."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:255
translate chinese CR4_sceurity_lab_f08d5c17:

    # Cindy "What?! Are you SERIOUS?! I went through all that effort for nothing!?"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:256
translate chinese CR4_sceurity_lab_f94956dc:

    # MC "Err..."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:259
translate chinese CR4_sceurity_lab_9f8963dd:

    # Cindy "I wasn’t even the one who snuck into the warehouse! It was HIM!"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:260
translate chinese CR4_sceurity_lab_8362cfd9:

    # Cindy "He was the one who-"
    Cindy ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:261
translate chinese CR4_sceurity_lab_de2eb4c1:

    # Headmaster "Quiet! I KNOW you put him up to it."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:264
translate chinese CR4_sceurity_lab_1f9252d8:

    # Headmaster "Now, hurry up and get her out of my sight."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:265
translate chinese CR4_sceurity_lab_00142482:

    # Bodyguard1 "Right away, sir."
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:268
translate chinese CR4_sceurity_lab_9a5a5262:

    # Headmaster "Did you watch how I handled that, [player_name]?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:269
translate chinese CR4_sceurity_lab_b5855d0d:

    # Headmaster "That is how you command respect. That bitch will serve her time and repay her debt."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:270
translate chinese CR4_sceurity_lab_f41fc6ed:

    # Headmaster "When she gets out, she’ll understand the value of loyalty. She’ll respect me."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:276
translate chinese CR4_sceurity_lab_f5a39b9d:

    # MC "Sir, I- I don’t think you handled that well, at all, actually. There was no need to slap her."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:277
translate chinese CR4_sceurity_lab_c113dd5e:

    # Headmaster "Hmph... Perhaps I... overreacted."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:278
translate chinese CR4_sceurity_lab_03b4bb1d:

    # Headmaster "I don’t blame you for breaking into my warehouse. There was clearly something very important about this necklace."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:279
translate chinese CR4_sceurity_lab_cc686f37:

    # Headmaster "It takes some massive fucking balls to risk your life over some metal."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:282
translate chinese CR4_sceurity_lab_ebdf3f4f:

    # Headmaster "Tell me your story, [player_name]. Entertain me."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:283
translate chinese CR4_sceurity_lab_652a51e8:

    # MC "Right... A while ago, Charles busted up your club. He owed you money."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:284
translate chinese CR4_sceurity_lab_37766835:

    # Headmaster "Yes. Go on?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:287
translate chinese CR4_sceurity_lab_c041c595:

    # MC "Charles couldn’t afford to pay it. He attacked someone very close to me and stole a necklace that's a family heirloom."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:288
translate chinese CR4_sceurity_lab_708af7eb:

    # MC "I have heard rumours, he gave it to you to repay his debt."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:291
translate chinese CR4_sceurity_lab_d92ddda5:

    # MC "She’s devastated over the loss of it. I just... want it back for her."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:292
translate chinese CR4_sceurity_lab_d1ef0f79:

    # MC "Do you have it?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:295
translate chinese CR4_sceurity_lab_e4791a02:

    # Headmaster "I do."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:296
translate chinese CR4_sceurity_lab_329de115:

    # MC "You have it?! Are you sure it’s the right necklace?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:297
translate chinese CR4_sceurity_lab_3bb40f3d:

    # Headmaster "It’s not often, people bring me beautiful antique necklaces."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:300
translate chinese CR4_sceurity_lab_575a3d11:

    # Headmaster "It did cost me a lot of money though. I accepted this as payment in lieu of the damage."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:301
translate chinese CR4_sceurity_lab_9aa52084:

    # Headmaster "I hope you understand that it wouldn’t make business sense to just... give it away again."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:302
translate chinese CR4_sceurity_lab_1f181e9e:

    # MC "Y-Yeah... I know..."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:305
translate chinese CR4_sceurity_lab_16f90224:

    # Headmaster "You told me that the one who stole the necklace was the same person who damaged my nightclub. Is that true?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:306
translate chinese CR4_sceurity_lab_c9e17d32:

    # MC "Yes. It is. Charles: he’s about a foot taller than me, brown hair, looks like every frat boy ever."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:307
translate chinese CR4_sceurity_lab_fbff7705:

    # Headmaster "Do me a favour - check the monitors for me. Find this Charles chap. If the security cameras corroborate this young man’s story, then we will return the necklace."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:308
translate chinese CR4_sceurity_lab_e88e53cd:

    # Bodyguard1 "Yes, sir!"
    Bodyguard1 ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:311
translate chinese CR4_sceurity_lab_32f742de:

    # Headmaster "And as for Charles... I will be dealing with him myself."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:312
translate chinese CR4_sceurity_lab_fe8b389a:

    # Headmaster "I might be the head honcho of a rather clandestine network of individuals - but I abhor those who prey on the weak. There’s something grossly unfair about that."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:315
translate chinese CR4_sceurity_lab_b4e53b47:

    # MC "Thank you, sir."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:316
translate chinese CR4_sceurity_lab_53efe6e0:

    # Headmaster "I have a lot to consider right now. Would you kindly return tomorrow?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:317
translate chinese CR4_sceurity_lab_306619e0:

    # MC "Yes, not a problem."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:320
translate chinese CR4_sceurity_lab_2029b34c:

    # MC "Sir?"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:321
translate chinese CR4_sceurity_lab_686d0378:

    # Headmaster "Hmm?"
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:322
translate chinese CR4_sceurity_lab_c22fc85c:

    # MC "Thank you for listening. And sorry again for breaking into your warehouse."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:325
translate chinese CR4_sceurity_lab_80ee9f96:

    # Headmaster "Water off a duck’s back, pal. Now, I’ll start working with my men to substantiate your claims about Charles."
    Headmaster ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:326
translate chinese CR4_sceurity_lab_b4e53b47_1:

    # MC "Thank you, sir."
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:329
translate chinese CR4_sceurity_lab_1e99d9ff:

    # MC "(In the grand scheme of things, this probably went better than expected!)"
    MC ""

# game/scripts/Nightclub/Corridor/N/Scenes/CR4_Security.rpy:330
translate chinese CR4_sceurity_lab_076c3579:

    # MC "(I know where Caroline’s necklace is now, and I know that once they see Charles trashing the place they might be able to return it to me! Things are finally starting to look up again!)"
    MC ""

