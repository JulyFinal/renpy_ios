﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/dark_alley/ran_scenes.rpy:32
translate chinese dark_alley_S1_4a76afbc:

    # Violet "It wouldn’t kill you to visit her, once in a while, would it?"
    Violet ""

# game/scripts/dark_alley/ran_scenes.rpy:33
translate chinese dark_alley_S1_db2f47f5:

    # Dwayne "Shut the fuck up, Violet!"
    Dwayne ""

# game/scripts/dark_alley/ran_scenes.rpy:34
translate chinese dark_alley_S1_e72d33b1:

    # Violet "I’m just saying, she still asks about you. She’s getting better. There’s days when she’s almost like her old self."
    Violet ""

# game/scripts/dark_alley/ran_scenes.rpy:36
translate chinese dark_alley_S1_67dcbbc4:

    # Dwayne "You’re delusional if you think that."
    Dwayne ""

# game/scripts/dark_alley/ran_scenes.rpy:37
translate chinese dark_alley_S1_e6ae3cc1:

    # Dwayne "Only reason you even visit her is because you feel guilty about sending her there, in the first place."
    Dwayne ""

# game/scripts/dark_alley/ran_scenes.rpy:38
translate chinese dark_alley_S1_8a9ac122:

    # Violet "...please, Dwayne, I don’t want to do this again, right now."
    Violet ""

# game/scripts/dark_alley/ran_scenes.rpy:39
translate chinese dark_alley_S1_800dd17b:

    # Dwayne "You’re the one who brought it up."
    Dwayne ""

# game/scripts/dark_alley/ran_scenes.rpy:40
translate chinese dark_alley_S1_79146351:

    # Violet "..."
    Violet ""

# game/scripts/dark_alley/ran_scenes.rpy:60
translate chinese dark_alley_NS1_b5b71794:

    # Bodyguard2 "You said this was gonna be a simple job."
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:61
translate chinese dark_alley_NS1_b2ca2426:

    # Bodyguard1 "I got my intel DIRECTLY from the boss, if you got a problem with ME, then you got a problem with HIM!"
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:63
translate chinese dark_alley_NS1_ecfe234e:

    # Bodyguard2 "Cut the crap! Going in unprepared, is how we lost Stewart, back in Serbia."
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:64
translate chinese dark_alley_NS1_891ee0a5:

    # Bodyguard1 "Listen, all I’m saying is that we gotta improvise. The door key wasn’t working, so we just try a different method of entry."
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:66
translate chinese dark_alley_NS1_2c39b104:

    # Bodyguard2 "*Sigh* Give me a boost."
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:67
translate chinese dark_alley_NS1_e77c6861:

    # Bodyguard1 "You got this!"
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:69
translate chinese dark_alley_NS1_9e2bfd23:

    # Bodyguard2 "I swear to God, if I end up dying tonight, I’m gonna make sure my bald ghost HAUNTS your unprepared ass."
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:70
translate chinese dark_alley_NS1_b266d756:

    # Bodyguard1 "Will you just shut up and get on with the job? We’re burning moonlight here!"
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:90
translate chinese dark_alley_NS2_fe066435:

    # Juliett "So anyway, I called Madison and she told me that Maddie was cheating on Maddisyn’s boyfriend behind her back."
    Juliett ""

# game/scripts/dark_alley/ran_scenes.rpy:91
translate chinese dark_alley_NS2_6c60cb4c:

    # Juliett "No silly, you’re thinking of Maddy, not Maddie."
    Juliett ""

# game/scripts/dark_alley/ran_scenes.rpy:93
translate chinese dark_alley_NS2_ed51e01a:

    # Juliett "Madysin and Maddisyn were both there! Yeah, they were both sitting at Madi’s table, the whole night."
    Juliett ""

# game/scripts/dark_alley/ran_scenes.rpy:95
translate chinese dark_alley_NS2_4a91fc5f:

    # Juliett "Yeah, the whole thing was totally mad! LOL!"
    Juliett ""

# game/scripts/dark_alley/ran_scenes.rpy:96
translate chinese dark_alley_NS2_973dc987:

    # Juliett "Anyway, I gotta go. I’ll catch you later Madyson."
    Juliett ""

# game/scripts/dark_alley/ran_scenes.rpy:111
translate chinese dark_alley_NS3_a5942f4d:

    # Bodyguard1 "Wrong house! Wrong house!"
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:112
translate chinese dark_alley_NS3_4b9691f1:

    # Bodyguard2 "This is the LAST time I EVER go on a mission with you!"
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:114
translate chinese dark_alley_NS3_a69b5a83:

    # Bodyguard1 "What kind of monster needs that many body pillows in their home?!"
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:115
translate chinese dark_alley_NS3_c8cfe9c3:

    # Bodyguard1 "Or eats that many burgers!"
    Bodyguard1 ""

# game/scripts/dark_alley/ran_scenes.rpy:117
translate chinese dark_alley_NS3_d0b839b7:

    # Bodyguard2 "My fucking eyes! The hentai he was watching on his TV... How was that tentacle monster fucking her in eight holes, at the same time?!"
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:118
translate chinese dark_alley_NS3_2a23cbdc:

    # Bodyguard2 "Oh God! I think I’m going to be sick!"
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:120
translate chinese dark_alley_NS3_dc99f329:

    # Bodyguard2 "W-Wait, don’t leave me!"
    Bodyguard2 ""

# game/scripts/dark_alley/ran_scenes.rpy:121
translate chinese dark_alley_NS3_082710ff:

    # B_J "*Distant Voice* W-Wait! *Wheeze* Don’t you guys want to join me for episode three? I’ve pre-lubed the extra fleshlights!"
    B_J ""

