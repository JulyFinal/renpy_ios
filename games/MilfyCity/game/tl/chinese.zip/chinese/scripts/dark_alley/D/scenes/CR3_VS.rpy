﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:22
translate chinese CR3_VS_label_3f9f49b5:

    # MC "Hey, Violet! My sister said I could probably, find you hanging out around here."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:24
translate chinese CR3_VS_label_e7ad94f8:

    # MC "Hey, Violet! Caroline said I could probably, find you hanging out around here."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:25
translate chinese CR3_VS_label_1e721047:

    # Violet "Oh hey, [player_name]. Is Caroline looking for me?"
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:26
translate chinese CR3_VS_label_041fd66d:

    # MC "Yeah, but we can get to that later. It’s nothing urgent."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:42
translate chinese CR3_VS_menu_d79c5e88:

    # MC "Why are you always hanging out in this filthy alley?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:43
translate chinese CR3_VS_menu_3f368a46:

    # Violet "Filthy alley?!"
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:47
translate chinese CR3_VS_menu_feaedcd5:

    # Violet "My house is at the end of this alleyway!"
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:49
translate chinese CR3_VS_menu_594a37fd:

    # MC "(Oops!)"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:50
translate chinese CR3_VS_menu_cb18d925:

    # MC "Shit! Sorry, I didn’t mean to insult you."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:54
translate chinese CR3_VS_menu_6d150163:

    # Violet "*Sigh* You’re right... It’s a shithole. I just can’t afford a better place, right now."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:55
translate chinese CR3_VS_menu_b83cb793:

    # MC "What are you working as?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:56
translate chinese CR3_VS_menu_f6fa5148:

    # Violet "I’m mostly doing - random one-off - jobs. My art degree didn’t make me very lucrative, to the job market. I should have seen it coming, to be honest."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:65
translate chinese CR3_VS_menu_1c2b9298:

    # MC "How are you keeping?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:66
translate chinese CR3_VS_menu_68f109df:

    # Violet "*Sigh* I’ve been better. I’m struggling to pay rent, struggling to find a permanent job, and Dwayne is... "
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:70
translate chinese CR3_VS_menu_89223ddc:

    # Violet "...well, you know how my brother is."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:71
translate chinese CR3_VS_menu_761f6412:

    # MC "Damn, I’m sorry to hear that. Is there anything I can do to help you?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:72
translate chinese CR3_VS_menu_3e744854:

    # Violet "If you can line me up with a job - or even work experience - I’d really appreciate it. Aside from that, I’m just waiting for a miracle."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:81
translate chinese CR3_VS_menu_dc331ffd:

    # MC "How are things with your brother?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:82
translate chinese CR3_VS_menu_a0a201af:

    # Violet "He’s still an asshole. Nothing has changed there."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:83
translate chinese CR3_VS_menu_0d077c13:

    # MC "He hasn’t beaten you again, has he?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:87
translate chinese CR3_VS_menu_25bc81b3:

    # Violet "...I don’t want to talk about it."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:88
translate chinese CR3_VS_menu_71a304ae:

    # MC "How have you been handling things by yourself, so far? Have you tried speaking to him?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:89
translate chinese CR3_VS_menu_e3bdb549:

    # Violet "Umm... not successfully."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:93
translate chinese CR3_VS_menu_1f5e7f6f:

    # MC "Do you need my help to sort things out with him?"
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:94
translate chinese CR3_VS_menu_084f0094:

    # Violet "M-Maybe... I’ll come back to you, when I figure out what’s going on. My head’s not in a great place, right now."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:103
translate chinese CR3_VS_menu_62d538b4:

    # MC "Caroline wants to know if you’d like to come and help out, at her shop."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:104
translate chinese CR3_VS_menu_64682105:

    # Violet "Really? What would I be doing?"
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:105
translate chinese CR3_VS_menu_9e043534:

    # MC "Photography, I think."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:109
translate chinese CR3_VS_menu_78164185:

    # Violet "Hmm, I don’t really have a lot of experience - in that area of art."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:110
translate chinese CR3_VS_menu_cdd35fe1:

    # MC "It’ll be fine - besides, you definitely owe her, after stealing from her shop."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:114
translate chinese CR3_VS_menu_fd7df19a:

    # Violet "*Sigh* That’s true. Fine. I’ll help out. When does she need me there?"
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:115
translate chinese CR3_VS_menu_36dc726e:

    # MC "I’m not sure. You’ll need to talk with her."
    MC ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:116
translate chinese CR3_VS_menu_49bf357f:

    # Violet "No problem. I’ll do that soon."
    Violet ""

# game/scripts/dark_alley/D/scenes/CR3_VS.rpy:117
translate chinese CR3_VS_menu_0a60c973:

    # MC "Thanks, Violet. I really appreciate it. Caroline is struggling to find a good employee - I reckon you’re exactly the person she needs."
    MC ""

translate chinese strings:

    # game/scripts/dark_alley/D/scenes/CR3_VS.rpy:38
    old "Why do you always hang out in this filthy alley?"
    new ""

    # game/scripts/dark_alley/D/scenes/CR3_VS.rpy:38
    old "How are you keeping?"
    new ""

    # game/scripts/dark_alley/D/scenes/CR3_VS.rpy:38
    old "How are things with your brother? Do you need any help?"
    new ""

    # game/scripts/dark_alley/D/scenes/CR3_VS.rpy:38
    old "{color=#00ff00}Caroline wants to know if you’d like to come and help out, at her shop.{/color}"
    new ""

