﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:42
translate chinese Vv2_AS1_label_d8efe05e:

    # MC "(This looks like the area Caroline told me to check...)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:43
translate chinese Vv2_AS1_label_512f3f5b:

    # MC "(And THAT looks like Violet over there! I wonder who she’s with.)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:44
translate chinese Vv2_AS1_label_90bc4db9:

    # MC "(I can’t confront her in front of him - he’d beat the shit out of me in a fight!)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:45
translate chinese Vv2_AS1_label_a3a86aee:

    # MC "(I’ll hang back and watch what’s going on first...)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:50
translate chinese Vv2_AS1_label_2d4861e3:

    # Violet "I-I’m sorry, Dwayne."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:51
translate chinese Vv2_AS1_label_a38a6399:

    # Dwayne "Sorry’s not gunna cut it, is it?"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:52
translate chinese Vv2_AS1_label_6239065d:

    # Violet "N-No... *Sniff*"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:56
translate chinese Vv2_AS1_label_3918c638:

    # Dwayne "You OWE me. Never forget that."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:57
translate chinese Vv2_AS1_label_6ebfbcf9:

    # Violet "I won’t, Dwayne."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:58
translate chinese Vv2_AS1_label_395c36b8:

    # Dwayne "I mean, shit, I asked you to do ONE simple thing for me."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:59
translate chinese Vv2_AS1_label_36c346a6:

    # Dwayne "One simple thing!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:63
translate chinese Vv2_AS1_label_dd646816:

    # Dwayne "And my stupid fucking sister can’t even get that right!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:64
translate chinese Vv2_AS1_label_da05599e:

    # Dwayne "I oughta just turn you in to the cops right now! How would you like to serve some time in jail, like I did? Huh?!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:65
translate chinese Vv2_AS1_label_aaafa8b4:

    # Violet "Noooo!"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:73
translate chinese Vv2_AS1_label_29b51b2c:

    # Violet "Ooof!"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:74
translate chinese Vv2_AS1_label_6e899d4c:

    # Dwayne "Next time, you better rob a store that has some fucking money in it!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:75
translate chinese Vv2_AS1_label_c62f92f3:

    # Dwayne "How am I supposed to pay the cartel back, with this shit?! Huh?!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:82
translate chinese Vv2_AS1_label_5465497d:

    # Violet "P-Please! No more!"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:83
translate chinese Vv2_AS1_label_124f22cd:

    # Dwayne "Stupid..! Fucking..! Bitch..!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:89
translate chinese Vv2_AS1_label_87e02ce4:

    # MC "(Fuck! He’s gonna murder her! I can’t just stand still and watch!)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:90
translate chinese Vv2_AS1_label_ee51b720:

    # MC "(Should I punch him? Or maybe kick him?)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:97
translate chinese Vv2_AS1_label_1771e6d6:

    # MC "Hyaaaahhh!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:98
translate chinese Vv2_AS1_label_d48efcab:

    # Dwayne "UGH!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:99
translate chinese Vv2_AS1_label_9c62680b:

    # MC "Leave her alone!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:100
translate chinese Vv2_AS1_label_3c519ba1:

    # MC "(Take that, you bastard!)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:106
translate chinese Vv2_AS1_label_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:107
translate chinese Vv2_AS1_label_bb44e217:

    # MC "Hey! Leave her alone!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:109
translate chinese Vv2_AS1_label_23038146:

    # Dwayne "Ooof!"
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:116
translate chinese Vv2_AS1_label_933aa022:

    # "*THUD*"
    ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:117
translate chinese Vv2_AS1_label_b9f4816d:

    # Violet "Eeeek!"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:118
translate chinese Vv2_AS1_label_b17f2683:

    # Dwayne "Arrgh! You made me hurt my fucking fist."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:122
translate chinese Vv2_AS1_label_ded40053:

    # Dwayne "Get me actual money next time."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:123
translate chinese Vv2_AS1_label_759d4cb5:

    # Dwayne "If you screw up again, then YOU’LL be the one paying the cartel back."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:124
translate chinese Vv2_AS1_label_9240848e:

    # Dwayne "I’m sure they’ll knock a few grand off my debt, for a month of letting them use your body."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:125
translate chinese Vv2_AS1_label_161d7b5e:

    # Violet "N-No! Please!"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:126
translate chinese Vv2_AS1_label_7c92bd39:

    # Dwayne "Then get me the rest of the money."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:138
translate chinese Vv2_AS1_q1_8c30a5e7:

    # Dwayne "Huh? Oh look, Violet. You’ve got your very own white knight."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:139
translate chinese Vv2_AS1_q1_196f9ecf:

    # Dwayne "Looks like I’m gunna have to teach this punk a lesson too."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:140
translate chinese Vv2_AS1_q1_a7d39f52:

    # MC "I said, leave her alon-"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:146
translate chinese Vv2_AS1_q1_7b3ebabd:

    # "*THWACK*"
    ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:148
translate chinese Vv2_AS1_q1_8a6b7baa:

    # MC "OUCH!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:149
translate chinese Vv2_AS1_q1_e470a966:

    # MC "(Fuck!)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:153
translate chinese Vv2_AS1_q1_f446d684:

    # MC "Owww..."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:154
translate chinese Vv2_AS1_q1_6971879e:

    # MC "(Jesus Christ... My head’s spinning...)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:158
translate chinese Vv2_AS1_q1_29f7b196:

    # Dwayne "I don’t know what the hell you were thinking, trying to take me on, you little piece of shit."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:159
translate chinese Vv2_AS1_q1_b9110080:

    # Dwayne "But it’s time to put you back where you belong."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:160
translate chinese Vv2_AS1_q1_0929ae50:

    # MC "Ahh...."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:164
translate chinese Vv2_AS1_q1_918fc9ca:

    # Dwayne "In the fucking garbage."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:165
translate chinese Vv2_AS1_q1_ab5c129d:

    # MC "H-Hey! Stop! Put me down!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:166
translate chinese Vv2_AS1_q1_9029b9da:

    # MC "Ahhhh!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:172
translate chinese Vv2_AS1_q1_460735c5:

    # Dwayne "Fucking punk asshole. They got no respect for anyone nowadays."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:173
translate chinese Vv2_AS1_q1_7816af45:

    # MC "Owwww...."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:174
translate chinese Vv2_AS1_q1_a8f5429c:

    # Dwayne "I’ll be back for the rest of that money later, Violet. Don’t forget it."
    Dwayne ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:178
translate chinese Vv2_AS1_q1_d6b2e05b:

    # MC "(Is... Is he gone yet?)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:179
translate chinese Vv2_AS1_q1_1591fa0e:

    # MC "(Almost...)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:180
translate chinese Vv2_AS1_q1_02d77486:

    # MC "(That bastard’s probably given me a damn black eye! He punches like a fucking truck!)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:187
translate chinese Vv2_AS1_q1_e2f66288:

    # MC "Oh God... Violet..."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:188
translate chinese Vv2_AS1_q1_adc52678:

    # MC "(Is she alright?! I have to go and check...)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:189
translate chinese Vv2_AS1_q1_af4a4ab2:

    # MC "(I hope that asshole hasn’t hurt her!)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:196
translate chinese Vv2_AS1_continue_ba16d018:

    # MC "Hey Violet...?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:197
translate chinese Vv2_AS1_continue_79146351:

    # Violet "..."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:198
translate chinese Vv2_AS1_continue_26f298b9:

    # MC "Violet? Can you hear me?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:202
translate chinese Vv2_AS1_continue_0cb4e0a2:

    # Violet "Ahh!"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:203
translate chinese Vv2_AS1_continue_ef4cf139:

    # MC "Hey! It’s just me! It’s just me!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:204
translate chinese Vv2_AS1_continue_6b6b8736:

    # MC "Dwayne’s gone."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:205
translate chinese Vv2_AS1_continue_7c86c9b0:

    # Violet "Oh fuck..."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:206
translate chinese Vv2_AS1_continue_ffef38f9:

    # MC "Let me help you get back on your feet."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:210
translate chinese Vv2_AS1_continue_91c66de5:

    # Violet "Thanks for helping me, back there."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:211
translate chinese Vv2_AS1_continue_c3a8bc8a:

    # MC "It’s not a problem - I'd do the same for anyone."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:212
translate chinese Vv2_AS1_continue_5ab7be47:

    # Violet "You’re a good person."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:216
translate chinese Vv2_AS1_continue_6f1c58d9:

    # Violet "I uh... guess this means, you know that I stole from Caroline now."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:217
translate chinese Vv2_AS1_continue_183f677c:

    # MC "Yeah, I do!"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:218
translate chinese Vv2_AS1_continue_0e08847c:

    # Violet "Please don’t tell her. She’s the only friend that I truly trust..."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:219
translate chinese Vv2_AS1_continue_d8709af6:

    # Violet "I’ll get her the money back - somehow. I promise."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:231
translate chinese Vv2_AS1_menu_a2af4ed4:

    # MC "Why was that asshole beating you up?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:235
translate chinese Vv2_AS1_menu_2b1de22e:

    # Violet "God... I was stupid a few years ago. I smuggled some drugs for an ex-boyfriend."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:236
translate chinese Vv2_AS1_menu_66bcb69e:

    # Violet "That guy, Dwayne, has enough evidence to put me in prison. In exchange for not showing it to the police he makes me do odd jobs for him. Like... robbing Caroline’s store."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:237
translate chinese Vv2_AS1_menu_8e29b9fa:

    # MC "Jesus..."
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:247
translate chinese Vv2_AS1_menu_e5b46848:

    # MC "Who was that asshole?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:249
translate chinese Vv2_AS1_menu_4672b80f:

    # Violet "It’s my brother, Dwayne. He’d been in jail for four, maybe five years. "
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:251
translate chinese Vv2_AS1_menu_e233320f:

    # Violet "I hadn’t missed him at all. But now he’s back, he’s just as bad as ever."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:252
translate chinese Vv2_AS1_menu_f32eb4e7:

    # MC "Has he beaten you before?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:253
translate chinese Vv2_AS1_menu_de2b0909:

    # Violet "The beatings used to be daily. I’m used to them, don’t worry."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:264
translate chinese Vv2_AS1_continue2_08ac4462:

    # Violet "Owww..."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:265
translate chinese Vv2_AS1_continue2_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:266
translate chinese Vv2_AS1_continue2_afe7106f:

    # Violet "Just a bit sore. I need to go home and lie down."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:267
translate chinese Vv2_AS1_continue2_2ee647f8:

    # MC "Can I help you?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:271
translate chinese Vv2_AS1_continue2_5e14f9b7:

    # Violet "N-No, I don’t need your help. I can handle this by myself."
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:272
translate chinese Vv2_AS1_continue2_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:273
translate chinese Vv2_AS1_continue2_38e62756:

    # Violet "Just... Just focus on taking care of Caroline, okay?"
    Violet ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:274
translate chinese Vv2_AS1_continue2_bb3a4666:

    # MC "(That girl really needs more help than she’s letting on. Something needs to be done about Dwayne...)"
    MC ""

# game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:277
translate chinese Vv2_AS1_continue2_0c220f49:

    # MC "(Shit! I forgot to ask her for help at Caroline's cosplay store. Maybe she will be here tommorow.)"
    MC ""

translate chinese strings:

    # game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:85
    old "Intervene to help Violet. You’ve got to save her!"
    new ""

    # game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:85
    old "Stay out of it! This guy would murder you!"
    new ""

    # game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:92
    old "Punch him!"
    new ""

    # game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:92
    old "Kick him!"
    new ""

    # game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:227
    old "Why was that asshole beating you up?"
    new ""

    # game/scripts/dark_alley/D/scenes/Vv2_AS1.rpy:227
    old "Who is that asshole?"
    new ""

