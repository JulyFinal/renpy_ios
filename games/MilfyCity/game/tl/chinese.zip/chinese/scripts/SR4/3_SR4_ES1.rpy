﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/3_SR4_ES1.rpy:83
translate chinese SR4_ES1_D_50b90cf5:

    # MC "(This is where Macy said she lived...)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:85
translate chinese SR4_ES1_D_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:87
translate chinese SR4_ES1_D_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:91
translate chinese SR4_ES1_D_0b5d66f1:

    # MC "Hmm... (She mustn’t be home right now. I’ll try again later.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:101
translate chinese SR4_ES1_N_f46bf786:

    # MC "(Alright, it’s late at night so Lily should probably be home by now.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:103
translate chinese SR4_ES1_N_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:105
translate chinese SR4_ES1_N_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:109
translate chinese SR4_ES1_N_96810e15:

    # MC "Hmm... (Still no answer?)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:111
translate chinese SR4_ES1_N_32bd8714:

    # MC "(Maybe she’s asleep and didn’t hear me? Perhaps I should try in the evening before it gets too late.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:126
translate chinese SR4_ES1_E_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:128
translate chinese SR4_ES1_E_cc0d7dcf:

    # Lily2 "Two seconds! Coming!"
    Lily2 ""

# game/scripts/SR4/3_SR4_ES1.rpy:132
translate chinese SR4_ES1_E_e05781ed:

    # Lily "Oh! Hey, [player_name]. I wasn’t expecting you to drop by."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:134
translate chinese SR4_ES1_E_f2edf720:

    # MC "Hey Lily, I was beginning to wonder where you’d got to. Nobody has seen you on campus lately."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:136
translate chinese SR4_ES1_E_aa99c36d:

    # Lily "Sara isn’t with you right now? Is she?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:138
translate chinese SR4_ES1_E_ec45555e:

    # MC "No, just me tonight."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:140
translate chinese SR4_ES1_E_56607077:

    # Lily "*Phew*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:144
translate chinese SR4_ES1_E_406dd673:

    # Lily "It’s... It’s been a bit... Uh... complicated lately. That’s why I’ve been studying from home."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:146
translate chinese SR4_ES1_E_24838582:

    # MC "Complicated? What’s complicated?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:148
translate chinese SR4_ES1_E_dcda39d0:

    # Lily "This probably isn’t the best thing to try and talk about on the doorstep. Do you want to come in? I’m home alone right now."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:150
translate chinese SR4_ES1_E_e40ae654:

    # MC "Sure, why not?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:154
translate chinese SR4_ES1_E_ef524836:

    # Lily "Y’know, it was really nice of you to drop by like this, [player_name]. I wasn’t expecting you to come to check on me."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:156
translate chinese SR4_ES1_E_9e3dadae:

    # MC "*Gulp* I wasn’t trying to-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:158
translate chinese SR4_ES1_E_c6bd6eda:

    # Lily "You’re such a sweet guy, [player_name]. I can see why Sara is so attracted to you."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:160
translate chinese SR4_ES1_E_a9931e19:

    # MC "I- Listen, I’m just trying to clear the air between you and Sara before one of you ends up getting hurt or doing something stupid."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:164
translate chinese SR4_ES1_E_54f51306:

    # Lily "I think it’s quite interesting that you chose to come alone tonight. If you were trying to smooth things over, then you could have brought her along too, right?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:166
translate chinese SR4_ES1_E_79cfa724:

    # MC "I..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:168
translate chinese SR4_ES1_E_3c77e7df:

    # Lily "*Whispered* Now it’s just you... and me... alone in this apartment."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:170
translate chinese SR4_ES1_E_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:172
translate chinese SR4_ES1_E_b5fa6811:

    # Lily "*Whispered* My parents won’t be coming back tonight, so we have plenty of time to... talk things over."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:174
translate chinese SR4_ES1_E_d850ffe3:

    # Lily "*Whispered* Nobody else is coming over tonight, so we have plenty of time to... talk things over."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:178
translate chinese SR4_ES1_E_1be9e576:

    # MC "A-Alright! Calm down, Lily. You see, this is the EXACT behaviour that got you into this trouble with Sara in the first place!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:180
translate chinese SR4_ES1_E_a0e385fb:

    # Lily "Aww, are you talking about that sexy pic I sent you?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:182
translate chinese SR4_ES1_E_a5df3d9c:

    # MC "Sara has turned into a full-blown psychopath ever since she saw you send that! She’s raging at you, and she’s giving me the silent treatment!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:184
translate chinese SR4_ES1_E_06f5db84:

    # MC "Sara has turned into a full-blown psychopath ever since she caught you sending that! She’s furious at you, and I’M getting the silent treatment!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:188
translate chinese SR4_ES1_E_bbd2b327:

    # Lily "Oh, I know. You should see some of the crazy messages she’s been sending me! I’ve been avoiding campus just to keep out of her reach."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:190
translate chinese SR4_ES1_E_0bcbd83a:

    # MC "Yeah, that’s the only smart move you’ve made here."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:192
translate chinese SR4_ES1_E_b766a42a:

    # Lily "Hey! It’s not MY fault she’s a jealous psycho!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:196
translate chinese SR4_ES1_E_fe7c465d:

    # MC "Listen, Lily... I really need you to try and fix things with Sara. For BOTH our sakes."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:198
translate chinese SR4_ES1_E_6b242895:

    # Lily "*Sigh* What do you expect me to do?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:200
translate chinese SR4_ES1_E_fab46a0c:

    # MC "I think we can put this behind us if you message Sara and let her know that it was a poorly-executed prank."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:204
translate chinese SR4_ES1_E_56b714f0:

    # Lily "Oh, is that what you think that was? A harmless little joke?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:206
translate chinese SR4_ES1_E_705a6c24:

    # MC "That’s exactly what you’re going to tell Sara that it was."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:208
translate chinese SR4_ES1_E_eace66be:

    # Lily "Well, if it was just a joke you probably didn’t enjoy it all that much. You probably forgot about it. You probably never looked at it again, am I right?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:210
translate chinese SR4_ES1_E_70cf2782:

    # MC "I never said-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:214
translate chinese SR4_ES1_E_d3a8258a:

    # Lily "I left my phone in my bedroom. C’mon through and we’ll message Sara together."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:216
translate chinese SR4_ES1_E_c198f107:

    # MC "(I’m getting a bad feeling about this... I’ll make sure that Lily properly apologises to Sara, and then I better get out of this apartment.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:220
translate chinese SR4_ES1_E_1952efa4:

    # Lily "Why don’t you take a seat beside me and we’ll talk about the best thing to say to Sara?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:222
translate chinese SR4_ES1_E_e842fc30:

    # MC "Do you, uh, have a chair or-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:226
translate chinese SR4_ES1_E_24afbe20:

    # Lily "Aww, c’mon and sit beside me on the bed. I don’t bite. I promise."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:228
translate chinese SR4_ES1_E_40f0f29c:

    # MC "*Gulp (I think she might be trying to seduce me right now. I can’t let her do that. As soon as she messages Sara I will get up and leave.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:233
translate chinese SR4_ES1_E_2cde34e0:

    # Lily "Y’know, I never quite understood why you gave me your number if you didn’t want me to send you naughty photos like that."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:235
translate chinese SR4_ES1_E_0710fa7c:

    # Lily "I mean, surely there’s a part of you that’s ALWAYS wondered what I look like without my clothes on?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:237
translate chinese SR4_ES1_E_615f4cb6:

    # MC "I didn’t-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:241
translate chinese SR4_ES1_E_50ff1041:

    # Lily "I bet that you would have stroked your cock over and over if Sara hadn’t seen that picture. Wouldn’t you?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:243
translate chinese SR4_ES1_E_e61fdf57:

    # MC "She DID see it though. That’s the problem."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:245
translate chinese SR4_ES1_E_a89a5d00:

    # Lily "Oh, c’mon. A sexy picture isn’t cheating. If that was true then you’d be cheating anytime you watched pornography, and that’s just ridiculous."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:247
translate chinese SR4_ES1_E_209cf59c:

    # MC "I... uh... I see where you’re coming from, but-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:253
translate chinese SR4_ES1_E_aa1e8e9f:

    # Lily "Y’know, despite everything that’s happened, it was worth stealing your number off Sara’s phone."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:255
translate chinese SR4_ES1_E_511a98cf:

    # MC "Are you serious? She wants you dead!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:257
translate chinese SR4_ES1_E_5b4637df:

    # Lily "I know, but the idea of knowing you saw that sexy photo of me made it worthwhile."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:261
translate chinese SR4_ES1_E_68b14c11:

    # Lily "Tell me, [player_name]. Did you touch yourself when you were looking at it?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:263
translate chinese SR4_ES1_E_c171fd26:

    # Lily "I bet you did. I bet you rubbed your cock over and over to that picture without Sara knowing."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:265
translate chinese SR4_ES1_E_11a02301:

    # MC "*Gulp* Lily, I’m not going to cheat on Sara."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:267
translate chinese SR4_ES1_E_d9409ba7:

    # Lily "Who said anything about cheating? It’s just a dirty picture. If THAT counted as cheating, then any type of porn you watch would basically be cheating. And that doesn’t make any sense at all, does it [player_name]?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:273
translate chinese SR4_ES1_E_con_36664583:

    # "*RING RING* *RING RING*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:277
translate chinese SR4_ES1_E_con_6e9379b2:

    # MC "You okay?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:279
translate chinese SR4_ES1_E_con_36664583_1:

    # "*RING RING* *RING RING*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:284
translate chinese SR4_ES1_E_con_e998d919:

    # Lily "It’s her."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:286
translate chinese SR4_ES1_E_con_36664583_2:

    # "*RING RING* *RING RING*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:288
translate chinese SR4_ES1_E_con_935e9686:

    # MC "Answer it. Now’s as good a time as any to bury this."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:290
translate chinese SR4_ES1_E_con_36664583_3:

    # "*RING RING* *RING RING*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:292
translate chinese SR4_ES1_E_con_4f004d6f:

    # Lily "*Gulp* What should I say?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:294
translate chinese SR4_ES1_E_con_7d77857c:

    # MC "Exactly what we planned earlier. It was a stupid joke, you didn’t mean anything by it, and you won’t do it again. Got it?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:296
translate chinese SR4_ES1_E_con_36664583_4:

    # "*RING RING* *RING RING*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:298
translate chinese SR4_ES1_E_con_8366e3cd:

    # Lily "O-Okay."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:302
translate chinese SR4_ES1_E_con_8fa6b7f7:

    # Lily "H-Hello?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:304
translate chinese SR4_ES1_E_con_8c9ff32f:

    # Sara "FINALLY! I was wondering how long you were going to avoid me, you man-stealing bitch!"
    Sara ""

# game/scripts/SR4/3_SR4_ES1.rpy:308
translate chinese SR4_ES1_E_con_08c20d15:

    # Lily "..."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:310
translate chinese SR4_ES1_E_con_3e22cddf:

    # Sara "I swear to God, if you EVER show up on campus again you better watch out, because my knife and I aren’t gonna be far behind."
    Sara ""

# game/scripts/SR4/3_SR4_ES1.rpy:312
translate chinese SR4_ES1_E_con_c6cdd5f6:

    # Lily "S-Sara, I didn’t mean to-"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:315
translate chinese SR4_ES1_E_con_a3f4c8a1:

    # Sara "I’m going to plunge this blade into your back, the SAME way YOU backstabbed me! Pretty poetic, huh?"
    Sara ""

# game/scripts/SR4/3_SR4_ES1.rpy:317
translate chinese SR4_ES1_E_con_33334f58:

    # Lily "T-This is just a misunderstanding, Sara! C-Can I just get a word in and I’ll explain-"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:319
translate chinese SR4_ES1_E_con_c3fc4011:

    # Sara "YOU WERE SUPPOSED TO BE MY BEST FRIEND!"
    Sara ""

# game/scripts/SR4/3_SR4_ES1.rpy:323
translate chinese SR4_ES1_E_con_5f6f222d:

    # Lily "I... *Gulp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:326
translate chinese SR4_ES1_E_con_b8a7705e:

    # "*Beep*"
    ""

# game/scripts/SR4/3_SR4_ES1.rpy:328
translate chinese SR4_ES1_E_con_b74e720d:

    # Lily "She... uh... She hung up."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:333
translate chinese SR4_ES1_E_con_3eea8a9f:

    # MC "I was going to ask you how it went, but I kinda heard everything."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:335
translate chinese SR4_ES1_E_con_b27288d9:

    # Lily "She’s furious, isn’t she?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:337
translate chinese SR4_ES1_E_con_330df83f:

    # MC "Apoplectic."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:339
translate chinese SR4_ES1_E_con_ba594aff:

    # Lily "Oof."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:343
translate chinese SR4_ES1_E_con_9c8de8c6:

    # MC "Did you lock the front door after I came in? Did she say that she’s coming over?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:345
translate chinese SR4_ES1_E_con_6c29d420:

    # Lily "Yeah, it’s locked. She didn’t say anything about coming over to my place though. She told me to “watch my back on campus.”"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:347
translate chinese SR4_ES1_E_con_4ba23796:

    # MC "Well, on the bright side, I think you’ll be safe at home. Obviously, you can’t stay here forever though. We’re gonna need to think of some way to calm her down."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:352
translate chinese SR4_ES1_E_con_6a305e42:

    # Lily "Thank you, [player_name]."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:354
translate chinese SR4_ES1_E_con_f2d203a6:

    # MC "It’s a bit too early to thank me yet, I still haven’t figured out how I’m going to save your ass."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:356
translate chinese SR4_ES1_E_con_da627bf4:

    # Lily "Perhaps not, but you’ll think of something. It was really good of you to come over here and check up on me. No one else on campus did."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:358
translate chinese SR4_ES1_E_con_d8bce726:

    # MC "Of course, Lily. It was the least I could do."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:365
translate chinese SR4_ES1_E_con_308a3880:

    # Lily "Perhaps I could show you just HOW grateful I am?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:367
translate chinese SR4_ES1_E_con_8af6e038:

    # MC "What are you-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:371
translate chinese SR4_ES1_E_con_1c606766:

    # MC "*Gasp* Lily!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:373
translate chinese SR4_ES1_E_con_c50d6387:

    # Lily "Are you hard right now, [player_name]? "
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:375
translate chinese SR4_ES1_E_con_efa9dfdd:

    # MC "N-No, I-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:379
translate chinese SR4_ES1_E_con_7b75eacb:

    # Lily "I bet you’re getting all stiff seeing me wearing nothing but these tight white panties and this flimsy lilac vest."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:381
translate chinese SR4_ES1_E_con_1bfbddf0:

    # MC "Lily, you can’t just-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:385
translate chinese SR4_ES1_E_con_0f36e447:

    # Lily "You know, it wouldn’t TECHNICALLY be cheating if I slipped my top off. How is staring at my naked body any different to looking at naked women on the internet?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:387
translate chinese SR4_ES1_E_con_79cfa724:

    # MC "I..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:389
translate chinese SR4_ES1_E_con_44577723:

    # Lily "Would you like me to see my breasts, [player_name]?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:396
translate chinese SR4_ES1_E_con_d62f6a9b:

    # MC "I’m not going to cheat on Sara, Lily."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:398
translate chinese SR4_ES1_E_con_5b6f2c8c:

    # Lily "Of course, not. You can just look. I bet you’ve been wanting to see my teenage tits for ages, haven’t you?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:400
translate chinese SR4_ES1_E_con_95328fd5:

    # Lily "Of course not! You can just look. I bet you've been wanting to see my tits for a long time, haven’t you?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:402
translate chinese SR4_ES1_E_con_5bd05b5e:

    # Lily "Have you been fantasising about me when you stroke your cock in the bathtub, [player_name]?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:404
translate chinese SR4_ES1_E_con_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:408
translate chinese SR4_ES1_E_con_11366c73:

    # Lily "I bet you have."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:410
translate chinese SR4_ES1_E_con_dc4ade9a:

    # MC "Lily, you’re-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:418
translate chinese SR4_ES1_E_con_8349876a:

    # MC "I uh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:420
translate chinese SR4_ES1_E_con_c6b6ba34:

    # Lily "You don’t even need to do anything except sit there, [player_name]."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:422
translate chinese SR4_ES1_E_con_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:424
translate chinese SR4_ES1_E_con_91fd27e5:

    # MC "(Wait, is she taking her top off?)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:428
translate chinese SR4_ES1_E_con_11cb0725:

    # Lily "You’re not doing anything by simply sitting there. And you can hardly call it “cheating” when you’re not actually taking any action, right?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:430
translate chinese SR4_ES1_E_con_d96f1faa:

    # MC "Yeah, but that doesn’t mean you need to take your clothes off-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:432
translate chinese SR4_ES1_E_con_b33d5bde:

    # Lily "Shush. If you keep talking like that, then sooner or later you’re going to say something you regret. "
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:436
translate chinese SR4_ES1_E_con_5a1713fa:

    # Lily "You’ve been wanting to see my nipples for a long time now, haven’t you, [player_name]?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:438
translate chinese SR4_ES1_E_con_2fe863c5:

    # Lily "Sometimes I dream that we are playing that game of spin the bottle again... except, I’m topless. And your envious little sister is just watching us as we wrestle our tongues in front of her."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:440
translate chinese SR4_ES1_E_con_6567695a:

    # Lily "Sometimes I dream that we're playing the game of spin the bottle again... except I'm topless. And your envious sicko girlfriend is just watching us as we wrestle our tongues in front of her."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:441
translate chinese SR4_ES1_E_con_52ba7d21:

    # MC "(I really have to leave. She’s openly discussing her sexual fantasies in front of me right now!)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:443
translate chinese SR4_ES1_E_con_5b01b2cd:

    # Lily "Here, look at this."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:447
translate chinese SR4_ES1_E_con_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:449
translate chinese SR4_ES1_E_con_992c6916:

    # Lily "I know they’re a little on the small side, but I kinda feel like tiny tits suit my body type. What do you think?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:451
translate chinese SR4_ES1_E_con_ee94029d:

    # MC "(I really shouldn’t do this. I need to cut this off right now.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:453
translate chinese SR4_ES1_E_con_dc41126a:

    # MC "I... Umm... I can’t really-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:455
translate chinese SR4_ES1_E_con_52e98532:

    # Lily "Ah, I know what you mean. You can’t properly assess them without seeing the full package."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:457
translate chinese SR4_ES1_E_con_fa9e6f4d:

    # MC "Wh-What? That’s not what I-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:461
translate chinese SR4_ES1_E_con_edf8205f:

    # Lily "Well? What do you think? As I said, they’re small - but they’re perky too!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:463
translate chinese SR4_ES1_E_con_79cfa724_1:

    # MC "I..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:465
translate chinese SR4_ES1_E_con_bba9c388:

    # Lily "Plus, I’m sure they’d feel great in your mouth if you ever wanted to suck on them."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:467
translate chinese SR4_ES1_E_con_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:469
translate chinese SR4_ES1_E_con_7784a89c:

    # Lily "What’s wrong, [player_name]? Cat got your tongue?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:473
translate chinese SR4_ES1_E_con_8589c256:

    # MC "I... I think we might be going a bit too far, Lily."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:475
translate chinese SR4_ES1_E_con_a3cab2ad:

    # Lily "Oh please, you’re worrying too much, [player_name]. Just think about it logically - would you be cheating on Sara if you watched porn?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:477
translate chinese SR4_ES1_E_con_bf09af38:

    # MC "No, but-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:479
translate chinese SR4_ES1_E_con_b4652a5a:

    # Lily "Therefore, looking at me naked isn’t cheating."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:481
translate chinese SR4_ES1_E_con_e0da9ea8:

    # MC "I mean, I see where you’re-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:483
translate chinese SR4_ES1_E_con_74798f8d:

    # Lily "The logical conclusion is that, if it isn’t cheating for me to strip my clothes off in front of you, then it isn’t cheating for you to strip your clothes off in front of me."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:485
translate chinese SR4_ES1_E_con_0eac9305:

    # MC "And why would you want me to get naked?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:487
translate chinese SR4_ES1_E_con_2f2b367d:

    # Lily "So I can stroke away that boner in your pants. I mean, think how dangerous it would be if you left my apartment, and bumped into Sara in the street outside with a big erection in your pants! She’d be sooo suspicious! I’m basically doing you a favour right now!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:489
translate chinese SR4_ES1_E_con_f4a36504:

    # MC "Okay, first of all, that is a REALLY convoluted scenario you’ve concocted in your head. My boner will go away on its own, and the odds of Sara being outside your apartment are-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:491
translate chinese SR4_ES1_E_con_f68324a9:

    # Lily "Definitely not zero."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:493
translate chinese SR4_ES1_E_con_c2ed6dd4:

    # MC "Ugh, fine. I’ll concede that Sara MAY be outside your apartment. But my boner WILL go away on its own and, more importantly, a handjob is DEFINITELY cheating!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:497
translate chinese SR4_ES1_E_con_1ef8789c:

    # Lily "Really? Is it though?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:499
translate chinese SR4_ES1_E_con_5a7b1fac:

    # MC "How on Earth could it not be?!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:501
translate chinese SR4_ES1_E_con_eacc047f:

    # Lily "Well, is it cheating when you finish yourself off with your own hand?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:503
translate chinese SR4_ES1_E_con_76840f38:

    # MC "No, but obviousl-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:505
translate chinese SR4_ES1_E_con_2af36c10:

    # Lily "Then why would it be any different if I used my hand to make you cum? There’s no material difference between the two acts. In both instances a HAND is stroking a COCK to make you climax. See?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:507
translate chinese SR4_ES1_E_con_377262ff:

    # Lily "I mean, it’s not like I’m using my mouth or pussy to make you cum. Hehe!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:509
translate chinese SR4_ES1_E_con_47e7ca3f:

    # MC "I can still just wait until my boner goes away."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:511
translate chinese SR4_ES1_E_con_7cea2c65:

    # Lily "Is it gonna go away though with a pretty girl like me beside you?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:513
translate chinese SR4_ES1_E_con_38ccfb36:

    # MC "Then I’ll stand outside in the hallway till it goes away!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:515
translate chinese SR4_ES1_E_con_719fcb29:

    # Lily "And what about the mental image you’ve still got of me in your mind? Are you really gonna be able to shake that? What if you stand in the corridor trying to get rid of your boner and Sara shows up to confront me?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:517
translate chinese SR4_ES1_E_con_4b5e3eb8:

    # Lily "Honestly, the safest way to do this is just for me to rub one out now for you."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:521
translate chinese SR4_ES1_E_con_582821a3:

    # MC "And why can’t I just rub my own cock?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:523
translate chinese SR4_ES1_E_con_04cbe2a9:

    # Lily "You could, but feel how soft my hands are. Imagine how good they would feel on your cock compared to your own."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:524
translate chinese SR4_ES1_E_con_0a47a4eb:

    # Lily "We've already established that a handjob is a handjob, regardless of who gives it - so, if you've got a choice between an Oyota and Reffari why would you ever take the Oyota?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:526
translate chinese SR4_ES1_E_con_240799c1:

    # MC "(I can’t see any flaws in her logic... but should I really take my clothes off and let her give me a handjob?)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:537
translate chinese SR4_ES1_E_con2_91fdbeee:

    # MC "I... I guess you’re right. I mean, you’re naked right now and we aren’t cheating, so it wouldn’t be cheating if I stripped off too?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:539
translate chinese SR4_ES1_E_con2_824f729c:

    # Lily "Yeah! See? It makes sense, right? Plus, if Sara ever finds out about you coming over to visit me, then you can truthfully tell her that neither of us were naked."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:541
translate chinese SR4_ES1_E_con2_da03b2e8:

    # MC "But... you’re naked right now."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:543
translate chinese SR4_ES1_E_con2_5cc5755e:

    # Lily "No, I’m not. I still have my panties and socks on! Hehe! TECHNICALLY, I’m still clothed."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:545
translate chinese SR4_ES1_E_con2_3fee2e9a:

    # MC "Well... if I take my clothes off, I’ll be-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:547
translate chinese SR4_ES1_E_con2_a12e53d1:

    # Lily "Keep your shoes on. Then you can honestly tell Sara you weren’t naked. See? A lotta guys on campus think I’m just some dumb bimbo, but I actually aced the Logical Reasoning modules in Philosophy! Straight A’s baby!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:549
translate chinese SR4_ES1_E_con2_c35f8a3c:

    # Lily "Now, how about you slip out of those clothes and I’ll help you get rid of that BIG problem before Sara notices it."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:553
translate chinese SR4_ES1_E_con2_309a795a:

    # MC "Ooh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:555
translate chinese SR4_ES1_E_con2_8162ab1e:

    # Lily "See? This isn’t so bad, is it?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:557
translate chinese SR4_ES1_E_con2_ecae0ae1:

    # MC "I don’t know..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:559
translate chinese SR4_ES1_E_con2_990718db:

    # Lily "Oh c’mon, this isn’t any different to you masturbating, is it? Well, maybe the hand wrapped around your penis is a LOT softer, but aside from that there’s no real difference."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:561
translate chinese SR4_ES1_E_con2_a78a7d48:

    # MC "Mmm... I guess... I guess you’re right."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:565
translate chinese SR4_ES1_E_con2_3a839606:

    # Lily "Of course I am. This feels good, doesn’t it?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:567
translate chinese SR4_ES1_E_con2_13d9acfd:

    # MC "Mmm, y-yeah, it does."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:569
translate chinese SR4_ES1_E_con2_f0df9709:

    # Lily "Would you like me to go faster?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:571
translate chinese SR4_ES1_E_con2_cca208cc:

    # MC "Can you grip it a little firmer?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:575
translate chinese SR4_ES1_E_con2_84a7fafa:

    # Lily "Sure."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:577
translate chinese SR4_ES1_E_con2_437f5e8a:

    # MC "Mmm! Fuck... *Pant* Your hand feels amazing."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:579
translate chinese SR4_ES1_E_con2_c7a0da18:

    # Lily "I love the way you squirm when I stroke your shaft like this. Up... and down. Up... and down. Hehe!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:581
translate chinese SR4_ES1_E_con2_5b528ba6:

    # MC "Hnnng...."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:583
translate chinese SR4_ES1_E_con2_959d2958:

    # Lily "God, you’re so adorable when you groan like that."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:587
translate chinese SR4_ES1_E_con2_9d077a5d:

    # Lily "Hey! I’ve got an idea! Wouldn’t it be fun if I kissed the tip of your cock?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:589
translate chinese SR4_ES1_E_con2_2fa12071:

    # MC "That... uh... That sounds a LOT like a blowjob!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:591
translate chinese SR4_ES1_E_con2_6cca111f:

    # Lily "Hehe, no! You’re pretty close to cumming from my handjob, right? Just think of this as a quick kiss to increase the intensity of your orgasm right before you cum."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:595
translate chinese SR4_ES1_E_con2_ef29c481:

    # MC "I think that’s probably crossing a line, Lily. A blowjob is DEFINITELY cheating."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:597
translate chinese SR4_ES1_E_con2_f1b57699:

    # Lily "Crossing a line? Not at all! It’s not like I’m going to put your dick in my mouth. I’m just going to kiss the tip! Think about it - the longer you spend here, the more tempted you might be to ACTUALLY cheat on Sara."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:599
translate chinese SR4_ES1_E_con2_ff458d26:

    # Lily "If I kiss the tip while I give you a handjob, then you’re going to cum faster and you can leave sooner. It all makes sense, right?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:601
translate chinese SR4_ES1_E_con2_9996dafe:

    # MC "Really? Just a kiss on the tip?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:605
translate chinese SR4_ES1_E_con2_d57375c9:

    # Lily "Uh huh! I promise. I would NEVER do anything to make you cheat on Sara."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:607
translate chinese SR4_ES1_E_con2_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:609
translate chinese SR4_ES1_E_con2_b28c462a:

    # MC "(Crap... This is going a bit too far. What should I do?)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:615
translate chinese SR4_ES1_E_con2_b2b25196:

    # MC "Y-Yeah, it’s probably not cheating if you just quickly kiss the tip to finish me off."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:617
translate chinese SR4_ES1_E_con2_de8a1d3e:

    # Lily "Hehe! I’m glad you realised."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:621
translate chinese SR4_ES1_E_con2_3ea1e90a:

    # Lily "Mwah!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:623
translate chinese SR4_ES1_E_con2_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:627
translate chinese SR4_ES1_E_con2_a6783d39:

    # Lily "See? That wasn’t anything to get worked up about, was it? And it felt REALLY good, didn’t it?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:629
translate chinese SR4_ES1_E_con2_b8e1b1ba:

    # MC "*Pant* Y-Yeah, it did."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:631
translate chinese SR4_ES1_E_con2_0b378337:

    # MC "(God, my heart’s racing right now. I shouldn’t be doing this to Sara...)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:633
translate chinese SR4_ES1_E_con2_67a29cab:

    # Lily "Would you like me to kiss it again?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:635
translate chinese SR4_ES1_E_con2_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:637
translate chinese SR4_ES1_E_con2_5f81fb13:

    # Lily "*Whispered* I’ll take your silence as a yes."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:641
translate chinese SR4_ES1_E_con2_3ea1e90a_1:

    # Lily "Mwah!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:643
translate chinese SR4_ES1_E_con2_b4fe6ef4:

    # MC "*Pant* Ohhh... I... I- Mmm... I don't know about this, Lily. It’s.... ah..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:645
translate chinese SR4_ES1_E_con2_8823b43d:

    # Lily "*Kiss*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:647
translate chinese SR4_ES1_E_con2_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:651
translate chinese SR4_ES1_E_con2_6ed7c406:

    # Lily "What’s the matter, [player_name]? It’s just a little kiss at the tip of your cock."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:653
translate chinese SR4_ES1_E_con2_c6ac2ad2:

    # MC "*Pant* Y-Yeah, it’s not like- *gulp* It’s not like you’re actually giving me a blowjob."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:655
translate chinese SR4_ES1_E_con2_320ef2d6:

    # Lily "Hehe! See? Can I keep going then?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:657
translate chinese SR4_ES1_E_con2_2470eacf:

    # MC "...Y-Yeah."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:661
translate chinese SR4_ES1_E_con2_8823b43d_1:

    # Lily "*Kiss*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:663
translate chinese SR4_ES1_E_con2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:665
translate chinese SR4_ES1_E_con2_3ea1e90a_2:

    # Lily "Mwah!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:667
translate chinese SR4_ES1_E_con2_634cccc7:

    # MC "(Lily’s right... I’m overthinking this. This is nothing more than a VERY special handjob. All she’s doing is kissing the tip, it’s not like my dick is in her-)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:671
translate chinese SR4_ES1_E_con2_860aaf15:

    # MC "*Gasp* Ah! L-Lily!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:673
translate chinese SR4_ES1_E_con2_6bc31c2e:

    # Lily "Mmm!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:677
translate chinese SR4_ES1_E_con2_e6adc295:

    # MC "Lily! You said you were just going to kiss the tip!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:679
translate chinese SR4_ES1_E_con2_dbdb3e7d:

    # Lily "Oh, I’m sorry, my lips slipped. It was just an accident, [player_name]. It can’t be cheating if it was an accident, can it?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:681
translate chinese SR4_ES1_E_con2_05269852:

    # MC "No, but- I-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:685
translate chinese SR4_ES1_E_con2_d421a1e5:

    # Lily "Wow! You got even harder!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:687
translate chinese SR4_ES1_E_con2_cc59ae31:

    # MC "Of course I did! That’s because you went and “accidentally” sucked the tip!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:689
translate chinese SR4_ES1_E_con2_8d1f3b68:

    # Lily "Uh oh, I guess a handjob isn’t going to be enough to satisfy you anymore. It looks like I’m going to have to use my mouth if you want to get rid of your BIG problem!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:693
translate chinese SR4_ES1_E_con2_99a89296:

    # MC "Absolutely not. No way, that’s DEFINITELY cheating on Sara. You can’t rationalise that one away."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:695
translate chinese SR4_ES1_E_con2_26e31930:

    # Lily "Au contraire, cheating is something that you would do to hurt someone."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:697
translate chinese SR4_ES1_E_con2_1dcd4147:

    # MC "You can’t be serious. There’s no way you’re talking me around on this."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:699
translate chinese SR4_ES1_E_con2_8f88d25a:

    # Lily "Hehe, just listen and think about it. You have a boner right now. Due to my... unfortunate slip-up, it’s gonna take more than my hand to satisfy you and make it go away."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:703
translate chinese SR4_ES1_E_con2_1b121627:

    # Lily "The way I see it, you have three choices."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:705
translate chinese SR4_ES1_E_con2_ea45d900:

    # Lily "One - you can get up now and leave my apartment with a full-blown erection. And, given how hard you are, I don’t think this bad boy is going away any time soon."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:706
translate chinese SR4_ES1_E_con2_deed0674:

    # Lily "How are you going to explain it away when Sara sees it? Are you going to lie to her about where you got it from? Because that would be SOOOO bad."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:708
translate chinese SR4_ES1_E_con2_e8875d15:

    # MC "Fuck it. I’ll just masturbate as soon as I leave here."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:710
translate chinese SR4_ES1_E_con2_f8faeafd:

    # Lily "Well, that brings me to choice number two - you go home and masturbate."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:711
translate chinese SR4_ES1_E_con2_58fe698a:

    # Lily " When you're stroking your shaft, you're probably going to be thinking about the blond cutie girl who had her lips wrapped around your cock earlier today. And that would be emotionally cheating on Sara, wouldn't it?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:713
translate chinese SR4_ES1_E_con2_8c4668c6:

    # MC "Wait a minute - earlier on you said masturbating and imagining people naked WASN’T cheating!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:715
translate chinese SR4_ES1_E_con2_f04c483a:

    # Lily "No, I didn’t. You’re mistaken."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:717
translate chinese SR4_ES1_E_con2_e48d3e4d:

    # MC "But-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:719
translate chinese SR4_ES1_E_con2_18cc3348:

    # Lily "Which leaves us with choice three - I finish you off with my mouth. You get to leave here with that boner gone, Sara doesn’t see your erection, so you don’t need to make up some lies about where it came from."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:720
translate chinese SR4_ES1_E_con2_d72f70bd:

    # Lily "PLUS, you don’t have to masturbate while thinking about me, which would be basically cheating."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:722
translate chinese SR4_ES1_E_con2_c8b98ba8:

    # MC "I... I don’t... That doesn’t really make sens-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:726
translate chinese SR4_ES1_E_con2_6ded602a:

    # Lily "*Glompf*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:728
translate chinese SR4_ES1_E_con2_2e0a04fa:

    # MC "Hnnngggg! Ugghh! LILY!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:730
translate chinese SR4_ES1_E_con2_eaa18141:

    # Lily "*Shlurp* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:734
translate chinese SR4_ES1_E_con2_dcd1779a:

    # Lily "Hehe, see? Was that really so bad?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:736
translate chinese SR4_ES1_E_con2_42d9691e:

    # MC "It doesn’t feel... right."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:738
translate chinese SR4_ES1_E_con2_24c1ecd2:

    # Lily "Tell ya what. Would it make you feel better if you didn’t finish inside my mouth?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:740
translate chinese SR4_ES1_E_con2_cf488740:

    # MC "I... I guess so. Yeah. I think that’s better."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:742
translate chinese SR4_ES1_E_con2_6e0ef47f:

    # Lily "How about you hold the back of my head and whenever you’re about to cum, let go and I’ll pull my head back. You can cum on my face instead then?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:744
translate chinese SR4_ES1_E_con2_13a21dc9:

    # MC "Alright..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:751
translate chinese SR4_ES1_E_con2_6e7f7a9f:

    # MC "I’m sorry, Lily. That’s way too close to a blowjob. I really think I need to leave now."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:753
translate chinese SR4_ES1_E_con2_3912ced4:

    # Lily "Aww... Well, if you’re sure that you need to go then you won’t mind one quick goodbye kiss."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:755
translate chinese SR4_ES1_E_con2_1fb3a871:

    # MC "No, wait-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:759
translate chinese SR4_ES1_E_con2_bf13a68f:

    # Lily "*Mwah*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:761
translate chinese SR4_ES1_E_con2_66a846e3:

    # MC "Mmm! Lily!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:765
translate chinese SR4_ES1_E_con2_ac5eb492:

    # Lily "What’s wrong, [player_name]? It was just one quick kiss."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:767
translate chinese SR4_ES1_E_con2_16887a79:

    # MC "You can’t just-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:769
translate chinese SR4_ES1_E_con2_7da4a910:

    # Lily "I bet it felt really good, didn’t it? How about I give you one more kiss down there before you go? Something to remember me by when you go away and wank off."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:771
translate chinese SR4_ES1_E_con2_ccf4c8ad:

    # MC "*Gulp* Just one more kiss... and then I have to go."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:775
translate chinese SR4_ES1_E_con2_bf13a68f_1:

    # Lily "*Mwah*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:777
translate chinese SR4_ES1_E_con2_24563497:

    # MC "Ooohh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:779
translate chinese SR4_ES1_E_con2_b6ae3de9:

    # MC "(Her lips are incredible. It feels so good! I’m gonna cum so quickly when I get back home and have a chance to masturbate!)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:783
translate chinese SR4_ES1_E_con2_f377b51e:

    # Lily "*Shlurp* *Lick*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:785
translate chinese SR4_ES1_E_con2_3dd2f4e4:

    # MC "Hnnngg... Ohhhh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:787
translate chinese SR4_ES1_E_con2_e13c06e6:

    # MC "(She started twirling her tongue around the tip!)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:789
translate chinese SR4_ES1_E_con2_042fcf21:

    # MC "*Pant* L-Lily! Hnnng! St-Stop!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:792
translate chinese SR4_ES1_E_con2_a2afa84f:

    # Lily "Aww, what’s wrong, [player_name]?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:794
translate chinese SR4_ES1_E_con2_f77b600c:

    # MC "You said you were just gonna kiss it! That was practically a blowjob!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:796
translate chinese SR4_ES1_E_con2_0fe58229:

    # Lily "Oh, come on, [player_name]. That wasn’t a blowjob! You told me I could kiss your dick one last time, so I decided to make it a French kiss! A French kiss is STILL a KISS, right?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:798
translate chinese SR4_ES1_E_con2_519d2fc8:

    # MC "I mean, yeah, but-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:800
translate chinese SR4_ES1_E_con2_039a9677:

    # Lily "And you interrupted me! So I’m going to have to start over again."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:802
translate chinese SR4_ES1_E_con2_9a8e28e0:

    # MC "Wait, what-"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:806
translate chinese SR4_ES1_E_con2_7e7de820:

    # MC "Ooohh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:808
translate chinese SR4_ES1_E_con2_d442d517:

    # Lily "*Shlurp* *Lick* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:810
translate chinese SR4_ES1_E_con2_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:812
translate chinese SR4_ES1_E_con2_4172a95b:

    # Lily "(I’ve got him right where I want him. Time to turn up the heat.)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:816
translate chinese SR4_ES1_E_con2_c54e483c:

    # MC "Hnnngg! L-Lily! What are you doing?!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:818
translate chinese SR4_ES1_E_con2_b6314233:

    # Lily "*Shlurrrp* *Suck* *SHLUUURRRP*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:820
translate chinese SR4_ES1_E_con2_d595bb37:

    # MC "Ooohhh... Fuuuck...."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:824
translate chinese SR4_ES1_E_con2_dca5c3c1:

    # Lily "*Glompf* *Suuuuck* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:826
translate chinese SR4_ES1_E_con2_334fc281:

    # MC "*Pant* Lily, this is- hnnngg... waaay more than a French kiss ahh... now!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:828
translate chinese SR4_ES1_E_con2_eaa18141_1:

    # Lily "*Shlurp* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:832
translate chinese SR4_ES1_E_con2_bc1e7ef3:

    # Lily "*Gasp* How was that?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:834
translate chinese SR4_ES1_E_con2_1173b397:

    # MC "That was WAY more than a French kiss! You were practically sucking my dick!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:836
translate chinese SR4_ES1_E_con2_4aaf2111:

    # Lily "Nonsense! It was just a VERY passionate French kiss! Plus, I NEVER even pushed my lips past your glans!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:838
translate chinese SR4_ES1_E_con2_795632a5:

    # MC "Shit... my dick is even harder than before! I have to go."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:840
translate chinese SR4_ES1_E_con2_290eeae9:

    # Lily "I wouldn’t do that if I were you. Have you ever stopped a movie or book right before the ending? It’s frustrating not finishing it off, wondering how it was going to end."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:842
translate chinese SR4_ES1_E_con2_5002151f:

    # Lily "If you walk away right now you’re going to CONSTANTLY be wondering how it would have felt to climax with me. It’ll be playing on your mind over and over every time you masturbate or have Sara suck your cock."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:844
translate chinese SR4_ES1_E_con2_01ae62bc:

    # Lily "There’s only one way you’re going to get me off your mind."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:846
translate chinese SR4_ES1_E_con2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:848
translate chinese SR4_ES1_E_con2_cf298c71:

    # Lily "Let’s finish the movie together, [player_name] and find out how it ends. Then you can go back to Sara with absolutely no regrets and no guilt."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:850
translate chinese SR4_ES1_E_con2_a095d76f:

    # MC "...fine. But there’s no way I’m finishing in your mouth. That’s FAR too intimate."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:852
translate chinese SR4_ES1_E_con2_46145b0c:

    # Lily "Of course, how about you hold the back of my head and whenever you’re about to cum, let go and I’ll pull my head back. You can cum on my face then if you want to?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:860
translate chinese SR4_ES1_E_con2_2be1a7a4:

    # MC "I... I’m sorry, Lily. I can’t do this to Sara."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:862
translate chinese SR4_ES1_E_con2_df5a4611:

    # Lily "Are you sure-"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:864
translate chinese SR4_ES1_E_con2_d7fd9e19:

    # MC "Lily. Enough."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:866
translate chinese SR4_ES1_E_con2_7a65aa50:

    # Lily "*Sigh*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:870
translate chinese SR4_ES1_E_con2_22e9a913:

    # Lily "Sara is lucky to have someone like you."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:872
translate chinese SR4_ES1_E_con2_ed8ad894:

    # MC "I’m lucky to have her too. Do you understand now why I can’t do this to her?"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:876
translate chinese SR4_ES1_E_con2_f19be8e7:

    # Lily "Yeah... It’s funny. No guy has ever been able to resist me before. I didn’t imagine you’d be the first."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:880
translate chinese SR4_ES1_E_con2_641562c3:

    # Lily "Perhaps I could reward you with a blowjob?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:882
translate chinese SR4_ES1_E_con2_468ada00:

    # MC "Lily!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:886
translate chinese SR4_ES1_E_con2_d514ad23:

    # Lily "*Sigh* Fine!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:890
translate chinese SR4_ES1_E_con2_22f79a69:

    # Lily "Well, I guess this is it then. You’re going to tell Sara about what I tried to do, aren’t you?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:894
translate chinese SR4_ES1_E_con2_13c4672a:

    # MC "No. I’m still going to help you, Lily. Sara has had a mental breakdown over a simple text message from you. I don’t know what would happen if she found out you tried to seduce me too."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:898
translate chinese SR4_ES1_E_con2_1cbf7f23:

    # Lily "...Thank you, [player_name]."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:902
translate chinese SR4_ES1_E_con2_ada7a5dd:

    # MC "You better stay off campus until Sara calms down. I’ll see if I can figure out a way to get her to back off."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:904
translate chinese SR4_ES1_E_con2_3c07d620:

    # Lily "Umm... Just a thought, maybe Macy could help?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:906
translate chinese SR4_ES1_E_con2_b5b98049:

    # MC "Got it. I’ll check in with her later on."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:908
translate chinese SR4_ES1_E_con2_b9e1d6fa:

    # Lily "Goodbye, [player_name]."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:910
translate chinese SR4_ES1_E_con2_46ada75e:

    # MC "Goodbye, Lily."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:942
translate chinese SR4_ES1_E_con3_cheat_bf13a68f:

    # Lily "*Mwah*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:945
translate chinese SR4_ES1_E_con3_cheat_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:949
translate chinese SR4_ES1_E_con3_cheat_33edc2ee:

    # Lily "Mmm... *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:951
translate chinese SR4_ES1_E_con3_cheat_af4e3dd2:

    # MC "*Gasp* Ooohhh..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:955
translate chinese SR4_ES1_E_con3_cheat_7a01ffea:

    # MC "(Lily’s right - this isn’t cheating. She’s just helping me get rid of this erection before I leave. It would be WAY worse if I left Lily’s apartment and Sara saw me with this boner!)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:957
translate chinese SR4_ES1_E_con3_cheat_c595d3e3:

    # MC "(Besides, Lily is just trying to get rid of it in the quickest, most efficient way she can.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:959
translate chinese SR4_ES1_E_con3_cheat_12d05742:

    # Lily "*Suck* "
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:963
translate chinese SR4_ES1_E_con3_cheat_eaa18141:

    # Lily "*Shlurp* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:965
translate chinese SR4_ES1_E_con3_cheat_3c755ef9:

    # MC "Hnnngg..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:969
translate chinese SR4_ES1_E_con3_cheat_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:971
translate chinese SR4_ES1_E_con3_cheat_5e906e79:

    # Lily "*Suuuck* *Shlurrrp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:975
translate chinese SR4_ES1_E_con3_cheat_3ed8d026:

    # MC "(It’s not like I’m going to finish somewhere erotic like in her mouth or anything! She’s just going to bring me to the edge of an orgasm, then I’ll pull out and cum in a tissue or something.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:977
translate chinese SR4_ES1_E_con3_cheat_3f2093f3:

    # Lily "*Suck* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:979
translate chinese SR4_ES1_E_con3_cheat_e0fc2c20:

    # MC "*Pant* Mmmm..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:984
translate chinese SR4_ES1_E_con3_cheat_42c838fb:

    # MC "(Besides, neither of us are even naked! I’ve still got my shoes, Lily still has her panties and socks on.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:986
translate chinese SR4_ES1_E_con3_cheat_b8045b51:

    # Lily "*Suuuuucck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:988
translate chinese SR4_ES1_E_con3_cheat_66aa61b2:

    # MC "Mmm.. God... That’s amazing..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:992
translate chinese SR4_ES1_E_con3_cheat_3adc2b93:

    # Lily "Mppff! *Shluurrp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:994
translate chinese SR4_ES1_E_con3_cheat_23407845:

    # MC "Ooohhh...."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:998
translate chinese SR4_ES1_E_con3_cheat_13dfa5e5:

    # Lily "*Gag* Mmppffff! *SHLUUURRRP!*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1000
translate chinese SR4_ES1_E_con3_cheat_0b9a4900:

    # MC "Ahhh! Hnnnngg!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1004
translate chinese SR4_ES1_E_con3_cheat_7ea5d090:

    # Lily "(I can’t believe [player_name] actually went along with this! Hehe!)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1006
translate chinese SR4_ES1_E_con3_cheat_b478e7d4:

    # Lily "(I’m soaking wet right now, but I don’t think I can convince him to fuck me today. He was already quite hesitant about me sucking his dick.)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1008
translate chinese SR4_ES1_E_con3_cheat_08d67cbc:

    # MC "*Pant* Wow..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1012
translate chinese SR4_ES1_E_con3_cheat_434d1df5:

    # Lily "(I knew he’d give in once he saw me strip my clothes off. There’s no way a horny guy like him would be able to resist me for long.)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1014
translate chinese SR4_ES1_E_con3_cheat_689135ad:

    # Lily "*Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1016
translate chinese SR4_ES1_E_con3_cheat_9464c65b:

    # Lily "(All I had to do was keep pushing at his boundaries until he gave in. I probably won’t get to fuck him today, but I can pleasure him so much that he’ll spend all night thinking about me.)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1020
translate chinese SR4_ES1_E_con3_cheat_52c677e0:

    # MC "*Pant* Mmm! God, your mouth is amazing..."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1022
translate chinese SR4_ES1_E_con3_cheat_4a2e1ed2:

    # Lily "Mmmm! Hmmm! *Suck* *Suck* *Suck*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1026
translate chinese SR4_ES1_E_con3_cheat_de8c2fbe:

    # MC "Ah! Hnnnng... Fuuuck... Mmm!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1028
translate chinese SR4_ES1_E_con3_cheat_8dab7641:

    # Lily "*Shlurp* *Suck* *SUUUUUCK*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1030
translate chinese SR4_ES1_E_con3_cheat_9a7420c3:

    # MC "Arrgh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1034
translate chinese SR4_ES1_E_con3_cheat_947c1c2f:

    # Lily "*Shluuurrp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1036
translate chinese SR4_ES1_E_con3_cheat_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1038
translate chinese SR4_ES1_E_con3_cheat_a4ce013b:

    # Lily "(I’ll give him a blowjob SO good that the next time Sara gives him head he’ll be imagining ME instead. Hehe!)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1040
translate chinese SR4_ES1_E_con3_cheat_32e94918:

    # Lily "*Suck* *Shluuurrp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1042
translate chinese SR4_ES1_E_con3_cheat_18fcb1ae:

    # MC "Hnnng! Fuck! Ah! *Pant* Ooohhh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1044
translate chinese SR4_ES1_E_con3_cheat_cd2b6769:

    # MC "(I’m getting close. I better take my hand off her head to let her know she can stop sucking now.)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1048
translate chinese SR4_ES1_E_con3_cheat_688f358c:

    # Lily "*Shlurp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1050
translate chinese SR4_ES1_E_con3_cheat_d0dbbc6b:

    # MC "I’m getting close, Lily!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1052
translate chinese SR4_ES1_E_con3_cheat_fd83815d:

    # Lily "*SUCK* *SUCK* *SUCK*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1054
translate chinese SR4_ES1_E_con3_cheat_1aa47849:

    # MC "Arrghh! Fuck! Lily! I’m about to cum! HNNNGG!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1056
translate chinese SR4_ES1_E_con3_cheat_8c006f76:

    # Lily "(Hehe! Did he ACTUALLY think I was going to let him finish anywhere other than in my mouth?)"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1058
translate chinese SR4_ES1_E_con3_cheat_7d79c184:

    # Lily "*SHLURP* *SUCK*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1060
translate chinese SR4_ES1_E_con3_cheat_d21a246b:

    # MC "Lily, stop! I can’t cheat on Sar-aaahhhh! HNNNGGG!!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1064
translate chinese SR4_ES1_E_con3_cheat_b8044d52:

    # MC "(Shit! I can’t stop myself from cumming, her mouth feels too good!)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1066
translate chinese SR4_ES1_E_con3_cheat_a6e9bc90:

    # Lily "*Shlurp* *Suck* *SUCK* *SHLLLUUUUUURRRP*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1068
translate chinese SR4_ES1_E_con3_cheat_eb978b73:

    # MC "HNNNGG!! I’m cummming! Shit! Ughhh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1072
translate chinese SR4_ES1_E_con3_cheat_b4b2d48d:

    # Lily "*SHLURP* *Gulp* *Gulp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1074
translate chinese SR4_ES1_E_con3_cheat_9536d5e8:

    # MC "Ooohhhh! Fuuuuuck! Arrghhhhh!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1079
translate chinese SR4_ES1_E_con3_cheat_80456f08:

    # MC "(She’s swallowing my semen each time I blast another load in her mouth!)"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1080
translate chinese SR4_ES1_E_con3_cheat_36b099d1:

    # Lily "*Gulp*"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1084
translate chinese SR4_ES1_E_con3_cheat_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1086
translate chinese SR4_ES1_E_con3_cheat_991bbedf:

    # MC "Lily, what the *Pant* fuck did you do? I told you I wasn’t *Pant* going to finish inside your mouth!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1088
translate chinese SR4_ES1_E_con3_cheat_5eea962c:

    # Lily "Hehe, you enjoyed it though, right?"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1090
translate chinese SR4_ES1_E_con3_cheat_c2ec33ae:

    # MC "Ye- No- That’s- That’s not the point! I explicitly told you I wasn’t going to cheat on Sara!"
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1094
translate chinese SR4_ES1_E_con3_cheat_c9ac438e:

    # Lily "Relax, [player_name]. You didn’t cheat on Sara. You told me to stop, and I kept sucking. See? You didn’t do anything wrong."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1096
translate chinese SR4_ES1_E_con3_cheat_8ffa0e3b:

    # Lily "The only bad girl here was me. Hehe!"
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1098
translate chinese SR4_ES1_E_con3_cheat_6c9ec8d3:

    # MC "...Y-Yeah, I told you to stop."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1100
translate chinese SR4_ES1_E_con3_cheat_4ae3d4b4:

    # Lily "You did. And I was a naughty little slut who kept sucking. That doesn’t make you a cheater."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1102
translate chinese SR4_ES1_E_con3_cheat_7f0cb1ba:

    # MC "*Gulp* G-Got it. That makes sense."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1104
translate chinese SR4_ES1_E_con3_cheat_afc10c4d:

    # Lily "How about we get dressed? Sara is probably going to get suspicious if you disappear for much longer."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1106
translate chinese SR4_ES1_E_con3_cheat_fee032d8:

    # MC "Yeah, good point."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1111
translate chinese SR4_ES1_E_con3_cheat_a5b5f3b0:

    # Lily "Well, I’m looking forward to seeing you again, [player_name]."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1113
translate chinese SR4_ES1_E_con3_cheat_4e5c1b3e:

    # MC "I won’t be coming back over, Lily. This was WAY too close to a mistake."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1115
translate chinese SR4_ES1_E_con3_cheat_ef1e6a11:

    # Lily "Uh huh, suuuure."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1119
translate chinese SR4_ES1_E_con3_cheat_1e881adf:

    # MC "Listen, I promised you I would sort out this situation with Sara. I meant that. I’m going to try and figure out a way to calm her down."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1121
translate chinese SR4_ES1_E_con3_cheat_156daf05:

    # MC "In the meantime, I need you to stay off campus. The last thing I need is her jumping you in the locker room with a knife."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1125
translate chinese SR4_ES1_E_con3_cheat_0abef12c:

    # Lily "Trust me, I don’t intend to risk my life by going back there."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1127
translate chinese SR4_ES1_E_con3_cheat_584559b9:

    # Lily "If you need a hand you could probably try speaking with Macy? She might be able to help you formulate a plan to placate Sara."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1131
translate chinese SR4_ES1_E_con3_cheat_76a04d93:

    # MC "Thanks Lily, I’ll keep that in mind."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1133
translate chinese SR4_ES1_E_con3_cheat_97fe8b90:

    # Lily "See you again soon for another round. You’re welcome to come back over whenever you want. I mean that."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1135
translate chinese SR4_ES1_E_con3_cheat_1a0ec8f3:

    # MC "Not happening, Lily."
    MC ""

# game/scripts/SR4/3_SR4_ES1.rpy:1137
translate chinese SR4_ES1_E_con3_cheat_b22855fe:

    # Lily "Whatever you say, [player_name]. I know you’ll be thinking about me when you’re lying alone in your bed tonight."
    Lily ""

# game/scripts/SR4/3_SR4_ES1.rpy:1139
translate chinese SR4_ES1_E_con3_cheat_2d204a49:

    # MC "..."
    MC ""

translate chinese strings:

    # game/scripts/SR4/3_SR4_ES1.rpy:392
    old "{color=#00ff00}No! I’m not going to cheat on Sara, Lily.{/color}"
    new ""

    # game/scripts/SR4/3_SR4_ES1.rpy:392
    old "{color=#FF0000}I... *Gulp*{/color}"
    new ""

    # game/scripts/SR4/3_SR4_ES1.rpy:533
    old "{color=#FF0000}I... I guess you’re right. A handjob isn’t cheating. I rub my own cock all the time after all.{/color}"
    new ""

    # game/scripts/SR4/3_SR4_ES1.rpy:533
    old "{color=#00ff00}No, a handjob is still cheating. I can’t do this to Sara.{/color}"
    new ""

    # game/scripts/SR4/3_SR4_ES1.rpy:611
    old "Y-Yeah, it’s probably not cheating if you just kiss the tip."
    new ""

    # game/scripts/SR4/3_SR4_ES1.rpy:611
    old "I’m sorry Lily, that sounds far too close to a blowjob. I need to leave."
    new ""

