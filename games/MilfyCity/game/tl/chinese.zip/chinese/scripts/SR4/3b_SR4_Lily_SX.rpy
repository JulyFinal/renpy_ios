﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:86
translate chinese SR4_Lily_SX_nocheat_fb2be6ff:

    # Lily "Well, hello again, [player_name]. I was beginning to wonder how long you were planning on avoiding me."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:88
translate chinese SR4_Lily_SX_nocheat_c26d47e8:

    # MC "*Sigh* Hi Lily. You still haven't accepted that I'm with Sara now, have you?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:92
translate chinese SR4_Lily_SX_nocheat_51e05508:

    # Lily "You'll come to your senses eventually. All the men do given enough time."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:94
translate chinese SR4_Lily_SX_nocheat_673879f5:

    # Lily "You'll be lying in bed alone at night and find yourself thinking of my beautiful, sexy body while you stroke your-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:96
translate chinese SR4_Lily_SX_nocheat_46ada75e:

    # MC "Goodbye, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:98
translate chinese SR4_Lily_SX_nocheat_64df799c:

    # Lily "Hmmph!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:105
translate chinese SR4_Lily_SX_nocheat_2a452eed:

    # Lily "Hey again, [player_name]. Ready to leave your pathetic little girlfriend yet?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:107
translate chinese SR4_Lily_SX_nocheat_5a7889ac:

    # MC "I'm still not cheating on Sara, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:111
translate chinese SR4_Lily_SX_nocheat_4fa5cfbf:

    # Lily "I'll be waiting. You won't be able to resist me forever, [player_name]."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:113
translate chinese SR4_Lily_SX_nocheat_887e14ca:

    # MC "*Sigh* Goodbye, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:124
translate chinese SR4_Lily_SX_closed_0290859d:

    # MC "(I still haven’t found the key.)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:144
translate chinese SR4_Lily_SX_closed_e83502d3:

    # MC "Oh, hey Lily. You don’t have class right now?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:146
translate chinese SR4_Lily_SX_closed_15b85003:

    # Lily "Nope, free for another twenty minutes. Say... Is Sara around?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:150
translate chinese SR4_Lily_SX_closed_411cbc8b:

    # MC "I haven’t seen her. She must be studying right now."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:152
translate chinese SR4_Lily_SX_closed_c88c1e5a:

    # Lily "*Whispered* How about we sneak off for a while and do some “studying” of our own?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:154
translate chinese SR4_Lily_SX_closed_1e909e51:

    # MC "*Whispered* Really? You’re STILL doing this? "
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:156
translate chinese SR4_Lily_SX_closed_d615d11a:

    # Lily "Uh huh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:158
translate chinese SR4_Lily_SX_closed_da74b5cb:

    # MC "*Sigh* Fine. Let’s be quick."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:160
translate chinese SR4_Lily_SX_closed_5ac82474:

    # Lily "Do you know anywhere we won’t be interrupted?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:164
translate chinese SR4_Lily_SX_closed_c3c81e18:

    # MC "Follow me, nobody is gonna be in the staff room right now."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:166
translate chinese SR4_Lily_SX_closed_2f8bf956:

    # Lily "Hehe! I can’t believe we’re actually going to be doing it on campus!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:171
translate chinese SR4_Lily_SX_closed_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:174
translate chinese SR4_Lily_SX_closed_53d75b06:

    # MC "Sorry, Lily. The staff room is locked. We can do this another time if you want."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:175
translate chinese SR4_Lily_SX_closed_aaa3e613:

    # Lily "Sure, no problem!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:176
translate chinese SR4_Lily_SX_closed_aad980bd:

    # MC "Catch you later, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:177
translate chinese SR4_Lily_SX_closed_fcaf6fe5:

    # Lily "See ya, [player_name]."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:195
translate chinese SR4_Lily_SX_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:210
translate chinese SR4_Lily_SX_e83502d3:

    # MC "Oh, hey Lily. You don’t have class right now?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:212
translate chinese SR4_Lily_SX_15b85003:

    # Lily "Nope, free for another twenty minutes. Say... Is Sara around?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:216
translate chinese SR4_Lily_SX_411cbc8b:

    # MC "I haven’t seen her. She must be studying right now."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:218
translate chinese SR4_Lily_SX_c88c1e5a:

    # Lily "*Whispered* How about we sneak off for a while and do some “studying” of our own?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:220
translate chinese SR4_Lily_SX_1e909e51:

    # MC "*Whispered* Really? You’re STILL doing this? "
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:222
translate chinese SR4_Lily_SX_d615d11a:

    # Lily "Uh huh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:224
translate chinese SR4_Lily_SX_da74b5cb:

    # MC "*Sigh* Fine. Let’s be quick."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:226
translate chinese SR4_Lily_SX_5ac82474:

    # Lily "Do you know anywhere we won’t be interrupted?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:230
translate chinese SR4_Lily_SX_c3c81e18:

    # MC "Follow me, nobody is gonna be in the staff room right now."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:232
translate chinese SR4_Lily_SX_2f8bf956:

    # Lily "Hehe! I can’t believe we’re actually going to be doing it on campus!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:236
translate chinese SR4_Lily_SX_09d06ab8:

    # "*Click*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:240
translate chinese SR4_Lily_SX_6c69c12b:

    # MC "(Perfect! It’s unlocked and ready to use! Sara will never catch us here.)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:244
translate chinese SR4_Lily_SX_d7d0af28:

    # Lily "Mmm, I’ve always wanted to fuck on the campus. It’s been my third favourite fantasy for as long as I can remember."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:246
translate chinese SR4_Lily_SX_2279f1a0:

    # Lily "There’s something so erotic about knowing you could get caught by one of your professors at any second. Or found by your fellow students who secretly film you and share the video around the whole campus."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:250
translate chinese SR4_Lily_SX_6512c233:

    # MC "Jesus. You really are a slut, aren’t you, Lily? If that’s your third favourite fantasy, then what’s the other two?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:252
translate chinese SR4_Lily_SX_097d41f4:

    # Lily "Oh, I thought that would have been pretty obvious by now, [player_name]."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:254
translate chinese SR4_Lily_SX_0835a6b9:

    # MC "Enlighten me."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:258
translate chinese SR4_Lily_SX_51c7b9e2:

    # Lily "Stealing someone’s boyfriend. I love the rush that comes from slowly seducing someone who I know is taken. That comes first."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:260
translate chinese SR4_Lily_SX_018f9d84:

    # MC "Ah, of course. I should have guessed."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:262
translate chinese SR4_Lily_SX_8e2d86b8:

    # Lily "Second is the risk of being impregnated and having my life ruined."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:266
translate chinese SR4_Lily_SX_4a1a6b94:

    # Lily "Does that make me a bad girl, [player_name]?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:268
translate chinese SR4_Lily_SX_a6b5e830:

    # MC "It certainly does."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:270
translate chinese SR4_Lily_SX_c35647f5:

    # Lily "I should probably be punished, shouldn’t I?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:272
translate chinese SR4_Lily_SX_2e1647f3:

    # MC "Oh, I’m going to punish you so fucking hard. Bend over the table and hike your skirt up. Let’s see that perfect little ass of yours."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:279
translate chinese SR4_Lily_SX_11ad55de:

    # Lily "Mmm... What are you planning to do to me, [player_name]?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:281
translate chinese SR4_Lily_SX_e83d8602:

    # MC "What do you WANT me to do to you?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:285
translate chinese SR4_Lily_SX_2654884f:

    # Lily "As far as I’m concerned, [player_name], nothing is off limits. Do your worst. Make me cum as hard as you possibly can."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:287
translate chinese SR4_Lily_SX_aeb28874:

    # MC "(Well, you can’t get any clearer consent than that!)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:291
translate chinese SR4_Lily_SX_a80603c8:

    # MC "(Those panties are so thin they barely cover her pussy!)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:295
translate chinese SR4_Lily_SX_b3110526:

    # MC "(Let’s start by getting this skirt out of the way.)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:299
translate chinese SR4_Lily_SX_173451ac:

    # MC "(Her ass looks amazing. I think I’ll begin by spanking her a bit to teach her a lesson for making me cheat on Sara like that.)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:301
translate chinese SR4_Lily_SX_4f87348b:

    # Sara "Are you planning to do something, [player_name]? Or are you just admiring the view?"
    Sara ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:305
translate chinese SR4_Lily_SX_457ba3fd:

    # MC "Hmm, I was thinking of just pulling your panties the side and fucking you right now."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:307
translate chinese SR4_Lily_SX_32ecdeb0:

    # Lily "Mmm, that sounds fun."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:309
translate chinese SR4_Lily_SX_321f1436:

    # MC "On second thoughts, I want you to strip. Completely."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:311
translate chinese SR4_Lily_SX_5b509ae6:

    # Lily "We’re on campus! What if someone walks in-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:313
translate chinese SR4_Lily_SX_870b5244:

    # MC "That’s a risk we’re going to take. You told me nothing was off limits - and getting naked on campus is a pretty tame request."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:317
translate chinese SR4_Lily_SX_d8049c0d:

    # Lily "How’s this? Happier now?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:319
translate chinese SR4_Lily_SX_ecb657e5:

    # MC "Ohh yeah!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:323
translate chinese SR4_Lily_SX_9f4d5295:

    # Lily "So, what happens now? Are you just gonna stare at me for a while longer?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:325
translate chinese SR4_Lily_SX_83da4b6c:

    # Lily "Maybe take out your phone and snap some compromising photos of my sexy body to jerk off to later?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:329
translate chinese SR4_Lily_SX_002032e4:

    # Lily "Or perhaps you’re going to fuck my tight teenage asshole?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:331
translate chinese SR4_Lily_SX_8784770f:

    # Lily "Or perhaps you’re going to fuck my tight little asshole?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:333
translate chinese SR4_Lily_SX_84e460b4:

    # Lily "Mmm! I bet you’d love that, wouldn’t you? Making me scream while you ravage my butthole with your fat cock?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:337
translate chinese SR4_Lily_SX_9ecebdd9:

    # MC "It sounds like you’d really enjoy me doing that. Wouldn’t you, Lily?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:339
translate chinese SR4_Lily_SX_d615d11a_1:

    # Lily "Uh huh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:341
translate chinese SR4_Lily_SX_98cd626f:

    # MC "You think I should punish you by ramming my cock into your tight ass and filling you up with cum?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:345
translate chinese SR4_Lily_SX_391f56d9:

    # Lily "God, yes! I’ve been such a bad girl! Hurry up and stick your dick in my-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:347
translate chinese SR4_Lily_SX_debde7e3:

    # MC "(She isn’t going to be expecting this!)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:355
translate chinese SR4_Lily_SX_20c73366:

    # "*Slap*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:356
translate chinese SR4_Lily_SX_b580b88c:

    # Lily "*GASP!*"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:359
translate chinese SR4_Lily_SX_20c73366_1:

    # "*Slap*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:361
translate chinese SR4_Lily_SX_016653ce:

    # Lily "Owie! Ah!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:365
translate chinese SR4_Lily_SX_11eff784:

    # MC "What’s wrong, Lily? I thought you were a bad girl who needed to be punished."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:367
translate chinese SR4_Lily_SX_1938c30a:

    # Lily "I wasn’t expecting you to-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:370
translate chinese SR4_Lily_SX_20c73366_2:

    # "*Slap*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:372
translate chinese SR4_Lily_SX_a05f1a9c:

    # Lily "Eeek!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:376
translate chinese SR4_Lily_SX_65b6fbe8:

    # MC "You’re such a bad girl for making me cheat on Sara like that."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:379
translate chinese SR4_Lily_SX_20c73366_3:

    # "*Slap*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:381
translate chinese SR4_Lily_SX_8c9ec2e0:

    # Lily "Ah! *GASP* Yes! I’m a naughty, slut! Punish me!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:385
translate chinese SR4_Lily_SX_b69a81d5:

    # Lily "*Pant* Please! Shove your cock in me!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:387
translate chinese SR4_Lily_SX_3a289c9a:

    # MC "Not yet, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:391
translate chinese SR4_Lily_SX_20c73366_4:

    # "*Slap*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:394
translate chinese SR4_Lily_SX_842adcfc:

    # Lily "*Gasp* Ow!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:398
translate chinese SR4_Lily_SX_12815253:

    # Lily "*Pant* Hurry up and fuck me, [player_name]! Please, don’t keep me waiting any longer!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:400
translate chinese SR4_Lily_SX_9bdfd120:

    # MC "You just can’t wait for me to plunge my cock inside you, can you?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:404
translate chinese SR4_Lily_SX_5049b89a:

    # Lily "No, I-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:407
translate chinese SR4_Lily_SX_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:409
translate chinese SR4_Lily_SX_4432b2bb:

    # Lily "Ayaaahhhh! Owie!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:413
translate chinese SR4_Lily_SX_dd920492:

    # MC "(Wow! That last slap left quite the red mark!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:415
translate chinese SR4_Lily_SX_cb82ef09:

    # Lily "*Pant* *Pant* Pleeeasse... stick it inside meee!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:419
translate chinese SR4_Lily_SX_c28b8a71:

    # Lily "I’m dripping wet right now, [player_name], I NEED you to fuck me!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:421
translate chinese SR4_Lily_SX_253b4482:

    # MC "Alright, here we go."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:425
translate chinese SR4_Lily_SX_f43d5c06:

    # Lily "Ah! Yeeesssss!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:427
translate chinese SR4_Lily_SX_22b2dc59:

    # MC "Mmm... (She wasn’t lying when she said she was dripping wet! Her pussy is soaking right now!)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:431
translate chinese SR4_Lily_SX_c930bf40:

    # Lily "Oh! Ah! AHHHH! YESSSS!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:433
translate chinese SR4_Lily_SX_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:435
translate chinese SR4_Lily_SX_6a8d44a7:

    # Lily "Say it! Say it again!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:437
translate chinese SR4_Lily_SX_8df7a2dc:

    # MC "Ugh! Say what?!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:441
translate chinese SR4_Lily_SX_83707826:

    # Lily "Tell me I’m ah... a better fuck than Sara! "
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:443
translate chinese SR4_Lily_SX_96470006:

    # MC "You’re a better fuck than Sara. Hnnng!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:446
translate chinese SR4_Lily_SX_5dff81d0:

    # Lily "Tell me my pussy ahhh... feels SOOOO much better than your dumb little sister’s! MMM!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:448
translate chinese SR4_Lily_SX_aff205ed:

    # Lily "Tell me my pussy ahhh... Feels SOOO much better than your dumb nerdy girlfriend's! MMM!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:451
translate chinese SR4_Lily_SX_9a363db4:

    # MC "Ugh! Arrgghhh! Ooohhh!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:455
translate chinese SR4_Lily_SX_d095037b:

    # MC "Your pussy feels so much better than ugh... my dumb little sister’s! *Pant* Hnnngg!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:457
translate chinese SR4_Lily_SX_cb4b1c9f:

    # MC "Your pussy feels so much better than ugh... my dumb nerdy girlfriend’s! *Pant* Hnnngg!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:461
translate chinese SR4_Lily_SX_f43d5c06_1:

    # Lily "Ah! Yeeesssss!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:463
translate chinese SR4_Lily_SX_1fc2ecd2:

    # Lily "Aaahh! Yes! Keep fucking me like this!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:467
translate chinese SR4_Lily_SX_f68a1368:

    # Lily "That silly ah... little bitch ohhh... doesn’t know I’m riding her man behind her back, does she?! Aahhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:469
translate chinese SR4_Lily_SX_6a8ae4af:

    # MC "(Jesus, I don’t know whether Lily or Sara is the bigger psycho out of the two of them!)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:471
translate chinese SR4_Lily_SX_30f55aec:

    # Lily "Oh! Mmmm! Aaahh! She doesn’t know I’m ahhh... fucking her man so much better than ayaaahhh... she ever did! OOHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:475
translate chinese SR4_Lily_SX_cac184a3:

    # MC "(A deep thrust ought to shut her up!)"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:477
translate chinese SR4_Lily_SX_c4185062:

    # Lily "AAYAAAHHHHHH!! I’M CUUUMMMMIIINNNG!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:479
translate chinese SR4_Lily_SX_9a363db4_1:

    # MC "Ugh! Arrgghhh! Ooohhh!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:482
translate chinese SR4_Lily_SX_ff7c563d:

    # Lily "God, your cock is sooohhhh fuuuckkking biiiig! Aaaahhhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:484
translate chinese SR4_Lily_SX_a22beecd:

    # MC "Hnnnngg..."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:486
translate chinese SR4_Lily_SX_4cbeb60c:

    # Lily "Ayaaahhhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:488
translate chinese SR4_Lily_SX_9c589d0e:

    # Lily "*Pant* *Pant* Wow... I’m done. I fucking came too many times."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:490
translate chinese SR4_Lily_SX_e69f0e66_1:

    # MC "Hnnng!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:493
translate chinese SR4_Lily_SX_6c8a9d53:

    # Lily "Oof! *Pant*"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:495
translate chinese SR4_Lily_SX_33b02cec:

    # MC "Here’s what’s going to happen next, Lily. I’m going to pin you down to this table, so every single thrust of my cock is hammering straight into your slutty g-spot."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:497
translate chinese SR4_Lily_SX_ccce8809:

    # Lily "*Pant* It’s w-way too sensitive right now! You can’t-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:501
translate chinese SR4_Lily_SX_4cbeb60c_1:

    # Lily "Ayaaahhhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:503
translate chinese SR4_Lily_SX_60fa1100:

    # MC "Oh really? If it’s feeling too intense for you right now, I have no idea how you’re going to handle it when I push myself balls deep and fill you up with my hot cum."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:505
translate chinese SR4_Lily_SX_dac3ac86:

    # Lily "*Gasp* Y-You can’t creampie me, I’ll-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:507
translate chinese SR4_Lily_SX_dab584d8:

    # MC "What do you mean “I can’t”? This is supposed to be a punishment, Lily. You’re the one who kept trying to seduce me."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:509
translate chinese SR4_Lily_SX_553ddb83:

    # Lily "OOHHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:511
translate chinese SR4_Lily_SX_1604b5c0:

    # MC "Besides, Sara’s pussy can handle me doing this perfectly fine. She lets me fill her up with my jizz any time I want."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:513
translate chinese SR4_Lily_SX_f6effd52:

    # Lily "Ahh! AHHHH!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:517
translate chinese SR4_Lily_SX_33d19e09:

    # Lily "Ohhhhh! W-Waaaiit! I- I’ve missed ahh... my ooohhh... pill for a couple of daaaayyhhhsss! Ayaaaahhh! You can’t cum inside meeeeehhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:519
translate chinese SR4_Lily_SX_605e3df5:

    # Lily "AHHH! I’m s-serrrrioouss! OOOHHHH!! I wasn’t- OOHHH! I wasn’t expecting to- AHHHH! -do this today! AAAHHHHHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:523
translate chinese SR4_Lily_SX_878afb3a:

    # MC "Oh no, you don’t get to do that, Lily. You don’t get to taunt and tease me for days about your tight teenage pussy, and then try to deny me filling you up when I finally want to!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:525
translate chinese SR4_Lily_SX_deb28ba5:

    # MC "Oh no, you don’t get to do that, Lily. You don’t get to taunt and tease me for days about your tight little pussy, and then try to deny me filling you up when I finally want to!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:527
translate chinese SR4_Lily_SX_d21b4cae:

    # Lily "Ah! Ah! AH! HOOOOOO!! OOOOHHHH!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:529
translate chinese SR4_Lily_SX_bb1f7714:

    # MC "Besides, you’re the one who told me one of your biggest fantasies was the risk of getting impregnated? If you GENUINELY haven’t taken your pills for a couple of days, then this should be exactly what you want - living out your darkest fantasy!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:531
translate chinese SR4_Lily_SX_4cbeb60c_2:

    # Lily "Ayaaahhhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:533
translate chinese SR4_Lily_SX_f4b49320:

    # MC "I bet you love it when I pull your hair like this, don’t you?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:535
translate chinese SR4_Lily_SX_8c27700f:

    # Lily "C-CUMMMMIIIINNNNG!! AYAAAAHHHH! *GASP* T-TOO INTENSE!! OOOHHHHHH!!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:539
translate chinese SR4_Lily_SX_2cfd3e52:

    # MC "This is how I’m going to punish you, Lily. Ugh! I’m going to pound you like this until every modicum of rational thought leaves your body. Hnnng!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:541
translate chinese SR4_Lily_SX_1e171a81:

    # Lily "Haaaaaahhhhh! OOOOHHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:543
translate chinese SR4_Lily_SX_fae7380d:

    # MC "I’m going to fuck you until your mind breaks, *Pant* and when the point comes that you can barely argh... string three words together, I’m going to empty my balls deep into your fertile little pussy. Ah! *Pant*"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:545
translate chinese SR4_Lily_SX_134e12b6:

    # Lily "AHHHHH! AHAHHHHH! NOOOOOTT INSSSHHIIIDDE!!! OOOHHHH!! NOT *PANT* *PANT* HAH! AH! AHH! AHHHH!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:547
translate chinese SR4_Lily_SX_c4735873:

    # MC "And... that sounds like my cue. Remember, Lily, if you want me to stop, all you have to do is string together three simple words, “Not inside me.”"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:549
translate chinese SR4_Lily_SX_588699ce:

    # Lily "NOOOOT INSHIDE! NOT! AHHHHH! HAAAAHH!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:551
translate chinese SR4_Lily_SX_22f064bd:

    # MC "Oh, Lily! You’re getting close! That was two words! This must feel REALLY good for you without a condom on! Or maybe it’s the threat of me impregnating you that’s getting you so hot and horny?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:553
translate chinese SR4_Lily_SX_4738d145:

    # Lily "NOT! HA! AAHHHHH! NO- N- HNNNNNNGGGG!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:557
translate chinese SR4_Lily_SX_42ba66ff:

    # MC "I bet you’re imagining my cock pulsing inside you right now. I bet you can’t shake the thought of millions of my sperm rushing deep into your body to fertilise your egg."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:559
translate chinese SR4_Lily_SX_208d313a:

    # Lily "Aaahhhh! Noooooooohhhhh!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:561
translate chinese SR4_Lily_SX_a68b61e1:

    # MC "Does it make it hotter when I have you *Pant* pinned down to the table like this? Does it make it hotter when you know you can’t escape? Ugh!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:563
translate chinese SR4_Lily_SX_efc0e735:

    # Lily "AAAHHHH! I’M CUMMMMMIIINNNNGG!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:565
translate chinese SR4_Lily_SX_4cf4bb39:

    # MC "C’mon Lily, just three words if you want me to pull out. Otherwise I’ll finish inside you and ruin your future the way you ruined my future with Sara."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:567
translate chinese SR4_Lily_SX_80ad6655:

    # Lily "(Holy fucking shit! This is turning me on sooooo much! Feeling him impregante me like this would feel soooo good, but do I really want to throw away my future for a few seconds of fun?)"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:569
translate chinese SR4_Lily_SX_d3b52cc4:

    # Lily "Ayaaahh! C-Cummming agaaaiiin! Haaaahhhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:576
translate chinese SR4_Lily_SX_6a9adc21:

    # Lily "Haaah! Ayaaahh! Y-You can’t- Ohhhh! D-Don’t... Oooohhhhhhh! MMMM!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:578
translate chinese SR4_Lily_SX_3e1aa699:

    # MC "I’m about to finish, Lily! Hnnnng! This is your last chance!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:580
translate chinese SR4_Lily_SX_21757416:

    # Lily "Ahhhh! N-Not inside me! NOT INSIDE ME! AYAAAAHHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:584
translate chinese SR4_Lily_SX_634153d4:

    # MC "Hnnngg! Ugh! Arrgghhhh! I’m cumming!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:586
translate chinese SR4_Lily_SX_f2288c7b:

    # Lily "(Oh fuck! He’s actually out! That was WAAAAY too close!)"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:590
translate chinese SR4_Lily_SX_9a363db4_2:

    # MC "Ugh! Arrgghhh! Ooohhh!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:592
translate chinese SR4_Lily_SX_277018bf:

    # Lily "*Pant* *Pant* Ohh..."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:602
translate chinese SR4_Lily_SX_a4375475:

    # Lily "(Holy crap! There’s a LOT of semen! I’m lucky he didn’t finish inside me!)"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:604
translate chinese SR4_Lily_SX_acbdcca8:

    # MC "Mmm, that was amazing, Lily. You’ve got a really tight pussy."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:608
translate chinese SR4_Lily_SX_66aa2ee0:

    # Lily "You weren’t ACTUALLY going to cum inside me if I couldn’t say those three words... right?"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:610
translate chinese SR4_Lily_SX_bf4bcf46:

    # MC "You weren’t ACTUALLY trying to make me cheat, when I visited your apartment... right?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:612
translate chinese SR4_Lily_SX_bf5be748:

    # Lily "Heh... Point taken."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:620
translate chinese SR4_Lily_SX_864c975a:

    # MC "Hnnnngg! Final chance, Lily!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:622
translate chinese SR4_Lily_SX_dd9b8b38:

    # Lily " Aaaahhh! HHAAAAAHHH! N-NOT- OOHHHHH! N-NO-! INSHIIIDDEE! HYEAAAHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:624
translate chinese SR4_Lily_SX_1a526d9c:

    # MC "I need to hear it Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:626
translate chinese SR4_Lily_SX_b3b8622c:

    # Lily "(Can’t... think... too much... pleasure!)"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:628
translate chinese SR4_Lily_SX_bce51736:

    # Lily "Ayaaaahhhhhhhhh!! I’m cuummmmiiiinggg!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:630
translate chinese SR4_Lily_SX_dd4363be:

    # MC "Suit yourself. Hnnnnggg! Ugh!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:635
translate chinese SR4_Lily_SX_b5c12d34:

    # Lily "(Cock.... twitching... inside me... he’s about to...)"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:645
translate chinese SR4_Lily_SX_4c16ae58:

    # Lily "OOHHHHHH!!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:647
translate chinese SR4_Lily_SX_e7a5feb0:

    # MC "Arrggh! Hnnnnggg! Ughhh!"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:649
translate chinese SR4_Lily_SX_ed1db6e1:

    # Lily "Shoooo hoooot! Oohhhhhh!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:653
translate chinese SR4_Lily_SX_89e23c65:

    # MC "Arrghh! Can you feel me filling you up? Hnnnng! You were too late, Lily! I’m impregnating you right now as you cum over my cock."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:655
translate chinese SR4_Lily_SX_c5254e92:

    # Lily "AAHHHHH! OHHHHH!!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:657
translate chinese SR4_Lily_SX_d4ea8531:

    # Lily "(Oh my God! This is so fucking hot! I can’t resist him!)"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:659
translate chinese SR4_Lily_SX_f70cfbe3:

    # Lily "AAAAHHHHH! CUMMMMIIINNNNGGG!"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:661
translate chinese SR4_Lily_SX_0e02ccc8:

    # Lily "*Pant* *Gasp* *Pant*"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:666
translate chinese SR4_Lily_SX_83a235c5:

    # MC "Did you enjoy that, Lily?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:668
translate chinese SR4_Lily_SX_f4350da7:

    # Lily "*Pant* Fu-Fucking amazing. *Pant* Ohhh..."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:670
translate chinese SR4_Lily_SX_6c53a7b3:

    # Lily "Y-You actually came inside me! If I actually get pregnant you could-"
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:672
translate chinese SR4_Lily_SX_716e7a80:

    # MC "I could what? Ruin your life for a while? Isn’t that EXACTLY what you tried to do to me when you seduced me into cheating on Sara?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:674
translate chinese SR4_Lily_SX_bf5be748_1:

    # Lily "Heh... Point taken."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:682
translate chinese SR4_Lily_SX_end_dd188a27:

    # MC "That was fantastic. We better get back to class though, before any of the professors or - God forbid - Sara, notices we’re missing."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:684
translate chinese SR4_Lily_SX_end_11a1ea39:

    # Lily "Hehe, you’re right. I don’t fancy the idea of having her trying to murder me again."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:688
translate chinese SR4_Lily_SX_end_2f324ead:

    # Lily "Y’know, I usually get bored with guys once I steal them from their girlfriends."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:690
translate chinese SR4_Lily_SX_end_8aff5831:

    # MC "Usually? Are you not getting bored with me?"
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:692
translate chinese SR4_Lily_SX_end_53eb2296:

    # Lily "Surprisingly not. I think the fact you’re still with Sara is making it even hotter for me."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:696
translate chinese SR4_Lily_SX_end_0c05f57e:

    # MC "You’re morally bankrupt, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:698
translate chinese SR4_Lily_SX_end_f288c263:

    # Lily "Hehe! I know! You should probably punish me when we meet up again."
    Lily ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:700
translate chinese SR4_Lily_SX_end_5a472716:

    # MC "You’re right, I probably should. Catch you later, Lily."
    MC ""

# game/scripts/SR4/3b_SR4_Lily_SX.rpy:702
translate chinese SR4_Lily_SX_end_fcaf6fe5:

    # Lily "See ya, [player_name]."
    Lily ""

translate chinese strings:

    # game/scripts/SR4/3b_SR4_Lily_SX.rpy:571
    old "Lily manages to pull herself together and tells you not to cum inside her."
    new ""

    # game/scripts/SR4/3b_SR4_Lily_SX.rpy:571
    old "Lily’s mind is far too pleasure-addled to string together three words in time. You empty your balls deep in her fertile wet pussy."
    new ""

