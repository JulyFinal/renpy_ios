﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/5_SR4_ES2.rpy:43
translate chinese SR4_ES2_8c8675b1:

    # MC "(I really hope Macy is able to talk to Sara soon. Lily is safe as long as she doesn't show her face on campus, but that isn’t a realistic permanent solution.)"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:45
translate chinese SR4_ES2_e8fe2378:

    # MC "(Plus, sooner or later Sara is going to get desperate enough to show up to Lily’s house and attack her there.)"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:47
translate chinese SR4_ES2_9116f2bd:

    # MC "Ugh... (What the fuck am I supposed to do?)"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:51
translate chinese SR4_ES2_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/5_SR4_ES2.rpy:53
translate chinese SR4_ES2_560530a4:

    # MC "I’m not dressed! Who is it?"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:55
translate chinese SR4_ES2_61a339c8:

    # Sara "Just me, [player_name]... Are you free to talk?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:59
translate chinese SR4_ES2_eeffa9a3:

    # MC "Y-Yeah, Sara! C’mon in!"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:61
translate chinese SR4_ES2_adcb1850:

    # MC "(Her voice didn’t sound too angry there.)"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:66
translate chinese SR4_ES2_0b45f7db:

    # MC "Hey Sara, what’s up? How’re you keeping?"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:68
translate chinese SR4_ES2_80324b9b:

    # Sara "I’m fine. I just... I needed to talk. You aren’t busy, are you?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:72
translate chinese SR4_ES2_53f6b377:

    # MC "No, not at all! I always have time for my little sister."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:73
translate chinese SR4_ES2_4ca4663f:

    # Sara "Thanks, bro."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:76
translate chinese SR4_ES2_df643755:

    # MC "No, not at all! I always have time for my girlfriend."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:77
translate chinese SR4_ES2_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:84
translate chinese SR4_ES2_d62a0afd:

    # MC "You, uh, seem a bit more relaxed today. Are you feeling better?"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:86
translate chinese SR4_ES2_411bf4fb:

    # Sara "A bit, I think I may have... slightly... overreacted. I think I owe you an apology."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:90
translate chinese SR4_ES2_cb90e31d:

    # MC "It’s alright, sis. C’mon and sit down beside me."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:92
translate chinese SR4_ES2_4c7cf00a:

    # MC "It’s alright, Sara. C’mon and sit down beside me."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:96
translate chinese SR4_ES2_2eb32a64:

    # MC "Did something happen? Last time I saw you I was getting the silent treatment, and Lily was about to get stabbed. Haha!"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:98
translate chinese SR4_ES2_a1678b9e:

    # Sara "Heh, yeah... That was... Umm... I kinda went a little bit psycho, didn’t I?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:100
translate chinese SR4_ES2_e675a79a:

    # MC "Just a little bit."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:104
translate chinese SR4_ES2_858b91b0:

    # Sara "I’m sorry. I just got so jealous at the thought of Lily stealing you away from me."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:106
translate chinese SR4_ES2_ff2aa5b4:

    # MC "She’s not going to steal me away. "
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:108
translate chinese SR4_ES2_9078f863:

    # Sara "Yeah, I know that now. Macy called me."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:112
translate chinese SR4_ES2_0fe02d85:

    # MC "Macy rang you? What did she say?"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:114
translate chinese SR4_ES2_90e8d5b4:

    # Sara "Lily is bisexual, she offered to send Macy some lewd pictures of herself. Macy decided to prank Lily by giving your number instead of her own."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:118
translate chinese SR4_ES2_90091ef8:

    # MC "Ahh! Is that what happened? That makes a whole lot of sense."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:120
translate chinese SR4_ES2_1ebc636d:

    # MC "(Clever girl, Macy. I wouldn’t have thought of that one myself!)"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:122
translate chinese SR4_ES2_8986974c:

    # Sara "So yeah, I kinda owe you an apology for giving you the silent treatment. I really thought you were cheating on me."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:126
translate chinese SR4_ES2_5e07a3f7:

    # MC "It’s okay, Sara. I’d never cheat on you."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:128
translate chinese SR4_ES2_9cf407ff:

    # Sara "I know that now."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:131
translate chinese SR4_ES2_a36d4253:

    # MC "You should probably apologise to Lily too."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:135
translate chinese SR4_ES2_8681799e:

    # Sara "Ugh... Do I HAVE to?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:137
translate chinese SR4_ES2_898f4395:

    # MC "You DID threaten to kill her. Repeatedly. With a knife. The LEAST you can do right now is call Lily and tell her that you’re no longer going to stab her."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:139
translate chinese SR4_ES2_8684eb14:

    # Sara "Hmmph. Fine."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:141
translate chinese SR4_ES2_e289ce74:

    # MC "Thanks, Sara."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:145
translate chinese SR4_ES2_50a47e31:

    # MC "(God, her ass is so hot in those tight pink panties.)"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:149
translate chinese SR4_ES2_0c25652f:

    # Sara "Hey... [player_name]?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:151
translate chinese SR4_ES2_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:153
translate chinese SR4_ES2_179974ad:

    # Sara "I’m sorry again for being so paranoid about Lily. I was being stupid."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:157
translate chinese SR4_ES2_d361c395:

    # MC "Haha, don’t sweat it, Sara. I’ve NEVER cheated on you with Lily, and there’s no way I ever could."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:161
translate chinese SR4_ES2_75b43d95:

    # Sara "I love you, [player_name]."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:163
translate chinese SR4_ES2_155d56f2:

    # MC "I love you too, Sara. Now, hurry up and call Lily. She’s probably locked herself up in her apartment, afraid that you’re going to show up and murder her."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:167
translate chinese SR4_ES2_03739b7a:

    # Sara "Haha! Maybe I’ll leave her stewing for another hour... See you later, bro."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:169
translate chinese SR4_ES2_a041f800:

    # Sara "Haha! Maybe I’ll leave her stewing for another hour... See you later, [player_name]."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:171
translate chinese SR4_ES2_6652fdf4:

    # MC "Goodnight, Sara."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:176
translate chinese SR4_ES2_f1f2c107:

    # Sara "Wait a minute... How do you know Lily lives in an apartment?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:180
translate chinese SR4_ES2_2c9a62fe:

    # MC "Wh-What?"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:184
translate chinese SR4_ES2_bedbfa95:

    # Sara "You said, “she’s probably locked herself up in her apartment.”"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:186
translate chinese SR4_ES2_ad1cbd64:

    # Sara "Bro... How do you know she lives in an apartment?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:188
translate chinese SR4_ES2_f45236ad:

    # Sara "[player_name]... How do you know she lives in an apartment?"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:192
translate chinese SR4_ES2_b3b6d2fe:

    # MC "I... I know she... lives in an apartment... because..."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:196
translate chinese SR4_ES2_7f68bb64:

    # MC "...whenever... I was..."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:198
translate chinese SR4_ES2_68c3bf8d:

    # MC "...going... th-through... the... um..."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:200
translate chinese SR4_ES2_abd023e9:

    # MC "...student attendance records I saw her address! Celia put me in detention to help her sort out student records, and I saw her address! She lives in those apartment blocks."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:204
translate chinese SR4_ES2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:206
translate chinese SR4_ES2_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:210
translate chinese SR4_ES2_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:212
translate chinese SR4_ES2_abd287a1_1:

    # Sara "..."
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:216
translate chinese SR4_ES2_1ba25b3a:

    # Sara "Oh my God... Are you serious?! I can’t believe it!"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:218
translate chinese SR4_ES2_3af43baa:

    # MC "Sara, I- I-"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:222
translate chinese SR4_ES2_3ac8b0a0:

    # Sara "I can’t believe Celia is so fucking dumb that she left you alone with the student attendance records! Those are supposed to be, like, super confidential!"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:224
translate chinese SR4_ES2_d906f7a9:

    # Sara "That’s a massive GDPR breach, haha!"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:228
translate chinese SR4_ES2_f3a94bc8:

    # MC "Ha... Ha... Y-Yeah! It *Gulp* definitely is!"
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:232
translate chinese SR4_ES2_a29290c1:

    # Sara "Night, bro!"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:234
translate chinese SR4_ES2_69f4ebe4:

    # Sara "Night, [player_name]!"
    Sara ""

# game/scripts/SR4/5_SR4_ES2.rpy:238
translate chinese SR4_ES2_6652fdf4_1:

    # MC "Goodnight, Sara."
    MC ""

# game/scripts/SR4/5_SR4_ES2.rpy:240
translate chinese SR4_ES2_a67962b5:

    # MC "(Fucking hell, that was WAY too close...)"
    MC ""

