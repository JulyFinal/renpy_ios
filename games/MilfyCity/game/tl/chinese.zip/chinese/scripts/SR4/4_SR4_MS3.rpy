﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/4_SR4_MS3.rpy:34
translate chinese SR4_MS3_24a97cb4:

    # MC "(Alright, hopefully Macy will be able to give me a hand smoothing things over between Sara and Lily.)"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:36
translate chinese SR4_MS3_bc087ed5:

    # MC "(I don’t actually know if Sara and Macy hang out that much - but I don’t really have any other options open to me right now.)"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:40
translate chinese SR4_MS3_e9f8eac6:

    # MC "Hey Macy."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:42
translate chinese SR4_MS3_187873e7:

    # Macy "Oh, hi [player_name]! Did you manage to speak with Lily in the end?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:44
translate chinese SR4_MS3_ff8b5ec7:

    # MC "Yeah, I did. That’s actually why I’m back here today. I kinda need your help for something. Things have gotten a little messed up."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:48
translate chinese SR4_MS3_e91819b2:

    # Macy "Oh no! What happened?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:50
translate chinese SR4_MS3_c057fa8f:

    # MC "So, uh... God, there’s quite a lot to explain."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:52
translate chinese SR4_MS3_fa1a223c:

    # Macy "How about you take a seat and just start at the beginning?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:56
translate chinese SR4_MS3_f13bdfbd:

    # MC "Alright... So, it all began when Sara, Lily and I played spin the bottle together."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:58
translate chinese SR4_MS3_cec6f659:

    # Macy "Hold up, isn’t that the game where you have to kiss whoever the bottle points to?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:60
translate chinese SR4_MS3_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:64
translate chinese SR4_MS3_a524da0e:

    # Macy "Ahd isn’t Sara your..."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:67
translate chinese SR4_MS3_99f3ccec:

    # Macy "Sara, Lily and You..?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:69
translate chinese SR4_MS3_752fb6c4:

    # MC "Yep... That’s what I'm talking about."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:71
translate chinese SR4_MS3_96c60d2f:

    # Macy "Ah... I’m curious... Did any of you actually... y’know?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:75
translate chinese SR4_MS3_abb86f50:

    # MC "*Sigh* This is gonna get a bit embarrassing for me. Can you try to hear me out until the end?"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:79
translate chinese SR4_MS3_a2a404cc:

    # Macy "Alright! What happened after you all played spin the bottle?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:85
translate chinese SR4_MS3_d26fc3ed:

    # MC "So, that brings us to today..."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:89
translate chinese SR4_MS3_af30a34f:

    # Macy "So... You screwed Sara in the ass?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:91
translate chinese SR4_MS3_cb715547:

    # MC "Did you miss the part when I said that she was LITERALLY planning to murder Lily?!"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:95
translate chinese SR4_MS3_82e84e9c:

    # Macy "But... you like, fucked her butt?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:97
translate chinese SR4_MS3_23207776:

    # MC "*Sigh* I feel like you’re focusing on the wrong part of the story here. Lily interrupted our date, and then she sent us a dirty picture. I can’t understate how livid Sara is right now."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:101
translate chinese SR4_MS3_250644ed:

    # Macy "I got it, don’t worry. And you going to visit Lily didn’t help smooth things over?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:105
translate chinese SR4_MS3_348d96d6:

    # MC "Not in the slightest. Sara rang Lily when I was there. I heard her screaming over the phone."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:107
translate chinese SR4_MS3_a07646a3:

    # Macy "Oof."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:109
translate chinese SR4_MS3_6bc1a320:

    # MC "I don’t know how close you are with Sara, but I really need someone to throw me a lifeline here. She’s gonna either end up murdering Lily or me unless we talk her out of it."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:113
translate chinese SR4_MS3_5222736e:

    # Macy "Right... You really got yourself into a bit of a tangle here, didn’t you, [player_name]?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:115
translate chinese SR4_MS3_b32dd846:

    # MC "Tell me about it."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:117
translate chinese SR4_MS3_4225cb19:

    # Macy "I think I’ve got a plan. I’m not sure if Sara will buy it, but I promise you that I’ll give it a go."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:121
translate chinese SR4_MS3_8be28345:

    # MC "Thanks Macy, you’re a lifesaver!"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:123
translate chinese SR4_MS3_f47868f6:

    # Macy "Haha, don’t thank me yet. Sara and I haven’t spoken that often, so I’m not sure if it’ll work."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:125
translate chinese SR4_MS3_cdd6890a:

    # MC "Well, I appreciate you trying anyway."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:127
translate chinese SR4_MS3_2b8c6e8f:

    # Macy "Umm, do you think you could do one thing for me in return?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:129
translate chinese SR4_MS3_3921914a:

    # MC "Sure, what do you need?"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:130
translate chinese SR4_MS3_0be77fa6:

    # Macy "I’ve liked you for quite a while now, [player_name]. But, it’s pretty clear that nothing is going to happen between us, with Sara in the picture."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:132
translate chinese SR4_MS3_ef11e803:

    # Macy "I want you to give me a taste of what it would have been like. Just a couple of minutes so I know what could have been."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:136
translate chinese SR4_MS3_437c3613:

    # MC "(Macy is right that I can’t add another woman to the mix now, given how unstable Sara has been. There’s no harm in indulging Macy’s fantasy of pretending to be her boyfriend for a couple of minutes though.)"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:138
translate chinese SR4_MS3_f500b4e6:

    # MC "Of course, Macy."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:140
translate chinese SR4_MS3_367b0877:

    # MC "You look beautiful today. Your eyes are the most beautiful shade of emerald. Have you any plans for after class?"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:142
translate chinese SR4_MS3_7c4205ac:

    # Macy "*Gulp* N-Nothing yet."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:144
translate chinese SR4_MS3_0c4d004c:

    # MC "How about we go bowling tonight, then? We can grab some ice cream and take a walk along the promenade afterwards."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:148
translate chinese SR4_MS3_8bfd8ca9:

    # Macy "I’d love that."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:150
translate chinese SR4_MS3_a45979f9:

    # MC "My parents are away tonight as well, so if you want to come over we could do our coursework in my room together?"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:152
translate chinese SR4_MS3_5c9b4ff7:

    # MC "I'm on my own tonight, as well, so if you want to come over we could do our coursework in my room together?"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:153
translate chinese SR4_MS3_34012e04:

    # Macy "Coursework? Really? Do you really think I’m gonna fall for that trick a second time?"
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:157
translate chinese SR4_MS3_52c173f3:

    # MC "Aw, c’mon - you enjoyed making out topless with me."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:159
translate chinese SR4_MS3_a85d14f8:

    # Macy "Okay, I’ll see you after class, then. Bowling by the promenade. "
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:161
translate chinese SR4_MS3_ca78f07b:

    # MC "I’ll see you then."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:165
translate chinese SR4_MS3_a2316a2e:

    # Macy "..."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:167
translate chinese SR4_MS3_6b21f19e:

    # Macy "Thank you for indulging my weird request, [player_name]. I just didn’t want to look back in ten years wondering what it would have felt like."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:169
translate chinese SR4_MS3_eaadda93:

    # MC "You enjoyed it?"
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:171
translate chinese SR4_MS3_a1308d96:

    # Macy "I really did. Perhaps we ended up together in another life? Maybe we did those walks along the promenade with our ice cream."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:175
translate chinese SR4_MS3_969a622a:

    # MC "I like to imagine that we did."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:177
translate chinese SR4_MS3_3d164935:

    # Macy "Thank you, [player_name]. I’ll speak to Sara whenever I get the chance."
    Macy ""

# game/scripts/SR4/4_SR4_MS3.rpy:181
translate chinese SR4_MS3_50f902a2:

    # MC "I really appreciate this, Macy."
    MC ""

# game/scripts/SR4/4_SR4_MS3.rpy:183
translate chinese SR4_MS3_5e22d22f:

    # Macy "(Okay Macy... it’s time for you to move on and stop pining over a guy who’s completely unavailable.)"
    Macy ""

