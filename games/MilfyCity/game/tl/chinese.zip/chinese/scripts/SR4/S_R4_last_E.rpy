﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/S_R4_last_E.rpy:27
translate chinese S_R4_last_E_44679468:

    # MC "(I should have guessed I’d find her chilling out in here! Sara has a whole lot more free time now that all her major exams are out of the way.)"
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:29
translate chinese S_R4_last_E_a770cdcb:

    # MC "Evening Sara, what’s up?"
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:31
translate chinese S_R4_last_E_af8b4572:

    # Sara "Oh! Hey there, [player_name]! I didn’t hear you come in!"
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:32
translate chinese S_R4_last_E_ed70d9ef:

    # MC "Heh, sorry, didn’t mean to startle you. I just wanted to check how you were doing."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:34
translate chinese S_R4_last_E_1a6e8474:

    # Sara "Yeah, I’m great! Waaay more relaxed now that the exams are over."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:35
translate chinese S_R4_last_E_f756f9d4:

    # MC "Good to hear."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:37
translate chinese S_R4_last_E_930ee12d:

    # MC "Oh, have you heard from Lily lately?"
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:38
translate chinese S_R4_last_E_3390478c:

    # Sara "Yeah, we’re probably gonna hit the mall together next week."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:39
translate chinese S_R4_last_E_6899d21c:

    # MC "Good to hear you two are back together again! I wasn’t sure you two would ever be on speaking terms again after everything that went down."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:41
translate chinese S_R4_last_E_97b584e5:

    # Sara "Yeah... I did kinda go a little bit psycho back then, didn’t I?"
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:42
translate chinese S_R4_last_E_fa5cbaa7:

    # MC "Haha, just a little."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:44
translate chinese S_R4_last_E_8343e540:

    # Sara "It was weird, because I felt SO certain that there was SOMETHING going on between the two of you."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:45
translate chinese S_R4_last_E_48c3b6d7:

    # Sara "I can’t quite put my finger on it, but something just felt... off."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:47
translate chinese S_R4_last_E_eda28e73:

    # Sara "ANYWAY, I know now that I was just being paranoid and silly."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:48
translate chinese S_R4_last_E_f24bc1ab:

    # MC "That’s alright, Sara. Lily was a bit inappropriate when she interrupted our date anyway. I think you were justified in being angry at the time."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:50
translate chinese S_R4_last_E_0b77bca0:

    # Sara "Thanks, [player_name]. It means a lot to hear you say that."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:51
translate chinese S_R4_last_E_7bd8ab10:

    # MC "Of course. I really love you, Sara. I’d never cheat on you with anyone. Not with Lily, and not with any other girl."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:53
translate chinese S_R4_last_E_9f6e92f2:

    # Sara "I know that now. I love you too, [player_name]. So soooooooo much!"
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:54
translate chinese S_R4_last_E_34d74964:

    # Sara "You know... you could drop by my room tonight if you want. Or maybe give me a call and I can creep over to yours?"
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:55
translate chinese S_R4_last_E_5f9e89b9:

    # MC "That sounds good to me. Let’s wait til night."
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:56
translate chinese S_R4_last_E_9e004259:

    # Sara "Okay!"
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:58
translate chinese S_R4_last_E_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/SR4/S_R4_last_E.rpy:59
translate chinese S_R4_last_E_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/SR4/S_R4_last_E.rpy:71
translate chinese S_R4_last_E_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

