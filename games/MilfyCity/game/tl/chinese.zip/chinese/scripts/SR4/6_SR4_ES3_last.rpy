﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/6_SR4_ES3_last.rpy:202
translate chinese SR4_ES3_a646901d:

    # Sara "Not now, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:213
translate chinese SR4_ES3_1e2a789c:

    # MC "(Looks like Sara’s taking a break and reading in bed. It’s nice to see her doing something other than playing video games for a change.)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:215
translate chinese SR4_ES3_328516ff:

    # MC "(She seems a lot calmer now than she was last week. That drama with Lily really drove her over the edge.)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:221
translate chinese SR4_ES3_4ef3a2e6:

    # MC "Hey Sara, how’re you keeping?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:223
translate chinese SR4_ES3_2c04d20e:

    # Sara "Hmm?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:227
translate chinese SR4_ES3_932979d2:

    # Sara "Oh, hey [player_name]! I didn’t hear you come in, there."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:229
translate chinese SR4_ES3_8b3e7f0f:

    # MC "It must be a good book then! What are you reading?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:231
translate chinese SR4_ES3_57e98d6a:

    # Sara "It's one of the required texts for my English course. I'm trying to limit my game time in the evening. I'll become a less nerdy girl, [player_name]! Haha!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:235
translate chinese SR4_ES3_979cf62a:

    # Sara "Plus... I really need to get my head screwed on. I’m gonna be graduating soon, and I need solid grades if I want a half-decent job."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:237
translate chinese SR4_ES3_ff3862fd:

    # MC "True. It’s good to see you studying. Keep at it."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:239
translate chinese SR4_ES3_4ca4663f:

    # Sara "Thanks, bro."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:241
translate chinese SR4_ES3_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:245
translate chinese SR4_ES3_84b1846e:

    # MC "(Looks like she’s either forgotten to wear panties, or just couldn’t be bothered.)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:247
translate chinese SR4_ES3_b1801590:

    # MC "(In either case, it’s a win for me!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:251
translate chinese SR4_ES3_321be1f4:

    # Sara "So, what brings you here?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:253
translate chinese SR4_ES3_0b362d6a:

    # MC "I actually just wanted to check how things are between you and Lily."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:255
translate chinese SR4_ES3_065ea3b9:

    # Sara "They’re fine. We still hang out on campus together, get lunch, go to coffee shops. I get that it was all one big misunderstanding now."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:257
translate chinese SR4_ES3_b72de37a:

    # MC "Well, that’s a relief."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:259
translate chinese SR4_ES3_fea945c3:

    # Sara "I know, it really is."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:263
translate chinese SR4_ES3_fc0545f9:

    # Sara "Haha! What are you doing, [player_name]?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:266
translate chinese SR4_ES3_f22faeb9:

    # MC "I think you’ve been studying hard enough. It’s time to relax a bit."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:268
translate chinese SR4_ES3_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:272
translate chinese SR4_ES3_9c5f4ed7:

    # MC "There we go, that’s much better, isn’t it? Goodness me, no bra either?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:274
translate chinese SR4_ES3_54dac722:

    # Sara "What can I say? I was too hot."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:276
translate chinese SR4_ES3_857e033b:

    # MC "You’re always hot, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:278
translate chinese SR4_ES3_52b1c4e6:

    # Sara "Hehe! Stop it!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:282
translate chinese SR4_ES3_7d90c80f:

    # Sara "Is anyone else home? Should we be quiet or can go hard?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:284
translate chinese SR4_ES3_7085e8eb:

    # MC "I’m not sure, I think so. I’m pretty sure Caroline is. Maybe Mom too."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:285
translate chinese SR4_ES3_55c0570e:

    # Sara "We’ll have to be quiet then. I hate to think how long she’d ground me if she caught us two fucking."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:287
translate chinese SR4_ES3_583146d8:

    # MC "I’m not sure, I think so. I’m pretty sure Caroline is. Maybe Linda too."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:289
translate chinese SR4_ES3_d5c5a4de:

    # Sara "We'll have to be quiet then. We don't want them to come here and disturb us..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:293
translate chinese SR4_ES3_95b99913:

    # Sara "C’mon, it’s hardly fair that I’m the only one who is naked here! Get those pants off!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:295
translate chinese SR4_ES3_36206cb8:

    # MC "Alright, alright! Hold on..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:299
translate chinese SR4_ES3_30a868aa:

    # Sara "Mmm... You look so hot when you’re naked, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:301
translate chinese SR4_ES3_ec61d277:

    # MC "So do you, Sara. I love the freckles on your face."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:305
translate chinese SR4_ES3_c5e90053:

    # Sara "Okay, so what should we do?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:307
translate chinese SR4_ES3_d00d675a:

    # MC "What are you up for?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:309
translate chinese SR4_ES3_1cdcc7d3:

    # Sara "Oral, anal, regular sex. You choose tonight."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:313
translate chinese SR4_ES3_135f0ca2:

    # MC "Well, in that case I think..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:320
translate chinese SR4_ES3_ea0f3fc9:

    # MC "...you’re pretty good at sucking cock now, Sara. How about you give me a blowjob tonight?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:326
translate chinese SR4_ES3_1a1ac53e:

    # Sara "Of course, [player_name]. You know I’d do anything for you. All you have to do is ask."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:328
translate chinese SR4_ES3_02102ed4:

    # MC "I love you, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:330
translate chinese SR4_ES3_e25b899f:

    # Sara "I love you too, bro."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:332
translate chinese SR4_ES3_368b48b9:

    # Sara "I love you too, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:336
translate chinese SR4_ES3_25697fe9:

    # Sara "Sorry again for going a bit crazy with Lily. I just kinda flipped out at the thought of her stealing you from me."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:338
translate chinese SR4_ES3_2f9a550b:

    # Sara "I really don’t know what I’d do without you. You’re the best thing that’s happened to me in, like, forever."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:342
translate chinese SR4_ES3_c7e12049:

    # MC "You’re the best thing that’s happened to me too, sis."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:344
translate chinese SR4_ES3_212af094:

    # MC "You’re the best thing that’s happened to me too."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:346
translate chinese SR4_ES3_23256d3b:

    # Sara "I’m gonna try my hardest to give you the best blowjob ever today, [player_name]. I REALLY hope you enjoy it!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:350
translate chinese SR4_ES3_7e662d41:

    # MC "I’m sure I will, Sara. How about you start off by kissing the tip?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:352
translate chinese SR4_ES3_90d909d0:

    # Sara "Sure!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:357
translate chinese SR4_ES3_8122815f:

    # MC "(I’m so glad that nonsense with Lily is sorted. She almost came between me and Sara.)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:359
translate chinese SR4_ES3_af8fcdbb:

    # MC "(This is nice. It reminds me of the early days when Sara used to give me really awkward blowjobs. She was so inexperienced, she could barely fit my cock in her mouth at the time!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:361
translate chinese SR4_ES3_9879b588:

    # MC "(This is nice. It reminds me of the early days when Sara used to give me really messy blowjobs! That was cute and funny, and she could barely fit my cock in her mouth at the time!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:364
translate chinese SR4_ES3_9064fdf4:

    # MC "(It certainly didn’t stop her from trying though!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:366
translate chinese SR4_ES3_676817a4:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:368
translate chinese SR4_ES3_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:372
translate chinese SR4_ES3_1dd292c8:

    # Sara "*Lick* *Lick*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:375
translate chinese SR4_ES3_398276ad:

    # MC "Ah... God... Just like that, sis. Mmm..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:377
translate chinese SR4_ES3_3a3b1ef6:

    # MC "Ah... God... Just like that, Sara. Mmm..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:381
translate chinese SR4_ES3_e8fddfeb:

    # MC "Mmm! I love it when you use your tongue like that. Ah..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:383
translate chinese SR4_ES3_31decd1b:

    # Sara "*Liiiiick* *Liiiiick*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:385
translate chinese SR4_ES3_24563497:

    # MC "Ooohh..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:389
translate chinese SR4_ES3_3cad6a41:

    # Sara "*Shlurp* *Suck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:391
translate chinese SR4_ES3_267a2e4a:

    # MC "Ooohhh! Mmmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:393
translate chinese SR4_ES3_f07c3ceb:

    # Sara "(It’s still quite difficult to take his big dick in my mouth, but I really wanna try my best for him.)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:397
translate chinese SR4_ES3_5335aada:

    # Sara "*Shlurrp* *Suck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:399
translate chinese SR4_ES3_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:401
translate chinese SR4_ES3_0dee306c:

    # Sara "*Suck* *Suck"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:405
translate chinese SR4_ES3_a3dabb5e:

    # MC "(She looks so cute when she’s trying to act all determined like that!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:407
translate chinese SR4_ES3_e6c0df81:

    # Sara "*Shluuurrrp* *Suuucck* Mmpppffff!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:411
translate chinese SR4_ES3_8fa69db0:

    # Sara "Hmmpff! *Suck* Mmpff! Mmm! *Suck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:413
translate chinese SR4_ES3_b334e72f:

    # MC "Hnnngg... Oohhh..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:417
translate chinese SR4_ES3_24f38da5:

    # MC "Mmmm! That feels so fucking good, Sara. I can’t help but notice you’re having a little difficulty taking more of it in your mouth though."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:419
translate chinese SR4_ES3_e72072cd:

    # MC "Y’know, it might be easier if you took your hand off my cock and grabbed my ass instead. You could try and pull yourself forward."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:423
translate chinese SR4_ES3_3cad6a41_1:

    # Sara "*Shlurp* *Suck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:425
translate chinese SR4_ES3_fa320d2c:

    # Sara "(I’m barely making it past the tip right now, but I want to see if I can do this myself!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:429
translate chinese SR4_ES3_ec1de8b8:

    # Sara "*Gloompfff!* *Gag* Hmmpfff! *SUUUCK*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:432
translate chinese SR4_ES3_fe07d739:

    # MC "OOHHH! Mmmmm! Your throat is so fucking tight, Sara!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:434
translate chinese SR4_ES3_8fa69db0_1:

    # Sara "Hmmpff! *Suck* Mmpff! Mmm! *Suck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:440
translate chinese SR4_ES3_7ee7ca8f:

    # Sara "*Shlurp* *Suck* *Suck* Mmppff! *Gag*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:442
translate chinese SR4_ES3_5b528ba6:

    # MC "Hnnng...."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:446
translate chinese SR4_ES3_a649f0cd:

    # Sara "*Gag*... *Gag* *Splutter*... *Shluuurrp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:448
translate chinese SR4_ES3_de5a5e85:

    # Sara "(I can’t hold my face down much longer... I think I’m gonna have to do what [player_name] suggested and wrap my hands behind him while I suck his cock.)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:450
translate chinese SR4_ES3_fdaabcc8:

    # MC "Mmmm..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:454
translate chinese SR4_ES3_9a00b903:

    # Sara "*Suck* *Suck* *Shlurp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:456
translate chinese SR4_ES3_4df9e459:

    # MC "OOHHHHH!! Mmmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:458
translate chinese SR4_ES3_4994b88d:

    # MC "Mmm! Fuck, you’re sucking like a pro, Sara! Hnnnngg!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:462
translate chinese SR4_ES3_eab63265:

    # Sara "*Shlurp* *Suck* Mmpfff!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:464
translate chinese SR4_ES3_75b34c1e:

    # MC "*Pant* Mmm... God, you’re fucking amazing at this."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:466
translate chinese SR4_ES3_803eb2cc:

    # MC "I never imagined my little sister would make *Pant* such an incredible cocksucker. Ooohh..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:468
translate chinese SR4_ES3_211d7d15:

    # MC "I never imagined my girlfriend would make *Pant* such an incredible cocksucker. Ooohh..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:472
translate chinese SR4_ES3_c39853f1:

    # Sara "*Glompf* *Shlurp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:474
translate chinese SR4_ES3_8c1cc617:

    # Sara "(I’m getting all wet when he compliments me like that!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:478
translate chinese SR4_ES3_eedffd37:

    # Sara "*Shlurp* *Suck* *Suck* *Suuuuuck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:480
translate chinese SR4_ES3_e46a9bf5:

    # MC "Hnnnngg! Ooohhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:483
translate chinese SR4_ES3_40140d6e:

    # MC "Alright Sara, let’s see how deep you can take my dick. I want to feel how tight my little sister’s throat really is."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:485
translate chinese SR4_ES3_e17c3911:

    # MC "Alright Sara, let’s see how deep you can take my dick. I want to feel how tight your throat really is."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:487
translate chinese SR4_ES3_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:489
translate chinese SR4_ES3_90b25ab3:

    # MC "Think you can do it?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:491
translate chinese SR4_ES3_e99a036c:

    # Sara "*Suck* *Suuuuck* *Suuuuuuuuccck*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:493
translate chinese SR4_ES3_d096eabd:

    # Sara "(Crap! This is super hard! How on Earth do they make it look so easy in porn?!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:495
translate chinese SR4_ES3_3c755ef9:

    # MC "Hnnngg..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:499
translate chinese SR4_ES3_73cfed14:

    # Sara "*SUUUCK* *GAG*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:501
translate chinese SR4_ES3_2260fe0a:

    # MC "Hnnnng! Arrrghhh.... *Pant* Oh wow... Mmmm! That’s it, keep going, Sara! *Pant* You can go deeper!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:503
translate chinese SR4_ES3_020eebb0:

    # Sara "(My jaw won’t go any wider! How am I supposed to do this?!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:505
translate chinese SR4_ES3_72331b8a:

    # Sara "*Gag* *Splutter* *Cough* *Shluurrrrp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:507
translate chinese SR4_ES3_d2cf13ee:

    # Sara "(Almost there... C’mon! Just another couple of inches...)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:511
translate chinese SR4_ES3_164c3dfc:

    # MC "Hnnnngg! Aahhh! Fuuuck!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:513
translate chinese SR4_ES3_e884a38d:

    # Sara "*SHLUUURRRP* *GAG*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:515
translate chinese SR4_ES3_15effab2:

    # Sara "(YES! I did it! I felt it slip down my throat! I really did it!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:517
translate chinese SR4_ES3_91f8fa86:

    # MC "*Pant* Mmm! I can feel my cock sliding down the back of your throat. Mmm! Fuck, this is amazing!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:521
translate chinese SR4_ES3_a5151852:

    # MC "*Pant* Hnnngg... I’m gonna cum, sis! *Pant* I’m about to cum!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:523
translate chinese SR4_ES3_aa78e530:

    # MC "*Pant* Hnnngg... I’m gonna cum, Sara! *Pant* I’m about to cum!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:529
translate chinese SR4_ES3_391e741b:

    # MC "*Pant* Keep sucking, Sara! Don’t stop! I’m gonna cum!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:531
translate chinese SR4_ES3_47e78cff:

    # Sara "*Shlurp* *GAG* *Shlurrrrp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:533
translate chinese SR4_ES3_38c26c19:

    # MC "Hnnngg!! Aarrgghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:543
translate chinese SR4_ES3_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:545
translate chinese SR4_ES3_c64b7a66:

    # Sara "(Holy crap! His cock’s twitching in my mouth! I can feel him cumming!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:547
translate chinese SR4_ES3_0339f93e:

    # Sara "*SHLUURP* *Gag* *Gloompfff*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:550
translate chinese SR4_ES3_858071dc:

    # MC "Ugh! Argh! Hnnnnggg!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:552
translate chinese SR4_ES3_ff1b9a4a_1:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:556
translate chinese SR4_ES3_52b0c082:

    # Sara "*Gasp* *Cough* *Splutter* H-How was *Cough* it?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:558
translate chinese SR4_ES3_e0dd366f:

    # MC "*Pant* It was absolutely *Pant* incredible, Sara You’ve gotten WAY better at this since we first started dating."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:560
translate chinese SR4_ES3_ff1b9a4a_2:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:564
translate chinese SR4_ES3_231de335:

    # Sara "R-Really?!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:566
translate chinese SR4_ES3_9603e07f:

    # MC "Oh yeah, you’re absolutely amazing. You’re the best girlfriend I could possibly ask for."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:568
translate chinese SR4_ES3_6944b6bd:

    # Sara "Yay! Haha! It makes me so happy to hear you say that, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:575
translate chinese SR4_ES3_c5efcdc4:

    # MC "I’m about to cum! Can you finish me off with your hand?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:579
translate chinese SR4_ES3_3b1ab346:

    # Sara "Sure, [player_name]. Just like this?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:581
translate chinese SR4_ES3_b45ba2e4:

    # MC "Mmm... God, that’s fucking perfect. Hnnng..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:583
translate chinese SR4_ES3_7a99f84a:

    # Sara "Do you like it when I rub your balls like this?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:585
translate chinese SR4_ES3_b3e12243:

    # MC "Oh yeah... Mmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:587
translate chinese SR4_ES3_39396dd5:

    # Sara "Cum for me, [player_name]. Cum all over my fac-"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:597
translate chinese SR4_ES3_f688c3c8:

    # MC "Arrgghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:599
translate chinese SR4_ES3_1207ee4a:

    # Sara "Eek!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:603
translate chinese SR4_ES3_256ed2aa:

    # MC "Hnnngg! I’m cumming! Aarrrghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:605
translate chinese SR4_ES3_bbf42ad6:

    # Sara "WHOA!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:609
translate chinese SR4_ES3_e481007c:

    # Sara "That... certainly came out quicker than I was anticipating it would."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:611
translate chinese SR4_ES3_3425ba35:

    # MC "Haha, yeah... *Pant* I wasn’t expecting you to massage my balls at the same time, it really helped me finish."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:613
translate chinese SR4_ES3_348856a0:

    # Sara "Hehe! You enjoyed it, then!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:615
translate chinese SR4_ES3_8206da56:

    # MC "Absolutely! It was amazing, Sara!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:617
translate chinese SR4_ES3_9b78d4d8:

    # Sara "Yay! I’m really happy to hear that!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:625
translate chinese SR4_ES3_26f3b4ee:

    # MC "*Pant* Hnnng! I’m gonna cum! Open wide and stick your tongue out!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:629
translate chinese SR4_ES3_785fc9f7:

    # Sara "Like this? Aaahhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:631
translate chinese SR4_ES3_f285eb84:

    # MC "Hnnng! Yes! Perfect! Aarghhh! *Pant* Just keep stroking! Arrghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:641
translate chinese SR4_ES3_31f0123c:

    # MC "Hnnngg! Oohhhhh! Fuck! *Pant* Ahhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:643
translate chinese SR4_ES3_105013ae:

    # Sara "(Oh wow! That’s a LOT of semen!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:647
translate chinese SR4_ES3_9dd3b841:

    # MC "Ugh! Arrghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:649
translate chinese SR4_ES3_4cbbf71d:

    # Sara "(Here it comes!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:653
translate chinese SR4_ES3_40b196fb:

    # MC "*Pant* *Pant* That was so fucking hot..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:655
translate chinese SR4_ES3_e2b91507:

    # Sara "(Hmm, very salty!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:659
translate chinese SR4_ES3_11a2758b:

    # Sara "Well? Did you enjoy it, [player_name]?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:661
translate chinese SR4_ES3_2aa88f0d:

    # MC "*Pant* It was absolutely amazing, Sara. You’re getting really good at sucking dick."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:663
translate chinese SR4_ES3_0bccc190:

    # Sara "Hehe! I’m glad you enjoyed it!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:671
translate chinese SR4_ES3_d83091f2:

    # MC "...we’ve gotten pretty good at anal, haven’t we? Do you want to give it another go?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:673
translate chinese SR4_ES3_020f57c0:

    # Sara "Sure, why not?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:675
translate chinese SR4_ES3_caaf736d:

    # MC "How about you lie back on your desk? We’ll try a different position today."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:682
translate chinese SR4_ES3_2229efde:

    # Sara "Just like this?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:684
translate chinese SR4_ES3_8a28b937:

    # MC "That’s perfect, Sara. I get to look into your eyes while I fuck your ass this time."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:686
translate chinese SR4_ES3_8e465825:

    # MC "What’s wrong? You’re covering your face."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:690
translate chinese SR4_ES3_ca30e4c7:

    # Sara "Nothing... I’m just a little shy."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:692
translate chinese SR4_ES3_fb1b3718:

    # MC "We’ve done anal before, there’s not much to be shy about!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:694
translate chinese SR4_ES3_18b17175:

    # Sara "I know, but... it was always on a roof, or late at night, or from behind. It’s embarrassing watching you look at my asshole like that."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:698
translate chinese SR4_ES3_5925f09d:

    # MC "Well, I think you’ve got a very sexy asshole. I’m looking forward to slowly pushing my cock inside and spreading you open."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:700
translate chinese SR4_ES3_da40e8b6:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:704
translate chinese SR4_ES3_e9a65211:

    # MC "I’m looking forward to burrowing my shaft into your tight hole and feeing your ass clench around me as you squirm."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:706
translate chinese SR4_ES3_0ec5b397:

    # MC "I’m looking forward to the little sounds you make. The gasps, the moans, the tiny squeaks of pleasure you give."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:710
translate chinese SR4_ES3_f9f5ddcf:

    # Sara "*Gasp* Eek!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:712
translate chinese SR4_ES3_8c34a2ae:

    # MC "Mmm! And I love how much easier anal is getting with you. Look at that, it’s sliding right in without any lube now."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:714
translate chinese SR4_ES3_1aa768d3:

    # Sara "Oh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:718
translate chinese SR4_ES3_f058c7e4:

    # Sara "*Pant* Ah! Ohh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:720
translate chinese SR4_ES3_7048c665:

    # MC "Does it hurt?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:722
translate chinese SR4_ES3_ddf70148:

    # MC "Do you want me to stop? Sara?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:724
translate chinese SR4_ES3_42ad4ab7:

    # Sara "*Pant* N-No! Not anymore..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:728
translate chinese SR4_ES3_9e3e6c6f:

    # MC "Hnnng! Ugh! There we go! *Pant* That’s the tip in!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:730
translate chinese SR4_ES3_f9af1359:

    # Sara "*Pant* J-Just the tip?!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:732
translate chinese SR4_ES3_e4440701:

    # MC "Come on, it wasn’t as bad as last time, was it?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:736
translate chinese SR4_ES3_de348b48:

    # Sara "I... I guess not. It didn’t really hurt this time."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:738
translate chinese SR4_ES3_7f442f7a:

    # Sara "I... I guess not. It really was more pleasant this time."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:740
translate chinese SR4_ES3_24943927:

    # MC "You’re getting used to it now. It’s probably going to be even easier for you to cum from anal, going forward."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:744
translate chinese SR4_ES3_517b47fd:

    # Sara "I know... I’m looking forward to it, [player_name]... You will then want to fuck my ass every day, am I right?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:746
translate chinese SR4_ES3_029bae99:

    # MC "Oh yeah, definitely. Once your body adjusts to the size of my dick and learns to ignore the pain, you can start focusing on the pleasure."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:748
translate chinese SR4_ES3_b2e4fc0c:

    # MC "Oh yeah, definitely. You can finally start focusing on the pleasure, cutie."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:752
translate chinese SR4_ES3_ca99462b:

    # Sara "uh! Cool! I’m actually kind of looking forward to this now, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:754
translate chinese SR4_ES3_55ff0bd3:

    # MC "Trust me, you’re gonna love it when we get started."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:758
translate chinese SR4_ES3_142526ea:

    # MC "Are you ready for me to start thrusting now?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:762
translate chinese SR4_ES3_2e994e0b:

    # Sara "Y-Yeah, I think so."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:766
translate chinese SR4_ES3_285fe75e:

    # MC "Alright, here we go..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:768
translate chinese SR4_ES3_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:770
translate chinese SR4_ES3_2218d69b:

    # Sara "*Gasp* Ah..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:774
translate chinese SR4_ES3_38c97939:

    # Sara "(I can feel his cock stretching my ass as he goes deeper!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:776
translate chinese SR4_ES3_2e052b5c:

    # MC "Mmm... You’re so fucking tight, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:780
translate chinese SR4_ES3_6d09218d:

    # Sara "*Gasp* Ah! Ooohhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:784
translate chinese SR4_ES3_16c70088:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:785
translate chinese SR4_ES3_6ac4ba2b:

    # Sara "*Pant* No, it’s... *Pant* feeling really intense! Kinda like when you *Gasp* bought me that vibrator!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:787
translate chinese SR4_ES3_19cfc187:

    # MC "Ah... Are you feeling the same pleasure as I am?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:789
translate chinese SR4_ES3_f90c994b:

    # Sara "*Pant* Yep.. Ahh... *Pant* feeling relly intense! Kinda like when you *Gasp* bought me the strongest vibrator on the market!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:793
translate chinese SR4_ES3_46d4beec:

    # MC "Hnnng... I’m about halfway there now. I’m just gonna keep taking it slowly until we’re done."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:795
translate chinese SR4_ES3_78812bd4:

    # Sara "Oohh... My knees are getting all weak [player_name]! Ahh! *Pant* It feels so- Ah!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:799
translate chinese SR4_ES3_e86062d5:

    # Sara "Ayaahhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:801
translate chinese SR4_ES3_21558e3e:

    # MC "(I think she’s cumming! Her butt is tightening around my dick!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:803
translate chinese SR4_ES3_5ea0298c:

    # Sara "Haahh! Oohhhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:807
translate chinese SR4_ES3_c94a4523:

    # MC "That’s me fully in now, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:809
translate chinese SR4_ES3_93f108c3:

    # Sara "*Pant* Ooohhh..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:811
translate chinese SR4_ES3_077a9481:

    # MC "Hehe, did you just cum from me sticking it in?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:815
translate chinese SR4_ES3_49750748:

    # Sara "Yeah... Yes... My whole body just started *Pant* trembling and... *Pant*"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:817
translate chinese SR4_ES3_f195ac6e:

    # Sara "*Gulp* It felt REALLY different to the orgasms from when you put it in my pussy though."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:819
translate chinese SR4_ES3_f566ac56:

    # MC "Good to hear! Why don’t you try holding your legs up high for the next part?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:823
translate chinese SR4_ES3_133a23c0:

    # Sara "Like this? Why?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:825
translate chinese SR4_ES3_8878dea8:

    # Sara "Like this? You’re a perv, [player_name]..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:827
translate chinese SR4_ES3_19789340:

    # MC "It’ll make it easier for me to fuck you deeper. Plus, you look waaay hotter when you do that."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:829
translate chinese SR4_ES3_64bd9212_1:

    # Sara "Hehe!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:833
translate chinese SR4_ES3_76c6e721:

    # MC "Hnnng... Ugh..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:837
translate chinese SR4_ES3_09ad1790:

    # Sara "*Pant* Oohh... Mmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:841
translate chinese SR4_ES3_d7c86935:

    # MC "Mmm! Argh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:843
translate chinese SR4_ES3_809af35f:

    # Sara "Ah! Ah! Oohhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:847
translate chinese SR4_ES3_b4c2b23e:

    # Sara "(Wow... It’s mesmerising watching his dick slide in and out of my ass like that!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:849
translate chinese SR4_ES3_35722d7b:

    # Sara "(And it feels soooo goooood! My whole body is trembling right now! Each time he thrusts his hips forward it shakes my whole world!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:851
translate chinese SR4_ES3_089304f1:

    # Sara "Ahh! AHHHH!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:855
translate chinese SR4_ES3_1c2f0d27:

    # MC "*Pant* You’re cumming again?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:857
translate chinese SR4_ES3_f29554ca:

    # Sara "S-Sorry! I can’t help it, I’m- oohhhhh! It’s sooo intense! Ahhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:861
translate chinese SR4_ES3_e8011809:

    # MC "That’s okay, you cum as much as you want, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:863
translate chinese SR4_ES3_76125af5:

    # Sara "Haaahhh! Ahhhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:865
translate chinese SR4_ES3_4a9ca6d1:

    # MC "Hnnngg! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:870
translate chinese SR4_ES3_f9950b7a:

    # Sara "W-Wait! Ah! It’s *Gasp* getting too much! Can we- *Pant* Can we switch up positions?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:872
translate chinese SR4_ES3_0f82a22a:

    # MC "Sure, what do you want to do?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:876
translate chinese SR4_ES3_993b1ece:

    # Sara "Can we try it from behind? Like we did that night on the roof?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:878
translate chinese SR4_ES3_d172cd4d:

    # MC "Doggy style? No problem. Let’s use your chair to support you."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:882
translate chinese SR4_ES3_201fccd0:

    # MC "How’s that? Comfortable?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:884
translate chinese SR4_ES3_3505abd7:

    # Sara "Yeah! I think so!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:888
translate chinese SR4_ES3_19ee37c3:

    # MC "(Her tight teen ass looks so fuckable from this angle. God, I can’t wait to pound it even harder now!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:890
translate chinese SR4_ES3_c392296b:

    # MC "(Her tight ass looks so fuckable from this angle. God, I can’t wait to pound it even harder now!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:892
translate chinese SR4_ES3_dc558305:

    # MC "(I’m going to fuck her tight little ass as fast as I possibly can!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:896
translate chinese SR4_ES3_2f7ea2ef:

    # Sara "Ready when you are, [player_name]!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:900
translate chinese SR4_ES3_45cd8432:

    # MC "Alright, coming now."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:904
translate chinese SR4_ES3_df597b37:

    # Sara "(When is he going to put it in? He’s been standing back there staring at my ass for aaaggges now!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:906
translate chinese SR4_ES3_ff112ba1:

    # Sara "C’mon, [player_name]. Don’t make me wait much longe-"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:908
translate chinese SR4_ES3_4a9ca6d1_1:

    # MC "Hnnngg! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:911
translate chinese SR4_ES3_f3199038:

    # Sara "Ooohhhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:913
translate chinese SR4_ES3_3c755ef9_1:

    # MC "Hnnngg..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:917
translate chinese SR4_ES3_26ce2aa8:

    # Sara "Ah! Yes! Stick it inside me! Fill me up with your big cock!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:919
translate chinese SR4_ES3_85ae232b:

    # MC "(Okay, let’s give her what she wants. One massive thrust!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:923
translate chinese SR4_ES3_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:925
translate chinese SR4_ES3_aca531ec:

    # Sara "Ayaahhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:927
translate chinese SR4_ES3_cfb00b1f:

    # MC "Ugh! Hnnngg!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:931
translate chinese SR4_ES3_9bb890f8:

    # MC "Argh! Hnnng! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:932
translate chinese SR4_ES3_5650fb45:

    # "*Slap* *Slap* *Slap*"
    ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:934
translate chinese SR4_ES3_3d8088b4:

    # Sara "Ohhh! Ahh! Ahhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:938
translate chinese SR4_ES3_96dc78aa:

    # "*SLAP* *SLAP* *SLAP*"
    ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:940
translate chinese SR4_ES3_8328e449:

    # Sara "AYAAHHHHH! AH! AHH! OOOOHHHHH!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:942
translate chinese SR4_ES3_07bca4e5:

    # Sara "(He’s thrusting so hard against me! I can feel his thighs slapping against my ass!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:946
translate chinese SR4_ES3_e4ae8f3b:

    # Sara "Ah! Ahhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:948
translate chinese SR4_ES3_1120c91a:

    # MC "Hnnng! Ugh! Oohhh fuuuuck!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:950
translate chinese SR4_ES3_3d8088b4_1:

    # Sara "Ohhh! Ahh! Ahhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:953
translate chinese SR4_ES3_38ee1973:

    # Sara "Oohhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:955
translate chinese SR4_ES3_5650fb45_1:

    # "*Slap* *Slap* *Slap*"
    ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:957
translate chinese SR4_ES3_416d3143:

    # Sara "*Pant* B-Bro! Ah! AHHHHHHH!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:959
translate chinese SR4_ES3_27ccb774:

    # Sara "*Pant* [player_name]! Ah! AHHHHHHH!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:963
translate chinese SR4_ES3_a60f96d7:

    # Sara "Yessss! I’m cumming! I’m cummmmiiinnnng! Ayaaahhhhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:965
translate chinese SR4_ES3_9863890a:

    # MC "Ohhh! *Pant* Argh! Mmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:969
translate chinese SR4_ES3_5650fb45_2:

    # "*Slap* *Slap* *Slap*"
    ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:971
translate chinese SR4_ES3_471e3c1e:

    # Sara "Doooohn’t stoooohhhp! Aaahhhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:975
translate chinese SR4_ES3_61221b81:

    # MC "Hnnnng! *Pant* I can’t keep this up much longer, Sara. Where do you *Pant* want me to finish?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:977
translate chinese SR4_ES3_d23051ee:

    # Sara "Ah! Ahh! Wh-Wherever you want, brooooooo! Aaahhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:979
translate chinese SR4_ES3_e0deb412:

    # Sara "Ah! Ahh! Wh-Wherever you want, [player_name]! Aaahhhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:986
translate chinese SR4_ES3_4e7c132d:

    # MC "Hnnngg... I’m cumming! Arrghh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:988
translate chinese SR4_ES3_f871f5d7:

    # Sara "*Gasp* Me tooo! Aaahhhh! I love you, bro! Ooohhhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:992
translate chinese SR4_ES3_0213b640:

    # MC "Argh! *Pant* Ooohhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:994
translate chinese SR4_ES3_9764035e:

    # Sara "*Gasp* Aaahhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:996
translate chinese SR4_ES3_cf315a6e:

    # Sara "(I can feel his hot cum filling me up! It’s like a warmth spreading deep inside me!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1006
translate chinese SR4_ES3_6c88d66e:

    # MC "*Pant* Ohh... God... That was amazing."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1008
translate chinese SR4_ES3_85973c05:

    # Sara "*Pant* *Pant* Y-Yeah, it was... incredible."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1012
translate chinese SR4_ES3_bf1557de:

    # MC "*Pant* Oh wow... Your ass looks so hot with my semen trickling out of it."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1014
translate chinese SR4_ES3_6c771b17:

    # Sara "Hehe, that’s embarrassing! Stop looking!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1016
translate chinese SR4_ES3_d9cb038f:

    # MC "You’ve got nothing to be embarrassed about, Sara. You’re really fucking hot."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1018
translate chinese SR4_ES3_43417f87:

    # Sara "Hehe..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1026
translate chinese SR4_ES3_8ab772c1:

    # MC "Hnnngg... I’m about to cum! I’m gonna pull out."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1028
translate chinese SR4_ES3_c72e1df5:

    # Sara "*Gasp* Yes! Cum for me, bro!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1032
translate chinese SR4_ES3_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1034
translate chinese SR4_ES3_ed6de2d1:

    # Sara "Cum for me!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1038
translate chinese SR4_ES3_79375ff3:

    # MC "Arrghhh! Hnnnng! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1049
translate chinese SR4_ES3_d35d4bfe:

    # MC "*Pant* Ohhhh! Mmmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1051
translate chinese SR4_ES3_a1945b9f:

    # Sara "Mmm... Cum all over my butt, bro!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1055
translate chinese SR4_ES3_0b8d9e9d:

    # MC "*Pant* That was... *Pant* sooo good, Sara!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1057
translate chinese SR4_ES3_2b112029:

    # Sara "Yeah, it was! I loved the part when you told me to hold my legs up. It just got waaay more intense!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1059
translate chinese SR4_ES3_2afaedd3:

    # MC "I noticed that. You were shaking so hard when I fucked you like that! It’s good you’re enjoying anal more now."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1061
translate chinese SR4_ES3_8fcc4977:

    # Sara "Yeah, I’m really happy to be doing it with you now. It’s not sore or uncomfortable like it was at the start."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1063
translate chinese SR4_ES3_7a50504d:

    # Sara "Thanks for being patient with me, bro."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1065
translate chinese SR4_ES3_ea02f168:

    # MC "No problem, sis. You were worth waiting for."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1073
translate chinese SR4_ES3_4e7c132d_1:

    # MC "Hnnngg... I’m cumming! Arrghh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1075
translate chinese SR4_ES3_ca873aea:

    # Sara "*Gasp* Me tooo! Aaahhhh! I love you, [player_name]! Ooohhhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1079
translate chinese SR4_ES3_0213b640_1:

    # MC "Argh! *Pant* Ooohhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1081
translate chinese SR4_ES3_9764035e_1:

    # Sara "*Gasp* Aaahhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1083
translate chinese SR4_ES3_cf315a6e_1:

    # Sara "(I can feel his hot cum filling me up! It’s like a warmth spreading deep inside me!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1093
translate chinese SR4_ES3_6c88d66e_1:

    # MC "*Pant* Ohh... God... That was amazing."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1095
translate chinese SR4_ES3_85973c05_1:

    # Sara "*Pant* *Pant* Y-Yeah, it was... incredible."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1099
translate chinese SR4_ES3_bf1557de_1:

    # MC "*Pant* Oh wow... Your ass looks so hot with my semen trickling out of it."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1101
translate chinese SR4_ES3_6c771b17_1:

    # Sara "Hehe, that’s embarrassing! Stop looking!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1103
translate chinese SR4_ES3_d9cb038f_1:

    # MC "You’ve got nothing to be embarrassed about, Sara. You’re really fucking hot."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1105
translate chinese SR4_ES3_43417f87_1:

    # Sara "Hehe..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1113
translate chinese SR4_ES3_8ab772c1_1:

    # MC "Hnnngg... I’m about to cum! I’m gonna pull out."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1115
translate chinese SR4_ES3_4af59922:

    # Sara "*Gasp* Yes! Cum for me, [player_name]!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1119
translate chinese SR4_ES3_6ab31951_1:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1121
translate chinese SR4_ES3_ed6de2d1_1:

    # Sara "Cum for me!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1125
translate chinese SR4_ES3_79375ff3_1:

    # MC "Arrghhh! Hnnnng! Ugh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1136
translate chinese SR4_ES3_d35d4bfe_1:

    # MC "*Pant* Ohhhh! Mmmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1138
translate chinese SR4_ES3_fb422cb5:

    # Sara "Mmm... Cum all over my butt, [player_name]!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1142
translate chinese SR4_ES3_0b8d9e9d_1:

    # MC "*Pant* That was... *Pant* sooo good, Sara!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1144
translate chinese SR4_ES3_2b112029_1:

    # Sara "Yeah, it was! I loved the part when you told me to hold my legs up. It just got waaay more intense!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1146
translate chinese SR4_ES3_2afaedd3_1:

    # MC "I noticed that. You were shaking so hard when I fucked you like that! It’s good you’re enjoying anal more now."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1148
translate chinese SR4_ES3_6f4778be:

    # Sara "Yeah, I'm really happy to be doing it with you now. It's now pleasant..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1150
translate chinese SR4_ES3_f1525d46:

    # Sara "Thanks for being patient with me, [player_name]."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1152
translate chinese SR4_ES3_59cf912a:

    # MC "No problem, Sara. You were worth waiting for."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1166
translate chinese SR4_ES3_pussy_92d74b93:

    # MC "...I’d like to fuck your tight teen pussy tonight. How does that sound?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1168
translate chinese SR4_ES3_pussy_f17d1667:

    # MC "...I’d like to fuck your tight pussy tonight. How does that sound?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1170
translate chinese SR4_ES3_pussy_077ea86b:

    # Sara "Okay! On the bed or...?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1172
translate chinese SR4_ES3_pussy_f0c026d8:

    # MC "How about you bend over the table there?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1179
translate chinese SR4_ES3_pussy_2229efde:

    # Sara "Just like this?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1181
translate chinese SR4_ES3_pussy_13b47032:

    # MC "That’s perfect."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1185
translate chinese SR4_ES3_pussy_3aafb603:

    # Sara "Okay... You DO have a condom, right?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1187
translate chinese SR4_ES3_pussy_9c397e69:

    # MC "Do we really need one now that we’re boyfriend and girlfriend?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1189
translate chinese SR4_ES3_pussy_275c2389:

    # Sara "Huh... I guess not?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1193
translate chinese SR4_ES3_pussy_3e89019c:

    # MC "Exactly! Besides, see how good it feels completely raw?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1195
translate chinese SR4_ES3_pussy_1f793de6:

    # Sara "Mmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1197
translate chinese SR4_ES3_pussy_0be9bf31:

    # MC "You’d lose some of that pleasure if I stopped to put on a condom. It just isn’t worth it."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1201
translate chinese SR4_ES3_pussy_d62fab00:

    # Sara "*Gulp* Okay, if you’re sure..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1203
translate chinese SR4_ES3_pussy_96387539:

    # MC "Of course I am."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1207
translate chinese SR4_ES3_pussy_260599e7:

    # Sara "Oohhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1209
translate chinese SR4_ES3_pussy_6f8c81ac:

    # MC "Mmm... How’s that?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1211
translate chinese SR4_ES3_pussy_062e6830:

    # Sara "*Gasp* Mmm! It’s good!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1215
translate chinese SR4_ES3_pussy_fbeed3bd:

    # MC "Alright, I’m going to slide it in now."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1217
translate chinese SR4_ES3_pussy_f90e1c85:

    # Sara "Ah! Mmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1221
translate chinese SR4_ES3_pussy_1aa768d3:

    # Sara "Oh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1223
translate chinese SR4_ES3_pussy_d7cb6dff:

    # MC "Ah... There we go. Your pussy feels amazing, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1225
translate chinese SR4_ES3_pussy_e8026f31:

    # Sara "Ah! Ah! Ah!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1228
translate chinese SR4_ES3_pussy_6cbe6880:

    # MC "Ohh! Mmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1230
translate chinese SR4_ES3_pussy_f90e1c85_1:

    # Sara "Ah! Mmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1234
translate chinese SR4_ES3_pussy_8dee5df0:

    # Sara "B-Bro! A-Are you sure we shouldn’t ooohh... use a condom?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1236
translate chinese SR4_ES3_pussy_085a37cf:

    # Sara "A-Are you sure we shouldn’t ooohh... use a condom?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1238
translate chinese SR4_ES3_pussy_2bd980c0:

    # MC "Relax, Sara. It’ll be fine. Hnnng! Just try and enjoy the moment!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1240
translate chinese SR4_ES3_pussy_2f761772:

    # Sara "It’s just that..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1242
translate chinese SR4_ES3_pussy_70fa4e90:

    # MC "How about I fuck you extra hard? Will that make you forget your worries?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1246
translate chinese SR4_ES3_pussy_8568aa67:

    # Sara "Ah! Ah! Ah! OOooOoooOOOHHHH!!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1248
translate chinese SR4_ES3_pussy_be8d3ed5:

    # MC "(I guess that worked!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1250
translate chinese SR4_ES3_pussy_c28b9128:

    # Sara "(Hoooollly shit! This feels soooo goood! It’s like my brain’s melting!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1254
translate chinese SR4_ES3_pussy_52c95c6f:

    # Sara "Ahhh! Ahhh! Yeessssss! Ooohhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1256
translate chinese SR4_ES3_pussy_49469797:

    # MC "See? Mmm! Much better without some rubber getting in the way. Ohh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1258
translate chinese SR4_ES3_pussy_018969f9:

    # Sara "Yessss! *Pant* Ahhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1262
translate chinese SR4_ES3_pussy_c59c86d6:

    # Sara "Ah! Ooohhh! Deeeeper! Ayaaahhhh! I’m cummmiinnng!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1264
translate chinese SR4_ES3_pussy_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1268
translate chinese SR4_ES3_pussy_17595564:

    # Sara "Oh my God! YESSSSS!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1270
translate chinese SR4_ES3_pussy_1f514653:

    # MC "Shush! If you don’t keep your voice down someone’s gonna hear us! Haha!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1272
translate chinese SR4_ES3_pussy_d9cb0998:

    # Sara "S-Sorry, it’s soooooo goood! I caaaahhn’t help myself! Aaahhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1276
translate chinese SR4_ES3_pussy_2218d1c2:

    # Sara "Ah! Ah! Ah! Faaaahhhssster, broooohhhh! Yeessss! Screw me! Aaahhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1278
translate chinese SR4_ES3_pussy_ba2dfd82:

    # Sara "Ah! Ah! Ah! Faaaahhhssster! Yeessss! Screw me! Aaahhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1280
translate chinese SR4_ES3_pussy_a48d0838:

    # MC "Mmmm! Hnnng!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1284
translate chinese SR4_ES3_pussy_54157304:

    # Sara "Oh! Ahh! AHhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1286
translate chinese SR4_ES3_pussy_c8b944e0:

    # MC "Hnnnngg! Arrghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1290
translate chinese SR4_ES3_pussy_e4c951f7:

    # Sara "Yes! Yesss! Harder, [player_name]! Ayaaahhhhhhh!! I’m cummmmiiinnngg!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1292
translate chinese SR4_ES3_pussy_bb331ba8:

    # MC "*Pant* Hnnng! Ugh! *Pant* Oh... Ah..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1294
translate chinese SR4_ES3_pussy_54157304_1:

    # Sara "Oh! Ahh! AHhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1297
translate chinese SR4_ES3_pussy_dc0c7fe1:

    # MC "*Pant* How... *Pant* How about you *Pant* take over, Sara? I’m running *Pant* out of breath here."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1299
translate chinese SR4_ES3_pussy_9b930881:

    # Sara "Aww, okay."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1301
translate chinese SR4_ES3_pussy_a0e46de1:

    # MC "I’m gonna *Pant* take a seat on the couch, try riding me from on top."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1305
translate chinese SR4_ES3_pussy_335ccaa9:

    # Sara "How’s this? Are you comfy?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1307
translate chinese SR4_ES3_pussy_0901e826:

    # MC "Mmm, yeah this is perfect."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1311
translate chinese SR4_ES3_pussy_89e448df:

    # Sara "Hehe, I’ve never thought of trying it from this angle before!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1313
translate chinese SR4_ES3_pussy_0e815002:

    # MC "First time for me too! Hope it feels good for you."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1317
translate chinese SR4_ES3_pussy_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1319
translate chinese SR4_ES3_pussy_a2063dd1:

    # Sara "Ahmmmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1321
translate chinese SR4_ES3_pussy_fe08e61e:

    # MC "(Sara’s barely moving! My cock hasn’t even entered her pussy. She’s taking her sweet time!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1325
translate chinese SR4_ES3_pussy_9e4bbef5:

    # Sara "Ah... Ooohh..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1327
translate chinese SR4_ES3_pussy_42f5ec98:

    # MC "Are you not gonna start riding me?"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1329
translate chinese SR4_ES3_pussy_4c920ce7:

    # Sara "Mmm, just savouring the moment when your dick first slides inside. It’s my favourite ah... part!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1333
translate chinese SR4_ES3_pussy_d7aabd05:

    # Sara "Ooohhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1335
translate chinese SR4_ES3_pussy_2bb1cef6:

    # MC "Mmm... *Pant*"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1337
translate chinese SR4_ES3_pussy_e18805dc:

    # Sara "Ahh..."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1341
translate chinese SR4_ES3_pussy_c196cec6:

    # Sara "*Gasp* I love the feeling of mmm... your cock slowly parting my vulva. Ahhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1343
translate chinese SR4_ES3_pussy_7e7fef97:

    # Sara "It’s like when you put on your ah... favourite movie and that moment when ooohh... the opening soundtrack you love just hits you."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1345
translate chinese SR4_ES3_pussy_a2063dd1_1:

    # Sara "Ahmmmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1347
translate chinese SR4_ES3_pussy_e95a0b3a:

    # Sara "And then, the pleasure just keeps building and building until your dick finally ahhh... slips mmm... inside!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1351
translate chinese SR4_ES3_pussy_618449f9:

    # Sara "*GASP* Ooohhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1353
translate chinese SR4_ES3_pussy_10899030_1:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1355
translate chinese SR4_ES3_pussy_504d4c1b:

    # Sara "Mmm! I love it when it fills me up like that!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1359
translate chinese SR4_ES3_pussy_a4af9407:

    # Sara "*Pant* And the sensation of it slowly leaving my body, stimulating ah... every part inside me! Oohhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1361
translate chinese SR4_ES3_pussy_3a05e4c5:

    # MC "Ah... Keep going, Sara."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1365
translate chinese SR4_ES3_pussy_99bffbfe:

    # Sara "*Pant* *Pant* Oohhhh! Yes! Mmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1367
translate chinese SR4_ES3_pussy_a871ef2b:

    # Sara "I’m so glad we didn’t use a condom today. You were ah... right! This is soooohhh much better! I love feeling your raw cock brushing up against my g-spot. Ahh! OOhhhH!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1369
translate chinese SR4_ES3_pussy_a2063dd1_2:

    # Sara "Ahmmmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1372
translate chinese SR4_ES3_pussy_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1374
translate chinese SR4_ES3_pussy_e23681fb:

    # Sara "Ah! Ah! Mmmm!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1378
translate chinese SR4_ES3_pussy_e6b5ad9c:

    # MC "(Her pussy was always tight, but it feels even tighter from this angle! It’s like she’s milking my cock each time she goes up!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1380
translate chinese SR4_ES3_pussy_8e50ddcc:

    # MC "*Pant* Oohhh..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1384
translate chinese SR4_ES3_pussy_e23fbcee:

    # MC "God... Mmm! Don’t stop, sis!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1385
translate chinese SR4_ES3_pussy_1f863fdd:

    # Sara "Ah *Pant* Oohhh! *Pant* Your cock’s AH!! soooo big, bro!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1387
translate chinese SR4_ES3_pussy_a73a9010:

    # MC "God... Mmm! Don’t stop!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1388
translate chinese SR4_ES3_pussy_b1b15566:

    # Sara "Ah *Pant* Oohhh! *Pant* Your cock’s AH!! soooo big, [player_name]!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1393
translate chinese SR4_ES3_pussy_28072140:

    # Sara "Oh! God! I’m gonna cum! I’m gonna cum! Yesss! *Pant* Aaayaaahhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1395
translate chinese SR4_ES3_pussy_fae4ca53:

    # MC "Hnnng! That’s it, cum for me sis! I want to feel you cum as you bounce on my shaft!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1397
translate chinese SR4_ES3_pussy_f2d141ab:

    # MC "Hnnng! That’s it, cum for me! I want to feel you cum as you bounce on my shaft!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1399
translate chinese SR4_ES3_pussy_ddd438c7:

    # Sara "Aaaaahhhhh! HHhhaaaahhhhhhhhh! OoohhhhhHHHHHHHhhh!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1403
translate chinese SR4_ES3_pussy_5c2168e1:

    # Sara "*Pant* It’s sooo big! *Pant* You’re filling me up, [player_name]! Ooohh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1405
translate chinese SR4_ES3_pussy_b4eadead:

    # MC "Argh! Hnnngg!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1409
translate chinese SR4_ES3_pussy_dc7b9133:

    # Sara "Ah! Ah! AH!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1411
translate chinese SR4_ES3_pussy_b884c2cd:

    # MC "Ohhh Mmmm!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1415
translate chinese SR4_ES3_pussy_7d01024d:

    # Sara "*Pant* Ah!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1417
translate chinese SR4_ES3_pussy_30884a8b:

    # Sara "(I really want to play with my breasts while I’m riding him...)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1419
translate chinese SR4_ES3_pussy_c9d9ad77:

    # Sara "Ohhh! Ah!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1423
translate chinese SR4_ES3_pussy_4b50e4bb:

    # Sara "(Oh God, my nipples are so sensitive! They’re tingling each time he thrusts into me! I think I’m about to-)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1425
translate chinese SR4_ES3_pussy_f26c98c3:

    # Sara "Aha! AHHHH! AHHHHHHHH!! I’M CUMMMMMIINNNG!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1427
translate chinese SR4_ES3_pussy_dc9d525c:

    # MC "Ugghhh! *Pant* Aaahhhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1431
translate chinese SR4_ES3_pussy_f444a837:

    # Sara "AYAAAHHHHHH!!!! OOHHHHHH!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1433
translate chinese SR4_ES3_pussy_4ae0f41e:

    # MC "Hnnngg! Fuck! I’m gonna cum, sis!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1435
translate chinese SR4_ES3_pussy_01454ce7:

    # MC "Hnnngg! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1437
translate chinese SR4_ES3_pussy_0c98c678:

    # Sara "*Pant* Ah! Ahhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1439
translate chinese SR4_ES3_pussy_1d1c7a6f:

    # MC "Sara! Hnnng! You gotta stop bouncing or I’ll cum inside you! *Pant* HNNNGG!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1441
translate chinese SR4_ES3_pussy_2dce233a:

    # Sara "AH! AHHH! AHHH!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1447
translate chinese SR4_ES3_pussy_2481190d:

    # MC "Hnnngg! SARA! I’m gonna Hnnng... cum! You need to stop bouncing! I- I can’t hold-"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1449
translate chinese SR4_ES3_pussy_b20f5f65:

    # Sara "AH! AH! AH! CUMMMMIIINNNGG!!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1453
translate chinese SR4_ES3_pussy_ce4a4d79:

    # MC "(Shit! I really should have worn a condom!)"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1455
translate chinese SR4_ES3_pussy_50163c01:

    # MC "HNNNGGG! Arrgghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1465
translate chinese SR4_ES3_pussy_4c6503c7:

    # MC "Ugghhh! *Pant* Aargghhh! Fuuuuucckk!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1467
translate chinese SR4_ES3_pussy_fff7ab6a:

    # Sara "Ahh! AHHHH!! H-Huh?!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1469
translate chinese SR4_ES3_pussy_86d8cb69:

    # MC "Oohh... "
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1473
translate chinese SR4_ES3_pussy_113b05c5:

    # Sara "*Pant* W-Why’s it all warm?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1475
translate chinese SR4_ES3_pussy_7aca7cc9:

    # MC "I *Gasp* tried to warn you... *Pant* Sara. I was about to cum and you kept *Pant* bouncing."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1477
translate chinese SR4_ES3_pussy_f478760b:

    # Sara "You came inside me?!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1479
translate chinese SR4_ES3_pussy_6de00618:

    # MC "I’m sorry, we should have used a condom, you were righ-"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1483
translate chinese SR4_ES3_pussy_d7c0f2e0:

    # Sara "If you came inside me, that must mean you REALLY love me!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1485
translate chinese SR4_ES3_pussy_2d6ebc04:

    # MC "*Sigh* I do really love you, Sara. I’m just worried about getting you pregnant."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1487
translate chinese SR4_ES3_pussy_cb19a6ce:

    # Sara "We’ll be fine. I mean, it’s just one little accident. I mean, the odds of getting pregnant can’t be THAT high, right?"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1489
translate chinese SR4_ES3_pussy_76bb5ccf:

    # MC "I hope not! Haha! You still need to finish your exams and graduate!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1491
translate chinese SR4_ES3_pussy_0324618b:

    # Sara "Haha, chill out, [player_name]! I’ll be fine!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1498
translate chinese SR4_ES3_pussy_9e30652e:

    # MC " Hnnng! I’m gonna cum, sis! You need to ugh... get off before I finish inside you! Ahhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1500
translate chinese SR4_ES3_pussy_afb9c4b6:

    # MC " Hnnng! I’m gonna cum, Sara! You need to ugh... get off before I finish inside you! Ahhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1502
translate chinese SR4_ES3_pussy_627d2da2:

    # Sara "AH! AHhhh!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1504
translate chinese SR4_ES3_pussy_743adcc7:

    # Sara "(Shit... It feels so good, I don’t want to stop...)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1508
translate chinese SR4_ES3_pussy_26680f46:

    # Sara "*Pant* *Pant* I’m off, [player_name]!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1512
translate chinese SR4_ES3_pussy_2871be5d:

    # MC "HNNNGG!!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1514
translate chinese SR4_ES3_pussy_faf880c6:

    # Sara "(Wow! I can see his dick twitching! It’s so big and veiny!)"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1525
translate chinese SR4_ES3_pussy_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1527
translate chinese SR4_ES3_pussy_22b85ee1:

    # MC "Ohhh... *Pant* Fuuuck..."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1531
translate chinese SR4_ES3_pussy_57ecd0b0:

    # Sara "Oh wow! That was a LOT! Good thing I hopped off just in time, huh? Hehe!"
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1533
translate chinese SR4_ES3_pussy_69d27312:

    # MC "Heh, yeah! *Pant* That was amazing, Sara. Thank you so much."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1535
translate chinese SR4_ES3_pussy_b299801d:

    # Sara "Thank you, bro. It felt incredible. I love you so much."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1536
translate chinese SR4_ES3_pussy_4ba56588:

    # MC "I love you too, sis."
    MC ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1538
translate chinese SR4_ES3_pussy_bf15ad0d:

    # Sara "Thank you, [player_name]. It felt incredible. I love you so much."
    Sara ""

# game/scripts/SR4/6_SR4_ES3_last.rpy:1539
translate chinese SR4_ES3_pussy_5ae34984:

    # MC "I love you too, Sara."
    MC ""

translate chinese strings:

    # game/scripts/SR4/6_SR4_ES3_last.rpy:315
    old "...you’re pretty good at sucking cock now, Sara. How about you give me a blowjob tonight?"
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:315
    old "...we’ve gotten pretty good at anal. How about we give it another go?"
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:315
    old "...I’d like to fuck your tight teen pussy tonight. How does that sound?"
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:315
    old "...I’d like to fuck your tight pussy tonight. How does that sound?"
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:525
    old "Tell Sara to keep sucking and blow your load down her throat."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:525
    old "Tell Sara to use her hand to finish you off, while you give her a facial."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:525
    old "Tell Sara to stick her tongue out for your salty load."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:981
    old "Cum inside your little sister’s tight ass."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:981
    old "Pull out and paint your little sister’s buttcheeks with your semen."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:981
    old "Cum inside your girlfriend’s tight ass."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:981
    old "Pull out and paint your girlfriend’s buttcheeks with your semen."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:1443
    old "Sara gets lost in the moment and keeps bouncing on your cock until you finish deep inside her."
    new ""

    # game/scripts/SR4/6_SR4_ES3_last.rpy:1443
    old "Sara hops off your dick with a couple of seconds to spare. You finish over her mons pubis."
    new ""

