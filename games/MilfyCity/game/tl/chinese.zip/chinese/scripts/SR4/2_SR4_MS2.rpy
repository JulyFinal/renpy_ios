﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/2_SR4_MS2.rpy:26
translate chinese SR4_MS2_0f0cfaa5:

    # Macy "Not now, [player_name]."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:38
translate chinese SR4_MS2_0bed8790:

    # Macy "I've already talked with her."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:55
translate chinese SR4_MS2_e700f341:

    # MC "(I wonder if Macy knows where Lily lives.)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:57
translate chinese SR4_MS2_f3f4fab2:

    # MC "(I haven’t really seen them hanging out before, but they share a class together so it’s probably the best shot I have outside of hacking into the Dean’s private computer and checking out the student records.)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:59
translate chinese SR4_MS2_4948b0b8:

    # MC "Hey Macy, can I bother you for a minute?"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:63
translate chinese SR4_MS2_934f9148:

    # Macy "Hey, [player_name]! You can bother me for as long as you want. Hehe!"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:65
translate chinese SR4_MS2_b59ffee4:

    # Macy "(Oh my God! He’s actually talking to me!)"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:69
translate chinese SR4_MS2_237fc478:

    # MC "Thanks, just one quick question - do you know Lily from your courses?"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:71
translate chinese SR4_MS2_4cdb8c2b:

    # Macy "Lily?"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:73
translate chinese SR4_MS2_d4ad67aa:

    # MC "Yeah, short girl. Hangs out with Sara a lot. Or at least, she USED to hang out with Sara..."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:77
translate chinese SR4_MS2_c0c1cb8d:

    # Macy "Yeah, I know her. What’s going on? Come to think of it, I haven’t seen her in a while. Is she off sick or something?"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:79
translate chinese SR4_MS2_809a62b2:

    # MC "Not quite. Sara and Lily got into a bit of an argument. I’m just trying to smooth things over before they end up killing each other."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:83
translate chinese SR4_MS2_59ae4e7d:

    # Macy "Oh no... That’s awful. I can take you to her house. How about we walk there together?"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:85
translate chinese SR4_MS2_3dba731b:

    # MC "Sure, that would be-"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:89
translate chinese SR4_MS2_2101824c:

    # Macy "We can grab ice cream on the way and make a date of it!"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:91
translate chinese SR4_MS2_e0c4e0cf:

    # MC "(Sara is already on the verge of murdering one of her classmates out of jealousy. I shouldn’t give her another target or I might push her over the edge!)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:95
translate chinese SR4_MS2_11612c34:

    # MC "Listen, I really appreciate the offer. Unfortunately, I’m already dating Sa-"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:97
translate chinese SR4_MS2_3fba9fa5:

    # MC "(Shit, I can’t just admit I’m dating my sister in front of Macy.)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:99
translate chinese SR4_MS2_a83e41e6:

    # MC "(Shit! I can’t just admit that I’m dating Sara in front of Macy... What if she tells other girls?)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:101
translate chinese SR4_MS2_3548b015:

    # Macy "Hmm?"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:104
translate chinese SR4_MS2_2357ea8e:

    # MC "I’m dating Sa... Sa... Someone right now. (Phew! Nice save!)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:108
translate chinese SR4_MS2_498872a9:

    # Macy "Aww, that’s a shame. I was really hoping the two of us could walk over to Lily’s together."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:110
translate chinese SR4_MS2_a5583d7f:

    # Macy "Oh well, if you ever find yourself available, I’ll be waiting right here."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:114
translate chinese SR4_MS2_7a7dbc44:

    # MC "Thanks Macy. Sorry again. If I wasn’t with someone, I would love to take you out somewhere."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:115
translate chinese SR4_MS2_a0ce46bd:

    # MC "It’s just, I can’t cheat on the person I’m currently with. It isn’t fair to them."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:119
translate chinese SR4_MS2_dc3504cb:

    # Macy "Don’t worry, [player_name]. You don’t need to explain yourself. I’m a big girl. I can handle rejection."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:121
translate chinese SR4_MS2_a6eb5438:

    # MC "Thanks for understanding, Macy."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:125
translate chinese SR4_MS2_09d8d895:

    # Macy "Anyway, you were looking for Lily’s address, right? If it makes it easier I can just text you it."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:127
translate chinese SR4_MS2_eb449bc5:

    # MC "(Her shirt is too loose when she’s leaning over! I don’t think she’s realised!)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:131
translate chinese SR4_MS2_f3f75ad0:

    # MC "(Nice! I can see her nipple poking out!)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:133
translate chinese SR4_MS2_92180221:

    # Macy "Hello?"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:135
translate chinese SR4_MS2_5b92ccbb:

    # MC "(God, I’d love to suck on that...)"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:137
translate chinese SR4_MS2_000d9c0f:

    # Macy "Hello? [player_name]?"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:139
translate chinese SR4_MS2_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:141
translate chinese SR4_MS2_2c6107cd:

    # Macy "I was asking for your number!"
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:145
translate chinese SR4_MS2_4e6847ba:

    # MC "Oh! Sorry, I spaced out there. Let me get it for you."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:147
translate chinese SR4_MS2_4761b774:

    # Macy "Hehe, no problem."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:151
translate chinese SR4_MS2_d901b2d8:

    # Macy "I'll text you Lily's address in a while. The last time I went there was her birthday party last year, but I probably still have her address in an old invite."
    Macy ""

# game/scripts/SR4/2_SR4_MS2.rpy:153
translate chinese SR4_MS2_5b4c1a36:

    # MC "Thanks Macy! Appreciate the help."
    MC ""

# game/scripts/SR4/2_SR4_MS2.rpy:155
translate chinese SR4_MS2_532dd666:

    # Macy "Anytime, [player_name]."
    Macy ""

