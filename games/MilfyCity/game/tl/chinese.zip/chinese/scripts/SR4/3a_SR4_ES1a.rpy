﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/3a_SR4_ES1a.rpy:184
translate chinese Lily_home_locked_a8703fdc:

    # MC "(I've chosen to not cheat on Sara.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:194
translate chinese Lily_home_locked_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:196
translate chinese Lily_home_locked_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:202
translate chinese Lily_home_locked_080dd519:

    # MC "(I've already been in there.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:222
translate chinese SR4_ES1a_blow_dfd4b6b3:

    # MC "(I need to set the record straight with Lily. I’ll just knock on the door, explain that what we did last time was way too close to cheating, and that we can’t see each other again.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:224
translate chinese SR4_ES1a_blow_75537eff:

    # MC "(She’s going to try to seduce me. I just have to be firm and confident.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:228
translate chinese SR4_ES1a_blow_9e2e9c98:

    # MC "(You can do this, [player_name]. Just knock on her door, tell Lily that it won’t be happening again, and then leave.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:230
translate chinese SR4_ES1a_blow_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:234
translate chinese SR4_ES1a_blow_abfdba0a:

    # Lily "Oh! Hi, [player_name]. I wasn’t expecting you to see you again so soon."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:236
translate chinese SR4_ES1a_blow_1327694c:

    # MC "Lily, I had-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:238
translate chinese SR4_ES1a_blow_534d7399:

    # MC "(Wow! She’s only in her underwear!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:240
translate chinese SR4_ES1a_blow_7784a89c:

    # Lily "What’s wrong, [player_name]? Cat got your tongue?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:242
translate chinese SR4_ES1a_blow_c6c29ee3:

    # MC "I- I had to come over to tell you we can’t-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:246
translate chinese SR4_ES1a_blow_0a77d834:

    # Lily "Do you think we can take this conversation inside? You’re letting the cold air in."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:248
translate chinese SR4_ES1a_blow_aac4b556:

    # MC "I was hoping we could-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:250
translate chinese SR4_ES1a_blow_8b24ff9b:

    # Lily "Don’t worry, my parents aren’t home. It’ll just be the two of us."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:252
translate chinese SR4_ES1a_blow_bfde620e:

    # Lily "Don’t worry, I’m still home alone. It’s just the two of us."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:256
translate chinese SR4_ES1a_blow_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:258
translate chinese SR4_ES1a_blow_ff3ef25b:

    # Lily "Make sure to close the door properly behind you - it sticks sometimes. Can I get you a beer?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:262
translate chinese SR4_ES1a_blow_bc719e81:

    # MC "(It would be rude if I just refused a beer, especially when I’m about to deliver her some bad news.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:264
translate chinese SR4_ES1a_blow_8be6166f:

    # MC "Sure, I’ll have a beer."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:266
translate chinese SR4_ES1a_blow_8eae0a4e:

    # Lily "Help yourself to one from the fridge. I’ll be waiting in my room."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:268
translate chinese SR4_ES1a_blow_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:275
translate chinese SR4_ES1a_blow_15888763:

    # Lily "So [player_name], what brought you all the way over here again? Did you want me to suck your cock again?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:277
translate chinese SR4_ES1a_blow_97a52896:

    # MC "N-No! I had to- I had... *Sigh* I had to tell you that we can’t do what we did last time... again. It isn’t fair to Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:279
translate chinese SR4_ES1a_blow_90da12ac:

    # Lily "And you came over to tell me this, rather than text me because...?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:283
translate chinese SR4_ES1a_blow_58750f67:

    # MC "B-Because texting would leave a trail that Sara could find."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:285
translate chinese SR4_ES1a_blow_87c1e5df:

    # Lily "Uh huh. You look anxious. Take a seat and try to relax, [player_name]."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:287
translate chinese SR4_ES1a_blow_15baeab3:

    # MC "I don’t know if I should..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:289
translate chinese SR4_ES1a_blow_c6919418:

    # Lily "Nothing’s going to happen, I promise. I mean, you’re still fully dressed? I can hardly do anything when you’ve got your clothes on."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:293
translate chinese SR4_ES1a_blow_9eb1e6fd:

    # MC "Heh, I guess you’re right."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:295
translate chinese SR4_ES1a_blow_11cc3834:

    # Lily "Hey! Do you wanna make out?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:299
translate chinese SR4_ES1a_blow_65813274:

    # MC "What?! No way, Lily. You can’t be serious!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:301
translate chinese SR4_ES1a_blow_42da74a4:

    # Lily "Oh c’mon, it’s just a bit of harmless fun!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:303
translate chinese SR4_ES1a_blow_9da632b7:

    # MC "Kissing someone else is literally cheating!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:305
translate chinese SR4_ES1a_blow_74388872:

    # Lily "Is it though? I mean, we didn’t cheat last time we were here, did we?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:307
translate chinese SR4_ES1a_blow_bf09af38:

    # MC "No, but-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:309
translate chinese SR4_ES1a_blow_1a5d9944:

    # Lily "We’ve established that we didn’t cheat last time. Last time you came over I kissed your cock. All I’m asking right now is to make out with you. Surely a kiss on the dick is more intimate than a kiss on the lips?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:311
translate chinese SR4_ES1a_blow_4fb80981:

    # MC "Yeah, but-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:313
translate chinese SR4_ES1a_blow_5e802fca:

    # Lily "Therefore, if kissing your cock wasn’t cheating, then kissing you on the lips couldn’t be cheating either."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:315
translate chinese SR4_ES1a_blow_c7cd3815:

    # MC "Lily, you’re twisting my words again."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:317
translate chinese SR4_ES1a_blow_3db8c028:

    # Lily "Besides, we’ve already kissed before. Remember that game of spin-the-bottle we played in Sara’s bedroom?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:319
translate chinese SR4_ES1a_blow_c20318dd:

    # MC "Lily, this is getting-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:326
translate chinese SR4_ES1a_blow_9b9a3077:

    # MC "Mmmpff!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:327
translate chinese SR4_ES1a_blow_6bc31c2e:

    # Lily "Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:329
translate chinese SR4_ES1a_blow_d31c1070:

    # MC "(She just jumped on me out of nowhere!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:333
translate chinese SR4_ES1a_blow_f7e58baa:

    # Lily "Mmmmm..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:335
translate chinese SR4_ES1a_blow_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:337
translate chinese SR4_ES1a_blow_9ea24878:

    # MC "(Lily’s sliding her tongue into my mouth! This woman’s insatiable!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:341
translate chinese SR4_ES1a_blow_9af1484a:

    # Lily "(Hehe! Got him! That should be [player_name] all hot and bothered now. I can start trying more risque moves now.)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:345
translate chinese SR4_ES1a_blow_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:347
translate chinese SR4_ES1a_blow_39d44d65:

    # Lily "Hehe, how was it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:349
translate chinese SR4_ES1a_blow_780e8cde:

    # MC "I... I... You just kissed me out of nowhere!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:353
translate chinese SR4_ES1a_blow_2bdf788a:

    # Lily "You seem REALLY pent up, [player_name]. Is Sara stressing you out?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:355
translate chinese SR4_ES1a_blow_b0bfe066:

    # MC "I didn’t say-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:357
translate chinese SR4_ES1a_blow_17241371:

    # Lily "You look like you could use a hand relaxing..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:361
translate chinese SR4_ES1a_blow_665d9f77:

    # Lily "...or perhaps a mouth?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:363
translate chinese SR4_ES1a_blow_94427969:

    # MC "Lily, I told you. Last time came way too close to actually cheating on Sara. It isn’t fair to do that to her. And that kissing thing you did nearly crossed the line!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:365
translate chinese SR4_ES1a_blow_1ebbc2b4:

    # Lily "When you say “last time came TOO CLOSE to cheating on Sara”, that means it wasn’t cheating?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:369
translate chinese SR4_ES1a_blow_f43e8a72:

    # MC "No, it wasn’t."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:371
translate chinese SR4_ES1a_blow_b9067087:

    # Lily "So, if what we did last time WASN’T cheating then there's no reason why we couldn’t do it again, right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:373
translate chinese SR4_ES1a_blow_c84ae725:

    # MC "I didn't say that, Lily. You’re- arrrghhh! You’re manipulating everything I say!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:377
translate chinese SR4_ES1a_blow_39d4d3b7:

    # Lily "I’m serious, [player_name]! It’s not like we fucked or anything."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:379
translate chinese SR4_ES1a_blow_3f4d021a:

    # Lily "I think there’s a reason you came back today - and it wasn’t to tell me that we’re not gonna fool around again."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:381
translate chinese SR4_ES1a_blow_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:383
translate chinese SR4_ES1a_blow_81e70e01:

    # Lily "You simply couldn’t get that blowjob I gave you out of your head, could you? You kept ruminating about the feeling as you blew your hot, salty load deep in my warm, wet, teenage mouth."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:385
translate chinese SR4_ES1a_blow_2c972208:

    # Lily "You simply couldn’t get that blowjob I gave you out of your head, could you? You kept ruminating about the feeling as you blew your hot, salty load deep in my warm, wet mouth."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:388
translate chinese SR4_ES1a_blow_43b305d2:

    # Lily "*Glug*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:390
translate chinese SR4_ES1a_blow_2afa4599:

    # Lily "(Hehe, seducing [player_name] is like shooting fish in a barrel. He never had a chance.)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:392
translate chinese SR4_ES1a_blow_1c24254b:

    # MC "I.."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:396
translate chinese SR4_ES1a_blow_e2c5538e:

    # Lily "So [player_name], given that you travelled all the way over here just to see me, perhaps you could put Sara out of your head for a while and let me treat you?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:398
translate chinese SR4_ES1a_blow_2b9f421e:

    # MC "*Gulp* Treat me how?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:400
translate chinese SR4_ES1a_blow_7c502ff3:

    # Lily "Nothing I haven’t done before."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:404
translate chinese SR4_ES1a_blow_36c74cd9:

    # Lily "How about you slip out of your clothes and I’ll suck your cock again?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:408
translate chinese SR4_ES1a_blow_c61ada8e:

    # MC "*Sigh* Lily, I said I wasn’t going to cheat on Sara anymore."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:412
translate chinese SR4_ES1a_blow_9b8e9776:

    # Lily "You won’t be! Promise! Think about it - if what you did last time wasn’t cheating, then simply repeating that couldn’t be cheating. It’s basic logic, [player_name]."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:414
translate chinese SR4_ES1a_blow_65ae8e5e:

    # Lily "I can keep my underwear on if it would make you feel better."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:418
translate chinese SR4_ES1a_blow_d67b9959:

    # MC "*Sigh* You’re a bad influence, Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:422
translate chinese SR4_ES1a_blow_8f268b6f:

    # Lily "I know you want this, [player_name]. You’ve been LONGING for me to suck your cock again. You can’t resist me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:426
translate chinese SR4_ES1a_blow_e6cb58d3:

    # MC "...fine. We’re not going any further than last time though. You can use your mouth and nothing more."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:430
translate chinese SR4_ES1a_blow_bfb89ee8:

    # Lily "See? Aren’t you much more comfortable now that you’re out of those clothes?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:432
translate chinese SR4_ES1a_blow_7bcd75ed:

    # MC "Y-Yeah."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:434
translate chinese SR4_ES1a_blow_1d355e59:

    # Lily "Just relax, sit back, and enjoy your beer. Let me take care of you today."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:438
translate chinese SR4_ES1a_blow_bf13a68f:

    # Lily "*Mwah*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:440
translate chinese SR4_ES1a_blow_dea714cb:

    # MC "Oohh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:442
translate chinese SR4_ES1a_blow_b502252b:

    # MC "(I’d forgotten how good it felt when she kissed my cock last time.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:446
translate chinese SR4_ES1a_blow_e1c9764c:

    # Lily "Mmm! *Kiss*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:448
translate chinese SR4_ES1a_blow_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:452
translate chinese SR4_ES1a_blow_2d11d10e:

    # Lily "(I knew [player_name] wouldn’t be able to resist coming back for another blowjob. I really blew his mind with the last one!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:454
translate chinese SR4_ES1a_blow_10c48e31:

    # Lily "*Kiss* Mwah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:460
translate chinese SR4_ES1a_blow_70eac9f9:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:462
translate chinese SR4_ES1a_blow_ed941f2d:

    # Lily "Are you enjoying this, [player_name]?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:464
translate chinese SR4_ES1a_blow_3eb8bf2d:

    # MC "Yeah, it’s great."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:466
translate chinese SR4_ES1a_blow_eaa18141:

    # Lily "*Shlurp* *Suck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:467
translate chinese SR4_ES1a_blow_4a04f620:

    # Lily "Good, because I haven’t even properly started yet."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:471
translate chinese SR4_ES1a_blow_6f9c0f5c:

    # MC "Oh really? What’s it going to be like when you-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:473
translate chinese SR4_ES1a_blow_0ba9cdbf:

    # Lily "*Glompf* *Shlurp*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:475
translate chinese SR4_ES1a_blow_05e23b28:

    # MC "Ooohhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:479
translate chinese SR4_ES1a_blow_3f2093f3:

    # Lily "*Suck* *Suck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:481
translate chinese SR4_ES1a_blow_d144eb85:

    # MC "*Pant* Ooohh! Hnnnnggg!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:483
translate chinese SR4_ES1a_blow_32263f0c:

    # Lily "*Shlurp* *Suuuuck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:487
translate chinese SR4_ES1a_blow_b5035649:

    # MC "Mmmm! Keep sucking, Lily! *Gasp* Your mouth is incredible! Oooh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:489
translate chinese SR4_ES1a_blow_eaa18141_1:

    # Lily "*Shlurp* *Suck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:493
translate chinese SR4_ES1a_blow_b00a0edb:

    # MC "(I might as well take Lily’s suggestion and enjoy my beer while she does this.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:495
translate chinese SR4_ES1a_blow_a83cf02c:

    # Lily "*Suck* *Suck* *Suck* *Suck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:499
translate chinese SR4_ES1a_blow_9beef527:

    # MC "*Glug* *Glug*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:501
translate chinese SR4_ES1a_blow_b06c2bbe:

    # Lily "*SUUUUCK* *SUUUUCK*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:503
translate chinese SR4_ES1a_blow_f239a65d:

    # MC "(Fuck, this is amazing!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:507
translate chinese SR4_ES1a_blow_f9738014:

    # MC "Mmm! *Glug*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:509
translate chinese SR4_ES1a_blow_fa1f9395:

    # Lily "(Hehe, alright... time to push [player_name] to the edge and see how he reacts.)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:511
translate chinese SR4_ES1a_blow_9cb2e3cb:

    # Lily "*Suck* *Suck* *Su-"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:515
translate chinese SR4_ES1a_blow_08c20d15:

    # Lily "..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:517
translate chinese SR4_ES1a_blow_05d3b68a:

    # MC "Huh? Why’d you stop?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:519
translate chinese SR4_ES1a_blow_d75e798b:

    # Lily "I’m not gonna finish you off unless you tell me I’m a better cocksucker than Sara."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:521
translate chinese SR4_ES1a_blow_4875dec0:

    # MC "What? I’m not going to-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:525
translate chinese SR4_ES1a_blow_0f216a92:

    # Lily "*Suck* *Suck"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:527
translate chinese SR4_ES1a_blow_7f5beb5e:

    # MC "Hnnngg! Aahhhhgggg! I’m gonna-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:531
translate chinese SR4_ES1a_blow_d378853a:

    # MC "*Pant* *Pant* LILY! I was so close!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:534
translate chinese SR4_ES1a_blow_b7ca96c2:

    # Lily "If you REALLY wanna cum, all you have to do is say that I’m a better cocksucker than your dumb little sister."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:536
translate chinese SR4_ES1a_blow_042eb521:

    # Lily "If you really wanna cum, all you have to do is tell me that I'm a better cocksucker than your dumb nerdy girlfriend."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:538
translate chinese SR4_ES1a_blow_698f3fd6:

    # MC "...Lily, I can’t-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:542
translate chinese SR4_ES1a_blow_37a969fd:

    # Lily "*Shlurp* *Suck* *Gag*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:545
translate chinese SR4_ES1a_blow_e3937d76:

    # MC "*Pant* Ooohhh! Fuuuuck! Hnnnggg!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:547
translate chinese SR4_ES1a_blow_3022cd64:

    # Lily "*Shlurp* *Suuuck* *SUUUUUCK*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:549
translate chinese SR4_ES1a_blow_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:551
translate chinese SR4_ES1a_blow_0959f2b9:

    # Lily "*Suuuck* *GAG*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:555
translate chinese SR4_ES1a_blow_2a5a818e:

    # Lily "*Gasp* *Cough*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:557
translate chinese SR4_ES1a_blow_fbb737e3:

    # MC "*Pant* This isn’t fair, Lily! You can’t just keep edging me like this!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:561
translate chinese SR4_ES1a_blow_7204f86b:

    # Lily "Oh, can’t I? If you’re THAT desperate to cum you could just finish yourself off in the bathroom."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:563
translate chinese SR4_ES1a_blow_98e4b17f:

    # Lily "But you don’t want that, do you? You want to feel your cock erupting deep inside my warm, wet mouth."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:565
translate chinese SR4_ES1a_blow_4ab90a2e_2:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:567
translate chinese SR4_ES1a_blow_8181405e:

    # Lily "Let’s hear those words, [player_name]. Tell me I’m a better cocksucker than your dumb little sister."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:569
translate chinese SR4_ES1a_blow_30d5be34:

    # Lily "Let's hear those words, [player_name]. Tell me I'm a better cocksucker than your dumb nerdy girlfriend."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:571
translate chinese SR4_ES1a_blow_1c94a033:

    # MC "You..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:573
translate chinese SR4_ES1a_blow_d06a9a20:

    # Lily "That’s it. Go on."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:575
translate chinese SR4_ES1a_blow_89dd8c44:

    # MC "You’re a better... cocksucker than my... *cough* dumb little... sister."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:578
translate chinese SR4_ES1a_blow_fe3884fd:

    # Lily "Very good. Just one last request - say her name. Say that I’m a better cocksucker than your stupid little sister, SARA."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:580
translate chinese SR4_ES1a_blow_91227b74:

    # MC "You're a better... cocksucker than my... *cough* ... dumb nerdy... girlfriend."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:584
translate chinese SR4_ES1a_blow_709addc5:

    # Lily "Very good. Just one last request - say her name. Say that I'm a better cocksucker than your stupid nerdy girlfriend, SARA."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:586
translate chinese SR4_ES1a_blow_56d4be4b:

    # MC "*Sigh* Y-You’re a better cocksucker than..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:588
translate chinese SR4_ES1a_blow_e1d4f294:

    # MC "(Why is Lily torturing me like this?!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:590
translate chinese SR4_ES1a_blow_af714651:

    # MC "...my stupid little sister...*Gulp* ...Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:592
translate chinese SR4_ES1a_blow_40289704:

    # MC "...my stupid nerdy girlfriend... *Gulp* ...Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:594
translate chinese SR4_ES1a_blow_b924223a:

    # Lily "There we go, that wasn’t so hard, was it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:598
translate chinese SR4_ES1a_blow_d6a6e3bd:

    # Lily "*Shlurp* *Suck* *Suck* *Shlurp*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:600
translate chinese SR4_ES1a_blow_c1f1345d:

    # MC "Ohhh... Mmmm! Yes!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:604
translate chinese SR4_ES1a_blow_6964ab86:

    # MC "*Pant* Don’t stop, Lily! Ugh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:606
translate chinese SR4_ES1a_blow_b136e491:

    # Lily "*Suck* *Suck* *Shluuurrrp*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:610
translate chinese SR4_ES1a_blow_86a831ec:

    # Lily "*Gag* *Shlurp* *Suck* *Suck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:612
translate chinese SR4_ES1a_blow_22f4c79e:

    # MC "Hnnnnggg! I’m cumming!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:614
translate chinese SR4_ES1a_blow_749fd678:

    # Lily "*Suck* *Suck* *Gag* Suck*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:620
translate chinese SR4_ES1a_blow_f6609f1e:

    # MC "Ugh! Hnnngg! Aaahh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:622
translate chinese SR4_ES1a_blow_ecb8a967:

    # Lily "Mmpff! *Gulp* *Shlurrrp* *Gulp*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:630
translate chinese SR4_ES1a_blow_d795e4bd:

    # MC "Ohh... Fuck... *Pant*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:632
translate chinese SR4_ES1a_blow_9109c8b6:

    # Lily "Mmm... So, what did you think?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:634
translate chinese SR4_ES1a_blow_7bc42a10:

    # MC "*Pant* Y-Yeah, you’re definitely a *Pant* better cocksucker than Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:636
translate chinese SR4_ES1a_blow_e6010a2d:

    # Lily "Hehe! I knew it!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:644
translate chinese SR4_ES1a_blow_3937165b:

    # MC "Hnnnggg! I’m cumming!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:646
translate chinese SR4_ES1a_blow_75d38bcf:

    # Lily "Yes! Empty your balls for me! Finish all over my face!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:649
translate chinese SR4_ES1a_blow_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:660
translate chinese SR4_ES1a_blow_0cfabe7b:

    # MC "Hnnnngg! Ugh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:662
translate chinese SR4_ES1a_blow_ceb45b37:

    # Lily "(Oh wow!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:666
translate chinese SR4_ES1a_blow_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:668
translate chinese SR4_ES1a_blow_9109c8b6_1:

    # Lily "Mmm... So, what did you think?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:670
translate chinese SR4_ES1a_blow_7bc42a10_1:

    # MC "*Pant* Y-Yeah, you’re definitely a *Pant* better cocksucker than Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:672
translate chinese SR4_ES1a_blow_e6010a2d_1:

    # Lily "Hehe! I knew it!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:679
translate chinese SR4_ES1a_blow_end_c12a0f0d:

    # Lily "Well? Did you enjoy that?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:681
translate chinese SR4_ES1a_blow_end_ecd6522f:

    # MC "It was fucking incredible, Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:685
translate chinese SR4_ES1a_blow_end_1f47eaf5:

    # Lily "See? There’s no reason we can’t have some fun like this without cheating."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:687
translate chinese SR4_ES1a_blow_end_5ba4a970:

    # MC "Yeah... We’ll just have to be careful not to go any farther."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:691
translate chinese SR4_ES1a_blow_end_0a13c74a:

    # Lily "So, can I expect you to drop by again next time you fancy having some harmless fun? I mean, you could always go to Sara for a blowjob... But, since I'm a better cocksucker..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:693
translate chinese SR4_ES1a_blow_end_c1b100ef:

    # MC "I get the point, Lily. You’ve said that before. *Sigh* We’re not doing anything more than a blowjob though."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:697
translate chinese SR4_ES1a_blow_end_8d00f515:

    # Lily "Of course we won’t."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:699
translate chinese SR4_ES1a_blow_end_ab8760ab:

    # Lily "(I’m going to fuck you yet, [player_name]. You’ll give in eventually, and then you’ll finally get to see how wet I am for you.)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:703
translate chinese SR4_ES1a_blow_end_aad980bd:

    # MC "Catch you later, Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:705
translate chinese SR4_ES1a_blow_end_5854698b:

    # Lily "Bubye, [player_name]."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:736
translate chinese SR4_ES1a_second_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:740
translate chinese SR4_ES1a_second_24838be3:

    # MC "Hey Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:742
translate chinese SR4_ES1a_second_ac799fe6:

    # Lily "Hey, [player_name]. Back again so soon? You just couldn’t stay away from me, could you?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:744
translate chinese SR4_ES1a_second_65a8203e:

    # MC "You aren’t busy, are you?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:748
translate chinese SR4_ES1a_second_4e98f8da:

    # Lily "Not at all. Come on in, make yourself at home."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:752
translate chinese SR4_ES1a_second_1ee4b0b9:

    # Lily "And grab a beer from the fridge if you want one!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:756
translate chinese SR4_ES1a_second_80c62520:

    # Lily "So, let me guess, you got horny and missed my blowjob?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:758
translate chinese SR4_ES1a_second_8fb8d44b:

    # MC "Am I that transparent? Haha!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:763
translate chinese SR4_ES1a_second_eb8601f4:

    # Lily "It’s a real shame though..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:765
translate chinese SR4_ES1a_second_96ecc174:

    # MC "What is?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:767
translate chinese SR4_ES1a_second_e58fe9c5:

    # Lily "Well, I don’t really feel like giving a blowjob today."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:769
translate chinese SR4_ES1a_second_fdce2475:

    # MC "Huh? Why not?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:771
translate chinese SR4_ES1a_second_e8cd4da5:

    # Lily "Well, I had something else in mind for us today."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:775
translate chinese SR4_ES1a_second_d8a8a743:

    # MC "And what exactly would that be? I already told you I’m not going to do anything more than oral with you. Anything beyond that is ONLY with Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:777
translate chinese SR4_ES1a_second_28d1ed2f:

    # Lily "Aww, that’s a real shame, because I wanted to play a little game today."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:779
translate chinese SR4_ES1a_second_0b4d485c:

    # MC "A little gam-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:786
translate chinese SR4_ES1a_second_5b937a1d:

    # MC "Hey, wh-what are you doing?!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:788
translate chinese SR4_ES1a_second_8af7d351:

    # Lily "You’re free to leave whenever you want, [player_name], but it’s my room and I’m going to take my clothes off if I want to."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:790
translate chinese SR4_ES1a_second_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:794
translate chinese SR4_ES1a_second_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:796
translate chinese SR4_ES1a_second_d0346e2c:

    # Lily "Well, you haven’t left yet, so I’m going to guess you’ve decided to stay. In that case, how about I tell you the rules of my little game."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:800
translate chinese SR4_ES1a_second_f47b822f:

    # Lily "You don’t want to cheat on Sara, but it’s hardly fair that YOU’RE the only one who gets to cum each time you stop by."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:802
translate chinese SR4_ES1a_second_b7776f3c:

    # Lily "So, if you want to keep having these fun little sessions with me, then you’re going to have to put in a little more work on your end."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:804
translate chinese SR4_ES1a_second_ed2d89ca:

    # MC "I don’t understand. What do you mean?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:808
translate chinese SR4_ES1a_second_0657ebb5:

    # Lily "I’m going to lie down and spread my legs for you. I want you to use that fat cock of yours to grind against my pussy."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:810
translate chinese SR4_ES1a_second_b4fada7e:

    # MC "Whoa! Okay, now THAT is CLEARLY cheating."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:812
translate chinese SR4_ES1a_second_02ec7dbe:

    # Lily "Not if you don’t put it inside."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:814
translate chinese SR4_ES1a_second_c9714a19:

    # MC "How on Earth are you rationalising that?!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:816
translate chinese SR4_ES1a_second_64d7d12f:

    # Lily "Think about it. Imagine I’m a virgin. If you shove your cock into my pussy, am I still a virgin?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:818
translate chinese SR4_ES1a_second_11bc8a6a:

    # MC "*Sigh* Obviously not."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:820
translate chinese SR4_ES1a_second_41df0f5f:

    # Lily "What if you just rubbed your shaft against my vulva? You wouldn’t be breaking my hymen, so I’d still be a virgin."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:822
translate chinese SR4_ES1a_second_80987d0f:

    # MC "I... I mean, I can see the logic behind your thinking."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:824
translate chinese SR4_ES1a_second_77020062:

    # Lily "Therefore, if grinding wouldn’t cause a girl to lose her virginity, then TECHNICALLY it isn’t really sex. And if it isn’t REALLY sex, then it can’t possibly be cheating."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:826
translate chinese SR4_ES1a_second_8ffef8cc:

    # MC "*Sigh* What do you want to work as after you graduate, Lily?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:828
translate chinese SR4_ES1a_second_139d3e3a:

    # Lily "A lawyer."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:830
translate chinese SR4_ES1a_second_8c9714de:

    # MC "(I could have fucking guessed.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:834
translate chinese SR4_ES1a_second_1c0d9203:

    # Lily "So! I’m ready whenever you are."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:836
translate chinese SR4_ES1a_second_257b872f:

    # MC "Lily, I-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:838
translate chinese SR4_ES1a_second_509d6947:

    # Lily "We’ve already established that grinding your cock against my pussy isn’t actually cheating, haven’t we?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:840
translate chinese SR4_ES1a_second_4fb80981:

    # MC "Yeah, but-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:844
translate chinese SR4_ES1a_second_c34e3b39:

    # Lily "Then what are you waiting for? Look, I’m even rubbing my clit right now to give you a head start. Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:846
translate chinese SR4_ES1a_second_264f3aab:

    # MC "(I really shouldn’t be doing this... Why did I even come back to her apartment again? She’s clearly dangerous!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:848
translate chinese SR4_ES1a_second_77fdcf17:

    # MC "I’m sorry Lily, I really don’t think that I should be-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:850
translate chinese SR4_ES1a_second_65f0997a:

    # Lily "Ooohh! C’mon, [player_name]. It’s not like I’m asking you to stick your dick inside me. Ah! I’m just mmm... asking you to grind up against me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:854
translate chinese SR4_ES1a_second_ac43ec03:

    # MC "*Gulp* We’re definitely not going to go any farther than grinding?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:856
translate chinese SR4_ES1a_second_8cbc9fdf:

    # Lily "Ah... Of course not. Mmm! You can just grind against my pussy until we both cum. Ooohh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:858
translate chinese SR4_ES1a_second_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:860
translate chinese SR4_ES1a_second_79f7d34e:

    # Lily "Please, [player_name]! Don’t keep me waiting, my pussy is soaking wet right now. Your cock would slide back and forth across my vulva SO easily."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:862
translate chinese SR4_ES1a_second_efd11aec:

    # MC "*Sigh* (She’s right. This isn’t actually sex, so it isn’t cheating as long as I don’t slip inside her.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:864
translate chinese SR4_ES1a_second_4b08964c:

    # MC "Alright Lily, move your hand out of the way."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:868
translate chinese SR4_ES1a_second_c32a4536:

    # Lily "Oooh! Hehe! I knew your cock was big when I had it in my mouth, but it feels even more imposing when I see it down there."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:870
translate chinese SR4_ES1a_second_fa92e55f:

    # MC "Don’t get any ideas, Lily. It isn’t going inside."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:872
translate chinese SR4_ES1a_second_622f8881:

    # Lily "(We’ll see about that, [player_name].)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:874
translate chinese SR4_ES1a_second_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:876
translate chinese SR4_ES1a_second_424a2218:

    # Lily "Are you enjoying that, [player_name]? Your thick dick feels SOOO good sliding up against my ah... wet pussy like that! Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:878
translate chinese SR4_ES1a_second_60dc91b8:

    # MC "(My heart’s racing right now. I don’t know if it’s the excitement of grinding against her pussy, or the guilt of doing this to Sara. Lily WAS pretty convincing that this wasn’t cheating though...)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:882
translate chinese SR4_ES1a_second_bd85bb73:

    # Lily "Ah! Yes! Mmm! God, I love it when your shaft rubs up against my clitty like that. Ooohh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:884
translate chinese SR4_ES1a_second_a06f9127:

    # Lily "*Gasp* Keep going! Faster! Ah! Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:886
translate chinese SR4_ES1a_second_de563e39:

    # MC "Oh... Fuck... *Pant* Mmm!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:888
translate chinese SR4_ES1a_second_a802cfb4:

    # MC "(Listening to her moan each time I thrust my cock over her vulva is so fucking hot.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:892
translate chinese SR4_ES1a_second_8f067ca3:

    # Lily "You can have more than this, [player_name]. Go on, slip the tip in. I know you want to."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:894
translate chinese SR4_ES1a_second_45ed5862:

    # MC "*Pant* I... I can’t. Going any further than this would-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:896
translate chinese SR4_ES1a_second_0b01f4fe:

    # Lily "-NOT be cheating! You’ve already got my juices coating your fat cock. You might as well just slip the tip in."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:898
translate chinese SR4_ES1a_second_17d2b6d7:

    # Lily "*Whispered* Come on, [player_name]. Put it in. I can tell you DESPERATELY want to know how good my pussy feels."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:900
translate chinese SR4_ES1a_second_c0afc856:

    # MC "No, I-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:902
translate chinese SR4_ES1a_second_0149f911:

    # Lily "*Whispered* I promise you, it’s going to be incredible. Just imagine my warm, wet hole tightly clenched around your sensitive glans."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:906
translate chinese SR4_ES1a_second_dc05fc6b:

    # MC "*Gulp* ..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:908
translate chinese SR4_ES1a_second_9b042bc4:

    # Lily "Go on, you can do it. Just push your hips forward a bit, let it slide in."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:910
translate chinese SR4_ES1a_second_09b6feb9:

    # Lily "*Whispered* You want this. I want this. What’s the issue?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:912
translate chinese SR4_ES1a_second_872a0c69:

    # MC "I... Sara... I can’t cheat on Sara like this."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:916
translate chinese SR4_ES1a_second_31068485:

    # Lily "Sure you can! Just the tip isn’t cheating."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:918
translate chinese SR4_ES1a_second_8a7ae97a:

    # MC "(Aw shit, she’s pulling her lawyer crap again. Don’t fall for it, [player_name]!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:920
translate chinese SR4_ES1a_second_8ead6aa1:

    # Lily "I mean, a girl’s a virgin if she still has her hymen, right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:922
translate chinese SR4_ES1a_second_5a7566bb:

    # MC "... I... want to disagree with that, but I can’t."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:924
translate chinese SR4_ES1a_second_f8c11308:

    # Lily "So, if for a girl to be de-virginised the penetration must go deep enough to break her hymen?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:926
translate chinese SR4_ES1a_second_fbd2dd48:

    # Lily "So, for a girl to be de-virginised the penetration must go deep enough to break her hymen, right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:928
translate chinese SR4_ES1a_second_1bc2f936:

    # MC "*Sigh* I see where you’re going with this."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:930
translate chinese SR4_ES1a_second_ec054adf:

    # Lily "Okay, I’m not a virgin, but let’s say that hypothetically I was... Given that the hymen is located about an inch inside the pussy that means you can just put the tip of your cock in and I would STILL have my theoretical hymen intact, and THEREFORE still be a virgin."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:932
translate chinese SR4_ES1a_second_954b28b1:

    # Lily " It logically follows that if my theoretical hymen has not been broken, then I haven’t ACTUALLY had sex. And if I haven’t had sex with you then..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:934
translate chinese SR4_ES1a_second_ab6bc32e:

    # MC "(Goddammit. Her logic is flawless.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:936
translate chinese SR4_ES1a_second_cab8e694:

    # MC "...we never actually cheated."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:938
translate chinese SR4_ES1a_second_17829500:

    # Lily "Bingo! See? You’re getting the hang of this!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:942
translate chinese SR4_ES1a_second_bc2c1be8:

    # Lily "Go on, push the tip inside me. I know you want to feel my wet cunt engulf your fat cock."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:944
translate chinese SR4_ES1a_second_8d0db773:

    # MC "(Ah, fuck it. She’s right. Just the tip shouldn’t matter.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:948
translate chinese SR4_ES1a_second_f31c2db8:

    # MC "Hnnng! Ooohhh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:950
translate chinese SR4_ES1a_second_58f10ece:

    # MC "(Holy shit, her pussy is REALLY warm!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:952
translate chinese SR4_ES1a_second_bd0c8fcb:

    # Lily "Mmmm! That’s it! Ah..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:956
translate chinese SR4_ES1a_second_0c5f1f49:

    # Lily "Try thrusting your hips a bit. I want to feel your mmm... thick cock spreading my labia. Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:958
translate chinese SR4_ES1a_second_95f0f040:

    # MC "Mmmm! Oh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:960
translate chinese SR4_ES1a_second_9ff8111d:

    # MC "(This feels incredible! I don’t know how long I’m going to last.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:964
translate chinese SR4_ES1a_second_5c919202:

    # Lily "Ah! Yes! Mmmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:966
translate chinese SR4_ES1a_second_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:968
translate chinese SR4_ES1a_second_8306707b:

    # Lily "You can go a bit deeper! Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:972
translate chinese SR4_ES1a_second_ba631755:

    # MC "Hnnng... *Pant* Ooohh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:974
translate chinese SR4_ES1a_second_7a0e4a39:

    # Lily "God... Your cock feels amazing! Tell me how my cunt feels."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:976
translate chinese SR4_ES1a_second_5b915940:

    # MC "It, uh, feels really good. It’s super tight and sooo warm and-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:980
translate chinese SR4_ES1a_second_0f7724dd:

    # Lily "Is it better than Sara’s?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:982
translate chinese SR4_ES1a_second_2c9a62fe:

    # MC "Wh-What?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:984
translate chinese SR4_ES1a_second_d15d465b:

    # Lily "I want to know if my soaking wet cunt feels better than your dumb little sister’s pussy. So, tell me, does it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:986
translate chinese SR4_ES1a_second_db6cb84b:

    # Lily "I want to know if my soaking wet cunt feels better than your dumb nerdy girlfriend's pussy. So, tell me, does it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:990
translate chinese SR4_ES1a_second_df0834bf:

    # MC "I... ah... I..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:992
translate chinese SR4_ES1a_second_db2becf5:

    # Lily "It’s okay, she’s not here right now. You can say whatever you want. She isn't going to find out."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:994
translate chinese SR4_ES1a_second_cc36dcf5:

    # MC "It’s... difficult to compare just the tip to... actual sex."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:998
translate chinese SR4_ES1a_second_ebc58c42:

    # Lily "Well, how about you tell me how the tip feels? What gets you more excited - the idea of penetrating your moody, whiny little sister’s pussy? Or pounding this slutty girl’s wet fuckhole?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1000
translate chinese SR4_ES1a_second_0ba45063:

    # Lily "Well, how about you tell me how the tip feels? What gets you more excited - the idea of penetrating your moody, whiny nerdy girlfriend's pussy? Or pounding this slutty girl's wet fuckhole?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1001
translate chinese SR4_ES1a_second_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1004
translate chinese SR4_ES1a_second_bf691ab7:

    # MC "(Does she really have to keep bringing Sara up right in the middle of this?!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1008
translate chinese SR4_ES1a_second_716202a1:

    # Lily "I bet Sara is SUPER awkward in bed, isn’t she? How does it feel being with a girl who ACTUALLY knows how to use her body for a change?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1010
translate chinese SR4_ES1a_second_438840c3:

    # MC "I... I don’t really..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1012
translate chinese SR4_ES1a_second_e6b08903:

    # Lily "Just tell me how my best friend is in bed. Is she a good fuck?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1016
translate chinese SR4_ES1a_second_0ec2e825:

    # MC "She was a virgin, so it was her first time. You can’t really expect her to-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1018
translate chinese SR4_ES1a_second_bf26fecb:

    # Lily "Oooh, so you’re saying she didn’t know how to fuck you right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1020
translate chinese SR4_ES1a_second_fb44ba23:

    # MC "That isn’t what I-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1024
translate chinese SR4_ES1a_second_fb109ea5:

    # Lily "You know that I could fuck you right, [player_name]. If you let me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1026
translate chinese SR4_ES1a_second_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1028
translate chinese SR4_ES1a_second_36a8880a:

    # Lily "You’ve already seen exactly what I can do with my mouth. And you’ve felt how good a fraction of my pussy feels grinding against your cock."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1030
translate chinese SR4_ES1a_second_f8fe1b16:

    # Lily "I know you want this."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1034
translate chinese SR4_ES1a_second_9549a7cc:

    # MC "(If I go in any deeper then I’m definitely cheating on Sara... Even by Lily’s twisted logic.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1036
translate chinese SR4_ES1a_second_c55b6172:

    # MC "N-No Lily, I’m not going any further. Just the tip. That’s what we agreed was the limit between just having some fun and cheating."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1038
translate chinese SR4_ES1a_second_a78fca53:

    # Lily "Aww, fine. Just let me know if you change your mind though."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1042
translate chinese SR4_ES1a_second_353e63a8:

    # MC "Oh! *Groan* Mmm!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1044
translate chinese SR4_ES1a_second_6ccc190b:

    # Lily "You love that, don’t you? Ah! Gently rocking the tip of your oh...! fat dick in and out of my pussy. It must feel sooo good right now."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1046
translate chinese SR4_ES1a_second_10c18169:

    # MC "*Pant* Mmm! Ah! Fuck... This feels so fucking good, Lily. I’m getting really close."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1050
translate chinese SR4_ES1a_second_61fda3ca:

    # Lily "Tell me, [player_name], where do you want to cum? Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1052
translate chinese SR4_ES1a_second_c3234216:

    # MC "Hnnng! I’m not *pant* wearing a condom or-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1054
translate chinese SR4_ES1a_second_5a2e8fbc:

    # Lily "Relax, you can finish wherever you want. If you want to cum inside, then you finish inside. I’m on the pill anyway."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1056
translate chinese SR4_ES1a_second_95e5ebe2:

    # Lily "(Well, at least when I remember to take it... Come to think of it, DID I take it this morning?)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1058
translate chinese SR4_ES1a_second_eded0c83:

    # MC "(Even if she’s on a contraceptive, there’s still a chance I could accidentally impregante Lily... There’d be no hiding it from Sara then. The smart move is to pull out.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1064
translate chinese SR4_ES1a_second_294aea57:

    # MC "*Pant* Mmm! *Gasp* Ooohh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1066
translate chinese SR4_ES1a_second_0e346373:

    # MC "(I’m getting pretty close. Another couple of thrusts and I’ll pull out and cum over her belly.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1068
translate chinese SR4_ES1a_second_52ba1cce:

    # Lily "Aww!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1071
translate chinese SR4_ES1a_second_34e395a9:

    # Lily "Ohh! Fuuck! This is amazing! I’m gonna cum, [player_name]! I’m cummmmiinnnng!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1073
translate chinese SR4_ES1a_second_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1077
translate chinese SR4_ES1a_second_5ae249ce:

    # MC "(Oh shit, her pussy is clamping around the tip of my cock as she cums! Fuck, it feels like she’s milking my dick!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1079
translate chinese SR4_ES1a_second_eb4995ca:

    # MC "(I need to pull out before I-)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1081
translate chinese SR4_ES1a_second_95071b21:

    # MC "Hnnnnggg! Noooo! Arrrgghhhh!!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1082
translate chinese SR4_ES1a_second_90559f50:

    # Lily "Ayaaahhhh!! YEESSSSSS!! Cum inside meeee!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1092
translate chinese SR4_ES1a_second_c904ef9b:

    # Lily "*Pant* That was amazing. Hehe, did I forget to mention that my pussy gets very clingy when I cum? I bet it felt like it was sucking you off. All those kegel exercises paid off."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1094
translate chinese SR4_ES1a_second_5bbba3b4:

    # MC "Ohh... Fuck... *Pant* Shit! *Gasp* Did I just cum inside you?! I think... I think I managed to pull out in time? Maybe it was a dry orgasm?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1096
translate chinese SR4_ES1a_second_e571b197:

    # Lily "I dunno, I definitely felt SOMETHING warm down there."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1100
translate chinese SR4_ES1a_second_b4da7c96:

    # MC "Oh no, no, no! Fuck!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1102
translate chinese SR4_ES1a_second_99b097e3:

    # MC "(Shit! I’ve creampied her! I knew I shouldn’t have agreed to her stupid game! She just kept tempting me again and again!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1106
translate chinese SR4_ES1a_second_f4ecc1fe:

    # Lily "Relax, [player_name]. I already told you I was on the pill. Nothing bad is gonna happen."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1108
translate chinese SR4_ES1a_second_af201067:

    # MC "Even if you ARE on the pill, I still cheated on Sara! I gave you a fucking creampie for God’s sake!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1110
translate chinese SR4_ES1a_second_719d1045:

    # Lily "Pfft, you were BARELY in my pussy. It’s not like you were blasting your semen directly at my cervix, right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1112
translate chinese SR4_ES1a_second_27e73fe1:

    # MC "*Sigh* We can’t let this happen again, Lily. This went WAY too far."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1114
translate chinese SR4_ES1a_second_d885417a:

    # Lily "Ugh, fine. Just try and work on your pull-out game next time."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1122
translate chinese SR4_ES1a_second_294aea57_1:

    # MC "*Pant* Mmm! *Gasp* Ooohh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1124
translate chinese SR4_ES1a_second_0e346373_1:

    # MC "(I’m getting pretty close. Another couple of thrusts and I’ll pull out and cum over her belly.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1126
translate chinese SR4_ES1a_second_52ba1cce_1:

    # Lily "Aww!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1129
translate chinese SR4_ES1a_second_34e395a9_1:

    # Lily "Ohh! Fuuck! This is amazing! I’m gonna cum, [player_name]! I’m cummmmiinnnng!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1131
translate chinese SR4_ES1a_second_e69f0e66_1:

    # MC "Hnnng!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1135
translate chinese SR4_ES1a_second_5ae249ce_1:

    # MC "(Oh shit, her pussy is clamping around the tip of my cock as she cums! Fuck, it feels like she’s milking my dick!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1137
translate chinese SR4_ES1a_second_351b2021:

    # Lily "Ahhh! YEESSS! OOOHHH!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1141
translate chinese SR4_ES1a_second_abd898c6:

    # MC "Hnnngg! Arrgh! "
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1151
translate chinese SR4_ES1a_second_9f14665c:

    # MC "*Pant* Mmmm! Aahh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1153
translate chinese SR4_ES1a_second_52ba1cce_2:

    # Lily "Aww!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1155
translate chinese SR4_ES1a_second_e8e1cae8:

    # Lily "(I thought I had him there! He pulled out on me at the last second!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1159
translate chinese SR4_ES1a_second_8549a012:

    # MC "Hnnnng! Ugghhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1163
translate chinese SR4_ES1a_second_c05a3876:

    # MC "*Gasp* *Pant* That was *Pant* waaaay too close. I almost *Pant* finished inside you at the end there."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1165
translate chinese SR4_ES1a_second_97403804:

    # Lily "You should have. You would have really enjoyed it. Imagine my vaginal walls clamping down around your sensitive glans as you orgasm. It would have been phenomenal."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1167
translate chinese SR4_ES1a_second_10131d8a:

    # Lily "Oh well, there’s always next time!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1169
translate chinese SR4_ES1a_second_2883eeb0:

    # MC "(Damn, she is REALLY persistent!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1176
translate chinese SR4_ES1a_second_end_aa21f26d:

    # Lily "You better get back. Sara’s going to wonder where you are, and I really don’t need her suspecting me of hanging out with you privately right now."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1178
translate chinese SR4_ES1a_second_end_b14df790:

    # MC "Yeah, I get that."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1180
translate chinese SR4_ES1a_second_end_0a7d2c3b:

    # Lily "So, am I going to see you again for round three?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1184
translate chinese SR4_ES1a_second_end_55cffba0:

    # MC "That depends on what you had in mind. If you try to escalate things again, then I probably shouldn’t keep coming back over."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1186
translate chinese SR4_ES1a_second_end_e33980f7:

    # Lily "Aww, but you enjoy my company, don’t you? Isn’t it nice having a slutty girl like me for a change? It must be so EXHAUSTING having to teach Sara every single basic thing about sex. You can skip straight to the fun part with me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1188
translate chinese SR4_ES1a_second_end_2c1561e6:

    # Lily "Aww, but you enjoy my company, don't you? Isn't it nice having a slutty girl like me for a change?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1191
translate chinese SR4_ES1a_second_end_d8c29db3:

    # MC "I mean it, Lily. I’m not going any farther than today."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1195
translate chinese SR4_ES1a_second_end_fcd08092:

    # Lily "*Sigh* Fine. Next time we meet up we’ll play just the tip again. It’s hardly fair on me that you get all the pleasure when you come over and I just suck your cock."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1197
translate chinese SR4_ES1a_second_end_1493a723:

    # MC "Alright, fine."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1199
translate chinese SR4_ES1a_second_end_5bb57e0e:

    # Lily "In that case, I’ll see you again soon, [player_name]."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1203
translate chinese SR4_ES1a_second_end_aad980bd:

    # MC "Catch you later, Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1232
translate chinese SR4_ES1a_third_f85f1328:

    # MC "(What am I even doing coming back here again? I keep going way too far with Lily.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1234
translate chinese SR4_ES1a_third_d719e402:

    # MC "(She’s deceptive, she tricks me, she outright lies...)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1238
translate chinese SR4_ES1a_third_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1240
translate chinese SR4_ES1a_third_805c167d:

    # MC "(I’ll stand my ground this time and draw a line in the sand. We won’t go any further than playing her ‘just the tip’ game.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1245
translate chinese SR4_ES1a_third_24838be3:

    # MC "Hey Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1247
translate chinese SR4_ES1a_third_8e14dafb:

    # Lily "Oh, hey [player_name]. I knew you were horny, but I didn’t expect you’d be back again this soon."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1251
translate chinese SR4_ES1a_third_ea01b215:

    # Lily "Is Sara just not doing it for you anymore? Hehe!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1253
translate chinese SR4_ES1a_third_4ac02822:

    # MC "This has nothing to do with Sara, I’m simply coming over for a little bit of casual fun. Nothing we haven’t done before."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1255
translate chinese SR4_ES1a_third_ef1e6a11:

    # Lily "Uh huh, suuuure."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1257
translate chinese SR4_ES1a_third_a008eb1e:

    # MC "I’m serious Lily. I’m not going any farther than we did last time. I’m not going to-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1261
translate chinese SR4_ES1a_third_e41e256e:

    # Lily "There’s cold beer waiting for you in the fridge and a hot girl waiting for you in the bedroom."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1263
translate chinese SR4_ES1a_third_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1265
translate chinese SR4_ES1a_third_ee5a1db2:

    # MC "(I don’t think she even listened to what I was saying at all. I can still stand my ground though.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1269
translate chinese SR4_ES1a_third_073475d7:

    # Lily "Well? What are you waiting for? C’mon sit down beside me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1273
translate chinese SR4_ES1a_third_67d9ae6f:

    # MC "Listen, Lily, I think we can both agree we went a little too far with that just-the-tip game we played last time."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1275
translate chinese SR4_ES1a_third_c4ac9880:

    # MC "So, I was thinking, maybe we could just settle for you using your mouth again today?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1279
translate chinese SR4_ES1a_third_5f1af5bc:

    # Lily "Where’s the fun in that for me though? You get to have your dick sucked while I’m left unsatisfied. That doesn’t sound fair at all, does it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1283
translate chinese SR4_ES1a_third_f30002f3:

    # MC "I’m sorry, Lily. I just have to try and put my foot down. I can’t-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1285
translate chinese SR4_ES1a_third_5908ca3b:

    # Lily "(It appears that [player_name] is getting a little uncomfortable with how far we went last time. I just need to make him a bit hornier and he won’t be able to resist me!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1292
translate chinese SR4_ES1a_third_9c3f9e0f:

    # MC "Mmpff!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1294
translate chinese SR4_ES1a_third_1c6f3989:

    # Lily "Mmmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1298
translate chinese SR4_ES1a_third_b40c73ab:

    # Lily "(I can feel his dick stiffening beneath his pants! He’s starting to get hard! Let’s see if I can push the idea of playing the just-the-tip game again.)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1300
translate chinese SR4_ES1a_third_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1302
translate chinese SR4_ES1a_third_91e9036f:

    # MC "(She took me by surprise there!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1306
translate chinese SR4_ES1a_third_da5c89f6:

    # Lily "What’s wrong, [player_name]? You’re looking a little flustered there."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1308
translate chinese SR4_ES1a_third_6323bdd5:

    # MC "I... I know what you’re trying to do, Lily. You’re trying to turn me on so I’ll play that game with you instead of just taking a blowjob."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1312
translate chinese SR4_ES1a_third_3a6eba48:

    # Lily "Whaaat? I have no idea what you’re talking about!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1314
translate chinese SR4_ES1a_third_13063bf8:

    # MC "Oh, c’mon. Don’t act all innocent! I know you’ve been manipulating me since I first swung by to try and stop Sara from literally killing you!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1316
translate chinese SR4_ES1a_third_e4a66595:

    # Lily "It’s really warm in here, isn’t it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1320
translate chinese SR4_ES1a_third_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1322
translate chinese SR4_ES1a_third_bfc43b76:

    # Lily "I’m, like, super warm right now, so I’m gonna take these off."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1324
translate chinese SR4_ES1a_third_468ada00:

    # MC "Lily!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1328
translate chinese SR4_ES1a_third_69c88940:

    # Lily "Oh relax, it’s not like you haven’t seen my ass before. Drink your beer and enjoy the view."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1330
translate chinese SR4_ES1a_third_c2800ee6:

    # MC "(She’s trying to seduce me again.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1334
translate chinese SR4_ES1a_third_0186e3e0:

    # Lily "That’s better. I just hate it when it gets waaay too hot."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1336
translate chinese SR4_ES1a_third_d656f311:

    # MC "*Sigh* Lily, what are you playing at?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1340
translate chinese SR4_ES1a_third_96a83608:

    # Lily "I was just thinking, if I’m going to be down on my knees sucking on your cock, then I’m not going to be getting to cum myself."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1342
translate chinese SR4_ES1a_third_e79f7d54:

    # Lily "So, it only makes sense that I should finish myself off first before I start licking your dick."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1346
translate chinese SR4_ES1a_third_580b29b7:

    # Lily "I’m not sayin’ that you have to get involved, you can just watch me rub my pussy like mmm... this..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1348
translate chinese SR4_ES1a_third_aaacf40e:

    # Lily "Ah..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1350
translate chinese SR4_ES1a_third_b31b21df:

    # Lily "I’ll crawl over and suck your shaft when I’m - oooohh... done. Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1354
translate chinese SR4_ES1a_third_4f1cb09f:

    # Lily "Ahmmm... Of course, you could always join me right now if you wanted. Oooh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1356
translate chinese SR4_ES1a_third_257b872f:

    # MC "Lily, I-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1358
translate chinese SR4_ES1a_third_b7c71bb3:

    # Lily "You’ve stuck the tip of your dick in my pussy before. You can do it again. It’s not cheating and Sara will never suspect a thing."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1360
translate chinese SR4_ES1a_third_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1364
translate chinese SR4_ES1a_third_8b1f1f3a:

    # Lily "*Pant* Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1366
translate chinese SR4_ES1a_third_5fe948e3:

    # Lily "How about you warm yourself up for the blowjob? Just take your cock and ahh... grind it against my vulva? You don’t even mmm... have to put it in."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1368
translate chinese SR4_ES1a_third_acde21c1:

    # MC "... *Sigh* Fine, but no penetration."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1370
translate chinese SR4_ES1a_third_3e6ae9ce:

    # Lily "Hehe, of course!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1374
translate chinese SR4_ES1a_third_6bc31c2e:

    # Lily "Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1376
translate chinese SR4_ES1a_third_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1378
translate chinese SR4_ES1a_third_1c042fcc:

    # Lily "See? Not bad, right? Can you feel how wet I am for you? I bet your dick would slip inside me super easily if you let it."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1380
translate chinese SR4_ES1a_third_bc568e8a:

    # MC "*Pant* Hnnng..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1384
translate chinese SR4_ES1a_third_d5c7b4fd:

    # MC "You’re ugh... trying to tempt me into cheating again, Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1386
translate chinese SR4_ES1a_third_869255f6:

    # Lily "Hehe, I don’t know what you’re talking about!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1388
translate chinese SR4_ES1a_third_3bc89867:

    # MC "I don’t trust you."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1392
translate chinese SR4_ES1a_third_e6a2e91a:

    # Lily "Listen, [player_name], I ran out of my birth control this morning. It would be terrible for both of us if you finished inside me. I swear, I’m not trying to tempt you into cheating."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1394
translate chinese SR4_ES1a_third_9a3fd3ef:

    # MC "Hmm, alright."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1396
translate chinese SR4_ES1a_third_2b66a5fb:

    # Lily "However... if you wanted to have a little bit of fun BEFORE I give you a blowjob, you could always try sticking the tip in again like last time."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1398
translate chinese SR4_ES1a_third_da67129a:

    # MC "*Sigh* Do you have a condom or anything?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1400
translate chinese SR4_ES1a_third_d1b96707:

    # Lily "Nope, but we’re not going to be doing it for too long, so you shouldn’t really be cumming that quickly. We’ll switch to a blowjob before you feel like you’re about to finish. Okay?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1404
translate chinese SR4_ES1a_third_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1406
translate chinese SR4_ES1a_third_4f42ab99:

    # MC "(Ah, fuck it. It’s not like I haven’t already done this before with Lily!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1410
translate chinese SR4_ES1a_third_309a795a:

    # MC "Ooh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1412
translate chinese SR4_ES1a_third_d95d3bb5:

    # Lily "Mmm... See? Feels ah... good, right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1414
translate chinese SR4_ES1a_third_00d9141d:

    # MC "*Pant* Mmm..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1418
translate chinese SR4_ES1a_third_fb34ae7c:

    # Lily "Ooohh! I love feeling you rock your hips back and forth like that."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1420
translate chinese SR4_ES1a_third_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1422
translate chinese SR4_ES1a_third_8bbb80ce:

    # MC "(Keep your wits about you, [player_name]. Get ready to pull out if you feel like you’re about to cum.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1426
translate chinese SR4_ES1a_third_227291ca:

    # Lily "Ah! Ahh! Mmm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1428
translate chinese SR4_ES1a_third_96a826e9:

    # Lily "How does it feel to have my tight, wet pussy clamping down around your glans? Mmm! Pretty good, I imagine."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1430
translate chinese SR4_ES1a_third_bc568e8a_1:

    # MC "*Pant* Hnnng..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1434
translate chinese SR4_ES1a_third_ef3e4d83:

    # Lily "God, I bet you wish you could ooohhh... just THRUST deep inside me right now..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1437
translate chinese SR4_ES1a_third_9e8b33a8:

    # Lily "...but you can’t. Mmm! Because THAT would be cheating, and you don’t want to cheat on your stupid little sister, Sara, do you?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1439
translate chinese SR4_ES1a_third_2023360c:

    # Lily "...but you can't. Mmm! Because THAT would be cheating, and you don't want to cheat on your stupid nerdy girlfriend, Sara, do you?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1441
translate chinese SR4_ES1a_third_c33840a9:

    # MC "Ugh... *Pant*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1445
translate chinese SR4_ES1a_third_61f68df1:

    # Lily "I bet you’d love to know what the deepest parts of my pussy feel like. Ooohh! You probably dream about my tight teenage cunt engulfing your thick shaft."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1447
translate chinese SR4_ES1a_third_ee6162c0:

    # Lily "I bet you’d love to know what the deepest parts of my pussy feel like. Ooohh! You probably dream about my tight little cunt engulfing your thick shaft."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1449
translate chinese SR4_ES1a_third_07b34297:

    # MC "(Ignore her, ignore her!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1451
translate chinese SR4_ES1a_third_92cc8015:

    # Lily "It’s such a shame you’re ah... never going to *Gasp* get to truly experience it...."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1455
translate chinese SR4_ES1a_third_96c5428a:

    # Lily "...unless you were to shove your cock deep inside me. Imagine how good it would feel to just give up control and fuck me like I’m Sara."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1457
translate chinese SR4_ES1a_third_de0997d1:

    # MC "Lily, I can’t-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1459
translate chinese SR4_ES1a_third_f9ec8d8c:

    # Lily "You’re right. It would be stupid. You’d DEFINITELY be cheating on Sara, AND it would be SOOO dangerous to fuck me right now."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1463
translate chinese SR4_ES1a_third_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1465
translate chinese SR4_ES1a_third_933476bd:

    # Lily "No condom... No birth control... Mmm..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1467
translate chinese SR4_ES1a_third_a58ba445:

    # Lily "You probably haven’t even jerked yourself off today, so your balls are probably full with your thick, potent semen."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1471
translate chinese SR4_ES1a_third_834a996b:

    # MC "(Resist her, [player_name]! Pull yourself together!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1473
translate chinese SR4_ES1a_third_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1475
translate chinese SR4_ES1a_third_275d194f:

    # Lily "Just one mistake... One slip up... One little accident where you lose control, and you could empty your balls deep in my fertile womb."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1479
translate chinese SR4_ES1a_third_26cdd4d1:

    # Lily "Of course, maybe you’ll be able to keep your cool. Maybe you’d be sensible enough to pull out in time. If you did that then you’d get to enjoy fucking my wet cunt."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1481
translate chinese SR4_ES1a_third_4886a741:

    # Lily "But could you REALLY resist not giving me a creampie, [player_name]?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1483
translate chinese SR4_ES1a_third_a7c2d1b6:

    # MC "Hnnng... (Fuck, fuck, fuck!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1485
translate chinese SR4_ES1a_third_299729c1:

    # Lily "Imagine the feeling as I cum. My vaginal walls contracting around your shaft, milking every last drop of cum from your-"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1489
translate chinese SR4_ES1a_third_7de05bf2:

    # MC "HNNNG!! ARGGHHH!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1491
translate chinese SR4_ES1a_third_14979427:

    # Lily "OOOHHHH!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1493
translate chinese SR4_ES1a_third_f5402402:

    # Lily "(Mwahahaha! You put up a fight, but I always knew I’d get you eventually, [player_name]!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1497
translate chinese SR4_ES1a_third_f148c256:

    # Lily "Mmm! Looks like you just couldn’t resist me, could you, [player_name]?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1499
translate chinese SR4_ES1a_third_c140feb0:

    # MC "*Pant* Shit... Hnnng..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1501
translate chinese SR4_ES1a_third_413d177d:

    # Lily "Go on... Thrust your hips. You’re already inside me. I want to feel your thick cock sliding in and out of me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1505
translate chinese SR4_ES1a_third_52857d5e:

    # MC "(Fuck... She tricked me again... How does she keep managing to do this?!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1507
translate chinese SR4_ES1a_third_8126da6d:

    # Lily "*Pant* Ah! Yeessss!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1510
translate chinese SR4_ES1a_third_8c8c22de:

    # MC "Shit, I didn’t mean to-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1514
translate chinese SR4_ES1a_third_b2963705:

    # Lily "You’ve already thrust your cock inside me, [player_name]. You might as well do it a few more times and enjoy it. It isn’t going to make a difference at this point, is it?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1516
translate chinese SR4_ES1a_third_bf09af38:

    # MC "No, but-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1518
translate chinese SR4_ES1a_third_a0abd778:

    # Lily "Besides, doesn’t my tight teen pussy feel SOOOO much better than a blowjob?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1520
translate chinese SR4_ES1a_third_9d35623f:

    # Lily "Besides, doesn’t my tight little pussy feel SOOOO much better than a blowjob?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1522
translate chinese SR4_ES1a_third_4ab90a2e_2:

    # MC "*Gulp*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1526
translate chinese SR4_ES1a_third_2567c70a:

    # Lily "Mmm! Hehe! That’s it! Ahh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1528
translate chinese SR4_ES1a_third_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1530
translate chinese SR4_ES1a_third_e54c29b6:

    # Lily "Does my wet fuckhole feel better than Sara’s?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1534
translate chinese SR4_ES1a_third_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1536
translate chinese SR4_ES1a_third_e6049976:

    # Lily "It probably does. *Gasp* I bet you’re getting all excited at the taboo of screwing me. It turns you on knowing that you shouldn’t be fucking me while you’re dating Sara. Mmm..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1538
translate chinese SR4_ES1a_third_7cdaec15:

    # Lily "Heck, it probably turns you on even more than I’m off my birth control, doesn’t it? Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1542
translate chinese SR4_ES1a_third_2a315a9a:

    # Lily "Go on, [player_name], shove your cock balls deep inside me. I want to feel your thick dick stretching my ahhh... pussy! Mmmm! Yeeesss!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1544
translate chinese SR4_ES1a_third_531b574d:

    # MC "Hnnngg! Ah! *Pant*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1546
translate chinese SR4_ES1a_third_1a94f54c:

    # Lily "(Hehe, I’ve got him wrapped around my finger!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1550
translate chinese SR4_ES1a_third_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1552
translate chinese SR4_ES1a_third_25ceae7a:

    # Lily "Every thrust just ayaaahh... feels so wrong, doesn’t it, [player_name]? At least, *Pant* until it doesn’t."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1554
translate chinese SR4_ES1a_third_4bc9eabb:

    # Lily "Ah! Ahhhh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1558
translate chinese SR4_ES1a_third_9146e33b:

    # Lily "It was the same as when I kissed you oooohhh... or when I stroked your cock, or when I kissed it... Mmmmm... and then slowly sucked it."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1560
translate chinese SR4_ES1a_third_9975eb01:

    # MC "*Pant* Hnnnng..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1562
translate chinese SR4_ES1a_third_66793e9c:

    # Lily "You just can’t resist me, [player_name]. All that pleasure you’re feeling right now is because you gave into me every step of the way."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1564
translate chinese SR4_ES1a_third_3d8d9cbf:

    # MC "Ahh... Hnnnngg! Argh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1568
translate chinese SR4_ES1a_third_525241ae:

    # Lily "Oh God! I’m about to cum, [player_name]! Can you mmm... feel my pussy clenching around your aaahhhh... fat cock?!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1570
translate chinese SR4_ES1a_third_60734d6a:

    # Lily "Go on, [player_name]! Fuck me! You know you want this! Fill my slutty little pussy with your aaahhhh... hot cuuuumm!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1572
translate chinese SR4_ES1a_third_894a6999:

    # MC "(Shit, I need to pull out! I need to-)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1574
translate chinese SR4_ES1a_third_4611164e:

    # Lily "AYAAAHHHHHH!! OOHHHHHH!!!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1576
translate chinese SR4_ES1a_third_59f562e9:

    # MC "HNNNNGGG! *Pant* Ooohhhhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1587
translate chinese SR4_ES1a_third_3a65bbb7:

    # Lily "Yeesss! Fill me up! Oohhhhh!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1589
translate chinese SR4_ES1a_third_1161d562:

    # MC "*Pant* Sh-Shit... Fuck..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1593
translate chinese SR4_ES1a_third_f2d9c7bc:

    # Lily "Pretty fun, right? Told you my pussy was better than a blowjob!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1595
translate chinese SR4_ES1a_third_06f631ad:

    # MC "Lily, you aren’t on birth control!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1597
translate chinese SR4_ES1a_third_cfcf8671:

    # Lily "Life’s no fun without a little risk every now and then. Live in the moment, [player_name]."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1601
translate chinese SR4_ES1a_third_e640a53a:

    # MC "*Pant* *Pant* You’re dangerous to be around, Lily. You know that?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1603
translate chinese SR4_ES1a_third_116849a5:

    # Lily "Hehe, I think I’m quite fun actually."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1605
translate chinese SR4_ES1a_third_afcd9d8f:

    # MC "Fuck... What the heck am I supposed to say to Sara?!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1607
translate chinese SR4_ES1a_third_8a070b4a:

    # Lily "Absolutely nothing. As soon as you walk out of this apartment, you pretend this never happened."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1609
translate chinese SR4_ES1a_third_a0611026:

    # Lily "You act completely normal around Sara. You make out with her, you let her suck your dick, you fuck her - and, most importantly, you pretend that she’s half as good as I am at any of those things."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1611
translate chinese SR4_ES1a_third_ef2b24e8:

    # MC "You’re... morally bankrupt, you know that?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1615
translate chinese SR4_ES1a_third_cad514bb:

    # Lily "Oh, one more thing, keep coming to visit me! It’s nice to find a cock that can thoroughly satisfy me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1617
translate chinese SR4_ES1a_third_419ce3e6:

    # MC "*Sigh* Goodbye Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1619
translate chinese SR4_ES1a_third_57811a01:

    # Lily "See you again soon! Hehe!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1650
translate chinese SR4_ES1a_fourth_2d2a527d:

    # MC "(This shit has gone on long enough. Lily tricked and deceived me time and time again into fucking her!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1654
translate chinese SR4_ES1a_fourth_0ebfc4cb:

    # MC "(I’m going to make things right today.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1656
translate chinese SR4_ES1a_fourth_bd798f53:

    # "*BANG BANG*"
    ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1660
translate chinese SR4_ES1a_fourth_f501d128:

    # Lily "Hey again! Just can’t get enough of me, can ya? Hehe!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1662
translate chinese SR4_ES1a_fourth_4a468031:

    # MC "No, Lily. I came here to put an end to this nonsense you started."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1666
translate chinese SR4_ES1a_fourth_1f2994a2:

    # Lily "OoooOoooOOOOhhh! Somebody’s got their big boy pants on today!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1668
translate chinese SR4_ES1a_fourth_24395ae6:

    # MC "I’m serious, Lily!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1669
translate chinese SR4_ES1a_fourth_25343536:

    # Lily "“i’M sErIOuS, LiLy!”"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1671
translate chinese SR4_ES1a_fourth_b5ca161f:

    # MC "I do not sound like that!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1675
translate chinese SR4_ES1a_fourth_87a8a5a2:

    # Lily "Hehe! Beer’s in the fridge."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1677
translate chinese SR4_ES1a_fourth_528631e9:

    # MC "Grr..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1681
translate chinese SR4_ES1a_fourth_9093ef35:

    # MC "(Does she literally just sit around in her lingerie every evening on the off-chance I show up?!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1685
translate chinese SR4_ES1a_fourth_b30ce4d2:

    # Lily "So, I’m thinking that I strip out of my panties, lean against the wall, spread my legs, and let you pound me until-"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1687
translate chinese SR4_ES1a_fourth_0f8ee1c5:

    # MC "Lily! I said I was going to put an end to this today!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1689
translate chinese SR4_ES1a_fourth_3df0ecae:

    # Lily "Suuure... Listen, how about you stop screaming and sit down beside me so we can have a normal discussion like adults?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1691
translate chinese SR4_ES1a_fourth_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1695
translate chinese SR4_ES1a_fourth_c3e018f1:

    # Lily "See? Better?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1697
translate chinese SR4_ES1a_fourth_d2a5678b:

    # MC "We can’t keep doing this, Lily. It has to end."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1701
translate chinese SR4_ES1a_fourth_57269bf5:

    # Lily "Does it though?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1703
translate chinese SR4_ES1a_fourth_ca455b78:

    # MC "YES! It does! I can’t spend ANY time with Sara without YOU popping into my fucking head! You’re incessant! You always fucking show up at the worst possible moment! You’re- You’re..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1707
translate chinese SR4_ES1a_fourth_af31aa86:

    # MC "...you’re the human equivalent of a Raid Shadow Legends advert!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1709
translate chinese SR4_ES1a_fourth_a9577241:

    # Lily "*Glug* *Glug*"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1711
translate chinese SR4_ES1a_fourth_2f1f0220:

    # MC "Argh! You’ve RUINED my relationship with Sara. Do you know that?! You’re a terrible person!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1715
translate chinese SR4_ES1a_fourth_55ae5df1:

    # Lily "Have I though?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1717
translate chinese SR4_ES1a_fourth_19570c32:

    # MC "What?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1719
translate chinese SR4_ES1a_fourth_18b45c3c:

    # Lily "I mean, does she actually know we’re fucking?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1721
translate chinese SR4_ES1a_fourth_bf09af38:

    # MC "No, but-"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1723
translate chinese SR4_ES1a_fourth_add03f25:

    # Lily "If she doesn’t know... and she hasn’t changed how she’s acting around you, then how exactly is the relationship with Sara ruined?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1727
translate chinese SR4_ES1a_fourth_f45a0358:

    # MC "God... it’s this. You’re doing your fucking lawyer-talk again!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1729
translate chinese SR4_ES1a_fourth_613e37cb:

    # Lily "Ooh, you must really hate me right now. Hehe! But seriously, though, what’s changed? Sara doesn’t know any better."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1731
translate chinese SR4_ES1a_fourth_a1fe773f:

    # MC "I KNOW BETTER!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1738
translate chinese SR4_ES1a_fourth_44d8934d:

    # Lily "Ahh, so it’s your own guilt that’s eating you up - NOT Sara’s opinion of your relationship with her."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1740
translate chinese SR4_ES1a_fourth_71c855e3:

    # MC "Lily, what are you doing?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1742
translate chinese SR4_ES1a_fourth_365fede8:

    # Lily "I’m just trying to explain that your relationship with Sara isn’t ruined."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1746
translate chinese SR4_ES1a_fourth_998014c8:

    # Lily "You two can still go on your little dates, buttfuck, give each other awkward oral sex. Sara gets to enjoy her mirage of a happy life, while you get to enjoy some ACTUAL sexual satisfaction."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1748
translate chinese SR4_ES1a_fourth_af70de44:

    # Lily "Plus, I get a good dicking when I want it. From where I’m standing, this is an absolute win for everybody. Right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1750
translate chinese SR4_ES1a_fourth_f1c1f45e:

    # MC "It’s not fair to Sara though. You’re supposed to be her best friend! And you’ve- you’ve irreparably damaged what my sister and I had!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1752
translate chinese SR4_ES1a_fourth_87c7e629:

    # MC "It’s not fair to Sara though. You’re supposed to be her best friend! And you’ve- you’ve irreparably damaged what my girlfriend and I had!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1756
translate chinese SR4_ES1a_fourth_beaefbdf:

    # Lily "Gee, it sounds like you really hate me right now."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1758
translate chinese SR4_ES1a_fourth_e42d434c:

    # MC "I fucking despise you, Lily. I hate you with every fibre of my being - and I hate myself for constantly coming over here, thinking that I could somehow fix things."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1760
translate chinese SR4_ES1a_fourth_6997cf8b:

    # Lily "Go on, let it all out."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1762
translate chinese SR4_ES1a_fourth_7573797d:

    # MC "I see it now, clear as day. You’re like a fungus that’s gotten into the timbers of a house. And every time I try to tear out another rotten floorboard I find the rot has spread further and further."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1766
translate chinese SR4_ES1a_fourth_cb674749:

    # MC " And so, I come back and rip out another one. And another one. Each time finding that the fungus has just spread and spread, and by ripping those planks out I’m only spreading your Goddamn spores!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1768
translate chinese SR4_ES1a_fourth_df2e50a1:

    # MC "And then... when it’s all over, I’m left standing in nothing more than a husk of what was supposed to be a home."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1772
translate chinese SR4_ES1a_fourth_a7e694ad:

    # Lily "You really feel like I’ve ruined your life, don’t you?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1774
translate chinese SR4_ES1a_fourth_b29b68bb:

    # MC "Yes! That’s EXACTLY what I’ve been saying! Have you not been listening?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1776
translate chinese SR4_ES1a_fourth_9ce1d7b5:

    # Lily "Would getting even make you feel better?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1778
translate chinese SR4_ES1a_fourth_b5001821:

    # MC "Getting even?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1780
translate chinese SR4_ES1a_fourth_8dbdb769:

    # Lily "Yeah, I’ll give you a shot at ruining my life. That ought to make us even."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1782
translate chinese SR4_ES1a_fourth_fe0417fe:

    # MC "Hmm, what are you suggesting?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1784
translate chinese SR4_ES1a_fourth_d1d64c1f:

    # Lily "I actually lied to you the last time you were here..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1786
translate chinese SR4_ES1a_fourth_f785aeef:

    # MC "(No surprise there!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1788
translate chinese SR4_ES1a_fourth_d3778cca:

    # Lily "...I actually WAS on birth control. I’m not anymore. Of course, I did a pregnancy test to be safe and, thankfully, it was negative."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1790
translate chinese SR4_ES1a_fourth_9e0e1b16:

    # Lily "I’m going to offer you a second chance today, [player_name]. Fuck me raw. No protection. Finish inside my fertile teen pussy. Try and knock me up."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1792
translate chinese SR4_ES1a_fourth_ae021b31:

    # Lily "I’m going to offer you a second chance today, [player_name]. Fuck me raw. No protection. Finish inside my fertile little pussy. Try and knock me up."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1794
translate chinese SR4_ES1a_fourth_9bb4f3ef:

    # MC "(Ah, fuck it. Lily deserves what’s coming to her!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1798
translate chinese SR4_ES1a_fourth_fe8634a5:

    # MC "Alright, Lily... turn around and face the wall."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1800
translate chinese SR4_ES1a_fourth_d47ba187:

    # MC "(If this bitch is offering me the chance to ruin her life, then that’s EXACTLY what I’m going to do.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1804
translate chinese SR4_ES1a_fourth_2da1a9a1:

    # Lily "Well? What are you waiting for? This is your chance, [player_name]. Take it."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1806
translate chinese SR4_ES1a_fourth_0ae7e9fc:

    # Lily "I know you want this. You want to cause me as much pain as I’ve caused you. So, go on, fuck me without a condom."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1810
translate chinese SR4_ES1a_fourth_1a8182d0:

    # Lily "Thrust your fat cock into my tight little pussy. Finish deep inside my body. "
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1814
translate chinese SR4_ES1a_fourth_fdafa233:

    # Lily "This is your opportunity to get even with me, [player_name]. Carpe diem. Fill my unprotected pussy up with your hot cum."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1816
translate chinese SR4_ES1a_fourth_8c303aa4:

    # Lily "Take a shot at impregnating me. I’ll probably have to drop out of campus if that happens. "
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1819
translate chinese SR4_ES1a_fourth_2b842db9:

    # Lily "Sara would love that, wouldn’t she? Not having me around anymore is EXACTLY what she always wanted."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1821
translate chinese SR4_ES1a_fourth_f67e8ca4:

    # MC "(She makes a compelling argument. This is what Lily deserves after all the shit she’s pulled!)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1825
translate chinese SR4_ES1a_fourth_e75a4604:

    # Lily "Go on, [player_name]. Fuck me raw and smear my womb with your semen. Doesn’t the thought of ruining my life bring you some satisfaction, [player_name]?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1827
translate chinese SR4_ES1a_fourth_aad376ae:

    # Lily "Imagine me, kicked off campus, unable to pursue my dream job, reduced to just another teen mom. That’s schadenfreude right there for everything I did to you and Sara. So, go on [player_name]... hatefuck me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1829
translate chinese SR4_ES1a_fourth_31b0113c:

    # Lily "Imagine me, kicked off campus, unable to pursue my dream job, reduced to just another single mom. That’s schadenfreude right there for everything I did to you and Sara. So, go on [player_name]... hatefuck me."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1830
translate chinese SR4_ES1a_fourth_f5feb9de:

    # Lily "Unless you aren’t man enough to take your revenge?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1834
translate chinese SR4_ES1a_fourth_2d204a49:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1836
translate chinese SR4_ES1a_fourth_404e7c58:

    # Lily "That’s what I thought. You’ve got my vulnerable, unprotected pussy just ripe for the taking, but you can’t bring yourself to..."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1840
translate chinese SR4_ES1a_fourth_e00005c4:

    # Lily "Ayaaahhhh!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1842
translate chinese SR4_ES1a_fourth_1001deb4:

    # MC "Ugghhhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1844
translate chinese SR4_ES1a_fourth_b6cf4e12:

    # Lily "OOOHHHHH!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1848
translate chinese SR4_ES1a_fourth_fc114e58:

    # Lily "*Gasp* Ha... Hah... S-So you DO have some fight in you!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1850
translate chinese SR4_ES1a_fourth_34fdc76c:

    # MC "I hate you so Goddamn much! This is for making me cheat on Sara like that!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1852
translate chinese SR4_ES1a_fourth_3e38df5f:

    # Lily "Uh huh! Tell me what you’re gonna do to me! Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1856
translate chinese SR4_ES1a_fourth_8293407b:

    # MC "I’m gonna pound your pussy so fucking hard. You told me to take a shot at ruining your life, so that’s just what I’m going to do."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1858
translate chinese SR4_ES1a_fourth_e6ecdd12:

    # Lily "Ah! Ah! Ahh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1860
translate chinese SR4_ES1a_fourth_4bbc07c6:

    # MC "Arrrgghh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1864
translate chinese SR4_ES1a_fourth_7a50685b:

    # Lily "AH! AHHH! AHHH!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1866
translate chinese SR4_ES1a_fourth_d9e2d906:

    # MC "Whenever I hnnng... feel myself about to cum, I’m going to make sure that *Pant* I go balls deep inside you."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1868
translate chinese SR4_ES1a_fourth_de2dd979:

    # Lily "AAAAAYYAAAHHHHHHHH!! OOOHHHHHH!!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1872
translate chinese SR4_ES1a_fourth_6c508204:

    # MC "I’m going to pin you against this wall and hold my dick as tightly as I can inside you, and I’m not going *Pant* to move until I feel the last droplets of cum leave my balls."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1874
translate chinese SR4_ES1a_fourth_d6b69994:

    # Lily "Haaaahhhhhh!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1876
translate chinese SR4_ES1a_fourth_9022a77b:

    # MC "I’m going to impregnate you today, Lily. Were you seriously so arrogant in not taking your birth control? Did you ACTUALLY think I wouldn’t do this when you invited me to ruin your life?"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1880
translate chinese SR4_ES1a_fourth_f886adca:

    # Lily "AHHHHHH! OOOHHHHHHH!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1882
translate chinese SR4_ES1a_fourth_1b34b0e8:

    # MC "Hnnnng! Ugh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1884
translate chinese SR4_ES1a_fourth_6bd3c15b:

    # MC "Was it worth it, Lily? Argh! Was it worth risking your future for a bit of risky sex? Hnnng!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1889
translate chinese SR4_ES1a_fourth_2e052728:

    # Lily "OOOHHHHHHHH!!! AAAHHHHHH!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1891
translate chinese SR4_ES1a_fourth_a3eaadf0:

    # Lily "(Oh my God, this is sooooo fucking hot! I always got so wet seducing [player_name] into doing things with me when he was dating Sara, but having him aggressively dominate me like this is a WHOLE other level!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1895
translate chinese SR4_ES1a_fourth_96129697:

    # MC "Ugh! This is for all the times you made me cheat on Sara!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1897
translate chinese SR4_ES1a_fourth_534d604c:

    # Lily "Ah!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1899
translate chinese SR4_ES1a_fourth_16e2ac38:

    # MC "HNNNGGG! Arrghh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1903
translate chinese SR4_ES1a_fourth_efd2892b:

    # Lily "*Pant* Ah! Ahhhhhh! [player_name], listen to me, I-"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1905
translate chinese SR4_ES1a_fourth_15390ceb:

    # MC "I know what your game plan is, Lily. You wanted to play dangerously, and NOW you’re going to try and use your silver tongue to talk your way out of this one."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1907
translate chinese SR4_ES1a_fourth_c4e6326b:

    # MC "Well, tough luck, because I’m not listening to you anymore."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1909
translate chinese SR4_ES1a_fourth_688352bb:

    # Lily "Wh-What?! *Pant* N-No, wait, I-"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1913
translate chinese SR4_ES1a_fourth_175bd1fc:

    # MC "You’re the one who taunted me into impregnating you to ruin your life. Arghh! I don’t know what your end game was, but you were definitely going to try and talk me into something else there."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1915
translate chinese SR4_ES1a_fourth_8990c43a:

    # Lily "*GASP* Ahh! [player_name]! Ohhh! Th-Think about this! I’m not on the pill, I’ll-"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1917
translate chinese SR4_ES1a_fourth_a5eaafe5:

    # MC "HNNNG!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1919
translate chinese SR4_ES1a_fourth_07a2411d:

    # Lily "AYAAAHHHHH!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1923
translate chinese SR4_ES1a_fourth_806ec35c:

    # MC "I hate you so fucking much, Lily!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1925
translate chinese SR4_ES1a_fourth_aeecc3ae:

    # Lily "AAAHHHH!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1927
translate chinese SR4_ES1a_fourth_f7bed815:

    # MC "I hope you experience some kind of regret when you feel my semen rushing up against your cervix. Hnnnngg!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1929
translate chinese SR4_ES1a_fourth_1c5f8969:

    # Lily "*Pant* Ahhhhhh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1933
translate chinese SR4_ES1a_fourth_b9015c6b:

    # Lily "OOOHHHHHH!!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1935
translate chinese SR4_ES1a_fourth_3b423bfc:

    # MC "HNNNGG! Fuck! I’m getting close!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1937
translate chinese SR4_ES1a_fourth_846d6a0d:

    # Lily "OOoooohhhhHHHHHH!!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1941
translate chinese SR4_ES1a_fourth_c0455261:

    # MC "Arrghhh! TAKE IT! UGH!!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1943
translate chinese SR4_ES1a_fourth_28af89c9:

    # Lily "*GASP* NOOOOOOOOO!! OOHHHHHHHH! FFUUUUUUUCCCKK!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1945
translate chinese SR4_ES1a_fourth_bd53a7b4:

    # Lily "(His dick’s twitching inside me! He’s about to cum!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1949
translate chinese SR4_ES1a_fourth_6095d818:

    # MC "Aarrghhh!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1951
translate chinese SR4_ES1a_fourth_687cab0f:

    # Lily "Ayaaaahhhhh!!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1953
translate chinese SR4_ES1a_fourth_fe68829c:

    # Lily "(I can feel him cumming! Oh God! He’s filling me up!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1963
translate chinese SR4_ES1a_fourth_933d7b09:

    # MC "HNNNGG!! Take it, Lily! Take every last drop! Arrghhh! See how it feels to have your life ruined for a quick bit of fun, huh?!"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1965
translate chinese SR4_ES1a_fourth_a5296cd2:

    # Lily "(Holy shit! He’s flooding my pussy with his semen!)"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1967
translate chinese SR4_ES1a_fourth_61359edf:

    # Lily "AHHHHH! *Pant* Oooohhhhhh!"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1969
translate chinese SR4_ES1a_fourth_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1973
translate chinese SR4_ES1a_fourth_9d48900f:

    # Lily "*Pant* That’s us *Pant* even now, right?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1975
translate chinese SR4_ES1a_fourth_78cdb9a0:

    # MC " If that’s the way you want to look at it, sure. I still despise you for what you made me do to Sara."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1979
translate chinese SR4_ES1a_fourth_ffcc9e89:

    # Lily "But it did make you feel better getting a chance to try to impregnate me, riiiight?"
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1981
translate chinese SR4_ES1a_fourth_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1983
translate chinese SR4_ES1a_fourth_5478ea06:

    # Lily "Y’know, if it didn’t work you probably deserve another chance at doing it. Give me a call some time."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1987
translate chinese SR4_ES1a_fourth_46ada75e:

    # MC "Goodbye, Lily."
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1989
translate chinese SR4_ES1a_fourth_a5bc2706:

    # MC "(I really put her back in her place. She didn’t know I would actually go through with it when she offered to let me cum inside her unprotected pussy.)"
    MC ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1991
translate chinese SR4_ES1a_fourth_5854698b:

    # Lily "Bubye, [player_name]."
    Lily ""

# game/scripts/SR4/3a_SR4_ES1a.rpy:1993
translate chinese SR4_ES1a_fourth_98dd5690:

    # Lily "(LMAO! He doesn’t know I’m still on birth control. I just got another free fuck out of him - and he was more enthusiastic about it than ever!)"
    Lily ""

translate chinese strings:

    # game/scripts/SR4/3a_SR4_ES1a.rpy:165
    old "First visit"
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:165
    old "Second visit"
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:165
    old "Third visit"
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:165
    old "Fourth visit"
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:616
    old "Let Lily keep sucking your cock until you finish in her mouth."
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:616
    old "Pull out and finish over Lily’s face."
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:1060
    old "You accidentally cum inside Lily’s pussy before you can pull out."
    new ""

    # game/scripts/SR4/3a_SR4_ES1a.rpy:1060
    old "You manage to pull out of Lily’s pussy a split second before you ejaculate."
    new ""

