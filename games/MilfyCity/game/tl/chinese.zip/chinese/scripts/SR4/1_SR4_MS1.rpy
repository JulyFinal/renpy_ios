﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/SR4/1_SR4_MS1.rpy:28
translate chinese SR4_MS1_f2485087:

    # MC "(Oh, there’s Sara!)"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:30
translate chinese SR4_MS1_d2d247a3:

    # MC "(She looks furious... I don’t need to guess who she’s on the phone with.)"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:34
translate chinese SR4_MS1_1cd22f26:

    # Sara "You can’t hide forever! Face me you cowardly man-stealing bitch!"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:36
translate chinese SR4_MS1_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:40
translate chinese SR4_MS1_f097908a:

    # Sara "Oh yeah? Well, we’ll see about that! Sooner or later you’re gonna have to come in for exams - and when you do-"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:42
translate chinese SR4_MS1_abd287a1_1:

    # Sara "..."
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:46
translate chinese SR4_MS1_d8f6d59a:

    # Sara "IRRATIONAL?! You’re calling ME irrational?!"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:48
translate chinese SR4_MS1_a8fc16de:

    # Sara "YOU are the one who sent a picture of yourself in your underwear to MY boyfriend!"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:53
translate chinese SR4_MS1_2652e685:

    # Sara "I don’t fucking care about your excuse! You KNEW how much I liked him and you STILL did it, you treacherous bitch!"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:55
translate chinese SR4_MS1_abd287a1_2:

    # Sara "..."
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:57
translate chinese SR4_MS1_9a3681d4:

    # Sara "Oh yeah, I’ll calm down. Right after I plunge a knife into your chest!"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:61
translate chinese SR4_MS1_a3c76107:

    # MC "(Jesus Christ!)"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:63
translate chinese SR4_MS1_8e1da8a3:

    # Sara "Oh yeah, maybe you SHOULD keep hiding!"
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:65
translate chinese SR4_MS1_b8a7705e:

    # "*Beep*"
    ""

# game/scripts/SR4/1_SR4_MS1.rpy:69
translate chinese SR4_MS1_5dd2702b:

    # MC "Sara... I... Is everything okay?"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:71
translate chinese SR4_MS1_abd287a1_3:

    # Sara "..."
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:76
translate chinese SR4_MS1_ad553f69:

    # MC "Can I get you anything? Do you want to sit down and grab a coffee? Maybe just talk?"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:78
translate chinese SR4_MS1_c934e362:

    # "*Beep beep*"
    ""

# game/scripts/SR4/1_SR4_MS1.rpy:80
translate chinese SR4_MS1_8fb075e0:

    # MC "*Ahem* Perhaps a decaf?"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:84
translate chinese SR4_MS1_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:86
translate chinese SR4_MS1_abd287a1_4:

    # Sara "..."
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:88
translate chinese SR4_MS1_ea666023:

    # MC "You’re not talking to me now? What did I do?! I didn’t ask her to send me that photo!"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:92
translate chinese SR4_MS1_aec3e145:

    # MC "Sara? Please. Talk to me. We can figure this out."
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:94
translate chinese SR4_MS1_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:98
translate chinese SR4_MS1_67240a96:

    # MC "C’mon, you know you can trust me. I’d never cheat on you! This was all Lily! She’s manipulating things! She wants to make me look bad!"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:100
translate chinese SR4_MS1_abd287a1_5:

    # Sara "..."
    Sara ""

# game/scripts/SR4/1_SR4_MS1.rpy:102
translate chinese SR4_MS1_ddec9a7a:

    # MC "Please! Sara!"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:106
translate chinese SR4_MS1_23b7d322:

    # MC "(Goddammit... I need to fix this. I should try and speak with Lily myself. Maybe I can convince her to apologise to Sara?)"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:108
translate chinese SR4_MS1_eaee6072:

    # MC "(Where on Earth does Lily even live though? I need to find her address...)"
    MC ""

# game/scripts/SR4/1_SR4_MS1.rpy:110
translate chinese SR4_MS1_4aa5e12c:

    # MC "(Perhaps one of the students in her course will know?)"
    MC ""

