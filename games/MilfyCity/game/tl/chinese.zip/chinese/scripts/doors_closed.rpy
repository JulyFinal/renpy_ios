﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/doors_closed.rpy:5
translate chinese sis_nerdy_door_locked_2cc29a5d:

    # MC "(It’s locked.)"
    MC ""

