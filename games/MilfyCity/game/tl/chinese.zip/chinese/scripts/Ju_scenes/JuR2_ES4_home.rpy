﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:82
translate chinese JuR2_ES3_check_afd08365:

    # MC "(I am required to purchase white wine.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:95
translate chinese JuR2_ES3_check_d3e26e8f:

    # "(Required: 2 Relation Points with Caroline or Sara.)"
    ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:102
translate chinese JuR2_ES3_check_d3e26e8f_1:

    # "(Required: 2 Relation Points with Caroline or Sara.)"
    ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:122
translate chinese JuR2_ES4_64301acb:

    # MC "Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:124
translate chinese JuR2_ES4_a20cefa7:

    # "..."
    ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:126
translate chinese JuR2_ES4_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:130
translate chinese JuR2_ES4_4f7642ee:

    # MC "(That's weird... Judy normally opens her door quite enthusiastically when I show up!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:149
translate chinese JuR2_ES4_step1_05c11518:

    # Judy "Ah, glad to see you made it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:150
translate chinese JuR2_ES4_step1_fc2528ed:

    # MC "Yeah, the front door was open. Hope you don’t mind me letting myself in."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:151
translate chinese JuR2_ES4_step1_67e07394:

    # Judy "Not at all. I suspected you were coming, and I would prefer not to have to leave my desk to go and unlock it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:155
translate chinese JuR2_ES4_step1_7ff08436:

    # Judy "I always found that walking away from one’s desk breaks your concentration. It takes me ages to get back into a productive mode again."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:156
translate chinese JuR2_ES4_step1_5ac4c395:

    # Judy "If you would just bear with me, I am finishing up a couple of notes here."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:160
translate chinese JuR2_ES4_step1_e853d559:

    # MC "No problem, take your time."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:161
translate chinese JuR2_ES4_step1_74c939b1:

    # Judy "Annnnnd, done. There we go. Sorry about that. I’ve been running behind schedule with my other patients."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:162
translate chinese JuR2_ES4_step1_83856124:

    # Judy "My passion is in the psychology of taboo and my book, but it’s my depression and anxiety patients who are keeping the lights on right now, so to speak."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:166
translate chinese JuR2_ES4_step1_ef708f64:

    # Judy "There we go, that should do it. Now, clean sheet of paper, pen. Alright, that’s everything."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:167
translate chinese JuR2_ES4_step1_0c9c438b:

    # Judy "Why don’t you take a seat over there, [player_name], and we’ll begin."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:168
translate chinese JuR2_ES4_step1_9a204087:

    # MC "Thanks Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:172
translate chinese JuR2_ES4_step1_78d7f7e9:

    # Judy "So, the topic today is your sisters. Sara and..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:174
translate chinese JuR2_ES4_step1_3a07a74e:

    # Judy "So, the topic today is your roommates. Sara and..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:176
translate chinese JuR2_ES4_step1_7b5017ec:

    # MC "Caroline."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:180
translate chinese JuR2_ES4_step1_296a7432:

    # Judy "Ah, yes, Caroline. I must say, I’m much more acquainted with Sara. Lovely girl. Gorgeous auburn hair."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:184
translate chinese JuR2_ES4_step1_fbb57529:

    # Judy "So, who would you prefer to start with?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:192
translate chinese JuR2_ES4_step1_71058713:

    # MC "I’m probably most comfortable talking about Sara."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:193
translate chinese JuR2_ES4_step1_d953ef3e:

    # Judy "Very well, Sara it is then. How have things been going between the two of you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:197
translate chinese JuR2_ES4_step1_22a81003:

    # MC "It’s... uh... It’s been a little challenging, to be honest. I can’t remember if I told you or not, but Sara and her friend Lily played spin the bottle with me."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:201
translate chinese JuR2_ES4_step1_18990976:

    # Judy "You might have mentioned it in passing. But please, go into more detail for me if you can. I’d like to make some comprehensive notes."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:205
translate chinese JuR2_ES4_step1_42c04665:

    # MC "Uh, sure. Lily, Sara and I were playing spin the bottle. Lily and me kissed a couple of times, and Sara kinda freaked out and threw the bottle at Lily."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:209
translate chinese JuR2_ES4_step1_f872d972:

    # Judy "Sorry to interrupt you. Lily and Sara... are they close friends? Are Sara’s actions abnormal for her?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:213
translate chinese JuR2_ES4_step1_8d0ca024:

    # MC "Yeah, as far as I know they’re best friends at school."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:215
translate chinese JuR2_ES4_step1_0b8c95e6:

    # MC "Yeah, as far as I know they’re best friends at college."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:216
translate chinese JuR2_ES4_step1_55df321d:

    # Judy "Hmm... It seems that she is displaying extreme levels of jealousy. What happened next?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:217
translate chinese JuR2_ES4_step1_75fa9689:

    # MC "Well, I tried to comfort her afterwards. Sara wanted a real kiss with me, the same way I’d kissed Lily."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:221
translate chinese JuR2_ES4_step1_48570dda:

    # Judy "Uh huh... Go on. I’m listening."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:225
translate chinese JuR2_ES4_step1_7cbb54ae:

    # MC "We uh... We did... kiss. And a bit more."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:229
translate chinese JuR2_ES4_step1_4c763643:

    # Judy "What do you mean by “a bit more”? Can you be precise?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:233
translate chinese JuR2_ES4_step1_b358ff56:

    # MC "Sara gave me a blojwob."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:237
translate chinese JuR2_ES4_step1_45721d05:

    # Judy "Oh my! How was it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:241
translate chinese JuR2_ES4_step1_d56f9f42:

    # MC "Honestly? Not that great. She hadn’t given one before - but she genuinely tried her best, and I appreciated it."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:242
translate chinese JuR2_ES4_step1_efddcf61:

    # Judy "Now, that is fascinating. She is both jealous AND has a strong desire to please you. That’s a fiery combination."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:243
translate chinese JuR2_ES4_step1_943f33af:

    # MC "Also, I think she might actually be falling in love with me."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:247
translate chinese JuR2_ES4_step1_4befc662:

    # Judy "That’s very sweet. It’s perfectly natural for a sister to feel a strong bond with their older brother. You’re a masculine figure that she can look up to and rely upon, in contrast to your rather meek father."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:249
translate chinese JuR2_ES4_step1_57c44dc7:

    # Judy "That's very kind. It's perfectly natural for someone like Sara to feel a strong bond with you. You're a strong and reliable figure, in contrast to the rather meek Bob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:255
translate chinese JuR2_ES4_step1_d62556f8:

    # MC "Let’s talk about Caroline."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:257
translate chinese JuR2_ES4_step1_32674ecb:

    # Judy "Okay, Caroline it is. She’s your older sister, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:259
translate chinese JuR2_ES4_step1_212ee75d:

    # Judy "Okay, Caroline it is. She’s your older roommate, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:260
translate chinese JuR2_ES4_step1_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:261
translate chinese JuR2_ES4_step1_3112a8ce:

    # Judy "How much older?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:265
translate chinese JuR2_ES4_step1_15fd50ea:

    # MC "Umm, a few years? There isn’t that big a gap between any of us."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:269
translate chinese JuR2_ES4_step1_20ddbdbc:

    # Judy "And what has transpired between Caroline and you since our previous sessions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:273
translate chinese JuR2_ES4_step1_a76390cf:

    # MC "Well, uh, Caroline has started her own business. Cosplay clothing and fashion stuff. She opened it up in town not that long ago."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:274
translate chinese JuR2_ES4_step1_d80ac201:

    # Judy "Yes, I think I’ve driven past it. Quirky little place."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:275
translate chinese JuR2_ES4_step1_750ef886:

    # MC "So yeah, she needed some help running the store, but couldn’t afford to pay me cash."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:279
translate chinese JuR2_ES4_step1_f9e9ef76:

    # Judy "Uh huh. Keep going. I’m listening."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:282
translate chinese JuR2_ES4_step1_15461482:

    # MC "We came to an arrangement whereby she would give me sexual favours in exchange for helping out her store."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:283
translate chinese JuR2_ES4_step1_10697c9f:

    # MC "I’d help her with photoshoots, she’d let me use her body, or help me cum."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:287
translate chinese JuR2_ES4_step1_c7753e52:

    # Judy "And is there an emotional attachment? Or is this a purely transactional arrangement?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:291
translate chinese JuR2_ES4_step1_75e00043:

    # MC "It’s transactional. Caroline’s been clear that this only lasts until I get my own girlfriend. There’s a whole load of rules and limitations that she’s set up."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:295
translate chinese JuR2_ES4_step1_0cf5979f:

    # Judy "Interesting... She’s willing to prostitute herself to you in exchange for assistance, but only in the confines of the walls that she has erected."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:296
translate chinese JuR2_ES4_step1_9ff5f869:

    # Judy "Her own values and morals appear to be strongly influencing her judgement when it comes to implementing this “agreement” that the two of you have come to."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:300
translate chinese JuR2_ES4_step1_d754203b:

    # Judy "Tell me, [player_name], has there been any moment from Caroline which hinted at intimacy beyond the transactional element of the relationship?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:304
translate chinese JuR2_ES4_step1_55e54a6b:

    # MC "Not really, it’s- oh wait! There was one morning when she climbed into my bed and gave me a blowjob to thank me for all the work I’d done for her."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:305
translate chinese JuR2_ES4_step1_8520ef66:

    # MC "I don’t know if it was supposed to be more intimate than our usual encounters, but it definitely FELT that way to me, if that makes sense."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:309
translate chinese JuR2_ES4_step1_0743db1d:

    # Judy "Hmm, intriguing... I wonder if, perhaps, a seed was planted that is beginning to finally blossom into something more."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:310
translate chinese JuR2_ES4_step1_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:314
translate chinese JuR2_ES4_step1_73390749:

    # Judy "Nothing, [player_name], we’ll see in time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:321
translate chinese JuR2_ES4_step1_con_aab19784:

    # Judy "Well, that was a VERY productive session for me. I’ve got all the notes I need, for at least two more chapters."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:322
translate chinese JuR2_ES4_step1_con_f7824a89:

    # MC "Glad I could help. You ARE going to change the names though, right?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:323
translate chinese JuR2_ES4_step1_con_9a5b2cad:

    # Judy "Of course, I already promised I would."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:325
translate chinese JuR2_ES4_step1_con_67b96bb4:

    # Judy "I don’t know if you realise how valuable this information truly is, [player_name]. The scenarios you have described with your sisters are vastly different to what you have told me about your mom."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:327
translate chinese JuR2_ES4_step1_con_1d0ccb92:

    # Judy "I don’t know if you realise how valuable this information truly is, [player_name]. The scenarios you have described with your roomates are vastly different to what you have told me about your landlady, Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:328
translate chinese JuR2_ES4_step1_con_fc879f50:

    # Judy "They open up whole new avenues of thinking in terms of Fredudian psychology. I think this calls for a celebration! Did you bring that bottle of wine like I asked?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:332
translate chinese JuR2_ES4_step1_con_f538d85a:

    # MC "Oh, yeah, I have it right here."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:333
translate chinese JuR2_ES4_step1_con_c7952773:

    # Judy "Ah, brilliant! Thank you, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:337
translate chinese JuR2_ES4_step1_con_3deff515:

    # Judy "How about we head into the Livingroom together and toast to this breakthrough?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:338
translate chinese JuR2_ES4_step1_con_a9671b04:

    # MC "Sure, sounds good to me! Is there any chance I can get a reward for sharing stories, like you promised?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:339
translate chinese JuR2_ES4_step1_con_69d63d89:

    # Judy "Haha, of course. Just be patient. I’ll meet you in the Livingroom. I’m going to change into something a little more... comfortable."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:354
translate chinese JuR2_ES4_step2_wait_beb30648:

    # MC "(Judy is changing her clothes there.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:368
translate chinese JuR2_ES4_step2_bdf83b9c:

    # MC "(Judy’s been gone a while now. I wonder what’s taking her so long?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:370
translate chinese JuR2_ES4_step2_ccaa3d96:

    # MC "(She seems absolutely obsessed with the relationships I have with my family. I can see why she went into psychology.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:372
translate chinese JuR2_ES4_step2_a707ef37:

    # MC "(She seems absolutely obsessed with the relationships I have with other people. I can see why she went into psychology.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:376
translate chinese JuR2_ES4_step2_6751d19e:

    # Judy "Sorry to keep you waiting, I brought us some glasses. You do drink white wine, don’t you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:377
translate chinese JuR2_ES4_step2_7cc1a0d0:

    # MC "Oh yeah, I don’t mind white w-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:381
translate chinese JuR2_ES4_step2_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:382
translate chinese JuR2_ES4_step2_6a425e97:

    # Judy "Something wrong, [player_name]? You’re looking a little bit flustered, there."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:383
translate chinese JuR2_ES4_step2_ce4f7e22:

    # MC "I just... whoa!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:387
translate chinese JuR2_ES4_step2_5e8bf36a:

    # MC "When you said you were going to change into something more comfortable, I didn’t quite imagine... that."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:388
translate chinese JuR2_ES4_step2_cfd10063:

    # Judy "Are you saying it doesn’t suit me?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:389
translate chinese JuR2_ES4_step2_91377d46:

    # MC "No! It’s amazing! You’re amazing! I mean, it looks amazing!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:393
translate chinese JuR2_ES4_step2_5eeeabb4:

    # Judy "(I’ve always found you can keep guys on the back foot with some unexpected display of sexuality. It’s one of the best ways to keep yourself in control of a situation.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:394
translate chinese JuR2_ES4_step2_84597278:

    # Judy "There you go, pour yourself a glass first. You’re looking a bit shellshocked."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:395
translate chinese JuR2_ES4_step2_bfeff091:

    # MC "You just took me by surprise, is all."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:408
translate chinese JuR2_ES4_living_s2_q_b8561393:

    # MC "You just live by yourself, then. No husband? Or partner?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:409
translate chinese JuR2_ES4_living_s2_q_ae313695:

    # Judy "Just me, myself, and I."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:413
translate chinese JuR2_ES4_living_s2_q_6a19d693:

    # MC "That seems really lonely. Is there no one that you have close to you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:417
translate chinese JuR2_ES4_living_s2_q_9bf3f7e7:

    # Judy "I find that romantic partners tend to interrupt the progress and nature of my work. The peace and quiet gives me more time to think."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:418
translate chinese JuR2_ES4_living_s2_q_2b101a84:

    # Judy "Plus, when one finds a partner, they make themselves vulnerable, open themselves up. But over time, they also close themselves off."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:419
translate chinese JuR2_ES4_living_s2_q_b3cfdc87:

    # Judy "How could I possibly continue my research into this taboo if I had a husband whom I was afraid to tell about it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:423
translate chinese JuR2_ES4_living_s2_q_8b70deac:

    # MC "So... You’d rather risk being alone than take a gamble that a romantic partner would leave you for your own taboo interests?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:427
translate chinese JuR2_ES4_living_s2_q_7df00c0f:

    # Judy "Precisely. I couldn’t have put it much clearer than that myself."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:429
translate chinese JuR2_ES4_living_s2_q_6ea3ef58:

    # MC "But, are you also not closing yourself off to the possibility that there is a partner out there with the same taboo interests as you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:433
translate chinese JuR2_ES4_living_s2_q_f37ac201:

    # Judy "Sometimes the risk isn’t worth the gamble."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:435
translate chinese JuR2_ES4_living_s2_q_c1021ca7:

    # MC "Even if it means isolating yourself from any kind of romantic relationship?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:437
translate chinese JuR2_ES4_living_s2_q_2986e75f:

    # Judy "Even if it means isolating myself from a romantic relationship."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:439
translate chinese JuR2_ES4_living_s2_q_85425bdd:

    # MC "That’s... pretty sad."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:443
translate chinese JuR2_ES4_living_s2_q_a2ca8f5c:

    # Judy "When you’ve done this as long as I have, you learn to cope."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:451
translate chinese JuR2_ES4_living_s2_q_01eee8cf:

    # MC "Why are you so interested in this book you’re writing?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:452
translate chinese JuR2_ES4_living_s2_q_27c1cccf:

    # Judy "The Taboo of Human Nature? It fascinates me!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:456
translate chinese JuR2_ES4_living_s2_q_d06fd2dc:

    # Judy "It has ALWAYS fascinated me for as long as I can remember. I mean, when I first started masturbating, my fantasies were always about my brother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:458
translate chinese JuR2_ES4_living_s2_q_c9370380:

    # Judy "It has ALWAYS fascinated me for as long as I can remember. I mean, when I first started masturbating, my fantasies were always about an older professor who was a close friend of my family."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:462
translate chinese JuR2_ES4_living_s2_q_37c3af8d:

    # MC "Your brother? Did the two of you ever do anything together?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:464
translate chinese JuR2_ES4_living_s2_q_52b91e4b:

    # MC "An older professor? Did you two ever do anything together?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:468
translate chinese JuR2_ES4_living_s2_q_e3416678:

    # Judy "Oh, not. Definitely not. I didn’t risk it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:472
translate chinese JuR2_ES4_living_s2_q_7fe50cb3:

    # MC "You’re a hot woman, Judy! You should think about giving it a go. I mean, look at how things are going with my sisters and my mom. Just ask him!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:474
translate chinese JuR2_ES4_living_s2_q_5074a3ef:

    # MC "You’re a hot woman, Judy. You should think about giving it a go! I mean, just look at how things are going with my landlady! She’s older than me and we’re getting on great! Just ask him!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:478
translate chinese JuR2_ES4_living_s2_q_bf8219a9:

    # Judy "I’d love to be able to ask him. But I... uh... I missed my chance. He had a heart defect. The last time I saw him was when we met for lunch after I graduated."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:480
translate chinese JuR2_ES4_living_s2_q_bc2673ef:

    # MC "I’m sorry, Judy. I didn’t realise. I shouldn’t have brought it up."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:482
translate chinese JuR2_ES4_living_s2_q_e278cbe1:

    # Judy "It’s alright. Just... promise me you won’t miss any opportunities with your mom or your sisters. You don’t know how long these people are going to be in your life for."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:484
translate chinese JuR2_ES4_living_s2_q_7ecd0956:

    # Judy "It’s alright. Just... promise me you won’t miss any opportunities with Linda or your roommates. You don’t know how long these people are going to be in your life for."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:492
translate chinese JuR2_ES4_living_s2_q_efcfcdd9:

    # MC "I noticed you didn’t have any children either - at least none that I saw."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:496
translate chinese JuR2_ES4_living_s2_q_039520cc:

    # Judy "No, I don’t have any."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:497
translate chinese JuR2_ES4_living_s2_q_5cc7c165:

    # MC "Do you want to have some someday?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:501
translate chinese JuR2_ES4_living_s2_q_b68c2099:

    # Judy "Let’s talk about something else."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:502
translate chinese JuR2_ES4_living_s2_q_690984ac:

    # MC "Oh sorry, didn’t mean to-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:503
translate chinese JuR2_ES4_living_s2_q_31546c2c:

    # Judy "It’s not something I want to discuss."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:514
translate chinese JuR2_ES4_living_s2_con_bf77f9ca:

    # Judy "How about we head upstairs together?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:515
translate chinese JuR2_ES4_living_s2_con_44a4a8a6:

    # MC "U-Upstairs?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:516
translate chinese JuR2_ES4_living_s2_con_929ec001:

    # Judy "Yeah, I want to try something a bit different tonight. You gave me a LOT of information to work with. I think it’s only fair that I give you an extra-special reward."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:520
translate chinese JuR2_ES4_living_s2_con_1366ce41:

    # Judy "C’mon, follow me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:521
translate chinese JuR2_ES4_living_s2_con_c2c42540:

    # MC "(I wonder what she has in mind? Is she going to let me fuck her?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:536
translate chinese JuR2_ES4_living_s3_32a63018:

    # MC "(Her bedroom’s really fancy!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:537
translate chinese JuR2_ES4_living_s3_5b9eaa6b:

    # Judy "C’mon [player_name], this way."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:541
translate chinese JuR2_ES4_living_s3_6046db8c:

    # MC "What’s going on, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:542
translate chinese JuR2_ES4_living_s3_3fd66730:

    # Judy "I’m about to reward you for all those juicy little stories you told me today. That’s what’s going on."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:543
translate chinese JuR2_ES4_living_s3_d1af95e6:

    # MC "What did you mean by “extra-special” reward? Are we going to-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:547
translate chinese JuR2_ES4_living_s3_cc388a1e:

    # Judy "I always appreciate it when a patient is talkative during therapy, but you need to learn that there’s times when you should just shut up and go with the flow."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:548
translate chinese JuR2_ES4_living_s3_a494f0de:

    # Judy "Alright, let’s get you back on the bed."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:552
translate chinese JuR2_ES4_living_s3_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:553
translate chinese JuR2_ES4_living_s3_af5e11ef:

    # MC "(She just pushed me with no warning!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:558
translate chinese JuR2_ES4_living_s3_628b54f9:

    # Judy "I’ve been looking forward to this, [player_name]. With every therapy session I’ve been putting myself into your mom’s shoes."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:559
translate chinese JuR2_ES4_living_s3_6208be41:

    # Judy "And God, it’s been making me so fucking horny. You have no idea how wet you made me when you called me “mommy” as I sucked you off."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:560
translate chinese JuR2_ES4_living_s3_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:561
translate chinese JuR2_ES4_living_s3_f5307bb2:

    # MC "(She’s taking her bra off! It’s going to happen, isn’t it? She’s going to fuck me tonight!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:565
translate chinese JuR2_ES4_living_s3_f0524dde:

    # Judy "My imagination was running wild. You couldn’t even begin to guess the filthy thoughts running through my mind."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:566
translate chinese JuR2_ES4_living_s3_3c638f21:

    # MC "Try me, you might be surprised."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:568
translate chinese JuR2_ES4_living_s3_ce03c22e:

    # Judy "Mmm. As I was wrapping my lips around your shaft I pictured you as my son. I imagined this was your first time with a woman. Your first blowjob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:570
translate chinese JuR2_ES4_living_s3_b12bcb4a:

    # Judy "Mmm. As I was wrapping my lips around your shaft I pictured you as my man. I imagined this was your first time with a woman. Your first blowjob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:574
translate chinese JuR2_ES4_living_s3_71d5d805:

    # Judy "I want to continue that fantasy tonight, [player_name]. You’re going to keep calling me “mommy” while I ride your cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:575
translate chinese JuR2_ES4_living_s3_d73c01ce:

    # MC "Is that a condom?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:576
translate chinese JuR2_ES4_living_s3_e42640cd:

    # Judy "Yeah, the condom is mandatory. No going inside me without it on."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:580
translate chinese JuR2_ES4_living_s3_f70ff52a:

    # MC "Are you sure? I’ve heard that it feels better for women without-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:581
translate chinese JuR2_ES4_living_s3_c4d3c251:

    # Judy "No condom, no penetration. Okay?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:582
translate chinese JuR2_ES4_living_s3_b1ddb5d0:

    # MC "Fine, fine."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:586
translate chinese JuR2_ES4_living_s3_2351af0b:

    # Judy "Alright, here we go."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:587
translate chinese JuR2_ES4_living_s3_7b91c048:

    # MC "Huh, that went on easier than I thought it would."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:591
translate chinese JuR2_ES4_living_s3_be1b7b7e:

    # Judy "So, here’s the deal - you’re my man tonight. I’ve sucked your cock a couple of times, but you’re still a virgin."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:592
translate chinese JuR2_ES4_living_s3_c2662518:

    # Judy "Mommy is here to take your first time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:593
translate chinese JuR2_ES4_living_s3_ce7e12a8:

    # MC "(I wonder how much of Judy’s rewards are for my benefit, and how much are simply an excuse for her to act out her own fantasies!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:597
translate chinese JuR2_ES4_living_s3_e5eb75e5:

    # Judy "God, your cock has grown so fucking big. I can’t wait to feel it inside me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:598
translate chinese JuR2_ES4_living_s3_43e45eae:

    # MC "(I guess the roleplay has started.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:599
translate chinese JuR2_ES4_living_s3_1505e35e:

    # MC "I’m so hard for you, mom. I can’t wait to feel my cock buried in your tight pussy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:603
translate chinese JuR2_ES4_living_s3_0fef918f:

    # Judy "Mmm! Can you feel my wet slit sliding over the top of your virgin cock?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:605
translate chinese JuR2_ES4_living_s3_efef204c:

    # MC "Ah, it feels good!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:606
translate chinese JuR2_ES4_living_s3_15946f82:

    # MC "(But it’d be A LOT better without a condom!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:607
translate chinese JuR2_ES4_living_s3_1548f5f9:

    # Judy "I’m going to start lowering my body down now. Slowly taking your cock inside me, inch by inch."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:611
translate chinese JuR2_ES4_living_s3_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:612
translate chinese JuR2_ES4_living_s3_a00ce5e8:

    # Judy "How does it feel to have your mommy take your virginity? To have her slowly lower herself down onto your shaft?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:613
translate chinese JuR2_ES4_living_s3_e71248a2:

    # MC "Ah! It feels, so fucking hot. Keep going, mom."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:614
translate chinese JuR2_ES4_living_s3_20e9f39c:

    # Judy "Tell me what you want, [player_name]. Tell me what you want your mom to do."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:618
translate chinese JuR2_ES4_living_s3_8071852b:

    # MC "I want you to ride my cock, mom. I want to feel your pussy wrapped around my dick as you bounce up and down, screaming in pleasure."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:619
translate chinese JuR2_ES4_living_s3_abe0b0da:

    # Judy "Ohhh fuuuck!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:620
translate chinese JuR2_ES4_living_s3_6205619f:

    # Judy "(Holy shit! This is even better than I imagined it would be! The tip is barely in and I already feel like I’m about to cum!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:621
translate chinese JuR2_ES4_living_s3_1a7c424f:

    # Judy "Ah! Ah *Pant* Oh God!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:625
translate chinese JuR2_ES4_living_s3_7ba9dc69:

    # MC "Deeper, mommy. I want to feel more of my cock inside you."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:626
translate chinese JuR2_ES4_living_s3_908cf503:

    # Judy "Haah... Ohhh... Fuuucck! Yes!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:627
translate chinese JuR2_ES4_living_s3_c8d31fab:

    # MC "Slide all the way down, mom. Take my virginity."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:631
translate chinese JuR2_ES4_living_s3_4c7116cd:

    # Judy "Aaahhh! Yeeessss! Oooohhh! You’re sooo fucking big!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:632
translate chinese JuR2_ES4_living_s3_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:636
translate chinese JuR2_ES4_living_s3_3e5819b2:

    # Judy "*Pant* Oooh my God! I can’t believe *Pant* I’m ahhh... riding my own oohhh... man’s dick! Ahhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:638
translate chinese JuR2_ES4_living_s3_af77ec6a:

    # MC "(Judy is REALLY getting into character here! She’s absolutely loving this!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:639
translate chinese JuR2_ES4_living_s3_c894ab02:

    # MC "Keep going, mom! Don’t stop! Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:643
translate chinese JuR2_ES4_living_s3_acaa478d:

    # Judy "That’s it, baby. Moan for me! Ah! I want to hear you moan as you fuck your mom’s pussy!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:644
translate chinese JuR2_ES4_living_s3_274e448c:

    # MC "Ahh! Mmmm! Oooh fuck! It feels so good!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:645
translate chinese JuR2_ES4_living_s3_858ea157:

    # Judy "(I knew it! The taboo nature of an act increases the pleasurability of the act. This is some of the most intense sex I’ve ever had!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:649
translate chinese JuR2_ES4_living_s3_5d3ef1fb:

    # MC "Oh! Faster! Faster, mom!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:651
translate chinese JuR2_ES4_living_s3_58979889:

    # Judy "*Pant* *Pant* Oh! Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:652
translate chinese JuR2_ES4_living_s3_8a2d975b:

    # MC "Mmm! You’re going to make me cum in your pussy if you keep riding me like this!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:656
translate chinese JuR2_ES4_living_s3_ae6e42cd:

    # Judy "And you’d like that, would you? You want to creampie your mother’s pussy?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:658
translate chinese JuR2_ES4_living_s3_f91cad67:

    # MC "Absolutely. Mmm! I’d want to shove my cock in balls-deep and fill you up with my thick, potent cum."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:659
translate chinese JuR2_ES4_living_s3_9c03356d:

    # Judy "(Thank God he has a condom on! If he didn’t I could easily find myself giving in, during the heat of the moment!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:663
translate chinese JuR2_ES4_living_s3_a398f3c7:

    # Judy "Can I kiss you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:664
translate chinese JuR2_ES4_living_s3_0611ff7f:

    # MC "Absolutely, mom."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:665
translate chinese JuR2_ES4_living_s3_de4716f8:

    # Judy "*Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:666
translate chinese JuR2_ES4_living_s3_954a1315:

    # Judy "I really shouldn’t... You’re my son and I-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:667
translate chinese JuR2_ES4_living_s3_7318ed84:

    # MC "(We’re already doing FAR worse than kissing, but I’ll just let Judy play out this fantasy whatever way she wants to.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:672
translate chinese JuR2_ES4_living_s3_c9a14018:

    # Judy "Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:674
translate chinese JuR2_ES4_living_s3_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:675
translate chinese JuR2_ES4_living_s3_623c94c6:

    # MC "(Well, this turned out to be far more passionate than I was expecting it to be. I was maybe thinking I’d get another blowjob tonight - or maybe a lapdance, at a push.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:679
translate chinese JuR2_ES4_living_s3_a7b97956:

    # MC "(Judy is a fantastic kisser!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:680
translate chinese JuR2_ES4_living_s3_936ad36f:

    # MC "(Fuck, she’s grinding on my cock as she makes out with me. It’s so intense! I don’t think I’m going to be able to last much longer.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:681
translate chinese JuR2_ES4_living_s3_c8c65f90:

    # MC "Mmmm!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:685
translate chinese JuR2_ES4_living_s3_223a7099:

    # MC "(God, she’s wriggling her hips as she explores my mouth with her tongue.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:686
translate chinese JuR2_ES4_living_s3_3062eae0:

    # Judy "Ahmmm! Mmmpff! MMMM!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:687
translate chinese JuR2_ES4_living_s3_6341c4eb:

    # Judy "(I can’t stop cumming at this angle! I just want to ride him like this forever!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:691
translate chinese JuR2_ES4_living_s3_4ab4dee1:

    # Judy "*Pant* Oh my God! Yes! Just like that!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:692
translate chinese JuR2_ES4_living_s3_7cc1855b:

    # MC "Ahh! I’m gonna cum soon, mom!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:696
translate chinese JuR2_ES4_living_s3_1e81c63a:

    # Judy "W-Wait! *Pant* Not inside."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:697
translate chinese JuR2_ES4_living_s3_13549670:

    # MC "But, but I’ve got a condom on!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:698
translate chinese JuR2_ES4_living_s3_f3ba29fd:

    # Judy "*Pant* I’m not *Pant risking it. You can finish on my tits or my face. Which would you prefer?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:704
translate chinese JuR2_ES4_living_s3_6d496f65:

    # Judy "Okay, let’s get this condom off you. There we go."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:705
translate chinese JuR2_ES4_living_s3_a4bc70f4:

    # MC "That was amazing, Judy. You’re fucking incredible at-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:706
translate chinese JuR2_ES4_living_s3_e5674e6e:

    # Judy "Mom! I’m still your mom until we’re finished."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:710
translate chinese JuR2_ES4_living_s3_654f90e3:

    # MC "Oh, gotcha."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:711
translate chinese JuR2_ES4_living_s3_74b23bdd:

    # Judy "So, you want to finish on your mommy’s tits? I’m looking forward to feeling your hot cum splash over them."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:712
translate chinese JuR2_ES4_living_s3_423afe60:

    # MC "*Pant* I’m getting close, mom. Keep rubbing my cock like that."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:723
translate chinese JuR2_ES4_living_s3_b9a486a2:

    # Judy "Oh yeah? That’s it baby. C’mon! Cum for me!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:724
translate chinese JuR2_ES4_living_s3_8b75cc27:

    # MC "Hnnnggg! Aaahhhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:725
translate chinese JuR2_ES4_living_s3_642bd170:

    # Judy "Ohh, wow! There’s so much!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:726
translate chinese JuR2_ES4_living_s3_72bdcff6:

    # MC "Ugh! Ohhh fuck!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:727
translate chinese JuR2_ES4_living_s3_fc1aba28:

    # Judy "Hehe! That’s quite an impressive load. I’m glad I decided against letting you finish inside me. You might have burst the condom with this!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:733
translate chinese JuR2_ES4_living_s3_6d496f65_1:

    # Judy "Okay, let’s get this condom off you. There we go."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:734
translate chinese JuR2_ES4_living_s3_a4bc70f4_1:

    # MC "That was amazing, Judy. You’re fucking incredible at-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:735
translate chinese JuR2_ES4_living_s3_e5674e6e_1:

    # Judy "Mom! I’m still your mom until we’re finished."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:739
translate chinese JuR2_ES4_living_s3_d956115c:

    # Judy "So, you want to finish on your mommy’s face, is that it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:740
translate chinese JuR2_ES4_living_s3_fa5b6e76:

    # MC "Yes! Ugh! Keep stroking my cock, mom! I’m getting close."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:741
translate chinese JuR2_ES4_living_s3_e2fc3bf9:

    # Judy "Cum for me. Cum for me, baby. I want to hear you moan as you release your load all over my-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:752
translate chinese JuR2_ES4_living_s3_ff9d872c:

    # MC "HNNNGG! Arrrgghh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:753
translate chinese JuR2_ES4_living_s3_57c77313:

    # Judy "...face."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:754
translate chinese JuR2_ES4_living_s3_788bd12a:

    # Judy "(Well, that came a little sooner than I had anticipated.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:758
translate chinese JuR2_ES4_living_s3_3f58789e:

    # MC "Thanks, mom, that was *Pant* absolutely- Wait, what are you doing?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:759
translate chinese JuR2_ES4_living_s3_acb6d882:

    # Judy "Shush, let mommy clean you up."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:760
translate chinese JuR2_ES4_living_s3_8b08430c:

    # Judy "*Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:761
translate chinese JuR2_ES4_living_s3_a073645c:

    # MC "Oohh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:765
translate chinese JuR2_ES4_living_s3_ecfff93b:

    # Judy "*Suck* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:766
translate chinese JuR2_ES4_living_s3_df3f22e9:

    # MC "Ah! Ohhh! God!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:767
translate chinese JuR2_ES4_living_s3_ee011559:

    # MC "(Shit! I’m WAY more sensitive after I’ve cum! Her mouth is amazing!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:768
translate chinese JuR2_ES4_living_s3_252f78b6:

    # MC "Aahh! W-Wow... That was... *Pant* phenomenal, Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:775
translate chinese JuR2_ES4_bedroom_s3_end_a88c67d3:

    # Judy "Well? How was it for you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:776
translate chinese JuR2_ES4_bedroom_s3_end_7421b1f6:

    # MC "Incredible Judy. Shame about the condom though, I would have loved to feel you with my bare cock."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:777
translate chinese JuR2_ES4_bedroom_s3_end_540df5d4:

    # Judy "Not happening, I’m afraid. I despise kids. Don’t want anything to do with them."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:779
translate chinese JuR2_ES4_bedroom_s3_end_a8a08400:

    # Judy "Make sure you come back and see me again at college when things progress further with your mom. I’m sure I’ll be able to think of some other ways to compensate you for your time too."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:781
translate chinese JuR2_ES4_bedroom_s3_end_fc4e2d0a:

    # Judy "Make sure you come back and see me again at college when things progress further with Linda. I’m sure I’ll be able to think of some other ways to compensate you for your time too."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES4_home.rpy:782
translate chinese JuR2_ES4_bedroom_s3_end_1f04c24b:

    # MC "Thanks Judy, I’ll make sure to do that."
    MC ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:186
    old "Let’s talk about Sara."
    new ""

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:186
    old "Let’s talk about Caroline."
    new ""

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:404
    old "So, you just live here by yourself? No husband?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:404
    old "Why are you so interested in this book you’re writing?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:404
    old "And you don’t have any children either?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:700
    old "I’ll finish on your tits."
    new ""

    # game/scripts/Ju_scenes/JuR2_ES4_home.rpy:700
    old "I’ll finish on your face."
    new ""

