﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/Ju_NV.rpy:86
translate chinese Ju_NV_start_ed025652:

    # MC "(It’s hard to see in the dark, but I think Judy’s asleep in bed.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:87
translate chinese Ju_NV_start_a1c4c851:

    # MC "(I unlocked the window, so I should be able to open it and sneak in without waking her. Alright, here goes nothing...)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:89
translate chinese Ju_NV_start_c976f868:

    # "*Creeak*"
    ""

# game/scripts/Ju_scenes/Ju_NV.rpy:94
translate chinese Ju_NV_start_f62fbd28:

    # MC "(Ha! Made it! I And I didn’t even have to complete a minigame to do it.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:95
translate chinese Ju_NV_start_16315100:

    # MC "(It’s a fairly loose window, so I should be able to make a quick escape in the event that she wakes up.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:99
translate chinese Ju_NV_start_0e8d539c:

    # MC "(And there she is. Fast asleep.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:102
translate chinese Ju_NV_start_4a1da1e3:

    # MC "*Whispered* Hey Judy, are you awake?"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:105
translate chinese Ju_NV_start_4a4b4929:

    # Judy "Mmm?"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:107
translate chinese Ju_NV_start_52ceff46:

    # MC "Do you want to try some roleplaying therapy session tonight?"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:109
translate chinese Ju_NV_start_92cf5f93:

    # Judy "What?"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:111
translate chinese Ju_NV_start_74c3ac33:

    # MC "You pretend to be asleep, and I'll play with your body. What do you think?"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:114
translate chinese Ju_NV_start_b9258fbd:

    # Judy "*Yawn* Sure, why not? Just don't take too long. I have an early morning ahead. (I'm curious to see what's on his mind...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:116
translate chinese Ju_NV_start_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:119
translate chinese Ju_NV_start_9b463a33:

    # MC "(Judy did agree that she would reward me with pleasure in exchange for telling her about my exploits with my mom and sisters.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:122
translate chinese Ju_NV_start_9f46a16a:

    # MC "(So, if I play with her body when she’s asleep, I’m not technically taking anything that she hasn’t already offered, right?)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:124
translate chinese Ju_NV_start_e2f33165:

    # MC "(Judy did agree that she would reward me with pleasure, in exchange for telling her about my exploits with my roommates and Linda.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:128
translate chinese Ju_NV_start_fdcb48e1:

    # MC "(So, if I play with her body when she's pretending to be asleep, I'm not technically taking anything that she hasn't already offered, right?)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:129
translate chinese Ju_NV_start_d8442a2a:

    # MC "*Whispered* Nice..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:133
translate chinese Ju_NV_start_ab531293:

    # MC "(She looks really fucking hot in that lingerie. Her panties are so sheer, that I can practically see her vulva beneath them!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:134
translate chinese Ju_NV_start_17a70d05:

    # MC "(I wonder how easy they will be to take off, if I decide to go further...)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:138
translate chinese Ju_NV_start_ae55662a:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:140
translate chinese Ju_NV_start_4d2b460f:

    # Judy "Zzz... (Is he going to just look at me and wank off?)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:141
translate chinese Ju_NV_start_ebcf86a4:

    # MC "(Phew, she’s only snoring. I nearly had a heart attack there!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:145
translate chinese Ju_NV_start_27e3c3a5:

    # MC "(Okay, let’s start with something simple. I’ll see if I can get away with touching her breasts while she sleeps.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:146
translate chinese Ju_NV_start_c13d69c9:

    # Judy "Hmm... Zzz... Ugh... Too many patients..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:153
translate chinese Ju_NV_start_3d2d7116:

    # MC "(Let's hold off until the night.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:235
translate chinese Ju_NV_back_242e683e:

    # MC "(That was awesome! I should come back another time to play with her again.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:237
translate chinese Ju_NV_back_8f6e4b5c:

    # MC "(That was awesome! I should come back another time, and roleplay like this again with her!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:251
translate chinese Ju_NV_tits_7da2caae:

    # MC "*Whispered* Easy does it..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:252
translate chinese Ju_NV_tits_c222e5c1:

    # MC "*Phew* (Thankfully her bra wasn’t that difficult to remove.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:254
translate chinese Ju_NV_tits_2a3fa7ef:

    # MC "(Damn, her breasts are amazing!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:258
translate chinese Ju_NV_tits_de636aca:

    # MC "(My heart’s pounding so hard right now! I can’t believe I’m actually getting away with this!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:260
translate chinese Ju_NV_tits_d7beb314:

    # MC "(My heart’s pounding so hard right now! I can't believe she actually agreed to this!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:262
translate chinese Ju_NV_tits_4879cc70:

    # MC "(Her breast is so soft and warm. I could squeeze these for hours!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:266
translate chinese Ju_NV_tits_036e0f44:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:267
translate chinese Ju_NV_tits_9ec78456:

    # MC "(Did she just moan in her sleep? I think she’s secretly enjoying this!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:271
translate chinese Ju_NV_tits_15d9c112:

    # Judy "*Yawn* Ahh... Mmm, what time is it?"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:272
translate chinese Ju_NV_tits_bbd65794:

    # MC "(Shit! She’s awake!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:274
translate chinese Ju_NV_tits_d928868e:

    # Judy "*Yawn* Ahh... Mmm, what time is it? (Let’s stop it right here...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:275
translate chinese Ju_NV_tits_0a394141:

    # MC "(Shit! She’s awake! That means no more roleplaying!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:279
translate chinese Ju_NV_tits_27f6619c:

    # MC "(Crap! I’ve got to get out of here ASAP! This is way too risky. I’ve no idea how she’d react if she actually caught me!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:280
translate chinese Ju_NV_tits_241abaa0:

    # MC "(At least I know the window is an easy way to get in from now on. I’ll try again another night when she’s in a deeper sleep.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:291
translate chinese Ju_NV_kiss_6a4f373b:

    # MC "(It was so sexy when Judy pinned me down during sex and started making out with me. She was such an intense kisser.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:292
translate chinese Ju_NV_kiss_ae55662a:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:296
translate chinese Ju_NV_kiss_3b054944:

    # MC "(I think I’ll try kissing her tonight. The lips are one of the most sensitive parts of the body, so it could be possible that she suddenly wakes up. I’ll just have to be extremely careful and take things slowly.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:300
translate chinese Ju_NV_kiss_5582063e:

    # MC "(Damn... She is so beautiful. I still can’t believe I actually got to have sex with her.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:302
translate chinese Ju_NV_kiss_dbd3a129:

    # Judy "Hmm... Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:304
translate chinese Ju_NV_kiss_ae3e2b24:

    # Judy "Hmm... Zzz... (What is [player_name], planning?)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:308
translate chinese Ju_NV_kiss_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:312
translate chinese Ju_NV_kiss_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:314
translate chinese Ju_NV_kiss_b96a079d:

    # Judy "Zz-mmm..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:315
translate chinese Ju_NV_kiss_06b72fc4:

    # MC "(It’s not quite as good as when she was lying on top of me, but it’s still nice to kiss her again.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:319
translate chinese Ju_NV_kiss_fea870fc:

    # MC "(I wonder if she’d wake up if I used my tongue a bit?)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:320
translate chinese Ju_NV_kiss_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:321
translate chinese Ju_NV_kiss_d1be8d41:

    # Judy "Ahmmm... *snore* Hmm..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:325
translate chinese Ju_NV_kiss_05e14ce5:

    # MC "(I’m honestly surprised she hasn’t woken up yet. She must be in an especially deep sleep!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:327
translate chinese Ju_NV_kiss_3405135e:

    # Judy "Mmm... *Snore*"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:329
translate chinese Ju_NV_kiss_06fa1356:

    # Judy "Mmm... *Snore* (It feels good...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:333
translate chinese Ju_NV_kiss_436fe632:

    # MC "(I’m looking forward to when we can make out together while she’s awake again. I think she really enjoyed the passionate kissing part.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:334
translate chinese Ju_NV_kiss_f2f8c819:

    # MC "(Maybe if I timed my kissing right, she wouldn’t be able to resist letting me finish inside her? Provided I had a condom on, of course.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:338
translate chinese Ju_NV_kiss_f08ae432:

    # MC "(Yeah, I think that would work. I’ll try fucking her, and the second she starts displaying concern or worry about me finishing inside her pussy, I’ll begin kissing her like crazy.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:339
translate chinese Ju_NV_kiss_1d776a39:

    # MC "(She’ll be so overwhelmed, in the moment, that she won’t be able to say no to me filling her up with my hot cum.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:341
translate chinese Ju_NV_kiss_a7d1081f_2:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:342
translate chinese Ju_NV_kiss_d33ee418:

    # Judy "*Snore* Mmm... Hmm?!"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:346
translate chinese Ju_NV_kiss_e6999a19:

    # MC "(Aw fuck! I got caught up in the moment myself, there! Time to go before she sees me!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:347
translate chinese Ju_NV_kiss_75d8bb46:

    # Judy "*Yawn* What was...?"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:348
translate chinese Ju_NV_kiss_9b6381ea:

    # Judy "(I was having the weirdest erotic dream, there...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:356
translate chinese Ju_NV_foot_9ebf73a3:

    # MC "(Hmm, I think I’ll switch things up tonight and play with her feet for a chance. It’s not like I need to remove any of her lingerie to get to them, so they should be an easier target.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:357
translate chinese Ju_NV_foot_a492cd47:

    # MC "(At least, as long as she isn’t ticklish!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:361
translate chinese Ju_NV_foot_ae55662a:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:362
translate chinese Ju_NV_foot_050f8a89:

    # MC "(Alright, let’s slip out of my clothes and see if I can manage to pull off a footjob without taking her up.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:366
translate chinese Ju_NV_foot_bae6be6c:

    # Judy "Zzzz.... *Snore*"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:367
translate chinese Ju_NV_foot_a3e11273:

    # "*Rustle* *Rustle*"
    ""

# game/scripts/Ju_scenes/Ju_NV.rpy:371
translate chinese Ju_NV_foot_74044b3b:

    # MC "(Perfect, there we go. Let’s just move your feet into a better position like this...)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:372
translate chinese Ju_NV_foot_b3bfdc60:

    # Judy "Mmm... Zzzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:376
translate chinese Ju_NV_foot_f6d7309c:

    # MC "*Whispered* Oh yeah, that’s the spot."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:379
translate chinese Ju_NV_foot_ececdede:

    # Judy "*Snore*"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:381
translate chinese Ju_NV_foot_2d0ecfa1:

    # Judy "Zzz... Hmm... *Yawn* (Don’t’ tell me he’s just gonna leave his cum on my feet...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:382
translate chinese Ju_NV_foot_61596a2b:

    # MC "Mmm... Ah..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:386
translate chinese Ju_NV_foot_6b8cba9b:

    # MC "(It feels amazing when the soles of her feet caress my cock like this. She must have moisturised them before she went to bed.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:387
translate chinese Ju_NV_foot_c14a63ad:

    # MC "Haah... ah... Oh fuck... Mmm..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:391
translate chinese Ju_NV_foot_e3813eb6:

    # MC "(Let’s pick up the pace a bit! I might be able to get away with cumming tonight.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:392
translate chinese Ju_NV_foot_ae55662a_1:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:393
translate chinese Ju_NV_foot_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:397
translate chinese Ju_NV_foot_c1396077:

    # MC "*Pant* Fuck... I’m getting close."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:398
translate chinese Ju_NV_foot_ed3138d7:

    # MC "Arrgh...."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:399
translate chinese Ju_NV_foot_01d8d9b3:

    # MC "(I have to keep my voice down when I finish! This would be the absolute WORST point for her to wake up and catch me!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:409
translate chinese Ju_NV_foot_e69c04f3:

    # MC "*Pant* Oh! Fuck! Ah!"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:410
translate chinese Ju_NV_foot_58a00191:

    # Judy "Zzz.... Hmm... *Yawn*"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:411
translate chinese Ju_NV_foot_baf31f76:

    # MC "*Whispered* Argh... "
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:412
translate chinese Ju_NV_foot_054fe4ee:

    # MC "(Shit! I came so hard I couldn’t keep quiet! I better leg it out of here before she catches me. Hopefully she falls back asleep without noticing the present I left on her feet!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:420
translate chinese Ju_NV_blow_1fc04c9a:

    # MC "(Let’s take things further tonight and see if I can get away with having Judy give me a blowjob while she sleeps.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:422
translate chinese Ju_NV_blow_93471551:

    # MC "(Let's take things further tonight and see if I can get away with having Judy give me a blowjob while we roleplaying...)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:423
translate chinese Ju_NV_blow_3173c6bc:

    # MC "(This one’s gonna be risky. One wrong move, and I’ll easily wake her up.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:427
translate chinese Ju_NV_blow_ae55662a:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:428
translate chinese Ju_NV_blow_1f1a8b76:

    # MC "(She looks so beautiful when she’s sleeping. I wonder what she’s dreaming of right now.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:432
translate chinese Ju_NV_blow_c5109004:

    # MC "(Alright... here we go! C’mon Judy, part those lips for me.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:433
translate chinese Ju_NV_blow_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:434
translate chinese Ju_NV_blow_2c511337:

    # MC "(That’s it, just a little bit more...)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:436
translate chinese Ju_NV_blow_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:439
translate chinese Ju_NV_blow_cfb27584:

    # Judy "Zzz... Mmmm..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:440
translate chinese Ju_NV_blow_bd653185:

    # MC "*Whispered* Ooohh..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:442
translate chinese Ju_NV_blow_eafcb065:

    # MC "(I can feel a warm rush of air over my cock each time she breathes out. Let’s see if I can squeeze my whole glans in without rousing her.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:446
translate chinese Ju_NV_blow_112e1edc:

    # MC "(Oh fuck! That’s it!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:447
translate chinese Ju_NV_blow_76ad57e7:

    # MC "Mmm! (Shit! I moaned WAY too loudly, there! I need to be more careful!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:448
translate chinese Ju_NV_blow_ae55662a_1:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:449
translate chinese Ju_NV_blow_7ceaa6db:

    # MC "(I really should play it safe... but her mouth feels so good! Just another couple of inches, and I’ll stop.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:453
translate chinese Ju_NV_blow_1b12a807:

    # Judy "*Shluurrp* Zzz...."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:455
translate chinese Ju_NV_blow_b39ec90e:

    # Judy "*Shluurrp* Zzz... (Let me help him a little...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:456
translate chinese Ju_NV_blow_f2f3c3af:

    # MC "*Whispered* Ooohhh... hnnnngg... Yes..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:460
translate chinese Ju_NV_blow_62c39f0d:

    # MC "(Yes, yes, yes! God damn! I wonder if I can keep going until I finish? Would she actually wake up if I came in her mouth?)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:461
translate chinese Ju_NV_blow_0abb7dfd:

    # MC "(Alright, let’s try one last gamble. I’m going to see if I can slip my cock to the back of her throat.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:465
translate chinese Ju_NV_blow_da432bad:

    # MC "*Whispered* Hnnngg.... Ahh..."
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:466
translate chinese Ju_NV_blow_553c0fed:

    # MC "(Holy shit this feels good! I can barely contain my moans!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:467
translate chinese Ju_NV_blow_eb44379a:

    # Judy "*Shlurp* *Gag* *GAG* *COUGH*"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:468
translate chinese Ju_NV_blow_e429997c:

    # MC "Ohhh! (Crap! Her throat is tightening around my glans when she coughs!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:479
translate chinese Ju_NV_blow_46047f78:

    # Judy "*Cough* *Cough* What... *Yawn* What’s going..."
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:481
translate chinese Ju_NV_blow_7980e846:

    # Judy "*Cough* *Cough* What... *Yawn* What’s going... (Did he just came inside my mouth? Naughty...)"
    Judy ""

# game/scripts/Ju_scenes/Ju_NV.rpy:482
translate chinese Ju_NV_blow_5d3eb7e6:

    # MC "(Crap! She’s awake! Time for me to bail!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:487
translate chinese Ju_NV_blow_778578a2:

    # MC "(I played it with too risky with a blowjob there. I need to slow down and be more careful in future!)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:499
translate chinese Ju_NV_open_window_35f0e1ea:

    # MC "(Window is already open.)"
    MC ""

# game/scripts/Ju_scenes/Ju_NV.rpy:514
translate chinese Ju_NV_open_window_b4004070:

    # MC "(I don't have a key to Judy's house, but if I pry this window open, I should be able to sneak in tonight.)"
    MC ""

