﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_ES2.rpy:75
translate chinese JuR2_ES2_0e191b48:

    # MC "(Things got pretty intense with Judy at my last therapy session in school. I wonder how different private therapy will be.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:77
translate chinese JuR2_ES2_33c83710:

    # MC "(Things got pretty intense with Judy at my last therapy session in college. I wonder how different private therapy will be.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:88
translate chinese JuR2_ES2_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:92
translate chinese JuR2_ES2_5b63d457:

    # Judy "[player_name], is that you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:93
translate chinese JuR2_ES2_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:94
translate chinese JuR2_ES2_6f14dad9:

    # Judy "It’s unlocked, let yourself in."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:98
translate chinese JuR2_ES2_cae388f7:

    # MC "Hi Judy, I’m here for-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:99
translate chinese JuR2_ES2_bc469e1b:

    # MC "(WHOA!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:100
translate chinese JuR2_ES2_ea915e7e:

    # Judy "Cat got your tongue?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:104
translate chinese JuR2_ES2_fe5c5631:

    # MC "I- You-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:105
translate chinese JuR2_ES2_62efbe7d:

    # Judy "I needed to apply some moisturiser to my body after the bath. Wearing underwear is the easiest way to do it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:106
translate chinese JuR2_ES2_851dacf0:

    # MC "Y-Yeah, of course, I just-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:110
translate chinese JuR2_ES2_5a2d560d:

    # Judy "You just what?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:111
translate chinese JuR2_ES2_79cfa724:

    # MC "I..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:112
translate chinese JuR2_ES2_13eaec27:

    # Judy "You weren’t expecting to see me clad in my lingerie?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:116
translate chinese JuR2_ES2_91211cbd:

    # Judy "Interesting. Are you usually this shy and awkward around women?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:118
translate chinese JuR2_ES2_4923c21a:

    # Judy "Interesting. Are you usually this shy and awkward around older women? That could upset someone else."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:120
translate chinese JuR2_ES2_eef7e707:

    # MC "Wh-What? I wasn’t- I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:121
translate chinese JuR2_ES2_256a7297:

    # MC "(Does she EVER stop psychoanalysing everyone she meets?! It must be exhausting!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:125
translate chinese JuR2_ES2_a650ce22:

    # Judy "Try to relax, [player_name]. Therapy is far more effective when you let your guard down."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:126
translate chinese JuR2_ES2_2a109e17:

    # Judy "Head on into my office, just down the hall. I work with my private clients there."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:127
translate chinese JuR2_ES2_077486d6:

    # Judy "Make yourself comfortable. I’ll join you in a few minutes."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:141
translate chinese JuR2_ES2_bathroom_lock_2b030633:

    # MC "(Judy is there.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:151
translate chinese JuR2_ES2_step1_lock_ea88f5d7:

    # MC "(Judy and [Mom_name] are waiting for me in the office.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:157
translate chinese JuR2_ES2_step1_lock_171d7774:

    # MC "(I just walked in. Where is she?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:163
translate chinese JuR2_ES2_step1_lock_4c72fa7f:

    # MC "(I should wait in the Livingroom.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:169
translate chinese JuR2_ES2_step1_lock_b746cf06:

    # MC "(Let's look around the house.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:175
translate chinese JuR2_ES2_step1_lock_47962c9a:

    # MC "(Let's go to the office as Judy told me.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:194
translate chinese JuR2_ES2_step1_adf68914:

    # MC "(I can’t believe how nervous I was when Judy appeared in her underwear.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:195
translate chinese JuR2_ES2_step1_cb6f361a:

    # MC "(Is she right? Am I really shy and awkward around women?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:196
translate chinese JuR2_ES2_step1_01727efe:

    # MC "(No... She took me by surprise and caught me off guard! This was a deliberate power play by her. She KNEW I was coming over for private therapy and she chose to dress like that.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:200
translate chinese JuR2_ES2_step1_6d0e662f:

    # MC "(She has some nerve telling me to ‘let my guard down’ when she’s the one who got me all anxious in the first place.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:201
translate chinese JuR2_ES2_step1_e299506e:

    # MC "(If Judy is going to play dirty, then the last thing I should be doing is letting my guard down. She’s a manipulative-)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:202
translate chinese JuR2_ES2_step1_e9553ea6:

    # Judy "I’m glad to see you’ve made yourself comfortable."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:206
translate chinese JuR2_ES2_step1_44e45108:

    # MC "(I was right! She’s taken off her dressing gown now. Judy is deliberately messing with me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:207
translate chinese JuR2_ES2_step1_9d2f3e67:

    # Judy "Is something wrong, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:208
translate chinese JuR2_ES2_step1_4e00878e:

    # MC "(I’ll keep playing it cool. I can’t let her know that she’s getting to me.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:212
translate chinese JuR2_ES2_step1_dfa3a60a:

    # MC "*Ahem* N-No, nothing wrong. Aren’t you getting a little cold?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:213
translate chinese JuR2_ES2_step1_f0a8adbd:

    # Judy "Au contraire, I’m far too hot. I just get really uncomfortable in stuffy clothing."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:214
translate chinese JuR2_ES2_step1_9afe6b1c:

    # Judy "Hmm... Intriguing."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:218
translate chinese JuR2_ES2_step1_a0a77568:

    # MC "What’s intriguing?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:219
translate chinese JuR2_ES2_step1_39b1ca81:

    # Judy "You’re gripping onto the arms of that chair. Do you feel more grounded and safe when you hold onto the object?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:220
translate chinese JuR2_ES2_step1_a1e764be:

    # MC "What, I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:224
translate chinese JuR2_ES2_step1_c27408a3:

    # Judy "I mean, I can understand your unease and general anxiety right now. Especially when you find yourself interrupting your own parent’s marriage."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:225
translate chinese JuR2_ES2_step1_6219e6ea:

    # Judy "I think we should focus on that for today’s session. How about you open up to me about your feelings towards your parents?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:227
translate chinese JuR2_ES2_step1_b138d500:

    # Judy "I mean, I can understand your unease and general anxiety right now. Especially when you find yourself disrupting Linda and Bob's marriage."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:228
translate chinese JuR2_ES2_step1_1b76577f:

    # Judy "I think we should focus on that for today’s session. How about you open up to me about your feelings towards Bob and Linda?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:232
translate chinese JuR2_ES2_step1_0dcff637:

    # MC "I’d... uh... I’d rather not."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:233
translate chinese JuR2_ES2_step1_73e97bae:

    # Judy "..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:234
translate chinese JuR2_ES2_step1_f751c7f4:

    # MC "I mean, it’s just difficult to talk about."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:236
translate chinese JuR2_ES2_step1_73e97bae_1:

    # Judy "..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:240
translate chinese JuR2_ES2_step1_ba5eef2b:

    # MC "It’d be easy if my dad was a bad guy. But... he isn’t. He doesn’t raise his voice, he’s never hit my mom."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:241
translate chinese JuR2_ES2_step1_3f89aaee:

    # Judy "Are you saying that Bob doesn’t deserve what’s happening to him? How present has he been? If he is always working, then it seems fair for your mom to seek satisfaction with someone else, doesn’t it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:243
translate chinese JuR2_ES2_step1_f29d7e41:

    # MC "It’d be easy if Bob was a bad guy. But... he isn’t. He doesn’t raise his voice, he’s never hit Linda."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:244
translate chinese JuR2_ES2_step1_99e4d578:

    # Judy "Are you saying that Bob doesn’t deserve what’s happening to him? How present has he been? If he is always working, then it seems fair for Linda to seek satisfaction with someone else, doesn’t it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:245
translate chinese JuR2_ES2_step1_deaddead:

    # MC "I mean, he works... a lot. But he was mostly there when it mattered. I mean, he showed up to Caroline’s graduation and sometimes turned up to Sara’s events at college."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:249
translate chinese JuR2_ES2_step1_5256891f:

    # Judy "But your mom isn’t happy with him, is she?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:251
translate chinese JuR2_ES2_step1_48bf1e9a:

    # Judy "But Linda isn’t happy with him, is she?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:252
translate chinese JuR2_ES2_step1_51606f1c:

    # MC "I guess not."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:254
translate chinese JuR2_ES2_step1_a60ea979:

    # Judy "Think about it this way. Before you started a sexual relationship with Linda, your mom was unhappy and your dad was happy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:256
translate chinese JuR2_ES2_step1_1399928a:

    # Judy "Think about it this way. Before you started a sexual relationship with Linda, she was unhappy and Bob was happy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:257
translate chinese JuR2_ES2_step1_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:258
translate chinese JuR2_ES2_step1_3ab96720:

    # Judy "Now, look at the present day. You’re having a sexual relationship with Linda which is making her happy AND you happy. Does it matter if Bob becomes upset by this when the net number of people who are now happy has increased?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:262
translate chinese JuR2_ES2_step1_a10d4f17:

    # MC "That’s... uh... a very... clinical way of looking at human relationships."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:263
translate chinese JuR2_ES2_step1_9b477257:

    # Judy "Is it? Before you had one person satisfied and one person unsatisfied. We now have two satisfied people, and one unsatisfied one."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:265
translate chinese JuR2_ES2_step1_85ba4304:

    # MC "But what about my dad’s happiness?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:267
translate chinese JuR2_ES2_step1_59ed102f:

    # MC "But what about Bobs’s happiness?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:271
translate chinese JuR2_ES2_step1_ea21ae4e:

    # Judy "What about your mom’s happiness? How many years has she spent trapped in a marriage that she hates? And is it really fair to let your dad live under the illusion of his unrequited love for Linda?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:273
translate chinese JuR2_ES2_step1_a8558cc5:

    # Judy "What about Linda’s happiness? How many years has she spent trapped in a marriage she hates? And is it really fair to let Bob live under the illusion of his unrequited love for Linda?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:274
translate chinese JuR2_ES2_step1_2141ea9f:

    # MC "I don’t know."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:278
translate chinese JuR2_ES2_step1_bb2e5edd:

    # Judy "I think the fairest thing you can do is pursue a relationship with the woman who WANTS to be in a relationship with you. You’re setting your dad free as well."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:279
translate chinese JuR2_ES2_step1_315dbd40:

    # Judy "There’s no reason to keep him trapped in a relationship with a woman who so clearly despi... who is so clearly unhappy living with him."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:281
translate chinese JuR2_ES2_step1_315dbd40_1:

    # Judy "There’s no reason to keep him trapped in a relationship with a woman who so clearly despi... who is so clearly unhappy living with him."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:284
translate chinese JuR2_ES2_step1_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:285
translate chinese JuR2_ES2_step1_a3b778c4:

    # Judy "Perhaps we should move on to a lighter subject."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:289
translate chinese JuR2_ES2_step1_36bec1e7:

    # Judy "How have things been progressing with your sisters?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:291
translate chinese JuR2_ES2_step1_c1bf0933:

    # Judy "How have things been progressing with Sara and Caroline?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:292
translate chinese JuR2_ES2_step1_db91e599:

    # MC "They, uh, they’ve been good."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:293
translate chinese JuR2_ES2_step1_c0654c55:

    # Judy "That’s an evasive answer. Tell me how you’re getting on with..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:299
translate chinese JuR2_ES2_step1_fcba3ebe:

    # Judy "How are you getting on with Sara?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:303
translate chinese JuR2_ES2_step1_29af0c4a:

    # MC "She’s my sister, but we aren’t especially close if that’s what you’re asking."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:305
translate chinese JuR2_ES2_step1_2c74716d:

    # MC "She’s my roommate... but we aren’t especially close, if that’s what you’re asking."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:306
translate chinese JuR2_ES2_step1_ec236886:

    # Judy "You don’t interact with her much?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:307
translate chinese JuR2_ES2_step1_11a0a57e:

    # MC "I mean, we walk to college together, and I see her in the corridors sometimes. But that’s about it."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:308
translate chinese JuR2_ES2_step1_f127cb22:

    # Judy "Hmm... And are you interested in ‘advancing’ your relationship with Sara further?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:309
translate chinese JuR2_ES2_step1_ebf95b7d:

    # MC "What do you mean by that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:310
translate chinese JuR2_ES2_step1_4e2ca053:

    # Judy "Nothing, just forget I asked."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:314
translate chinese JuR2_ES2_step1_c789d412:

    # MC "It’s been going pretty well to be completely honest."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:315
translate chinese JuR2_ES2_step1_5755106d:

    # Judy "Complete honesty is good, [player_name]. So... ‘Pretty well’, huh? Care to elaborate for me?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:316
translate chinese JuR2_ES2_step1_f74afb5d:

    # MC "We’ve been hanging out together a bit. Talking more than we used to as well."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:317
translate chinese JuR2_ES2_step1_78e74b9d:

    # Judy "Just the two of you? Was Caroline there as well?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:319
translate chinese JuR2_ES2_step1_2ce17f4d:

    # MC "No, actually - but her friend, Lily, was."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:320
translate chinese JuR2_ES2_step1_fd2c38be:

    # Judy "Ah yes, I am aware of Lily. A rather forward girl if the profesor's comments are to be believed."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:321
translate chinese JuR2_ES2_step1_eca347e1:

    # MC "Yeah, the three of us played spin the bottle together."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:323
translate chinese JuR2_ES2_step1_e9938326:

    # Judy "Ooh, exciting. Tell me how that went?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:324
translate chinese JuR2_ES2_step1_dd067500:

    # MC "Not how you’d think, surprisingly. Sara ended up getting jealous after Lily kissed me and there was a bit of an incident involving a glass bottle being thrown."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:325
translate chinese JuR2_ES2_step1_a5a698b0:

    # Judy "Oof. It sounds like Sara really likes you. You should consider opening yourself up to her and requiting that love."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:326
translate chinese JuR2_ES2_step1_b44851c5:

    # MC "Well, it’s funny you should say that because- I... It’s nothing."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:327
translate chinese JuR2_ES2_step1_d1c0dd6c:

    # Judy "Go on, what happened?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:329
translate chinese JuR2_ES2_step1_561e8b24:

    # MC "Nothing."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:330
translate chinese JuR2_ES2_step1_eb9fe973:

    # Judy "How do you intend to progress in therapy if you refuse to open up to me about details that make you anxious or uncomfortable?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:331
translate chinese JuR2_ES2_step1_e6b24a4e:

    # MC "*Sigh* We made up and kissed after that."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:333
translate chinese JuR2_ES2_step1_44bcbbe2:

    # Judy "You and Sara?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:334
translate chinese JuR2_ES2_step1_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:336
translate chinese JuR2_ES2_step1_fc87678d:

    # Judy "Well, a kiss hardly seems like something to get so nervous about. Even if she is your sister, your anxiety here seems to be a disproportionate reaction."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:338
translate chinese JuR2_ES2_step1_ff60599e:

    # Judy "Well, a kiss hardly seems like something to get so nervous about. Even if she is a close friend, your anxiety here seems to be a disproportionate reaction."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:339
translate chinese JuR2_ES2_step1_a93c48a0:

    # Judy "Unless... the two of you did more than kiss?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:340
translate chinese JuR2_ES2_step1_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:342
translate chinese JuR2_ES2_step1_32893633:

    # Judy "Mmm... Tell me what happened, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:343
translate chinese JuR2_ES2_step1_9a1cc5c2:

    # MC "She... She went down on me that night."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:344
translate chinese JuR2_ES2_step1_ee18e849:

    # Judy "Oooh, and did you wear a condom or...?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:345
translate chinese JuR2_ES2_step1_33b2ead3:

    # MC "N-No condom. She just..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:347
translate chinese JuR2_ES2_step1_07e42e5d:

    # Judy "She just gobbled down on her brother’s big, fat cock?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:349
translate chinese JuR2_ES2_step1_835715cc:

    # Judy "She just gobbled down on your big, fat cock?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:351
translate chinese JuR2_ES2_step1_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:353
translate chinese JuR2_ES2_step1_502c91e0:

    # Judy "Tell me, where did you finish? All over her pretty little face? Or did you cum in her tight, wet mouth?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:354
translate chinese JuR2_ES2_step1_66ead5d1:

    # MC "I... Inside..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:356
translate chinese JuR2_ES2_step1_22462e97:

    # Judy "Hmm, very illuminating. I’m glad to hear you’re getting on so well with your younger sister."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:358
translate chinese JuR2_ES2_step1_8c4195f7:

    # Judy "Hmm, very illuminating. I’m glad to hear you’re getting on so well with your roommate."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:364
translate chinese JuR2_ES2_step1_8556805b:

    # MC "Heh... Where to begin?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:365
translate chinese JuR2_ES2_step1_68ec36c4:

    # MC "I guess it all kicked off when Sara engrossed herself a bit too much in her gaming. Her grades ended up dropping faster than..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:366
translate chinese JuR2_ES2_step1_59892d92:

    # Judy "Lily’s panties on prom night?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:368
translate chinese JuR2_ES2_step1_91d2ebef:

    # MC "You can’t talk about your students like that!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:370
translate chinese JuR2_ES2_step1_0ee6c9b1:

    # Judy "Haha! Why not? You and I both know she’s one of the more promiscuous ones on campus. Anyway, your sister’s grades started dropping. What happened next? Did you start offering her... “private tutoring?”"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:371
translate chinese JuR2_ES2_step1_356b8d51:

    # MC "Uh... no. My mom grounded her."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:373
translate chinese JuR2_ES2_step1_09a98d3d:

    # Judy "Haha! Why not? You and I both know she’s one of the more promiscuous ones on campus. Anyway, Sara’s grades started dropping. What happened next? Did you start offering her... “private tutoring?”"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:374
translate chinese JuR2_ES2_step1_a9e3b16f:

    # MC "Uh... no. She's staying all alone in her room and studying."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:376
translate chinese JuR2_ES2_step1_2814a8aa:

    # Judy "Oh... (That’s a far less sexy direction than I had anticipated this story going.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:378
translate chinese JuR2_ES2_step1_e49617bc:

    # MC "Yeah, we ended up having to chat while passing each other in the corridors of college. Despite mom keeping us apart though, we did kinda grow closer during that time."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:380
translate chinese JuR2_ES2_step1_0c283e4e:

    # MC "Yeah, we ended up having to chat while passing each other in the corridors of college. Despite her lack of time, we did kinda grow closer during that time."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:381
translate chinese JuR2_ES2_step1_23b12a56:

    # Judy "Absence makes the heart grow fonder, as they say."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:383
translate chinese JuR2_ES2_step1_b04371b8:

    # Judy "You mentioned that you “grew closer.” Can you define that for me? For example, were you intimate with your younger sister?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:385
translate chinese JuR2_ES2_step1_f3df4252:

    # Judy "You mentioned that you “grew closer.” Can you define that for me? For example, were you intimate with Sara?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:387
translate chinese JuR2_ES2_step1_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:388
translate chinese JuR2_ES2_step1_8369403d:

    # Judy "Oh, come on. You can tell me about this. It’s private therapy, completely confidential."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:389
translate chinese JuR2_ES2_step1_4f497db3:

    # MC "I... uh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:391
translate chinese JuR2_ES2_step1_98893a2b:

    # Judy "Did you have sex with her?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:392
translate chinese JuR2_ES2_step1_07432902:

    # MC "...y-yes..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:393
translate chinese JuR2_ES2_step1_479866c6:

    # Judy "What birth control did you use?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:395
translate chinese JuR2_ES2_step1_5eaa6a3c:

    # MC "I- We- didn’t-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:397
translate chinese JuR2_ES2_step1_4cb5f2d4:

    # Judy "Mmm, you fucked your own sister raw? Her tight teenage pussy must have felt so good against your bare cock. Did you cum insid-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:399
translate chinese JuR2_ES2_step1_f09f58f3:

    # Judy "Mmm, you fucked her raw? Her tight pussy must have felt so good against your bare cock. Did you cum insid-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:400
translate chinese JuR2_ES2_step1_a21433f4:

    # MC "N-No! I didn’t touch her pussy! It was the... other hole."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:403
translate chinese JuR2_ES2_step1_c2fdbba5:

    # Judy "Oh, so little Sara sucked off her own brother then?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:405
translate chinese JuR2_ES2_step1_c6e56e57:

    # Judy "Oh, so Sara sucked you off, then?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:406
translate chinese JuR2_ES2_step1_0d2706b9:

    # MC "No, it was the... uh... OTHER hole."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:407
translate chinese JuR2_ES2_step1_8ff5a2ba:

    # Judy "You fucked Sara in the ass?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:409
translate chinese JuR2_ES2_step1_0bc3cc90:

    # MC "Y-Yeah, she wasn’t quite ready for actual sex, so we did anal instead."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:411
translate chinese JuR2_ES2_step1_9248676a:

    # Judy "(I hadn’t planned to devote a chapter of my book to lusty brothers ravaging their own sisters’ asses, but it does offer an interesting avenue for potential research.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:413
translate chinese JuR2_ES2_step1_fc5dca66:

    # Judy "(I hadn’t planned to devote a chapter of my book to lusty men ravaging their womens' asses, but it does offer an interesting avenue for potential research - the male fascination with the derrieré!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:414
translate chinese JuR2_ES2_step1_d6cbe98a:

    # Judy "And how would you describe the experience for both of you? Thrilling? Enlightening? Life-changing?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:416
translate chinese JuR2_ES2_step1_7c18c0f4:

    # MC "Pretty... awful?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:417
translate chinese JuR2_ES2_step1_fc860bfe:

    # Judy "Oh... Why negative?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:418
translate chinese JuR2_ES2_step1_8fc97999:

    # MC "The first time we didn’t know to use lubricant."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:419
translate chinese JuR2_ES2_step1_963516c6:

    # Judy "Ouch."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:421
translate chinese JuR2_ES2_step1_a00f2a85:

    # MC "Yeah, it was-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:423
translate chinese JuR2_ES2_step1_619f8464:

    # Judy "Wait a minute, you said “the first time”. That implies you have fucked your sister’s ass on multiple occassions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:425
translate chinese JuR2_ES2_step1_8f1e276a:

    # Judy "Wait a minute, you said “the first time”. That implies you have fucked her ass on multiple occasions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:426
translate chinese JuR2_ES2_step1_53eac84b:

    # MC "(Nothing gets past this woman!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:428
translate chinese JuR2_ES2_step1_049aeaca:

    # MC "*Sigh* Yes."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:429
translate chinese JuR2_ES2_step1_2550f4e2:

    # Judy "With lube, I presume? How was it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:430
translate chinese JuR2_ES2_step1_807c4de4:

    # MC "Better with lube. For both of us."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:432
translate chinese JuR2_ES2_step1_4c6b2de0:

    # Judy "Mmm, well this has been MOST illuminating, [player_name]. We’ll move on now, but please keep me appraised of any future... adventures you have with your younger sister."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:434
translate chinese JuR2_ES2_step1_53f5b1bc:

    # Judy "Mmm, well this has been MOST illuminating, [player_name]. We’ll move on now, but please keep me appraised of any future... adventures you have with Sara."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:441
translate chinese JuR2_ES2_step1_3899f394:

    # Judy "How are you getting on with your big sister? Caroline, wasn’t it? It must have been a few years now since she graduated."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:443
translate chinese JuR2_ES2_step1_ca939346:

    # Judy "How are you getting on with that other girl you live with... Caroline, wasn’t it? I remember her. It must have been a few years now since she graduated."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:447
translate chinese JuR2_ES2_step1_729a8b66:

    # MC "Caroline and I haven’t really spoken that much recently. I mean, I stole a bottle of vodka from her right after the godawful incident with Ms. Celia."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:448
translate chinese JuR2_ES2_step1_1f5582c9:

    # Judy "Oh, I’m sorry to hear that, [player_name]. It may benefit you to try and get closer to her. I think it would be nice for you to have some positive female relationships in your life, after that traumatic incident with Ms. Celia."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:449
translate chinese JuR2_ES2_step1_7fd18fd0:

    # MC "Thanks Judy, I’ll consider it."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:459
translate chinese JuR2_ES2_step1_con_ff5b4d10:

    # MC "Judy, why are you so interested in my relationships with my sisters?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:461
translate chinese JuR2_ES2_step1_con_ed399ccb:

    # MC "Judy, why are you so interested in my relationships with my roommates?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:462
translate chinese JuR2_ES2_step1_con_3a767a1e:

    # Judy "Hmm? No reason in particular. Just general investigation, as part of my therapy process. Let’s move on to a different topic."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:464
translate chinese JuR2_ES2_step1_con_366a4027:

    # Judy "I think it would be wise for you to come to me whenever you advance your relationship with your mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:466
translate chinese JuR2_ES2_step1_con_3719bf60:

    # Judy "I think it would be wise for you to come to me whenever you advance your relationship with your landlady."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:467
translate chinese JuR2_ES2_step1_con_1f56319f:

    # MC "Really? Why?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:468
translate chinese JuR2_ES2_step1_con_032e4de5:

    # Judy "It would enable me to monitor the situation and keep an eye on your mental health. I wouldn’t want you slipping back into an unstable state, such as the one you experienced after Ms. Celia."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:470
translate chinese JuR2_ES2_step1_con_953ac76e:

    # Judy "Now, I do believe I promised to reward you if you talked to me about your relationship with your mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:472
translate chinese JuR2_ES2_step1_con_439dbc0e:

    # Judy "Now, I do believe I promised to reward you if you talked to me about your relationship with your landlady."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:473
translate chinese JuR2_ES2_step1_con_4ceba490:

    # Judy "Be a good boy and close your eyes for me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:480
translate chinese JuR2_ES2_step1_con_beac4e9f:

    # Judy "You were especially good today - and you really opened up about your relationship with your sister too. So I think you deserve something really special."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:482
translate chinese JuR2_ES2_step1_con_15a73f5c:

    # Judy "You were especially good today - and you really opened up about your relationship with your roommate too. So I think you deserve something really special."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:483
translate chinese JuR2_ES2_step1_con_309de5aa:

    # MC "(I wonder what she’s going to-)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:486
translate chinese JuR2_ES2_step1_con_d9bbec5b:

    # "*Zzzziiip*"
    ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:490
translate chinese JuR2_ES2_step1_con_2f956f5e:

    # Judy "(My, my... [player_name] is hard already. Seeing me clad in nothing more than my lingerie must have excited him.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:491
translate chinese JuR2_ES2_step1_con_20ed7f54:

    # Judy "(So... This is the cock that has gotten Linda so hot and bothered. I can see why. It’s a decent size. She must have enjoyed playing with it under the table of that restaurant.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:495
translate chinese JuR2_ES2_step1_con_b66f7637:

    # MC "(Holy crap! She just unzipped my jeans!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:496
translate chinese JuR2_ES2_step1_con_fc083688:

    # MC "Judy, wh-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:500
translate chinese JuR2_ES2_step1_con_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:501
translate chinese JuR2_ES2_step1_con_036e0f44:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:502
translate chinese JuR2_ES2_step1_con_6cfb2489:

    # MC "(I can feel her soft palm stroking up and down against my shaft. She must have just moisturised, her fingers feel slippery.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:506
translate chinese JuR2_ES2_step1_con_036e0f44_1:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:508
translate chinese JuR2_ES2_step1_con_faac6070:

    # Judy "([player_name] mentioned that he had sixty-nined with his mom. I wonder if she has given him a handjob like this yet. If I were Linda’s son I don’t think I’d be able to last long with her stroking my cock like this.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:510
translate chinese JuR2_ES2_step1_con_fc850d52:

    # Judy "([player_name] mentioned that he had sixty-nined with Linda. I wonder if she has given him a handjob like this yet... If I were a young man, like [player_name], I don’t think I’d be able to last long with her stroking my cock like this.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:511
translate chinese JuR2_ES2_step1_con_2ce9e250:

    # MC "Mmm! (I’m getting so fucking hard, right now!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:515
translate chinese JuR2_ES2_step1_con_963ce2c6:

    # Judy "([player_name] isn’t a bad kisser, for someone still in college.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:517
translate chinese JuR2_ES2_step1_con_b057af19:

    # Judy "(Speaking of which, it is HIGHLY unethical for me to be wanking off a patient, let alone one who is also a student. The Association would revoke my licence if they ever found out.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:518
translate chinese JuR2_ES2_step1_con_998ed297:

    # Judy "(Maybe after I have completed my research, I will finally begin to understand why things of a taboo nature turn me on soooo much.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:522
translate chinese JuR2_ES2_step1_con_8f027c34:

    # Judy "Let’s move on to your balls now, shall we?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:523
translate chinese JuR2_ES2_step1_con_292f3145:

    # MC "Ahh... Mmmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:524
translate chinese JuR2_ES2_step1_con_a65cf5a3:

    # MC "(Her hands are so warm, I don’t think I’ll be able to last long!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:528
translate chinese JuR2_ES2_step1_con_076c0813:

    # Judy "Here, why don’t you look at my breasts while I finish you off?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:529
translate chinese JuR2_ES2_step1_con_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:530
translate chinese JuR2_ES2_step1_con_77c31587:

    # Judy "Go on, you can touch them."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:534
translate chinese JuR2_ES2_step1_con_c8fee973:

    # Judy "You’ve wanted this since the first time you saw me, haven’t you? What guy wouldn’t?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:535
translate chinese JuR2_ES2_step1_con_514046b7:

    # Judy "Mmm... You can squeeze my tits as much as you want, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:537
translate chinese JuR2_ES2_step1_con_ff383112:

    # MC "(They’re so firm!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:541
translate chinese JuR2_ES2_step1_con_9834b424:

    # Judy "I want you to tell me when you’re getting close, [player_name]. Are you there yet?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:542
translate chinese JuR2_ES2_step1_con_a780f652:

    # MC "A-Almost... Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:543
translate chinese JuR2_ES2_step1_con_53a34df3:

    # Judy "Let me know when you want to cum and I’ll stroke your cock even faster."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:550
translate chinese JuR2_ES2_step1_con_040684f0:

    # MC "Hnnng! I’m getting there! I’m about to cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:551
translate chinese JuR2_ES2_step1_con_5e321b1d:

    # Judy "That’s it. Cum for me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:553
translate chinese JuR2_ES2_step1_con_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:554
translate chinese JuR2_ES2_step1_con_3984a5bd:

    # Judy "I want to feel your hard cock pulsate between my fingers. Blow your hot cum all over my hand."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:558
translate chinese JuR2_ES2_step1_con_6819ec68:

    # MC "Ah! Sh-Shit! I’m cumming!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:559
translate chinese JuR2_ES2_step1_con_5e2257ad:

    # Judy "Keep groping my breasts while you release your load, [player_name]. That’s it. Give me your cum."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:560
translate chinese JuR2_ES2_step1_con_bd0fd27b:

    # MC "Aarrghhhh! Ugh *Pant* *Gasp* Ahh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:570
translate chinese JuR2_ES2_step1_con_c6cf8a88:

    # Judy "Oh wow, that is A LOT. Were you saving this up for me?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:571
translate chinese JuR2_ES2_step1_con_70588038:

    # MC "*Pant* I... *Gasp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:572
translate chinese JuR2_ES2_step1_con_d267645f:

    # Judy "Wasn’t that a nice relief from a good therapy session? Take some time to catch your breath, [player_name], and don’t forget..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:576
translate chinese JuR2_ES2_step1_con_f55f9dee:

    # Judy "...I am prepared to reward you in MUCH more exciting ways if you continue to update me on the relationship between you and your mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:577
translate chinese JuR2_ES2_step1_con_c2feb93c:

    # MC "(That’s a really tempting offer! I should probably visit Judy again if anything new happens with my mom.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:579
translate chinese JuR2_ES2_step1_con_fec5bfc6:

    # Judy "...I am prepared to reward you in MUCH more exciting ways if you continue to update me on the relationship between you and your landlady."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:580
translate chinese JuR2_ES2_step1_con_c71a8a79:

    # MC "(That’s a really tempting offer! I should probably visit Judy again if anything new happens with Linda.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:607
translate chinese JuR2_ES2_step1_con_520c41d4:

    # MC "W-Wait, hold on. Do..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:608
translate chinese JuR2_ES2_step1_con_a29885c2:

    # Judy "Yes?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:609
translate chinese JuR2_ES2_step1_con_936d0166:

    # MC "Nevermind."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:610
translate chinese JuR2_ES2_step1_con_3e1b0e41:

    # Judy "Go on. It’s so important that you fully open up in therapy. Tell me what you desire, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:611
translate chinese JuR2_ES2_step1_con_0b815ec6:

    # MC "Could you- *gulp* Could you use your... feet instead?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:615
translate chinese JuR2_ES2_step1_con_56c2b2eb:

    # Judy "My feet? I must say, I wasn’t expecting you to request that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:616
translate chinese JuR2_ES2_step1_con_94d061ec:

    # Judy "A blowjob? Sure. Fuck my tits? Absolutely. I would have even thought you bold enough to ask to fuck me. But my feet? You took me by surprise there, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:618
translate chinese JuR2_ES2_step1_con_79084ded:

    # Judy "Perhaps I was naive to not expect such perversions from someone who would willingly receive a blowjob from his own mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:620
translate chinese JuR2_ES2_step1_con_4c532cf7:

    # Judy "Perhaps I was naive to not expect such perversions from someone who would willingly receive a blowjob from a married older woman in public."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:623
translate chinese JuR2_ES2_step1_con_a977313a_1:

    # MC "Wow..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:624
translate chinese JuR2_ES2_step1_con_5038223f:

    # Judy "Now, THAT is worth noting."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:625
translate chinese JuR2_ES2_step1_con_4596eaf4:

    # MC "Wh-What is?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:626
translate chinese JuR2_ES2_step1_con_86a0a54c:

    # Judy "I took my bra off and turned to face you with my breasts exposed, yet your eyes are currently focused on my high-heels. Do you find my feet more attractive than my breasts, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:627
translate chinese JuR2_ES2_step1_con_cea225ce:

    # MC "N-No!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:628
translate chinese JuR2_ES2_step1_con_17a36079:

    # Judy "You think my feet are unattractive, then?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:629
translate chinese JuR2_ES2_step1_con_a1e764be:

    # MC "What, I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:633
translate chinese JuR2_ES2_step1_con_bcfb78d5:

    # Judy "Ha! I couldn’t resist teasing you. Feel free to look wherever you want, [player_name]. Cast your gaze anywhere you want on my body."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:635
translate chinese JuR2_ES2_step1_con_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:639
translate chinese JuR2_ES2_step1_con_6ccb6b8e:

    # Judy "Or you can just close your eyes and fantasise that it’s your own mother, curling her soft toes around the tip of your rock-hard cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:641
translate chinese JuR2_ES2_step1_con_6e31fe5e:

    # Judy "Or you can just close your eyes and fantasise that it’s Linda, curling her soft toes around the tip of your rock-hard cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:642
translate chinese JuR2_ES2_step1_con_aa08f92d:

    # MC "Hnng...! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:644
translate chinese JuR2_ES2_step1_con_b70988c5:

    # Judy "Mmm, you liked it when I brought up Linda, didn’t you? I could feel your shaft twitch as soon as I raised the idea of your own mother massaging your cock with her feet."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:646
translate chinese JuR2_ES2_step1_con_c1471347:

    # Judy "Mmm, you liked it when I brought up Linda, didn’t you? I could feel your shaft twitch as soon as I raised the idea of your landlady massaging your cock with her feet."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:650
translate chinese JuR2_ES2_step1_con_57d08b00:

    # MC "Mmm... Ohh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:652
translate chinese JuR2_ES2_step1_con_f25b5f51:

    # Judy "Feel my toes sliding along your shaft. Focus on the sensation as it glides down to the base of your cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:653
translate chinese JuR2_ES2_step1_con_8690377b:

    # Judy "You’re enjoying this, aren’t you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:657
translate chinese JuR2_ES2_step1_con_17510228:

    # MC "Mmm! Yes! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:659
translate chinese JuR2_ES2_step1_con_c5e0323e:

    # Judy "I want you to keep imagining your mom doing this right now. Keep your mind focused on Linda, stroking her own son’s shaft with her soles."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:661
translate chinese JuR2_ES2_step1_con_6a9d7c0c:

    # Judy "I want you to keep imagining Linda doing this right now. Keep your mind focused on her. Visualise her, stroking your shaft with her soles."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:665
translate chinese JuR2_ES2_step1_con_dd984d93:

    # MC "*Gasp* Oohh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:666
translate chinese JuR2_ES2_step1_con_196be25a:

    # Judy "That’s it. Just sit back and enjoy this."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:667
translate chinese JuR2_ES2_step1_con_9c1e1dbc:

    # Judy "It was good that you opened up so much in therapy today. This is your reward for being open and honest with me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:668
translate chinese JuR2_ES2_step1_con_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:669
translate chinese JuR2_ES2_step1_con_e1cbff3f:

    # Judy "And the rewards will only get better, the more you tell me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:671
translate chinese JuR2_ES2_step1_con_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:673
translate chinese JuR2_ES2_step1_con_83c6a341:

    # Judy "Oh, is someone about to cum? Think about your mom. Imagine her lying back on the bed, completely naked, as she rubs her bare feet all over your-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:674
translate chinese JuR2_ES2_step1_con_347f7634:

    # MC "Hnnng! I’m cumming, mom!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:676
translate chinese JuR2_ES2_step1_con_b38ddd38:

    # Judy "Oh, is someone about to cum? Think about Linda. Imagine her lying back on the bed, completely naked, as she rubs her bare feet all over your-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:677
translate chinese JuR2_ES2_step1_con_bb3b0dc6:

    # MC "Hnnng! I’m cumming, Linda!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:678
translate chinese JuR2_ES2_step1_con_175502eb:

    # Judy "That’s it! Cum for me, baby! Let it all out!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:687
translate chinese JuR2_ES2_step1_con_6d5ccc6c:

    # MC "Hnnng!! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:688
translate chinese JuR2_ES2_step1_con_1af9b395:

    # Judy "Mmm, good boy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:692
translate chinese JuR2_ES2_step1_con_bf97f7c0:

    # MC "*Pant* Sorry, I think I called you ‘mom’ instead of Judy, at the end there. That was really awkwa-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:694
translate chinese JuR2_ES2_step1_con_f5d22e8b:

    # MC "*Pant* Sorry, I think I called you ‘Linda’ instead of Judy, at the end there. That was really awkwa-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:695
translate chinese JuR2_ES2_step1_con_d98c2b8b:

    # Judy "No, it wasn’t. It was just another part of therapy. You revealed your true desires, in the heat of the moment."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:696
translate chinese JuR2_ES2_step1_con_d7b2c3a1:

    # MC "Huh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:697
translate chinese JuR2_ES2_step1_con_3b3168b1:

    # MC "What are YOUR true desires, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:698
translate chinese JuR2_ES2_step1_con_73e97bae:

    # Judy "..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:699
translate chinese JuR2_ES2_step1_con_b7417299:

    # Judy "I think that will conclude our therapy for today. You can take some tissues if you need to clean yourself up."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:701
translate chinese JuR2_ES2_step1_con_3f72c0e9:

    # Judy "Don’t forget to return if you have any further encounters with your mom. I would be VERY interested in discussing them with you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:703
translate chinese JuR2_ES2_step1_con_bafca38c:

    # Judy "Don’t forget to return if you have any further encounters with your landlady. I would be VERY interested in discussing them with you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:740
translate chinese JuR2_ES2_step2_d3d962dd:

    # Judy "Oh... Mmm... Ah..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:741
translate chinese JuR2_ES2_step2_90efa01d:

    # MC "(Huh? What’s going on in there?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:746
translate chinese JuR2_ES2_step2_05dee19c:

    # "*Creeaaak*"
    ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:747
translate chinese JuR2_ES2_step2_65bb5cd4:

    # MC "(Oh my God!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:751
translate chinese JuR2_ES2_step2_49144e23:

    # Judy "Ah... *Gasp* Ohh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:752
translate chinese JuR2_ES2_step2_f91c6cbc:

    # MC "(She’s playing with herself after our therapy session!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:756
translate chinese JuR2_ES2_step2_0715d513:

    # Judy "Mmm... Yes! That’s it Linda, keep sucking your son’s cock. Ah! Just like that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:758
translate chinese JuR2_ES2_step2_42af5c1e:

    # Judy "Mmm... Yes! That’s it Linda, keep sucking [player_name]’s cock. Ah! Just like that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:759
translate chinese JuR2_ES2_step2_d4506f85:

    # Judy "Ooh! *Gasp* His inexperienced dick isn’t going to last too long in your talented mouth."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:760
translate chinese JuR2_ES2_step2_20607582:

    # MC "(I can’t believe this! She’s fantasising about what I opened up to her about in therapy!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:764
translate chinese JuR2_ES2_step2_7900893d:

    # Judy "Ah! Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:766
translate chinese JuR2_ES2_step2_b99ed724:

    # Judy "That’s it, Linda. Take your boy’s cock deep into your warm, wet mouth. Feel his cock ugh... throb in your tight throat."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:768
translate chinese JuR2_ES2_step2_51a52813:

    # Judy "That’s it, Linda. Take [player_name]’s cock deep into your warm, wet mouth. Feel his cock ugh... throb in your tight throat."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:772
translate chinese JuR2_ES2_step2_223b8f96:

    # Judy "Oh! Mmm! Yes!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:773
translate chinese JuR2_ES2_step2_3e3564bc:

    # Judy "Caress his balls as you gobble down his dick. Imagine how his salty cum is going to taste when he finally erupts in your mouth."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:777
translate chinese JuR2_ES2_step2_acabd4b6:

    # Judy "Mmm! MMMM!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:778
translate chinese JuR2_ES2_step2_e2a74713:

    # MC "(Holy crap! She’s licking up my cum from earlier!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:782
translate chinese JuR2_ES2_step2_4d65f1b3:

    # Judy "Mmmpff! *Shlurrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:783
translate chinese JuR2_ES2_step2_c51b535f:

    # Judy "*Suck* Mmm! I’mmm cummmminnng!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:787
translate chinese JuR2_ES2_step2_08d248a5:

    # MC "(Y’know what? I’m beginning to realise why private therapy is a whole lot better than the one offered at college!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:788
translate chinese JuR2_ES2_step2_360320aa:

    # Judy "Ahmmmmmmm!!! MMMMM!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES2.rpy:789
translate chinese JuR2_ES2_step2_559d5500:

    # MC "(I’ll sneak out now before she notices I was spying on her.)"
    MC ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_ES2.rpy:545
    old "I’m there - finish me with your hand!"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES2.rpy:545
    old "W-Wait, do you think you could use your... feet instead?"
    new ""

