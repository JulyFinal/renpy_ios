﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_We.rpy:271
translate chinese JuR2_We_step1_7a030e5e:

    # Judy "Well, hello there, [player_name]. I was beginning to think you weren’t going to come."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:278
translate chinese JuR2_We_step1_29b807f2:

    # Judy "It isn’t fair to keep a girl waiting, y’know."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:280
translate chinese JuR2_We_step1_63f9fbfb:

    # MC "Hey, sorry I’m a little late."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:282
translate chinese JuR2_We_step1_accbdf0d:

    # Judy "Haha, relax. I’m just teasing you. I’m sure I would have been able to find another way to pass the time if you didn’t make it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:286
translate chinese JuR2_We_step1_eff13507:

    # MC "How did you get access to campus on the weekend? I thought this place was pretty strict with security."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:288
translate chinese JuR2_We_step1_e9363e64:

    # Judy "I’ve done MORE than my fair share of favours for our illustrious Dean. I decided now was the time to call in a few of them. He gave me a set of keys and turned off security."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:290
translate chinese JuR2_We_step1_ad30fd68:

    # MC "He knows you’re going to fool around with one of his students?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:292
translate chinese JuR2_We_step1_506f44ff:

    # Judy "Oh please, he does it all the time too."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:296
translate chinese JuR2_We_step1_22379f9a:

    # Judy "Now, can I interest you in something to drink? A little wine, perhaps?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:298
translate chinese JuR2_We_step1_5c8031ac:

    # MC "The last time I accepted a glass of wine from you, I was drugged and knocked unconscious."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:302
translate chinese JuR2_We_step1_d2be7670:

    # Judy "True, but you also got to have a threesome with me and your mom. So, y’know... six of one, half a dozen of the other?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:304
translate chinese JuR2_We_step1_16daaa06:

    # Judy "True, but you also got to have a threesome with me and Linda. So, y’know... six of one, half a dozen of the other?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:306
translate chinese JuR2_We_step1_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:308
translate chinese JuR2_We_step1_574687db:

    # Judy "Oh, c’mon. Worst-case scenario, I’ve drugged the wine again. If that happens, I’m just gonna fuck you silly - but that’s what you came here for anyway, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:310
translate chinese JuR2_We_step1_67383431:

    # MC "You’re an awful therapist, Judy, you know that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:314
translate chinese JuR2_We_step1_967b2e1d:

    # Judy "I prefer the term, “ethically challenged.” Haha!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:316
translate chinese JuR2_We_step1_de9be7ff:

    # MC "Ahaha!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:318
translate chinese JuR2_We_step1_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/Ju_scenes/JuR2_We.rpy:322
translate chinese JuR2_We_step1_1e41f95d:

    # MC "All joking aside, congrats on finally publishing your book. It’s a big win for you."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:324
translate chinese JuR2_We_step1_d3bfedf3:

    # Judy "Thanks, [player_name]. I’m really happy with how it turned out. The worst part was having to call round dozens of publishers to try and find one who would actually put it to print."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:328
translate chinese JuR2_We_step1_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:330
translate chinese JuR2_We_step1_58df3ca9:

    # Judy "See? No drugs."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:334
translate chinese JuR2_We_step1_3c106128:

    # MC "Hmm... (I don’t feel sleepy like last time. It looks like Judy is telling the truth.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:336
translate chinese JuR2_We_step1_1a487239:

    # MC "I don’t think I ever properly thanked you, Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:338
translate chinese JuR2_We_step1_f029e271:

    # Judy "Thanked me? Whatever for? You’re the one who helped me with the research I needed to complete my novel."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:341
translate chinese JuR2_We_step1_6f894c25:

    # MC "You did plenty for me as well. I was a total mess after Ms. Celia’s rejection. Your therapy sessions helped me process everything."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:342
translate chinese JuR2_We_step1_8f4fe3c4:

    # MC "(God, her body is incredible!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:345
translate chinese JuR2_We_step1_ee241ffe:

    # MC "Plus, you also helped me out by giving advice on how to handle my mom’s advances. I wasn’t sure about it at the start, but you convinced me."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:346
translate chinese JuR2_We_step1_bf40e041:

    # MC "And then when the time came to deal with my dad, you guided us both through that."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:348
translate chinese JuR2_We_step1_f6bb851c:

    # MC "Plus, you also helped me out by giving advice on how to handle Linda’s advances. I wasn’t sure about it at the start, but you convinced me."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:349
translate chinese JuR2_We_step1_88a725fe:

    # MC "And then when the time came to deal with Bob, you guided us both through that."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:350
translate chinese JuR2_We_step1_96f934de:

    # MC "So, yeah... thanks for everything, Judy. I really appreciate everything you’ve done for me."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:352
translate chinese JuR2_We_step1_705fcbf4:

    # Judy "It’s been a pleasure, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:353
translate chinese JuR2_We_step1_dec60017:

    # MC "So, what exactly did you have planned for this weekend that requires you to use the ENTIRE campus?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:354
translate chinese JuR2_We_step1_59945fae:

    # Judy "I thought you and I could play a little game together."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:356
translate chinese JuR2_We_step1_470f07ca:

    # MC "A game?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:357
translate chinese JuR2_We_step1_b9c87223:

    # Judy "Hide and seek. I’ll go and hide somewhere on campus. Each time you find me, I’ll let you fuck me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:358
translate chinese JuR2_We_step1_9879a67c:

    # MC "Sounds good to me!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:360
translate chinese JuR2_We_step1_342c13be:

    # Judy "Did you bring condoms by the way?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:361
translate chinese JuR2_We_step1_83fc11b8:

    # MC "Err... no."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:362
translate chinese JuR2_We_step1_ae58090c:

    # Judy "Then you can fuck me anywhere EXCEPT my pussy. How about we kick off with a warm-up session in here before I go to hide?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:363
translate chinese JuR2_We_step1_66c0595e:

    # MC "Sure!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:364
translate chinese JuR2_We_step1_1746fa00:

    # Judy "Give me a hand getting this bra off."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:366
translate chinese JuR2_We_step1_be9fe07d:

    # Judy "Ahh, there we go. Much better."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:368
translate chinese JuR2_We_step1_75ce191e:

    # MC "(Her breasts are so soft!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:370
translate chinese JuR2_We_step1_8c0bca9b:

    # Judy "Are you enjoying that, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:372
translate chinese JuR2_We_step1_7a059b89:

    # MC "Of course! They’re amazing!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:373
translate chinese JuR2_We_step1_eac4d6ec:

    # MC "Do I still have to keep calling you “mom” tonight?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:374
translate chinese JuR2_We_step1_1347b38e:

    # Judy "Haha, Judy will be fine. I think I’ve got that out of my system, now that I’ve finally put that book behind me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:376
translate chinese JuR2_We_step1_036e0f44:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:378
translate chinese JuR2_We_step1_57f7aca4:

    # Judy "It’s hardly fair that I’m the only one having any fun here..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:380
translate chinese JuR2_We_step1_e32d63ef:

    # Judy "...especially when you are overdressed for the occasion. Let’s get you out of these clothes."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:382
translate chinese JuR2_We_step1_f776eb60:

    # MC "Whoa, easy! No need to rush, we’ve got all weekend!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:383
translate chinese JuR2_We_step1_a8b11154:

    # Judy "C’mon! Hurry up and get your shoes off as well! I want you completely naked for the next part!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:384
translate chinese JuR2_We_step1_ec7e1559:

    # Judy "There we go! Better!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:386
translate chinese JuR2_We_step1_3d6e26ca:

    # Judy "Now, let’s get you warmed up."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:387
translate chinese JuR2_We_step1_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:389
translate chinese JuR2_We_step1_96df3bdc:

    # MC "Aaahhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:390
translate chinese JuR2_We_step1_faa9d921:

    # MC "(What the fuck?! She just pushed me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:395
translate chinese JuR2_We_step1_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Ju_scenes/JuR2_We.rpy:396
translate chinese JuR2_We_step1_1b08a95a:

    # MC "Ooof!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:397
translate chinese JuR2_We_step1_d51368ad:

    # Judy "There we go! See? Isn’t that better?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:398
translate chinese JuR2_We_step1_40820c3b:

    # MC "You could have just asked me to lie down!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:399
translate chinese JuR2_We_step1_40eaf6b2:

    # Judy "Oh yeah, I probably should have... I get a little bit ahead of myself sometimes when I’ve been drinking."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:401
translate chinese JuR2_We_step1_143545f9:

    # Judy "Here, let me make it up to you. Just lie back, relax, and enjoy the sensation of your cock buried between my breasts."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:402
translate chinese JuR2_We_step1_a28ac71a:

    # MC "(Eh, I guess I can handle Judy being a little bit rough, so long as she treats me like this afterwards!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:404
translate chinese JuR2_We_step1_58ab7cd5:

    # MC "So, when are we starting this game of hide and seek you wanted to play?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:406
translate chinese JuR2_We_step1_fee56a64:

    # Judy "Right after I get us both warmed up."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:407
translate chinese JuR2_We_step1_3200c0a0:

    # Judy "Mmm, I see you’re already nice and hard for me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:409
translate chinese JuR2_We_step1_1655047f:

    # Judy "Your big dick is going to feel so good between my breasts."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:411
translate chinese JuR2_We_step1_c3f494c2:

    # Judy "I really hope you enjoy today, [player_name]. I think you’re going to find it to be a VERY satisfying reward - for everything you’ve done to help me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:412
translate chinese JuR2_We_step1_3fb6515d:

    # MC "Mmm, I’m sure I will."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:414
translate chinese JuR2_We_step1_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:415
translate chinese JuR2_We_step1_f80b23ca:

    # Judy "Mmm, you like it when I rub your cock between my tits, don’t you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:417
translate chinese JuR2_We_step1_ceeda8d1:

    # Judy "I’m sure there’s some deep-rooted psychological reasoning behind the arousal you experience when I do this."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:418
translate chinese JuR2_We_step1_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:420
translate chinese JuR2_We_step1_1a66fd65:

    # Judy "After all, when men enjoy sucking on breasts, it is often a sign of an oral fixation."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:421
translate chinese JuR2_We_step1_8a6b9c00:

    # Judy "These are usually caused by the mother not breastfeeding the child at-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:423
translate chinese JuR2_We_step1_349ba5ba:

    # MC "Okay Judy, listen... You’re great, but can we just... try and turn off therapist mode for a few hours? Please."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:424
translate chinese JuR2_We_step1_87a35556:

    # Judy "Whoops. Sorry, I’ve got a tendency to do that. My ex used to hate it when I did that during sex."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:425
translate chinese JuR2_We_step1_eba3b418:

    # MC "Ahaha, seriously? You psychoanalysed your ex while you were having sex?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:427
translate chinese JuR2_We_step1_8060d43f:

    # Judy "What can I say? I’m good at turning people on, but not so good at turning myself off! Haha!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:429
translate chinese JuR2_We_step1_0189b4f1:

    # MC "How about you just try saying sexy stuff, for a change? You’ve finished your book - you’re supposed to be relaxing this weekend, remember?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:431
translate chinese JuR2_We_step1_a50fc167:

    # Judy "Haha, alright, alright! No more therapy talk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:432
translate chinese JuR2_We_step1_19f340fd:

    # MC "Thank you!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:434
translate chinese JuR2_We_step1_eb06c41f:

    # Judy "How does it feel? Do you want me to go faster?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:435
translate chinese JuR2_We_step1_a385279c:

    # MC "Mmm, no, that’s perfect! Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:437
translate chinese JuR2_We_step1_40257181:

    # Judy "I love the feeling of your hard cock, pulsing between my breasts."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:439
translate chinese JuR2_We_step1_54b7d44a:

    # MC "Ah... hnngg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:441
translate chinese JuR2_We_step1_2bbc2a1d:

    # Judy "Are you close to cumming, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:442
translate chinese JuR2_We_step1_d82a35fd:

    # MC "*Pant* I’m getting there!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:443
translate chinese JuR2_We_step1_00726ad8:

    # Judy "Yeah? How about if I speed things up?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:445
translate chinese JuR2_We_step1_74584043:

    # MC "Oh! Ohh fuck! Hnng!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:446
translate chinese JuR2_We_step1_18e1c7d6:

    # MC "I’m gonna cum! I’m-"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:448
translate chinese JuR2_We_step1_fac74deb:

    # Judy "Ah, ah, ah. Not yet! You and I still have a whole weekend of sex planned."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:449
translate chinese JuR2_We_step1_d8f1631c:

    # MC "Oh c’mon! I was sooo close!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:450
translate chinese JuR2_We_step1_3056669d:

    # Judy "I’m not having you blow your load on the first lap!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:452
translate chinese JuR2_We_step1_ff770802:

    # MC "*Sigh* Fine! What happens now?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:453
translate chinese JuR2_We_step1_e6b5642e:

    # Judy "Well, first things first..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:455
translate chinese JuR2_We_step1_98e84ac6:

    # Judy "...you are going to close your eyes, and I’m going to find a place to hide."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:456
translate chinese JuR2_We_step1_0751a674:

    # Judy "If you can find me, then you’ll get to fuck me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:457
translate chinese JuR2_We_step1_89d379ae:

    # MC "And what are you planning to do when you’re waiting for me to find you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:458
translate chinese JuR2_We_step1_b6e81f4d:

    # Judy "Get drunk on wine and play with myself, of course!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:460
translate chinese JuR2_We_step1_f14bb477:

    # MC "Haha, fine!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:462
translate chinese JuR2_We_step1_bc92d5d0:

    # Judy "Get dressed, count to thirty, and then start looking!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:463
translate chinese JuR2_We_step1_35c5d6cb:

    # MC "Why do I have to get dressed again?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:464
translate chinese JuR2_We_step1_ad271f13:

    # Judy "Because stripping you is half the fun!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:465
translate chinese JuR2_We_step1_d9cdbbc5:

    # Judy "(Right, there’s my wine and my glass. Hmm, where should I hide?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:466
translate chinese JuR2_We_step1_2776523e:

    # MC "One... Two... Three..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:468
translate chinese JuR2_We_step1_4fcbce41:

    # MC "Four... Five... Six..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:469
translate chinese JuR2_We_step1_35bf34bc:

    # MC "(I wonder where she’s going to hide first?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:489
translate chinese JuR2_We_step2_d9b76f5c:

    # MC "(Aha! There she is!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:490
translate chinese JuR2_We_step2_eaf4b4da:

    # MC "Found ya!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:496
translate chinese JuR2_We_step2_3aa08a0f:

    # Judy "Took you *Hic* longer than I expected!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:497
translate chinese JuR2_We_step2_e7860098:

    # MC "What can I say? It’s a big campus! You’re getting tipsy, aren’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:498
translate chinese JuR2_We_step2_68534b00:

    # Judy "No, no. Just a couple of glasses. I’m fine!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:500
translate chinese JuR2_We_step2_7a21b477:

    # MC "So, I’ve found you. What happens now?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:501
translate chinese JuR2_We_step2_1f7e3010:

    # Judy "What do you WANT to happen now?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:503
translate chinese JuR2_We_step2_f5e3193f:

    # MC "Well, I got to take off your bra in your office, so I think we’ll lose your panties this time."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:504
translate chinese JuR2_We_step2_1b80eef3:

    # Judy "Oh, really?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:506
translate chinese JuR2_We_step2_e3dd1314:

    # Judy "And what exactly are you *hic* planning to do with me once my panties are gone and I’m all exposed?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:508
translate chinese JuR2_We_step2_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/Ju_scenes/JuR2_We.rpy:509
translate chinese JuR2_We_step2_953ba607:

    # MC "You’ll just have to wait and find out, won’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:511
translate chinese JuR2_We_step2_5e6f24c1:

    # Judy "Hehe!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:512
translate chinese JuR2_We_step2_e0f0ecf9:

    # Judy "Are you sure you didn’t bring any condoms with you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:513
translate chinese JuR2_We_step2_4d414dd4:

    # MC "I’m afraid not."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:515
translate chinese JuR2_We_step2_edb1db5f:

    # MC "Besides, we don’t need condoms, do we?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:516
translate chinese JuR2_We_step2_2e349566:

    # Judy "We doooo!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:517
translate chinese JuR2_We_step2_05a931ac:

    # MC "C’mon, it’ll feel good if I just slip it inside. How about I just put it in for a second and see how you feel?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:519
translate chinese JuR2_We_step2_8d83b48d:

    # Judy "I..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:520
translate chinese JuR2_We_step2_dde65662:

    # Judy "God, I shouldn't... but it's really tempting. I'd get to experience what Linda felt again. Plus, his cock is soooo thick."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:521
translate chinese JuR2_We_step2_055bb54e:

    # MC "Let’s just slide your panties out of the way and, see what happens."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:523
translate chinese JuR2_We_step2_4a02fefd:

    # Judy "*Gasp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:524
translate chinese JuR2_We_step2_ea40a5bf:

    # MC "You’re really cute when you’re drunk, you know that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:525
translate chinese JuR2_We_step2_23f674e8:

    # Judy "I’m not drunk! Just a little bit... tipsy, perhaps."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:527
translate chinese JuR2_We_step2_b10aa102:

    # Judy "Whoa!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:528
translate chinese JuR2_We_step2_021c7f33:

    # MC "See? Much better at this angle. Now just lie back, relax, and enjoy the feeling of my dick sliding inside."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:529
translate chinese JuR2_We_step2_daaf5c33:

    # Judy "(I shouldn’t do this! I need to pull myself together! I don’t want to end up with kids! Why would I fuck this guy with no protection?!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:531
translate chinese JuR2_We_step2_133e8ef9:

    # Judy "(On the other hand... it should be safe as long as he doesn’t finish inside, right?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:532
translate chinese JuR2_We_step2_4e96376e:

    # Judy "(I mean, I’ll probably enjoy it? It should feel much better than the last time we did it when he was wearing a condom.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:533
translate chinese JuR2_We_step2_731310fa:

    # MC "Let’s get these out of the way."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:535
translate chinese JuR2_We_step2_85b8982f:

    # MC "I’m going to fuck you so hard."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:536
translate chinese JuR2_We_step2_de4716f8:

    # Judy "*Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:537
translate chinese JuR2_We_step2_e28c8f8b:

    # Judy "(It shouldn’t matter if he just puts it in for a few seconds, right? I’ll be able to tell him when to stop and then we can try something else.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:539
translate chinese JuR2_We_step2_0f6d5e30:

    # Judy "(Oh my God, it’s really going to happen, isn’t it? He’s going to put his bare cock inside me...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:540
translate chinese JuR2_We_step2_59e6ae3e:

    # MC "You want this inside you, don’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:541
translate chinese JuR2_We_step2_06d0d649:

    # Judy "Mmm... Yes..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:543
translate chinese JuR2_We_step2_57bc533b:

    # MC "(She’s so incredibly sexy when she looks up at me like that.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:544
translate chinese JuR2_We_step2_f0f8307f:

    # Judy "*Pant*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:545
translate chinese JuR2_We_step2_ea40958f:

    # Judy "(I can’t believe I’m actually going to do it bareback with him...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:547
translate chinese JuR2_We_step2_3d53a726:

    # MC "Here we go, Judy. Are you ready?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:548
translate chinese JuR2_We_step2_9a395592:

    # Judy "(His cock is so close... God... what am I thinking?! I’m not even on the pill right now. I shouldn’t do this...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:549
translate chinese JuR2_We_step2_cf8d3177:

    # Judy "Yes..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:551
translate chinese JuR2_We_step2_4a02fefd_1:

    # Judy "*Gasp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:552
translate chinese JuR2_We_step2_96cdb08a:

    # Judy "(I’m getting so wet at the thought of his bare cock sliding into my unprotected pussy. Him thrusting back and forth... me losing control as I feel his big dick pulsate inside me.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:553
translate chinese JuR2_We_step2_80d4153b:

    # Judy "(The panic as he thrusts his shaft inside me and empties his hot cum, deep into my fertile womb. I’d be unable to resist him as I feel his sperm rushing to fertilise me.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:555
translate chinese JuR2_We_step2_233071be:

    # Judy "(Crap! I can’t let my impregnation kink get the better of me, right now! I’ve just published my first novel! The last thing I need is a child!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:556
translate chinese JuR2_We_step2_fa48878e:

    # Judy "Whoa! Hold up! No condom, no pussy!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:558
translate chinese JuR2_We_step2_935e865d:

    # MC "Haha, fine! Where do you want me to fuck you instead?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:559
translate chinese JuR2_We_step2_4101c37a:

    # Judy "You can go in my ass."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:560
translate chinese JuR2_We_step2_c396bf41:

    # MC "You sure you don’t want me to pound your pussy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:561
translate chinese JuR2_We_step2_7e70cc66:

    # Judy "Whether or not I want you to is *hic* out of the question if you don’t have a condom."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:563
translate chinese JuR2_We_step2_ed2f7218:

    # MC "Alright then, anal it is!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:564
translate chinese JuR2_We_step2_d93c674e:

    # Judy "Phew..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:565
translate chinese JuR2_We_step2_f74295c2:

    # Judy "(That was WAY too close! I really need to cut back on my drinking. I’m starting to lose my inhibitions, here!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:567
translate chinese JuR2_We_step2_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:569
translate chinese JuR2_We_step2_4a02fefd_2:

    # Judy "*Gasp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:574
translate chinese JuR2_We_step2_77d133db:

    # Judy "Oh! Ah..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:576
translate chinese JuR2_We_step2_6e9379b2:

    # MC "You okay?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:577
translate chinese JuR2_We_step2_af618683:

    # Judy "Ahh... yeah... That’s ah... so good!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:578
translate chinese JuR2_We_step2_1a2c9255:

    # MC "I bet you’re imagining that I’m in your pussy right now, instead of your ass, aren’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:579
translate chinese JuR2_We_step2_e811ddb5:

    # Judy "*Pant* N-No!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:581
translate chinese JuR2_We_step2_10356845:

    # MC "You’re thinking of my dick plunging, deep inside your wet hole, thrusting right up to your cervix."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:582
translate chinese JuR2_We_step2_fabd9b48:

    # Judy "Ah! Ahhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:583
translate chinese JuR2_We_step2_81edd77c:

    # Judy "(He’s really turning me on with this dirty talk!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:585
translate chinese JuR2_We_step2_e18d7cc1:

    # Judy "OOOHHHHH! God! Yesssss!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:587
translate chinese JuR2_We_step2_2a7f2f3a:

    # MC "Ugh! Hnngg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:589
translate chinese JuR2_We_step2_1c2900a3:

    # MC "(Her asshole is so tight! It feels like she’s gripping onto my cock, each time I thrust!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:591
translate chinese JuR2_We_step2_3698d5ce:

    # MC "*Pant* Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:593
translate chinese JuR2_We_step2_2eb6c6f6:

    # MC "Just imagine how it would feel if I emptied my balls, deep in your pussy."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:595
translate chinese JuR2_We_step2_73617229:

    # Judy "*Gasp* *Pant*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:596
translate chinese JuR2_We_step2_aeac6f3f:

    # MC "All that hot cum flowing inside you."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:598
translate chinese JuR2_We_step2_5f8d3bb7:

    # Judy "St-Stop *Pant* tempting me! Ah! Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:600
translate chinese JuR2_We_step2_f223d565:

    # MC "I could pull out of your ass right now, and just thrust it into your pussy instead. Imagine how good it would feel to have my dick, thrusting in and out of your wet-"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:602
translate chinese JuR2_We_step2_ed57c077:

    # Judy "Ahhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:604
translate chinese JuR2_We_step2_401fbc8e:

    # Judy "*Pant* Fuck! Ohh God! Yes!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:605
translate chinese JuR2_We_step2_e52d3b32:

    # MC "Yes? You want me to fuck your pussy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:606
translate chinese JuR2_We_step2_82677154:

    # Judy "Y-Yes, I- I-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:608
translate chinese JuR2_We_step2_c2f1d104:

    # Judy "N-No, wait! *Pant* Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:609
translate chinese JuR2_We_step2_16cb1066:

    # Judy "God, you’re dangerous! Haha! Stop trying to *Hic* tempt me like that!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:610
translate chinese JuR2_We_step2_224c8e96:

    # Judy "Right, we’re switching things up. Lie back on the table, I’m gonna climb on top so I have some more control of where you’re putting that dick!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:611
translate chinese JuR2_We_step2_742ad3e9:

    # MC "Haha, no problem!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:613
translate chinese JuR2_We_step2_c28ab945:

    # MC "Mmm! God, you’re so fucking hot!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:614
translate chinese JuR2_We_step2_2a763ba4:

    # Judy "Mmm! Ah! Ohhh! Oh! Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:615
translate chinese JuR2_We_step2_8f96814f:

    # Judy "How does my ass feel?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:617
translate chinese JuR2_We_step2_04d1b5d0:

    # MC "Hnnng... So fucking tight!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:618
translate chinese JuR2_We_step2_02db4929:

    # Judy "AH! Ah! Oh! Ahh! Yes! I’m gonna ride your dick until you cum!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:619
translate chinese JuR2_We_step2_2260a15a:

    # MC "Ahhh! Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:621
translate chinese JuR2_We_step2_a5c52702:

    # MC "(God! Her body is incredible! How did she get so athletic?!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:622
translate chinese JuR2_We_step2_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:623
translate chinese JuR2_We_step2_b76b8939:

    # Judy "Oh! Yes! OHHH!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:625
translate chinese JuR2_We_step2_7113a733:

    # MC "Are you sure you don’t want me to put it in your pussy? You could ride me while you’re on top like this."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:626
translate chinese JuR2_We_step2_641aa818:

    # Judy "Ah! Mmm... N-No, it’s not worth the risk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:627
translate chinese JuR2_We_step2_d4739a4b:

    # MC "Aw, c’mon Judy, you’ll enjoy it! You can hop off whenever you want!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:629
translate chinese JuR2_We_step2_de3c6384:

    # Judy "Ah! Ahh... No, if you cum without giving me *hic* a warning, then I might not be able to get off in time!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:630
translate chinese JuR2_We_step2_c128c534:

    # Judy "Ohh! Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:631
translate chinese JuR2_We_step2_238866c1:

    # MC "(Looks like there’s no convincing Judy to have sex. I really should have brought some damn condoms with me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:633
translate chinese JuR2_We_step2_138c1f4c:

    # Judy "AH! AHH! Yes!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:635
translate chinese JuR2_We_step2_19e74466:

    # MC "Hnnng! Ugh! Fuck!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:637
translate chinese JuR2_We_step2_3069a74a:

    # MC "I’m getting *Pant* close, Judy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:639
translate chinese JuR2_We_step2_492f150e:

    # Judy "Yes! Cum inside me! Ah! Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:640
translate chinese JuR2_We_step2_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:642
translate chinese JuR2_We_step2_68e60c37:

    # Judy "Ayaaahhhh! I’m cummmmiiinnng!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:643
translate chinese JuR2_We_step2_f15f85a0:

    # MC "HNNNG! Fuck! Ugh! I’m gonna cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:645
translate chinese JuR2_We_step2_bd35d64b:

    # Judy "*Pant* Yes! Fill my pussy with your cum! Ah! I- I mean my ass! Fill my ass!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:647
translate chinese JuR2_We_step2_06e890fe:

    # MC "(She keeps almost giving into her desires! I don’t think she’s going to need much more convincing.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:648
translate chinese JuR2_We_step2_7b1d55ef:

    # MC "Hnnnnng!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:650
translate chinese JuR2_We_step2_39da96e9:

    # MC "Fuck! I’m cumming!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:651
translate chinese JuR2_We_step2_d0580f9a:

    # MC "Arrrghhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:652
translate chinese JuR2_We_step2_926addc5:

    # Judy "Ah! Ah! AHHHHH!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:662
translate chinese JuR2_We_step2_8456474c:

    # MC "Hnnng! Aarrghhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:663
translate chinese JuR2_We_step2_50201a9d:

    # Judy "Ooooh God! Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:664
translate chinese JuR2_We_step2_bc11a476:

    # Judy "(Oh wow! I can feel his hot cum, rushing deep inside me... God, I wish I could feel that in my- No! You’re getting distracted by your impregnation fetish again! Pull yourself together, Judy!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:665
translate chinese JuR2_We_step2_1b8d1166:

    # MC "*Pant* *Pant* Wow..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:667
translate chinese JuR2_We_step2_b1cdbbf0:

    # Judy "Well, did you enjoy round two?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:668
translate chinese JuR2_We_step2_73fa4008:

    # MC "*Pant* It was fucking amazing!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:669
translate chinese JuR2_We_step2_03433ae8:

    # Judy "Well, I hope you have enough energy left for another couple of rounds, because I’m not done playing yet!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:670
translate chinese JuR2_We_step2_0d1c119d:

    # Judy "Close your eyes and count to thirty, I’m going to get dressed and find another hiding location."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:672
translate chinese JuR2_We_step2_1b87ed45:

    # MC "*Sigh* One, two, three..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:674
translate chinese JuR2_We_step2_72dcd835:

    # Judy "(Okay... where did I leave the wine? Ah! There it is!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:676
translate chinese JuR2_We_step2_97da542f:

    # MC "Seven, eight, nine..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:677
translate chinese JuR2_We_step2_17b54fbb:

    # Judy "You’re *hic* counting way too fast! Slow down a bit! Give me a chance!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:678
translate chinese JuR2_We_step2_646f9e1d:

    # MC "Haha! Nine... Ten... Eleven!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:680
translate chinese JuR2_We_step2_e24259cf:

    # MC "(I love the underwear she chose for this weekend. She looks absolutely stunning!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:681
translate chinese JuR2_We_step2_cc6f0a4f:

    # MC "(I wonder if she’ll eventually let me fuck her pussy without a condom on. She was clearly contemplating letting me do it earlier!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:701
translate chinese JuR2_We_step3_e66eab73:

    # Judy "You REALLY know how to *Hic* keep a girl waiting, don’t you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:702
translate chinese JuR2_We_step3_ea0bf929:

    # MC "Oh c’mon, it didn’t take me that long to find you!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:703
translate chinese JuR2_We_step3_249a6ede:

    # Judy "Hehe! Alright, get over here and I’ll give you your *hic* reward for finding me again."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:704
translate chinese JuR2_We_step3_09093e3c:

    # MC "Are you going to let me fuck your pussy this time?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:705
translate chinese JuR2_We_step3_98ae8060:

    # Judy "Hah! You should have brought a condom if you wanted to do that again. However, I am feeling *hic* generous tonight, so I’ll let you choose what we do next."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:711
translate chinese JuR2_We_step3_9e3c6062:

    # MC "Well, in that case, I think I’d like to see you stay there on your knees."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:712
translate chinese JuR2_We_step3_8e7a8d2e:

    # Judy "Yeah? And what would you like me to do while I’m down here?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:713
translate chinese JuR2_We_step3_be66c346:

    # MC "You’re a smart woman, Judy. Use your imagination."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:716
translate chinese JuR2_We_step3_8b3caba7:

    # Judy "My imagination? *Hic* Let’s see what I can *Hic come up with!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:718
translate chinese JuR2_We_step3_d8519dfb:

    # MC "(She’s been drinking her wine pretty quickly. Each time I find her she’s getting more and more tipsy!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:720
translate chinese JuR2_We_step3_01b916f1:

    # MC "(I wonder if her inhibitions will keep slipping as this little game goes on?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:724
translate chinese JuR2_We_step3_76ed2ce2:

    # Judy "Wow..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:726
translate chinese JuR2_We_step3_8152cfdf:

    # Judy "(I can’t believe he’s hard again so quickly! He only just came in my ass a few minutes ago! [player_name] REALLY has some stamina!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:728
translate chinese JuR2_We_step3_b2ca6d82:

    # MC "You sound impressed!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:732
translate chinese JuR2_We_step3_08c794fa:

    # Judy "Jussht can’t believe you’re *Hic* sthill hard!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:734
translate chinese JuR2_We_step3_bb7aef91:

    # MC "It sounds like someone is getting a little bit drunk."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:736
translate chinese JuR2_We_step3_699b5e50:

    # Judy "I am *hic* not! Now, hurry up and take your clothes off, so I can get started."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:740
translate chinese JuR2_We_step3_2c7b50b5:

    # Judy "Okay, so here’s what we’re going to do. I’m going to start shucking- *Ahem* sucking your cock. And then *Hic* when you feel like you’re about to cum, I want you to grab on to the back of my head and pull it down onto your shaft."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:742
translate chinese JuR2_We_step3_40e0f672:

    # MC "You sure about that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:744
translate chinese JuR2_We_step3_7fdfaf0d:

    # Judy "Absholutely... shlutely... Absh-so-lutely."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:748
translate chinese JuR2_We_step3_326805ae:

    # MC "You are drunk."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:750
translate chinese JuR2_We_step3_57367967:

    # Judy "You’re *Hic the one who’s drunk. I’m Judy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:752
translate chinese JuR2_We_step3_cc335982:

    # MC "Uh huh, sure."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:756
translate chinese JuR2_We_step3_b69cdeec:

    # Judy "It’s soooo much bigger than earlier. How did you make it grow *Hic* so big?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:758
translate chinese JuR2_We_step3_61fcb225:

    # MC "It’s the same-"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:760
translate chinese JuR2_We_step3_ddec82bc:

    # Judy "*Gasp* What if it only SEEMS bigger when it’s going in my mouth instead of my ass?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:764
translate chinese JuR2_We_step3_bc8b5ee4:

    # MC "(It’s kinda funny seeing Judy not in control of things. She’s really let her guard down since she finally published her book.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:766
translate chinese JuR2_We_step3_3ad6b463:

    # MC "(Or perhaps its because she doesn’t need to manipulate me or my mom anymore, now that we all know what she was actually up to.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:768
translate chinese JuR2_We_step3_c65e6d34:

    # MC "(Or perhaps its because she doesn’t need to manipulate me or Linda anymore, now that we all know what she was actually up to.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:770
translate chinese JuR2_We_step3_49704fae:

    # MC "(Either way, she seems happy. And I’m about to get my dick sucked, so everyone wins!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:774
translate chinese JuR2_We_step3_089997f6:

    # Judy "*Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:776
translate chinese JuR2_We_step3_61596a2b:

    # MC "Mmm... Ah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:778
translate chinese JuR2_We_step3_089997f6_1:

    # Judy "*Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:782
translate chinese JuR2_We_step3_211bba36:

    # MC "(I hope she genuinely wants me to pull her head down on my cock, and it isn’t just the alcohol talking!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:784
translate chinese JuR2_We_step3_a5efde1c:

    # MC "(She seemed enthusiastic about the idea when she suggested it.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:786
translate chinese JuR2_We_step3_089997f6_2:

    # Judy "*Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:790
translate chinese JuR2_We_step3_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:792
translate chinese JuR2_We_step3_d193fe95:

    # Judy "*Lick* *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:794
translate chinese JuR2_We_step3_21ed4a11:

    # MC "Mmm, fuck, your tongue feels so good!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:798
translate chinese JuR2_We_step3_6c6d3d63:

    # Judy "*Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:800
translate chinese JuR2_We_step3_b43232ec:

    # MC "Oooh... God... That’s incredible, Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:802
translate chinese JuR2_We_step3_6e7519fd:

    # Judy "*Shlurp* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:806
translate chinese JuR2_We_step3_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:809
translate chinese JuR2_We_step3_61523ed2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:811
translate chinese JuR2_We_step3_8d938f04:

    # MC "Hnnng... Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:815
translate chinese JuR2_We_step3_60be8fcb:

    # MC "(She’s even better at giving head when she’s drunk!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:817
translate chinese JuR2_We_step3_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:819
translate chinese JuR2_We_step3_6c6d3d63_1:

    # Judy "*Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:823
translate chinese JuR2_We_step3_07fffcea:

    # Judy "*Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:825
translate chinese JuR2_We_step3_47d9a327:

    # MC "*Pant* Mmm! Keep sucking, Judy! Ah... Just like that."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:826
translate chinese JuR2_We_step3_ecfff93b:

    # Judy "*Suck* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:830
translate chinese JuR2_We_step3_db38c76d:

    # MC "(I wonder how many more rounds Judy wants to play hide and seek for? I don’t know how much longer I’ll be able to sustain another erection if she keeps making me cum!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:832
translate chinese JuR2_We_step3_61523ed2_1:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:834
translate chinese JuR2_We_step3_64b4e65b:

    # MC "Mmm! God..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:838
translate chinese JuR2_We_step3_ba6e33ac:

    # Judy "*Gulp* *SHLUURRRP*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:840
translate chinese JuR2_We_step3_00c787e3:

    # MC "Ah! That’s amazing, Judy. Don’t stop!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:842
translate chinese JuR2_We_step3_dee582b5:

    # Judy "*SUCK* *SUCK*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:846
translate chinese JuR2_We_step3_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:848
translate chinese JuR2_We_step3_50e61242:

    # MC "(I’m going to cum soon. Time to pull Judy’s head onto my cock, and see if she actually likes getting her throat fucked!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:850
translate chinese JuR2_We_step3_ecfff93b_1:

    # Judy "*Suck* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:854
translate chinese JuR2_We_step3_eda9fb75:

    # MC "Aarrrghhh! I’m gonna cum soon!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:856
translate chinese JuR2_We_step3_6c6d3d63_2:

    # Judy "*Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:858
translate chinese JuR2_We_step3_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:862
translate chinese JuR2_We_step3_1beef168:

    # MC "*Pant* Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:864
translate chinese JuR2_We_step3_c1394d37:

    # Judy "Mmpfff! *Gag* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:866
translate chinese JuR2_We_step3_eaa0bad2:

    # MC "(Fuck it, let’s see what happens!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:870
translate chinese JuR2_We_step3_e5c0911e:

    # Judy "MPFFFF!!! *GAG* MMPFFFFF!!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:872
translate chinese JuR2_We_step3_8fc6a12e:

    # MC "Ugh! Aaahhhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:874
translate chinese JuR2_We_step3_c9d3b9a4:

    # MC "(God, I can feel her throat vibrating around my cock as she screams! Holy shit, it’s so intense!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:878
translate chinese JuR2_We_step3_28c948df:

    # MC "Uggghhh! I’m cumming! *Pant*"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:882
translate chinese JuR2_We_step3_de4716f8:

    # Judy "*Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:884
translate chinese JuR2_We_step3_2759f53b:

    # Judy "([player_name]’s cock is twitching in the back of my throat! I can feel his cum hitting the back of my mouth!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:888
translate chinese JuR2_We_step3_0408e694:

    # Judy "*Shluurrrp* *Gag* *Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:890
translate chinese JuR2_We_step3_e0da8e8b:

    # MC "Mmm! That’s it! Swallow it all! Drink every last drop! Hnnng!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:901
translate chinese JuR2_We_step3_7bc82850:

    # Judy "*GASP* *Cough* *Cough* *Pant*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:903
translate chinese JuR2_We_step3_61fdf7f2:

    # MC "Oh shit, sorry, was I too rough?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:905
translate chinese JuR2_We_step3_e56c1f87:

    # Judy "N-No, *Pant* that was *Cough* exactly what I told you to do."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:907
translate chinese JuR2_We_step3_a84073a4:

    # MC "You actually enjoyed it?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:909
translate chinese JuR2_We_step3_53db459e:

    # Judy "Eh, it was alright. Something different to do when I’m a bit *Hic* drunk, but I wouldn’t do it all the time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:911
translate chinese JuR2_We_step3_4ac51375:

    # MC "Sounds like you’re beginning to sober up a bit anyway."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:915
translate chinese JuR2_We_step3_3636c935:

    # Judy "I know, it’s TERRIBLE! I’m sure I brought a third bottle with me... Wonder where I *Hic* left it lying."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:917
translate chinese JuR2_We_step3_fbc19abb:

    # MC "Are you sure you should still be drinking? I don’t want you doing something you’ll regret when-"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:919
translate chinese JuR2_We_step3_619b68b7:

    # Judy "I’ll be fine! You’re worrying too much, just try and relax. We’re supposed to be celebrating my book launch!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:923
translate chinese JuR2_We_step3_e1fa5c56:

    # Judy "Now close your eyes and count to thirty... I’m going to *Hic* find another place to hide."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:925
translate chinese JuR2_We_step3_2011ccc2:

    # MC "One... Two..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:929
translate chinese JuR2_We_step3_e7b50ca2:

    # Judy "(Hmm... If I go out that way, I can grab my final bottle of wine on the way to my hiding spot. Yeah! That’ll work perfectly!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:931
translate chinese JuR2_We_step3_c1bffd89:

    # MC "Three... Four... Five..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:935
translate chinese JuR2_We_step3_0b23e61a:

    # MC "Six... Seven... Eight..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:937
translate chinese JuR2_We_step3_37921d16:

    # MC "(I hope she isn’t too drunk by the next time I find her...)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:960
translate chinese JuR2_We_step4_e3395bee:

    # Judy "You *hic* finally made it! What took you sho long?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:962
translate chinese JuR2_We_step4_30cfeafd:

    # MC "It wasn’t that long!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:964
translate chinese JuR2_We_step4_65a5d37f:

    # Judy "It wash long enough for another *hic* couple of glasshes of *hic wine."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:971
translate chinese JuR2_We_step4_ed378d56:

    # Judy "Help yourshelf, by the way. I’ve poured *hic* you one too."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:973
translate chinese JuR2_We_step4_96cd6045:

    # MC "Cheers Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:977
translate chinese JuR2_We_step4_92f70b19:

    # Judy "I think... I think thish ish going to be *hic* the last round of hide and sheek for the night. I’m shtarting to feel very *yawn* shleepy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:979
translate chinese JuR2_We_step4_212cc099:

    # MC "You’re starting to get very drunk too. I’m surprised"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:983
translate chinese JuR2_We_step4_86be1d92:

    # Judy "Hehe... *hic* perhaps."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:985
translate chinese JuR2_We_step4_b5682f50:

    # MC "(Her cheeks are scarlet right now!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:989
translate chinese JuR2_We_step4_a6d129a2:

    # Judy "Whatdya *hic* shay. How about we make one *hic* final toast to the great work you and I did tog- *hic* together?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:991
translate chinese JuR2_We_step4_66c0595e:

    # MC "Sure!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:995
translate chinese JuR2_We_step4_a50a6a11:

    # Judy "Here’s to the completion of my *hic* magnum opush! And to Linda for being such a willing partichipant in *hic* my research!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:997
translate chinese JuR2_We_step4_6e1f4446:

    # Judy "And to you, for all the usehful material that you gave me during our therapy shesshions. Thank you, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1001
translate chinese JuR2_We_step4_c0c688e0:

    # MC "And thank you, Judy. You really bailed me out after everything went to shit with Ms. Celia. I don’t know where I’d be right now if it wasn’t for your help."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1003
translate chinese JuR2_We_step4_44fca587:

    # Judy "You’re very *hic* welcome, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1007
translate chinese JuR2_We_step4_e1c8d451:

    # Judy "*Glug*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1009
translate chinese JuR2_We_step4_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1013
translate chinese JuR2_We_step4_fbe36eb5:

    # Judy "Ah... Well, that was the *hic* last bottle. I think it’s time that we finish thingsh off for the night."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1015
translate chinese JuR2_We_step4_63d71c5e:

    # MC "What did you have in mind?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1019
translate chinese JuR2_We_step4_2d78763c:

    # Judy "Well, I was thinking about you forgetting to bring condomsh and, perhaps, I was being *hic* a little too... uptight about that rule."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1021
translate chinese JuR2_We_step4_b202d5b8:

    # MC "Are you suggesting I can fuck your pussy tonight? Do you actually want this, or is this just the alcohol talking?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1025
translate chinese JuR2_We_step4_003af7c8:

    # Judy "Who knows?! Probably a bit of *hic* both. Jusht try and make shure that you don’t cum inshide me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1027
translate chinese JuR2_We_step4_62a6f55e:

    # MC "Don’t worry, I’ll remember to pull out."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1031
translate chinese JuR2_We_step4_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1033
translate chinese JuR2_We_step4_918fa984:

    # MC "(Alright! Time to show Judy how good my dick feels without a condom on! I’m going to blow her mind tonight!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1037
translate chinese JuR2_We_step4_36c7c5f1:

    # MC "(God, she’s so sexy. I can’t wait to fuck her senseless.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1039
translate chinese JuR2_We_step4_c3f30712:

    # Judy "I jusht need to take my bra *hic* off."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1043
translate chinese JuR2_We_step4_a7b8fb23:

    # MC "Let me give you a hand getting undressed. You won’t be needing these anymore."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1045
translate chinese JuR2_We_step4_a03d70c7:

    # Judy "Hehe! Someone’s *hic* excited!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1047
translate chinese JuR2_We_step4_50ab4399:

    # MC "Alright, spread your legs for me, I want to get a good look at your pussy before I fuck you."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1051
translate chinese JuR2_We_step4_6651fcf0:

    # Judy "How’sh this?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1053
translate chinese JuR2_We_step4_66f8ab9b:

    # MC "You look perfect. Are you definitely sure you want me to go without a condom?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1055
translate chinese JuR2_We_step4_bcd62cfe:

    # Judy "Yes! Just hurry up before I come to my shenses and change my *hic* mind! Hehe!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1059
translate chinese JuR2_We_step4_3c36c304:

    # MC "Alright! If you insist!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1061
translate chinese JuR2_We_step4_9ce6a58d:

    # Judy "(Oh my God! It’s actually happening! I’m going to let a guy fuck me without a condom on! It felt so good last time when Linda and I had that threesome. Mmm, I can’t wait to feel his bare dick inside me again!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1063
translate chinese JuR2_We_step4_2a4b409d:

    # Judy "Jusht remember to pull out, okay?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1067
translate chinese JuR2_We_step4_127dfbba:

    # MC "Of course I will."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1069
translate chinese JuR2_We_step4_b614cf22:

    # MC "I wouldn’t want to fill you up with my hot cum and get you pregnant now, would I?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1073
translate chinese JuR2_We_step4_de4716f8:

    # Judy "*Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1075
translate chinese JuR2_We_step4_6c17fcc6:

    # MC "I mean, it would be pretty bad if I emptied my balls, deep inside your wet cunt, wouldn’t it?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1079
translate chinese JuR2_We_step4_afc05dd9:

    # MC "Are you even on birth control?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1081
translate chinese JuR2_We_step4_bf1f822f:

    # Judy "N-No. The condoms WERE the *hic* birth control. So you can’t cum inside me, or I’ll-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1083
translate chinese JuR2_We_step4_b561f31b:

    # Judy "*GASP*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1087
translate chinese JuR2_We_step4_d0b6665c:

    # Judy "Ooohhh!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1089
translate chinese JuR2_We_step4_49bfffd6:

    # MC "Sorry, you were so wet that it just slipped right in. What were you saying, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1091
translate chinese JuR2_We_step4_921615ee:

    # Judy "(Oh my God! His bare cock feels soooo much better than with a condom!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1095
translate chinese JuR2_We_step4_4d615522:

    # Judy "Y-You *Pant* won’t cum inshide me, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1097
translate chinese JuR2_We_step4_f36f8f07:

    # MC "I promise, I won’t cum inside you unless you want me to."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1098
translate chinese JuR2_We_step4_362c0d31:

    # Judy "*Pant* Ah! Ohhhh..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1102
translate chinese JuR2_We_step4_4e041b3f:

    # MC "You’re REALLY wet, Judy. If I didn’t know better, I’d think you had a fetish for having unprotected sex."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1104
translate chinese JuR2_We_step4_362502b3:

    # Judy "N-No! *Gulp* I- Ah... I don’t!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1106
translate chinese JuR2_We_step4_ece6c8a7:

    # MC "Really? In all the time I’ve known you, you’ve ALWAYS wanted to be the one in control. The one pulling the strings. The puppetmaster."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1108
translate chinese JuR2_We_step4_76ee6c93:

    # Judy "Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1110
translate chinese JuR2_We_step4_b68eebcc:

    # MC "Right now though, you’re completely vulnerable and your pussy is soaking wet."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1112
translate chinese JuR2_We_step4_db49fc64:

    # MC "I was anxious to start a relationship with Linda because I was worried about how taboo it was. I think you’ve got your own secret taboo you never told me about."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1116
translate chinese JuR2_We_step4_019d79f1:

    # Judy "OOOHHH!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1118
translate chinese JuR2_We_step4_7e0eadb1:

    # MC "I think you LOVE the idea of being fucked without a condom. I think you adore the sensation of not being in control for once."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1120
translate chinese JuR2_We_step4_c6dd2f52:

    # Judy "Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1122
translate chinese JuR2_We_step4_d4194fb8:

    # MC "I think you relish the taboo thought that I might flood your womb with my hot cum, instead of pulling out."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1126
translate chinese JuR2_We_step4_7558d5f1:

    # Judy "N-No! Ohhhhh! N-Hnnnggg! Aaahh! I’m cummmmmmiiinng!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1128
translate chinese JuR2_We_step4_2137e599:

    # MC "I can feel your pussy clamping down around my dick, every time you cum. If you keep this up, I’m going to end accidentally giving you a creampie."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1130
translate chinese JuR2_We_step4_7e77c7d7:

    # Judy "Hnnngg.... Nnnnnnnn!! Aaahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1134
translate chinese JuR2_We_step4_f0cb7601:

    # MC "You’re cumming pretty hard, for someone who doesn’t want to be impregnated."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1136
translate chinese JuR2_We_step4_d4a22e4d:

    # Judy "I *Gasp* d-don’t want- Haaah! Y-You have to- Ohh! P-Pull out before you ahh... cum!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1138
translate chinese JuR2_We_step4_1c3d4e10:

    # Judy "(Crap! All this talk about him cumming inside me is really turning me on! I shouldn’t have drank so much!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1142
translate chinese JuR2_We_step4_1f04e166:

    # MC "How about we switch up to doggy-style?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1144
translate chinese JuR2_We_step4_ca4f7b76:

    # Judy "*Pant* Y-Yeah... *Pant*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1148
translate chinese JuR2_We_step4_ecef98dd:

    # Judy "Ohh! Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1150
translate chinese JuR2_We_step4_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1152
translate chinese JuR2_We_step4_3ab582d5:

    # MC "(Her pussy feels fucking amazing!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1156
translate chinese JuR2_We_step4_d1c74b3c:

    # Judy "Ah! Ah! Ah! Ooohhh!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1158
translate chinese JuR2_We_step4_f8bdad8a:

    # MC "How does it feel finally being fucked by a raw cock? You love it, don’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1160
translate chinese JuR2_We_step4_4b0f3d2a:

    # Judy "Ahh! *GASP* Haaaahhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1162
translate chinese JuR2_We_step4_7b730039:

    # MC "Tell me you love it."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1166
translate chinese JuR2_We_step4_927c3fd6:

    # Judy " I- Mmm... love being ahhh... fucked by your raw *hic* cock! It feelsh shooo gooooooddd!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1168
translate chinese JuR2_We_step4_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1170
translate chinese JuR2_We_step4_1f444b9f:

    # Judy "Ayaaahhhh! I’m cumming!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1174
translate chinese JuR2_We_step4_74fee4ef:

    # MC "That’s it! Cum for me!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1176
translate chinese JuR2_We_step4_a66bf435:

    # Judy "Aaayaaaahhhhhhhhh!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1180
translate chinese JuR2_We_step4_3ae9071d:

    # Judy "*Pant* *Pant* Ah! Ahhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1182
translate chinese JuR2_We_step4_7aabdef5:

    # MC "You love being pounded from behind like this, don’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1184
translate chinese JuR2_We_step4_d1c74b3c_1:

    # Judy "Ah! Ah! Ah! Ooohhh!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1186
translate chinese JuR2_We_step4_3b31db23:

    # Judy "Yeessssssss! Aaahhhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1188
translate chinese JuR2_We_step4_f4ba2226:

    # Judy "Ahhh! Haaahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1190
translate chinese JuR2_We_step4_a66bf435_1:

    # Judy "Aaayaaaahhhhhhhhh!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1193
translate chinese JuR2_We_step4_22734ff0:

    # MC "Okay, I’m going to fuck you while you’re standing up, next. Turn around."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1195
translate chinese JuR2_We_step4_de550f4e:

    # Judy "*Pant* O-Okay..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1199
translate chinese JuR2_We_step4_ef74bf78:

    # MC "Mmm, there we go."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1201
translate chinese JuR2_We_step4_019c2853:

    # Judy "*Pant* Y-You’re not gonna cum inshide me, right? Don’t *hic* forget that you’re not wearing a condom."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1203
translate chinese JuR2_We_step4_2f1e4a1b:

    # MC "If you don’t want to take the risk, I can always just fuck you in another hole instead?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1205
translate chinese JuR2_We_step4_61d7d4d7:

    # Judy "*Gulp* N-No, my pusshy ish fine..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1209
translate chinese JuR2_We_step4_5d63cde5:

    # MC "If you insist."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1211
translate chinese JuR2_We_step4_f4ba2226_1:

    # Judy "Ahhh! Haaahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1213
translate chinese JuR2_We_step4_27dcbd61:

    # Judy "(I shouldn’t be screwing him without a condom! Why am I throwing caution to the wind like this?!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1217
translate chinese JuR2_We_step4_ba7788ae:

    # Judy "(It doesn’t matter how good it feels. You need to pull yourself together, Judy!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1219
translate chinese JuR2_We_step4_8d83b48d:

    # Judy "I..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1221
translate chinese JuR2_We_step4_638e79d5:

    # Judy "(You need to tell him to use your ass instead.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1225
translate chinese JuR2_We_step4_07843f5b:

    # Judy "I... Ah... K-Keep fucking meeee! Harder!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1226
translate chinese JuR2_We_step4_c1105292:

    # MC "Ugghh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1228
translate chinese JuR2_We_step4_11059a88:

    # Judy "OOHHHH!!! Yesss! Right there!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1232
translate chinese JuR2_We_step4_b40a6f49:

    # Judy "*Pant* It feels shooo gooood! Aaahhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1234
translate chinese JuR2_We_step4_c40b0cf2:

    # MC "It would feel even better if I finished inside you, wouldn’t it, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1236
translate chinese JuR2_We_step4_9d330456:

    # Judy "Haah... N-No!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1240
translate chinese JuR2_We_step4_6b7ed4fe:

    # MC "Are you sure? Imagine my hot cum, rushing deep into your body."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1242
translate chinese JuR2_We_step4_cf6d36c2:

    # Judy "Ahhnnnngg...."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1244
translate chinese JuR2_We_step4_3cd909c0:

    # MC "Imagine the feeling, knowing that my semen might be impregating you tonight."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1248
translate chinese JuR2_We_step4_a2de4073:

    # Judy "Ahhhh! I’m cummmiinnngg!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1250
translate chinese JuR2_We_step4_1cfabead:

    # MC "You want me to finish inside you, don’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1252
translate chinese JuR2_We_step4_3afcffe4:

    # Judy "I... M-Maybe, I- Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1256
translate chinese JuR2_We_step4_5c4f691d:

    # MC "I’m about to cum. Last chance, Judy. Tell me where you want me to finish."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1258
translate chinese JuR2_We_step4_41b80f0d:

    # Judy "(Keep it together, Judy! Don’t give into your drunken horniness! ...no matter how tempting it may be.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1260
translate chinese JuR2_We_step4_d3e0912e:

    # Judy "I... Ah! I... *Pant*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1262
translate chinese JuR2_We_step4_8d83b48d_1:

    # Judy "I..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1267
translate chinese JuR2_We_step4_ac4eed9e:

    # Judy "I... want you to cum inshide me! Please! *Hic* Fill me up!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1269
translate chinese JuR2_We_step4_d94118a4:

    # MC "As you command."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1273
translate chinese JuR2_We_step4_4eba5139:

    # Judy "(Oh my God! I can’t believe I actually said that! What am I thinking?!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1275
translate chinese JuR2_We_step4_0109f199:

    # MC "Hnnnnnnggg! I hope your pussy is ready, Judy. I’m about to give you your first ever creampie."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1277
translate chinese JuR2_We_step4_8a4d486a:

    # Judy "Ooohhh!! Fuuuuck! I’m cummmmmmmiiiinngg! AAAAHHHHH!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1288
translate chinese JuR2_We_step4_da218ca8:

    # MC "Arrrghhh!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1290
translate chinese JuR2_We_step4_efbbc276:

    # Judy "AAAHHHH!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1292
translate chinese JuR2_We_step4_42159bff:

    # Judy "(Holy crap! I can feel his cock pulsating inside me! Oh God! It’s so hot! His cum is filling me up!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1296
translate chinese JuR2_We_step4_1b9d71da:

    # MC "Mmm... Fuck, that was good!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1298
translate chinese JuR2_We_step4_f0f8307f:

    # Judy "*Pant*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1300
translate chinese JuR2_We_step4_63b8306e:

    # Judy "(I can feel his semen dripping out of me. There’s so much!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1306
translate chinese JuR2_We_step4_b0b7e6f9:

    # Judy "W-Wait, you gotta pull out! You can *Hic* cum on my asshh, jusht not inshide!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1308
translate chinese JuR2_We_step4_3e90a376:

    # MC "Okay, okay."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1312
translate chinese JuR2_We_step4_5ddd7f61:

    # MC "Hnnnggg..."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1314
translate chinese JuR2_We_step4_2d23702d:

    # Judy "Cum for me! That’sh it! *Hic* Cum all over my butt!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1325
translate chinese JuR2_We_step4_0e285ae4:

    # MC "Hnnnggg! Aarrghhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1327
translate chinese JuR2_We_step4_63745932:

    # Judy "Ooohh..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1331
translate chinese JuR2_We_step4_c9a65c62:

    # MC "*Pant* Fuck... That was amazing."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1333
translate chinese JuR2_We_step4_3f51be72:

    # Judy "(That was way too close... I was sooo tempted to just let him finish inside me. That could have ended VERY badly for me...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1335
translate chinese JuR2_We_step4_73e97bae:

    # Judy "..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1337
translate chinese JuR2_We_step4_411a411d:

    # Judy "(It would’ve been sooo hot though...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1343
translate chinese JuR2_We_step4_con1_244903b7:

    # MC "Well? How was it?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1345
translate chinese JuR2_We_step4_con1_da241f5e:

    # Judy "*Pant* Incredible! I’m still trying to *Hic* catch my breath."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1347
translate chinese JuR2_We_step4_con1_a5eaaf6f:

    # MC "Are you planning to head home now? Or are you staying until-"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1355
translate chinese JuR2_We_step4_con1_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1356
translate chinese JuR2_We_step4_con1_64301acb:

    # MC "Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1358
translate chinese JuR2_We_step4_con1_ececdede:

    # Judy "*Snore*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1360
translate chinese JuR2_We_step4_con1_57cc8eab:

    # MC "(She’s passed out now. She DEFINITELY had way too much to drink.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1361
translate chinese JuR2_We_step4_con1_1f6b6ad2:

    # MC "(I can explore the college and see if I can find something interesting, then come back here later.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1376
translate chinese JuR2_We_step4_con1_a91012a8:

    # MC "(Let's look around the college.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1395
translate chinese JuR2_We_step5_32931780:

    # MC "(Let’s see what Judy keeps in her desk drawer...)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1399
translate chinese JuR2_We_step5_32c9b729:

    # MC "(“Harem? - Not a Problem!”)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1403
translate chinese JuR2_We_step5_1ed2f738:

    # MC "(Huh? Is this the first draft of another book Judy is working on?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1407
translate chinese JuR2_We_step5_c5aff079:

    # MC "(She’s probably looking for someone else to run another social experiment on, so she can finish her research.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1411
translate chinese JuR2_We_step5_527a2ea5:

    # MC "(I genuinely didn’t expect things to end this way with Judy. I always kinda figured she’d just be pulling the strings - didn’t think I’d actually ever get to fuck her as well.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1425
translate chinese JuR2_We_step5_con1_a91012a8:

    # MC "(Let's look around the college.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1442
translate chinese JuR2_We_step5_con1_64301acb:

    # MC "Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1444
translate chinese JuR2_We_step5_con1_ececdede:

    # Judy "*Snore*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1448
translate chinese JuR2_We_step5_con1_0312547e:

    # MC "(What am I supposed to do now? I can’t just leave her lying here, or the Dean will find her in the morning.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1450
translate chinese JuR2_We_step5_con1_558f0af0:

    # MC "(He’d probably end up firing her... or worse.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1452
translate chinese JuR2_We_step5_con1_ececdede_1:

    # Judy "*Snore*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1456
translate chinese JuR2_We_step5_con1_1d3f5d03:

    # MC "Yeah, I’m gonna have to make sure you get home safe, aren’t I?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1458
translate chinese JuR2_We_step5_con1_ae55662a:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1464
translate chinese JuR2_We_step5_con1_bbd19d5b:

    # MC "Hello? Is that Milfy City Taxis?"
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1466
translate chinese JuR2_We_step5_con1_52c6a04b:

    # MC "Uh huh. Yup, I need a cab from the campus."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1468
translate chinese JuR2_We_step5_con1_ae55662a_1:

    # Judy "Zzz..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1470
translate chinese JuR2_We_step5_con1_5dcb03ce:

    # MC "Yeah, as soon as possible."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1471
translate chinese JuR2_We_step5_con1_a5bcf99c:

    # MC "Perfect, thanks. We’ll be there."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1472
translate chinese JuR2_We_step5_con1_649cde84:

    # MC "C’mon Judy, time to get up."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1476
translate chinese JuR2_We_step5_con1_1d02c0ec:

    # Judy "Hmm? What’s... Where are we?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1477
translate chinese JuR2_We_step5_con1_730c92b2:

    # MC "We’re on campus. You passed out after getting drunk. I called you a taxi to pick you up."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1478
translate chinese JuR2_We_step5_con1_4e9de34c:

    # Judy "...oh."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1482
translate chinese JuR2_We_step5_con1_39418feb:

    # Judy "That’sh *Hic* very kind... of you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1483
translate chinese JuR2_We_step5_con1_7a6223f6:

    # MC "Yeah, no problem."
    MC ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1484
translate chinese JuR2_We_step5_con1_fc869333:

    # Judy "Hehe... I had a dream that we were *hic* fucking without a condom. It was amaaaazzziinng!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_We.rpy:1485
translate chinese JuR2_We_step5_con1_c530f23f:

    # MC "Haha, let’s get you home."
    MC ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_We.rpy:230
    old "Therapist's Room"
    new ""

    # game/scripts/Ju_scenes/JuR2_We.rpy:230
    old "Professors' Office"
    new ""

    # game/scripts/Ju_scenes/JuR2_We.rpy:230
    old "My Calssroom"
    new ""

    # game/scripts/Ju_scenes/JuR2_We.rpy:230
    old "Dean's Office"
    new ""

    # game/scripts/Ju_scenes/JuR2_We.rpy:1264
    old "Judy gives in and begs you to cum inside her."
    new ""

    # game/scripts/Ju_scenes/JuR2_We.rpy:1264
    old "Judy manages to resist and asks you to pull out."
    new ""

