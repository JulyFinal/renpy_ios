﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:24
translate chinese JuR2_MS1_c0b815b5:

    # Judy "It’s good to see you again, [player_name]. You made a wise decision in continuing your therapy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:25
translate chinese JuR2_MS1_d6ff758f:

    # Judy "But therapy isn’t the only reason you’re here, is it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:28
translate chinese JuR2_MS1_dadbee94:

    # MC "How could you tell?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:31
translate chinese JuR2_MS1_c057a6ea:

    # Judy "You appear uneasy. More anxious than you usually do when you’re attending therapy. That suggests to me that you’re here today for more than simply therapy. You’re interested in this deal."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:33
translate chinese JuR2_MS1_11c33e92:

    # Judy "The fact that you’re nervous suggests that you have something interesting to tell me about your relationship with your mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:35
translate chinese JuR2_MS1_1d3cffc5:

    # Judy "The fact that you’re nervous suggests that you have something interesting to tell me about your relationship with Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:36
translate chinese JuR2_MS1_69fc9bcd:

    # Judy "And given how anxious you are right now... it has to be juicy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:40
translate chinese JuR2_MS1_37ac2ad9:

    # Judy "So, [player_name], tell me what happened between you and your mom. And don’t spare any details."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:42
translate chinese JuR2_MS1_b6078eef:

    # Judy "So, [player_name], tell me what happened between you and Linda. And don’t spare any details."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:43
translate chinese JuR2_MS1_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:44
translate chinese JuR2_MS1_068c5a16:

    # Judy "Remember what I promised you. If you help me with my research, I will help you in return."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:47
translate chinese JuR2_MS1_20b76820:

    # MC "(There’s no way I can tell her everything that actually happened.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:48
translate chinese JuR2_MS1_0674a8ad:

    # MC "I... uh... We... may have touched each other a bit."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:51
translate chinese JuR2_MS1_31a7b12b:

    # Judy "Oh, come on, [player_name]. I’m going to need you to be a bit more descriptive than that. I can hardly use that for my research, can I?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:54
translate chinese JuR2_MS1_46351420:

    # MC "We... um... went uh... out together."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:55
translate chinese JuR2_MS1_857d7424:

    # Judy "On a date?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:56
translate chinese JuR2_MS1_19034501:

    # MC "I- I didn’t say that."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:60
translate chinese JuR2_MS1_6f8c3e1d:

    # Judy "But it WAS a date, am I correct?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:62
translate chinese JuR2_MS1_f2b94741:

    # Judy "But It WAS a date, correct? With a significantly older married woman, no less."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:63
translate chinese JuR2_MS1_2d4b1087:

    # MC "I- uh... It’s hard to... define what makes a date, a date. Do you know what I mean?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:66
translate chinese JuR2_MS1_e4f39409:

    # Judy "Hmm... Fine. Where did you head out together?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:67
translate chinese JuR2_MS1_803b760f:

    # MC "Just a fancy restaurant. She drove us there."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:68
translate chinese JuR2_MS1_ecfb51a2:

    # Judy "Uh huh. And were the two of you intimate during the date at all?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:69
translate chinese JuR2_MS1_c4a515ea:

    # MC "I didn’t say it was a date!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:73
translate chinese JuR2_MS1_23d926fb:

    # Judy "Interesting. You denied that it was a date, but you didn’t say anything when I suggested there was intimacy. What happened? Did you kiss?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:75
translate chinese JuR2_MS1_da5ee206:

    # Judy "Interesting. You denied that it was a date, but you didn't say anything when I suggested there was intimacy. What happened? Did you kiss a significantly older woman?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:78
translate chinese JuR2_MS1_efa9dfdd:

    # MC "N-No, I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:81
translate chinese JuR2_MS1_01d421ec:

    # Judy "Come on, [player_name]. I want the full, unfiltered truth. Stop trying to hide things from me. What happened after you left the restaurant?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:84
translate chinese JuR2_MS1_65a91449:

    # MC "N-Nothing happened after the restaurant?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:87
translate chinese JuR2_MS1_00eaf7da:

    # Judy "Before the restaurant, then?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:90
translate chinese JuR2_MS1_cea225ce:

    # MC "N-No!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:93
translate chinese JuR2_MS1_bead3614:

    # Judy "Oh my, something happened DURING your meal?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:94
translate chinese JuR2_MS1_79cfa724:

    # MC "I..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:95
translate chinese JuR2_MS1_0210676f:

    # Judy "Mmm, tell me what it was."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:100
translate chinese JuR2_MS1_9c2dd36d:

    # MC "Shit... It’s embarrassing, alright?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:101
translate chinese JuR2_MS1_167264e0:

    # Judy "Remember that the more you tell me, the more I can help you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:102
translate chinese JuR2_MS1_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:103
translate chinese JuR2_MS1_151a9c6c:

    # MC "She took off her shoe during the meal and began rubbing her foot against my crotch through my jeans."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:106
translate chinese JuR2_MS1_7b4193d2:

    # Judy "My, my... I didn’t imagine you as a foot fetishist."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:107
translate chinese JuR2_MS1_fcb54282:

    # MC "I’m not! Which is why I told her to stop! I mean, we were in the middle of a crowded restaurant!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:108
translate chinese JuR2_MS1_7572421d:

    # Judy "I’m getting a strong sense that’s not where it ended though."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:111
translate chinese JuR2_MS1_cb971ecc:

    # MC "...you’re right. She came to sit beside me after I told her to stop."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:112
translate chinese JuR2_MS1_69eb2854:

    # MC "I thought she was just being romantic, but a few seconds later she had reached down and..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:115
translate chinese JuR2_MS1_947cad07:

    # Judy "Reached down and what, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:116
translate chinese JuR2_MS1_ade55fc9:

    # MC "...opened up my jeans. "
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:119
translate chinese JuR2_MS1_214fc5ab:

    # Judy "Was she playing with your cock?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:120
translate chinese JuR2_MS1_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:123
translate chinese JuR2_MS1_a0d8fca3:

    # MC "It started with her just giving me a handjob, but..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:124
translate chinese JuR2_MS1_99539297:

    # MC "You have to understand, I didn’t initiate this! I couldn’t stop her! It all happened so suddenly. One minute she was just rubbing my cock, and the next..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:125
translate chinese JuR2_MS1_1a7af437:

    # MC "...she was under the table with her lips wrapped around my dick."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:128
translate chinese JuR2_MS1_4e866e54:

    # Judy "Oh my! That sounds... Wow..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:130
translate chinese JuR2_MS1_e316ed4e:

    # Judy "So, just to clarify, your mother leaned over in the middle of a crowded restaurant and performed oral sex on you? Did you cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:132
translate chinese JuR2_MS1_103384da:

    # Judy "So, just to clarify, Linda leaned over in the middle of a crowded restaurant and performed oral sex on you? Did you cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:135
translate chinese JuR2_MS1_a6ee7769:

    # MC "*Sigh* Y-Yeah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:136
translate chinese JuR2_MS1_51850bd3:

    # MC "You have to understand though - I was trapped, I couldn’t move or leave the table. People would see me if I did! All I could do was sit there and let her finish... sucking."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:139
translate chinese JuR2_MS1_03048c04:

    # Judy "Where did you finish? In a napkin?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:142
translate chinese JuR2_MS1_b5431d59:

    # MC "Down her... throat."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:144
translate chinese JuR2_MS1_da1a6dfe:

    # Judy "(A son cumming down his own mother’s throat in public?! My panties are drenched just imagining it. God... If I had a son of my own I would drink his balls dry.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:146
translate chinese JuR2_MS1_15753084:

    # Judy "([player_name] cumming down to a far older woman's throat in public?! My panties are drenched just imagining it. God... If I had a man like that, I would drink his balls dry.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:152
translate chinese JuR2_MS1_9c2dd36d_1:

    # MC "Shit... It’s embarrassing, alright?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:153
translate chinese JuR2_MS1_167264e0_1:

    # Judy "Remember that the more you tell me, the more I can help you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:154
translate chinese JuR2_MS1_d9ebec3f_1:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:155
translate chinese JuR2_MS1_151a9c6c_1:

    # MC "She took off her shoe during the meal and began rubbing her foot against my crotch through my jeans."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:158
translate chinese JuR2_MS1_7b4193d2_1:

    # Judy "My, my... I didn’t imagine you as a foot fetishist."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:159
translate chinese JuR2_MS1_b3077fcf:

    # MC "I... I mean... She had already started and I didn’t want to offend her."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:162
translate chinese JuR2_MS1_a2638003:

    # Judy "Uh huh. So, what happened next?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:163
translate chinese JuR2_MS1_0f151ea8:

    # MC "You know... it just sort of... progressed from there."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:164
translate chinese JuR2_MS1_575c71f7:

    # Judy "Be more descriptive, [player_name]. Use your vocabulary."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:165
translate chinese JuR2_MS1_152db30c:

    # MC "I... uh... She unzipped my jeans with her toes."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:168
translate chinese JuR2_MS1_0d85348d:

    # Judy "And then?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:169
translate chinese JuR2_MS1_3a08a390:

    # MC "She began rubbing my... *ahem* with both her feet."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:171
translate chinese JuR2_MS1_d3de1a98:

    # Judy "Mmm, it must have felt sooo good to have your mother massage your cock with her feet in public. Did you cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:173
translate chinese JuR2_MS1_53ba1a64:

    # Judy "Mmm, it must have felt sooo good to have your landlady massage your cock with her feet in public. Did you cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:176
translate chinese JuR2_MS1_320eade3:

    # MC "Y-Yeah, I finished."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:179
translate chinese JuR2_MS1_ce504640:

    # Judy "Where? Detail is important, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:182
translate chinese JuR2_MS1_efcd5585:

    # MC "I... uh... I finished over her feet."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:185
translate chinese JuR2_MS1_6d8cb30d:

    # Judy "Mmm... Fascinating."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:192
translate chinese JuR2_MS1_con_9b93e629:

    # Judy "So, was the restaurant your ONLY encounter that you’ve had with your mother?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:194
translate chinese JuR2_MS1_con_eed09ae5:

    # Judy "So, was the restaurant your ONLY encounter that you’ve had with your lanlady?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:196
translate chinese JuR2_MS1_con_a55e01a2:

    # MC "I don’t... uh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:198
translate chinese JuR2_MS1_con_5084070e:

    # Judy "Have you done anything together anywhere else? The car? The house, perhaps?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:201
translate chinese JuR2_MS1_con_4cda6d2a:

    # Judy "You don’t need to be shy, [player_name]. Everything you tell me in therapy is strictly confidential, and you will be anonymised if I use your data in my book."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:203
translate chinese JuR2_MS1_con_d28350af:

    # MC "*Gulp* I... may have... sixty-nined with my mom... at home."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:205
translate chinese JuR2_MS1_con_5b9ee456:

    # MC "*Gulp* I... may have... sixty-nined with her... at home."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:207
translate chinese JuR2_MS1_con_9386af02:

    # Judy "Oh, where abouts? Your bed?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:209
translate chinese JuR2_MS1_con_6d77a2f2:

    # MC "Her bed, I mean - my parents’ bed."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:211
translate chinese JuR2_MS1_con_9e4ebbd6:

    # MC "Her bed."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:214
translate chinese JuR2_MS1_con_955bd65b:

    # Judy "And... you came again?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:215
translate chinese JuR2_MS1_con_afc8cc1f:

    # MC "Yeah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:217
translate chinese JuR2_MS1_con_778f4296:

    # Judy "And your mother, did you make her cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:219
translate chinese JuR2_MS1_con_5fe9875d:

    # Judy "And Linda, did you make her cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:221
translate chinese JuR2_MS1_con_afc2e58c:

    # MC "I think so...It ended after the sixty-nine."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:224
translate chinese JuR2_MS1_con_2b04a6d8:

    # Judy "Did it really?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:225
translate chinese JuR2_MS1_con_88406816:

    # MC "Y-You don’t believe me?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:227
translate chinese JuR2_MS1_con_3364de49:

    # Judy "I just think you may be too shy or embarrassed by the taboo of sleeping with your own mother to admit that you went farther."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:229
translate chinese JuR2_MS1_con_2a4a5614:

    # Judy "I just think you may be too shy or embarrassed by the taboo of sleeping with an older married woman."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:230
translate chinese JuR2_MS1_con_0a488882:

    # MC "*Gulp* W-We may have... started to... prepare to have... uh... y’know. Bob interrupted us though."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:231
translate chinese JuR2_MS1_con_66de717f:

    # Judy "Goodness me, did you have a condom on?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:232
translate chinese JuR2_MS1_con_7037c814:

    # MC "N-No, I didn’t."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:236
translate chinese JuR2_MS1_con_0bac4b90:

    # Judy "(Holy fuck that’s hot. Thank God I keep a pair of spare panties in my desk drawer - the thought of a son screwing his own mom raw and unprotected makes me so-)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:238
translate chinese JuR2_MS1_con_ded32d83:

    # Judy "(Holy fuck that’s hot. Thank God I keep a pair of spare panties in my desk drawer - the thought of him screwing his landlady raw and unprotected makes me so-)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:239
translate chinese JuR2_MS1_con_c9a14018:

    # Judy "Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:240
translate chinese JuR2_MS1_con_3d0aaa78:

    # MC "Did you just moan?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:241
translate chinese JuR2_MS1_con_0e9fa49e:

    # Judy "*Ahem* Just something caught in my throat, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:242
translate chinese JuR2_MS1_con_b5f53d3d:

    # Judy "Anyway, it ended after Bob interrupted you both, correct?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:244
translate chinese JuR2_MS1_con_570df17f:

    # MC "Yeah, my mom was furious at him, but thankfully I didn’t get caught."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:246
translate chinese JuR2_MS1_con_057612a9:

    # MC "Yeah, she was furious at him, but thankfully I didn’t get caught."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:247
translate chinese JuR2_MS1_con_8b6b4003:

    # Judy "(Fascinating...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:251
translate chinese JuR2_MS1_con_191b1515:

    # Judy "And how is your relationship with your sisters going? Anything of note there?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:253
translate chinese JuR2_MS1_con_046dce2e:

    # Judy "And how is your relationship with your roommates going? Anything of note there?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:254
translate chinese JuR2_MS1_con_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:255
translate chinese JuR2_MS1_con_e27aec67:

    # Judy "Actually, hold off. This is something better explored in a private therapy session at my house."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:257
translate chinese JuR2_MS1_con_dfcdbf8d:

    # MC "I couldn’t afford private therapy, Judy. Do you know how many times I’d have to complete that fucking cleaning minigame in my mom’s office to be able to afford that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:259
translate chinese JuR2_MS1_con_12872799:

    # MC "I couldn't afford private therapy, Judy. Do you have any idea how many times I'd have to complete those darn minigames just to afford it?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS1_terapistroom.rpy:260
translate chinese JuR2_MS1_con_32c7f8a1:

    # Judy "Relax, [player_name], I won’t be charging you. You’re already helping me out with my work. Come along to my place for private therapy. I promise that you won’t regret it."
    Judy ""

