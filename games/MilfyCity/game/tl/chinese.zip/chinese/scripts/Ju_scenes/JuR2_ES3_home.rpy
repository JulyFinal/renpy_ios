﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:66
translate chinese JuR2_ES3_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:68
translate chinese JuR2_ES3_327d4e14:

    # Judy "Jus’ a minute!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:75
translate chinese JuR2_ES3_6e281ced:

    # Judy "Oh, it’s you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:76
translate chinese JuR2_ES3_c9f67a03:

    # MC "Are you alright, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:77
translate chinese JuR2_ES3_0940b71b:

    # Judy "Jus’ a bit... drunk. Had a little too much wine."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:81
translate chinese JuR2_ES3_81bbfd5b:

    # MC "Did you forget that we’ve got a private therapy session today?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:82
translate chinese JuR2_ES3_00c2db8f:

    # Judy "Ah shit... Sorry, I’m... I’m gonna... Today might not be the best day for therapy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:83
translate chinese JuR2_ES3_e0c95802:

    # MC "(She’s REALLY drunk right now. What on Earth’s gotten into her?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:87
translate chinese JuR2_ES3_4ea293a8:

    # Judy "But, y’know what? Let’s just go with it anyway - and see what happens."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:88
translate chinese JuR2_ES3_d5788873:

    # Judy "I mean, if I was in your position, I’d need all the therapy I could get! Ha! *Hic*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:92
translate chinese JuR2_ES3_df2163cf:

    # MC "Pardon?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:93
translate chinese JuR2_ES3_9888f624:

    # Judy "Whoopsh, did I shay that out loud? *Hic* Shit."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:95
translate chinese JuR2_ES3_2daa13c2:

    # MC "I mean, we can reschedule if you want, I just thought I’d share with you an update about my mom."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:97
translate chinese JuR2_ES3_bd01774b:

    # MC "I mean, we can reschedule if you want, I just thought I’d share with you an update about Linda."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:101
translate chinese JuR2_ES3_db1e2290:

    # Judy "Oh! Linda! Of course! Yes! *Hic* You HAVE to tell me what’s going on."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:102
translate chinese JuR2_ES3_a8f39a3c:

    # Judy "Please, come in, come in. Make yourself *hic* at home."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:103
translate chinese JuR2_ES3_fb94bf79:

    # MC "Umm... Thanks?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:107
translate chinese JuR2_ES3_bbd786a4:

    # Judy "I’ve been looking forward to this *Hic* all week. Did I tell you that? I feel like I’ve already told you that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:108
translate chinese JuR2_ES3_f9123acd:

    # MC "You haven’t, but I’m happy to hear that."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:109
translate chinese JuR2_ES3_e67ebebe:

    # Judy "Go on into *Hic* my therapy room. Wait for me there. I’m jusht gonna... gonna... get some coffee. I need to shober up a bit. The room’s all spinny right now. Hehe!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:110
translate chinese JuR2_ES3_74bea3fa:

    # MC "(God, she is wasted right now!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:128
translate chinese JuR2_ES3_kitchen_lock_a768063e:

    # MC "(Let's hang around while Judy's in the kitchen.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:140
translate chinese JuR2_ES3_step1_75f272f1:

    # MC "(So, I guess I’m just supposed to hang around in here and hope Judy hasn’t passed out in the kitchen.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:141
translate chinese JuR2_ES3_step1_641e2314:

    # MC "(Seriously though, what was she thinking? It’s out of character for her to get drunk like that. I wonder if something happened.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:145
translate chinese JuR2_ES3_step1_3bbdcb02:

    # MC "(Maybe she’s just stressed from work. She’s already pulling extra hours doing private therapy for me. It’s possible that the woman has just reached her limit.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:146
translate chinese JuR2_ES3_step1_1510cc1b:

    # MC "(I’ll try and go a little easier on her today. Maybe not drop anything too heavy.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:150
translate chinese JuR2_ES3_step1_9780c2f3:

    # MC "(Huh? That’s weird. There’s a lone book lying on her desk there.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:154
translate chinese JuR2_ES3_step1_dc77b2d4:

    # MC "(I wonder if she was reading something that upset her. Maybe that’s why she decided to go and get drunk?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:155
translate chinese JuR2_ES3_step1_a1084371:

    # MC "(Ah what the hell, let’s check it out.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:172
translate chinese JuR2_ES3_step2_374c34cb:

    # MC "...and the subject then entered a restaurant with his... mother?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:175
translate chinese JuR2_ES3_step2_6b8ed6f0:

    # MC "The subject was pleasured by his mother until he ejaculated, suggesting that the oedipus complex as suggested by Sigmund Freud is..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:177
translate chinese JuR2_ES3_step2_f73c63d2:

    # MC "...and the subject then entered a restaurant with... a lot older married woman who can't control her emotions... She’s like a cougar in comparison to him."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:180
translate chinese JuR2_ES3_step2_46d160fa:

    # MC "The subject was pleasured by that older married woman who was betraying her husband until he ejaculated, suggesting that the oedipus complex as suggested by Sigmund Freud is..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:184
translate chinese JuR2_ES3_step2_155b57c8:

    # MC "(Wait a minute...)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:185
translate chinese JuR2_ES3_step2_9e5d9ceb:

    # MC "(This is everything I’ve been telling Judy about in my therapy sessions! Why’s it all written down in this book?!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:186
translate chinese JuR2_ES3_step2_c4950667:

    # MC "(What even is this book?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:190
translate chinese JuR2_ES3_step2_214213f1:

    # MC "The Taboo of Human Nature... by Dr Judy Reneaux."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:192
translate chinese JuR2_ES3_step2_48701417:

    # MC "Fucking hell..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:196
translate chinese JuR2_ES3_step2_c5750ac9:

    # MC "(She’s using me and my mom as test subjects to write a psychology book?! This is insane!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:198
translate chinese JuR2_ES3_step2_f0ae73c5:

    # MC "(She’s using me and Linda as test subjects to write a psychology book?! This is insane!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:199
translate chinese JuR2_ES3_step2_a2c40535:

    # MC "Dammit! (I should have noticed this sooner! Judy has been acting weird since the first day I saw her!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:204
translate chinese JuR2_ES3_step2_e75c874d:

    # Judy "Is everything alright, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:205
translate chinese JuR2_ES3_step2_42fad66c:

    # MC "You LIED to me."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:206
translate chinese JuR2_ES3_step2_38e5652f:

    # Judy "Pardon?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:210
translate chinese JuR2_ES3_step2_fbab2f58:

    # MC "You lied to me and manipulated me! And you lied to my mom and manipulated her too!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:212
translate chinese JuR2_ES3_step2_e2e7dd7f:

    # MC "You lied to me and manipulated me! And you lied to Linda and manipulated her too!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:216
translate chinese JuR2_ES3_step2_5dbab25d:

    # Judy "Really, I have no idea what you’re-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:220
translate chinese JuR2_ES3_step2_c46ea15f:

    # MC "I found your book! You’ve been using my mom and me as test subjects for your weird research into human taboo!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:222
translate chinese JuR2_ES3_step2_c9a33ce7:

    # MC "I found your book! You’ve been using Linda and me as test subjects for your weird research into human taboo!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:223
translate chinese JuR2_ES3_step2_6253b73a:

    # Judy "(Oh crap. I can’t believe I forgot to pack it away!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:227
translate chinese JuR2_ES3_step2_a77d5229:

    # Judy "Well, yes, I-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:231
translate chinese JuR2_ES3_step2_9297d9e3:

    # MC "I never agreed to be part of this! You tricked me!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:235
translate chinese JuR2_ES3_step2_d3cceb4a:

    # Judy "You’re angry *hic* again, [player_name]. I am going to need you to take a deep breath and calm down."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:236
translate chinese JuR2_ES3_step2_b333057d:

    # MC "You’re telling me to calm down?! You’re writing things I tell you in CONFIDENTIALITY into a creepy book!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:237
translate chinese JuR2_ES3_step2_79ea93cd:

    # Judy "Try to relax, [player_name]. I’m going to change the names before the final version gets published. And you’re being well-compensated for telling me these things, are you not?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:241
translate chinese JuR2_ES3_step2_c9aadc7f:

    # Judy "Did you not enjoy me making you cum during our last session? You told me some very interesting things about your mom and your sisters."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:243
translate chinese JuR2_ES3_step2_85a5b50d:

    # Judy "Did you not enjoy me making you cum during our last session? You told me some very interesting things about your landlady and your roommates."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:244
translate chinese JuR2_ES3_step2_9845745f:

    # Judy "And in return, I think I was VERY generous with my body."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:249
translate chinese JuR2_ES3_step2_143af8cb:

    # Judy "I could be even more generous, you know."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:250
translate chinese JuR2_ES3_step2_8b9539cc:

    # MC "What do you mean? Are you going to give me a share of the profits when you publish it?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:254
translate chinese JuR2_ES3_step2_d0633304:

    # Judy "Haha! I could, but would a guy your age not prefer something more... enticing than cash?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:255
translate chinese JuR2_ES3_step2_7b4f4a39:

    # MC "What are you suggesting?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:259
translate chinese JuR2_ES3_step2_c8b510d4:

    # Judy "I think you *hic* already know what I’m suggesting. You’re just too shy to admit what you actually want."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:260
translate chinese JuR2_ES3_step2_6fd263e7:

    # MC "And that is?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:264
translate chinese JuR2_ES3_step2_88baabfb:

    # Judy "Do I really have to spell it out for you? I’m already drunk, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:265
translate chinese JuR2_ES3_step2_82338802:

    # MC "(What is she planning?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:269
translate chinese JuR2_ES3_step2_d38eb984:

    # Judy "Take a seat on my desk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:270
translate chinese JuR2_ES3_step2_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:271
translate chinese JuR2_ES3_step2_7352c264:

    # Judy "Just... Just trust me, okay. I know that’s asking A LOT right now."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:272
translate chinese JuR2_ES3_step2_77a73522:

    # MC "You don’t say... *Sigh* Alright, I’ll sit over there."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:282
translate chinese JuR2_ES3_step_bj_b94bfa00:

    # "*Ziiip*"
    ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:285
translate chinese JuR2_ES3_step_bj_6335b10f:

    # MC "J-Judy wh-what are you-?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:286
translate chinese JuR2_ES3_step_bj_1dd7a785:

    # Judy "I told you I was going *hic* to be even more generous with my body. Hehe! I hope you enjoy blowjobs, [player_name], because I’m going to suck you dry."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:287
translate chinese JuR2_ES3_step_bj_265bd5ba:

    # MC "(Holy shit! She just whipped out my cock with no warning!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:288
translate chinese JuR2_ES3_step_bj_032a0a11:

    # MC "You’re drunk!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:289
translate chinese JuR2_ES3_step_bj_c84a4d89:

    # Judy "Drunk *hic* AND horny! C’mon, you don’t have to do anything, just sit back and enjoy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:291
translate chinese JuR2_ES3_step_bj_e3d72d75:

    # Judy "Hehe! Try to imagine *hic* that I’m *hic* your mommy when I’m doing this. You can call me mommy if you want."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:293
translate chinese JuR2_ES3_step_bj_27610a1c:

    # MC "I don’t know about-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:297
translate chinese JuR2_ES3_step_bj_81933f4f:

    # Judy "*Lick* Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:298
translate chinese JuR2_ES3_step_bj_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:299
translate chinese JuR2_ES3_step_bj_4e4485a2:

    # Judy "*Lick* *Lick* *Slurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:300
translate chinese JuR2_ES3_step_bj_cb0801cd:

    # MC "Ahhh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:301
translate chinese JuR2_ES3_step_bj_53fb5dbe:

    # MC "(Fuck! Her tongue feels incredible!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:305
translate chinese JuR2_ES3_step_bj_d193fe95:

    # Judy "*Lick* *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:306
translate chinese JuR2_ES3_step_bj_9a2f65ae:

    # Judy "Mmm! Are you enjoying this, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:307
translate chinese JuR2_ES3_step_bj_b8cc2658:

    # MC "Y-Yeah, it’s amazing, Judy. Ahh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:311
translate chinese JuR2_ES3_step_bj_674c8a9d:

    # Judy "Not “Judy”, try again."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:312
translate chinese JuR2_ES3_step_bj_119299bc:

    # MC "It’s..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:313
translate chinese JuR2_ES3_step_bj_d193fe95_1:

    # Judy "*Lick* *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:315
translate chinese JuR2_ES3_step_bj_42f16a3b:

    # MC "Oooh! It’s amazing... M... mo..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:318
translate chinese JuR2_ES3_step_bj_0a7eebd8:

    # Judy "(Hmm... He’s still resistant to vocalising his latent desires. Perhaps if I increased the intensity, he would give in.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:322
translate chinese JuR2_ES3_step_bj_c985200d:

    # Judy "*Suck* *Suuuuucck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:324
translate chinese JuR2_ES3_step_bj_f5062fc4:

    # MC "Ohh God, it’s amazing, mommy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:327
translate chinese JuR2_ES3_step_bj_a643b6fd:

    # Judy "(Well, he was A LOT closer to announcing his true desires than I had anticipated. I had thought it may take multiple sessions before he would openly call me “mommy” during an encounter like this.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:332
translate chinese JuR2_ES3_step_bj_61523ed2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:333
translate chinese JuR2_ES3_step_bj_c9eca583:

    # MC "Ahhh! D-Don’t stop! Ooohh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:334
translate chinese JuR2_ES3_step_bj_440602f3:

    # Judy "(I’ll have to document my findings before I go to sleep for the night. This is a fascinating discovery.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:338
translate chinese JuR2_ES3_step_bj_2b3646f3:

    # Judy "*Suck* *Shluurrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:340
translate chinese JuR2_ES3_step_bj_2bf4a204:

    # MC "Ohh... Hnnng! Suck my cock! Ahh! Just like that!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:341
translate chinese JuR2_ES3_step_bj_ed5c1622:

    # Judy "*Suuuuck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:343
translate chinese JuR2_ES3_step_bj_f4ada5e8:

    # MC "Ahh... (I can feel her cheeks pursing in around the tip of my cock. She’s caressing every single inch of it with her mouth!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:347
translate chinese JuR2_ES3_step_bj_b1217c90:

    # Judy "*Shlurp* *Suck* *Gasp* C’mon, [player_name], keep talking to me. Tell me what you want ‘mommy’ to do."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:349
translate chinese JuR2_ES3_step_bj_ef3c9b5a:

    # MC "I... *Pant* I..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:350
translate chinese JuR2_ES3_step_bj_e70b9268:

    # Judy "(It seems he’s only really letting his guard down during moments of intense pleasure. I’ll have to try and slowly lure him into vocalising his desires during less intense periods.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:354
translate chinese JuR2_ES3_step_bj_0b0c0fe4:

    # Judy "Mmm hmm... Keep talking. *Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:355
translate chinese JuR2_ES3_step_bj_a26ca5ab:

    # MC "Hnng... (She’s just focusing on sucking the tip of my cock now! Fuck, I can feel her swirling her tongue around the tip. She’s teasing me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:356
translate chinese JuR2_ES3_step_bj_920dfcae:

    # Judy "*Lick* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:360
translate chinese JuR2_ES3_step_bj_3c4f9ea3:

    # Judy "You want me to do more, don’t you? If you really want me to take more of your delicious dick in my mouth, then you only have to say one thing. One little word. Two syllables."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:361
translate chinese JuR2_ES3_step_bj_79cfa724:

    # MC "I..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:365
translate chinese JuR2_ES3_step_bj_73341df1:

    # Judy "Tell me what you want, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:366
translate chinese JuR2_ES3_step_bj_fffd1031:

    # MC "I... Ah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:367
translate chinese JuR2_ES3_step_bj_fa82ee81:

    # Judy "*Shlurp* *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:368
translate chinese JuR2_ES3_step_bj_724395f4:

    # MC "I... Ohh... Hnng..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:370
translate chinese JuR2_ES3_step_bj_3e3fe046:

    # MC "Keep sucking my cock... mommy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:375
translate chinese JuR2_ES3_step_bj_afff8cea:

    # Judy "*Glompf* *Shluurrrrp* *Suuuck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:377
translate chinese JuR2_ES3_step_bj_fe154046:

    # MC "Ooohh! Y-Yes, don’t stop! Ah! Your mouth feels so fucking good, mommy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:379
translate chinese JuR2_ES3_step_bj_01a510f6:

    # Judy "(And that is how you break down a guy’s mental defences. You tempt down his walls by granting him only partial-satisfaction. When he finally gets so desperate for the full experience, he will do and say anything.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:383
translate chinese JuR2_ES3_step_bj_ecfff93b:

    # Judy "*Suck* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:384
translate chinese JuR2_ES3_step_bj_f67c71f8:

    # Judy "(It’s a miracle I’ve not had my licence revoked.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:385
translate chinese JuR2_ES3_step_bj_4e0367d2:

    # MC "Hnnng! Oh God! Yes! Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:389
translate chinese JuR2_ES3_step_bj_dc190fea:

    # MC "Fuck! I’m about to cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:391
translate chinese JuR2_ES3_step_bj_72ec6de4:

    # Judy "*Shlurp* *Gasp* Where do you want to cum? Do you want to finish all over mommy’s face? Or do you want to shoot your load deep into my warm mouth so mommy can taste your cum?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:398
translate chinese JuR2_ES3_step_bj_8c2e11e3:

    # MC "Hnnng! I want to cum in your mouth, mommy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:400
translate chinese JuR2_ES3_step_bj_56ea263e:

    # Judy "*Shlurp* *Suck* *Suucccck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:401
translate chinese JuR2_ES3_step_bj_2f1cf822:

    # MC "Ohh! Oh fuck! Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:402
translate chinese JuR2_ES3_step_bj_18ae769c:

    # Judy "*Suck* *Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:403
translate chinese JuR2_ES3_step_bj_6ad700d8:

    # MC "HNNNNGGG!! Aarrghhh! I’m cumming!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:414
translate chinese JuR2_ES3_step_bj_d1fa42bb:

    # MC "*Gasp* Oooohhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:415
translate chinese JuR2_ES3_step_bj_036e0f44:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:416
translate chinese JuR2_ES3_step_bj_2fa5ebf0:

    # MC "Wow... *Pant* That was... *Pant* fucking intense."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:420
translate chinese JuR2_ES3_step_bj_86a5fe15:

    # Judy "(Hmm... It’s interesting that he decided to cum in my mouth. Does that suggest a repulsion or aversion to seeing his own semen? Or perhaps he gets off on KNOWING that a woman is tasting his very essence.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:421
translate chinese JuR2_ES3_step_bj_79f1a710:

    # Judy "*Gulp* Ahh.."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:422
translate chinese JuR2_ES3_step_bj_7a2f9d94:

    # MC "(Did she just swallow my cum?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:426
translate chinese JuR2_ES3_step_bj_b007aa5e:

    # Judy "Well? Do you think you’re *hic* going to enjoy our therapy shessions, going forward?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:427
translate chinese JuR2_ES3_step_bj_6103eed0:

    # MC "Were you always going to give me a blowjob, Judy? Or is this just because you’re drunk and I caught you writing that book?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:428
translate chinese JuR2_ES3_step_bj_70597759:

    # Judy "Hehe! The blowjob was alwaysh in the *hic* cards. Shwallowing your load though, *Hic*, that’s just because I’m a little bit *hic* tipsy. I don’t do that when I’m shober."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:429
translate chinese JuR2_ES3_step_bj_a98e902d:

    # Judy "Shober. Sh...ober. Hehe, that’s a funny word."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:433
translate chinese JuR2_ES3_step_bj_e8e044fe:

    # MC "*Sigh* Right, well, it’s getting late. I’m going to head home for the night."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:434
translate chinese JuR2_ES3_step_bj_8c0d11d0:

    # Judy "Make sure to drop by my office next time you’re around campus. We still have a lot of things to dischuss. D-Dischuss... *Hic*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:436
translate chinese JuR2_ES3_step_bj_e8d23e2b:

    # MC "*Sigh* Goodnight mommy- I mean, Judy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:438
translate chinese JuR2_ES3_step_bj_ac60c103:

    # Judy "Haha, g’night! (It was a good session... Time to finally get a glass of wine.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:461
translate chinese JuR2_ES3_step_bj_56ea263e_1:

    # Judy "*Shlurp* *Suck* *Suucccck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:462
translate chinese JuR2_ES3_step_bj_37f8d443:

    # MC "Hnng... I’m about to cum! Stop sucking, I want to finish over your face!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:472
translate chinese JuR2_ES3_step_bj_8215b72a:

    # MC "Argh! Fuck, I’m cumming! Aaahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:473
translate chinese JuR2_ES3_step_bj_eb109842:

    # Judy "(Oof! Why do guys always go for the eye?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:475
translate chinese JuR2_ES3_step_bj_d85956cc:

    # MC "*Pant* Oh fuuuck, keep stroking it with your hand, mommy, it feels so good."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:480
translate chinese JuR2_ES3_step_bj_b70d61d0:

    # Judy "(I wonder why [player_name] decided to finish over my face? Perhaps he views the act of “painting” my face with his semen as some sort of primal domination or victory display after a mating ritual?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:481
translate chinese JuR2_ES3_step_bj_7ed2b5ea:

    # Judy "(Or maybe there’s a deep-rooted anxiety of finishing inside my mouth?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:482
translate chinese JuR2_ES3_step_bj_72fc10ec:

    # Judy "(Maybe he actually wanted to finish in my mouth but was concerned about how my opinion of him would alter or change based upon the actions he took - in effect, self-limiting his own actions out of fear of others perception of his true desires.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:483
translate chinese JuR2_ES3_step_bj_fd3bae5e:

    # Judy "(Which is a really sad thing if true, given that it obscures the chance for a genuine connection with someone who shared identical desires.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:487
translate chinese JuR2_ES3_step_bj_3a0c15ec:

    # MC "Uh... hello? Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:488
translate chinese JuR2_ES3_step_bj_3cebd3d3:

    # Judy "Hmm?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:489
translate chinese JuR2_ES3_step_bj_36cae597:

    # MC "I was talking to you there, it was like you were in a daze."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:490
translate chinese JuR2_ES3_step_bj_f6874db3:

    # Judy "Oh, just lost in *hic* thought. Happensh when I’m drunk. Did you enjoy our therapy shession today?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:491
translate chinese JuR2_ES3_step_bj_f83e0633:

    # MC "Of course, but were you always going to give me a blowjob, Judy? Or is this just because you’re drunk and I caught you writing that book?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:492
translate chinese JuR2_ES3_step_bj_70597759_1:

    # Judy "Hehe! The blowjob was alwaysh in the *hic* cards. Shwallowing your load though, *Hic*, that’s just because I’m a little bit *hic* tipsy. I don’t do that when I’m shober."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:493
translate chinese JuR2_ES3_step_bj_a98e902d_1:

    # Judy "Shober. Sh...ober. Hehe, that’s a funny word."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:497
translate chinese JuR2_ES3_step_bj_e8e044fe_1:

    # MC "*Sigh* Right, well, it’s getting late. I’m going to head home for the night."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:498
translate chinese JuR2_ES3_step_bj_8c0d11d0_1:

    # Judy "Make sure to drop by my office next time you’re around campus. We still have a lot of things to dischuss. D-Dischuss... *Hic*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:500
translate chinese JuR2_ES3_step_bj_e8d23e2b_1:

    # MC "*Sigh* Goodnight mommy- I mean, Judy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES3_home.rpy:502
translate chinese JuR2_ES3_step_bj_ac60c103_1:

    # Judy "Haha, g’night! (It was a good session... Time to finally get a glass of wine.)"
    Judy ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_ES3_home.rpy:394
    old "Cum in Judy’s mouth."
    new ""

    # game/scripts/Ju_scenes/JuR2_ES3_home.rpy:394
    old "Cum on Judy’s face."
    new ""

