﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:222
translate chinese JuR2_ES5_step1_f7970037:

    # MC "(I wonder what Judy meant when she talked about cutting-edge therapy techniques.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:223
translate chinese JuR2_ES5_step1_9e3f43aa:

    # MC "(She’s already sucked my dick and fucked me, so I’m not really sure what else there is that she could do. Maybe she could ride me without a condom?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:225
translate chinese JuR2_ES5_step1_5b3eeb8f:

    # MC "(Ugh, it doesn’t matter anyway. I really need to talk to her about what happened with [Dad_name]. I can’t get distracted with sex this time!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:228
translate chinese JuR2_ES5_step1_ccfb4b48:

    # Mom "Once again, thank you soooo much, Judy. You have no idea how much I appreciate it."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:233
translate chinese JuR2_ES5_step1_1be05521:

    # Judy "Just pick up the phone, anytime. I’m always available for a quick chat."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:234
translate chinese JuR2_ES5_step1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:237
translate chinese JuR2_ES5_step1_a6b87eff:

    # MC "M-Mom?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:239
translate chinese JuR2_ES5_step1_2eb0eb69:

    # MC "L-Linda?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:240
translate chinese JuR2_ES5_step1_f7d399c7:

    # Mom "Really, Judy, I can’t thank you enough. For everything. You’re my one true friend, I can’t think of anyone else I can trust quite like you."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:241
translate chinese JuR2_ES5_step1_46371ba2:

    # Judy "Awk, you’re being far too kind, Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:243
translate chinese JuR2_ES5_step1_00ddad3b:

    # Mom "Oh, hi sweetie! I didn’t see you there."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:244
translate chinese JuR2_ES5_step1_8b13a2d2:

    # MC "What are YOU doing here?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:245
translate chinese JuR2_ES5_step1_d8117194:

    # Mom "I was about to ask you the same thing, [player_name]."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:246
translate chinese JuR2_ES5_step1_cc5e6e58:

    # Judy "Ah, [player_name] and I have been doing some additional private therapy sessions at my place. I told him to swing by this evening."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:248
translate chinese JuR2_ES5_step1_4a07278a:

    # Mom "Don’t just stand there. C’mon and join us!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:250
translate chinese JuR2_ES5_step1_0f76e37b:

    # MC "(Is mom getting private therapy from Judy too? She never mentioned that to me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:252
translate chinese JuR2_ES5_step1_9bab15e8:

    # MC "(Is Linda getting private therapy from Judy too? She never mentioned that to me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:254
translate chinese JuR2_ES5_step1_16b514db:

    # MC "So, Judy’s treating you too?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:255
translate chinese JuR2_ES5_step1_515d08bf:

    # Mom "No, I just wanted to come by and chat with Judy as a friend. I kinda just needed someone to vent to after what happened with Bob the other night."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:256
translate chinese JuR2_ES5_step1_dfc8d11a:

    # MC "Oh God, don’t remind me. I’m still feeling sick to my stomach over it."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:257
translate chinese JuR2_ES5_step1_d5576022:

    # Mom "Everything’s gonna be fine, I promise. C’mere and give me a kiss."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:258
translate chinese JuR2_ES5_step1_9de9509d:

    # MC "Right in front of..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:260
translate chinese JuR2_ES5_step1_31a9bb34:

    # Mom "*Whispered* Oh please, Judy already knows."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:261
translate chinese JuR2_ES5_step1_5a295a5a:

    # MC "*Whispered* You’re okay with her seeing us-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:262
translate chinese JuR2_ES5_step1_24df2e7f:

    # Mom "*Whispered* Let her watch."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:265
translate chinese JuR2_ES5_step1_ed7f8b6b:

    # MC "*Whispered* I’m sorry, mom. I think I’ve really fucked things up with dad."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:267
translate chinese JuR2_ES5_step1_60f60201:

    # MC "*Whispered* I’m sorry, Linda. I think I’ve really fucked things up with Bob."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:268
translate chinese JuR2_ES5_step1_474d22da:

    # Mom "Shush, nothing we can’t solve. Now stop worrying and kiss me."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:270
translate chinese JuR2_ES5_step1_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:271
translate chinese JuR2_ES5_step1_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:273
translate chinese JuR2_ES5_step1_8272c7cc:

    # Judy "Aww, how sweet."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:274
translate chinese JuR2_ES5_step1_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:276
translate chinese JuR2_ES5_step1_7d7a1f8d:

    # Judy "(Bob has proven to be a bit of a fly in the soup - but aside from that, things are right on track.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:277
translate chinese JuR2_ES5_step1_873a6642:

    # Judy "(Let’s see if I can keep things moving.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:279
translate chinese JuR2_ES5_step1_39b40be4:

    # MC "What are your plans now, [Mom_name]?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:280
translate chinese JuR2_ES5_step1_416a499c:

    # Mom "I was just about to head back home."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:281
translate chinese JuR2_ES5_step1_903e0865:

    # Judy "You know, in my professional opinion, it would definitely be beneficial for you to join [player_name] in a group therapy session, Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:282
translate chinese JuR2_ES5_step1_35741d97:

    # Mom "Really?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:283
translate chinese JuR2_ES5_step1_5248d7f9:

    # Judy "Of course it would. I am one of the greatest therapists of all time, after all."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:306
translate chinese JuR2_ES5_step2_72646bc3:

    # Judy "Please, [player_name], take a seat."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:308
translate chinese JuR2_ES5_step2_7c9c602e:

    # Judy "Your mom has already been very forthcoming about what she would like to get, out of this session."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:310
translate chinese JuR2_ES5_step2_f67c8d6d:

    # Judy "Linda has already been very forthcoming about what she would like to get, out of this session."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:314
translate chinese JuR2_ES5_step2_3053bbb3:

    # Judy "I’m hoping that you can be equally honest and open with me. Especially given what she has explained to me about the current situation with your father."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:316
translate chinese JuR2_ES5_step2_f18cb1b6:

    # Judy "I’m hoping that you can be equally honest and open with me. Especially given what she has explained to me about the current situation with Bob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:317
translate chinese JuR2_ES5_step2_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:318
translate chinese JuR2_ES5_step2_6b503cf1:

    # Judy "I can tell you’re nervous, [player_name]. Just take a seat and try to relax. This is going to be a place to share your feelings and heal."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:322
translate chinese JuR2_ES5_step2_66fc6789:

    # MC "(Holy shit! [Mom_name]’s areolae are showing! I don’t think she realises that her top is a bit too loose for her!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:323
translate chinese JuR2_ES5_step2_25eb496d:

    # Mom "Try to relax, Sweetie. We’re going to talk with Judy, and she’ll guide us through a group therapy session."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:324
translate chinese JuR2_ES5_step2_c8e45674:

    # MC "O-Okay."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:328
translate chinese JuR2_ES5_step2_fd5389da:

    # Mom "I’ve known Judy for most of my life. You can trust her - even with something as difficult as what happened with your dad."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:330
translate chinese JuR2_ES5_step2_99850bea:

    # Mom "I’ve known Judy for most of my life. You can trust her - even with something as difficult as what happened with Bob."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:331
translate chinese JuR2_ES5_step2_d115703f:

    # MC "*Sigh* Alright, let’s get this over with."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:335
translate chinese JuR2_ES5_step2_9320c50e:

    # Judy "Good. Right, I think now is a good time to make a start."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:337
translate chinese JuR2_ES5_step2_0e1aa590:

    # Judy "One of the strengths of group therapy is that you can rely on support from other participants of the group. In your case [player_name], that would be your mom."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:339
translate chinese JuR2_ES5_step2_53e0dab3:

    # Judy "One of the strengths of group therapy is that you can rely on support from other participants of the group. In your case, [player_name], that would be Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:340
translate chinese JuR2_ES5_step2_4d113ffa:

    # Judy "How about we start by establishing a nice strong bond between the two of you? Linda and [player_name], would you turn to face each other and stare into each others’ eyes?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:344
translate chinese JuR2_ES5_step2_085dd616:

    # Judy "That’s perfect. Just like that. I really want you to try and make a connection with each other, on a deep emotional level."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:345
translate chinese JuR2_ES5_step2_6b034c36:

    # Judy "Think about some happy memories you have shared with each other. Try and list three positive traits about this person, in your mind."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:347
translate chinese JuR2_ES5_step2_b6ad1791:

    # MC "(Positive traits about my mom? She’s... confident. She’s sexy. She’s... really fun to be around.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:349
translate chinese JuR2_ES5_step2_b4fd763b:

    # MC "(Positive traits about Linda? She’s... confident. She’s sexy. She’s... really fun to be around.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:350
translate chinese JuR2_ES5_step2_9c12f518:

    # Judy "Have you both completed that exercise?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:351
translate chinese JuR2_ES5_step2_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:352
translate chinese JuR2_ES5_step2_8d3e3a1c:

    # Mom "Yes."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:353
translate chinese JuR2_ES5_step2_8da19b99:

    # Judy "Good. Now, I want both of you to reach out and hold hands."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:357
translate chinese JuR2_ES5_step2_3d4851fb:

    # MC "This seems like a rather unorthodox type of group therapy, Judy. Kinda feels more like couple’s counselling."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:358
translate chinese JuR2_ES5_step2_e1f0caa9:

    # Judy "That’s because I’m not an orthodox therapist, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:359
translate chinese JuR2_ES5_step2_223d6998:

    # Mom "Just go along with it, [player_name]. Please. For me."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:363
translate chinese JuR2_ES5_step2_2300ff56:

    # MC "Alright, [Mom_name]."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:364
translate chinese JuR2_ES5_step2_6e855956:

    # Mom "Thank you, Sweetie."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:368
translate chinese JuR2_ES5_step2_3962739b:

    # MC "So, what’s next, Judy? You want us to start making out?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:369
translate chinese JuR2_ES5_step2_5b9aa1de:

    # Mom "[player_name]! Haha! Take it seriously!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:370
translate chinese JuR2_ES5_step2_39c72d7e:

    # MC "Heh, sorry, just trying to lighten the mood. I feel like we’re not addressing the elephant in the room."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:374
translate chinese JuR2_ES5_step2_3c38304f:

    # Mom "[player_name] is right, Judy. We need to start talking about my husband."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:375
translate chinese JuR2_ES5_step2_fed9a477:

    # Mom "I don’t really know how either of us can go back home without a clear plan, for how we’re going to deal with this."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:379
translate chinese JuR2_ES5_step2_bfda7166:

    # Judy "Absolutely, Linda. How about you both start off by telling me EXACTLY what happened."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:380
translate chinese JuR2_ES5_step2_7a2cd9ce:

    # Judy "I’m going to stay quiet and listen to you, for the most part, but if I feel any critical information is missing, then I might jump in with some questions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:381
translate chinese JuR2_ES5_step2_d6783828:

    # Mom "Thanks, Judy. *Sigh* Where to begin?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:387
translate chinese JuR2_ES5_step2_54b3ac72:

    # Judy "Well, how about we start with the facts? What EXACTLY happened with Bob?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:391
translate chinese JuR2_ES5_step2_ccb51dbe:

    # MC "[Mom_name] and I were... uh... we were... fooling around in bed together."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:392
translate chinese JuR2_ES5_step2_c23ccb00:

    # Mom "What [player_name] means to say is: that we were fucking. Bob walked in on us."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:393
translate chinese JuR2_ES5_step2_d78d3805:

    # Judy "Oh my... What was his reaction?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:394
translate chinese JuR2_ES5_step2_b0902bc5:

    # Mom "God... It was... I felt like there was a lead weight in my stomach."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:398
translate chinese JuR2_ES5_step2_ccbc032a:

    # Mom "I was THIS close to throwing him out of the house. I mean, I FINALLY had a chance to spend some proper quality time with a man who makes me happy and the bumbling oaf stumbles in and ruins it!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:402
translate chinese JuR2_ES5_step2_fdb3e3da:

    # Judy "I think you need to take a pause, Linda. Kicking Bob out of the family home isn’t going to make anything better."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:404
translate chinese JuR2_ES5_step2_28f4ffca:

    # Judy "I think you need to take a pause, Linda. Kicking Bob out of the matrimonial home isn’t going to make anything better."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:405
translate chinese JuR2_ES5_step2_9a96fcbc:

    # Judy "It isn’t going to win you any points with the judge if this ends in divorce, it isn’t going to make your life easier, and it isn’t going to endear you to Sara or Caroline."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:407
translate chinese JuR2_ES5_step2_13e9c45c:

    # Judy "How do you think they’d feel if you kicked their father out on the street because he caught you making love with his son?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:409
translate chinese JuR2_ES5_step2_596a6fd5:

    # Judy "How do you think they’d react to you kicking out your husband on the street because he caught you making love to one of your tenants?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:413
translate chinese JuR2_ES5_step2_83423133:

    # Mom "*Sigh* Christ... I should have just kept my desires to myself... I’m sorry, [player_name], it was wrong for me to get you tangled up in my taboo desires."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:414
translate chinese JuR2_ES5_step2_28f68383:

    # MC "[Mom_name]! It’s not your fault! I wanted it too! I just didn’t realise it at the start and-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:418
translate chinese JuR2_ES5_step2_3d21800b:

    # Judy "Linda, self-flagellation isn’t helping. Take a few minutes to collect yourself."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:420
translate chinese JuR2_ES5_step2_43297024:

    # Judy "I’d actually like to hear [player_name]’s thoughts on the subject. What do you want to happen to your father, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:422
translate chinese JuR2_ES5_step2_25db7939:

    # Judy "I’d actually like to hear [player_name]’s thoughts on the subject. What do you want to happen to Bob, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:426
translate chinese JuR2_ES5_step2_a7f2edec:

    # MC "Are you asking if I want mom to kick him out of the house?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:428
translate chinese JuR2_ES5_step2_44d28b53:

    # MC "Are you asking if I want Linda to kick him out of the house?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:429
translate chinese JuR2_ES5_step2_1f45132a:

    # Judy "Is that something you want?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:431
translate chinese JuR2_ES5_step2_200d866a:

    # MC "I... I don’t think so. He’s not a bad dad. He’s just..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:433
translate chinese JuR2_ES5_step2_7185fa1c:

    # MC "I... I don’t think so. He’s not a bad man. He’s just..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:437
translate chinese JuR2_ES5_step2_d327971c:

    # Mom "...getting in the way of our happiness."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:441
translate chinese JuR2_ES5_step2_aaffb7ba:

    # Judy "Linda, that kind of interruption isn’t helpful. Let [player_name] speak."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:442
translate chinese JuR2_ES5_step2_dbeb1c11:

    # Mom "*Sigh*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:446
translate chinese JuR2_ES5_step2_f263e397:

    # MC "I’m just trying to say, this whole thing would be easier if he wasn’t such a great dad. He’s always there when I need him. He’s always trying to help me."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:448
translate chinese JuR2_ES5_step2_d565136a:

    # MC "I’m just trying to say, this whole thing would be easier if he wasn’t such a great man. He’s always there when I need him. He’s always trying to help me."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:449
translate chinese JuR2_ES5_step2_6c212eab:

    # MC "I don’t really want him to leave..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:453
translate chinese JuR2_ES5_step2_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:457
translate chinese JuR2_ES5_step2_2d41fbf1:

    # Judy "It’s going to be fine, Linda. Kicking Bob out of the house, in my professional opinion, would be a gross overreaction."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:458
translate chinese JuR2_ES5_step2_d36bb259:

    # Mom "Really? What makes you think that?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:459
translate chinese JuR2_ES5_step2_fd7a0035:

    # Judy "Trust me, Linda. I’ve spoken to a lot of men during my line of work. You wouldn’t believe the secrets that they hide from their wives."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:460
translate chinese JuR2_ES5_step2_fe0a1c49:

    # Mom "I don’t quite understand what you’re-"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:464
translate chinese JuR2_ES5_step2_894da832:

    # Judy "Just trust me. Give Bob some time and see who he wants to talk to first."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:465
translate chinese JuR2_ES5_step2_837d7835:

    # Mom "Huh?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:469
translate chinese JuR2_ES5_step2_d0d3933f:

    # Judy "I’ve got a feeling that Bob may try to reach out to [player_name], rather than yourself, Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:470
translate chinese JuR2_ES5_step2_23e4b547:

    # Mom "Hmm, I’ll give you the benefit of the doubt, Judy - but if he hasn’t approached either of us by next week, then I’m kicking him out."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:474
translate chinese JuR2_ES5_step2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:475
translate chinese JuR2_ES5_step2_77f1fcc3:

    # Judy "I wouldn’t advise that, Linda. Just stick with me on this one."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:476
translate chinese JuR2_ES5_step2_08d2e1e7:

    # Mom "You’re an enigma, Judy. You know that?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:480
translate chinese JuR2_ES5_step2_1a0d8fc1:

    # Judy "I can’t help it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:481
translate chinese JuR2_ES5_step2_93dedf2a:

    # Mom "You’re not even going to drop a hint about what you’re up to, are you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:482
translate chinese JuR2_ES5_step2_9070c004:

    # Judy "Silence is golden, Linda. Silence is golden."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:486
translate chinese JuR2_ES5_step2_7d6fd853:

    # Mom "Heh... You never change."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:494
translate chinese JuR2_ES5_step2_54b3ac72_1:

    # Judy "Well, how about we start with the facts? What EXACTLY happened with Bob?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:498
translate chinese JuR2_ES5_step2_ccb51dbe_1:

    # MC "[Mom_name] and I were... uh... we were... fooling around in bed together."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:499
translate chinese JuR2_ES5_step2_79d947ff:

    # Mom "What [player_name] means to say is that we were fucking. Bob walked in on us."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:500
translate chinese JuR2_ES5_step2_d78d3805_1:

    # Judy "Oh my... What was his reaction?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:504
translate chinese JuR2_ES5_step2_00d34f3c:

    # Mom "We were lucky I was covered with the bedsheets when Bob walked in. As far as he knows you could have been sleeping with ANYBODY!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:508
translate chinese JuR2_ES5_step2_fcd05c0f:

    # Judy "Oh really? You believe Bob is that naive?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:512
translate chinese JuR2_ES5_step2_9c4bfd0d:

    # Mom "Yes, I do. He’s a bumbling oaf, for Christ’s sake!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:516
translate chinese JuR2_ES5_step2_21121a1b:

    # Judy "You and [player_name] were presumably naked, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:517
translate chinese JuR2_ES5_step2_b9068c80:

    # Mom "What?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:518
translate chinese JuR2_ES5_step2_7d13eab7:

    # Judy "When you were having sex. You didn’t have your clothes on?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:519
translate chinese JuR2_ES5_step2_a72dc30f:

    # Mom "Of course not! What kind of question is that?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:523
translate chinese JuR2_ES5_step2_7b43ef04:

    # Judy "Where did you get undressed?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:527
translate chinese JuR2_ES5_step2_98e366a8:

    # Mom "In the bedroom. Where else would we-"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:531
translate chinese JuR2_ES5_step2_de30b54c:

    # Mom "Oh..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:535
translate chinese JuR2_ES5_step2_f508b366:

    # Judy "The first thing Bob saw when he entered the room was [player_name] in bed with someone else. The second thing he would have seen would be..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:536
translate chinese JuR2_ES5_step2_6268f998:

    # Mom "...my clothes spread over the floor."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:537
translate chinese JuR2_ES5_step2_a003f119:

    # MC "*Gulp* Oh shit. Can we be certain that he saw? Maybe he-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:542
translate chinese JuR2_ES5_step2_01208150:

    # Judy "This is probably a slight breach of my obligations to patient confidentiality, but... Bob has been visiting me, Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:543
translate chinese JuR2_ES5_step2_5689973c:

    # Mom "What?!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:544
translate chinese JuR2_ES5_step2_c4dcfa8f:

    # MC "WHAT?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:545
translate chinese JuR2_ES5_step2_154219fc:

    # Judy "I can’t tell you precisely what was discussed, but he knows everything."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:546
translate chinese JuR2_ES5_step2_62a0831a:

    # MC "Oh no..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:550
translate chinese JuR2_ES5_step2_02ba29ab:

    # Mom "What did he say?! He wants the house in the divorce, doesn’t he?! He’s going to try for sole custody of the-"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:552
translate chinese JuR2_ES5_step2_2cf6af97:

    # Mom "What did he say?! He wants the house in the divorce, doesn't he?!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:553
translate chinese JuR2_ES5_step2_4d9d658f:

    # Judy "Linda! Take a deep breath."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:557
translate chinese JuR2_ES5_step2_47b3e986:

    # Judy "I can’t tell you what was discussed. However..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:561
translate chinese JuR2_ES5_step2_85335427:

    # Judy "I would ask that you TRUST me on this matter. I’m keeping an eye out for your interests."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:565
translate chinese JuR2_ES5_step2_37fc07b9:

    # Mom "...Thank you, Judy. I appreciate that."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:569
translate chinese JuR2_ES5_step2_a8934ceb:

    # MC "(I wonder what Judy’s plan is now? She must be manipulating Bob in some way as well.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:579
translate chinese JuR2_ES5_step2_con_f3257757:

    # Judy "Here we go! A quick toast to, what I believe to be, a very productive therapy session."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:580
translate chinese JuR2_ES5_step2_con_9771bf4a:

    # Mom "Ohh, Chateau Petit Lorraine! I haven’t drunk that since university! I thought they discontinued production YEARS ago!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:584
translate chinese JuR2_ES5_step2_con_eb96523e:

    # Judy "They did! I kept a few bottles stashed away for... special occasions. Haha! Remember how we used to get wasted on this stuff?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:585
translate chinese JuR2_ES5_step2_con_72b2b794:

    # Mom "I remember how rough I always felt, the next morning."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:586
translate chinese JuR2_ES5_step2_con_3142a59f:

    # Judy "Oh, c’mon Linda, just one glass for old times’ sake."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:587
translate chinese JuR2_ES5_step2_con_4b302319:

    # Mom "Fine! Go on, then!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:591
translate chinese JuR2_ES5_step2_con_c0bec29d:

    # Mom "You’re incorrigible, Judy, you know that? You haven’t changed a bit."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:592
translate chinese JuR2_ES5_step2_con_825fc494:

    # Mom "Now that I think about it - you were always the one encouraging me to go out drinking, when I should have been studying!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:596
translate chinese JuR2_ES5_step2_con_5c54217e:

    # Judy "Only because you’re a colossal bore when you’re sober!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:600
translate chinese JuR2_ES5_step2_con_034c9bd7:

    # Mom "Ahaha! You cheeky bitch!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:601
translate chinese JuR2_ES5_step2_con_2857d415:

    # Judy "Haha! I miss hanging out like this. We should get together more often."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:604
translate chinese JuR2_ES5_step2_con_7cba4dbb:

    # MC "(It’s really nice seeing [Mom_name] so happy. I never realised just how close Judy and her were.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:606
translate chinese JuR2_ES5_step2_con_3f614495:

    # MC "(This is the way things used to be with mom and Auntie Liza before they drifted apart...)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:608
translate chinese JuR2_ES5_step2_con_cd9c326d:

    # MC "(This is the way things used to be between Linda and Liza before they drifted apart.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:609
translate chinese JuR2_ES5_step2_con_14fbd4bf:

    # Mom "[player_name]?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:613
translate chinese JuR2_ES5_step2_con_ca4adecb:

    # MC "Huh? Yeah?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:614
translate chinese JuR2_ES5_step2_con_aad225cc:

    # Mom "I asked you if you were going to drink that."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:615
translate chinese JuR2_ES5_step2_con_0b793d93:

    # MC "Oh! Sorry, I was daydreaming, there. Haha!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:616
translate chinese JuR2_ES5_step2_con_ebdc7862:

    # Mom "To a successful therapy session!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:620
translate chinese JuR2_ES5_step2_con_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:621
translate chinese JuR2_ES5_step2_con_f5d71fda:

    # MC "To a successful therapy session."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:622
translate chinese JuR2_ES5_step2_con_22e0a907:

    # Judy "Yes, well done both, of you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:627
translate chinese JuR2_ES5_step2_con_9beef527:

    # MC "*Glug* *Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:631
translate chinese JuR2_ES5_step2_con_37bdc53f:

    # MC "Ahh... That wash pretty delihshous... de... delishshoussh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:632
translate chinese JuR2_ES5_step2_con_dd1556dc:

    # MC " That’shh weird... my speecsch ishh all shhluurred..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:636
translate chinese JuR2_ES5_step2_con_5861ee23:

    # MC "[Mom_name]? What’shh going..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:641
translate chinese JuR2_ES5_step2_con_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:642
translate chinese JuR2_ES5_step2_con_a679029e:

    # Judy "And, that’s him gone..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:643
translate chinese JuR2_ES5_step2_con_0863eceb:

    # Mom "Wow, that stuff works quicker than I thought it would!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:644
translate chinese JuR2_ES5_step2_con_932f0ba4:

    # Judy "One of the perks of being a qualified medical practitioner, is you get access to the good stuff."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:648
translate chinese JuR2_ES5_step2_con_b1136be5:

    # Judy "But listen, Linda, you don’t need to worry about anything. Bob has known for a LONG time that he couldn’t satisfy you. He’s accepted that as a fact."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:649
translate chinese JuR2_ES5_step2_con_f23eb551:

    # Mom "*Sigh* I suppose that does make things a little easier."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:650
translate chinese JuR2_ES5_step2_con_603a8b43:

    # Judy "And don’t feel guilty, either. Bob has his own preferences as well - secret desires that you can’t fulfill."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:654
translate chinese JuR2_ES5_step2_con_7869c788:

    # Mom "He does?! He never mentioned anything about them to me!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:655
translate chinese JuR2_ES5_step2_con_acdce1cd:

    # MC "Zzz..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:656
translate chinese JuR2_ES5_step2_con_7858f762:

    # Judy "Of course he didn’t! He was afraid to talk to you, given how aggressive you’ve been towards him lately."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:657
translate chinese JuR2_ES5_step2_con_eb393b0f:

    # Mom "I haven’t been- Ugh, okay, I might have been a BIT aggressive!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:661
translate chinese JuR2_ES5_step2_con_b9f3236b:

    # MC "Why’m... shoo... shleepy... Zzz..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:662
translate chinese JuR2_ES5_step2_con_02881bcd:

    # Mom "I mean, I never tried to talk to Bob because I didn’t even think he could begin to understand anyway! Maybe... maybe I was wrong?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:663
translate chinese JuR2_ES5_step2_con_b719a434:

    # Judy "It’s okay to be wrong. What matters is, admitting it and learning from our mistakes."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:667
translate chinese JuR2_ES5_step2_con_3915c292:

    # Mom "I’ve been a real bitch to Bob, haven’t I?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:668
translate chinese JuR2_ES5_step2_con_1aa9501a:

    # Judy "Yeah, you have. I mean, this could have all been avoided with some decent communication."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:669
translate chinese JuR2_ES5_step2_con_043fbd8c:

    # Judy "But you’re not entirely to blame, and Bob failed to communicate too. Everything will work itself out in time. That’s all this is going to need - some time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:673
translate chinese JuR2_ES5_step2_con_5f444038:

    # Mom "So... You’ve been acting as a therapist to my son, me, and my husband, all at the same time?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:675
translate chinese JuR2_ES5_step2_con_18691939:

    # Mom "So... You’ve been acting as a therapist to me, my husband, AND my tenant, all at the same time?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:676
translate chinese JuR2_ES5_step2_con_acdce1cd_1:

    # MC "Zzz..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:677
translate chinese JuR2_ES5_step2_con_08f974a9:

    # Judy "Yes."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:678
translate chinese JuR2_ES5_step2_con_af357ee6:

    # Mom "That’s one hell of a conflict of interest."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:682
translate chinese JuR2_ES5_step2_con_b5cd4692:

    # Judy "Haha! I know, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:683
translate chinese JuR2_ES5_step2_con_93f5f53d:

    # Judy "All joking aside, Linda, you can trust me. I promise. I might have concealed some parts of the truth from you, but I never once lied."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:687
translate chinese JuR2_ES5_step2_con_acdce1cd_2:

    # MC "Zzz..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:688
translate chinese JuR2_ES5_step2_con_8ae4b2ab:

    # Mom "I know."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:689
translate chinese JuR2_ES5_step2_con_bddf92f0:

    # Judy "Umm, you can probably put that glass of wine down now. I wouldn’t want you to accidentally drink it and ruin the rest of our night."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:693
translate chinese JuR2_ES5_step2_con_6d86715f:

    # Mom "Good point."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:694
translate chinese JuR2_ES5_step2_con_4904fbd3:

    # Judy "Well, I think it’s time for you to uphold your end of our agreement. Let’s see, in person, just how you did it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:695
translate chinese JuR2_ES5_step2_con_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:696
translate chinese JuR2_ES5_step2_con_ade1849b:

    # Judy "Oh c’mon, Linda. You wouldn’t even be fucking him today if it wasn’t for me! The least you can do is let me watch!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:697
translate chinese JuR2_ES5_step2_con_2e4d133f:

    # Mom "Fine. But then we’re even!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:698
translate chinese JuR2_ES5_step2_con_7a25c048:

    # Judy "Perfect. Let’s go and slip into something more comfortable."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:706
translate chinese JuR2_ES5_step2_con_544a818b:

    # Mom "Wakey wakey, [player_name]."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:707
translate chinese JuR2_ES5_step2_con_e11dad36:

    # MC "Mmm... Hmm?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:708
translate chinese JuR2_ES5_step2_con_1dae3f06:

    # Mom "You’re missing out on the fun."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:710
translate chinese JuR2_ES5_step2_con_a0893d50:

    # MC "Huh?! Wh-What? How did I end up- What are- Where am I?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:711
translate chinese JuR2_ES5_step2_con_f68d3365:

    # MC "What’s going on?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:713
translate chinese JuR2_ES5_step2_con_e2f764bc:

    # Mom "Hush. Relax, Sweetie. Everything is fine."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:714
translate chinese JuR2_ES5_step2_con_d41e7c75:

    # MC "Did she- She drugged me! She spiked my drink!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:715
translate chinese JuR2_ES5_step2_con_c2b168b2:

    # Mom "Of course, she did. We couldn't risk you, freaking out and running away, when we made our proposal. You're not angry because of that?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:717
translate chinese JuR2_ES5_step2_con_4574cb2e:

    # MC "N-No it’s okay... Umm... P-Proposal? What proposal?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:718
translate chinese JuR2_ES5_step2_con_c07bd5b1:

    # Mom "I’m going to fuck you on this bed while Judy watches us."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:720
translate chinese JuR2_ES5_step2_con_ac8885e8:

    # MC "Why does she need to watch us?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:721
translate chinese JuR2_ES5_step2_con_eb915929:

    # MC "And would it not have been easier to communicate this to me when I was awake, rather than having her drug me?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:723
translate chinese JuR2_ES5_step2_con_71a0f6da:

    # Judy "I need it for my research. I’ve hit a... roadblock, so to speak. If I want to complete my final chapters, then I’m going to need to experience the nature of your relationship, first hand."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:725
translate chinese JuR2_ES5_step2_con_1bc5e27e:

    # MC "That still doesn’t explain why you drugged me!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:728
translate chinese JuR2_ES5_step2_con_54bab201:

    # Judy "Well, I needed some privacy to discuss the remit of my research with your mother. In order to avoid any bias on your part, I wanted to make sure you were unaware of the precise elements of your sexual relationship that I would be measuring today."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:729
translate chinese JuR2_ES5_step2_con_a2ef7a8c:

    # Judy "Essentially, your mom will be performing sexual acts on you, while I observe the reactions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:731
translate chinese JuR2_ES5_step2_con_0eeb9a23:

    # Judy "Well, I needed some privacy to discuss the remit of my research with your landlady. In order to avoid any bias on your part, I wanted to make sure you were unaware of the precise elements of your sexual relationship that I would be measuring today."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:732
translate chinese JuR2_ES5_step2_con_de144276:

    # Judy "Essentially, this beautiful MILF will be performing sexual acts on you, while I observe the reactions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:735
translate chinese JuR2_ES5_step2_con_6a39860d:

    # Mom "Try not to be too angry at her, [player_name]. We wouldn’t even be together in the first place if it wasn’t for her pushing us to be together."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:736
translate chinese JuR2_ES5_step2_con_35d52539:

    # MC "Wait a minute - that phone call you had. You were talking to Judy about some kinda deal. THIS was the deal you two arranged, wasn’t it?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:737
translate chinese JuR2_ES5_step2_con_45d35742:

    # MC "She helps you start a relationship with me, and in return she gets all the juicy details to use in her research."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:739
translate chinese JuR2_ES5_step2_con_c5ab3f2f:

    # Judy " Well done, [player_name]. Very astute."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:740
translate chinese JuR2_ES5_step2_con_b63b1654:

    # Judy "But let’s not forget that there is a third party in this mutually beneficial arrangement - you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:742
translate chinese JuR2_ES5_step2_con_367bdb09:

    # Judy "Do you have any idea how many perverts there are in the world that fantasise about doing what you are right now? Do you have any idea how many horny guys would LOVE to have their mother straddling them, the way she is doing to you this very minute?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:744
translate chinese JuR2_ES5_step2_con_d3558431:

    # Judy "Do you have any idea how many perverts there are in the world that fantasise about doing what you are right now? Do you have any idea how many horny guys would LOVE to have a MILF straddling them, the way she is doing to you this very minute?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:745
translate chinese JuR2_ES5_step2_con_7dc87762:

    # Judy "You’re angry at being manipulated, I understand that. But you’d be lying if you said you hadn’t been enjoying it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:746
translate chinese JuR2_ES5_step2_con_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:747
translate chinese JuR2_ES5_step2_con_70c16a03:

    # MC "(She’s right. This has been one of the best years of my life, so far!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:748
translate chinese JuR2_ES5_step2_con_f85f6d8d:

    # Judy "Now, how about we get things started? As sexy as your black lingerie is, Linda, I’m going to have to ask you to remove it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:750
translate chinese JuR2_ES5_step2_con_a0dfb5db:

    # Mom "*Whispered* I’m sorry about this, [player_name]. I know Judy can be a bit eccentric, but there was nobody else I knew who could have helped me start a romantic relationship with you."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:751
translate chinese JuR2_ES5_step2_con_dd455368:

    # MC "*Sigh* I understand, [Mom_name]."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:752
translate chinese JuR2_ES5_step2_con_f5b58216:

    # MC "Alright, let’s get you out of those clothes."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:754
translate chinese JuR2_ES5_step2_con_fc5ed050:

    # Judy "Mmm, perfect. I’m going to take a step back at this point and allow the scene to unfold naturally."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:755
translate chinese JuR2_ES5_step2_con_8bc80cf4:

    # Judy "Just do whatever feels right. Pretend that I’m not here."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:757
translate chinese JuR2_ES5_step2_con_4e59b1ee:

    # Mom "Well, Sweetie, shall we start with me riding your cock?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:758
translate chinese JuR2_ES5_step2_con_5dd0c807:

    # MC "Uh, yeah! Sounds good to me!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:760
translate chinese JuR2_ES5_step2_con_b3efe381:

    # Judy "(Oh my... She’s already soaking wet for him. His cock just slipped inside her so easily.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:761
translate chinese JuR2_ES5_step2_con_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:762
translate chinese JuR2_ES5_step2_con_dc1eee29:

    # Mom "Ah..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:764
translate chinese JuR2_ES5_step2_con_d533661e:

    # Mom "Ahh... Let’s get it deeper inside."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:765
translate chinese JuR2_ES5_step2_con_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:766
translate chinese JuR2_ES5_step2_con_81f13909:

    # Mom "Ooohh! That’s the spot! Mmm!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:768
translate chinese JuR2_ES5_step2_con_38dd78de:

    # Mom "How does my pussy feel, Sweetie? I want you to describe it to me."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:769
translate chinese JuR2_ES5_step2_con_b1260f20:

    # MC "Ah! Mmm! It’s so ugh... warm and arrghhh... tight! Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:771
translate chinese JuR2_ES5_step2_con_b3ca3812:

    # Mom "You like it when I ride you like this, don’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:773
translate chinese JuR2_ES5_step2_con_cb090fd3:

    # MC "Mmm, yes! It’s amazing."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:775
translate chinese JuR2_ES5_step2_con_0e45fe10:

    # Mom "You love feeling your thick cock buried deep in mommy’s wet cunt, don’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:777
translate chinese JuR2_ES5_step2_con_0ce47933:

    # Mom "You love feeling your thick cock, buried, deep in my wet cunt, don’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:779
translate chinese JuR2_ES5_step2_con_59205754:

    # MC "*Pant* Y-Yes! Ah! Keep riding my cock like that, [Mom_name]! Hnnng!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:781
translate chinese JuR2_ES5_step2_con_31ec9d2b:

    # Judy "(My, my! The dirty talk between them is of a far greater intensity than I predicted it would be. I’ll need to make a note of that.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:783
translate chinese JuR2_ES5_step2_con_e8d34277:

    # MC "*Pant* Can you go faster, [Mom_name]?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:784
translate chinese JuR2_ES5_step2_con_cf21d3f5:

    # Mom "Ah! Of course, Sweetie! Mmm! Ah!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:786
translate chinese JuR2_ES5_step2_con_aa18bc81:

    # Mom "*Pant* How’s that? Ah! Ah!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:787
translate chinese JuR2_ES5_step2_con_eb8f58dd:

    # MC "Ohh! S-So fucking good, [Mom_name]! Mmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:788
translate chinese JuR2_ES5_step2_con_f9d80192:

    # Mom "Stay right there, baby. I’m going to try and mmm... take your cock deeper!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:790
translate chinese JuR2_ES5_step2_con_b3dfa1fc:

    # MC "Ooooohhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:791
translate chinese JuR2_ES5_step2_con_a52998cb:

    # Mom "Ahh! Yeesss!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:793
translate chinese JuR2_ES5_step2_con_4ed86bb8:

    # Mom "(I can feel his cock stretching me out! God, he’s SOOO much bigger than Bob!)"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:795
translate chinese JuR2_ES5_step2_con_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:796
translate chinese JuR2_ES5_step2_con_fddeac1d:

    # Judy "(I suppose I better take off my panties too. They’re getting in the way of my research.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:797
translate chinese JuR2_ES5_step2_con_baf4d1fa:

    # Mom "Mmm! You’re so fucking big, [player_name]! Yes! Ooohhh!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:798
translate chinese JuR2_ES5_step2_con_b5748c95:

    # MC "Hnnng! How about *pant* we try reverse cowgirl next?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:799
translate chinese JuR2_ES5_step2_con_83ab64ff:

    # Mom "Sure, why not?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:801
translate chinese JuR2_ES5_step2_con_9d69e67b:

    # Mom "Ah! Ah! Ahhh!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:803
translate chinese JuR2_ES5_step2_con_23337dee:

    # Judy "Mmm... (I wish I was Linda right now. Feeling my own son’s cock thrusting, deep into my soaking wet pussy.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:805
translate chinese JuR2_ES5_step2_con_db4b6125:

    # Judy "Mmm... (I wish I was Linda right now. Feeling a strapping young man’s cock thrusting, deep into my soaking wet pussy.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:807
translate chinese JuR2_ES5_step2_con_ad3bbdfd:

    # Judy "(I’d be cumming my brains out, every time he slammed his dick into me.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:808
translate chinese JuR2_ES5_step2_con_0de9c41f:

    # Judy "*Pant* Ah... Oh..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:811
translate chinese JuR2_ES5_step2_con_1eb46f0b:

    # Mom "Yes! Yes! Don’t stop! Ahh! Fuck me! Fuck my wet pussy! Ahhh! Squeeze my boobs! Tighter! Aaahhhh! Fuuuuck! I’m cummming! My baby boy’s cock is making me cum!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:813
translate chinese JuR2_ES5_step2_con_4bce33c5:

    # Mom "Yes! Yes! Don’t stop! Ahh! Fuck me! Fuck my wet pussy! Ahhh! Squeeze my boobs! Tighter! Aaahhhh! Fuuuuck! I’m cummming! Your big cock is making me cum!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:814
translate chinese JuR2_ES5_step2_con_e455c4ae:

    # MC "Aaahhhh! *PANT* Hnnnggg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:816
translate chinese JuR2_ES5_step2_con_810c491b:

    # Judy "Ohh... Mmmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:817
translate chinese JuR2_ES5_step2_con_ac4bb8ef:

    # MC "(It sounds like Judy is doing a bit more than just observing us!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:819
translate chinese JuR2_ES5_step2_con_31b8009e:

    # MC "Ah! Hnnngg! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:821
translate chinese JuR2_ES5_step2_con_6446d4bc:

    # Mom "Ohhhh fuuuuckk! Yeessss! Your cock is so fucking big!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:824
translate chinese JuR2_ES5_step2_con_2eeb52f3:

    # Mom "Ah! AHH! Ooohhh! It feels sooooo good! Don’t stop, Sweetie! Ah! Keep pounding your mommy’s pussy! Ahhhh!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:826
translate chinese JuR2_ES5_step2_con_556dc59e:

    # Mom "Ah! AHH! Ooohhh! It feels sooooo good! Don’t stop, Sweetie! Ah! Keep pounding my pussy! Ahhhh!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:827
translate chinese JuR2_ES5_step2_con_81ed25de:

    # MC "Hnnng! Ugh! Aarrghhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:828
translate chinese JuR2_ES5_step2_con_13846cab:

    # MC "(She’s riding me like crazy, right now! I don’t think I’ve ever seen her this horny before!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:831
translate chinese JuR2_ES5_step2_con_9bc0d8ce:

    # Judy "Mmm... That’s it... Keep bouncing on your son’s dick."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:833
translate chinese JuR2_ES5_step2_con_71eda876:

    # Judy "Mmm... That’s it... Keep bouncing on his dick."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:834
translate chinese JuR2_ES5_step2_con_38ef8b42:

    # Mom "Ah! Ah! Ah!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:836
translate chinese JuR2_ES5_step2_con_33a258c8:

    # Judy "Take him, balls-deep, inside you. Mmm, that’s it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:838
translate chinese JuR2_ES5_step2_con_4ab160c2:

    # MC "Ah! Ooohh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:839
translate chinese JuR2_ES5_step2_con_851afe35:

    # Judy "(Fuck, I’m dripping wet, right now. I’m so horny, I can barely concentrate!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:841
translate chinese JuR2_ES5_step2_con_6f09250b:

    # Judy "Linda, I have a proposition for you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:842
translate chinese JuR2_ES5_step2_con_28993424:

    # Mom "Ah! Ahh! Uh huh?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:843
translate chinese JuR2_ES5_step2_con_5f22a7b0:

    # Judy "How would you feel about me conducting... some hands-on research?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:845
translate chinese JuR2_ES5_step2_con_0aa7d01c:

    # Mom "You want to get involved as well?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:846
translate chinese JuR2_ES5_step2_con_d270457d:

    # Judy "Yes, if you don’t mind. I think it would be very useful for my research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:847
translate chinese JuR2_ES5_step2_con_f269cd80:

    # Mom "Uh huh. It’s for your research, and DEFINITELY not because you’re horny? I can hear you fingering yourself, over there!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:849
translate chinese JuR2_ES5_step2_con_25d8fd0f:

    # Judy "If you’d rather I didn’t-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:851
translate chinese JuR2_ES5_step2_con_5b698911:

    # Mom "No, don’t worry. This could be fun. Let’s give it a go."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:853
translate chinese JuR2_ES5_step2_con_f61d2bb6:

    # Mom "I better not catch you looking at her more than you look at me, or I’ll scratch your eyes out, [player_name]."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:855
translate chinese JuR2_ES5_step2_con_0a38bb0e:

    # MC "What?! I wasn’t! I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:856
translate chinese JuR2_ES5_step2_con_28e2f3b2:

    # Mom "I’m just kidding. Probably."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:858
translate chinese JuR2_ES5_step2_con_2ad72812:

    # Mom "How about we start with a double blowjob?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:859
translate chinese JuR2_ES5_step2_con_223aa2d8:

    # Judy "Yeah, I think [player_name] would enjoy having two busty women sucking on his dick at the same time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:861
translate chinese JuR2_ES5_step2_con_33506b27:

    # Judy "How long do you think he’s actually going to last though? I think two mouths slurping at his cock might prove too much for him to handle."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:862
translate chinese JuR2_ES5_step2_con_731f4630:

    # MC "Pfft! I call a double blowjob ‘easy mode’."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:863
translate chinese JuR2_ES5_step2_con_41e4f52f:

    # Mom "Oh really? You’re not going to blow your load before we reach the best part of this threesome, are you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:865
translate chinese JuR2_ES5_step2_con_f21077fc:

    # MC "Of course not, I’m- Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:866
translate chinese JuR2_ES5_step2_con_8b08430c:

    # Judy "*Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:867
translate chinese JuR2_ES5_step2_con_730087d3:

    # Mom "Are you SURE about that? Because you reacted PRETTY loudly to Judy dragging her tongue up your shaft."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:868
translate chinese JuR2_ES5_step2_con_dff767fb:

    # MC "*Pant* I’m sure. I’m not gonna cum that easily!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:869
translate chinese JuR2_ES5_step2_con_180c75ca:

    # Mom "Oh, in that case it’s probably better if I join in on the fun."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:871
translate chinese JuR2_ES5_step2_con_8c20f667:

    # Mom "*Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:872
translate chinese JuR2_ES5_step2_con_8b08430c_1:

    # Judy "*Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:873
translate chinese JuR2_ES5_step2_con_11a48a93:

    # MC "Mmm... *Gasp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:874
translate chinese JuR2_ES5_step2_con_732c55c9:

    # Mom "*Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:875
translate chinese JuR2_ES5_step2_con_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:877
translate chinese JuR2_ES5_step2_con_021cd3ef:

    # MC "Ah... *Pant*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:878
translate chinese JuR2_ES5_step2_con_dca0e385:

    # MC "(The feeling of their tongues caressing my cock is amazing! Linda mentioned that there was going to be a “best part” of this threesome. I just have to try and hold on until then.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:879
translate chinese JuR2_ES5_step2_con_f98d1493:

    # MC "*Pant* Oooh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:881
translate chinese JuR2_ES5_step2_con_59c6b45f:

    # MC "(C’mon [player_name], you can endure this!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:882
translate chinese JuR2_ES5_step2_con_8c20f667_1:

    # Mom "*Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:883
translate chinese JuR2_ES5_step2_con_664be69b:

    # Judy "Mmm! *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:885
translate chinese JuR2_ES5_step2_con_27ce931d:

    # MC "*Gasp* Ah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:886
translate chinese JuR2_ES5_step2_con_39920c18:

    # Mom "*Lick* *Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:887
translate chinese JuR2_ES5_step2_con_b318f413:

    # MC "(Shit! I can feel my dick tingling when Linda flicks her tongue across my glans like that! It’s way too sensitive!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:890
translate chinese JuR2_ES5_step2_con_9544d3ec:

    # Judy "Well? What do you think, Linda? Are you proud of how long your boy is lasting?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:892
translate chinese JuR2_ES5_step2_con_576d304f:

    # Judy "Well? What do you think, Linda? Are you proud of how long your man is lasting?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:893
translate chinese JuR2_ES5_step2_con_2b2f391f:

    # Mom "He DID say it was ‘easy mode’, so perhaps we should up the difficulty a bit? Let’s see if he’s still that confident with both of us sucking his fat shaft."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:895
translate chinese JuR2_ES5_step2_con_a5868d30:

    # Mom "*Shlurp*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:897
translate chinese JuR2_ES5_step2_con_cd6732d3:

    # MC "Ahmmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:900
translate chinese JuR2_ES5_step2_con_e07aba17:

    # Judy "Oh, you like that, don’t you? I bet mommy’s lips feel REALLY good when they’re wrapped around your dick like that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:902
translate chinese JuR2_ES5_step2_con_49971236:

    # Judy "Oh, you like that, don’t you? I bet Linda's lips feel REALLY good when they’re wrapped around your dick like that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:903
translate chinese JuR2_ES5_step2_con_cdfb052a:

    # Mom "*Suck* *Shlurp*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:905
translate chinese JuR2_ES5_step2_con_3698d5ce:

    # MC "*Pant* Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:906
translate chinese JuR2_ES5_step2_con_9d581cc2:

    # Judy "She’s probably swirling her tongue around the tip too, isn’t she? God, that must feel SOOO intense right now."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:908
translate chinese JuR2_ES5_step2_con_12651982:

    # Mom "*SUCK* *SUCK* *SHLUURRRP*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:909
translate chinese JuR2_ES5_step2_con_56dc5a0b:

    # MC "Hnnnnnnnggg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:910
translate chinese JuR2_ES5_step2_con_bab6c43f:

    # Judy "You’re probably pretty close to cumming right now, aren’t you? Just remember, that if you waste your shot now, then you’re going to miss out on the main event."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:911
translate chinese JuR2_ES5_step2_con_a2b3f7ad:

    # MC "*Pant* I’m not- *Gasp* not going to-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:912
translate chinese JuR2_ES5_step2_con_1cab96ed:

    # Mom "*Suck* *Suck*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:913
translate chinese JuR2_ES5_step2_con_e206ed83:

    # MC "OOOHHH!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:915
translate chinese JuR2_ES5_step2_con_4b3b88cc:

    # Judy "Would you mind if I took a turn sucking your son’s shaft, Linda?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:917
translate chinese JuR2_ES5_step2_con_e7c009c1:

    # Judy "Would you mind if I took a turn sucking his shaft, Linda?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:918
translate chinese JuR2_ES5_step2_con_220a5544:

    # Mom "Mmm hmm! *Shluuurrp*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:921
translate chinese JuR2_ES5_step2_con_a692599a:

    # Mom "*Pant* Ahh... I can already taste your precum. You’re absolutely loving having your mommy suck your cock, aren’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:923
translate chinese JuR2_ES5_step2_con_896c1653:

    # Mom "*Pant* Ahh... I can already taste your precum. You’re absolutely loving having your landlady suck your cock, aren’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:925
translate chinese JuR2_ES5_step2_con_d26e3a53:

    # MC "*Pant* Mmmm.... Hnnnggg..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:927
translate chinese JuR2_ES5_step2_con_1777f573:

    # Mom "Tell me, is Judy’s blowjob as good as mine?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:928
translate chinese JuR2_ES5_step2_con_18ae769c:

    # Judy "*Suck* *Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:931
translate chinese JuR2_ES5_step2_con_7f71411b:

    # MC "I *Gasp* don’t think I should ah... c-compare them-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:934
translate chinese JuR2_ES5_step2_con_1e6479c9:

    # Mom "Don’t worry, I won’t be offended. Just tell me who the better cocksucker is - your therapist, or your mommy?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:936
translate chinese JuR2_ES5_step2_con_e484f261:

    # Mom "Don’t worry, I won’t be offended. Just tell me who the better cocksucker is - your therapist, or your landlady?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:937
translate chinese JuR2_ES5_step2_con_e90d1a1a:

    # MC "I- I like you both ahh... equally!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:938
translate chinese JuR2_ES5_step2_con_69513d0f:

    # Judy "*SHLURP* *Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:939
translate chinese JuR2_ES5_step2_con_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:941
translate chinese JuR2_ES5_step2_con_49c8cc25:

    # Mom "Both equally? Smart answer."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:942
translate chinese JuR2_ES5_step2_con_00ba94b6:

    # Judy "*Shlurp* *Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:943
translate chinese JuR2_ES5_step2_con_935ce855:

    # MC "Hnnnng! When are- *Pant* we getting to the main event?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:945
translate chinese JuR2_ES5_step2_con_273ad341:

    # Mom "In a while. Your therapist still has some more sucking to do - don’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:946
translate chinese JuR2_ES5_step2_con_36213f7c:

    # Judy "*Suuuuuck* Mmm hmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:947
translate chinese JuR2_ES5_step2_con_10b98fac:

    # MC "Oooh! *Gasp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:948
translate chinese JuR2_ES5_step2_con_61523ed2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:949
translate chinese JuR2_ES5_step2_con_c5762288:

    # MC "*Pant* *Pant* (I can’t let them make me cum yet!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:951
translate chinese JuR2_ES5_step2_con_61523ed2_1:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:952
translate chinese JuR2_ES5_step2_con_51a86334:

    # MC "Hnnnnggg! MMMM!!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:953
translate chinese JuR2_ES5_step2_con_690310bf:

    # Judy "*Shluurrrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:955
translate chinese JuR2_ES5_step2_con_80d3fd72:

    # Mom "Okay, I think that’s enough."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:956
translate chinese JuR2_ES5_step2_con_98e46581:

    # Judy "*Suck* *Suck* You were right, Linda, he’s got impressive stamina! I was wondering... Would you mind if I fucked him during the threesome? I think it would be VERY helpful to insert myself, more directly into this research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:957
translate chinese JuR2_ES5_step2_con_921b545d:

    # Mom "Sure, go ahead."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:958
translate chinese JuR2_ES5_step2_con_ca941314:

    # Judy "Great! I think it’s going to be invaluable if I put myself in your shoes, and act as if I AM Linda, for the next part. I’ll just grab a condom and-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:960
translate chinese JuR2_ES5_step2_con_a5a40bdd:

    # MC "Whoa! No condom! If you actually want to step into the role of my mom, then you’re going to have to fuck me the way she does - and that means no condom."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:962
translate chinese JuR2_ES5_step2_con_691938ee:

    # MC "Whoa! No condom! If you actually want to step into the role of Linda, then you’re going to have to fuck me the way she does - and that means no condom."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:963
translate chinese JuR2_ES5_step2_con_de4716f8:

    # Judy "*Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:964
translate chinese JuR2_ES5_step2_con_24b35d05:

    # Mom "He’s right, Judy. We don’t use condoms."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:965
translate chinese JuR2_ES5_step2_con_caef6e3d:

    # Judy "F-Fine. No condom it is. Just make sure you don't finish inside me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:967
translate chinese JuR2_ES5_step2_con_7a338f39:

    # Judy "Did you really have to pick such a convoluted position, Linda? I mean, I can’t even see what’s going on!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:969
translate chinese JuR2_ES5_step2_con_605c36fa:

    # Mom "Hehe, not being able to see what’s happening is half the fun. Besides, this is the only position where I get to make out with my son."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:971
translate chinese JuR2_ES5_step2_con_c883d5fd:

    # Mom "Hehe, not being able to see what’s happening is half the fun. Besides, this is the only position where I get to make out with [player_name]."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:973
translate chinese JuR2_ES5_step2_con_6e6d3ea6:

    # Mom "*Mwah*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:974
translate chinese JuR2_ES5_step2_con_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:975
translate chinese JuR2_ES5_step2_con_e588480a:

    # Judy "It’s just ugh... you’re weighing me down, and if I feel like [player_name] is about to cum, I can’t crawl away quickly."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:977
translate chinese JuR2_ES5_step2_con_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:978
translate chinese JuR2_ES5_step2_con_b7251322:

    # Judy "Linda? Are you even listening to me?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:979
translate chinese JuR2_ES5_step2_con_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:981
translate chinese JuR2_ES5_step2_con_8d8ecc45:

    # Mom "*Whispered* She’s talking way too much. Go ahead and stick it in her."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:982
translate chinese JuR2_ES5_step2_con_710f5f9f:

    # MC "My pleasure."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:984
translate chinese JuR2_ES5_step2_con_e6b56fb7:

    # Judy "I’m just suggesting that we try a position where I have a little more controoooohhhhhl!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:985
translate chinese JuR2_ES5_step2_con_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:987
translate chinese JuR2_ES5_step2_con_b8813655:

    # Judy "(Holy crap! His bare cock feels amazing! Oh God! The tip is hitting my g-spot, each time he thrusts! Shit! It’s so intense!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:989
translate chinese JuR2_ES5_step2_con_025c758f:

    # Judy "Ah! *GASP* Ohhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:991
translate chinese JuR2_ES5_step2_con_51a86334_1:

    # MC "Hnnnnggg! MMMM!!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:993
translate chinese JuR2_ES5_step2_con_4d0233a6:

    # Judy "*Gasp* Ah! Ahnnnngg! Ohh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:994
translate chinese JuR2_ES5_step2_con_f95b85f7:

    # MC "Hnngg! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:995
translate chinese JuR2_ES5_step2_con_a07f3298:

    # MC "(Judy’s pussy is clamping down around my shaft! She must be cumming already!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:997
translate chinese JuR2_ES5_step2_con_38ebd554:

    # Judy "*Pant* Ah! *Gasp* Oh! Ahh! F-Fuck! I’m cumming! I’m cumming!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:998
translate chinese JuR2_ES5_step2_con_f5e2c260:

    # Judy "AAAHHHHHHH!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:999
translate chinese JuR2_ES5_step2_con_18190eae:

    # Mom "My, my... that was certainly a quick climax."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1000
translate chinese JuR2_ES5_step2_con_933eb952:

    # Judy "He- *Pant* He was- *Pant* thrusting directly into my g-spot at that angle!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1002
translate chinese JuR2_ES5_step2_con_5c3113d8:

    # MC "How about we give Judy a break, [Mom_name]? Maybe switch things up a bit and I’ll fuck you instead?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1003
translate chinese JuR2_ES5_step2_con_83ab64ff_1:

    # Mom "Sure, why not?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1004
translate chinese JuR2_ES5_step2_con_3eed9ac6:

    # Judy "Where should I go, then?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1005
translate chinese JuR2_ES5_step2_con_247caae7:

    # MC "How about you sit on [Mom_name]’s face while I fuck her?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1006
translate chinese JuR2_ES5_step2_con_da5bcda5:

    # Mom "Mmm, I can get behind that."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1008
translate chinese JuR2_ES5_step2_con_8c20f667_2:

    # Mom "*Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1010
translate chinese JuR2_ES5_step2_con_bf420e7d:

    # Judy "*Gasp* Oooh..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1012
translate chinese JuR2_ES5_step2_con_a7d1081f_2:

    # MC "Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1013
translate chinese JuR2_ES5_step2_con_5890fcac:

    # Judy "Mmmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1015
translate chinese JuR2_ES5_step2_con_732c55c9_1:

    # Mom "*Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1016
translate chinese JuR2_ES5_step2_con_4be45041:

    # Judy "(Linda has an incredible tongue! She’s flicking it across my clit!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1018
translate chinese JuR2_ES5_step2_con_c5a20c39:

    # Judy "Ahmmm! Mmmmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1020
translate chinese JuR2_ES5_step2_con_b97d73d3:

    # Mom "*Shlurp* *Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1022
translate chinese JuR2_ES5_step2_con_4a9ca6d1:

    # MC "Hnnngg! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1024
translate chinese JuR2_ES5_step2_con_0a011e86:

    # Judy "Ah! Ahmmmm! Yeesss! Right there! Ahhh! Don’t stop!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1026
translate chinese JuR2_ES5_step2_con_344bad3f:

    # MC "Are you enjoying this, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1027
translate chinese JuR2_ES5_step2_con_77bf644b:

    # Judy "Y-Yes! Ahh! Ahhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1029
translate chinese JuR2_ES5_step2_con_7d0688d6:

    # MC "You’re going to cum, from my Mom licking your pussy, aren’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1031
translate chinese JuR2_ES5_step2_con_7582a3c5:

    # MC "You’re going to cum, from Linda licking your pussy, aren’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1032
translate chinese JuR2_ES5_step2_con_58493ac3:

    # Judy "*Gasp* Ah! Y-Yes!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1035
translate chinese JuR2_ES5_step2_con_1325c9bb:

    # MC "Do it. Cum for me. I want to watch you cum while I fuck my Mom’s pussy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1037
translate chinese JuR2_ES5_step2_con_8fddd21d:

    # MC "Do it. Cum for me. I want to watch you cum while I fuck Linda’s pussy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1038
translate chinese JuR2_ES5_step2_con_732c55c9_2:

    # Mom "*Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1040
translate chinese JuR2_ES5_step2_con_04277ae6:

    # Judy "*GASP* Ahh! Ayaaaahhh! I’m- I’m- I’m cummmmiinng!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1042
translate chinese JuR2_ES5_step2_con_4d0a4904:

    # MC "Oohhhh! Hnnngg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1043
translate chinese JuR2_ES5_step2_con_b97d73d3_1:

    # Mom "*Shlurp* *Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1045
translate chinese JuR2_ES5_step2_con_1a1679a5:

    # Judy "AAHHH! F-Fuck! It’s so sensitive! Linda! I can’t- I can’t go any- AAHHHHHH! I’m cumming again! AAAAHHH!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1047
translate chinese JuR2_ES5_step2_con_686d4459:

    # MC "Hnnnggg! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1048
translate chinese JuR2_ES5_step2_con_afa29b0e:

    # Mom "*Lick* OOOHHHH!!!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1050
translate chinese JuR2_ES5_step2_con_5643d9df:

    # MC "Your pussy feel so good, Mom!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1052
translate chinese JuR2_ES5_step2_con_79a6f03c:

    # MC "Your pussy feel so good!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1054
translate chinese JuR2_ES5_step2_con_ee292688:

    # Mom "Mmm! *Lick* Ooohhh! *Shlurp*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1055
translate chinese JuR2_ES5_step2_con_dc7a29ec:

    # Mom "(He’s so deep inside me! I can feel his cock kissing my cervix, each time he thrusts!)"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1056
translate chinese JuR2_ES5_step2_con_e942980c:

    # Judy "Ah! AH! AHHHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1059
translate chinese JuR2_ES5_step2_con_be4f6eb2:

    # MC "(My mom’s soaking wet, right now! My cock’s sliding inside her, so easily!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1061
translate chinese JuR2_ES5_step2_con_10c8f2d2:

    # MC "(Linda’s soaking wet, right now! My cock’s sliding inside her, so easily!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1062
translate chinese JuR2_ES5_step2_con_c79e1644:

    # Judy "Ah! AAAHHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1063
translate chinese JuR2_ES5_step2_con_87e44dd3:

    # Mom "*Shlurp* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1065
translate chinese JuR2_ES5_step2_con_590ef6b6:

    # MC "Hnnngg! I’m about to cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1067
translate chinese JuR2_ES5_step2_con_65189d72:

    # Judy "W-Wait! Can we change position, first? I really want to see you creampie your Mom, up close, when you finish."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1069
translate chinese JuR2_ES5_step2_con_95f692f5:

    # Judy "W-Wait! Can we change position, first? I really want to see you creampie Linda, up close, when you finish."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1070
translate chinese JuR2_ES5_step2_con_8d6a5c5b:

    # Mom "Sure, we can do that."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1073
translate chinese JuR2_ES5_step2_con_405bcdd0:

    # Mom "Oh! Oh! Yes! Fuck me! Just like that! MMM!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1076
translate chinese JuR2_ES5_step2_con_c5f3a95e:

    # MC "Ugh! Arrghh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1078
translate chinese JuR2_ES5_step2_con_e17d838d:

    # Judy "Ohhh! Aaahhh! (Linda’s finger is curling inside of me! She’s pushing up against my g-spot!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1080
translate chinese JuR2_ES5_step2_con_d2c52a8b:

    # MC "Ah! Argh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1082
translate chinese JuR2_ES5_step2_con_8416d09e:

    # Judy "(Oh wow! It’s amazing watching it happen, this close. I can’t wait to see the moment when his dick swells up inside his Mom’s pussy, filling it up with his thick cum.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1084
translate chinese JuR2_ES5_step2_con_ab6ecd0b:

    # Judy "(Oh wow! It’s amazing watching it happen, this close. I can’t wait to see the moment when his dick swells up inside his landlady’s pussy, filling it up with his thick cum.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1085
translate chinese JuR2_ES5_step2_con_036e0f44:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1087
translate chinese JuR2_ES5_step2_con_f8531102:

    # Mom "Ah! Ahhh! Oh! Fuck! Yes!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1088
translate chinese JuR2_ES5_step2_con_036e0f44_1:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1090
translate chinese JuR2_ES5_step2_con_8cfb723f:

    # Judy "(I’m getting so wet, just imagining if I had a son of my own, willing to do this to me...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1092
translate chinese JuR2_ES5_step2_con_f63afb7f:

    # Judy "(I’m getting so wet, just imagining if I had a hot, young stud of my own, willing to do this to me...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1094
translate chinese JuR2_ES5_step2_con_c487c3ef:

    # Judy "(I’d let him fuck me any time he wanted. I’d suck his cock while he studied for college.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1096
translate chinese JuR2_ES5_step2_con_c5f3a95e_1:

    # MC "Ugh! Arrghh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1098
translate chinese JuR2_ES5_step2_con_ec19855e:

    # Judy "(God, I’d ride him every single night.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1099
translate chinese JuR2_ES5_step2_con_ec954343:

    # Mom "Ah! Yesss!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1101
translate chinese JuR2_ES5_step2_con_0c7fa58b:

    # MC "Ugh! Aahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1102
translate chinese JuR2_ES5_step2_con_c3bb9766:

    # Mom "*Pant* Oohh! God! Yes! I’m cumming! I’m cumming!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1103
translate chinese JuR2_ES5_step2_con_33cf37dd:

    # MC "Arrghh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1105
translate chinese JuR2_ES5_step2_con_1d63bea3:

    # MC "UGH!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1106
translate chinese JuR2_ES5_step2_con_2ac8a36e:

    # Judy "(It’s incredible, watching how deep his cock slides inside her... It must feel amazing to have his dick, pressed right up against her womb.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1107
translate chinese JuR2_ES5_step2_con_255faeef:

    # Mom "Aaahhhh!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1109
translate chinese JuR2_ES5_step2_con_acbeaa8b:

    # Judy "Oooh! Mmmmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1111
translate chinese JuR2_ES5_step2_con_4fb5fa39:

    # Judy "(I wonder how intense it feels to have your own son blast his hot semen deep into your womb? It must be mind-blowing. All that pleasure, the risk of impregnation, the taboo of the illicit relationship.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1113
translate chinese JuR2_ES5_step2_con_cb4886da:

    # Judy "(I wonder how intense it feels to have this hot young guy blast his hot semen deep into your womb? It must be mind-blowing. All that pleasure, the risk of impregnation, the taboo of the illicit relationship.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1114
translate chinese JuR2_ES5_step2_con_22d87149:

    # Judy "Aaahhhh! I’m cumming! I’m- AAAHHHHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1116
translate chinese JuR2_ES5_step2_con_519cd11d:

    # MC "I’m getting close!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1118
translate chinese JuR2_ES5_step2_con_102c806a:

    # Judy "Fill your mother up, [player_name]! I want to see the moment you cum inside her!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1120
translate chinese JuR2_ES5_step2_con_2eedaa37:

    # Judy "Fill her, [player_name]! I want to see the moment you cum inside her!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1121
translate chinese JuR2_ES5_step2_con_c153fa47:

    # MC "Is it ugh... okay, [Mom_name]? I haven’t got a condom on."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1123
translate chinese JuR2_ES5_step2_con_0e28e852:

    # Mom "Ah! Finish wherever you want!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1124
translate chinese JuR2_ES5_step2_con_e90440b7:

    # MC "Ughh! Ah! Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1126
translate chinese JuR2_ES5_step2_con_bf8fa51f:

    # Judy "Yes, yes! Do it! Fill your Mom’s horny pussy with your semen!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1128
translate chinese JuR2_ES5_step2_con_ebc15ddf:

    # Judy "Yes, yes! Do it! Fill her horny pussy with your semen!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1130
translate chinese JuR2_ES5_step2_con_c9a14018:

    # Judy "Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1132
translate chinese JuR2_ES5_step2_con_ee497df4:

    # Judy "(If I close my eyes I can ALMOST imagine that Linda’s fingers are my own boy’s cock. He’s about to finish inside me.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1134
translate chinese JuR2_ES5_step2_con_e31b5a06:

    # Judy "(If I close my eyes I can ALMOST imagine that Linda’s fingers are a young guy’s cock. He’s about to finish inside me.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1135
translate chinese JuR2_ES5_step2_con_bd4625a3:

    # Judy "(I’m getting SO close. It’s SO dangerous. His raw cock, his potent semen about to blast into my pussy. We shouldn’t do it, but I’m too horny to resist.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1136
translate chinese JuR2_ES5_step2_con_29ab17fa:

    # Judy "OOOOHHHH! I’m cummmmmmiiinnngg!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1138
translate chinese JuR2_ES5_step2_con_66c4efcb:

    # MC "Hnnnnggg! Arrghhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1148
translate chinese JuR2_ES5_step2_con_b56ef3ff:

    # Mom "*GASP* Aaaahhhh!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1149
translate chinese JuR2_ES5_step2_con_adf5c98b:

    # Judy "Yes! Tell me what you’re feeling, Linda. Describe it to me!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1151
translate chinese JuR2_ES5_step2_con_5328f454:

    # Mom "It’s oooh... s-so hot! I feel his ah... cock throbbing inside me! His cum is ooohh... filling me up!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1153
translate chinese JuR2_ES5_step2_con_ec94b1a8:

    # Judy "Yes! Mmm! That’s it, [player_name]! Empty your balls deep, in your mom’s wet pussy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1155
translate chinese JuR2_ES5_step2_con_04c265b2:

    # Judy "Yes! Mmm! That’s it, [player_name]! Empty your balls deep, in Linda’s wet pussy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1156
translate chinese JuR2_ES5_step2_con_b7ac55f0:

    # Mom "Ah... *Pant* Oohh..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1158
translate chinese JuR2_ES5_step2_con_76ed2ce2:

    # Judy "Wow..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1159
translate chinese JuR2_ES5_step2_con_6c31ba06:

    # Judy "(It’s amazing to see it trickle out of her pussy like that. This is the EXACT inspiration I needed for my final chapter. The “climax” of my book - if I do say so myself!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1161
translate chinese JuR2_ES5_step2_con_cd021ab0:

    # Judy "Aah..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1162
translate chinese JuR2_ES5_step2_con_6747caf2:

    # MC "*Pant* That was amazing. All okay, there, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1163
translate chinese JuR2_ES5_step2_con_e8947846:

    # Judy "Uh huh."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1165
translate chinese JuR2_ES5_step2_con_036e0f44_2:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1166
translate chinese JuR2_ES5_step2_con_de4716f8_1:

    # Judy "*Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1167
translate chinese JuR2_ES5_step2_con_fa94fd91:

    # Judy "([player_name]’s cum mixed with Linda’s juices, is delicious!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1169
translate chinese JuR2_ES5_step2_con_acdce1cd_3:

    # MC "Zzz..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1170
translate chinese JuR2_ES5_step2_con_7b623fd3:

    # Mom "*Snore*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1171
translate chinese JuR2_ES5_step2_con_29923665:

    # Judy "*Yawn*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1173
translate chinese JuR2_ES5_step2_con_3cebd3d3:

    # Judy "Hmm?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1174
translate chinese JuR2_ES5_step2_con_640ac048:

    # Judy "(Well, that’s interesting. I wasn’t expecting [player_name] to have a rock-hard cock while he sleeps. ESPECIALLY after our, rather intense session, earlier.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1175
translate chinese JuR2_ES5_step2_con_73e97bae:

    # Judy "..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1177
translate chinese JuR2_ES5_step2_con_349bdf48:

    # Judy "(He probably won’t mind me lending him a hand... right?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1178
translate chinese JuR2_ES5_step2_con_ee1c7a00:

    # Judy "(I mean, he’s asleep anyway! I wouldn’t want him waking up and finding that he’s got a huge boner to deal with. I’d be basically doing him a favour!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1179
translate chinese JuR2_ES5_step2_con_c8f8564b:

    # Judy "(God... It’s throbbing beneath my fingers... Maybe I should...)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1181
translate chinese JuR2_ES5_step2_con_00ba94b6_1:

    # Judy "*Shlurp* *Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1182
translate chinese JuR2_ES5_step2_con_dba5e987:

    # Judy "(Using my hand isn’t the most efficient way to finish him off. I’ll just use my mouth to quickly make him cum - then sneak back to bed.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1183
translate chinese JuR2_ES5_step2_con_3a213d85:

    # Judy "(He’ll be done before anyone even wakes up!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1185
translate chinese JuR2_ES5_step2_con_61523ed2_2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1186
translate chinese JuR2_ES5_step2_con_af46bbed:

    # MC "Mmm... Huh?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1187
translate chinese JuR2_ES5_step2_con_40ff9b1a:

    # Judy "Mmm... *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1188
translate chinese JuR2_ES5_step2_con_4a4c3d37:

    # MC "(Was Judy trying to give me a blowjob while I was asleep?! What kind of perv performs a sex act on someone while they’re trying to sleep?! Absolutely disgraceful!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1190
translate chinese JuR2_ES5_step2_con_a93af9ea:

    # Judy "Mmm! *Shluuurrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1191
translate chinese JuR2_ES5_step2_con_5106f36c:

    # Mom "(Goodness me! I can see why [player_name] has been enjoying his therapy sessions so much, now...)"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1193
translate chinese JuR2_ES5_step2_con_ac9cd12d:

    # MC "*Whispered* Should we tell her we’re awake, [Mom_name]? "
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1194
translate chinese JuR2_ES5_step2_con_b81d107f:

    # Judy "*Suck* Mmm! *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1195
translate chinese JuR2_ES5_step2_con_17247d85:

    # Mom "*Whispered* She seems completely absorbed in sucking your cock. I don’t think she realises either of us are up yet..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1196
translate chinese JuR2_ES5_step2_con_07fffcea:

    # Judy "*Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1197
translate chinese JuR2_ES5_step2_con_ef134ce0:

    # MC "Ohh... *Whispered* If you’re going to join in, then you better do it quick, [Mom_name]. I don’t think I’m gonna last much longer, with her sucking my dick like that."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1199
translate chinese JuR2_ES5_step2_con_8a11aec2:

    # Mom "Morning Judy, what EXACTLY do you think you’re doing to my boy?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1201
translate chinese JuR2_ES5_step2_con_5def211b:

    # Mom "Morning Judy, what EXACTLY do you think you’re doing to my man?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1202
translate chinese JuR2_ES5_step2_con_655a8915:

    # Judy "*Suck* *Su-* U-Um, m-morning, Linda! *Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1204
translate chinese JuR2_ES5_step2_con_908e8ae5:

    # Mom "You’ve got some nerve, Judy."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1205
translate chinese JuR2_ES5_step2_con_336667c4:

    # Judy "I.. Uh..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1207
translate chinese JuR2_ES5_step2_con_06050095:

    # Mom "Did you ACTUALLY think you could just start sucking my son’s cock while he was asleep?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1209
translate chinese JuR2_ES5_step2_con_bccfa06c:

    # Mom "Did you ACTUALLY think you could just start sucking my man’s cock while he was asleep?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1210
translate chinese JuR2_ES5_step2_con_8d3d98b8:

    # Judy "I-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1211
translate chinese JuR2_ES5_step2_con_3c11ffc7:

    # Mom "Without inviting me to join in?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1213
translate chinese JuR2_ES5_step2_con_f061e601:

    # Judy "Haha! You almost had me there, Linda. You’ve still got that deadpan stare from university."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1214
translate chinese JuR2_ES5_step2_con_0e9e2492:

    # Mom "Heh, I couldn’t resist. On you go, keep sucking his shaft. [player_name] is awake now anyway, so you might as well ride his face while you’re at it."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1216
translate chinese JuR2_ES5_step2_con_b169ba2b:

    # Judy "*Shlurp* *Suck* *Shluuuurrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1218
translate chinese JuR2_ES5_step2_con_bc282d82:

    # Mom "*Lick* *Mwah*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1222
translate chinese JuR2_ES5_step2_con_ced0da3e:

    # MC "Mmm! (Holy shit, this is amazing. It feels so good having Judy’s mouth suck on my shaft while my mom licks my balls.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1224
translate chinese JuR2_ES5_step2_con_10bf15e6:

    # MC "Mmm! (Holy shit, this is amazing. It feels so good having Judy’s mouth suck on my shaft while Linda licks my balls.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1226
translate chinese JuR2_ES5_step2_con_cd6732d3_1:

    # MC "Ahmmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1227
translate chinese JuR2_ES5_step2_con_732c55c9_3:

    # Mom "*Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1228
translate chinese JuR2_ES5_step2_con_5f2486e8:

    # Judy "*Suck* *Suck* *Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1229
translate chinese JuR2_ES5_step2_con_ea7f3056:

    # MC "MMMMMMMM!!!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1231
translate chinese JuR2_ES5_step2_con_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1233
translate chinese JuR2_ES5_step2_con_07fffcea_1:

    # Judy "*Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1234
translate chinese JuR2_ES5_step2_con_e27b7d49:

    # MC "(Fuck, this is so intense! I don’t think I’ll last too long, with a double-blowjob like this!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1236
translate chinese JuR2_ES5_step2_con_192ec1e8:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1237
translate chinese JuR2_ES5_step2_con_01c2a467:

    # Judy "Hmmmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1238
translate chinese JuR2_ES5_step2_con_f45875c1:

    # MC "(Judy’s pussy is delicious! She was already soaking wet from the moment she climbed on top of me. She must have gotten horny from giving me that blowjob while I was still asleep.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1240
translate chinese JuR2_ES5_step2_con_d1ad45b3:

    # Judy "([player_name]’s tongue is plunging deep inside me! My legs are starting to shake!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1241
translate chinese JuR2_ES5_step2_con_77cd4868:

    # Judy "MMMMPFFF! *SHLURP* *SUCK* *SUCK* *SUCK*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1242
translate chinese JuR2_ES5_step2_con_deed4e66:

    # MC "(It feels like Judy’s about to cum! Let’s see how she reacts if I start sucking on her clitoris.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1244
translate chinese JuR2_ES5_step2_con_8742a523:

    # MC "*Suuuucck*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1245
translate chinese JuR2_ES5_step2_con_3365967d:

    # Judy "(Oh fuck! I can feel his lips pursed around my clit! It’s so sensitive! It’s happening! I’m cumming!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1246
translate chinese JuR2_ES5_step2_con_6ca76b25:

    # Judy "MMMMMMM!! NMMMMMMMM!!!!!! AHMMMMMM!!!!!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1247
translate chinese JuR2_ES5_step2_con_8d04715e:

    # MC "(She’s trembling like crazy, right now! I think I definitely made her cum!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1249
translate chinese JuR2_ES5_step2_con_6d9298f3:

    # Judy "*Suck* *Suck* *Suck* *Suck* *SHLURP* *SUUUUUUCCK*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1251
translate chinese JuR2_ES5_step2_con_7b3980d4:

    # MC "Hnnnng! Mmmmm! F-FUCK! I’m gonna cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1253
translate chinese JuR2_ES5_step2_con_5901cf0c:

    # Judy "*SHLUUURRRP*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1254
translate chinese JuR2_ES5_step2_con_732c55c9_4:

    # Mom "*Lick* *Lick*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1255
translate chinese JuR2_ES5_step2_con_645fa6fe:

    # MC "Aaarrghhhhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1257
translate chinese JuR2_ES5_step2_con_7cf4ae85:

    # Mom "*Liiiiicccck*"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1258
translate chinese JuR2_ES5_step2_con_96df3bdc:

    # MC "Aaahhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1260
translate chinese JuR2_ES5_step2_con_8f665b3b:

    # Judy "That’s it, [player_name]. Cum for your mommy while she drags her tongue up your big, fat-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1262
translate chinese JuR2_ES5_step2_con_0bc804d8:

    # Judy "That’s it, [player_name]. Cum for your landlady while she drags her tongue up your big, fat-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1272
translate chinese JuR2_ES5_step2_con_2afbdcd7:

    # MC "HNNNNGGG!! AARRGHHHHH!!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1273
translate chinese JuR2_ES5_step2_con_83091b70:

    # Judy "...cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1274
translate chinese JuR2_ES5_step2_con_32a9a237:

    # Mom "*Lick* Mmm!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1276
translate chinese JuR2_ES5_step2_con_3a6fa308:

    # MC "*Pant* *Pant* That was... fucking amazing... *Gasp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1277
translate chinese JuR2_ES5_step2_con_32377264:

    # Judy "Seems like we did a pretty good job, Linda. He came like a fountain!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1278
translate chinese JuR2_ES5_step2_con_48df436b:

    # Mom "Heh, a double blowjob will do that to ANY man!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1279
translate chinese JuR2_ES5_step2_con_e8d76d4c:

    # Judy "Do you want to try that thing we used to do, back in university?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1280
translate chinese JuR2_ES5_step2_con_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1281
translate chinese JuR2_ES5_step2_con_3d873f12:

    # Judy "Oh, c’mon! For old times’ sake."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1282
translate chinese JuR2_ES5_step2_con_81605c7a:

    # Mom "Fine. For old times’ sake."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1284
translate chinese JuR2_ES5_step2_con_28baa1c9_1:

    # Mom "Mmm!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1285
translate chinese JuR2_ES5_step2_con_036e0f44_3:

    # Judy "Mmm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1287
translate chinese JuR2_ES5_step2_con_99abc748:

    # MC "*Pant* (That was incredible! I didn’t imagine [Mom_name] would be up for a threesome with Judy. A surprise, to be sure - but a welcome one.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1288
translate chinese JuR2_ES5_step2_con_38372b01:

    # Mom "Where’s your shower, Judy?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1289
translate chinese JuR2_ES5_step2_con_51cfa86e:

    # Judy "I’ll show you. Unfortunately, I only have one so I hope you don’t mind sharing."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1290
translate chinese JuR2_ES5_step2_con_d2ba3557:

    # Mom "Couldn’t you just go after me?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1292
translate chinese JuR2_ES5_step2_con_9a587c64:

    # Judy "Ah, but if I go after you, then I’m not going to get the chance to wash down your body, am I?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1293
translate chinese JuR2_ES5_step2_con_78f263e6:

    # Mom "I see you still haven’t changed from our days in university. You’re still a perv."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1294
translate chinese JuR2_ES5_step2_con_972a06d6:

    # Judy "You weren’t calling me a perv when I held that shower head against your pussy, while making out with you, in the gym showers!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1295
translate chinese JuR2_ES5_step2_con_ec4d8eff:

    # Mom "Oh, c’mon. That was a one-time thing! Everyone gets a little wild in university. You’re supposed to mellow out afterwards!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1296
translate chinese JuR2_ES5_step2_con_fa6276a1:

    # Judy "Mellow out? You mean “get boring”?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1297
translate chinese JuR2_ES5_step2_con_d7bcfd85:

    # Mom "I am NOT boring!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1298
translate chinese JuR2_ES5_step2_con_c38b8f12:

    # Judy "Prove it, then. Join me in the shower!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1299
translate chinese JuR2_ES5_step2_con_55bdf529:

    # Mom "*Sigh* Fine!"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1300
translate chinese JuR2_ES5_step2_con_ac4736f3:

    # MC "(Heh, sounds like those two are going to be lifelong friends.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1319
translate chinese Ju_ES5_leave_b3d30217:

    # MC "(It's time to leave.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1328
translate chinese JuR2_ES5_bonus_bd366442:

    # MC "(I wonder if the shower is free yet.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1330
translate chinese JuR2_ES5_bonus_77a4738e:

    # "*Rattle Rattle*"
    ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1331
translate chinese JuR2_ES5_bonus_efe14c39:

    # MC "(Nah, still locked.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1336
translate chinese JuR2_ES5_bonus_49a7933b:

    # Judy "What are you- Ohhh! OH"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1337
translate chinese JuR2_ES5_bonus_1c666ee5:

    # Mom "Shush, keep your voice down."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1338
translate chinese JuR2_ES5_bonus_3cfc58bf:

    # Judy "Ah! Ah! Mmppfff!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1339
translate chinese JuR2_ES5_bonus_56302b7d:

    # Mom "Fine. I’m just going to have to cover your mouth, if you can’t keep your voice down."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1340
translate chinese JuR2_ES5_bonus_9fcbc386:

    # Judy "Mmppff! HMMPFF!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1341
translate chinese JuR2_ES5_bonus_11efeb9e:

    # Mom "Oh yeah, you like that, don’t you? I bet you’re imagining that this is [player_name]’s dick, aren’t you?"
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1342
translate chinese JuR2_ES5_bonus_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1343
translate chinese JuR2_ES5_bonus_be822f88:

    # MC "(Sounds like they continued the party without me!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1366
translate chinese JuR2_ES5_step3_c182c026:

    # Mom "*Whispered* ...saying that, I didn’t think you’d be bringing a strap-on to the shower."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1367
translate chinese JuR2_ES5_step3_4b0ab856:

    # Judy "*Whispered* Don’t tell me you didn’t enjoy it! You were screaming my name when I had you pinned against the tiles. Admit it, you love being fucked by a woman with a dildo."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1373
translate chinese JuR2_ES5_step3_605b2314:

    # Mom "*Whispered* Shush, keep your voice down."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1374
translate chinese JuR2_ES5_step3_ab1a3de3:

    # Judy "*Whispered* Keep my voice down? You’re the one who was-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1378
translate chinese JuR2_ES5_step3_93bf91df:

    # MC "Hey guys!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1379
translate chinese JuR2_ES5_step3_0d1e0a79:

    # Mom "Hey Sweetie! I thought you’d fallen back asleep."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1380
translate chinese JuR2_ES5_step3_53fb291e:

    # Judy "*Ahem* H-Hey! How long have you been standing there?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1381
translate chinese JuR2_ES5_step3_b9702c1c:

    # MC "I only just arrived. Why? How was the shower?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1385
translate chinese JuR2_ES5_step3_0ea4432f:

    # Judy "*Ahem* G-Great! Your Mom had a great time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1387
translate chinese JuR2_ES5_step3_b80500a1:

    # Judy "*Ahem* G-Great! Linda had a great time."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1388
translate chinese JuR2_ES5_step3_56d4c5a6:

    # Mom "Y-Yeah, the shower was... um... really good."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1392
translate chinese JuR2_ES5_step3_53cd7d4c:

    # Judy "...Oh! Your Mom and I were just talking about the best way to approach the situation with Bob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1394
translate chinese JuR2_ES5_step3_1e0b5fd7:

    # Judy "...Oh! Linda and I were just talking about the best way to approach the situation with Bob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1395
translate chinese JuR2_ES5_step3_e7c97e11:

    # Judy "Are you clear on what you have to do?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1396
translate chinese JuR2_ES5_step3_42775c2b:

    # MC "Err... Not really."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1400
translate chinese JuR2_ES5_step3_aa3f2c48:

    # Judy "Absolutely nothing. Just be patient."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1401
translate chinese JuR2_ES5_step3_344e1f26:

    # Judy "I promise you, [player_name]. Everything will fall into place. Trust me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1405
translate chinese JuR2_ES5_step3_8e81c963:

    # MC "That’s easy for you to say. Bob’s not your Dad. It’s really awkward having to-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1407
translate chinese JuR2_ES5_step3_9364bd55:

    # MC "That’s easy for you to say. You don’t live with Bob. It’s really awkward having to-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1411
translate chinese JuR2_ES5_step3_fbab25c1:

    # Mom "C’mon Judy. Can you not give him any better advice than that? He’s anxious. I’M anxious too."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1412
translate chinese JuR2_ES5_step3_d9760959:

    # Judy "Have I ever betrayed your trust before?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1413
translate chinese JuR2_ES5_step3_8d3e3a1c:

    # Mom "Yes."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1414
translate chinese JuR2_ES5_step3_500a9657:

    # MC "Yes. Repeatedly."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1415
translate chinese JuR2_ES5_step3_fe9eeda5:

    # Judy "That was a badly phrased question. *Sigh* Listen. The two of you listened to me, and you both ended up having an amazing sexual relationship together. Just... Just try and listen to me for a little bit longer."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1419
translate chinese JuR2_ES5_step3_f5578119:

    # MC "*Sigh* Fine. We’re not just puppets in your show though, Judy. You can’t expect us to dance to your tune every waking moment."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1421
translate chinese JuR2_ES5_step3_540347a9:

    # Judy "What’s wrong with sacrificing a little autonomy in your decisions, if it results in a net benefit to you and your Mom’s overall happiness?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1423
translate chinese JuR2_ES5_step3_ee7fecca:

    # Judy "What’s wrong with sacrificing a little autonomy in your decisions, if it results in a net benefit to you and Linda’s overall happiness?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1424
translate chinese JuR2_ES5_step3_32d6c8ae:

    # MC "Because they wouldn’t be OUR decisions."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1425
translate chinese JuR2_ES5_step3_7827ed2f:

    # Judy "All I’m asking you to do is sit tight. Everything will fall neatly into place. I promise."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1429
translate chinese JuR2_ES5_step3_4ba071b0:

    # MC "You better be right about this."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1430
translate chinese JuR2_ES5_step3_b1c678db:

    # Judy "Have I ever been wrong so far? See you again soon, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1431
translate chinese JuR2_ES5_step3_98cf6957:

    # MC "Bye Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1432
translate chinese JuR2_ES5_step3_16ee19b4:

    # Mom "See you later, Judy."
    Mom ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1443
translate chinese JuR2_ES5_step3_d2712176:

    # MC "(Judy has an interesting perspective on life. She seems to think that people should just voluntarily sacrifice a bit of their own freedom, to allow her to choose what she believes to be the objectively best outcome.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1444
translate chinese JuR2_ES5_step3_2bcf1a51:

    # MC "(Even if she actually causes a better outcome, does the benefit really matter when it becomes a decision that I never got to make?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1448
translate chinese JuR2_ES5_step3_15efe0af:

    # MC "(At the end of the day, none of this would have happened if Judy hadn’t gotten involved. I’d probably still be home alone suffering from depression after that incident with Ms. Celia.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1449
translate chinese JuR2_ES5_step3_68c2bdff:

    # MC "*Sigh* (Maybe I should give Judy the benefit of the doubt, one final time? She’s been right every time so far...)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1453
translate chinese JuR2_ES5_step3_c29c4543:

    # Judy "(Not bad... Not bad at all. I dare say that this is the most impressive literature I have written, in my career.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1454
translate chinese JuR2_ES5_step3_98eb414d:

    # Judy "(Heh, I can almost imagine my publisher having a heart attack as he reads chapter nine.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1458
translate chinese JuR2_ES5_step3_cef20a40:

    # Judy "(I couldn’t have done this without [player_name]’s assistance. Linda was a huge help too. I’ll have to make sure to send both of them signed copies."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1462
translate chinese JuR2_ES5_step3_c95833d7:

    # Judy "(Okay... I’ll do one final review tomorrow. Once that’s complete, and I get the all clear, it should hit the shelves within the next couple of weeks.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1466
translate chinese JuR2_ES5_step3_428afe5c:

    # Judy "*Sigh* (I wonder what I’m going to do after this is all over? A couple of interviews? Book signings?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1467
translate chinese JuR2_ES5_step3_87c1cf1a:

    # Judy "(I definitely don’t want to go back to a stuffy university to lecture or do research.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES5_home.rpy:1468
translate chinese JuR2_ES5_step3_adfa151e:

    # Judy "Hmm... I’m gonna need a new project. Linda and [player_name] have already proven to be MORE than willing participants once I coaxed them out of their shells."
    Judy ""

