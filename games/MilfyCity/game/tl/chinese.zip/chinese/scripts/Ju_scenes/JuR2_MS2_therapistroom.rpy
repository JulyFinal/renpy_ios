﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:47
translate chinese JuR2_MS2_44aea3f2:

    # Judy "Ah, I wasn’t expecting to see you again so soon. I thought you would require a bit more time to... process what happened at my place."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:48
translate chinese JuR2_MS2_27ba5b43:

    # MC "I’m surprised you actually remember. You were pretty drunk. You did ask me to call by your office though."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:52
translate chinese JuR2_MS2_6f795af2:

    # Judy "I was, wasn’t I? I still recall the evening though. Quite unforgettable, if I do say so myself."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:53
translate chinese JuR2_MS2_1cc2a450:

    # Judy "Did you enjoy it, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:54
translate chinese JuR2_MS2_b1298092:

    # MC "Well... finding out that you were writing that book came as a shock. I don’t get why you couldn’t have just been open and honest about it from the start."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:55
translate chinese JuR2_MS2_c914f716:

    # Judy "I’d been writing that book for a long time, [player_name]. Way before your incident with Ms. Celia landed you in my care."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:59
translate chinese JuR2_MS2_514eae5b:

    # MC "You’d been speaking with my Mom about that BEFORE Celia though, right?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:61
translate chinese JuR2_MS2_a72e2991:

    # MC "You’d been speaking with Linda about that BEFORE Celia though, right?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:62
translate chinese JuR2_MS2_fee92d61:

    # Judy "That part is true, [player_name]. Linda and I had been sharing certain... intimate fantasies with each other for several months prior. We reconnected over a coffee and she expressed an intense fascination with my work."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:63
translate chinese JuR2_MS2_3b20509a:

    # Judy "Would you like to continue our arrangement? I’m happy to continue pleasuring you in exchange for the raw data that you are providing for my research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:69
translate chinese JuR2_MS2_bdf10e00:

    # MC "(Is she honestly expecting me to answer that? She’s supposed to be my therapist, but she’s literally just been using me the whole time.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:70
translate chinese JuR2_MS2_2786c857:

    # Judy "I’ll take your silence as proof that you aren’t quite convinced of my proposal yet."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:74
translate chinese JuR2_MS2_365ee45e:

    # MC "You’re right. I’m not."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:75
translate chinese JuR2_MS2_9ce357a2:

    # Judy "Perhaps... Perhaps you just need another demonstration before you make your final decision? How about you come over here and I’ll give you another blowjob to try and convince you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:83
translate chinese JuR2_MS2_77485945:

    # MC "Okay, sounds like a deal. There’s just one thing I’d like to add."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:87
translate chinese JuR2_MS2_0738a7b9:

    # Judy "Oh? And what is that?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:91
translate chinese JuR2_MS2_acc15495:

    # MC "I want to be able to enjoy this arrangement whenever I want. I can’t guarantee that I’m always going to have some juicy new gossip about my mom and me to share with you."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:93
translate chinese JuR2_MS2_143ebceb:

    # MC "I want to be able to enjoy this arrangement whenever I want. I can’t guarantee that I’m always going to have some juicy new gossip about Linda and me to share with you."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:97
translate chinese JuR2_MS2_6ddb2548:

    # Judy "Hmm, that’s fair. Fine. You can request for me to pleasure you whenever you want, but you MUST keep updating me on your progress with your mom. We still talk regularly - and if I find out that you’ve been keeping secrets from me, our deal is off."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:99
translate chinese JuR2_MS2_67964669:

    # Judy "Hmm, that’s fair. Fine. You can request for me to pleasure you whenever you want, but you MUST keep updating me on your progress with Linda. We still talk regularly - and if I find out that you’ve been keeping secrets from me, our deal is off."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:100
translate chinese JuR2_MS2_75715e4e:

    # MC "Perfect."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:101
translate chinese JuR2_MS2_7aa8759a:

    # Judy "Shall we seal the deal with another blowjob?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:111
translate chinese JuR2_MS2_step1_b6c15349:

    # Judy "Mmm, you’re already hard. Tell me, [player_name], was it my short red dress that turned you on? Or was it the anticipation of me sucking your shaft a second time?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:112
translate chinese JuR2_MS2_step1_856a13eb:

    # Judy "Heh, probably a bit of both. Just try to relax and enjoy yourself, [player_name]. I want you to truly appreciate how good things can be for you if you work with me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:116
translate chinese JuR2_MS2_step1_0e2c7266:

    # Judy "All you have to do is keep updating me on how things are going with your mom. Keep telling me every little gritty detail."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:118
translate chinese JuR2_MS2_step1_29efba11:

    # Judy "All you have to do is keep updating me on how things are going with Linda. Keep telling me every little gritty detail."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:119
translate chinese JuR2_MS2_step1_4142b6eb:

    # Judy "And in return, you can have your cock sucked WHENEVER you want. Maybe I’ll even let you finish in my mouth if your stories prove enticing enough."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:120
translate chinese JuR2_MS2_step1_7e8cc852:

    # MC "Mmm... (Her fingers are so soft. They feel so good, stroking my dick like that.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:124
translate chinese JuR2_MS2_step1_8b08430c:

    # Judy "*Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:125
translate chinese JuR2_MS2_step1_73049590:

    # MC "Mmm! Ah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:126
translate chinese JuR2_MS2_step1_c52014a9:

    # MC "Shit, that feels so good, Judy!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:130
translate chinese JuR2_MS2_step1_e839db2a:

    # Judy "Do you remember what I told you to call me when you visited my place?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:131
translate chinese JuR2_MS2_step1_880f6622:

    # MC "Uh... Yeah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:132
translate chinese JuR2_MS2_step1_3a45c426:

    # Judy "Keep calling me that while I’m sucking on your cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:133
translate chinese JuR2_MS2_step1_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:135
translate chinese JuR2_MS2_step1_a69e4bb2:

    # Judy "Well, aside from being very useful for my research, I also think you enjoy doing it. I think you enjoy the fantasy of your own mother sucking and slurping on your big, fat cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:137
translate chinese JuR2_MS2_step1_2b06db04:

    # Judy "Well, aside from being very useful for my research, I also think you enjoy doing it. I think you enjoy the fantasy of MILF sucking and slurping on your big, fat cock."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:139
translate chinese JuR2_MS2_step1_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:140
translate chinese JuR2_MS2_step1_08ae33d5:

    # Judy "Now, be a good boy and say it for me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:144
translate chinese JuR2_MS2_step1_bc28f253:

    # Judy "*SHLURP*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:146
translate chinese JuR2_MS2_step1_10c9781d:

    # MC "Ohh! M-Mommy! Ahh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:148
translate chinese JuR2_MS2_step1_f5b4103c:

    # Judy "*Suck* *Suuuck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:152
translate chinese JuR2_MS2_step1_bbd1e3b4:

    # MC "Hnnng... Oh God! Keep going! Deeper, mom! Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:156
translate chinese JuR2_MS2_step1_5f9df56b:

    # Judy "*Suck* *Suck* *Suuuucck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:159
translate chinese JuR2_MS2_step1_8a609258:

    # Judy "(His dick is getting harder every time he uses the “m word.” Hopefully my time spent rewarding [player_name] with sex will farther encourage him to take things farther with Linda.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:163
translate chinese JuR2_MS2_step1_590250cb:

    # Judy "*Lick* *Suck* *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:164
translate chinese JuR2_MS2_step1_7982a5f1:

    # MC "Ohh! Ohhh! It’s ahh... really sensitive there! Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:165
translate chinese JuR2_MS2_step1_e2e7d52f:

    # Judy "*SHLURP* *SUCK*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:167
translate chinese JuR2_MS2_step1_e29520b9:

    # MC "AAHHH!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:171
translate chinese JuR2_MS2_step1_89c0ecd3:

    # Judy "Aww, is my little boy’s penis too sensitive at the tip? That’s such a shame - I planning to let you fuck mommy’s throat, but your dick clearly isn’t up to it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:172
translate chinese JuR2_MS2_step1_d46190ab:

    # MC "Hey, hold on, I could handle that!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:173
translate chinese JuR2_MS2_step1_89d66c0d:

    # Judy "Oh really? Because you sounded like you could barely stand me sucking the tip of your shaft."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:174
translate chinese JuR2_MS2_step1_e15190f6:

    # MC "It just got a bit intense when you were sucking on the same spot for so long. I could DEFINITELY fuck your throat."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:175
translate chinese JuR2_MS2_step1_e18ae548:

    # Judy "Well, let’s see about that. How about we take things over to the wall?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:179
translate chinese JuR2_MS2_step1_8b08430c_1:

    # Judy "*Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:180
translate chinese JuR2_MS2_step1_fb235885:

    # MC "Mmm... That’s it, lick my cock like that. Ah..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:181
translate chinese JuR2_MS2_step1_a438dbd8:

    # Judy "(It always drives guys wild when you start a blowjob by licking from the base of their shaft. There is something about slowly dragging your tongue up the length of their dick that just gets them unbelieveably horny.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:185
translate chinese JuR2_MS2_step1_4292fe18:

    # Judy "Mppf!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:187
translate chinese JuR2_MS2_step1_d8cc665f:

    # MC "Oh fuuuck! Hnnnng... Your mouth is amazing, Judy - I mean, mom!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:189
translate chinese JuR2_MS2_step1_7ce41a93:

    # Judy "(He’s thrusting his hips a bit, but I think he needs a bit of encouragement to go deeper. Let’s give him a hand.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:191
translate chinese JuR2_MS2_step1_61523ed2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:195
translate chinese JuR2_MS2_step1_da9cdd7c:

    # MC "Huh? Ooohhhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:196
translate chinese JuR2_MS2_step1_46f382ec:

    # MC "(She just grabbed my ass and pulled me right in! I can feel my dick slipping down her throat!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:197
translate chinese JuR2_MS2_step1_8706bc56:

    # Judy "*Shluurrp* *Suck* *GAG* *Suck* Mmmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:201
translate chinese JuR2_MS2_step1_2211446a:

    # MC "Aaah! Your throat’s so ugh... tight! I can’t... ahh! I can’t last much longer!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:202
translate chinese JuR2_MS2_step1_61523ed2_1:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:203
translate chinese JuR2_MS2_step1_e5327580:

    # MC "(Should I cum down her throat? Or should I pull out and finish over her tits?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:209
translate chinese JuR2_MS2_step1_6ecbbbc0:

    # MC "I’m gonna cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:213
translate chinese JuR2_MS2_step1_61523ed2_2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:215
translate chinese JuR2_MS2_step1_8c3e7884:

    # MC "Ah! Aaargghhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:225
translate chinese JuR2_MS2_step1_708d0e51:

    # MC "Aah! I’m cummmmiing! Unnngggh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:226
translate chinese JuR2_MS2_step1_fab8f88d:

    # Judy "*Gulp* *Suck* *Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:227
translate chinese JuR2_MS2_step1_4614e3ba:

    # MC "Ooohh! I can feel your throat tightening around my cock! Aahhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:228
translate chinese JuR2_MS2_step1_96db3a59:

    # MC "Holy shit! You’re *Pant* amazing at this!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:234
translate chinese JuR2_MS2_step1_ebc0e3f8:

    # MC "Wait, I’m about to cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:235
translate chinese JuR2_MS2_step1_61523ed2_3:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:236
translate chinese JuR2_MS2_step1_fdb1f4f7:

    # MC "Hnnng! Can I pull out and finish on your breasts?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:246
translate chinese JuR2_MS2_step1_c954cc08:

    # MC "Ugh! Aahhh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:247
translate chinese JuR2_MS2_step1_d3937431:

    # Judy "That’s it. Cum for mommy! Mmm! I want to feel your hot semen all over my chest."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:248
translate chinese JuR2_MS2_step1_75742b4a:

    # MC "*Pant* Ooohh, fuck... Your tits are amazing."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:255
translate chinese JuR2_MS2_step2_f46a553e:

    # Judy "Well? Did a second blowjob help convince you of the benefits of our arrangement?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:256
translate chinese JuR2_MS2_step2_c5d7625a:

    # MC "Yeah, *Pant*, I’m convinced. You’re *Pant* incredible at that."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:258
translate chinese JuR2_MS2_step2_e540de17:

    # Judy "Swing by my home when you’ve got some free time. I’d love to hear more about how you’re getting on with your sisters."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:260
translate chinese JuR2_MS2_step2_5f3b65b0:

    # Judy "Swing by my home when you’ve got some free time. I’d love to hear more about how you’re getting on with your roommates."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:264
translate chinese JuR2_MS2_step2_b2bccfb0:

    # Judy "Oh, and I know I said I was treating you for free, but do you think you could bring along a bottle of white wine? A little drink puts me in the mood, and in my line of work that REALLY helps me focus."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:265
translate chinese JuR2_MS2_step2_ec989803:

    # MC "Sure, white wine. Got it."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:266
translate chinese JuR2_MS2_step2_19c66f21:

    # Judy "Thanks, [player_name]. I’m looking forward to hearing more about your scandalous exploits."
    Judy ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:65
    old "Don’t answer Judy."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:65
    old "Agree to Judy’s proposal."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:205
    old "Cum down Judy’s throat as she pulls you closer."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS2_therapistroom.rpy:205
    old "Pull out and cum on Judy’s chest."
    new ""

