﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:122
translate chinese JuR2_MS4_5d597972:

    # Judy "Ah, [player_name], I was beginning to wonder if you’d actually read my text. You really shouldn’t keep a girl waiting."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:126
translate chinese JuR2_MS4_ed90f30e:

    # MC "Sorry, I got held up with a few things. What did you have in mind for today? You mentioned having a bit of fun?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:130
translate chinese JuR2_MS4_d23edcff:

    # Judy "Absolutely. Take a seat, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:134
translate chinese JuR2_MS4_e153d62c:

    # MC "So, what did you want me to come onto campus for today? Are you gonna let me show you how good I am at fucking your pussy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:136
translate chinese JuR2_MS4_777fb2c3:

    # Judy "Did you bring a condom?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:138
translate chinese JuR2_MS4_de841ab6:

    # MC "It feels better without a condom. Trust me."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:142
translate chinese JuR2_MS4_4377645b:

    # Judy "I KNOW it feels better, but I also don't want to end up pregnant! There's plenty of other things we can try together tonight."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:144
translate chinese JuR2_MS4_46fb77b7:

    # MC "Oh yeah? Care to give me a hint?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:148
translate chinese JuR2_MS4_ce6878f1:

    # Judy "Well, it’s normally my patients making confessions to me. But since you asked..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:150
translate chinese JuR2_MS4_f5ae767f:

    # Judy "I have always gotten REALLY turned on, sucking a guy’s cock. So if you want to fuck my face today, you certainly can."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:152
translate chinese JuR2_MS4_f7beae2b:

    # Judy "And I won’t be expecting you to wear a condom for that. You’ll be able to feel my mouth directly against your shaft."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:156
translate chinese JuR2_MS4_0bc63704:

    # Judy "Alternatively, you could always have some fun fucking my ass. It’s probably A LOT tighter than my pussy, so a guy like you might not be able to handle it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:158
translate chinese JuR2_MS4_4d92409b:

    # MC "Whoa! Hold on! What makes you think I won’t be able to handle your ass?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:162
translate chinese JuR2_MS4_1e48812e:

    # Judy "Oh please... a horny young guy like you? My tight ass would milk your balls dry in seconds."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:164
translate chinese JuR2_MS4_9b3c19ee:

    # Judy "So, what’s it going to be, [player_name]? Do you want to cum in my mouth? Or would you rather see how long you can last doing anal?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:171
translate chinese JuR2_MS4_39beeb20:

    # MC "I want you to suck my cock, Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:173
translate chinese JuR2_MS4_c7b3cc57:

    # Judy "Very well. In that case, let’s get you undressed."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:177
translate chinese JuR2_MS4_8a9527d6:

    # Judy "Mmm, I wasn’t expecting you to be so hard, so quickly."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:179
translate chinese JuR2_MS4_4f134828:

    # MC "You’re an attractive woman, Judy. What did you think was going to happen?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:183
translate chinese JuR2_MS4_87763919:

    # Judy "Hehe, you’re enjoying looking at my body, aren't you? What’s your favourite part?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:185
translate chinese JuR2_MS4_87667874:

    # Judy "My breasts? My thighs? My pussy? You probably enjoy it all."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:187
translate chinese JuR2_MS4_61fbda7f:

    # MC "How about you get down on your knees, and I’ll tell you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:191
translate chinese JuR2_MS4_be72cf50:

    # Judy "Like this?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:193
translate chinese JuR2_MS4_c73f8698:

    # MC "Exactly like that."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:195
translate chinese JuR2_MS4_ea6ca9d5:

    # Judy "You like seeing women down on their knees, don’t you, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:199
translate chinese JuR2_MS4_4d97e209:

    # Judy "You’re getting harder. I didn’t realise you had such dominant traits within you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:201
translate chinese JuR2_MS4_dd0a3c17:

    # Judy "It really turns you on seeing me subservient like this, doesn’t it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:203
translate chinese JuR2_MS4_771844a9:

    # MC "Do you think we could just proceed with the blowjob without the psychoanalysis?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:207
translate chinese JuR2_MS4_c5939a94:

    # Judy "Oh [player_name], the psychoanalysis is the best part. I love watching a guy’s reaction as I slowly peel back layer after layer, exposing them and leaving them vulnerable."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:209
translate chinese JuR2_MS4_97ff7e8f:

    # Judy "For instance, you wanted to see me on my knees using my mouth on your cock. You probably enjoy seeing women in a submissive role to men like you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:211
translate chinese JuR2_MS4_53b07eef:

    # MC "I wouldn’t say that... I think you’re overthinking th-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:215
translate chinese JuR2_MS4_bc28f253:

    # Judy "*SHLURP*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:217
translate chinese JuR2_MS4_68c793a2:

    # MC "Oooohhhh! Fuuuck! Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:221
translate chinese JuR2_MS4_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:223
translate chinese JuR2_MS4_13ea3ab2:

    # MC "(She just took my cock in her mouth without any warning!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:225
translate chinese JuR2_MS4_61523ed2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:229
translate chinese JuR2_MS4_07fffcea:

    # Judy "*Suck* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:231
translate chinese JuR2_MS4_31c03c0b:

    # MC "Ah! *Pant* Mmm! God, you’re good at that, Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:235
translate chinese JuR2_MS4_acebadff:

    # Judy "Mmpff! *Gag* *Shluuuurrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:237
translate chinese JuR2_MS4_292975ff:

    # MC "Hnnngg! Mmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:241
translate chinese JuR2_MS4_a0250dcd:

    # MC "(I can feel my cock starting to slip down her throat!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:244
translate chinese JuR2_MS4_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:246
translate chinese JuR2_MS4_13335128:

    # MC "Mmmm! God, your mouth is fucking incredible, Judy. *Pant*"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:248
translate chinese JuR2_MS4_eb707d63:

    # Judy "*Shlurp* *Suck* *Suuuuucck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:254
translate chinese JuR2_MS4_d193fe95:

    # Judy "*Lick* *Lick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:256
translate chinese JuR2_MS4_7c54fe1f:

    # Judy "*Shluuuurrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:258
translate chinese JuR2_MS4_6eeaa59d:

    # MC "*Pant* Ah... Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:260
translate chinese JuR2_MS4_61523ed2_1:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:262
translate chinese JuR2_MS4_81933f4f:

    # Judy "*Lick* Mmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:263
translate chinese JuR2_MS4_189f322a:

    # MC "(She stopped sucking? Is she trying to tease me instead? I’ll show her.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:267
translate chinese JuR2_MS4_8fe860ae:

    # Judy "Mmppfff!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:269
translate chinese JuR2_MS4_1065073c:

    # MC "Did you think you could get away with deepthroating my cock and then just suddenly stop? I know what you’re trying to do, Judy. You’re deliberately teasing me."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:271
translate chinese JuR2_MS4_58d3e415:

    # Judy "*Gag* *Shlurrrp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:275
translate chinese JuR2_MS4_324ad4d4:

    # MC "That’s why you were lecturing me on dominant traits and seeing women on their knees. You wanted me to forcefully fuck your face like this, didn’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:277
translate chinese JuR2_MS4_db2ad8f6:

    # Judy "*SUCK* *SHLUUUURRRP* *GAG* MMPPFFFF!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:279
translate chinese JuR2_MS4_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:281
translate chinese JuR2_MS4_ba8d5334:

    # Judy "(It looks like [player_name] finally got the message!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:285
translate chinese JuR2_MS4_48782360:

    # Judy "*Gag* *Shlurp* *Shlick*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:287
translate chinese JuR2_MS4_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:289
translate chinese JuR2_MS4_d73469f9:

    # MC "Is that want you wanted Judy? For me to ram my ugh... thick cock down your tight throat?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:293
translate chinese JuR2_MS4_d7616f0a:

    # Judy "Nmmppff!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:295
translate chinese JuR2_MS4_2fb15637:

    # Judy "(He’s holding my head and fucking my face, like I’m nothing more than a sextoy to him. This is so fucking hot.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:297
translate chinese JuR2_MS4_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:301
translate chinese JuR2_MS4_6c6d3d63:

    # Judy "*Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:303
translate chinese JuR2_MS4_55a6ff35:

    # Judy "(Perhaps I could use this as inspiration for a future book? An exploration of the fetishisation of women as sextoys. Perhaps delving into the freeuse fetish?)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:305
translate chinese JuR2_MS4_8f3dde0b:

    # Judy "*Suck* *Gag* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:309
translate chinese JuR2_MS4_24f95052:

    # MC "*Pant* Fuck! Your throat is so tight."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:311
translate chinese JuR2_MS4_a909fc27:

    # MC "Hnnngg!!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:315
translate chinese JuR2_MS4_9489e7e1:

    # Judy "*SHLURP* *SUCK* *SUCK*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:319
translate chinese JuR2_MS4_4a6e3406:

    # MC "Ah! *Pant* I bet you love me doing this, don’t you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:321
translate chinese JuR2_MS4_8e1d76fc:

    # Judy "Mmpff! *Gag* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:323
translate chinese JuR2_MS4_753dfccd:

    # MC "You’re probably dripping wet on your office floor, right now."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:327
translate chinese JuR2_MS4_a213804e:

    # Judy "*Gag* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:329
translate chinese JuR2_MS4_3fbe8043:

    # MC "*Pant* Ugh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:331
translate chinese JuR2_MS4_ee996267:

    # MC "That’s it. Keep sucking my cock like that, you slut."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:335
translate chinese JuR2_MS4_1a1307ec:

    # Judy "(It appears I was correct - he DOES enjoy seeing women in a submissive role like this. The dirty talk corroborates my theory quite nicely.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:337
translate chinese JuR2_MS4_61523ed2_2:

    # Judy "*Shlurp* *Suck*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:341
translate chinese JuR2_MS4_78b41ad8:

    # MC "Hnnngg! Ugh! I’m gonna cum."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:343
translate chinese JuR2_MS4_81c4c7ee:

    # MC "(Where should I finish?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:349
translate chinese JuR2_MS4_ede28fdb:

    # MC "Hnnng!! Aarrgghh! I’m cumming!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:351
translate chinese JuR2_MS4_5498b6a2:

    # Judy "Mppfff! *Gag* *Shlurp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:353
translate chinese JuR2_MS4_9af687a9:

    # MC "Hnnngggggg! Ohhh! Fuck!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:357
translate chinese JuR2_MS4_0bfd0273:

    # Judy "*Gulp* *Gulp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:359
translate chinese JuR2_MS4_ef05d0a6:

    # MC "Ohhhh! (I can feel her cheeks wrapping around my cock as she swallows my semen!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:370
translate chinese JuR2_MS4_63d417a6:

    # MC "Fuck... *Pant* That was amazing."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:372
translate chinese JuR2_MS4_3dcf7632:

    # Judy "Mmm... See how fun it is when you give in to your desires? You enjoyed dominating my face, didn’t you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:374
translate chinese JuR2_MS4_2f586570:

    # MC "*Pant* Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:376
translate chinese JuR2_MS4_77f7763f:

    # Judy "There’s nothing wrong with exploring some of your more perverse desires with a consenting partner, [player_name]. Never forget that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:382
translate chinese JuR2_MS4_052a321f:

    # MC "Hnnng! I’m gonna cum!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:384
translate chinese JuR2_MS4_e445cb86:

    # Judy "Do it. Make a mess of my pretty little face."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:386
translate chinese JuR2_MS4_609a2dba:

    # MC "Argh! Stick your tongue out!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:388
translate chinese JuR2_MS4_21224e58:

    # Judy "Ahh..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:398
translate chinese JuR2_MS4_cdaeeb7e:

    # MC "Oohh! Ugh! Argh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:400
translate chinese JuR2_MS4_3d5467ce:

    # Judy "Aaahh...."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:402
translate chinese JuR2_MS4_c53418e6:

    # MC "*Pant* Hnnngg!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:408
translate chinese JuR2_MS4_5076f485:

    # MC "*Pant* *Pant* Fuck... That was amazing."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:410
translate chinese JuR2_MS4_3dcf7632_1:

    # Judy "Mmm... See how fun it is when you give in to your desires? You enjoyed dominating my face, didn’t you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:412
translate chinese JuR2_MS4_2f586570_1:

    # MC "*Pant* Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:414
translate chinese JuR2_MS4_77f7763f_1:

    # Judy "There’s nothing wrong with exploring some of your more perverse desires with a consenting partner, [player_name]. Never forget that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:420
translate chinese JuR2_MS4_61c5a38b:

    # MC "Bend over. I want to fuck your tight ass."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:422
translate chinese JuR2_MS4_cd3be7bd:

    # Judy "Mmm, someone’s confident."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:426
translate chinese JuR2_MS4_93e70acb:

    # MC "Are you sure I can’t just screw your pussy instead?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:428
translate chinese JuR2_MS4_14f5f270:

    # Judy "No condom, no pussy. That’s the rules."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:430
translate chinese JuR2_MS4_b1ddb5d0:

    # MC "Fine, fine."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:434
translate chinese JuR2_MS4_2a3b0096:

    # MC "I hope you’re ready for this, Judy. Because I’m about to rock your world."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:436
translate chinese JuR2_MS4_5227d103:

    # Judy "Oh really? You think you can rock my world in the thirty seconds that you’re going to last?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:438
translate chinese JuR2_MS4_9f21f953:

    # MC "Hey! I thought therapists were supposed to be supportive!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:442
translate chinese JuR2_MS4_6cb7b8a8:

    # Judy "If you think I’m being a bad therapist right now, then you should probably punish me. Go on, prove me wrong."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:444
translate chinese JuR2_MS4_ce6049aa:

    # Judy "Show me that you can fuck my tight little ass without blowing your load instantly."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:448
translate chinese JuR2_MS4_8efbe4c7:

    # MC "Heh, you’re on. Where’s the lube?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:450
translate chinese JuR2_MS4_ddb0ad91:

    # Judy "We’re not using any. Lube makes it easier for your cock to go in, but it also helps it slide out."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:454
translate chinese JuR2_MS4_2e019b1c:

    # Judy "I want you to feel what it’s like when my tight sphincter wraps around your dick. I want to see your expression when you realise you can’t pull out - without my ass milking your cock dry."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:456
translate chinese JuR2_MS4_e5478b3f:

    # MC "And what if it hurts you?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:460
translate chinese JuR2_MS4_83423e5b:

    # Judy "Perhaps I enjoy a little bit of pain, every now and then? Ready whenever you are, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:462
translate chinese JuR2_MS4_302312e5:

    # MC "(Does she really think I’m only going to last half a minute? She’s gotta be joking.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:466
translate chinese JuR2_MS4_09646c75:

    # MC "Alright Judy, brace yourself. I don’t want to hear you screaming in pain."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:468
translate chinese JuR2_MS4_617aa6f5:

    # Judy "Pfft, there you go, talking a big game again. Once you’re inside me, the only sound we’re going to be hearing are your moans."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:472
translate chinese JuR2_MS4_beb3842a:

    # MC "(Okay, let’s spread her cheeks and fuck her senseless. I’ll show Judy her place! She’ll never question my sexual stamina ever again!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:476
translate chinese JuR2_MS4_4a02fefd:

    # Judy "*Gasp*"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:478
translate chinese JuR2_MS4_c53b8455:

    # MC "You okay there, Judy?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:480
translate chinese JuR2_MS4_aa0a2fa9:

    # Judy "Yeah... Ah! Hnnng..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:484
translate chinese JuR2_MS4_3cb910ca:

    # MC "This is your final chance to use some lube."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:486
translate chinese JuR2_MS4_fd9032f2:

    # Judy "Ohhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:489
translate chinese JuR2_MS4_b07545f8:

    # Judy "And this ugh... is your final ah... chance to stop, before my ass humiliates you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:491
translate chinese JuR2_MS4_65a6b0dd:

    # MC "Sure... whatever you say."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:493
translate chinese JuR2_MS4_aa0a2fa9_1:

    # Judy "Yeah... Ah! Hnnng..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:497
translate chinese JuR2_MS4_00f60759:

    # MC "Ugh! Arrgh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:499
translate chinese JuR2_MS4_fd9032f2_1:

    # Judy "Ohhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:501
translate chinese JuR2_MS4_bdf64c1c:

    # MC "(Goddamn, she wasn’t lying! Her ass is REALLY tight! I can barely move my cock!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:505
translate chinese JuR2_MS4_c513e5f0:

    # Judy "*Pant* Ha... Ha... The hard part is getting it past the sphincter."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:507
translate chinese JuR2_MS4_4f046ca3:

    # MC "Ugh... Fuck..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:509
translate chinese JuR2_MS4_20f09bae:

    # Judy "Something *Pant* wrong, [player_name]?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:513
translate chinese JuR2_MS4_20021d29:

    # MC "Nope! You’re tight, but that ugh... just means I need to use a bit more force!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:515
translate chinese JuR2_MS4_4f046ca3_1:

    # MC "Ugh... Fuck..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:517
translate chinese JuR2_MS4_60866e6a:

    # Judy "Oh! Ah!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:519
translate chinese JuR2_MS4_225f232d:

    # MC "(Each time I pull back, it feels like her ass is sucking on my cock! I can see why she was so confident I wouldn’t last long without lube.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:523
translate chinese JuR2_MS4_fabd9b48:

    # Judy "Ah! Ahhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:525
translate chinese JuR2_MS4_ca5e07b0:

    # MC "What’s wrong, Judy? Hnnng! I thought the only thing we’d be hearing was the sound of MY moans?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:527
translate chinese JuR2_MS4_9372acf7:

    # Judy "*Gasp* Ah! You're sooooo mmm... big! Ohh! Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:531
translate chinese JuR2_MS4_8f1ddf71:

    # MC "Ah, so that’s your excuse? Tell me Judy, how long has it been since we started? It’s gotta be AT LEAST thirty seconds."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:533
translate chinese JuR2_MS4_d59c0f60:

    # Judy "Ah! Ah! Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:535
translate chinese JuR2_MS4_cdf181f4:

    # MC "What happened to that cocky prediction you made?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:539
translate chinese JuR2_MS4_98ba4aa9:

    # Judy "OOHHHHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:541
translate chinese JuR2_MS4_f8150c1c:

    # MC "That’s what I thought. Your asshole is clenching around my cock, you must be cumming already."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:543
translate chinese JuR2_MS4_d59c0f60_1:

    # Judy "Ah! Ah! Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:547
translate chinese JuR2_MS4_e15de19d:

    # Judy "Ayaaahhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:549
translate chinese JuR2_MS4_200ebb3a:

    # MC "You like being fucked hard in the ass, don’t you? This wasn’t about my stamina at all - you wanted me to fuck your unlubed ass because you wanted the pain!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:551
translate chinese JuR2_MS4_cf839457:

    # Judy "*Gasp* OOHHH! OH! AHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:555
translate chinese JuR2_MS4_7481732a:

    # Judy "(He worked it out much quicker than I had anticipated. It’s always a shame when my patients get too observant for me to easily manipulate them anymore.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:557
translate chinese JuR2_MS4_7a0b9035:

    # Judy "Ah! Ayaaahhhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:559
translate chinese JuR2_MS4_cf839457_1:

    # Judy "*Gasp* OOHHH! OH! AHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:562
translate chinese JuR2_MS4_07c28173:

    # MC "Your ass is a really good fuck, Judy. You know that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:564
translate chinese JuR2_MS4_3c7bf424:

    # Judy "Ah! *GASP* Ooohhhh! I’m cumming! I’m cummmmmmiiinnng!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:566
translate chinese JuR2_MS4_e562db67:

    # MC "That’s it Judy, cum for me! I want to see you tremble while my fat cock destroys your tight ass."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:569
translate chinese JuR2_MS4_d59c0f60_2:

    # Judy "Ah! Ah! Ahh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:571
translate chinese JuR2_MS4_98ba4aa9_1:

    # Judy "OOHHHHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:573
translate chinese JuR2_MS4_cf839457_2:

    # Judy "*Gasp* OOHHH! OH! AHH!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:574
translate chinese JuR2_MS4_eddea4e3:

    # MC "(Should I finish inside her? Or pull out and cum over her ass?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:581
translate chinese JuR2_MS4_db284076:

    # MC "Hnnnnggg! Argh!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:583
translate chinese JuR2_MS4_ce2c6c43:

    # Judy "*Pant* Ooohhh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:585
translate chinese JuR2_MS4_85ac20fb:

    # Judy "(Oh God! I can feel his cock twitching inside me! He’s cumming!)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:587
translate chinese JuR2_MS4_124c3cbf:

    # Judy "Yesssss! Fill me up! Mmmm!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:596
translate chinese JuR2_MS4_bc43d21d:

    # MC "Hnnnggg! Ooohhhhh! Mmmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:598
translate chinese JuR2_MS4_30dfa314:

    # Judy "*GASP* Aaaaahhhhh! *Pant* Yeeesssss!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:600
translate chinese JuR2_MS4_ed7150c0:

    # MC "Fuck... That was *Pant* amazing."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:604
translate chinese JuR2_MS4_a26d983e:

    # Judy "*Pant* Your semen is so warm..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:606
translate chinese JuR2_MS4_8d63ad8e:

    # Judy "(I can feel his cum slowly leaking out of my asshole. God, that was so hot.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:610
translate chinese JuR2_MS4_474a01dc:

    # Judy "Oh!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:612
translate chinese JuR2_MS4_4a496db2:

    # MC "(Her ass is still gaping a bit. She DEFINITELY wasn’t ready for a dick as big as mine! She seemed to enjoy it though!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:616
translate chinese JuR2_MS4_e4bd6f90:

    # Judy "Hehe, you certainly *Pant* lasted longer than I expected."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:618
translate chinese JuR2_MS4_99185e97:

    # MC "Oh please... you never believed I was only going to last thirty seconds. You were just egging me on so I’d get frustrated at the challenge, and fuck you harder."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:620
translate chinese JuR2_MS4_2f6d5c8b:

    # Judy "Aww, do you REALLY think I could EVER be that manipulative?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:622
translate chinese JuR2_MS4_5c2df02a:

    # MC "Absolutely. You’re devoid of the honesty and integrity required to be a therapist, Judy. You know that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:624
translate chinese JuR2_MS4_dd4c52f8:

    # Judy "Heh, so I’ve been told."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:631
translate chinese JuR2_MS4_ad3d745f:

    # MC "Hnnngg! Ahhh! Fuck! Mmm!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:633
translate chinese JuR2_MS4_a58b5198:

    # Judy "Yes! Cum for me, [player_name]! Paint my ass with your thick semen!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:643
translate chinese JuR2_MS4_b33896c7:

    # MC "*Pant* Fuck... Ugh! God..."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:645
translate chinese JuR2_MS4_4679826f:

    # Judy "Mmm... (I can feel his cum splattering over my ass.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:650
translate chinese JuR2_MS4_66c7f1eb:

    # MC "Ah... That was amazing, Judy. Thanks for that."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:652
translate chinese JuR2_MS4_e4bd6f90_1:

    # Judy "Hehe, you certainly *Pant* lasted longer than I expected."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:656
translate chinese JuR2_MS4_7731083a:

    # MC "Oh please, you never believed I was only going to last thirty seconds. You were just egging me on so I’d get frustrated at the challenge and fuck you harder."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:658
translate chinese JuR2_MS4_2f6d5c8b_1:

    # Judy "Aww, do you REALLY think I could EVER be that manipulative?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:660
translate chinese JuR2_MS4_5c2df02a_1:

    # MC "Absolutely. You’re devoid of the honesty and integrity required to be a therapist, Judy. You know that?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:662
translate chinese JuR2_MS4_dd4c52f8_1:

    # Judy "Heh, so I’ve been told."
    Judy ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:166
    old "I want you to suck my cock, Judy."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:166
    old "I want to fuck your tight ass."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:344
    old "Thrust your shaft deep into your therapist’s mouth and empty your balls deep down her throat."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:344
    old "Withdraw your cock, order Judy to stick her tongue out, and give your therapist a facial."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:577
    old "Cum deep inside Judy’s ass."
    new ""

    # game/scripts/Ju_scenes/JuR2_MS4_therapistroom.rpy:577
    old "Pull out and blow your hot load all over her buttcheeks."
    new ""

