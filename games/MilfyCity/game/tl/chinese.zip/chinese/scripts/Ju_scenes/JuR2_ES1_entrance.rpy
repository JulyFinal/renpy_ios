﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:44
translate chinese JuR2_ES1_36641d47:

    # MC "(I just can’t get it out of my head. Why was Judy on the phone with my mom?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:46
translate chinese JuR2_ES1_86885906:

    # MC "(I just can’t get it out of my head. Why was Judy on the phone with Linda? My landlady? Do they know each other?)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:47
translate chinese JuR2_ES1_a2be9822:

    # MC "(I mean, I guess it would make sense if she was updating her on what happened between me and Ms. Celia... but that’s not what it sounded like to me.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:49
translate chinese JuR2_ES1_61c5ddbd:

    # MC "(No, it’s clear that Judy had come to some kind of secret arrangement with my mom. Something fishy is going on, and I’m gonna get myself some answers!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:51
translate chinese JuR2_ES1_01a00b3e:

    # MC "(No, it’s clear that Judy had come to some kind of secret arrangement with Linda. Something fishy is going on, and I’m gonna get myself some answers!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:61
translate chinese JuR2_ES1_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:62
translate chinese JuR2_ES1_b6f94802:

    # Judy "Who is it?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:63
translate chinese JuR2_ES1_a0dace81:

    # MC "It’s [player_name], Judy."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:64
translate chinese JuR2_ES1_90c8d762:

    # Judy "Oh! Hold on, the front door is locked and I can’t find the key. I’m going to need you to travel to the other side of town, complete three poorly-optimised mini-games, and then save up $10,000 to buy a new key from the shop."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:65
translate chinese JuR2_ES1_b8281ee6:

    # MC "...what?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:68
translate chinese JuR2_ES1_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:72
translate chinese JuR2_ES1_90ab2584:

    # Judy "Haha, I’m just pulling your leg. Come on in. I do have to say though, I wasn’t expecting any visitors today."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:73
translate chinese JuR2_ES1_bd2a4f65:

    # MC "Yeah, I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:74
translate chinese JuR2_ES1_e9ca234d:

    # Judy "I much prefer knowing my plans in advance."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:75
translate chinese JuR2_ES1_894afce8:

    # MC "Listen, I need to talk to you abo-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:78
translate chinese JuR2_ES1_fd585945:

    # Judy "It just gives me more time to get prepared. You know?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:81
translate chinese JuR2_ES1_605bac37:

    # MC "Judy, there’s something-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:82
translate chinese JuR2_ES1_0281bb48:

    # Judy "Regardless, you’re here now, but in future I would appreciate a head’s up before you arrive. Just in case I’m in the middle of something more... private."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:86
translate chinese JuR2_ES1_c18d439d:

    # MC "Judy! Can I just get a word in?! I know you made some kinda secret deal with my mom!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:88
translate chinese JuR2_ES1_cb80a40d:

    # MC "Judy! Can I just get a word in?! I know you made some kinda secret deal with Linda!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:89
translate chinese JuR2_ES1_64e72a5c:

    # MC "I don’t know what the hell you two are up to, but everything I told you in therapy was supposed to be confidential! What are you doing? Sharing my secrets as gossip?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:92
translate chinese JuR2_ES1_9bd7fd7a:

    # Judy "Oh... I wasn’t aware that you knew."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:94
translate chinese JuR2_ES1_1cb2a5e5:

    # MC "So you WERE sharing what I told you during therapy with my mom?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:96
translate chinese JuR2_ES1_24006c3c:

    # MC "So you WERE sharing what I told you during therapy, with Linda?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:97
translate chinese JuR2_ES1_0fa7a986:

    # Judy "No! Absolutely not, I have never violated the confidentiality between me and my patients."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:98
translate chinese JuR2_ES1_f3476963:

    # MC "Then what’s this “deal” that you were talking with her about?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:101
translate chinese JuR2_ES1_f5e056a7:

    # Judy "Did you know that anger has been found to trigger a greater degree of certainty, leading to less careful processing of information?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:102
translate chinese JuR2_ES1_5ce13e03:

    # MC "What are you talking about?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:104
translate chinese JuR2_ES1_d85b6493:

    # Judy "You’re angry. You’re emotional. You’ve heard your mother and I talking about a “deal.” In your anger, you have jumped to the erroneous conclusion that any discussion between your mother and I must somehow be bad for you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:106
translate chinese JuR2_ES1_7a005b8c:

    # Judy "You’re angry. You’re emotional. You’ve heard Linda and I talking about a “deal.” In your anger, you have jumped to the erroneous conclusion that any discussion between Linda and I must somehow be bad for you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:107
translate chinese JuR2_ES1_5d92b90b:

    # MC "I’m not angry."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:108
translate chinese JuR2_ES1_92eb7d1b:

    # Judy "I can read your body language, [player_name]. Your fists are clenched. Your brow furrowed. Your voice elevated. It’s okay to be angry but we can’t allow rage to blind us to the evidence of what is actually happening."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:110
translate chinese JuR2_ES1_4f8470af:

    # Judy "If you wanted to know about the deal between your mother and I, you simply had to ask. You could have asked me in therapy. You could have sent me an email. Instead, you allowed it to bubble up inside you, to fester and ferment until..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:112
translate chinese JuR2_ES1_4d46af28:

    # Judy "If you wanted to know the deal between your landlady and I, you simply had to ask. You could have asked me in therapy. You could have sent me an email. Instead you allowed it to bubble up inside you, to fester and ferment until..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:113
translate chinese JuR2_ES1_72b6a460:

    # MC "...until I blew up on you at your front door."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:116
translate chinese JuR2_ES1_697cfe8e:

    # Judy "How about you come into the living room with me and we’ll sit down together? I can talk you through everything that has happened."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:118
translate chinese JuR2_ES1_0f93a989:

    # Judy "Try and relax. I promise you, the deal between your mother and I isn’t suspicious or malicious. If anything, it’s for your own good."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:120
translate chinese JuR2_ES1_c37322f9:

    # Judy "Try and relax. I promise you, the deal between Linda and I isn’t suspicious or malicious. If anything, it’s for your own good."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:121
translate chinese JuR2_ES1_7bd5a205:

    # MC "My own good?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:122
translate chinese JuR2_ES1_0c24de88:

    # Judy "Come on inside and take a seat. We’ll have a proper talk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:136
translate chinese JuR2_ES1_living_79242034:

    # MC "(Oh God, Judy was right. I was completely out of line there.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:138
translate chinese JuR2_ES1_living_5a57f9e6:

    # MC "(I ended up letting everything just bubble up inside me until I exploded. I mean, there’s probably a perfectly rational explanation behind this “deal” she has with my mom.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:140
translate chinese JuR2_ES1_living_3a4d1790:

    # MC "(I ended up letting everything just bubble up inside me until I exploded. I mean, there’s probably a perfectly rational explanation behind this “deal” she has with Linda.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:141
translate chinese JuR2_ES1_living_d95e77d5:

    # MC "(Fuck me, I’m such a dick.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:145
translate chinese JuR2_ES1_living_b75c57eb:

    # Judy "(Hmm... He’s looking a little bit down now. I should try and cheer him up before I reveal any details of the agreement his mom and I had.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:147
translate chinese JuR2_ES1_living_831003d2:

    # Judy "(Hmm... He’s looking a little bit down now. I should try and cheer him up before I reveal any details of the agreement Linda and I had.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:148
translate chinese JuR2_ES1_living_cd537970:

    # Judy "I thought you might be thirsty, is a beer okay?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:151
translate chinese JuR2_ES1_living_c44b8beb:

    # MC "Uh... Yeah, thanks."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:152
translate chinese JuR2_ES1_living_864d2447:

    # Judy "Sorry, I didn’t have anything else in the house. I wasn’t anticipating having a guest over tonight."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:153
translate chinese JuR2_ES1_living_35050ea7:

    # Judy "(I could have offered water or cola, but getting [player_name] a little bit tipsy should make it easier for me to manipulate him and regain some control over this situation.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:156
translate chinese JuR2_ES1_living_58167e2f:

    # MC "*Glug Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:158
translate chinese JuR2_ES1_living_28ab1591:

    # Judy "(Now, I just have to try and figure out the best way I can to explain the deal I have with his mother without scaring him off.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:160
translate chinese JuR2_ES1_living_2b256f77:

    # Judy "(Now, I just have to try and figure out the best way I can to explain the deal I have with Linda without scaring him off.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:161
translate chinese JuR2_ES1_living_c248c87c:

    # Judy "You must be exhausted suppressing that secret for so long. Take a long drink, relax yourself. You can ask me whatever you want when you’ve calmed down. Just let me know when you’re ready to talk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:190
translate chinese JuR2_ES1_Living_q1_d192ba4c:

    # MC "Okay... I guess one of my biggest questions is, when did you decide to get in touch with my mom? Did you get her number from the school records after I messed up with Celia?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:192
translate chinese JuR2_ES1_Living_q1_d26fa265:

    # MC "Okay... I guess one of my biggest questions is, when did you decide to get in touch with Linda? Did you get her number from the college records after I messed up with Celia?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:196
translate chinese JuR2_ES1_Living_q1_f6de07ec:

    # Judy "Ooh, is that what you are so concerned about?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:198
translate chinese JuR2_ES1_Living_q1_20f3f1e9:

    # Judy "[player_name], your mom and I have known each other since we were both in high school."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:200
translate chinese JuR2_ES1_Living_q1_62220443:

    # Judy "[player_name], Linda and I have known each other since we were both in high school."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:204
translate chinese JuR2_ES1_Living_q1_1e81afbe:

    # MC "R-Really?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:205
translate chinese JuR2_ES1_Living_q1_545c1b0e:

    # Judy "Of course! We took Chemistry, Physics, and Maths together. We kept in touch over the years."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:206
translate chinese JuR2_ES1_Living_q1_3ec2bc9f:

    # MC "Huh... I’ve never heard her talk about you before."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:207
translate chinese JuR2_ES1_Living_q1_3f7f3807:

    # Judy "Drink up, you look parched."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:211
translate chinese JuR2_ES1_Living_q1_c6036b31:

    # Judy "Linda and I know each other very well. We’ve drifted in and out of each other's lives for the past couple of decades."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:212
translate chinese JuR2_ES1_Living_q1_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:213
translate chinese JuR2_ES1_Living_q1_a0b342e0:

    # Judy "We even dated some of the same boys over the years."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:214
translate chinese JuR2_ES1_Living_q1_07b9b786:

    # Judy "(Not to mention the odd fling with the same girls.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:217
translate chinese JuR2_ES1_Living_q1_d890b5dd:

    # Judy "I can understand her not speaking about me much, especially after settling down with Bob and..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:220
translate chinese JuR2_ES1_Living_q1_3b08fb17:

    # Judy "(...starting a family.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:224
translate chinese JuR2_ES1_Living_q1_96048831:

    # Judy "*Ahem* But I was engrossed in my PhD, your mom was engrossed in raising her three wonderful children, and WE are getting off track."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:226
translate chinese JuR2_ES1_Living_q1_eeb9dce9:

    # Judy "*Ahem* But I was engrossed in my PhD, Linda was engrossed in her new relationship and career with Bob. However, WE are getting off track!"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:234
translate chinese JuR2_ES1_Living_q2_656ec442:

    # MC "So, tell me about this deal you’ve made with my mom?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:236
translate chinese JuR2_ES1_Living_q2_104e6545:

    # MC "So, tell me about this deal you’ve made with Linda?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:237
translate chinese JuR2_ES1_Living_q2_e664816a:

    # Judy "Oh, it’s really nothing special or significant."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:240
translate chinese JuR2_ES1_Living_q2_b190ce42:

    # MC "If it’s insignificant, then just tell me! I’ve been left in the dark here, and it’s-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:243
translate chinese JuR2_ES1_Living_q2_6f0b2652:

    # Judy "Making you feel anxious?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:244
translate chinese JuR2_ES1_Living_q2_a6fbf3fc:

    # MC "Y-Yes!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:246
translate chinese JuR2_ES1_Living_q2_96213594:

    # Judy "Very well. There really isn’t that much to tell you though. I’ve been conducting research for my newest book. Your mom has been assisting me with that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:248
translate chinese JuR2_ES1_Living_q2_bcef48c6:

    # Judy "Very well. There really isn’t that much to tell you though. I’ve been conducting research for my newest book. Linda has been assisting me with that."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:251
translate chinese JuR2_ES1_Living_q2_5a11ff9f:

    # MC "Assisting you? Assisting you, how? What’s this book about?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:252
translate chinese JuR2_ES1_Living_q2_b5f6bca9:

    # Judy "Oh, it’s nothing more than highly-technical psychological drivel. I assure you, the topic would bore you to death."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:253
translate chinese JuR2_ES1_Living_q2_d29e7770:

    # MC "Try me."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:254
translate chinese JuR2_ES1_Living_q2_d8b3ebd7:

    # Judy "(It is definitely too early to drop the full extent of the nature of my research. I’ll just embed my answer in layers of jargon and make it too vague for him to understand.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:256
translate chinese JuR2_ES1_Living_q2_570f7826:

    # Judy "Very well. I’m expounding on Freudian theories of the Oedipus complex as it pertains to integral development of the-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:258
translate chinese JuR2_ES1_Living_q2_7c4f6781:

    # Judy "Very well. I'm expounding on Freudian theories of the Milfius Complex as it pertains to integral development of the-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:261
translate chinese JuR2_ES1_Living_q2_87b5b563:

    # MC "(I don’t understand a word of what she’s saying. It’s like she’s speaking some made-up language!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:262
translate chinese JuR2_ES1_Living_q2_cbc032d7:

    # MC "(If I let her know I don’t understand then she’ll just think I’m stupid. If that happens she will think she can get away with manipulating me or keeping me in the dark again.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:263
translate chinese JuR2_ES1_Living_q2_d336a72a:

    # Judy "...through the lens of an impartial observer in order to evaluate what brings true satisfaction."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:264
translate chinese JuR2_ES1_Living_q2_c9cbc987:

    # MC "Hmm... Yes. That makes... sense. Very... intriguing."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:268
translate chinese JuR2_ES1_Living_q2_dcae02ca:

    # Judy "I’m glad to see you taking an interest in my work. Your mother has been a great help in providing me with additional research materials."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:269
translate chinese JuR2_ES1_Living_q2_302e984c:

    # Judy "She has also acted as a sounding board to help me decide which elements of research I should pursue further, as well as which ones are ‘dead ends’, so to speak."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:272
translate chinese JuR2_ES1_Living_q2_da898f67:

    # Judy "I’m glad to see you taking an interest in my work. Linda has been a great help in providing me with additional research materials."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:273
translate chinese JuR2_ES1_Living_q2_302e984c_1:

    # Judy "She has also acted as a sounding board to help me decide which elements of research I should pursue further, as well as which ones are ‘dead ends’, so to speak."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:282
translate chinese JuR2_ES1_Living_q3_cc6a4cd9:

    # MC "Why are you and my mom being so secretive about this deal? What have you got to hide?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:284
translate chinese JuR2_ES1_Living_q3_91f2ce69:

    # MC "Why are you and Linda being so secretive about this deal? What have you got to hide?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:285
translate chinese JuR2_ES1_Living_q3_86fd1573:

    # Judy "Oh, I assure you, there is nothing nefarious going on. I’ll explain everything. Take another drink."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:288
translate chinese JuR2_ES1_Living_q3_58167e2f:

    # MC "*Glug Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:289
translate chinese JuR2_ES1_Living_q3_e5e0af09:

    # Judy "You see, not every piece of academic research is smooth sailing. Some... avenues of research are..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:290
translate chinese JuR2_ES1_Living_q3_a54c6113:

    # Judy "...controversial."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:293
translate chinese JuR2_ES1_Living_q3_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:294
translate chinese JuR2_ES1_Living_q3_f1746978:

    # Judy "What I’m trying to say is... Something that I find to be perfectly natural, or even highly exciting may be considered... controversial or taboo by others."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:298
translate chinese JuR2_ES1_Living_q3_f2423698:

    # Judy "This deal I have with your mother about my research may be considered... fairly taboo by some less open-minded folk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:300
translate chinese JuR2_ES1_Living_q3_27c0ac8e:

    # Judy "This deal I have with Linda about my research may be considered... fairly taboo by some less open-minded folk."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:303
translate chinese JuR2_ES1_Living_q3_6e72f10d:

    # Judy "You’re not closed-minded though, are you? You always seemed like a very intelligent, open-minded guy to me."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:304
translate chinese JuR2_ES1_Living_q3_bc484eb8:

    # MC "I am, actually. *Hic* I’m very open-minded and *hic* stuff like that."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:305
translate chinese JuR2_ES1_Living_q3_171249fb:

    # Judy "That’s good to hear."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:313
translate chinese JuR2_ES1_Living_q4_08a18194:

    # MC "So, what’s taboo about your research?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:314
translate chinese JuR2_ES1_Living_q4_d5f3f3e9:

    # Judy "“Taboo” is subjective, [player_name]. Let me give you an example. I’m going to give you some examples and I want you to rank how ‘taboo’ they are in your mind."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:315
translate chinese JuR2_ES1_Living_q4_8e64ea0d:

    # Judy "We’ll use a scale of one to ten, with one being ‘not taboo at all’ and ten being ‘extremely taboo.’"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:318
translate chinese JuR2_ES1_Living_q4_1040b3d9:

    # MC "Uhh... Okay. But why me?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:319
translate chinese JuR2_ES1_Living_q4_c2d196bb:

    # Judy "It will help you appreciate the work that I’m doing. "
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:322
translate chinese JuR2_ES1_Living_q4_d6b2d64e:

    # Judy "Now, some of these questions may make you feel... a little uncomfortable. But try to answer them as honestly as you can."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:323
translate chinese JuR2_ES1_Living_q4_11c22474:

    # MC "*Gulp* Alright..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:324
translate chinese JuR2_ES1_Living_q4_d534ec38:

    # Judy "Actually, take a drink before we begin. You look thirsty."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:327
translate chinese JuR2_ES1_Living_q4_58167e2f:

    # MC "*Glug Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:328
translate chinese JuR2_ES1_Living_q4_d92a8d3b:

    # Judy "Good boy."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:331
translate chinese JuR2_ES1_Living_q4_a350707e:

    # Judy "So, I want you to imagine you are asking a girl you like out on a date. Someone around 20 years old."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:334
translate chinese JuR2_ES1_Living_q4_07e8f129:

    # MC "Uh... *Hic* One?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:336
translate chinese JuR2_ES1_Living_q4_8e1b4394:

    # Judy "Okay. Now, I want you to imagine that you’re asking out someone a few years younger than you."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:338
translate chinese JuR2_ES1_Living_q4_911790c4:

    # Judy "Okay, now I want you to imagine that you're asking out someone closer to your own age."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:341
translate chinese JuR2_ES1_Living_q4_03c6d6ae:

    # MC "My age? 18 years old? Hmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:343
translate chinese JuR2_ES1_Living_q4_45eaf2f2:

    # Judy "Someone... around Sara’s age."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:345
translate chinese JuR2_ES1_Living_q4_89a26e5d:

    # Judy "Let’s say someone like... Sara or Lily."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:346
translate chinese JuR2_ES1_Living_q4_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:348
translate chinese JuR2_ES1_Living_q4_e9d903f4:

    # MC "Umm... Maybe a two or three?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:350
translate chinese JuR2_ES1_Living_q4_84ea767b:

    # MC "Umm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:353
translate chinese JuR2_ES1_Living_q4_f57d668a:

    # Judy "See? Easy, right?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:354
translate chinese JuR2_ES1_Living_q4_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:355
translate chinese JuR2_ES1_Living_q4_973b5fff:

    # Judy "Now, how about an older woman?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:356
translate chinese JuR2_ES1_Living_q4_6be799b8:

    # MC "Like Caroline’s age?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:358
translate chinese JuR2_ES1_Living_q4_a396d12d:

    # Judy "Let’s say... someone the same age as me or your mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:360
translate chinese JuR2_ES1_Living_q4_44065af7:

    # Judy "Let’s say... someone the same age as me or Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:364
translate chinese JuR2_ES1_Living_q4_f502ef19:

    # MC "M-My mom?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:366
translate chinese JuR2_ES1_Living_q4_8b032156:

    # MC "L-Linda?! "
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:367
translate chinese JuR2_ES1_Living_q4_06dac59e:

    # Judy "How taboo would it feel asking out someone that age on a date?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:368
translate chinese JuR2_ES1_Living_q4_a25afa3f:

    # MC "I... uh... I... S-Seven?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:371
translate chinese JuR2_ES1_Living_q4_8466c2f3:

    # Judy "Hmm... Interesting. What about if we switched things around?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:372
translate chinese JuR2_ES1_Living_q4_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:376
translate chinese JuR2_ES1_Living_q4_80ba4f72:

    # Judy "How would you feel if a woman of your mother’s age showed a romantic interest in you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:378
translate chinese JuR2_ES1_Living_q4_3d2cc235:

    # Judy "How would you feel if a woman of Linda’s age showed a romantic interest in you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:379
translate chinese JuR2_ES1_Living_q4_582a4637:

    # MC "Ah- I- Um-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:380
translate chinese JuR2_ES1_Living_q4_559d0a86:

    # Judy "Would it feel taboo to you if someone old enough to be your mother took you into their bedroom and unbuckled your jeans?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:381
translate chinese JuR2_ES1_Living_q4_8753bc5d:

    # MC "I- I- I need another drink."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:384
translate chinese JuR2_ES1_Living_q4_d5c280e8:

    # Judy "(Intriguing... He’s getting flustered. I’ll have to make sure to document this when he leaves. Let’s see how far I can push him.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:385
translate chinese JuR2_ES1_Living_q4_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:386
translate chinese JuR2_ES1_Living_q4_4b5c2eeb:

    # Judy "How taboo would it be if this older woman pulled down your underwear and exposed your virgin cock?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:389
translate chinese JuR2_ES1_Living_q4_fc7f9667:

    # MC "*Cough* *Splutter*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:390
translate chinese JuR2_ES1_Living_q4_b213d622:

    # MC "I- I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:391
translate chinese JuR2_ES1_Living_q4_b220b933:

    # Judy "You’re stammering. I’ll assume that it is extremely taboo for you? It’s okay for inexperienced virgins to find situations like this taboo."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:392
translate chinese JuR2_ES1_Living_q4_fb74cbd8:

    # MC "Wh-What?! (Shit! She’s going to think I’m a cringeworthy virgin now!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:393
translate chinese JuR2_ES1_Living_q4_ea8d7f96:

    # MC "N-NO! It’s n-not taboo at all. Like a... like a... three out of ten. J-Just a three."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:396
translate chinese JuR2_ES1_Living_q4_8594fd8f:

    # Judy "Really? Are you lying to me, [player_name]? Because your reaction right now suggests that the idea of being with an older woman is-"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:397
translate chinese JuR2_ES1_Living_q4_9962bab5:

    # MC "I’m not lying! It’s a three, I swear! And I’m not some... inexperienced virgin."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:398
translate chinese JuR2_ES1_Living_q4_c7eba1e9:

    # Judy "Uh huh... Very well then. Let’s continue."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:399
translate chinese JuR2_ES1_Living_q4_e205a3ee:

    # Judy "On a scale of one to ten, how taboo would you consider it to be for that older woman to wrap her fingers around your inexperienced virgin cock?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:400
translate chinese JuR2_ES1_Living_q4_be9d05ff:

    # MC "Th-Three."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:401
translate chinese JuR2_ES1_Living_q4_355d6cb1:

    # Judy "What about if she got down on her knees before you and dragged her tongue over your hard, young shaft? What if she licked her lips and took your hard cock in her hot, wet mouth?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:402
translate chinese JuR2_ES1_Living_q4_bb12dcca:

    # MC "(Shit, I’m going to get a boner just listening to her! I can’t rank it any higher than a three or she’ll think I’m just a wimp.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:405
translate chinese JuR2_ES1_Living_q4_1be4ad3b:

    # MC "S-Still a three."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:406
translate chinese JuR2_ES1_Living_q4_7ea8f131:

    # Judy "Interesting..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:409
translate chinese JuR2_ES1_Living_q4_e3417260:

    # Judy "I’m going to describe a final scenario and I want you to tell me how taboo it is. I want you to close your eyes and imagine that beautiful, big-breasted MILF bobbing her head up and down between your legs."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:410
translate chinese JuR2_ES1_Living_q4_4e85c061:

    # Judy "I want you to imagine her fingers cradling your balls. I want you to feel the sensation of her tongue twirling over your glans."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:411
translate chinese JuR2_ES1_Living_q4_420c9f20:

    # Judy "I want you to feel yourself driven to the edge of a climax, as her years of experience prove too much for your young, inexperienced body to handle."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:412
translate chinese JuR2_ES1_Living_q4_4be37e2b:

    # MC "(Oh fuck...)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:413
translate chinese JuR2_ES1_Living_q4_e839c39c:

    # Judy "And as you feel yourself begin to cum I want you to imagine your hot semen flowing down your shaft, filling up her mouth with your seed."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:414
translate chinese JuR2_ES1_Living_q4_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:415
translate chinese JuR2_ES1_Living_q4_93817fdd:

    # Judy "And as you feel the orgasmic contractions surging through your body, you open your eyes and look down..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:416
translate chinese JuR2_ES1_Living_q4_0f756bc9:

    # MC "Hnng...."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:420
translate chinese JuR2_ES1_Living_q4_c0b63a1d:

    # Judy "...into the face of your own mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:422
translate chinese JuR2_ES1_Living_q4_de0baae8:

    # Judy "...into the face of Linda."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:423
translate chinese JuR2_ES1_Living_q4_0b20b83a:

    # MC "WH-WHAT?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:424
translate chinese JuR2_ES1_Living_q4_f997251c:

    # Judy "Hmm, that was a massive reaction. I’m going to record that as a ‘ten’ on the taboo scale."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:426
translate chinese JuR2_ES1_Living_q4_ff3fe5ce:

    # MC "W-WAIT, Y-You never told me that it would be my-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:428
translate chinese JuR2_ES1_Living_q4_fbd31c95:

    # MC "W-WAIT, Y-You never told me that it would be Li-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:429
translate chinese JuR2_ES1_Living_q4_97bcae44:

    # Judy "If I told you what the experiment was going to be testing for, then it wouldn’t be a good experiment. You’d have pre-prepared mental defences and built up expectations, negating the usefulness of any data that I collected today."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:432
translate chinese JuR2_ES1_Living_q4_4df4b075:

    # Judy "However, I will concede that I was... unfair to involve you in my research without your fully informed consent. So, how about I make it up to you?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:433
translate chinese JuR2_ES1_Living_q4_0fa24216:

    # MC "Make it up to me? How?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:434
translate chinese JuR2_ES1_Living_q4_5f0758ff:

    # Judy "I’m thinking that we could make a deal of our own."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:435
translate chinese JuR2_ES1_Living_q4_f0917950:

    # MC "What would that entail?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:439
translate chinese JuR2_ES1_Living_q4_44bfeded:

    # Judy "You keep me informed about the relationship you are having with your mom. Let me know how everything is going. And I do mean every detail. I don’t know how close you two are, but it would be good to know for my research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:441
translate chinese JuR2_ES1_Living_q4_69f2375f:

    # Judy "You keep me informed about the relationship you are having with Linda. Let me know how everything is going. And I do mean every detail. I don’t know how close you two are, but it would be good to know for my research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:442
translate chinese JuR2_ES1_Living_q4_9e84f7e1:

    # MC "And what would I get in return?"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:445
translate chinese JuR2_ES1_Living_q4_9cc11b58:

    # Judy "I don’t know. I haven’t decided yet."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:446
translate chinese JuR2_ES1_Living_q4_44b3b804:

    # MC "Wha-"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:447
translate chinese JuR2_ES1_Living_q4_3261d8f7:

    # Judy "If only there was some way I could... repay you for helping me gather data for my research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:450
translate chinese JuR2_ES1_Living_q4_66a58c2b:

    # Judy "I’m going to need both quantitative and qualitative data to finish my book. That means, if you take this deal, I’m going to need descriptions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:451
translate chinese JuR2_ES1_Living_q4_a1c21d84:

    # Judy "Detailed descriptions."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:452
translate chinese JuR2_ES1_Living_q4_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:454
translate chinese JuR2_ES1_Living_q4_26c4e2d6:

    # Judy "Of course, recounting details of what goes on between you and your family could prove to get you all... hot and bothered. It would be unfair for me to leave you in a difficult position."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:456
translate chinese JuR2_ES1_Living_q4_07c15f8a:

    # Judy "Of course, recounting details of what goes on between you and your roommates could prove to get you all... hot and bothered. It would be unfair for me to leave you in a difficult position."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:457
translate chinese JuR2_ES1_Living_q4_705252bd:

    # MC "I- I gotta go."
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:460
translate chinese JuR2_ES1_Living_q4_430fff45:

    # Judy "No problem, [player_name]. Just take time to think about my offer. I wouldn’t want you missing out on this research. Working with a Doctor on a critically-acclaimed piece of psychological literature could prove great for your future CV..."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:461
translate chinese JuR2_ES1_Living_q4_a1a6d2f5:

    # Judy "...and I promise you, it will be a LOT of fun."
    Judy ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:462
translate chinese JuR2_ES1_Living_q4_ce723804:

    # MC "(This is so weird... I don’t know whether to trust her at all.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:464
translate chinese JuR2_ES1_Living_q4_5cc04dd2:

    # MC "(I mean, she’s been so secretive, this whole time going behind my back to speak with, my mom when she’s also acting as my therapist!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:466
translate chinese JuR2_ES1_Living_q4_bf217dfc:

    # MC "(I mean, she’s been so secretive this whole time going behind my back to speak with, Linda when she’s also acting as my therapist!)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:467
translate chinese JuR2_ES1_Living_q4_3d9b3eb8:

    # MC "(It’s surely unethical, if not outright illegal! I need to take some time to think about this before I go jumping into this deal of hers.)"
    MC ""

# game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:489
translate chinese JuR2_ES1_after_de001821:

    # MC "(I shouldn't go in there now.)"
    MC ""

translate chinese strings:

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "How do you know my mom?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "How do you know Linda?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "What’s this “deal” that you’ve made with my mom?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "What’s this “deal” that you’ve made with Linda?"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "{color=#00ff00}Why are you and my mom being so secretive about this “deal”?{/color}"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "{color=#00ff00}Why are you and Linda being so secretive about this “deal”?{/color}"
    new ""

    # game/scripts/Ju_scenes/JuR2_ES1_entrance.rpy:167
    old "{color=#00ff00}What’s taboo about your research?{/color}"
    new ""

