﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:29
translate chinese JuR2_MS3_a6b1e905:

    # MC "Judy? Are you free right now? We REALLY need to talk!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:30
translate chinese JuR2_MS3_ee870ef3:

    # Judy "Easy, easy, calm down, [player_name]. What’s wrong?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:31
translate chinese JuR2_MS3_af756ebc:

    # MC "I... I fucked up! I fucked up and I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:35
translate chinese JuR2_MS3_641b15db:

    # Judy "Calm down. Deep breaths, [player_name]. Take a deep breath and try to avoid panicking."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:36
translate chinese JuR2_MS3_b213d622:

    # MC "I- I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:37
translate chinese JuR2_MS3_ff09665c:

    # Judy "Come on in and take a seat. Trust me, you’ll feel better after you sit down. You’re running on adrenaline right now."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:41
translate chinese JuR2_MS3_7dab0759:

    # MC "I’ve fucked up, Judy. It’s real bad. I’ve-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:42
translate chinese JuR2_MS3_67289242:

    # Judy "Is someone dead?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:43
translate chinese JuR2_MS3_0f9263f1:

    # MC "E-Excuse me?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:47
translate chinese JuR2_MS3_60ed8c92:

    # Judy "I asked you if someone was dead."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:48
translate chinese JuR2_MS3_9b5b65ad:

    # MC "N-No, why would-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:49
translate chinese JuR2_MS3_4b0b0ddf:

    # Judy "So, nobody has died?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:50
translate chinese JuR2_MS3_297427ac:

    # MC "No! Why would you even ask me that?!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:54
translate chinese JuR2_MS3_927eb609:

    # Judy "You’re reacting as if the worst thing in the world has happened to you. Something irreversible and unfixable. In my line of work that usually only means death."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:55
translate chinese JuR2_MS3_6e41b02e:

    # Judy "If something bad has happened, then by all means, you have the right to feel upset, afraid or angry. But try to keep it in perspective."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:56
translate chinese JuR2_MS3_2a63fef6:

    # Judy "Now, is the situation you are currently facing, as bad as someone dying?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:60
translate chinese JuR2_MS3_3a322ebb:

    # MC "...no."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:61
translate chinese JuR2_MS3_3483e5bc:

    # Judy "See? How does that make you feel now?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:62
translate chinese JuR2_MS3_378cd017:

    # MC "A bit... a bit better."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:66
translate chinese JuR2_MS3_d99cd7f1:

    # MC "Hey, you’re good at this!"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:67
translate chinese JuR2_MS3_a694e3bc:

    # Judy "Of course I am, it’s my job. I’ve only been doing it for God-knows-how-many years! But back to the topic at hand. I want you to, VERY CALMLY, explain to me what has happened."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:68
translate chinese JuR2_MS3_2b5561f7:

    # MC "*Sigh* Alright. So, I was with Linda. We were fooling around in the bedroom and-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:72
translate chinese JuR2_MS3_2e22e6b3:

    # Judy "Oh. Oh my, I think I see where this is headed. Regret is a perfectly normal feeling to have after engaging in sexual activities which are considered “taboo” by society."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:73
translate chinese JuR2_MS3_e5c707c0:

    # MC "No, it isn’t- I’m not feeling guilty about-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:75
translate chinese JuR2_MS3_50072652:

    # Judy "Hmm? You aren’t here because you’re feeling regret about the sexual activities you have been undertaking with your mother."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:77
translate chinese JuR2_MS3_34c0821d:

    # Judy "Hmm? You aren’t here because you’re feeling regret about the sexual activities you have been undertaking with an older married woman?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:78
translate chinese JuR2_MS3_9387e86e:

    # MC "No! It’s Bob! He came home while we were-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:82
translate chinese JuR2_MS3_a6cd20a0:

    # Judy "Oh my! I’m going to have to cut you off there, I’m afraid. This is DEFINITELY a topic that warrants a private therapy session."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:83
translate chinese JuR2_MS3_d1f996a8:

    # MC "But, I-"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:84
translate chinese JuR2_MS3_ba41d02f:

    # Judy "We wouldn’t want any of your fellow students overhearing our discussions on this rather sensitive subject, would we?"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:88
translate chinese JuR2_MS3_63318217:

    # MC "Oh yeah, you’re right."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:89
translate chinese JuR2_MS3_1bb06eba:

    # Judy "So, here’s what we’ll do. You’ll come over to my house in the evening. Hopefully you’ll have had time to sit back and process some of the thoughts which had caused you to be in such an anxious state when you arrived."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:90
translate chinese JuR2_MS3_64591a83:

    # MC "Yeah, that sounds good."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:94
translate chinese JuR2_MS3_a3366dba:

    # MC "Thanks Judy, appreciate it."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:95
translate chinese JuR2_MS3_792e0f9e:

    # Judy "No problem, [player_name]. We’ll have a good private session tonight. You can talk to me at length about the issues you’re facing with Bob."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:96
translate chinese JuR2_MS3_3f3563dd:

    # Judy "We’ll get to the bottom of this together and work through it."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:100
translate chinese JuR2_MS3_00ff6c07:

    # MC "Thanks Judy, you are definitely one of the greatest therapists of all time."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:101
translate chinese JuR2_MS3_fa80d5c6:

    # Judy "Of course I am. Now, head on and try to put your worries aside until this evening."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:102
translate chinese JuR2_MS3_95db53c6:

    # MC "I’ll try."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:106
translate chinese JuR2_MS3_70147314:

    # Judy "Oh, and one last thing, [player_name]."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:107
translate chinese JuR2_MS3_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:108
translate chinese JuR2_MS3_e2d3875e:

    # Judy "I’m probably going to be attempting some cutting-edge therapy techniques tonight. These haven’t been peer-reviewed or approved by the American Psychiatric Association, so I hope you are able to keep our sessions... confidential."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:112
translate chinese JuR2_MS3_c045adbc:

    # MC "Yeah, no sweat."
    MC ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:113
translate chinese JuR2_MS3_f370de48:

    # Judy "Thank you, [player_name]. I knew I could trust you to help with my research."
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:117
translate chinese JuR2_MS3_b1634244:

    # Judy "(And now for the final stage of my master plan! I’ll have to be careful with my next steps. There’s going to be a lot of moving parts to keep an eye on.)"
    Judy ""

# game/scripts/Ju_scenes/JuR2_MS3_therapistroom.rpy:118
translate chinese JuR2_MS3_df524a2e:

    # Judy "(Bob, Linda, and [player_name]... I’ll have to be very careful to balance everything, as I move forward.)"
    Judy ""

