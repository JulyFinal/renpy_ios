﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/2_MLR4_MS2.rpy:42
translate chinese MLR4_MS2_4ad84445:

    # Linda "I don’t want to talk about it!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:43
translate chinese MLR4_MS2_b3f584f4:

    # Bob "Well forgive me if I feel like I’m entitled to at least a LITTLE explanation of what was going on!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:44
translate chinese MLR4_MS2_62a0831a:

    # MC "Oh no..."
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:46
translate chinese MLR4_MS2_ba2d4761:

    # Linda "I said I don’t want to talk about it!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:47
translate chinese MLR4_MS2_ed1986e2:

    # Bob "You can’t avoid this any longer, Linda! This cold shoulder you’re giving me has been going on for years now!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:49
translate chinese MLR4_MS2_13b1d83d:

    # MC "(Shit, better stay out of sight.)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:51
translate chinese MLR4_MS2_bb759eac:

    # Bob "Come on, Linda. It’s one thing to act cold towards me, but don’t gaslight me and pretend that nothing happened!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:52
translate chinese MLR4_MS2_d3552255:

    # Linda "I’m not going to engage when you’re angry like this."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:54
translate chinese MLR4_MS2_17722377:

    # Bob "I’m not angry at you. I’m just frustrated. I’ve already forgiven you, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:55
translate chinese MLR4_MS2_093b6026:

    # Linda "Wh-What?"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:56
translate chinese MLR4_MS2_9fac0a8e:

    # Bob "I can understand why you did what you did. I know you haven’t been happy. I’ve been acting like a flamingo - and pretending it would pass."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:58
translate chinese MLR4_MS2_321cf512:

    # Bob "But... at least fucking talk to me about it! You can’t just give me the cold shoulder when I’m trying to fix things, and then act as if you’re the only aggrieved party here!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:59
translate chinese MLR4_MS2_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:61
translate chinese MLR4_MS2_04078f62:

    # Bob "Thirty years, Linda... Thirty years..."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:62
translate chinese MLR4_MS2_73bc337f:

    # Bob "*Sigh* Thirty years and three children. Can we at least be mature about this, for their sake?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:63
translate chinese MLR4_MS2_57b03333:

    # Linda "...I’m sorry."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:65
translate chinese MLR4_MS2_e9680c14:

    # Linda "But... can you at least try to see things from my point of view? I mean, how could I possibly tell you?!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:66
translate chinese MLR4_MS2_d2725365:

    # Linda "How would you have reacted if I told you the truth?!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:68
translate chinese MLR4_MS2_0e3ba499:

    # Bob "Easy, easy... I’m sorry for shouting earlier. *Sigh*"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:69
translate chinese MLR4_MS2_7e9ee579:

    # Bob "How about we both try and keep our voices down? We’re both professional adults. Let’s handle this like the mature people we are."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:71
translate chinese MLR4_MS2_2bbcd453:

    # Linda "... *Sigh* Alright."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:74
translate chinese MLR4_MS2_4ad84445_1:

    # Linda "I don’t want to talk about it!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:75
translate chinese MLR4_MS2_b3f584f4_1:

    # Bob "Well forgive me if I feel like I’m entitled to at least a LITTLE explanation of what was going on!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:76
translate chinese MLR4_MS2_62a0831a_1:

    # MC "Oh no..."
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:78
translate chinese MLR4_MS2_ba2d4761_1:

    # Linda "I said I don’t want to talk about it!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:79
translate chinese MLR4_MS2_ed1986e2_1:

    # Bob "You can’t avoid this any longer, Linda! This cold shoulder you’re giving me has been going on for years now!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:81
translate chinese MLR4_MS2_13b1d83d_1:

    # MC "(Shit, better stay out of sight.)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:83
translate chinese MLR4_MS2_bb759eac_1:

    # Bob "Come on, Linda. It’s one thing to act cold towards me, but don’t gaslight me and pretend that nothing happened!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:84
translate chinese MLR4_MS2_d3552255_1:

    # Linda "I’m not going to engage when you’re angry like this."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:86
translate chinese MLR4_MS2_17722377_1:

    # Bob "I’m not angry at you. I’m just frustrated. I’ve already forgiven you, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:87
translate chinese MLR4_MS2_093b6026_1:

    # Linda "Wh-What?"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:88
translate chinese MLR4_MS2_9fac0a8e_1:

    # Bob "I can understand why you did what you did. I know you haven’t been happy. I’ve been acting like a flamingo - and pretending it would pass."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:90
translate chinese MLR4_MS2_321cf512_1:

    # Bob "But... at least fucking talk to me about it! You can’t just give me the cold shoulder when I’m trying to fix things, and then act as if you’re the only aggrieved party here!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:91
translate chinese MLR4_MS2_c43b46a9_1:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:93
translate chinese MLR4_MS2_04078f62_1:

    # Bob "Thirty years, Linda... Thirty years..."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:94
translate chinese MLR4_MS2_07cef4e8:

    # Bob "*Sigh* Thirty years! Can we at least be mature about this, for their sake?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:95
translate chinese MLR4_MS2_57b03333_1:

    # Linda "...I’m sorry."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:97
translate chinese MLR4_MS2_e9680c14_1:

    # Linda "But... can you at least try to see things from my point of view? I mean, how could I possibly tell you?!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:98
translate chinese MLR4_MS2_d2725365_1:

    # Linda "How would you have reacted if I told you the truth?!"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:100
translate chinese MLR4_MS2_0e3ba499_1:

    # Bob "Easy, easy... I’m sorry for shouting earlier. *Sigh*"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:101
translate chinese MLR4_MS2_7e9ee579_1:

    # Bob "How about we both try and keep our voices down? We’re both professional adults. Let’s handle this like the mature people we are."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:103
translate chinese MLR4_MS2_2bbcd453_1:

    # Linda "... *Sigh* Alright."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:109
translate chinese MLR4_MS2_ebf24bb6:

    # Bob "Let’s talk things over. I think I’m gonna need to sit down for this."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:110
translate chinese MLR4_MS2_fb30e272:

    # Linda "Y-Yeah, it’s probably best."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:112
translate chinese MLR4_MS2_0fe8afdc:

    # Bob "I... uh... I was right in what I saw, wasn’t I? You’re sleeping with [player_name]?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:113
translate chinese MLR4_MS2_86aa9175:

    # Linda "... *Gulp* I am."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:114
translate chinese MLR4_MS2_f935eda4:

    # Bob "Whew."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:116
translate chinese MLR4_MS2_609e71e2:

    # Bob "It’s... It’s a lot to take in."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:117
translate chinese MLR4_MS2_2caa7ff8:

    # Linda "I’m sorry."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:118
translate chinese MLR4_MS2_c2baf3a8:

    # Bob "How... uh... How long has this... affair been going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:119
translate chinese MLR4_MS2_4a10c072:

    # Linda "I... I don’t know."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:121
translate chinese MLR4_MS2_b5b58d93:

    # Bob "Work with me, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:122
translate chinese MLR4_MS2_37cee6a6:

    # Linda "*Sigh* Weeks, maybe a couple of months? I’ve lost track of time. It all blew up after [player_name] got rejected by his professor."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:124
translate chinese MLR4_MS2_90327c88:

    # Bob "He made moves on you when his professor rejected him?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:125
translate chinese MLR4_MS2_c9feebf9:

    # Linda "I..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:126
translate chinese MLR4_MS2_b16d8060:

    # Bob "Linda?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:127
translate chinese MLR4_MS2_1a7f0e7d:

    # Linda "I... was... the one who... initiated it."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:129
translate chinese MLR4_MS2_970ac8a1:

    # Bob "Oof. That’s rough."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:130
translate chinese MLR4_MS2_c77ac4ab:

    # Bob "Certainly explains why you haven’t been interested in our sex life lately."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:131
translate chinese MLR4_MS2_ce4b09de:

    # Linda "Please don’t take it out on, [player_name]. I was the one who-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:133
translate chinese MLR4_MS2_9bb85945:

    # Bob "I won’t. The lad’s done nothing wrong."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:134
translate chinese MLR4_MS2_0eb658a6:

    # Bob "What happens now? You clearly don’t want me around anymore."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:136
translate chinese MLR4_MS2_657db4dd:

    # Linda "I’m gonna need some space, Bob. Even just for a few days."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:137
translate chinese MLR4_MS2_b26158ca:

    # Bob "So you can fuck him in our bed?!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:138
translate chinese MLR4_MS2_ea50ad93:

    # Linda "B-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:139
translate chinese MLR4_MS2_2b1126f5:

    # Bob "Shit! I’m sorry, I’m sorry. That was an immature emotional reaction. I didn’t mean that."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:140
translate chinese MLR4_MS2_8fd80fb7:

    # Linda "*Sigh* I’m sorry. I really am."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:142
translate chinese MLR4_MS2_ab77e413:

    # Bob "*Sniff* Aright. I’ll pack my things. We can... uh... We can talk over this in a few days. It’ll give me a chance to clear my head."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:143
translate chinese MLR4_MS2_e0be50a1:

    # Linda "I’ll help you get your cases."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:144
translate chinese MLR4_MS2_85e3d8e7:

    # Bob "Thanks."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:147
translate chinese MLR4_MS2_a260795a:

    # MC "(Dad’s leaving?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:148
translate chinese MLR4_MS2_5b8e8553:

    # MC "(And Mom doesn’t seem to mind at all?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:150
translate chinese MLR4_MS2_b9a413a0:

    # Linda "I think it’s a good idea for you to get away. We can discuss the finances of our separation later."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:151
translate chinese MLR4_MS2_e4559965:

    # Bob "God damn it... Lawyers are so fucking expensive."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:152
translate chinese MLR4_MS2_41e2341b:

    # Linda "We’ll think it over. Perhaps we can reach some kind of amicable agreement that doesn’t involve lawyers when we’ve both had some time to cool off."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:154
translate chinese MLR4_MS2_560db8df:

    # Bob "Yeah... That sounds like it would work."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:155
translate chinese MLR4_MS2_de6c0191:

    # Bob "Just one last question, Linda. Is... Is it still going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:157
translate chinese MLR4_MS2_8643a03d:

    # Linda "I’m not going to stop fucking [player_name]. Sorry, Bob."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:158
translate chinese MLR4_MS2_ec01afc4:

    # Bob "*Sigh* God damn it..."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:159
translate chinese MLR4_MS2_cdaced16:

    # Bob "Right. I’m gonna go and pack my things."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:163
translate chinese MLR4_MS2_ebf24bb6_1:

    # Bob "Let’s talk things over. I think I’m gonna need to sit down for this."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:164
translate chinese MLR4_MS2_fb30e272_1:

    # Linda "Y-Yeah, it’s probably best."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:166
translate chinese MLR4_MS2_0fe8afdc_1:

    # Bob "I... uh... I was right in what I saw, wasn’t I? You’re sleeping with [player_name]?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:167
translate chinese MLR4_MS2_86aa9175_1:

    # Linda "... *Gulp* I am."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:168
translate chinese MLR4_MS2_f935eda4_1:

    # Bob "Whew."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:170
translate chinese MLR4_MS2_609e71e2_1:

    # Bob "It’s... It’s a lot to take in."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:171
translate chinese MLR4_MS2_2caa7ff8_1:

    # Linda "I’m sorry."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:172
translate chinese MLR4_MS2_c2baf3a8_1:

    # Bob "How... uh... How long has this... affair been going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:173
translate chinese MLR4_MS2_4a10c072_1:

    # Linda "I... I don’t know."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:175
translate chinese MLR4_MS2_b5b58d93_1:

    # Bob "Work with me, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:176
translate chinese MLR4_MS2_37cee6a6_1:

    # Linda "*Sigh* Weeks, maybe a couple of months? I’ve lost track of time. It all blew up after [player_name] got rejected by his professor."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:178
translate chinese MLR4_MS2_90327c88_1:

    # Bob "He made moves on you when his professor rejected him?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:179
translate chinese MLR4_MS2_c9feebf9_1:

    # Linda "I..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:180
translate chinese MLR4_MS2_b16d8060_1:

    # Bob "Linda?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:181
translate chinese MLR4_MS2_1a7f0e7d_1:

    # Linda "I... was... the one who... initiated it."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:183
translate chinese MLR4_MS2_970ac8a1_1:

    # Bob "Oof. That’s rough."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:184
translate chinese MLR4_MS2_c77ac4ab_1:

    # Bob "Certainly explains why you haven’t been interested in our sex life lately."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:185
translate chinese MLR4_MS2_ce4b09de_1:

    # Linda "Please don’t take it out on, [player_name]. I was the one who-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:187
translate chinese MLR4_MS2_9bb85945_1:

    # Bob "I won’t. The lad’s done nothing wrong."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:188
translate chinese MLR4_MS2_0eb658a6_1:

    # Bob "What happens now? You clearly don’t want me around anymore."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:190
translate chinese MLR4_MS2_657db4dd_1:

    # Linda "I’m gonna need some space, Bob. Even just for a few days."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:191
translate chinese MLR4_MS2_b26158ca_1:

    # Bob "So you can fuck him in our bed?!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:192
translate chinese MLR4_MS2_ea50ad93_1:

    # Linda "B-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:193
translate chinese MLR4_MS2_2b1126f5_1:

    # Bob "Shit! I’m sorry, I’m sorry. That was an immature emotional reaction. I didn’t mean that."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:194
translate chinese MLR4_MS2_8fd80fb7_1:

    # Linda "*Sigh* I’m sorry. I really am."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:196
translate chinese MLR4_MS2_ab77e413_1:

    # Bob "*Sniff* Aright. I’ll pack my things. We can... uh... We can talk over this in a few days. It’ll give me a chance to clear my head."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:197
translate chinese MLR4_MS2_e0be50a1_1:

    # Linda "I’ll help you get your cases."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:198
translate chinese MLR4_MS2_85e3d8e7_1:

    # Bob "Thanks."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:201
translate chinese MLR4_MS2_027f6b4b:

    # MC "(Bob’s leaving?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:202
translate chinese MLR4_MS2_0a0e2e2e:

    # MC "(And Linda doesn’t seem to mind at all?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:204
translate chinese MLR4_MS2_b9a413a0_1:

    # Linda "I think it’s a good idea for you to get away. We can discuss the finances of our separation later."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:205
translate chinese MLR4_MS2_e4559965_1:

    # Bob "God damn it... Lawyers are so fucking expensive."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:206
translate chinese MLR4_MS2_41e2341b_1:

    # Linda "We’ll think it over. Perhaps we can reach some kind of amicable agreement that doesn’t involve lawyers when we’ve both had some time to cool off."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:208
translate chinese MLR4_MS2_560db8df_1:

    # Bob "Yeah... That sounds like it would work."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:209
translate chinese MLR4_MS2_de6c0191_1:

    # Bob "Just one last question, Linda. Is... Is it still going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:211
translate chinese MLR4_MS2_8643a03d_1:

    # Linda "I’m not going to stop fucking [player_name]. Sorry, Bob."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:212
translate chinese MLR4_MS2_ec01afc4_1:

    # Bob "*Sigh* God damn it..."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:213
translate chinese MLR4_MS2_cdaced16_1:

    # Bob "Right. I’m gonna go and pack my things."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:220
translate chinese MLR4_MS2_ebf24bb6_2:

    # Bob "Let’s talk things over. I think I’m gonna need to sit down for this."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:221
translate chinese MLR4_MS2_fb30e272_2:

    # Linda "Y-Yeah, it’s probably best."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:223
translate chinese MLR4_MS2_821bebd2:

    # Bob "I... uh... I saw some clothes on the bedroom floor when I walked in."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:224
translate chinese MLR4_MS2_62ba0e75:

    # Linda "*Gulp*"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:225
translate chinese MLR4_MS2_0c371c4f:

    # Bob "They looked familiar. Very familiar. And, to be honest, I spent a few days ruminating about where I’d seen them before. And then it hit me."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:227
translate chinese MLR4_MS2_c43b46a9_2:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:228
translate chinese MLR4_MS2_195856b1:

    # Bob "It hit me like a ton of bricks, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:230
translate chinese MLR4_MS2_359dc0e0:

    # Bob "They were your clothing, weren't they?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:231
translate chinese MLR4_MS2_c43b46a9_3:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:233
translate chinese MLR4_MS2_a0f15faa:

    # Bob "It was you under the bed sheets the entire time. Wasn't it?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:234
translate chinese MLR4_MS2_c43b46a9_4:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:236
translate chinese MLR4_MS2_be4ea419:

    # Bob "Your silence is damning. I knew it."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:237
translate chinese MLR4_MS2_2caa7ff8_2:

    # Linda "I’m sorry."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:238
translate chinese MLR4_MS2_c2baf3a8_2:

    # Bob "How... uh... How long has this... affair been going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:239
translate chinese MLR4_MS2_4a10c072_2:

    # Linda "I... I don’t know."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:241
translate chinese MLR4_MS2_b5b58d93_2:

    # Bob "Work with me, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:242
translate chinese MLR4_MS2_37cee6a6_2:

    # Linda "*Sigh* Weeks, maybe a couple of months? I’ve lost track of time. It all blew up after [player_name] got rejected by his professor."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:244
translate chinese MLR4_MS2_90327c88_2:

    # Bob "He made moves on you when his professor rejected him?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:245
translate chinese MLR4_MS2_c9feebf9_2:

    # Linda "I..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:246
translate chinese MLR4_MS2_b16d8060_2:

    # Bob "Linda?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:247
translate chinese MLR4_MS2_1a7f0e7d_2:

    # Linda "I... was... the one who... initiated it."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:249
translate chinese MLR4_MS2_970ac8a1_2:

    # Bob "Oof. That’s rough."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:250
translate chinese MLR4_MS2_c77ac4ab_2:

    # Bob "Certainly explains why you haven’t been interested in our sex life lately."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:251
translate chinese MLR4_MS2_ce4b09de_2:

    # Linda "Please don’t take it out on, [player_name]. I was the one who-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:253
translate chinese MLR4_MS2_9bb85945_2:

    # Bob "I won’t. The lad’s done nothing wrong."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:254
translate chinese MLR4_MS2_0eb658a6_2:

    # Bob "What happens now? You clearly don’t want me around anymore."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:256
translate chinese MLR4_MS2_657db4dd_2:

    # Linda "I’m gonna need some space, Bob. Even just for a few days."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:257
translate chinese MLR4_MS2_b26158ca_2:

    # Bob "So you can fuck him in our bed?!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:258
translate chinese MLR4_MS2_ea50ad93_2:

    # Linda "B-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:259
translate chinese MLR4_MS2_2b1126f5_2:

    # Bob "Shit! I’m sorry, I’m sorry. That was an immature emotional reaction. I didn’t mean that."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:260
translate chinese MLR4_MS2_8fd80fb7_2:

    # Linda "*Sigh* I’m sorry. I really am."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:262
translate chinese MLR4_MS2_ab77e413_2:

    # Bob "*Sniff* Aright. I’ll pack my things. We can... uh... We can talk over this in a few days. It’ll give me a chance to clear my head."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:263
translate chinese MLR4_MS2_e0be50a1_2:

    # Linda "I’ll help you get your cases."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:264
translate chinese MLR4_MS2_85e3d8e7_2:

    # Bob "Thanks."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:267
translate chinese MLR4_MS2_a260795a_1:

    # MC "(Dad’s leaving?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:268
translate chinese MLR4_MS2_5b8e8553_1:

    # MC "(And Mom doesn’t seem to mind at all?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:270
translate chinese MLR4_MS2_b9a413a0_2:

    # Linda "I think it’s a good idea for you to get away. We can discuss the finances of our separation later."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:271
translate chinese MLR4_MS2_e4559965_2:

    # Bob "God damn it... Lawyers are so fucking expensive."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:272
translate chinese MLR4_MS2_41e2341b_2:

    # Linda "We’ll think it over. Perhaps we can reach some kind of amicable agreement that doesn’t involve lawyers when we’ve both had some time to cool off."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:274
translate chinese MLR4_MS2_560db8df_2:

    # Bob "Yeah... That sounds like it would work."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:275
translate chinese MLR4_MS2_de6c0191_2:

    # Bob "Just one last question, Linda. Is... Is it still going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:277
translate chinese MLR4_MS2_8643a03d_2:

    # Linda "I’m not going to stop fucking [player_name]. Sorry, Bob."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:278
translate chinese MLR4_MS2_ec01afc4_2:

    # Bob "*Sigh* God damn it..."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:279
translate chinese MLR4_MS2_cdaced16_2:

    # Bob "Right. I’m gonna go and pack my things."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:283
translate chinese MLR4_MS2_ebf24bb6_3:

    # Bob "Let’s talk things over. I think I’m gonna need to sit down for this."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:284
translate chinese MLR4_MS2_fb30e272_3:

    # Linda "Y-Yeah, it’s probably best."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:286
translate chinese MLR4_MS2_821bebd2_1:

    # Bob "I... uh... I saw some clothes on the bedroom floor when I walked in."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:287
translate chinese MLR4_MS2_62ba0e75_1:

    # Linda "*Gulp*"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:288
translate chinese MLR4_MS2_0c371c4f_1:

    # Bob "They looked familiar. Very familiar. And, to be honest, I spent a few days ruminating about where I’d seen them before. And then it hit me."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:290
translate chinese MLR4_MS2_c43b46a9_5:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:291
translate chinese MLR4_MS2_195856b1_1:

    # Bob "It hit me like a ton of bricks, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:293
translate chinese MLR4_MS2_359dc0e0_1:

    # Bob "They were your clothing, weren't they?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:294
translate chinese MLR4_MS2_c43b46a9_6:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:296
translate chinese MLR4_MS2_a0f15faa_1:

    # Bob "It was you under the bed sheets the entire time. Wasn't it?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:297
translate chinese MLR4_MS2_c43b46a9_7:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:299
translate chinese MLR4_MS2_be4ea419_1:

    # Bob "Your silence is damning. I knew it."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:300
translate chinese MLR4_MS2_2caa7ff8_3:

    # Linda "I’m sorry."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:301
translate chinese MLR4_MS2_c2baf3a8_3:

    # Bob "How... uh... How long has this... affair been going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:302
translate chinese MLR4_MS2_4a10c072_3:

    # Linda "I... I don’t know."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:304
translate chinese MLR4_MS2_b5b58d93_3:

    # Bob "Work with me, Linda."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:305
translate chinese MLR4_MS2_37cee6a6_3:

    # Linda "*Sigh* Weeks, maybe a couple of months? I’ve lost track of time. It all blew up after [player_name] got rejected by his professor."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:307
translate chinese MLR4_MS2_90327c88_3:

    # Bob "He made moves on you when his professor rejected him?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:308
translate chinese MLR4_MS2_c9feebf9_3:

    # Linda "I..."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:309
translate chinese MLR4_MS2_b16d8060_3:

    # Bob "Linda?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:310
translate chinese MLR4_MS2_1a7f0e7d_3:

    # Linda "I... was... the one who... initiated it."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:312
translate chinese MLR4_MS2_970ac8a1_3:

    # Bob "Oof. That’s rough."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:313
translate chinese MLR4_MS2_c77ac4ab_3:

    # Bob "Certainly explains why you haven’t been interested in our sex life lately."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:314
translate chinese MLR4_MS2_ce4b09de_3:

    # Linda "Please don’t take it out on, [player_name]. I was the one who-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:316
translate chinese MLR4_MS2_9bb85945_3:

    # Bob "I won’t. The lad’s done nothing wrong."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:317
translate chinese MLR4_MS2_0eb658a6_3:

    # Bob "What happens now? You clearly don’t want me around anymore."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:319
translate chinese MLR4_MS2_657db4dd_3:

    # Linda "I’m gonna need some space, Bob. Even just for a few days."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:320
translate chinese MLR4_MS2_b26158ca_3:

    # Bob "So you can fuck him in our bed?!"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:321
translate chinese MLR4_MS2_ea50ad93_3:

    # Linda "B-"
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:322
translate chinese MLR4_MS2_2b1126f5_3:

    # Bob "Shit! I’m sorry, I’m sorry. That was an immature emotional reaction. I didn’t mean that."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:323
translate chinese MLR4_MS2_8fd80fb7_3:

    # Linda "*Sigh* I’m sorry. I really am."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:325
translate chinese MLR4_MS2_ab77e413_3:

    # Bob "*Sniff* Aright. I’ll pack my things. We can... uh... We can talk over this in a few days. It’ll give me a chance to clear my head."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:326
translate chinese MLR4_MS2_e0be50a1_3:

    # Linda "I’ll help you get your cases."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:327
translate chinese MLR4_MS2_85e3d8e7_3:

    # Bob "Thanks."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:330
translate chinese MLR4_MS2_027f6b4b_1:

    # MC "(Bob’s leaving?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:331
translate chinese MLR4_MS2_0a0e2e2e_1:

    # MC "(And Linda doesn’t seem to mind at all?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:333
translate chinese MLR4_MS2_b9a413a0_3:

    # Linda "I think it’s a good idea for you to get away. We can discuss the finances of our separation later."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:334
translate chinese MLR4_MS2_03e005ea:

    # Bob "God damn... lawyers are so fucking expensive."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:335
translate chinese MLR4_MS2_41e2341b_3:

    # Linda "We’ll think it over. Perhaps we can reach some kind of amicable agreement that doesn’t involve lawyers when we’ve both had some time to cool off."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:337
translate chinese MLR4_MS2_560db8df_3:

    # Bob "Yeah... That sounds like it would work."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:338
translate chinese MLR4_MS2_de6c0191_3:

    # Bob "Just one last question, Linda. Is... Is it still going on?"
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:340
translate chinese MLR4_MS2_8643a03d_3:

    # Linda "I’m not going to stop fucking [player_name]. Sorry, Bob."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:341
translate chinese MLR4_MS2_ec01afc4_3:

    # Bob "*Sigh* God damn it..."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:342
translate chinese MLR4_MS2_cdaced16_3:

    # Bob "Right. I’m gonna go and pack my things."
    Bob ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:348
translate chinese MLR4_MS2_menu_3e8abd2d:

    # MC "(She winked at me! It seems like Linda finally got what she always wanted. [Dad_name] is actually leaving...)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:352
translate chinese MLR4_MS2_menu_a984e7de:

    # MC "(This is great! We can actually be together without getting interrupted!)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:357
translate chinese MLR4_MS2_menu_0675c543:

    # MC "(What’s going to happen to [Dad_name]? Where’s he going to live? What about Sara and Caroline? How are they going to react to him leaving?)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:365
translate chinese MLR4_MS2_con_c6aa6443:

    # MC "(She’s motioning for me to leave...)"
    MC ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:366
translate chinese MLR4_MS2_con_e5981b00:

    # Linda "I’ll go and tell [player_name] to chat with you before you go."
    Linda ""

# game/scripts/ML_R4/2_MLR4_MS2.rpy:368
translate chinese MLR4_MS2_con_e8b17562:

    # Bob "*Sigh* Yeah, I’d like to see him. I’ll be in the garage packing the car."
    Bob ""

translate chinese strings:

    # game/scripts/ML_R4/2_MLR4_MS2.rpy:349
    old "This is great! We can finally be together!"
    new ""

    # game/scripts/ML_R4/2_MLR4_MS2.rpy:349
    old "[Dad_name]’s actually leaving..."
    new ""

