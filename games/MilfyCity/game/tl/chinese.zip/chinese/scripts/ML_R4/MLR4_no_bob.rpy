﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/MLR4_no_bob.rpy:30
translate chinese MLR4_no_bob_ca242c68:

    # MC "(I should leave Linda alone.)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:42
translate chinese MLR4_no_bob_36a1e196:

    # "*Creak* *Creak*"
    ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:46
translate chinese MLR4_no_bob_09d06ab8:

    # "*Click*"
    ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:50
translate chinese MLR4_no_bob_48c1e588:

    # "*Creak*"
    ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:53
translate chinese MLR4_no_bob_df5278d0:

    # MC "Hey Linda, I-"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:55
translate chinese MLR4_no_bob_d85108df:

    # MC "(Oh no… That doesn’t look good.)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:59
translate chinese MLR4_no_bob_d0426ae4:

    # Linda "*Snore*"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:61
translate chinese MLR4_no_bob_abe8181c:

    # MC "(Jesus… How much has she been drinking?!)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:65
translate chinese MLR4_no_bob_7c3e6c89:

    # MC "(Fuck me… Did she burn through two whole bottles in one night?!)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:67
translate chinese MLR4_no_bob_1bfb22a6:

    # MC "(Is this because of Bob leaving?)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:71
translate chinese MLR4_no_bob_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:73
translate chinese MLR4_no_bob_bbdd1b5b:

    # MC "(I’ll have to wake her up and talk to her. God knows what’s going on right now.)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:77
translate chinese MLR4_no_bob_834c8bbd:

    # MC "Hey Linda… Psst. Linda?"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:79
translate chinese MLR4_no_bob_d0426ae4_1:

    # Linda "*Snore*"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:83
translate chinese MLR4_no_bob_79e0d1b9:

    # Linda "Zzz…"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:85
translate chinese MLR4_no_bob_2722d009:

    # MC "(She’s completely out of it.)"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:89
translate chinese MLR4_no_bob_99a340e0:

    # MC "Psst. Linda? Are you awake?"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:91
translate chinese MLR4_no_bob_86906124:

    # Linda "Mmm… Hmm?"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:95
translate chinese MLR4_no_bob_2377128a:

    # Linda "*Hic* Bob? Is that you?"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:97
translate chinese MLR4_no_bob_8fd95885:

    # MC "…"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:99
translate chinese MLR4_no_bob_11cd1096:

    # Linda "Oh! Heeeey [player_name], I didn’t sheee you come in. *Hic* What timesh it now?"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:103
translate chinese MLR4_no_bob_d3830884:

    # MC "It’s late. I just wanted to come in and see how-"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:105
translate chinese MLR4_no_bob_e7f44e03:

    # Linda "You missh him too, don’t you?"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:107
translate chinese MLR4_no_bob_8576e0b1:

    # MC "Him?"
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:109
translate chinese MLR4_no_bob_e4b18b46:

    # Linda "Bob."
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:113
translate chinese MLR4_no_bob_e3335bb9:

    # Linda "The big… lumbering… oaf was alwaysh there and now he’s gone. It’sh… shoooo quiet. The *Hic* house kinda feelsh empty… like when you lose a pet dog."
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:115
translate chinese MLR4_no_bob_ba37dc91:

    # MC "You’re drunk, Linda."
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:117
translate chinese MLR4_no_bob_c6547ed0:

    # Linda "I’m… I’m just sad… I think."
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:119
translate chinese MLR4_no_bob_feecb912:

    # MC "You need to stop drinking. You’ve had far too much already."
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:121
translate chinese MLR4_no_bob_cc3b1b7b:

    # Linda "…"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:123
translate chinese MLR4_no_bob_b9555c95:

    # MC "Promise me you’ll not do this again? If you’re feeling sad or missing Bob you can always come and talk to me about it."
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:127
translate chinese MLR4_no_bob_cc3b1b7b_1:

    # Linda "…"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:129
translate chinese MLR4_no_bob_5d4debb8:

    # Linda "Okay. I promise, [player_name]. No more *Hic* drinking."
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:131
translate chinese MLR4_no_bob_4002815c:

    # MC "*Sigh* Thanks. I’ll give you some privacy, try and get some sleep."
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:136
translate chinese MLR4_no_bob_c99eaeb5:

    # Linda "Night [player_name]."
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:138
translate chinese MLR4_no_bob_d5a54691:

    # MC "Goodnight Linda."
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:142
translate chinese MLR4_no_bob_f86c2ddf:

    # Linda "I meant what I *Hic* said! I’m not gonna touch another drop of the stuff!"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:144
translate chinese MLR4_no_bob_5b73cde9:

    # MC "Get some sleep, Linda. You’re going to have one hell of a hangover in the morning."
    MC ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:148
translate chinese MLR4_no_bob_09d06ab8_1:

    # "*Click*"
    ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:150
translate chinese MLR4_no_bob_cc3b1b7b_2:

    # Linda "…"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:154
translate chinese MLR4_no_bob_e3edd747:

    # Linda "*Sigh* No more drinking…"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:156
translate chinese MLR4_no_bob_cc3b1b7b_3:

    # Linda "…"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:160
translate chinese MLR4_no_bob_d45c167b:

    # Linda "(I mean, I did promise him I’d stop, but…)"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:162
translate chinese MLR4_no_bob_43d38f2f:

    # Linda "(...it’d be a real shame to waste a good wine.)"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:166
translate chinese MLR4_no_bob_952dc8ef:

    # Linda "(Ah, what the hell. [player_name]’s not gonna know.)"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:168
translate chinese MLR4_no_bob_e5f16b35:

    # Linda "(Fucking Bob… Can’t live with him. Can’t live without him.)"
    Linda ""

# game/scripts/ML_R4/MLR4_no_bob.rpy:170
translate chinese MLR4_no_bob_d57cc9e4:

    # Linda "*Sigh*"
    Linda ""

