﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/5_MLR4_MS5.rpy:165
translate chinese MLR4_S5_0756420e:

    # MC "(Oh wow! She looks so hot, right now!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:167
translate chinese MLR4_S5_4d0a274c:

    # MC "(That’s the skimpiest outfit I’ve ever seen her wear - outside the bedroom!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:171
translate chinese MLR4_S5_48c1e588:

    # "*Creak*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:172
translate chinese MLR4_S5_c89f6c0e:

    # Linda "(I was wondering how long it would take him to finally show up. I’ve been standing here for almost an hour!)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:174
translate chinese MLR4_S5_5dff9474:

    # MC "(She’s lucky Sara or Caroline didn’t come into the kitchen to get some food. An outfit THAT revealing would certainly require A LOT of explaining!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:176
translate chinese MLR4_S5_202e2d45:

    # MC "(Her butt looks VERY squeezable right now. I don’t think she’d mind me feeling it up.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:177
translate chinese MLR4_S5_94af9672:

    # MC "(She DID leave it on display, after all!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:179
translate chinese MLR4_S5_325d7f1a:

    # MC "(Then again, I could just reach around and play with her tits instead.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:181
translate chinese MLR4_S5_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:182
translate chinese MLR4_S5_375132dd:

    # MC "(Which one should I go for? Her ass or her tits?)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:191
translate chinese MLR4_S5_b9b76f81:

    # MC "(Her ass is just begging to be groped right now! Hehe!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:192
translate chinese MLR4_S5_3405fce5:

    # MC "(There’s no way she just left it hanging out like that if she wasn’t wanting me to give it a squeeze, right?)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:194
translate chinese MLR4_S5_b6dea001:

    # MC "(God, she’s so fucking hot.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:195
translate chinese MLR4_S5_ba96113a:

    # Linda "Is everything alright, [player_name]? You’ve gone a bit quiet, there."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:197
translate chinese MLR4_S5_24b05095:

    # MC "Uh huh! All good."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:198
translate chinese MLR4_S5_81e28f81:

    # MC "(Here goes nothing!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:201
translate chinese MLR4_S5_20c73366:

    # "*Slap*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:202
translate chinese MLR4_S5_c8a6929a:

    # Linda "Ohh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:204
translate chinese MLR4_S5_65281a22:

    # Linda "(I can’t believe I had to strip down, almost naked, before he finally got the message!)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:205
translate chinese MLR4_S5_c94f4d67:

    # Linda "Mmm... Enjoying yourself?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:206
translate chinese MLR4_S5_f6f9f238:

    # MC "Sorry, I couldn’t resist spanking your ass when you had it on display like that."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:207
translate chinese MLR4_S5_6189cd36:

    # Linda "How about you do it again?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:208
translate chinese MLR4_S5_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:210
translate chinese MLR4_S5_5fb92fd9:

    # Linda "Yes, spank me. Slap my fat ass as much as you want."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:211
translate chinese MLR4_S5_a76527c5:

    # MC "(Alright! If she’s inviting me to do it, then I may as well!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:214
translate chinese MLR4_S5_20c73366_1:

    # "*Slap*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:215
translate chinese MLR4_S5_08154bc4:

    # Linda "Ow! Mmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:217
translate chinese MLR4_S5_e75402d0:

    # Linda "Is that *pant* the best you can do?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:220
translate chinese MLR4_S5_20c73366_2:

    # "*Slap*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:221
translate chinese MLR4_S5_4d39adfb:

    # Linda "Ah! Ooohh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:223
translate chinese MLR4_S5_59f87d68:

    # MC "You’re a real tease flashing your ass like that."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:224
translate chinese MLR4_S5_e307375c:

    # Linda "Hehe! I’m glad you liked my outfit."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:226
translate chinese MLR4_S5_8cd125ce:

    # Linda "You’ve got a firm hand! I wasn’t expecting you to spank so hard!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:228
translate chinese MLR4_S5_a4b0acf2:

    # MC "Sorry, my bad. I didn’t hurt you, did it?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:230
translate chinese MLR4_S5_aef22e96:

    # Linda "No, it just came as a surprise."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:232
translate chinese MLR4_S5_56fdf60e:

    # Linda "I can see you staring."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:236
translate chinese MLR4_S5_64885e00:

    # MC "Staring? I wasn’t-"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:238
translate chinese MLR4_S5_7ea98612:

    # Linda "This apron is getting in the way, isn’t it? Would you prefer it if I took my breasts out?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:242
translate chinese MLR4_S5_d443a92d:

    # Linda "How’s that? Better?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:244
translate chinese MLR4_S5_1e0d6c7a:

    # MC "Oh my God... You look amazing, [Mom_name]."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:246
translate chinese MLR4_S5_0a6963c5:

    # Linda "Hehe, I knew you’d like to see me dressed in this."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:257
translate chinese MLR4_S5_3906791b:

    # MC "Hey there, [Mom_name]. I don’t remember you usually looking this hot when you’re in the kitchen."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:259
translate chinese MLR4_S5_da54aa0b:

    # Linda "I thought you’d like my new apron. I’d wear it more often, but I’m not sure Sara or Caroline would appreciate seeing my ass when I’m cooking dinner."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:260
translate chinese MLR4_S5_2939925c:

    # MC "Heh, they just can’t appreciate your body the way I do."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:262
translate chinese MLR4_S5_9664602b:

    # MC "Like your tits, for example."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:263
translate chinese MLR4_S5_525d4d47:

    # Linda "Oh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:264
translate chinese MLR4_S5_86d2605b:

    # MC "The back of your apron already looks perfect. It’s just the front that needs some adjustments. Why are you hiding your incredible tits?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:266
translate chinese MLR4_S5_b2cc81f4:

    # Linda "Mmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:267
translate chinese MLR4_S5_f5791b06:

    # MC "See? Isn’t it much more fun when your breasts are out where I can grope them?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:268
translate chinese MLR4_S5_360bef54:

    # Linda "Ahh... *Pant*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:270
translate chinese MLR4_S5_44f55094:

    # Linda "Mmm! Ooohh..."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:271
translate chinese MLR4_S5_2ad07a88:

    # MC "You enjoy it when I squeeze them like this, don’t you?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:272
translate chinese MLR4_S5_0ced8dfa:

    # Linda "*Pant*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:274
translate chinese MLR4_S5_772479f5:

    # MC "Tell me what you want me to do to your tits."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:275
translate chinese MLR4_S5_b699b89e:

    # Linda "I... Mmm... I want you to grope them. Squeeze my titties. Ah!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:277
translate chinese MLR4_S5_c120d52a:

    # MC "(They feel amazing to hold!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:278
translate chinese MLR4_S5_b38fa437:

    # Linda "Mmmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:280
translate chinese MLR4_S5_526eb3b5:

    # Linda "*Pant* Mmm! I knew wearing this slutty little apron would tempt you."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:281
translate chinese MLR4_S5_48e8eadf:

    # MC "Indeed. You’re really naughty - turning me on like that."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:282
translate chinese MLR4_S5_298016ee:

    # Linda "Oh? I’ve been naughty? Perhaps you should spank me..."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:284
translate chinese MLR4_S5_29efee44:

    # MC "Perhaps I should."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:286
translate chinese MLR4_S5_5ade8dcc:

    # Linda "(I wonder when he’s going to do it! I’m soaking with anticipation.)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:289
translate chinese MLR4_S5_20c73366_3:

    # "*Slap*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:290
translate chinese MLR4_S5_08da279b:

    # Linda "Ow! Oohhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:292
translate chinese MLR4_S5_e7fe8efd:

    # MC "Do you feel like I’ve suitably punished you?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:293
translate chinese MLR4_S5_f7f841b1:

    # Linda "Mmm! More!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:295
translate chinese MLR4_S5_5d63cde5:

    # MC "If you insist."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:298
translate chinese MLR4_S5_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:299
translate chinese MLR4_S5_38496b9d:

    # Linda "Ah! Oohhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:302
translate chinese MLR4_S5_4875f5be_1:

    # "*SLAP*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:303
translate chinese MLR4_S5_ecd3ce31:

    # Linda "*Pant* Ah!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:306
translate chinese MLR4_S5_4875f5be_2:

    # "*SLAP*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:307
translate chinese MLR4_S5_d008a440:

    # Linda "AH! *Pant* Oooh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:314
translate chinese MLR4_S5_con_dc292f4e:

    # Linda "Oh, I almost forgot. I made us cocktails!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:316
translate chinese MLR4_S5_con_713f1766:

    # MC "Thanks, [Mom_name]! What’s in them?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:320
translate chinese MLR4_S5_con_05894147:

    # Linda "Gin, sweet vermouth, and some fernet."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:321
translate chinese MLR4_S5_con_61c45a67:

    # Linda "I figured we deserved something to lighten the mood. Especially after those rather heavy therapy sessions with Judy."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:325
translate chinese MLR4_S5_con_7a08abff:

    # MC "They look delicious!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:327
translate chinese MLR4_S5_con_2336c9e8:

    # Linda "Thanks! Nothing fancy, just something I whipped up while waiting for you."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:331
translate chinese MLR4_S5_con_47f9ff56:

    # Linda "Cheers!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:333
translate chinese MLR4_S5_con_c6e514d0:

    # MC "Cheers."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:337
translate chinese MLR4_S5_con_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:341
translate chinese MLR4_S5_con_40553807:

    # Linda "So, is this your first time drinking cocktails with a topless woman?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:343
translate chinese MLR4_S5_con_5ae0bd71:

    # MC "Haha! It is!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:347
translate chinese MLR4_S5_con_662357ff:

    # Linda "Seems a little unfair that I’m the only one with my clothes off."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:349
translate chinese MLR4_S5_con_afc60d5f:

    # MC "Do you want me to take mine off now?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:353
translate chinese MLR4_S5_con_115deb61:

    # Linda "Heh, you’ll only distract me. Finish off your drink first, Sweetie."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:357
translate chinese MLR4_S5_con_e28bda70:

    # "*Sip*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:359
translate chinese MLR4_S5_con_1770bc28:

    # "*Shlurp*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:363
translate chinese MLR4_S5_con_2475a067:

    # MC "(She looks incredible, right now. I wish we were the same age though. I’d have loved to have known her when she was in her twenties.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:365
translate chinese MLR4_S5_con_07b61bd5:

    # MC "(Would she still be attracted to me if I wasn’t her son?)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:367
translate chinese MLR4_S5_con_c665bf42:

    # MC "(Would she still be attracted to me if I was her age?)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:371
translate chinese MLR4_S5_con_3281c163:

    # Linda "(Ah, fuck it. I don’t even like gin that much.)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:373
translate chinese MLR4_S5_con_77a55479:

    # MC "Huh? What are you-"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:375
translate chinese MLR4_S5_con_dbf7318e:

    # Linda "I can’t take it any longer! Get out of those clothes and sit down! I need to suck your cock!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:379
translate chinese MLR4_S5_con_5c40e5b7:

    # MC "Heh, I guess you’re more in the mood for a cock, rather than a cocktail tonight, eh?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:381
translate chinese MLR4_S5_con_242d5cd6:

    # Linda "(With that sense of humour that bad, it’s no wonder his professor rejected him!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:383
translate chinese MLR4_S5_con_de289357:

    # Linda "Maybe leave the jokes to the professional comedians."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:387
translate chinese MLR4_S5_con_e2c63bb5:

    # MC "Hey, it wasn’t that bad!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:389
translate chinese MLR4_S5_con_9882bae4:

    # Linda "Shush. Just sit back, stay quiet, and let me savour your delicious dick."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:391
translate chinese MLR4_S5_con_18dd9d85:

    # Linda "(God, I’ve been looking forward to wrapping my lips around this, all day!)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:395
translate chinese MLR4_S5_con_95bf31d9:

    # MC "Haha, alright. No more jokes, I promise!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:397
translate chinese MLR4_S5_con_b1152daf:

    # MC "(I hope Caroline and Sara aren’t home... It could get REALLY awkward if either of them walked in on us right now. I’m not quite sure how I’d talk my way out of that one!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:402
translate chinese MLR4_S5_con_45373afd:

    # Linda "(I can’t wait to feel his thick shaft, filling my mouth. Mmm! Why does my own son turn me on in a way Bob never could? It’s so wrong...)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:404
translate chinese MLR4_S5_con_a9ef6f68:

    # Linda "(I can’t wait to feel his thick shaft, filling my mouth. Mmm! Why does this guy turn me on in a way Bob never could? It’s so wrong...)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:406
translate chinese MLR4_S5_con_31b3e80c:

    # Linda "(Perhaps that’s why I find it so hot?)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:408
translate chinese MLR4_S5_con_0953c366:

    # Linda "Do me a favour and push your cock down for me, Sweetie."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:412
translate chinese MLR4_S5_con_365afdc9:

    # MC "Like this?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:414
translate chinese MLR4_S5_con_bc723ae1:

    # Linda "Mmm hmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:416
translate chinese MLR4_S5_con_39c34cc5:

    # Linda "*Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:420
translate chinese MLR4_S5_con_dea714cb:

    # MC "Oohh..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:422
translate chinese MLR4_S5_con_e5036f04:

    # MC "That feels amazing, [Mom_name]. Mmm..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:426
translate chinese MLR4_S5_con_39aa5087:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:428
translate chinese MLR4_S5_con_00d9141d:

    # MC "*Pant* Mmm..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:432
translate chinese MLR4_S5_con_0b3822d9:

    # MC "I’ll give you a warning if I hear any footsteps. I don’t know if Caroline and Sara are home, but I’ll keep an ear open."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:434
translate chinese MLR4_S5_con_bc723ae1_1:

    # Linda "Mmm hmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:438
translate chinese MLR4_S5_con_5643e142:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:440
translate chinese MLR4_S5_con_84e97ede:

    # MC "Mmm... Fuck, your mouth feels good."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:444
translate chinese MLR4_S5_con_39aa5087_1:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:446
translate chinese MLR4_S5_con_c1ee9dc3:

    # MC "*Pant* Mmmm! Ohhh..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:450
translate chinese MLR4_S5_con_da35f2a5:

    # Linda "*Shluuurrrp* *Suuuuck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:452
translate chinese MLR4_S5_con_c445f4b7:

    # MC "*Pant* Fuuuuck.... Hnnng.... "
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:456
translate chinese MLR4_S5_con_467f8d5d:

    # MC "Mmm, you give the best blowjobs, [Mom_name]."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:458
translate chinese MLR4_S5_con_39aa5087_2:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:460
translate chinese MLR4_S5_con_45e22a4d:

    # MC "I still think back to our date in that restaurant. *Pant* Remember when you teased me during the meal when the waiter was hnnng... standing right there?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:464
translate chinese MLR4_S5_con_5cfbb67a:

    # Linda "*Suuuuuuuccck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:466
translate chinese MLR4_S5_con_92534ff8:

    # MC "Ahnnnnnggg! Mmmmm!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:470
translate chinese MLR4_S5_con_45faa221:

    # MC "Oohhh... Mmm! You’re gonna drain me dry if you keep sucking like that."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:472
translate chinese MLR4_S5_con_aec84d2f:

    # Linda "*Suuuuuuccck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:476
translate chinese MLR4_S5_con_4991e25e:

    # MC "Hnnng... I want you to take it deeper, [Mom_name]. Can you deepthroat my cock now?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:479
translate chinese MLR4_S5_con_5b130191:

    # Linda "*Shlurp* *Suck* Mmm hmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:481
translate chinese MLR4_S5_con_0b8ae440:

    # Linda "*Glompff!*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:483
translate chinese MLR4_S5_con_0b8ae440_1:

    # Linda "*Glompff!*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:484
translate chinese MLR4_S5_con_6516fbe1:

    # MC "Oohhhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:485
translate chinese MLR4_S5_con_ba04004a:

    # Linda "*Gag* *Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:487
translate chinese MLR4_S5_con_ef344ad6:

    # MC "Mmm! Just like that, [Mom_name]! Ohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:491
translate chinese MLR4_S5_con_f7a6cc31:

    # MC "*Pant* Holy shit, your throat feels so good!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:493
translate chinese MLR4_S5_con_95ea9e1f:

    # Linda "*Suuuuuck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:495
translate chinese MLR4_S5_con_87693ef2:

    # MC "Ahh... Hnnngg!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:499
translate chinese MLR4_S5_con_39aa5087_3:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:501
translate chinese MLR4_S5_con_e01a51b4:

    # MC "*Pant* Ohh! Ah!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:503
translate chinese MLR4_S5_con_b02c9097:

    # Linda "*Shlurp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:507
translate chinese MLR4_S5_con_39aa5087_4:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:509
translate chinese MLR4_S5_con_32693876:

    # MC "Oohh... Mmmm!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:513
translate chinese MLR4_S5_con_b95d8baf:

    # MC "Hnnngg! Fuck! Hnnnngg! *Pant* Hold up! I’m gonna cum if you keep going like that!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:515
translate chinese MLR4_S5_con_b5fb5556:

    # Linda "*Shlurp* *Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:519
translate chinese MLR4_S5_con_c32c87f8:

    # MC "Hnnngg! [Mom_name]! Ahh! Ohhh fuck!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:521
translate chinese MLR4_S5_con_666f84a2:

    # Linda "*SHLURP*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:523
translate chinese MLR4_S5_con_efbb0459:

    # Linda "(His cock is beginning to pulsate in my mouth!)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:527
translate chinese MLR4_S5_con_b9545300:

    # Linda "*Gag* *Shlurp* *GLOMPF*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:529
translate chinese MLR4_S5_con_5b34b99f:

    # MC "OOHHH!! *Pant* [Mom_name]! Wait!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:533
translate chinese MLR4_S5_con_56b7b844:

    # MC "How about we change *Pant* things up, before I cum?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:535
translate chinese MLR4_S5_con_2e2ba04c:

    # Linda "*Gasp* Where do you want me?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:539
translate chinese MLR4_S5_con_dc4bee39:

    # MC "Lean back against the cupboard over there. I’ll stand up and facefuck you for a while."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:541
translate chinese MLR4_S5_con_a574bfb7:

    # Linda "Mmm, sounds fun."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:545
translate chinese MLR4_S5_con_f173375b:

    # Linda "Well? What are you waiting for? You’re the one who asked for this."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:547
translate chinese MLR4_S5_con_c9afbd42:

    # Linda "Come on over and ram your fat dick down your mother’s throat."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:549
translate chinese MLR4_S5_con_37494b48:

    # Linda "Come on over and ram your fat dick down my throat."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:551
translate chinese MLR4_S5_con_d16ef530:

    # Linda "I want to feel your cock plunging deep into my-"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:555
translate chinese MLR4_S5_con_98972e6b:

    # Linda "*Glompf*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:557
translate chinese MLR4_S5_con_660e4bb0:

    # MC "Hnngg! Ohh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:561
translate chinese MLR4_S5_con_c205f36e:

    # Linda "(Huh! He took me by surprise, there. Wasn’t expecting him to just rush forward and thrust it in like that.)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:563
translate chinese MLR4_S5_con_95f4c286:

    # Linda "(It’s nice to have him take charge, for a change.)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:567
translate chinese MLR4_S5_con_5643e142_1:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:569
translate chinese MLR4_S5_con_ee835c0a:

    # MC "Ohh, fuck! Mmm! Ugh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:573
translate chinese MLR4_S5_con_b0ea8bc6:

    # MC "Hnnngg! Ohh! That’s it, [Mom_name], suck my dick! *Pant* Ohh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:575
translate chinese MLR4_S5_con_c5f3a95e:

    # MC "Ugh! Arrghh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:577
translate chinese MLR4_S5_con_b5fb5556_1:

    # Linda "*Shlurp* *Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:581
translate chinese MLR4_S5_con_df478e6a:

    # MC "*Pant* Ohhh fuck! Mmm!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:583
translate chinese MLR4_S5_con_a2f261ff:

    # Linda "*Suck* *Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:587
translate chinese MLR4_S5_con_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:589
translate chinese MLR4_S5_con_3ad3b491:

    # MC "(It feels so good, thrusting into her warm, wet, mouth like this!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:593
translate chinese MLR4_S5_con_32fd9635:

    # MC "Hnnng! Oh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:595
translate chinese MLR4_S5_con_5643e142_2:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:597
translate chinese MLR4_S5_con_04ecfff9:

    # MC "I bet you’re loving this, aren’t you Mom? Having your son slam his dick down your throat, again and again. I bet this turns you on so much."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:599
translate chinese MLR4_S5_con_195c66ea:

    # MC "I bet you’re loving this, aren’t you Linda? Having me slam my dick down your throat, again and again. I bet this turns you on so much."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:603
translate chinese MLR4_S5_con_ff3c75f6:

    # Linda "*Gag* *Shluuurrrrp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:605
translate chinese MLR4_S5_con_84e63819:

    # MC "Hnnngggg! Ooohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:607
translate chinese MLR4_S5_con_98972e6b_1:

    # Linda "*Glompf*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:609
translate chinese MLR4_S5_con_dcda0773:

    # MC "I think I’m gonna hold it in for a while."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:613
translate chinese MLR4_S5_con_126a83de:

    # Linda "Mmmpfff... Mmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:615
translate chinese MLR4_S5_con_cf8bfc8e:

    # MC "Mmm... Are you enjoying the taste of my precum?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:617
translate chinese MLR4_S5_con_ea424dc1:

    # Linda "*Gag*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:621
translate chinese MLR4_S5_con_be20353c:

    # MC "I bet you are. You’ve been longing to suck my cock for YEARS, haven’t you [Mom_name]?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:623
translate chinese MLR4_S5_con_33dbface:

    # MC "I bet you are! You've been longing to suck my cock for a LONG time, haven’t you Linda?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:625
translate chinese MLR4_S5_con_675958fd:

    # Linda "*Shlurp* *Gag*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:629
translate chinese MLR4_S5_con_22a55bff:

    # Linda "Mppff!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:633
translate chinese MLR4_S5_con_6a2f7064:

    # Linda "*Shluurrrp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:635
translate chinese MLR4_S5_con_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:639
translate chinese MLR4_S5_con_a69fd60f:

    # MC "Hnnngg! *Pant* Mmm!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:641
translate chinese MLR4_S5_con_c79b0980:

    # Linda "*Suck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:643
translate chinese MLR4_S5_con_6516fbe1_1:

    # MC "Oohhhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:647
translate chinese MLR4_S5_con_68b13245:

    # Linda "(It feels so liberating to be able to have [player_name] fuck me like this without worrying about my husband catching us.)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:648
translate chinese MLR4_S5_con_7389dd95:

    # Linda "*Shlick* *Shlurrp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:652
translate chinese MLR4_S5_con_d4c6512d:

    # MC "Ohhh! [Mom_name]! Mmm! Ahh! Fuck! *Pant* Ohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:654
translate chinese MLR4_S5_con_c79b0980_1:

    # Linda "*Suck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:656
translate chinese MLR4_S5_con_c732e7fb:

    # Caroline "Crap! Where did I leave my phone?"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:660
translate chinese MLR4_S5_con_d83878b8:

    # MC "*Whispered* Oh shit..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:662
translate chinese MLR4_S5_con_cf2bdefe:

    # MC "(It’s one of my sisters... I can’t tell which.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:664
translate chinese MLR4_S5_con_7de3afd0:

    # MC "(It’s either Caroline or Sara... I can’t tell which.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:667
translate chinese MLR4_S5_con_297960a3:

    # Caroline "I could have sworn it was sitting on the couch..."
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:669
translate chinese MLR4_S5_con_0cf2e6fb:

    # Linda "*Whispered* Shush... Don’t panic."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:671
translate chinese MLR4_S5_con_7010791a:

    # MC "*Whispered* What do you mean “don’t panic”? We’re THIS close to getting caught!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:675
translate chinese MLR4_S5_con_ee4ad5a2:

    # Caroline "Did I leave it on charge somewhere?"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:677
translate chinese MLR4_S5_con_1992a5b4:

    # Linda "*Whispered* She isn’t going to come into the kitchen. The girls never charge their phones in here."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:679
translate chinese MLR4_S5_con_b2a47a13:

    # MC "*Whispered* You better be right or we’re going to have A LOT of explaining to do!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:683
translate chinese MLR4_S5_con_49f9fe59:

    # Linda "*Whispered* Relax. Keep fucking my face - just try and keep your moans down."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:685
translate chinese MLR4_S5_con_11c22474:

    # MC "*Gulp* Alright..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:689
translate chinese MLR4_S5_con_514afaff:

    # "*Shlick* *Shlick*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:691
translate chinese MLR4_S5_con_b3ebe37d:

    # Linda "*Shlurrrp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:692
translate chinese MLR4_S5_con_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:696
translate chinese MLR4_S5_con_c79b0980_2:

    # Linda "*Suck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:698
translate chinese MLR4_S5_con_a3c761df:

    # Caroline "[Mom_name]! Are you home?"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:700
translate chinese MLR4_S5_con_9672ef9f:

    # MC "Oh... ah..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:704
translate chinese MLR4_S5_con_74502780:

    # Caroline "[player_name]! Are you here? Have you seen my phone?"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:706
translate chinese MLR4_S5_con_1ced0d90:

    # Linda "*Shlick* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:708
translate chinese MLR4_S5_con_41b3f73a:

    # Caroline "Guys! Can anyone hear me? Hello?"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:712
translate chinese MLR4_S5_con_9e98843e:

    # MC "(Shit, I think it might be Caroline.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:714
translate chinese MLR4_S5_con_22751478:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:716
translate chinese MLR4_S5_con_30034a6e:

    # MC "Oh..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:720
translate chinese MLR4_S5_con_05195012:

    # Caroline "Nobody? *Sigh* Where the heck did I put it?"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:722
translate chinese MLR4_S5_con_b3ebe37d_1:

    # Linda "*Shlurrrp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:724
translate chinese MLR4_S5_con_7764f771:

    # MC "Hnnng... *Whispered* Fuck... I love it when you suck like that."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:728
translate chinese MLR4_S5_con_39aa5087_5:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:730
translate chinese MLR4_S5_con_bc568e8a:

    # MC "*Pant* Hnnng..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:732
translate chinese MLR4_S5_con_d6a09071:

    # Caroline "Oh! Nevermind! Found it! I’m off to the mall. Catch you guys later!"
    Caroline ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:738
translate chinese MLR4_S5_con_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:740
translate chinese MLR4_S5_con_c3d1cba1:

    # MC "(That was the front door! We’re alone again!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:742
translate chinese MLR4_S5_con_783b1308:

    # MC "HNNNGG! Arrghhh! Oohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:746
translate chinese MLR4_S5_con_5643e142_3:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:748
translate chinese MLR4_S5_con_0c606e62:

    # MC "*Pant* Yes! Mmm! Just like that, [Mom_name]! Keep sucking my dick!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:752
translate chinese MLR4_S5_con_05e23b28:

    # MC "Ooohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:754
translate chinese MLR4_S5_con_80d606c1:

    # Linda "*Gag* *Shluuurrrp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:758
translate chinese MLR4_S5_con_3da99ac6:

    # Linda "*Cough* *Gasp*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:760
translate chinese MLR4_S5_con_92d455db:

    # Linda "Alright, you’ve had your fun. How about you fuck me on the kitchen table?"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:762
translate chinese MLR4_S5_con_66c0595e:

    # MC "Sure!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:766
translate chinese MLR4_S5_con_bbdec0ab:

    # MC "Are you sure this is safe?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:768
translate chinese MLR4_S5_con_5527d297:

    # Linda "It’ll be fine. It’s a sturdy table."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:772
translate chinese MLR4_S5_con_8f967a11:

    # Linda "Mmm... I love watching for the exact moment before you slip it inside me."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:774
translate chinese MLR4_S5_con_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:776
translate chinese MLR4_S5_con_95d6c8d0:

    # Linda "It’s the anticipation that gets me excited."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:780
translate chinese MLR4_S5_con_cbabd37e:

    # MC "I’m going to rock your world, [Mom_name]."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:782
translate chinese MLR4_S5_con_fd32374a:

    # MC "We’re alone now, so I want to hear you screaming my name while I pound your pussy."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:786
translate chinese MLR4_S5_con_7a840f57:

    # Linda "*Gasp* Hurry up! Put it inside me! I need to feel your thick cock spreading me open."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:788
translate chinese MLR4_S5_con_2210eb2c:

    # MC "I want to hear you beg."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:792
translate chinese MLR4_S5_con_d3c6ebbc:

    # Linda "Please! Don’t make me wait any longer! I need it!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:794
translate chinese MLR4_S5_con_1295b552:

    # Linda "I need your fat dick buried inside my-"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:798
translate chinese MLR4_S5_con_bf51ad61:

    # Linda "Ayaahhhh! Oohhhhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:800
translate chinese MLR4_S5_con_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:804
translate chinese MLR4_S5_con_ea349b80:

    # MC "Wow! You’re already soaking wet, [Mom_name]! Did you get THAT horny from me fucking your face?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:806
translate chinese MLR4_S5_con_5c14ca96:

    # Linda "Ah! Ahh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:808
translate chinese MLR4_S5_con_c3e50ea2:

    # MC "I’m going to take it out again."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:814
translate chinese MLR4_S5_con_f7de7e76:

    # Linda "W-Wait! Why did you stop?!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:816
translate chinese MLR4_S5_con_da2216aa:

    # MC "Because I want to hear you beg for it again."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:818
translate chinese MLR4_S5_con_7e105c28:

    # Linda "Pleeeeasse fuck me! Pleeease! I need your cock inside me. I need to feel you filling me up!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:822
translate chinese MLR4_S5_con_280481a5:

    # MC "That’s better."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:824
translate chinese MLR4_S5_con_fae060b0:

    # Linda "Ah! Mmm! Yessss! Just like that, [player_name]!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:825
translate chinese MLR4_S5_con_978f5f2a:

    # Linda "Ooohhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:829
translate chinese MLR4_S5_con_684571a0:

    # Linda "*Pant* Mmmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:831
translate chinese MLR4_S5_con_fd44dbfe:

    # Linda "(His cock feels so much better than Bob’s!)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:835
translate chinese MLR4_S5_con_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:837
translate chinese MLR4_S5_con_7a98e4e0:

    # Linda "Ah! Ah! Ayaahhhh! *Pant* I’m- I’m gonna cum! Your fat cock is going to make me cum!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:839
translate chinese MLR4_S5_con_e250001a:

    # Linda "*Gasp* Ayaahh! I’m-"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:843
translate chinese MLR4_S5_con_c4ae0af3:

    # Linda "Noooooohh! I was sooo close! *Pant* Stop teasing me!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:845
translate chinese MLR4_S5_con_4169576a:

    # MC "I just wanted to hear you beg for my dick again. C’mon, just one last time."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:847
translate chinese MLR4_S5_con_9ec5da71:

    # Linda "PLEEEEASE! Fuck me! I want you to wreck my wet pussy! Please thrust it deep inside me! I’m begging you! Fuck me and make me cum!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:851
translate chinese MLR4_S5_con_1e6dfa0d:

    # MC "That’s better. I love hearing you beg for my dick."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:853
translate chinese MLR4_S5_con_239c2633:

    # Linda "Oohhhhhh! Yeessssss!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:855
translate chinese MLR4_S5_con_4a30f771:

    # Linda "*Pant* Ahhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:859
translate chinese MLR4_S5_con_102add15_1:

    # MC "Hnnngg!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:861
translate chinese MLR4_S5_con_c16fc22f:

    # MC "(Her pussy is soaking right now!)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:863
translate chinese MLR4_S5_con_0dfff898:

    # Linda "Ah! Ah!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:867
translate chinese MLR4_S5_con_6320c41b:

    # Linda "Ayaaahhhh! Yeessss!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:869
translate chinese MLR4_S5_con_9071c2d5:

    # Linda "*Pant* Mmm! Bury your dick deep inside me! Ooohhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:873
translate chinese MLR4_S5_con_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:875
translate chinese MLR4_S5_con_596dbcd0:

    # Linda "Ahhhh... Mmmm!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:880
translate chinese MLR4_S5_con_9a91ed5e:

    # Linda "Ah! Ohhhh God! Yesssss!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:882
translate chinese MLR4_S5_con_1cd67aca:

    # MC "*Pant* Fuck, your pussy feels so good, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:886
translate chinese MLR4_S5_con_e12c2c01:

    # Linda "Ayaaahhh! Ohhhh! You’re soooo deep!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:888
translate chinese MLR4_S5_con_5b8ab9ca:

    # MC "Ugh! Oh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:892
translate chinese MLR4_S5_con_2f84212e:

    # MC "*Pant* *Pant* Hnngg! Ugh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:894
translate chinese MLR4_S5_con_6ed6904b:

    # Linda "Ah! Ah! Ah!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:898
translate chinese MLR4_S5_con_da0e34e5:

    # MC "Ohhh fuck! Mmm! *Pant* You’re so fucking tight, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:900
translate chinese MLR4_S5_con_faa60172:

    # Linda "Ah! Ah! Ohhhhh! I’m cumming! I’m cumming! Aaaahhhhhhhh!!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:904
translate chinese MLR4_S5_con_cbf279ae:

    # Linda "Yes! Yes! Ohhhhhh!! HAAAAHHHHH!!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:906
translate chinese MLR4_S5_con_31e20392:

    # MC "Arrghhh! Hnnggg!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:910
translate chinese MLR4_S5_con_cfba34f8:

    # Linda "OooooOOooooOOOHHHHH!!! AYAAAHHHHHH!!!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:913
translate chinese MLR4_S5_con_2f1caae7:

    # MC "HNNNGGG! *Pant* Ohhh fuck! Arrgghhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:915
translate chinese MLR4_S5_con_6ed6904b_1:

    # Linda "Ah! Ah! Ah!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:918
translate chinese MLR4_S5_con_fcbf32a0:

    # Linda "*Gasp *Oh God! I’m cumming again!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:920
translate chinese MLR4_S5_con_2fcb1622:

    # Linda "Ayaahhhhhh!!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:922
translate chinese MLR4_S5_con_c9526ed2:

    # MC "Hnngg! Fuck! I’m gonna cum too!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:926
translate chinese MLR4_S5_con_90400743:

    # Linda "*Pant* Finish inside me! Please! I want to Ah... feel your warm semen fill me up! Ohhhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:928
translate chinese MLR4_S5_con_8eba5a19:

    # MC "(Should I give [Mom_name] a creampie? Or pull out and cum over her belly)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:934
translate chinese MLR4_S5_con_2439c284:

    # MC "*Pant* Hnnng! Ohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:936
translate chinese MLR4_S5_con_19c8b136:

    # Linda "*Gasp* Yes! Fill me up, [player_name]! Ahhhh! Yessss!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:938
translate chinese MLR4_S5_con_243f486b:

    # MC "Argh! Hnnnngg! Oohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:941
translate chinese MLR4_S5_con_243f486b_1:

    # MC "Argh! Hnnnngg! Oohhh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:943
translate chinese MLR4_S5_con_fb05a3b1:

    # Linda "Ahhhhh!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:947
translate chinese MLR4_S5_con_c74a22d2:

    # Linda "*Gasp* Ooohhh! Yessss! Mmmm! I can feel it rushing inside me!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:949
translate chinese MLR4_S5_con_e184347d:

    # MC "Ohhh *Pant* Hnnngg..."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:959
translate chinese MLR4_S5_con_027b0fa3:

    # Linda "*Pant* *Pant* That was... utterly amazing... *Pant*"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:961
translate chinese MLR4_S5_con_c26f5a9d:

    # MC "*Pant* God... Your pussy feels amazing."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:966
translate chinese MLR4_S5_con_32094838:

    # MC "(As good as it would feel, it simply isn’t worth the risk, giving her a creampie right now. Dad’s already gone and getting her pregnant wouldn’t make the situation any easier.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:968
translate chinese MLR4_S5_con_89d3534d:

    # MC "(As good as it would feel, it simply isn’t worth the risk, giving her a creampie right now. Bob is already gone and getting Linda pregnant wouldn’t make the situation any easier.)"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:970
translate chinese MLR4_S5_con_0dfff898_1:

    # Linda "Ah! Ah!"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:972
translate chinese MLR4_S5_con_117cf11d:

    # MC "I’m gonna pull out."
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:976
translate chinese MLR4_S5_con_ff3997d1:

    # Linda "*Pant* Aww..."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:978
translate chinese MLR4_S5_con_4a9ca6d1:

    # MC "Hnnngg! Ugh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:988
translate chinese MLR4_S5_con_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:990
translate chinese MLR4_S5_con_5f14d478:

    # Linda "(It’s a shame he didn’t finish inside me. I was looking forward to that.)"
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:997
translate chinese MLR4_MS5_con2_dc3e13e3:

    # MC "*Pant* That was incredible, [Mom_name]. Wait, are you leaving already?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:999
translate chinese MLR4_MS5_con2_1120f5c5:

    # Linda "I have to get to work."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1003
translate chinese MLR4_MS5_con2_b7834c4a:

    # MC "But we only just finished-"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1005
translate chinese MLR4_MS5_con2_4e83bf13:

    # Linda "I know, I spent far too long doing this. I really need to get to the office."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1007
translate chinese MLR4_MS5_con2_a85c20cb:

    # MC "Oh... Okay, I’ll see you sometime at night, then?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1011
translate chinese MLR4_MS5_con2_d3e1c697:

    # Linda "Yeah, sure. I’ll see you then."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1015
translate chinese MLR4_MS5_con2_63bd2fa9:

    # MC "...is something wrong?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1017
translate chinese MLR4_MS5_con2_56d0cdb0:

    # Linda "No, nothing’s wrong."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1021
translate chinese MLR4_MS5_con2_04cf1d0a:

    # Linda "I’m just running late. That’s all."
    Linda ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1023
translate chinese MLR4_MS5_con2_51a370d8:

    # MC "Umm, okay. If I’ve done something wrong, you can talk to me. You know that, right?"
    MC ""

# game/scripts/ML_R4/5_MLR4_MS5.rpy:1025
translate chinese MLR4_MS5_con2_32dbc105:

    # Linda "I’m fine, I promise. See you at night sometime."
    Linda ""

translate chinese strings:

    # game/scripts/ML_R4/5_MLR4_MS5.rpy:184
    old "Pat her on the butt."
    new ""

    # game/scripts/ML_R4/5_MLR4_MS5.rpy:184
    old "Grab her breasts."
    new ""

    # game/scripts/ML_R4/5_MLR4_MS5.rpy:930
    old "Thrust in deep and give Linda the creampie she so desperately wants."
    new ""

    # game/scripts/ML_R4/5_MLR4_MS5.rpy:930
    old "Play it safe and pull out."
    new ""

