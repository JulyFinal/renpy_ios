﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/8_MLR4_S8.rpy:86
translate chinese MLR4_S8_82bf0f91:

    # Linda "Hmm..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:87
translate chinese MLR4_S8_ee64c46c:

    # Linda "(It’s a little brighter than I would usually go for.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:89
translate chinese MLR4_S8_be8c9dec:

    # Linda "(It DOES fit my figure well though. That girl certainly knew what she was talking about when she had me try on the smaller size.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:91
translate chinese MLR4_S8_0f3d130f:

    # Linda "(I really hope, [player_name] likes it.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:92
translate chinese MLR4_S8_b118c843:

    # Linda "(Bob never appreciated it when I put a little bit of extra effort in.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:94
translate chinese MLR4_S8_119d2bd5:

    # Linda "(Come to think of it, I haven’t worn something this frilly since way back in uni.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:95
translate chinese MLR4_S8_c6d6d70f:

    # Linda "(Liza and Judy had them too. God, we were all so hot back then.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:97
translate chinese MLR4_S8_7747aa98:

    # Linda "(Speaking of uni, I feel twenty years younger wearing this!)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:99
translate chinese MLR4_S8_18727473:

    # Linda "(It really helps my breasts stand out.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:101
translate chinese MLR4_S8_2c79886b:

    # Linda "(Not to mention the way it accentuates my ass.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:103
translate chinese MLR4_S8_5ae844aa:

    # Linda "([player_name] is going to LOVE seeing me dressed in this. I just know it!)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:105
translate chinese MLR4_S8_c6cb6072:

    # Linda "(Alright, I should probably call him now. I wonder where he has been.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:106
translate chinese MLR4_S8_84e97643:

    # Linda "Sweetie?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:107
translate chinese MLR4_S8_be7d99a1:

    # Caroline "Yes, [Mom_name]?!"
    Caroline ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:110
translate chinese MLR4_S8_9abcee9e:

    # Linda "N-Not you, Honey! W-Wait, don’t come in! I’m getting changed! I was calling your brother!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:112
translate chinese MLR4_S8_78f9ca82:

    # Linda "N-Not you, Honey! W-Wait, don’t come in! I’m getting changed! I was calling... uh... [player_name]! "
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:113
translate chinese MLR4_S8_94181e0f:

    # Caroline "Oh. Okay! I’m leaving now, anyway. See ya later!"
    Caroline ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:114
translate chinese MLR4_S8_1b04b05a:

    # Linda "B-Bye!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:116
translate chinese MLR4_S8_90d7cba6:

    # Linda "(Phew... I keep forgetting it’s not just [player_name] and me in the house.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:117
translate chinese MLR4_S8_a47d14ff:

    # MC "Yeah, [Mom_name]? There’s something I need to talk to you abou-"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:119
translate chinese MLR4_S8_dcc829eb:

    # MC "Oh... Wow!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:120
translate chinese MLR4_S8_a1dfda83:

    # Linda "Do you like it?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:122
translate chinese MLR4_S8_f420d081:

    # MC "You look phenomenal! What made you choose pink? You don’t usually go for clothes that... bright."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:123
translate chinese MLR4_S8_2483d747:

    # Linda "I was reading a magazine the other day. Apparently men are attracted to women who dress and act a bit younger. I thought I should put a bit of effort into making myself-"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:125
translate chinese MLR4_S8_f3b99396:

    # MC "[Mom_name], you don’t need to change anything. I already loved you the way you were."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:126
translate chinese MLR4_S8_53f1899f:

    # MC "I have to admit though, you look so fucking hot right now!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:128
translate chinese MLR4_S8_2eea7fd9:

    # Linda "Mmm... Caroline just left the house and Sara’s gone to college."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:129
translate chinese MLR4_S8_8c2f4228:

    # Linda "How about we make the most of an empty house and have some fun together?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:131
translate chinese MLR4_S8_63873555:

    # MC "Absolutely!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:132
translate chinese MLR4_S8_3cc05249:

    # MC "I’m gonna have so much fun fucking you in that."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:134
translate chinese MLR4_S8_3d7d4c22:

    # Linda "*Gulp* I’ve never had sex before."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:135
translate chinese MLR4_S8_e59d3415:

    # MC "(Huh? What’s she talking about?)"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:137
translate chinese MLR4_S8_0333a2ab:

    # Linda "I’ve never done this before. This is my first time."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:138
translate chinese MLR4_S8_6f11ea9d:

    # MC "(Oh! She’s trying to act younger for me...)"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:140
translate chinese MLR4_S8_c84dd457:

    # Linda "You’re going to be my first, so I want you to be gentle when you-"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:141
translate chinese MLR4_S8_9e50b682:

    # MC "(Oh shit! I almost forgot to tell her about Bob’s hidden cameras!)"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:145
translate chinese MLR4_S8_959c15e8:

    # MC "Stop! Wait!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:146
translate chinese MLR4_S8_b191006b:

    # Linda "What’s wrong, Sweetie?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:148
translate chinese MLR4_S8_56ad7071:

    # Linda "Sorry... I thought you’d like it if I acted like this, for a change."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:149
translate chinese MLR4_S8_682dcf0d:

    # MC "No, it’s not that! It’s Bob!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:151
translate chinese MLR4_S8_1d58e689:

    # Linda "Bob?! Why are you bringing him up now? What’s going on?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:152
translate chinese MLR4_S8_6b486c53:

    # MC "He’s in the garage!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:154
translate chinese MLR4_S8_f7be84c6:

    # Linda "He came back?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:156
translate chinese MLR4_S8_6d19aa64:

    # MC "No, [Mom_name]! He NEVER left, in the first place! He’s been living in there!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:157
translate chinese MLR4_S8_971239ee:

    # Linda "WHAT?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:159
translate chinese MLR4_S8_2b72ddca:

    # MC "I saw him last night! I went out to check the garage after we heard those loud noises. He’s sitting in there."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:160
translate chinese MLR4_S8_8c2dc858:

    # MC "He’s got his computers set up and he’s stashed hidden cameras around the house! [Dad_name]’s been recording our sex sessions and watching us!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:162
translate chinese MLR4_S8_04e29e30:

    # Linda "You can’t be serious..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:163
translate chinese MLR4_S8_30bbb68f:

    # MC "I am! Look! There’s one in the corner of the room, hidden inside the plant pot!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:165
translate chinese MLR4_S8_1ddef87c:

    # MC "See? Right over there!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:166
translate chinese MLR4_S8_8303d311:

    # Linda "No way..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:168
translate chinese MLR4_S8_a34a50a3:

    # Linda "Oh my God..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:169
translate chinese MLR4_S8_c57f3704:

    # MC "He’s using us for porn, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:171
translate chinese MLR4_S8_719efd0d:

    # MC "Everything we did that night. He recorded it all!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:172
translate chinese MLR4_S8_8303d311_1:

    # Linda "No way..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:174
translate chinese MLR4_S8_67bb6c51:

    # Linda "Argh!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:175
translate chinese MLR4_S8_372188c3:

    # Linda "I should have KNOWN it was too easy to get him to leave the house. That bastard never had any intention of going, did he?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:177
translate chinese MLR4_S8_29453076:

    # Linda "BOB! That’s enough! Get your ass in here right now!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:178
translate chinese MLR4_S8_36b96984:

    # MC "*Gulp* Uh oh..."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:185
translate chinese MLR4_S8_cb7e9789:

    # Bob "*Hic*"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:186
translate chinese MLR4_S8_49278a52:

    # Bob "I shoulda... shoulda used the... shmaller camerash..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:188
translate chinese MLR4_S8_c99c9d98:

    # Linda "BOB!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:189
translate chinese MLR4_S8_b54dbb06:

    # Bob "Ah h-hey, Linda! You’re looking... looking... *hic* ...well"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:191
translate chinese MLR4_S8_305431af:

    # MC "Oh, yeah. I forgot to mention. He was drinking a bit, last night."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:193
translate chinese MLR4_S8_91a70269:

    # Bob "How... How’re the kids? *Hic* I haven’t sheen them in shoooo long..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:195
translate chinese MLR4_S8_09e632d4:

    # Bob "How... How’re Caroline and Sara? *Hic* I haven’t sheen them in shoooo long..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:196
translate chinese MLR4_S8_7bb91f39:

    # MC "Let me rephrase. He was drinking A LOT last night."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:198
translate chinese MLR4_S8_0f300a36:

    # Linda "Jesus Christ... You’re a mess, Bob."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:199
translate chinese MLR4_S8_92ccd5db:

    # Bob "*Glug* *Glug*"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:201
translate chinese MLR4_S8_f8532423:

    # Linda "Have you been sitting in the garage this entire time?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:202
translate chinese MLR4_S8_cb17defc:

    # Linda "And setting up hidden cameras to record me?! What the FUCK, Bob?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:204
translate chinese MLR4_S8_04514867:

    # MC "[Dad_name]... Maybe now would be a good time to stop drinking and explain yourself?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:205
translate chinese MLR4_S8_92ccd5db_1:

    # Bob "*Glug* *Glug*"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:207
translate chinese MLR4_S8_ea56a272:

    # Bob "Ooohh... I’m feelin’... a bit rough..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:208
translate chinese MLR4_S8_2a07b4b5:

    # Linda "For fuck’s sake."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:210
translate chinese MLR4_S8_7150de99:

    # Bob "Oh dear..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:211
translate chinese MLR4_S8_a359d976:

    # MC "(I guess there goes any chance of us discussing this in a mature way...)"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:216
translate chinese MLR4_S8_933aa022:

    # "*THUD*"
    ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:217
translate chinese MLR4_S8_17f70c69:

    # Bob "Huh... How’d I get down here?"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:219
translate chinese MLR4_S8_edb8f46d:

    # Linda "BOB! I need you to answer me! What are you doing hiding out in the garage?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:220
translate chinese MLR4_S8_70b022ea:

    # Bob "Ohh... Hey, Linda! I didn’t see you there! You’re looking *hic* well!"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:222
translate chinese MLR4_S8_23ea7394:

    # Linda "Arrghhh!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:223
translate chinese MLR4_S8_b6ad9774:

    # MC "It’s no use, [Mom_name]. We’re gonna need to wait for him to sober up."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:225
translate chinese MLR4_S8_03cbecd9:

    # Linda "Fine. Help me move him over to the couch. We’ll deal with him later."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:229
translate chinese MLR4_S8_d2c6675d:

    # Linda "Bob! Bob!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:230
translate chinese MLR4_S8_696938a1:

    # Bob "*Groan*"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:234
translate chinese MLR4_S8_ac73dc92:

    # Linda "You’re finally awake. Are you sober enough to have a grown-up conversation now?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:235
translate chinese MLR4_S8_ece07098:

    # MC "Want to tell us what you were doing in the garage, [Dad_name]?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:237
translate chinese MLR4_S8_03110c3b:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:239
translate chinese MLR4_S8_03110c3b_1:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:241
translate chinese MLR4_S8_03110c3b_2:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:243
translate chinese MLR4_S8_03110c3b_3:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:245
translate chinese MLR4_S8_03110c3b_4:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:247
translate chinese MLR4_S8_03110c3b_5:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:249
translate chinese MLR4_S8_03110c3b_6:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:251
translate chinese MLR4_S8_342491f5:

    # Linda "Don’t think you can just sit in silence and ignore me Bob. What were you doing in the garage?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:252
translate chinese MLR4_S8_03110c3b_7:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:253
translate chinese MLR4_S8_400975b1:

    # Linda "What’s with all the little spy cameras around the house?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:255
translate chinese MLR4_S8_4e9e4150:

    # Bob "I... *Hic* I invoke the fifth amendment right to..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:256
translate chinese MLR4_S8_c2beea1f:

    # Linda "BOB! Did you leave when I told you to get out of the house or not?!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:258
translate chinese MLR4_S8_70980229:

    # Bob "I... I did leave. For a while. I checked into a hotel."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:259
translate chinese MLR4_S8_c56fb755:

    # Bob "But... I just couldn’t get Sara, Caroline and [player_name] out of my head."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:261
translate chinese MLR4_S8_6fc69c4d:

    # Bob "So... I snuck back into the garage. I know you didn’t want me anymore, but I just wanted to be close to my kids..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:263
translate chinese MLR4_S8_26cfcb53:

    # Bob "So... I snuck back into the garage. I know you didn't want me anymore, but I just wanted to be close..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:265
translate chinese MLR4_S8_8954c1f5:

    # Linda "And the hidden cameras?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:266
translate chinese MLR4_S8_f2ef3b3b:

    # Bob "*Sigh* They came later. I snuck *Hic* in when you were all out at work. I dunno. I just heard the sounds of you and [player_name] fucking in here and..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:268
translate chinese MLR4_S8_bbda2aba:

    # MC "And you felt compelled to watch what was going on?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:269
translate chinese MLR4_S8_012baa50:

    # Bob "... *Sigh*"
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:271
translate chinese MLR4_S8_25cd9781:

    # Linda "Jesus Christ... Bob..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:272
translate chinese MLR4_S8_c9f40e7d:

    # Bob "I’m sorry, Linda. I did try to leave... I promise."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:274
translate chinese MLR4_S8_6dddd061:

    # Bob "I moved into the garage because I missed you guys... I didn’t- I didn’t plan the cameras until later."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:275
translate chinese MLR4_S8_daf00c9b:

    # Bob "I got bored and lonely and depressed, sitting in the dark by myself..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:277
translate chinese MLR4_S8_8ff35fea:

    # Bob "The cameras seemed like a good way to pass the time."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:278
translate chinese MLR4_S8_d57cc9e4:

    # Linda "*Sigh*"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:280
translate chinese MLR4_S8_cb113e3e:

    # Bob "I’ll make it easy on you. Once I’ve sobered up, I’ll go down to the station and turn myself in to the police."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:281
translate chinese MLR4_S8_e9ec09e4:

    # MC "W-What?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:282
translate chinese MLR4_S8_27c740bd:

    # Bob "You can have the house, Linda. Just... You all don’t need me anymore."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:284
translate chinese MLR4_S8_5b5613c2:

    # Linda "Bob, stop it!"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:286
translate chinese MLR4_S8_268e7855:

    # Bob "I’m *Hic* obsolete. [player_name] can take care of you and his sisters better than I ever *Hic* could."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:288
translate chinese MLR4_S8_9baa56e1:

    # Bob "I’m *Hic* obsolete. [player_name] can take care of you and the two girls better than I ever *Hic* could."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:290
translate chinese MLR4_S8_69a29e9e:

    # Bob "And he’s better than me in bed too..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:291
translate chinese MLR4_S8_39a7e827:

    # Bob "The way he screwed you... It was... *Hic* ...I’ve never been able to make you scream like that."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:293
translate chinese MLR4_S8_82bf0f91_1:

    # Linda "Hmm..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:294
translate chinese MLR4_S8_c1957933:

    # Bob "I’m gonna need the car... I still need to travel *hic* for work... and it’s a company car anyway, so I can’t exactly just give it to you during the divorce."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:296
translate chinese MLR4_S8_83dd49f4:

    # MC "(Why isn’t [Mom_name] saying anything?)"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:298
translate chinese MLR4_S8_0708324e:

    # Bob "I’d still... I’d still like to see the kids every now and then... if you’ll let me."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:300
translate chinese MLR4_S8_0ef1e99f:

    # Bob "I’d still... I’d still like to see all of you every now and then... if you’ll let me."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:302
translate chinese MLR4_S8_e87c5422:

    # Linda "Shut up, Bob."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:303
translate chinese MLR4_S8_4cc39eb8:

    # Linda "[player_name], I want you to kiss me."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:304
translate chinese MLR4_S8_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:306
translate chinese MLR4_S8_f1b1ca33:

    # Linda "Kiss me, right now."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:307
translate chinese MLR4_S8_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:308
translate chinese MLR4_S8_39bf28a8:

    # MC "Wh-Why? What’s-"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:310
translate chinese MLR4_S8_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:311
translate chinese MLR4_S8_a365e84f:

    # Linda "Mmmm..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:313
translate chinese MLR4_S8_ab980d7c:

    # MC "(What’s [Mom_name] up to? Bob may have spied on us, but he’s clearly having some kind of mental health crisis right now and she’s just treating him like shit!)"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:314
translate chinese MLR4_S8_22751478:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:316
translate chinese MLR4_S8_e52e27bd:

    # Linda "*Mwah*"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:317
translate chinese MLR4_S8_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:319
translate chinese MLR4_S8_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:320
translate chinese MLR4_S8_0aec990a:

    # Linda "(Time to see if I was right.)"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:322
translate chinese MLR4_S8_ad1661dc:

    # Linda "Aha... I knew it."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:323
translate chinese MLR4_S8_cc321b68:

    # MC "Huh? Knew what?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:325
translate chinese MLR4_S8_c3e084f1:

    # Linda "Bob’s enjoying this."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:326
translate chinese MLR4_S8_e00c8711:

    # MC "Yeah, I told you he was watching us on the hidden cameras."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:328
translate chinese MLR4_S8_afbac722:

    # Bob "I... uh... Well, this is a bit embarrassing."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:330
translate chinese MLR4_S8_13e58a1a:

    # Linda "You don’t say..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:331
translate chinese MLR4_S8_3ea5041b:

    # MC "Y’know, [Mom_name]. There might be a solution here."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:332
translate chinese MLR4_S8_5c09582f:

    # Linda "What do you mean?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:334
translate chinese MLR4_S8_06d23856:

    # MC "[Dad_name] clearly misses everyone. I understand that the two of you aren’t getting back together, but he still cares about Sara, Caroline and me."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:335
translate chinese MLR4_S8_803a77ab:

    # Linda "*Sigh* What are you suggesting?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:337
translate chinese MLR4_S8_759e8c1b:

    # MC "I’m saying we should just let him move back in and live here. He can still get to see the girls every single day that way."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:338
translate chinese MLR4_S8_2abd6bd1:

    # Linda "And what about us?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:339
translate chinese MLR4_S8_098b0838:

    # MC " Well, he clearly enjoys watching us! Why not let him?"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:340
translate chinese MLR4_S8_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:341
translate chinese MLR4_S8_b96d7b28:

    # MC "C’mon, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:342
translate chinese MLR4_S8_34843193:

    # Linda "*Sigh* You make a good point."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:344
translate chinese MLR4_S8_a51a69e6:

    # Linda "Alright Bob, go and wash yourself. You stink like a cheap bar."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:345
translate chinese MLR4_S8_b4628037:

    # Linda "And clear out that creepy set up you’ve got going on in the garage. I don’t want to find any more hidden cameras around the home."
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:346
translate chinese MLR4_S8_c94b7523:

    # Bob "*Hic* Okay, Linda..."
    Bob ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:348
translate chinese MLR4_S8_5fe5446d:

    # Linda "I’m gonna need some time to talk with Bob and figure this out. Can you give me a couple of days to get my life in order?"
    Linda ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:349
translate chinese MLR4_S8_3332f09c:

    # MC "Sure, no problem, [Mom_name]. Take all the time you need."
    MC ""

# game/scripts/ML_R4/8_MLR4_S8.rpy:350
translate chinese MLR4_S8_d4187935:

    # Linda "Thank you, Sweetie. I appreciate it."
    Linda ""

