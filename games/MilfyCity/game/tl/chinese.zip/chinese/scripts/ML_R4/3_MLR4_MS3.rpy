﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/3_MLR4_MS3.rpy:36
translate chinese MLR4_MS3_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:38
translate chinese MLR4_MS3_6f050731:

    # "*Clunk*"
    ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:39
translate chinese MLR4_MS3_db2a1bfc:

    # MC "(It looks like Dad’s packing the car. I knew things weren’t going to end well if Mom and I kept fooling around... but I never imagined he was actually going to leave.)"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:41
translate chinese MLR4_MS3_7aef08d8:

    # Bob "*Sigh*"
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:44
translate chinese MLR4_MS3_91ea4cf9_1:

    # "*Thud*"
    ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:45
translate chinese MLR4_MS3_a65aee0e:

    # Bob "Alright... That’s the last case."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:47
translate chinese MLR4_MS3_03110c3b:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:48
translate chinese MLR4_MS3_0c39d07a:

    # Bob "Thirty years... Thirty years fits in the back of a sedan. Can you believe it?"
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:50
translate chinese MLR4_MS3_1efedcac:

    # Bob "I kinda figured I’d have more to show for it, y’know? Heh... My entire life here. Everything I valued... and it only took two suitcases."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:51
translate chinese MLR4_MS3_80278abc:

    # MC "I’m sorry, Dad."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:53
translate chinese MLR4_MS3_3afd3b4a:

    # Bob "It’s peculiar how the things I want the most are the exact things that I can’t take with me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:54
translate chinese MLR4_MS3_40e8b255:

    # Bob "I can’t fold my hopes for the future. I can’t squeeze my retirement plans in with my toiletries."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:56
translate chinese MLR4_MS3_6f5f93ba:

    # Bob "Sara might be able to squeeze in a suitcase, but I can’t just pack one of her hugs and take it with me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:57
translate chinese MLR4_MS3_c370310d:

    # Bob "Heh... I can’t even pack the feeling of Caroline brewing me one of those weak, awful coffees she always makes. Even if she made me one, it’d be cold by the time I left the city."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:58
translate chinese MLR4_MS3_a2bce536:

    # Bob "God... I’m gonna miss her."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:60
translate chinese MLR4_MS3_f1e0efa1:

    # Bob "*Sniff* It’s... It’s the incorporeal stuff that I want to hold on to the most. The rest is meaningless."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:61
translate chinese MLR4_MS3_89cf2644:

    # Bob "All these fancy suits, my cigars, my watches..."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:63
translate chinese MLR4_MS3_018e5e7c:

    # Bob "...at the end of the day, they’re nothing compared to what I had."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:64
translate chinese MLR4_MS3_ae69832e:

    # MC "I’m really sorry, Dad. For everything."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:66
translate chinese MLR4_MS3_652645c7:

    # Bob "Don’t fret about it. Linda’s happy with you. I can see that. You have a responsibility now. You’ve got to keep her happy. Take care of her."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:67
translate chinese MLR4_MS3_243a6981:

    # MC "You’re not angry?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:68
translate chinese MLR4_MS3_44dc2af4:

    # Bob "Not at you."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:69
translate chinese MLR4_MS3_23c3f162:

    # MC "You’re angry with Mom."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:70
translate chinese MLR4_MS3_7b97dfdf:

    # Bob "No. Not at all. I’m angry with myself. And sad. And hurting."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:72
translate chinese MLR4_MS3_80278abc_1:

    # MC "I’m sorry, Dad."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:73
translate chinese MLR4_MS3_fe6f51b1:

    # Bob "Don’t be. I saw this coming for a long time. I just buried my head in the sand and pretended Linda still loved me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:80
translate chinese MLR4_MS3_91ea4cf9_2:

    # "*Thud*"
    ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:82
translate chinese MLR4_MS3_6f050731_1:

    # "*Clunk*"
    ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:83
translate chinese MLR4_MS3_f375bca7:

    # MC "(It looks like Bob’s packing the car. I knew things weren’t going to end well if Linda and I kept fooling around... but I never imagined he was actually going to leave.)"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:85
translate chinese MLR4_MS3_7aef08d8_1:

    # Bob "*Sigh*"
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:88
translate chinese MLR4_MS3_91ea4cf9_3:

    # "*Thud*"
    ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:89
translate chinese MLR4_MS3_a65aee0e_1:

    # Bob "Alright... That’s the last case."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:91
translate chinese MLR4_MS3_03110c3b_1:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:92
translate chinese MLR4_MS3_0c39d07a_1:

    # Bob "Thirty years... Thirty years fits in the back of a sedan. Can you believe it?"
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:94
translate chinese MLR4_MS3_1efedcac_1:

    # Bob "I kinda figured I’d have more to show for it, y’know? Heh... My entire life here. Everything I valued... and it only took two suitcases."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:95
translate chinese MLR4_MS3_33dead7b:

    # MC "I’m sorry, Bob."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:97
translate chinese MLR4_MS3_3afd3b4a_1:

    # Bob "It’s peculiar how the things I want the most are the exact things that I can’t take with me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:98
translate chinese MLR4_MS3_40e8b255_1:

    # Bob "I can’t fold my hopes for the future. I can’t squeeze my retirement plans in with my toiletries."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:100
translate chinese MLR4_MS3_6f5f93ba_1:

    # Bob "Sara might be able to squeeze in a suitcase, but I can’t just pack one of her hugs and take it with me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:101
translate chinese MLR4_MS3_c370310d_1:

    # Bob "Heh... I can’t even pack the feeling of Caroline brewing me one of those weak, awful coffees she always makes. Even if she made me one, it’d be cold by the time I left the city."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:102
translate chinese MLR4_MS3_3dfac23b:

    # Bob "God... I’m gonna miss them both. I know they’re just tenants, but they’ve lived here so long that I’ve grown close to both of ‘em."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:104
translate chinese MLR4_MS3_f1e0efa1_1:

    # Bob "*Sniff* It’s... It’s the incorporeal stuff that I want to hold on to the most. The rest is meaningless."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:105
translate chinese MLR4_MS3_89cf2644_1:

    # Bob "All these fancy suits, my cigars, my watches..."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:107
translate chinese MLR4_MS3_018e5e7c_1:

    # Bob "...at the end of the day, they’re nothing compared to what I had."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:108
translate chinese MLR4_MS3_0e87bf62:

    # MC "I’m really sorry, Bob. For everything."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:110
translate chinese MLR4_MS3_652645c7_1:

    # Bob "Don’t fret about it. Linda’s happy with you. I can see that. You have a responsibility now. You’ve got to keep her happy. Take care of her."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:111
translate chinese MLR4_MS3_243a6981_1:

    # MC "You’re not angry?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:112
translate chinese MLR4_MS3_44dc2af4_1:

    # Bob "Not at you."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:113
translate chinese MLR4_MS3_f3a88820:

    # MC "You’re angry with Linda."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:114
translate chinese MLR4_MS3_7b97dfdf_1:

    # Bob "No. Not at all. I’m angry with myself. And sad. And hurting."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:116
translate chinese MLR4_MS3_ef709962:

    # MC "I’m sorry, Bob. I really am."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:117
translate chinese MLR4_MS3_fe6f51b1_1:

    # Bob "Don’t be. I saw this coming for a long time. I just buried my head in the sand and pretended Linda still loved me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:126
translate chinese MLR4_MS3_q_5011156c:

    # MC "Where are you going to stay, [Dad_name]?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:128
translate chinese MLR4_MS3_q_217d9159:

    # Bob "I haven’t decided yet. I’ve got a few options in mind though."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:129
translate chinese MLR4_MS3_q_0850b562:

    # MC "You’re not going to be homeless, are you?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:131
translate chinese MLR4_MS3_q_8f28db0c:

    # Bob "Oh, no. Don’t you worry about that. I have plenty of places I can go to."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:141
translate chinese MLR4_MS3_q_f009ce61:

    # MC "Can I at least come and visit you?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:143
translate chinese MLR4_MS3_q_2f1a37dd:

    # Bob "I don’t think that’s a good idea. At least, not right now."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:144
translate chinese MLR4_MS3_q_94ce5f74:

    # MC "When am I going to see you again?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:147
translate chinese MLR4_MS3_q_69dab0d1:

    # Bob "*Sigh* Listen, your... Maybe... Maybe we can try and get the family together for Christmas. It gives me a chance to settle in and get my place decorated."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:148
translate chinese MLR4_MS3_q_3c0bce96:

    # Bob "You could swing by with your sisters if your Mom lets you and we’ll make the most of the holidays. How does that sound? "
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:150
translate chinese MLR4_MS3_q_7bde9d8e:

    # Bob "*Sigh* Listen, your... Maybe... Maybe we can try and get everyone together for Christmas. It gives me a chance to settle in and get my place decorated."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:151
translate chinese MLR4_MS3_q_e87a0078:

    # Bob "You could swing by with Caroline and Sara if Linda lets you. We’ll make the most of the holidays. How does that sound?"
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:153
translate chinese MLR4_MS3_q_ed503bed:

    # MC "Do you promise? Or are you just saying that to try and make me feel better?"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:155
translate chinese MLR4_MS3_q_87ff9938:

    # Bob "Y-Yeah, I mean it. You can all come over for Christmas. Linda’s not gonna mind."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:169
translate chinese MLR4_MS3_con_0df51121:

    # Bob "I, uh... I better get a move on. No sense in antagonizing your mother by having me lingering around."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:171
translate chinese MLR4_MS3_con_56021d0d:

    # Bob "I, uh... I better get a move on. No sense in antagonizing Linda by having me lingering around."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:172
translate chinese MLR4_MS3_con_09630d3c:

    # MC "Y-Yeah, I get it."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:174
translate chinese MLR4_MS3_con_82038ea5:

    # MC "...I’m really gonna miss you, [Dad_name]."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:175
translate chinese MLR4_MS3_con_03110c3b:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:176
translate chinese MLR4_MS3_con_9ebc51ff:

    # MC "I mean that. I never wanted to hurt y-"
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:178
translate chinese MLR4_MS3_con_27e9cbef:

    # Bob "I love you, [player_name]. Take care of Linda for me."
    Bob ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:179
translate chinese MLR4_MS3_con_c540d552:

    # MC "I love you, [Dad_name]..."
    MC ""

# game/scripts/ML_R4/3_MLR4_MS3.rpy:180
translate chinese MLR4_MS3_con_7d017e88:

    # Bob "Goodbye, [player_name]."
    Bob ""

translate chinese strings:

    # game/scripts/ML_R4/3_MLR4_MS3.rpy:123
    old "Where are you going to live?"
    new ""

    # game/scripts/ML_R4/3_MLR4_MS3.rpy:123
    old "Can I come and visit you?"
    new ""

