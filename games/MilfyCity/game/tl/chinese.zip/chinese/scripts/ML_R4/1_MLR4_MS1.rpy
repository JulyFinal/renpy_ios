﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/1_MLR4_MS1.rpy:45
translate chinese MLR4_MS1_5477a073:

    # MC "(I've already talked with him.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:58
translate chinese MLR4_MS1_081e3a3f:

    # Dad "*Sniff* Ohh... Fucking hell..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:59
translate chinese MLR4_MS1_c15f6800:

    # MC "(Oh my God... [Dad_name]...)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:60
translate chinese MLR4_MS1_4771341c:

    # MC "(I’ve never seen him lose his composure before. Even when [Mom_name] was fighting with him, he never lost his temper or cried.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:61
translate chinese MLR4_MS1_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:63
translate chinese MLR4_MS1_7d71531c:

    # MC "(I think I’ve broken my Dad.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:65
translate chinese MLR4_MS1_c75ab17a:

    # MC "(I think I’ve broken him...)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:71
translate chinese MLR4_MS1_b5afb1c3:

    # MC "(I think I better go, and give him some space. If he’s drunk enough, he might not have noticed me yet.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:72
translate chinese MLR4_MS1_66564c64:

    # Dad "*Sniff*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:74
translate chinese MLR4_MS1_87efefe3:

    # Dad "[player_name], wait... Don’t go..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:75
translate chinese MLR4_MS1_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:77
translate chinese MLR4_MS1_75b72af6:

    # Dad "Please..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:78
translate chinese MLR4_MS1_b4268732:

    # Dad "I just want to... I want... I just want to talk with you."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:79
translate chinese MLR4_MS1_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:82
translate chinese MLR4_MS1_a78b3466:

    # Dad "Please, [player_name]. You’re my boy. *Sob* Please, you’re the only son I’ve got."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:84
translate chinese MLR4_MS1_f071c310:

    # Dad "Please, [player_name]. You’re the only... *Sob* You’re the only man in this house..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:85
translate chinese MLR4_MS1_8512c683:

    # MC "(I don’t think I can avoid this any longer. He seems to be more sad than angry. Although, somehow THAT makes me feel much worse...)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:90
translate chinese MLR4_MS1_1522a843:

    # MC "(I need to try and clear the air. It isn’t healthy for either of us to be sneaking around and hiding from each other like this.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:91
translate chinese MLR4_MS1_fdc0c692:

    # MC "(And it seems like he’ll drink himself to an early grave if I don’t do something soon.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:93
translate chinese MLR4_MS1_80bf4e80:

    # MC "H-Hey [Dad_name]. Are you... *Gulp* Are you angry with me?"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:94
translate chinese MLR4_MS1_b69496b9:

    # Dad "... *Sigh*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:101
translate chinese MLR4_MS1_con_56b2009c:

    # Dad "I’ve- *sob* I’m losing her, [player_name]. At least, I am if I *hic* haven’t already."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:102
translate chinese MLR4_MS1_con_94dfb2dc:

    # Dad "She was the *hic* love of my life. I was supp- *hic* supposed to grow old with her. We used to talk about buying a little lakefront property up in Canada. Somewhere deep in the woods - just me and her."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:103
translate chinese MLR4_MS1_con_a165f3b2:

    # Dad "Then Caroline came along, followed by you, and Sara."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:105
translate chinese MLR4_MS1_con_ae08d65e:

    # Dad "And before you know it, you’re *Hic* in your fifties and your dreams for the future are staring back at you from your rear-view mirror."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:106
translate chinese MLR4_MS1_con_048ac352:

    # Dad "I drove- *Sob* I drove past my dreams at a hundred miles per hour. But that was okay! Because there was a destination I wanted to reach..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:107
translate chinese MLR4_MS1_con_8b63260c:

    # Dad "...that lakeshore cabin with Linda."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:109
translate chinese MLR4_MS1_con_667a59c3:

    # Dad "God, I wanted it so fucking bad. Waking up in the morning to find her head resting on my chest. *Sob* I loved it when she used to fall asleep listening to my heartbeat. "
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:110
translate chinese MLR4_MS1_con_6c7c41b0:

    # Dad "I thought... I thought this rough patch was just the stress of having kids, y’know? I was clinging to this little flicker of hope that I’d get her back when the three of you moved out."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:112
translate chinese MLR4_MS1_con_8053a5d7:

    # Dad "I’m an old man now, [player_name]. I’ve spent the past three decades happily driving towards a dream because I knew Linda was on that ride with me."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:113
translate chinese MLR4_MS1_con_3197354a:

    # Dad "*Sniff* And then I turn around one day and find the passenger seat is empty."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:114
translate chinese MLR4_MS1_con_c8d07bb4:

    # Dad "What am I supposed to do, at my age? I don't want to go and retire in some lakeside cabin in Canada, all alone - just waiting till I finally die."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:115
translate chinese MLR4_MS1_con_2e22a8a3:

    # Dad "I mean *Sniff* what can a man, well past his prime, possibly hope to make of himself in the final years of his life? I’m not fit or strong anymore. I’m not handsome. *Hic* And my family clearly hates me..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:117
translate chinese MLR4_MS1_con_9828da90:

    # MC "(Fuck me... I feel like Linda and I have ruined his life.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:118
translate chinese MLR4_MS1_con_896269ca:

    # Dad "*Glug* *Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:120
translate chinese MLR4_MS1_con_130cf523:

    # MC "(He’s a hollow shell of what he used to be.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:121
translate chinese MLR4_MS1_con_fafd49f0:

    # MC "(My Dad always used to know what to say when I needed some advice. It’s unsettling, seeing him as completely and utterly lost as I was after Celia rejected me.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:122
translate chinese MLR4_MS1_con_251b8ed4:

    # Dad "*Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:124
translate chinese MLR4_MS1_con_828ece57:

    # MC "(I don’t even know what to say to comfort him.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:125
translate chinese MLR4_MS1_con_7300ef79:

    # Dad "Maybe I should just go to Canada by myself. Heck, I’ll still get half the value of our assets. That should be enough *hic* to get me a small cabin. "
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:126
translate chinese MLR4_MS1_con_3ff3de6d:

    # Dad "I mean, I wouldn’t be totally alone. I could start fishing. Caroline would visit me. Sara too."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:128
translate chinese MLR4_MS1_con_e8169f27:

    # Dad "And... *Sigh* ...neither of them liked fishing - the way you did. Do you remember our first time I took you fishing?"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:129
translate chinese MLR4_MS1_con_17ec3797:

    # Dad "God... Your first catch was absolutely pathetic. This tiny little trout. It must have been barely two inches."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:131
translate chinese MLR4_MS1_con_e4b58123:

    # Dad "*Sniff* But you were SOOO proud of it."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:132
translate chinese MLR4_MS1_con_2e6ea7da:

    # Dad "Linda wanted to take a photo, of course. You holding your first, catch. I should’ve agreed. I really wanted your first picture with a fish to be a big one."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:134
translate chinese MLR4_MS1_con_4c083080:

    # Dad "*Sigh* I wish I had just let her take the stupid photo. I’d have carried it around in my wallet every single day, if she did."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:135
translate chinese MLR4_MS1_con_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:137
translate chinese MLR4_MS1_con_f57b376b:

    # Dad "I’ve fucked it all up, [player_name]. Linda, Caroline, Sara, you, being a dad... taking proper care of my family... I’ve-"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:138
translate chinese MLR4_MS1_con_5945eeff:

    # Dad "*Sob* I’ve fucked it all up."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:140
translate chinese MLR4_MS1_con_7de39c8d:

    # Dad "Sit with me, son."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:141
translate chinese MLR4_MS1_con_1f55adac:

    # Dad "I just realised we’ve never sat down and had your first drink together."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:143
translate chinese MLR4_MS1_con_1d519829:

    # Dad "I shoulda taken you to a bar and done it properly. My own Dad never did any of this with me."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:144
translate chinese MLR4_MS1_con_3c929bd6:

    # Dad "God, I wish he had. I’d give anything to see him again."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:146
translate chinese MLR4_MS1_con_418a24c0:

    # Dad "C’mon son, sit and have a drink with me."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:147
translate chinese MLR4_MS1_con_bdc97872:

    # MC "Dad, I-"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:149
translate chinese MLR4_MS1_con_0e509991:

    # Dad "Please. I don’t want it to be too late for me to at least make some amends."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:150
translate chinese MLR4_MS1_con_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:152
translate chinese MLR4_MS1_con_75b72af6:

    # Dad "Please..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:154
translate chinese MLR4_MS1_con_8e5b4149:

    # Dad "Thank you."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:155
translate chinese MLR4_MS1_con_a830f2b4:

    # Dad "*Sigh* I should’ve been present in your lives more. I should’ve sat down and played some video games with Sara. Maybe she wouldn’t have turned into such a recluse - gaming all by herself."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:156
translate chinese MLR4_MS1_con_72a6a439:

    # Dad "And Caroline... She always said she was fine, but I saw those bruises and heard her crying after her dates with that... fucking asshole."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:158
translate chinese MLR4_MS1_con_7f619a2f:

    # Dad "And you know what I did about it? Fucking nothing."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:159
translate chinese MLR4_MS1_con_1465ca99:

    # Dad "I was negligent. Detached. I figured if she said she was fine, then she could stand on her own two feet. I thought she would have come to me if she actually needed help."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:160
translate chinese MLR4_MS1_con_f86b8abb:

    # Dad "Caroline was always too proud to ask for it though. *Sigh* I shoulda known that."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:162
translate chinese MLR4_MS1_con_1dd5e8df:

    # Dad "And you... I should’ve been there to support you after *hic* all that shit you went through with that Professor of yours."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:163
translate chinese MLR4_MS1_con_48373446:

    # MC "Dad, it’s okay. You didn’t have to-"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:164
translate chinese MLR4_MS1_con_4ab38c7a:

    # Dad "No, I DID have to. It was my- *Sniff* It was my job as a father to protect each and every one of you. And I failed, every fucking time."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:165
translate chinese MLR4_MS1_con_9cf0e975:

    # MC "Honestly Dad, it’s okay."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:168
translate chinese MLR4_MS1_con_53eb9db8:

    # "*Glug*"
    ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:170
translate chinese MLR4_MS1_con_53eb9db8_1:

    # "*Glug*"
    ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:172
translate chinese MLR4_MS1_con_324101b0:

    # Dad "Y’know... Maybe this place would be better without me in it? I’ve never been enough for Linda. I could never *Hic* fully satisfy her needs."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:173
translate chinese MLR4_MS1_con_22a34feb:

    # Dad "And you... You’re gonna look after your sisters when I’m gone. You understand that?"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:175
translate chinese MLR4_MS1_con_08240fa0:

    # MC "Y-Yeah, Dad. I got it."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:176
translate chinese MLR4_MS1_con_a3acd800:

    # Dad "B-Because you’re... You’re gonna be the *hic* man of the house now."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:177
translate chinese MLR4_MS1_con_e7963a06:

    # Dad "You need to step up, where I failed. You gotta... You gotta take care of Sara. Make shure... sure she doeshn’t lock herself away, gaming all the *hic* time."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:180
translate chinese MLR4_MS1_con_896269ca_1:

    # Dad "*Glug* *Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:182
translate chinese MLR4_MS1_con_5ac52b4c:

    # Dad "And you gotta keep an eye *Hic* on Caroline too. Protect her from that... fucking asshole. If she shays... *hic* says she’s fine, don’t listen to her. She’s... *hic* hiding what’s really wrong."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:184
translate chinese MLR4_MS1_con_6d01a29f:

    # Dad "Ohh, and Linda... You’re gonna take care of her when I’m gone."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:185
translate chinese MLR4_MS1_con_8e799782:

    # MC "Dad... You don’t have to-"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:186
translate chinese MLR4_MS1_con_b68c2664:

    # Dad "You’re gonna make her happy. Okay? Promise me you’re gonna make her happy."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:187
translate chinese MLR4_MS1_con_f315c3e7:

    # MC "...I’ll make her happy, Dad. I promise. I’ll take care of everyone."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:188
translate chinese MLR4_MS1_con_9f2e360e:

    # Dad "Thank you, son. That means... That means a lot. The family is in good hands."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:191
translate chinese MLR4_MS1_con_251b8ed4_1:

    # Dad "*Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:193
translate chinese MLR4_MS1_con_10f7a572:

    # Dad "Zzz..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:194
translate chinese MLR4_MS1_con_cdd65458:

    # MC "...Dad?"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:195
translate chinese MLR4_MS1_con_e871c597:

    # Dad "*Snore*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:197
translate chinese MLR4_MS1_con_353fb35d:

    # MC "*Sigh* Goodnight, Dad."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:199
translate chinese MLR4_MS1_con_7d0bad75:

    # MC "I’m... I’m sorry for everything. You didn’t deserve any of this."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:204
translate chinese MLR4_MS1_con_56b2009c_1:

    # Dad "I’ve- *sob* I’m losing her, [player_name]. At least, I am if I *hic* haven’t already."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:205
translate chinese MLR4_MS1_con_94dfb2dc_1:

    # Dad "She was the *hic* love of my life. I was supp- *hic* supposed to grow old with her. We used to talk about buying a little lakefront property up in Canada. Somewhere deep in the woods - just me and her."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:206
translate chinese MLR4_MS1_con_10da47e3:

    # Dad "Then things got expensive... So we took in Caroline, then you, and then Sara. *Hic* we needed the extra money to cover the mortgage..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:208
translate chinese MLR4_MS1_con_ae08d65e_1:

    # Dad "And before you know it, you’re *Hic* in your fifties and your dreams for the future are staring back at you from your rear-view mirror."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:209
translate chinese MLR4_MS1_con_048ac352_1:

    # Dad "I drove- *Sob* I drove past my dreams at a hundred miles per hour. But that was okay! Because there was a destination I wanted to reach..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:210
translate chinese MLR4_MS1_con_8b63260c_1:

    # Dad "...that lakeshore cabin with Linda."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:212
translate chinese MLR4_MS1_con_667a59c3_1:

    # Dad "God, I wanted it so fucking bad. Waking up in the morning to find her head resting on my chest. *Sob* I loved it when she used to fall asleep listening to my heartbeat. "
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:213
translate chinese MLR4_MS1_con_6703d858:

    # Dad "I thought... I thought this rough patch was just the stress of having three tenants, y’know? I was clinging to this little flicker of hope that I’d get her back when the three of you moved out."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:215
translate chinese MLR4_MS1_con_8053a5d7_1:

    # Dad "I’m an old man now, [player_name]. I’ve spent the past three decades happily driving towards a dream because I knew Linda was on that ride with me."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:216
translate chinese MLR4_MS1_con_3197354a_1:

    # Dad "*Sniff* And then I turn around one day and find the passenger seat is empty."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:217
translate chinese MLR4_MS1_con_c8d07bb4_1:

    # Dad "What am I supposed to do, at my age? I don't want to go and retire in some lakeside cabin in Canada, all alone - just waiting till I finally die."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:218
translate chinese MLR4_MS1_con_f22642ba:

    # Dad "I mean *Sniff* what can a man, well past his prime, possibly hope to make of himself in the final years of his life? I’m not fit or strong anymore. I’m not handsome. *Hic* And my wife clearly hates me..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:220
translate chinese MLR4_MS1_con_24a4edab:

    # MC "(Fuck me... I feel like Linda and I have ruined his life... Besides, it’s me fucking his wife)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:221
translate chinese MLR4_MS1_con_896269ca_2:

    # Dad "*Glug* *Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:223
translate chinese MLR4_MS1_con_130cf523_1:

    # MC "(He’s a hollow shell of what he used to be.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:224
translate chinese MLR4_MS1_con_5c430729:

    # MC "(Bob always used to know what to say when I needed some advice. It’s unsettling, seeing him as completely and utterly lost as I was after Celia rejected me.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:225
translate chinese MLR4_MS1_con_251b8ed4_2:

    # Dad "*Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:227
translate chinese MLR4_MS1_con_828ece57_1:

    # MC "(I don’t even know what to say to comfort him.)"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:228
translate chinese MLR4_MS1_con_7300ef79_1:

    # Dad "Maybe I should just go to Canada by myself. Heck, I’ll still get half the value of our assets. That should be enough *hic* to get me a small cabin. "
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:229
translate chinese MLR4_MS1_con_c1f0671b:

    # Dad "I mean, I wouldn’t be totally alone. I could start fishing. Caroline would visit me. Sara too. Yeah... I get on with both of them pretty well..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:231
translate chinese MLR4_MS1_con_3a1a68e8:

    # Dad "And... *Sigh* ...neither of them liked fishing - the way you did. Do you remember your first time I took you fishing?"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:232
translate chinese MLR4_MS1_con_17ec3797_1:

    # Dad "God... Your first catch was absolutely pathetic. This tiny little trout. It must have been barely two inches."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:234
translate chinese MLR4_MS1_con_e4b58123_1:

    # Dad "*Sniff* But you were SOOO proud of it."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:235
translate chinese MLR4_MS1_con_2e6ea7da_1:

    # Dad "Linda wanted to take a photo, of course. You holding your first, catch. I should’ve agreed. I really wanted your first picture with a fish to be a big one."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:237
translate chinese MLR4_MS1_con_4c083080_1:

    # Dad "*Sigh* I wish I had just let her take the stupid photo. I’d have carried it around in my wallet every single day, if she did."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:238
translate chinese MLR4_MS1_con_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:240
translate chinese MLR4_MS1_con_09ab3fa8:

    # Dad "I’ve fucked it all up, [player_name]. Linda, Caroline, Sara, you, being a husband... taking proper care of my wife... I’ve-"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:241
translate chinese MLR4_MS1_con_5945eeff_1:

    # Dad "*Sob* I’ve fucked it all up."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:243
translate chinese MLR4_MS1_con_ce7dd435:

    # Dad "Sit with me, [player_name]."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:244
translate chinese MLR4_MS1_con_a827f25d:

    # Dad "I just realised we’ve never sat down and had a proper drink together."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:246
translate chinese MLR4_MS1_con_260c8a4d:

    # Dad "I shoulda taken you to a bar and done it properly. My own Dad never did any of this with me. I know you’re just my tenant, but you kinda feel like a son to me in some ways."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:247
translate chinese MLR4_MS1_con_9b625331:

    # Dad "God, I wish he had. I’d give anything to see my own dad again."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:249
translate chinese MLR4_MS1_con_28111d05:

    # Dad "C’mon [player_name], sit and have a drink with me."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:250
translate chinese MLR4_MS1_con_a0591fe1:

    # MC "Bob, I-"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:252
translate chinese MLR4_MS1_con_0e509991_1:

    # Dad "Please. I don’t want it to be too late for me to at least make some amends."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:253
translate chinese MLR4_MS1_con_2d204a49_3:

    # MC "..."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:254
translate chinese MLR4_MS1_con_75b72af6_1:

    # Dad "Please..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:257
translate chinese MLR4_MS1_con_8e5b4149_1:

    # Dad "Thank you."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:258
translate chinese MLR4_MS1_con_a830f2b4_1:

    # Dad "*Sigh* I should’ve been present in your lives more. I should’ve sat down and played some video games with Sara. Maybe she wouldn’t have turned into such a recluse - gaming all by herself."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:259
translate chinese MLR4_MS1_con_72a6a439_1:

    # Dad "And Caroline... She always said she was fine, but I saw those bruises and heard her crying after her dates with that... fucking asshole."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:261
translate chinese MLR4_MS1_con_7e926879:

    # Dad "And you know what I did about it? Fucking nothing. Sure, you are just my tenants, but I HAD to do something... *Hic* I had some responsibility to act..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:262
translate chinese MLR4_MS1_con_1465ca99_1:

    # Dad "I was negligent. Detached. I figured if she said she was fine, then she could stand on her own two feet. I thought she would have come to me if she actually needed help."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:263
translate chinese MLR4_MS1_con_f86b8abb_1:

    # Dad "Caroline was always too proud to ask for it though. *Sigh* I shoulda known that."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:265
translate chinese MLR4_MS1_con_901e4a82:

    # Dad "And you... I should’ve been there to support you after *hic* all that shit you went through with that professor of yours. What was her name... Ms. Celia?"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:266
translate chinese MLR4_MS1_con_5e12fa6d:

    # MC "Bob, it’s okay. You didn’t have to-"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:267
translate chinese MLR4_MS1_con_1736ba5f:

    # Dad "No, I DID have to. It was my- *Sniff* It was my job to protect each and every one of you. And I failed, every fucking time."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:268
translate chinese MLR4_MS1_con_48782d80:

    # MC "Honestly Bob, it’s okay."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:271
translate chinese MLR4_MS1_con_53eb9db8_2:

    # "*Glug*"
    ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:273
translate chinese MLR4_MS1_con_53eb9db8_3:

    # "*Glug*"
    ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:275
translate chinese MLR4_MS1_con_324101b0_1:

    # Dad "Y’know... Maybe this place would be better without me in it? I’ve never been enough for Linda. I could never *Hic* fully satisfy her needs."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:276
translate chinese MLR4_MS1_con_b83339c4:

    # Dad "And you... You’re gonna look after Caroline and Sara when I’m gone. You understand that?"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:278
translate chinese MLR4_MS1_con_d517f39d:

    # MC "Y-Yeah, Bob. I got it."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:279
translate chinese MLR4_MS1_con_a3acd800_1:

    # Dad "B-Because you’re... You’re gonna be the *hic* man of the house now."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:280
translate chinese MLR4_MS1_con_e7963a06_1:

    # Dad "You need to step up, where I failed. You gotta... You gotta take care of Sara. Make shure... sure she doeshn’t lock herself away, gaming all the *hic* time."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:283
translate chinese MLR4_MS1_con_896269ca_3:

    # Dad "*Glug* *Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:285
translate chinese MLR4_MS1_con_5ac52b4c_1:

    # Dad "And you gotta keep an eye *Hic* on Caroline too. Protect her from that... fucking asshole. If she shays... *hic* says she’s fine, don’t listen to her. She’s... *hic* hiding what’s really wrong."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:287
translate chinese MLR4_MS1_con_6d01a29f_1:

    # Dad "Ohh, and Linda... You’re gonna take care of her when I’m gone."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:288
translate chinese MLR4_MS1_con_07b529f1:

    # MC "Bob... You don’t have to-"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:289
translate chinese MLR4_MS1_con_b68c2664_1:

    # Dad "You’re gonna make her happy. Okay? Promise me you’re gonna make her happy."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:290
translate chinese MLR4_MS1_con_49a521e9:

    # MC "...I’ll make her happy, Bob. I promise. I’ll take care of everyone."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:291
translate chinese MLR4_MS1_con_f957a1c1:

    # Dad "Thank you, [player_name]. That means... That means a lot. The household is in good hands."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:294
translate chinese MLR4_MS1_con_251b8ed4_3:

    # Dad "*Glug*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:296
translate chinese MLR4_MS1_con_10f7a572_1:

    # Dad "Zzz..."
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:297
translate chinese MLR4_MS1_con_7b7791d5:

    # MC "...Bob?"
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:298
translate chinese MLR4_MS1_con_e871c597_1:

    # Dad "*Snore*"
    Dad ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:300
translate chinese MLR4_MS1_con_214d3485:

    # MC "*Sigh* Goodnight, Bob."
    MC ""

# game/scripts/ML_R4/1_MLR4_MS1.rpy:302
translate chinese MLR4_MS1_con_7d0bad75_1:

    # MC "I’m... I’m sorry for everything. You didn’t deserve any of this."
    MC ""

translate chinese strings:

    # game/scripts/ML_R4/1_MLR4_MS1.rpy:68
    old "Try to leave before he notices you."
    new ""

    # game/scripts/ML_R4/1_MLR4_MS1.rpy:68
    old "Approach him and check how he’s doing."
    new ""

