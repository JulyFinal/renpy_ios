﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/9_MLR4_S9.rpy:250
translate chinese MLR4_S9_9089a6bc:

    # MC "(Alright... [Mom_name] told me to come over to her room tonight.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:251
translate chinese MLR4_S9_f62095c2:

    # MC " (I didn’t hear either of them arguing or fighting. That conversation she had with [Dad_name] must have gone well.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:253
translate chinese MLR4_S9_f010ddc6:

    # MC "Oh, sorry [Dad_name]. [Mom_name] told me to-"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:255
translate chinese MLR4_S9_55c5fdd3:

    # Bob "No need to apologise. C’mon in. Your mom’s just finishing getting dressed."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:257
translate chinese MLR4_S9_b970ea2a:

    # Bob "No need to apologise. C’mon in. Linda’s just finishing getting dressed."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:259
translate chinese MLR4_S9_b41c3ca9:

    # MC "You... uh... You seem a lot better than earlier."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:261
translate chinese MLR4_S9_5dbac0de:

    # Bob "Your mom and I talked things through."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:263
translate chinese MLR4_S9_c020fe28:

    # Bob "Linda and I talked things through. "
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:265
translate chinese MLR4_S9_8d3fbaa5:

    # Bob "It was tough at first, I’ll give you that. But we slowly got there."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:267
translate chinese MLR4_S9_092fc119:

    # Bob "The thing that hurt me the most wasn’t her cheating. Well, it did at the start. But when the pain of that started to pass, it was the idea of not getting to see my kids that truly hurt the most."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:269
translate chinese MLR4_S9_a650942c:

    # Bob "The thing that hurt me the most wasn’t her cheating. Well, it did at the start. But when the pain of that started to pass, it was the idea of not getting to see any of you that truly hurt the most. "
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:270
translate chinese MLR4_S9_ae082e55:

    # Bob "I can handle losing Linda. I couldn’t take losing you guys."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:272
translate chinese MLR4_S9_b93bc40c:

    # Bob "*Glug*"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:273
translate chinese MLR4_S9_1c84baab:

    # MC "I’m sorry, [Dad_name]. I never meant for you to get kicked out."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:275
translate chinese MLR4_S9_b93bc40c_1:

    # Bob "*Glug*"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:276
translate chinese MLR4_S9_c5ac0ad6:

    # Bob "It wasn’t your fault. Linda talked me through the timeline of what happened. Our marriage had been on the rocks LONG before you and her started."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:279
translate chinese MLR4_S9_2a2eb656:

    # Bob "Your mom’s letting me stay in the house. I’m getting a second chance to be a more present Dad to Sara and Caroline."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:281
translate chinese MLR4_S9_a4c2d8ad:

    # Bob "Linda is allowing me to stay in the house. I'm getting a second chance to be more present for all of you. I would truly miss that if I lost it, [player_name]."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:282
translate chinese MLR4_S9_29a5f4b2:

    # Bob "And to you, if you still want me involved in your life."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:284
translate chinese MLR4_S9_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:285
translate chinese MLR4_S9_62e48e16:

    # MC "What about Linda?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:287
translate chinese MLR4_S9_bc74f1e2:

    # Bob "She’s all yours, [player_name]."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:288
translate chinese MLR4_S9_17bd9598:

    # Bob "Just as long as I get to watch, every now and then."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:292
translate chinese MLR4_S9_e72be4a9:

    # Linda "Sorry to keep you waiting, Sweetie. Do you want something to drink?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:293
translate chinese MLR4_S9_26f85cd2:

    # MC "Oh, hey [Mom_name]! No, I’m good. Thanks."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:295
translate chinese MLR4_S9_6a005d84:

    # MC "[Dad_name] said he was... uh... going to be watching us?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:296
translate chinese MLR4_S9_23f3f19d:

    # Linda "Oh yeah, that was part of the agreement."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:298
translate chinese MLR4_S9_cd7b5c7c:

    # Linda "Don’t worry, Sweetie. He won’t be bothering us. I promise."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:299
translate chinese MLR4_S9_8d752f83:

    # Bob "Are you sure I can’t pour you a whiskey or something, [player_name]?"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:301
translate chinese MLR4_S9_ef121c35:

    # MC "N-No, I’m all good."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:302
translate chinese MLR4_S9_f4fc46af:

    # Linda "Try to relax for me. How about we take things over to the bed?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:303
translate chinese MLR4_S9_5f101baa:

    # MC "O-Okay!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:305
translate chinese MLR4_S9_4f411f76:

    # Linda "See? Much more comfy over here."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:306
translate chinese MLR4_S9_e463807b:

    # MC "Yeah, it is."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:308
translate chinese MLR4_S9_c4be3240:

    # Linda "And my, my... You’re rock hard already, aren’t you? I can see that big bulge in your underwear."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:310
translate chinese MLR4_S9_22844283:

    # MC "*Whispered* Is Bob okay?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:311
translate chinese MLR4_S9_4f73559c:

    # Linda "Don’t you worry about him. He’s perfectly fine."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:312
translate chinese MLR4_S9_fc1c281c:

    # Linda "Oh, before I forget, would you mind taking a couple of photos?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:313
translate chinese MLR4_S9_220d8b74:

    # MC "You’ve never asked for pictures before, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:315
translate chinese MLR4_S9_ed8410a1:

    # Bob "They’re for me. Just capture whatever you feel like. I’ll enjoy them later on."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:316
translate chinese MLR4_S9_876be997:

    # MC "Uh... Okay. Sure."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:322
translate chinese MLR4_S9_02a38f56:

    # "*Snap*"
    ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:326
translate chinese MLR4_S9_931d0d17:

    # Linda "(God, I can’t wait any longer!)"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:327
translate chinese MLR4_S9_a824b156:

    # Linda "Let’s get you out of these tight boxers."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:329
translate chinese MLR4_S9_6e3035ee:

    # MC "Mmm... "
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:330
translate chinese MLR4_S9_9d13bdd4:

    # Linda "Hehe! You’re so hard already!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:332
translate chinese MLR4_S9_41cc7977:

    # Linda "You and I are going to have A LOT of fun tonight. Oh, the things I’m going to do to you. Mmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:334
translate chinese MLR4_S9_8922f879:

    # MC "Where do you want to start? Blowjob? Cowgirl? Doggystyle?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:335
translate chinese MLR4_S9_6d1bf305:

    # Linda "We can-"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:337
translate chinese MLR4_S9_33442cd8:

    # Bob "How about you fuck her tits? Her tight top is perfect for it."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:339
translate chinese MLR4_S9_563da885:

    # Linda "I thought you said you weren’t going to be involved."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:340
translate chinese MLR4_S9_2811d166:

    # Bob "You did agree I could pick a couple of positions of my choosing. I want to see him fuck your tits."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:341
translate chinese MLR4_S9_9504a5d2:

    # Linda "*Sigh* I did. Alright, I guess we’re gonna kick things off with a titjob, then."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:342
translate chinese MLR4_S9_8fdb9444:

    # Bob "Thanks Linda. I know there’s still a few kinks in this agreement we’ll have to iron out, but I appreciate you working with me."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:344
translate chinese MLR4_S9_ac430fe7:

    # Linda "Okay, that’s me ready for you, [player_name]. Strip your shorts off and get over here."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:347
translate chinese MLR4_S9_2be626ca:

    # Bob "(God... She’s so fucking hot. I can’t wait to see my own son thrust his shaft between her tits.)"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:349
translate chinese MLR4_S9_7ff07c39:

    # Bob "(God... She’s so fucking hot. I can’t wait to see [player_name] thrust his shaft between her tits.) "
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:350
translate chinese MLR4_S9_02739bb0:

    # Bob "(I wonder if they did that when they went to that beach resort together. Linda mentioned they had a wonderful time...)"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:352
translate chinese MLR4_S9_d030b616:

    # Linda "*Whistle*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:353
translate chinese MLR4_S9_7c668926:

    # Linda "You’re looking good there!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:355
translate chinese MLR4_S9_52bfc050:

    # MC "Heh, thanks [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:357
translate chinese MLR4_S9_e7a4d2c2:

    # Bob "What’re you waiting for, champ? She’s all yours now."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:358
translate chinese MLR4_S9_db16de37:

    # Bob "I want to see you bury your dick between her cleavage."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:360
translate chinese MLR4_S9_b93bc40c_2:

    # Bob "*Glug*"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:361
translate chinese MLR4_S9_aad0ba07:

    # MC "(I still can’t tell if [Dad_name] is actually happy with this situation or not...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:363
translate chinese MLR4_S9_f364ecbe:

    # MC "([Mom_name] looks amazing in that outfit though. Her cleavage is perfect for a boobjob!)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:365
translate chinese MLR4_S9_205520f6:

    # Linda "Slide your cock under my bra. It’ll hold it in place while you thrust."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:367
translate chinese MLR4_S9_9eb80f16:

    # MC "(This is gonna feel amazing!)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:369
translate chinese MLR4_S9_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:370
translate chinese MLR4_S9_254693c1:

    # Linda "There we go. See? A snug fit!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:372
translate chinese MLR4_S9_e90354d3:

    # Linda "How does that feel now?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:374
translate chinese MLR4_S9_8068075a:

    # MC "Mmm... So good, [Mom_name]! Ooohh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:376
translate chinese MLR4_S9_484ed2bd:

    # Linda "Do you want me to move faster?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:377
translate chinese MLR4_S9_f1127e48:

    # MC "*Pant* Yeah! Ohh... That’s amazing, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:378
translate chinese MLR4_S9_65a02b5f:

    # Bob "That’s it... Fuck her tits."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:380
translate chinese MLR4_S9_6f604f9f:

    # MC "Mmm... Ohhh... *Pant* [Mom_name]!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:383
translate chinese MLR4_S9_e8785142:

    # Linda "Do you like that, Sweetie? Are you enjoying feeling your mommy’s big boobs squeezing your dick?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:385
translate chinese MLR4_S9_95f94840:

    # Linda "Do you like that, Sweetie? Are you enjoying feeling my big boobs squeezing your dick? "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:387
translate chinese MLR4_S9_f7176af3:

    # MC "Hnnng... Ohh... That feels amazing, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:388
translate chinese MLR4_S9_9bcfaa92:

    # Linda "Wow! You’re SO much bigger than Bob!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:391
translate chinese MLR4_S9_98c2276d:

    # Linda "Hehe! I can feel it throbbing now. You must be REALLY enjoying your mommy’s big tits."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:393
translate chinese MLR4_S9_a81a330a:

    # Linda "Hehe! I can feel it throbbing now. You must be REALLY enjoying your landlady’s big tits. "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:394
translate chinese MLR4_S9_f928ee94:

    # Bob "(That’s it... Keep fucking my wife’s breasts.)"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:396
translate chinese MLR4_S9_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:397
translate chinese MLR4_S9_a94811ae:

    # Linda "God, you’re so fucking hard, right now. I bet you want to cum all over my face, don’t you?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:399
translate chinese MLR4_S9_50d8f5f1:

    # MC "Hnnng... Oh yeah! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:401
translate chinese MLR4_S9_a0e9f5c2:

    # Linda "Well, I’m afraid you’re going to have to hold off a little longer. It’s FAR too early in the night for you to finish."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:403
translate chinese MLR4_S9_410a4de2:

    # MC "Heh, alright [Mom_name]. What do you want to do next?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:405
translate chinese MLR4_S9_72d91b73:

    # Linda "I can think of a couple of ways this could go."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:407
translate chinese MLR4_S9_db873c90:

    # MC "Oh yeah? How about we head over to the bed while you talk me through the options."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:409
translate chinese MLR4_S9_3bec45d7:

    # Linda "My first idea was having you sit back on the bed while I rub my bare soles all over your dick."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:411
translate chinese MLR4_S9_9c36cc03:

    # Linda "I bet you’d love that, wouldn’t you?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:413
translate chinese MLR4_S9_2070c1e2:

    # Linda "You’re already dripping precum at the thought of having your mommy stroke your cock with her feet. Aren’t you?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:415
translate chinese MLR4_S9_bc3de680:

    # Linda "You’re already dripping precum at the thought of having me stroke your cock with my feet. Aren’t you?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:417
translate chinese MLR4_S9_26d2948e:

    # Linda "Of course, there’s always the second option where I get down on my knees and take my sweetie's cock deep into my mouth."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:418
translate chinese MLR4_S9_7c4df7f9:

    # Linda "Can you imagine me sucking and licking your dick?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:420
translate chinese MLR4_S9_c74ed444:

    # Linda "Which would you prefer, [player_name]? Do you want me to get down on my knees and suck your cock?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:421
translate chinese MLR4_S9_22ac64bd:

    # Linda "Or would you rather I rubbed my feet all over your big, hard shaft?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:426
translate chinese MLR4_S9_8e9e4a8e:

    # MC "I want you to suck my cock, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:428
translate chinese MLR4_S9_083b3f3b:

    # Linda "Mmm, I can’t wait to feel your dick sliding into my mouth."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:430
translate chinese MLR4_S9_ae4d3fe2:

    # Linda "I still get just as excited as the first time I ever saw your dick."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:432
translate chinese MLR4_S9_7c295870:

    # Linda "Mmm... I love how firm your dick is. I’ve missed having a good, hard cock in my life for a long time."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:433
translate chinese MLR4_S9_e825a1e4:

    # MC "(This must be something Linda had discussed with Bob in advance. He isn’t reacting to her!)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:435
translate chinese MLR4_S9_570ef136:

    # Linda "You’re SOOO much bigger than my husband. And it feels sooo much more pleasurable when you slide inside me."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:436
translate chinese MLR4_S9_02e57a7a:

    # Linda "There really is no comparison. You’re better in every way."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:438
translate chinese MLR4_S9_39c34cc5:

    # Linda "*Suck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:440
translate chinese MLR4_S9_d63fedd6:

    # MC "Oohhh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:442
translate chinese MLR4_S9_5643e142:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:443
translate chinese MLR4_S9_209b58cf:

    # MC "*Pant* Hnnngg... Oohhh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:445
translate chinese MLR4_S9_fab2dd64:

    # Linda "Mmm! Mmmm..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:446
translate chinese MLR4_S9_effb465f:

    # MC "Ah... Oh... You’re great at that! Ohh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:447
translate chinese MLR4_S9_38462afa:

    # MC "*Pant* I want to feel you deepthroat my cock!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:449
translate chinese MLR4_S9_f8d9c875:

    # Linda "*Shlurp* *GAG* Mmppff!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:451
translate chinese MLR4_S9_07b0d50f:

    # MC "Ohhh! Fuuuck! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:453
translate chinese MLR4_S9_c00d007c:

    # MC "*Pant* Hnnng! Just like that, [Mom_name]! Ah!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:454
translate chinese MLR4_S9_5c29da78:

    # Linda "*Suck* *Gag* *Shluuurrrp*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:455
translate chinese MLR4_S9_33cf37dd:

    # MC "Arrghh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:457
translate chinese MLR4_S9_47aff82e:

    # MC "Oh! *Pant*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:459
translate chinese MLR4_S9_c8874821:

    # Linda "Mmmmm! *Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:461
translate chinese MLR4_S9_ec1ef0f1:

    # MC "Hnnnggg! Argh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:462
translate chinese MLR4_S9_b02c9097:

    # Linda "*Shlurp*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:464
translate chinese MLR4_S9_62417820:

    # Linda "*Suck* *Suck* *Shlurrrp* Mmmff!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:465
translate chinese MLR4_S9_646673b7:

    # MC "Oh! Mmm! Yes, [Mom_name]! Don’t stop! Ahh! God, you’re such a great cocksucker!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:467
translate chinese MLR4_S9_60497ccb:

    # MC "(He’s just... watching us.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:468
translate chinese MLR4_S9_958c7d1c:

    # MC "(Is he angry? Sad? Impressed? I can’t tell... It’s impossible to read his expression.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:470
translate chinese MLR4_S9_e0e415ee:

    # Linda "*Shlurp* *Suuuck* *Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:472
translate chinese MLR4_S9_70eac9f9:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:474
translate chinese MLR4_S9_c2481aef:

    # Linda "*Glompf* *Gag* *Suuuuucck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:475
translate chinese MLR4_S9_21cc946b:

    # MC "HNNNGG! Oh! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:477
translate chinese MLR4_S9_d9323a99:

    # MC "*Pant* Yes! Just like that, [Mom_name]! Don’t stop! Arrghhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:478
translate chinese MLR4_S9_4c2c8ef7:

    # Linda "*SHLURP* *SUCK* *SUCK*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:480
translate chinese MLR4_S9_c4a5ffc2:

    # Linda "*Shlurp* *Suck* *Shlurp* *Gag*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:481
translate chinese MLR4_S9_631588c9:

    # MC "Ah! Ahhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:483
translate chinese MLR4_S9_174fe812:

    # MC "Shit! I’m gonna cum! Hnnngg!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:484
translate chinese MLR4_S9_5643e142_1:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:486
translate chinese MLR4_S9_c3008faa:

    # Linda "Nope, not yet, Sweetie. I haven’t had MY fun yet."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:487
translate chinese MLR4_S9_7c1615dd:

    # MC "*Pant* *Pant* You’ve REALLY got to stop blue-balling me at the last second!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:488
translate chinese MLR4_S9_7fc1bbff:

    # Linda "And you’ve got to learn some self-control! Hehe!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:494
translate chinese MLR4_S9_2129684e:

    # MC "I want you to use your feet tonight, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:496
translate chinese MLR4_S9_3e885ab9:

    # Linda "Of course, Sweetie."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:499
translate chinese MLR4_S9_61162921:

    # Linda "I know how much you love feeling your mommy’s feet rubbing your cock."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:501
translate chinese MLR4_S9_a9eb68e1:

    # Linda "I know how much you love feeling my feet rubbing your cock. "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:502
translate chinese MLR4_S9_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:504
translate chinese MLR4_S9_7e8f0b70:

    # Linda "I bet that feels REALLY good, doesn't it? Can you feel my toes curling over your glans?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:505
translate chinese MLR4_S9_bf1474cd:

    # MC "*Pant* Yes... Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:508
translate chinese MLR4_S9_11af92e1:

    # Linda "Oh wow... You’re so hard right now. That’s it. Moan for your mommy while she strokes your big cock."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:510
translate chinese MLR4_S9_8801b457:

    # Linda "Oh wow... You’re so hard right now. That’s it. Moan for me while I stroke your big cock. "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:511
translate chinese MLR4_S9_d8d9d8a3:

    # MC "*Pant* Mmm! Ohhh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:513
translate chinese MLR4_S9_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:514
translate chinese MLR4_S9_372c4792:

    # Linda "Oh my, that was quite the reaction! Looks like I found your weak spot."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:516
translate chinese MLR4_S9_e2b522d0:

    # Linda "You’re extra sensitive here, aren’t you?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:517
translate chinese MLR4_S9_47d0d9b1:

    # MC "Oh... Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:519
translate chinese MLR4_S9_9857c652:

    # Linda "How would you like me to use both my feet at the same time?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:520
translate chinese MLR4_S9_28bdfadb:

    # MC "Oh! Yes! *Gasp* Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:523
translate chinese MLR4_S9_d0a145b6:

    # Linda "Well Bob? Are you enjoying watching your wife rub her feet all over your son’s big dick?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:525
translate chinese MLR4_S9_7c239e25:

    # Linda "Well Bob? Are you enjoying watching your wife rub her feet all over someone else’s big dick? "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:526
translate chinese MLR4_S9_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:528
translate chinese MLR4_S9_8e0a384d:

    # Linda "Mmm, I bet you are."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:529
translate chinese MLR4_S9_551a7841:

    # MC "(I don’t quite get what [Dad_name]’s getting out of this...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:531
translate chinese MLR4_S9_bb05da0a:

    # MC "Hnng... Oh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:533
translate chinese MLR4_S9_b6e29980:

    # Linda "Keep moaning for me, Sweetie."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:536
translate chinese MLR4_S9_27cc4d5c:

    # Linda "Keep moaning while mommy rubs your cock between her soles."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:538
translate chinese MLR4_S9_097c290f:

    # Linda "Keep moaning while I rub your cock between my soft soles. "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:539
translate chinese MLR4_S9_67f2fd33:

    # MC "Mmm... Ohhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:541
translate chinese MLR4_S9_8c7856db:

    # MC "It feels so good, [Mom_name]! *Pant*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:543
translate chinese MLR4_S9_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:545
translate chinese MLR4_S9_3c755ef9:

    # MC "Hnnngg..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:546
translate chinese MLR4_S9_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:548
translate chinese MLR4_S9_7756e86d:

    # Linda "Are you close to cumming?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:549
translate chinese MLR4_S9_d82a35fd:

    # MC "*Pant* I’m getting there!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:551
translate chinese MLR4_S9_22751478:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:553
translate chinese MLR4_S9_e4dc4fde:

    # MC "*Pant* Oh! Ah! Mmmm! [Mom_name]!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:555
translate chinese MLR4_S9_6137be2f:

    # Linda "Tell me when you’re about to finish."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:556
translate chinese MLR4_S9_1f3aa65b:

    # MC "*Pant* I’m... I’m getting ugh... close!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:558
translate chinese MLR4_S9_47145a89:

    # MC "Hnnng! Oh God! [Mom_name]! I’m gonna-"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:560
translate chinese MLR4_S9_631588c9_1:

    # MC "Ah! Ahhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:562
translate chinese MLR4_S9_82b78d91:

    # MC "Fuck! You’re gonna make me cum! I’m-"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:564
translate chinese MLR4_S9_60fefe30:

    # Linda "Ah, ah! Not yet."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:565
translate chinese MLR4_S9_35b1008a:

    # MC "*Pant* Wh-What?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:567
translate chinese MLR4_S9_3e1935a9:

    # Linda "I’ve got a long night planned for us. I can’t have you blowing your load TOO early."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:573
translate chinese MLR4_MS9_con_04bce155:

    # Linda "Tell me, Bob. Have you been enjoying the little show we’ve put on for you?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:574
translate chinese MLR4_MS9_con_3531f012:

    # Linda "Wait. Don’t bother answering. I can already see your stiff little erection."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:576
translate chinese MLR4_MS9_con_2ae62805:

    # Linda "This is what you wanted all along, isn’t it, Bob? The forbidden desire that you repressed for so long."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:577
translate chinese MLR4_MS9_con_03110c3b:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:578
translate chinese MLR4_MS9_con_69c491e5:

    # Linda "The difference between you and me Bob, is that I acted on my desires."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:580
translate chinese MLR4_MS9_con_30bfd644:

    # Linda "It’s quite ironic actually. You wouldn’t be able to experience your own repressed desire of being a cuck, if I hadn’t started fucking [player_name]."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:581
translate chinese MLR4_MS9_con_e1c2c0bb:

    # Linda "It’s funny how the stars align sometimes."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:583
translate chinese MLR4_MS9_con_6f26f225:

    # Linda "I want you to watch me, Bob."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:584
translate chinese MLR4_MS9_con_f03f50c2:

    # Linda "Don’t you dare take your eyes off us, even for a second."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:587
translate chinese MLR4_MS9_con_bdc27963:

    # Linda "I want you to see the moment when your wife begins riding your own son."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:589
translate chinese MLR4_MS9_con_b879c49a:

    # Linda "I want you to see the moment when your wife begins riding this young stud in front of you. "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:590
translate chinese MLR4_MS9_con_8b852c85:

    # Linda "This pussy used to be only yours Bob. Now it belongs to him. How does that make you feel?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:591
translate chinese MLR4_MS9_con_fbd06619:

    # Bob "Linda, I-"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:593
translate chinese MLR4_MS9_con_e5278f19:

    # Linda "Ah! Oh God! He’s so much bigger than you, Bob! Mmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:594
translate chinese MLR4_MS9_con_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:596
translate chinese MLR4_MS9_con_251c831e:

    # Linda "Ah! Ahh! Yes!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:598
translate chinese MLR4_MS9_con_34a59dd4:

    # MC "Oh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:599
translate chinese MLR4_MS9_con_194c1dc5:

    # Linda "Watch me, Bob! Watch your wife get her brains fucked out! Ah! AHHH!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:601
translate chinese MLR4_MS9_con_3bf05ca6:

    # Linda "Oh God! Ah! Ohhhh! Mmmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:602
translate chinese MLR4_MS9_con_1e7db88d:

    # MC "Hnnng! *Pant*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:603
translate chinese MLR4_MS9_con_03110c3b_1:

    # Bob "..."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:605
translate chinese MLR4_MS9_con_d1dedf91:

    # Linda "Ah! Yes! Yes! God! I love riding your cock!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:606
translate chinese MLR4_MS9_con_0ee522ed:

    # MC "Oh! Hnnng! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:608
translate chinese MLR4_MS9_con_90db3f19:

    # Linda "Ah! AHHHH! Ohhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:610
translate chinese MLR4_MS9_con_2d1feb5a:

    # MC "*Pant* Mmm! OhH!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:612
translate chinese MLR4_MS9_con_9ac90ee0:

    # Linda " Oh God! I’m cumming! I’m cummmmiiinng! AHAAHHHHH!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:613
translate chinese MLR4_MS9_con_34d6b634:

    # Bob "... *Gulp*"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:615
translate chinese MLR4_MS9_con_a78e2cb0:

    # Linda "AH! Your son is making me cum so fucking hard, Bob!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:617
translate chinese MLR4_MS9_con_cdd4d27e:

    # Linda "AH! He’s making me cum so fucking hard, Bob! "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:619
translate chinese MLR4_MS9_con_eba6b33d:

    # Linda "Ohhh! How does it feel knowing he - *Pant* - is a better ahh... lover than you EVER were?! Mmmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:621
translate chinese MLR4_MS9_con_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:623
translate chinese MLR4_MS9_con_2689a134:

    # Linda "Oh wow! Mmm! *Pant* Ohhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:624
translate chinese MLR4_MS9_con_f11651ef:

    # MC "Yes! Ahh! Don’t stop, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:626
translate chinese MLR4_MS9_con_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:627
translate chinese MLR4_MS9_con_5bf95a0e:

    # Linda "AH! AH! AHHHH!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:629
translate chinese MLR4_MS9_con_d43751f8:

    # MC "Hnnngg! Ohhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:631
translate chinese MLR4_MS9_con_65cd7402:

    # Linda "AH! Ohhh! God! YES! MMMMM!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:632
translate chinese MLR4_MS9_con_e38a264a:

    # MC "*Pant* Oh! [Mom_name]!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:634
translate chinese MLR4_MS9_con_9366b096:

    # Linda "Ah! Ah! Ah! AH! AHHH! AHHHHHHHH!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:635
translate chinese MLR4_MS9_con_6c6298d2_1:

    # MC "Arrghhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:636
translate chinese MLR4_MS9_con_602c3984:

    # Linda "I’M CUMMMIINNNGG! AYAAAHHHHH!!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:638
translate chinese MLR4_MS9_con_e0b34db9:

    # Bob "Heh... Nice..."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:640
translate chinese MLR4_MS9_con_aace0454:

    # Linda "How about we get a photo to celebrate this new beginning, Bob?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:642
translate chinese MLR4_MS9_con_0d8ec07f:

    # Bob "Sure, why not?"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:644
translate chinese MLR4_MS9_con_9697d52b:

    # Linda "Strip off. Get on your knees. [player_name] - would you kindly take the picture?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:645
translate chinese MLR4_MS9_con_657e74df:

    # MC "Sure, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:647
translate chinese MLR4_MS9_con_6a17bd40:

    # Linda "Well? Is your fantasy as good as you imagined it would be?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:649
translate chinese MLR4_MS9_con_7134f3a0:

    # Linda "I know mine certainly was. I’ve loved every single second of kissing, sucking and fucking my own son."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:651
translate chinese MLR4_MS9_con_f012aaa6:

    # Linda "I know mine certainly was. I've loved every single second of kissing, sucking, and fucking [player_name]. Being married, as your wife, didn't stop me at all! I'm such a whore, Bob!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:653
translate chinese MLR4_MS9_con_8630cc07:

    # Bob "It’s... incredible, Linda."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:654
translate chinese MLR4_MS9_con_75bc9dd6:

    # Bob "I love watching him fuck you... I get so fucking hard every time he makes you cum."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:657
translate chinese MLR4_MS9_con_a9a5b035:

    # MC "(Yikes... What kind of deranged family was I born into?)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:659
translate chinese MLR4_MS9_con_b50fe46a:

    # MC "(Yikes... What kind of deranged couple am I renting a room from?!) "
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:661
translate chinese MLR4_MS9_con_425a42fb:

    # Linda "Have you got your phone ready, Sweetie?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:662
translate chinese MLR4_MS9_con_bc36a5aa:

    # MC "Uh, yeah..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:663
translate chinese MLR4_MS9_con_4a3f8246:

    # Linda "C’mon Bob, smile for the camera like the good little cuck that you are."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:669
translate chinese MLR4_MS9_con_67da5022:

    # MC "Alright, there we go."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:670
translate chinese MLR4_MS9_con_12fbe702:

    # Linda "How does it look?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:672
translate chinese MLR4_MS9_con_d9578210:

    # MC "It’s... uh... It’s probably my least favourite image on my phone right now..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:673
translate chinese MLR4_MS9_con_9033c0aa:

    # Bob "Just send it to me and you can delete it after."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:675
translate chinese MLR4_MS9_con_57f93be7:

    # Linda "Thanks for indulging me in my fantasy, Sweetie."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:677
translate chinese MLR4_MS9_con_b714466d:

    # Linda "And for accommodating your father too. I appreciate that this hasn’t been easy for any of us."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:679
translate chinese MLR4_MS9_con_60096c7b:

    # Linda "And for accommodating Bob too. I appreciate that this hasn’t been easy for any of us."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:680
translate chinese MLR4_MS9_con_0d0a07bc:

    # Bob "Yeah, thanks champ."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:684
translate chinese MLR4_MS9_con_48ee5035:

    # Linda "Oh, I almost forgot... we never finished that boobjob earlier, did we?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:685
translate chinese MLR4_MS9_con_e53b6b58:

    # Linda "How would you like to fuck your mommy’s tits now?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:687
translate chinese MLR4_MS9_con_48ee5035_1:

    # Linda "Oh, I almost forgot... we never finished that boobjob earlier, did we?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:689
translate chinese MLR4_MS9_con_6c20d05d:

    # Linda "I’ll lie back on the bed, and you can thrust into my massive mammaries until you cum all over my face."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:690
translate chinese MLR4_MS9_con_023821ca:

    # Linda "Would you like that?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:692
translate chinese MLR4_MS9_con_1ef70c73:

    # MC "Absolutely! Hurry up and get your ass onto bed!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:694
translate chinese MLR4_MS9_con_f9d3cb22:

    # MC "Squeeze your tits together for me, [Mom_name]. "
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:695
translate chinese MLR4_MS9_con_d0a550ed:

    # Linda "How’s this?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:696
translate chinese MLR4_MS9_con_91f4cf9c:

    # MC "Little bit tighter..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:698
translate chinese MLR4_MS9_con_228847df:

    # Linda "What about now?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:699
translate chinese MLR4_MS9_con_75715e4e:

    # MC "Perfect."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:701
translate chinese MLR4_MS9_con_ad9443f8:

    # MC "*Pant* Mmm... Ohh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:702
translate chinese MLR4_MS9_con_41de921a:

    # Linda "Go on. Thrust your cock deep into my cleavage."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:704
translate chinese MLR4_MS9_con_aefc7e55:

    # MC "Hnng... Ah..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:707
translate chinese MLR4_MS9_con_36ba7845:

    # Linda "That’s it, Sweetie. Just keep fucking your mommy’s tits."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:709
translate chinese MLR4_MS9_con_afcc86d6:

    # Linda "That’s it, Sweetie. Just keep fucking my breasts!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:711
translate chinese MLR4_MS9_con_ce69c786:

    # MC "Oh! Ah..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:713
translate chinese MLR4_MS9_con_547820ae:

    # MC "Ah... Ah... Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:715
translate chinese MLR4_MS9_con_260ddd79:

    # Linda "Mmm, I love listening to you moan, each time you thrust."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:717
translate chinese MLR4_MS9_con_aefc7e55_1:

    # MC "Hnng... Ah..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:721
translate chinese MLR4_MS9_con_d36daa92:

    # Linda "Tell me, Sweetie. Are you going to cum all over your mom’s face?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:723
translate chinese MLR4_MS9_con_f07b5c4f:

    # Linda "Tell me, Sweetie. Are you going to cum all over my face? "
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:724
translate chinese MLR4_MS9_con_47ed520c:

    # MC "*Pant* Hnng!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:725
translate chinese MLR4_MS9_con_17eca0f6:

    # Linda "I bet you are. Go on. Do it. Cum for me."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:727
translate chinese MLR4_MS9_con_07344093:

    # Linda "I want to feel your rock hard cock pulsating between my breasts."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:728
translate chinese MLR4_MS9_con_ce69c786_1:

    # MC "Oh! Ah..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:730
translate chinese MLR4_MS9_con_8c3048ac:

    # Linda "I need to feel your hot semen splashing over my face."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:731
translate chinese MLR4_MS9_con_77fca77a:

    # MC "Hnnngg! *Pant* Ah!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:733
translate chinese MLR4_MS9_con_6398b6c1:

    # Linda "That’s it, Sweetie! Cum for me! Cum all over my face!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:735
translate chinese MLR4_MS9_con_6b4d47ad:

    # MC "HNNNGG! Arrghghhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:737
translate chinese MLR4_MS9_con_547820ae_1:

    # MC "Ah... Ah... Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:740
translate chinese MLR4_MS9_con_dcedcbff:

    # Linda "Mmmm! Yes! Let mommy’s big breasts drain your balls dry! Cum for me!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:742
translate chinese MLR4_MS9_con_7935d0d2:

    # Linda "Mmmm! Yes! Let my big breasts drain your balls dry! Cum for me!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:743
translate chinese MLR4_MS9_con_13fa9efb:

    # MC "ARRGHHH! HNNNGGG! OHHHH!!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:752
translate chinese MLR4_MS9_con_9a0debb4:

    # MC "*Pant* Oh... Fuck! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:753
translate chinese MLR4_MS9_con_17c08427:

    # Linda " Mmm! That’s it. Give me every last drop."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:755
translate chinese MLR4_MS9_con_f3be9950:

    # MC "*Pant* *Pant* That was fucking amazing, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:756
translate chinese MLR4_MS9_con_b93bc40c:

    # Bob "*Glug*"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:757
translate chinese MLR4_MS9_con_d6f046a0:

    # Linda "Hehe, I’m glad you liked it. I just need to get a tissue for my face. Hold on a minute."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:759
translate chinese MLR4_MS9_con_a2c0961f:

    # Linda "There we go. All wiped off."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:760
translate chinese MLR4_MS9_con_3e83dbb1:

    # Linda "Well, do you think you have the energy for a second round? I was REALLY hoping you’d fuck my pussy tonight as well."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:762
translate chinese MLR4_MS9_con_eff44b68:

    # MC "Yeah! I’m still hard, aren’t I?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:763
translate chinese MLR4_MS9_con_d5a02d5d:

    # Bob "Heh, that’s my boy."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:765
translate chinese MLR4_MS9_con_ff623910:

    # MC "(I wonder if I should talk with [Dad_name], before I fuck [Mom_name] right in front of him...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:766
translate chinese MLR4_MS9_con_0750730e:

    # MC "(If he’s going to be moving back in under some kind of new arrangement, then I should probably clear the air and apologise.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:771
translate chinese MLR4_MS9_con_9ffcb033:

    # MC "Hey [Dad_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:772
translate chinese MLR4_MS9_con_0995b860:

    # Bob "Alright, champ. You having a good night?"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:774
translate chinese MLR4_MS9_con_c27c6c12:

    # MC "I... uh... I wanted to apologise for everything that happened."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:775
translate chinese MLR4_MS9_con_a02874ba:

    # Bob "Pfft! Don’t sweat it. Water under the bridge."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:777
translate chinese MLR4_MS9_con_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:778
translate chinese MLR4_MS9_con_b9b774fa:

    # MC "I don’t think it’s that simple, [Dad_name]. I owe you a proper apology for what happened with [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:780
translate chinese MLR4_MS9_con_c352af8e:

    # Bob "[player_name], you don’t-"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:781
translate chinese MLR4_MS9_con_19ba1205:

    # MC "Just because it turned out you’ve got a fetish for seeing your wife fucked doesn’t mean any of this was fair to you."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:783
translate chinese MLR4_MS9_con_682d47f8:

    # MC " I mean, I saw how you broke down when you thought you’d never see Caroline and Sara again. I know those two mean the world to you."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:784
translate chinese MLR4_MS9_con_f5e53db6:

    # MC "Heck... You even said you’d miss me - after everything I did to you."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:787
translate chinese MLR4_MS9_con_b4d774c6:

    # MC "You’re a good dad, Bob. You’ve always been a far better dad than I deserved."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:789
translate chinese MLR4_MS9_con_0e687698:

    # MC "You’re a good man, Bob. You've always been a far better father-like figure than I deserve."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:790
translate chinese MLR4_MS9_con_958c35a4:

    # MC "Heck... Any other man I know would have probably beaten my ass for everything Linda and I did to you."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:792
translate chinese MLR4_MS9_con_b93bc40c_1:

    # Bob "*Glug*"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:793
translate chinese MLR4_MS9_con_e60f45e4:

    # MC "I’m just... I’m just trying to say I appreciate you being around. You’ve been busy with work a lot, but you’ve always been there when I needed some advice."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:795
translate chinese MLR4_MS9_con_23c6100f:

    # Bob "Thanks, champ."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:796
translate chinese MLR4_MS9_con_c8b75a7b:

    # Bob "Here... take a drink. It’s an expensive one. You’ll like it. I’ve been saving it for a special occasion."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:798
translate chinese MLR4_MS9_con_4e4023a5:

    # Bob "The trick is to sniff the whiskey before you take it in your mouth. It really allows the flavour to develop on your palate."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:800
translate chinese MLR4_MS9_con_72a08610:

    # MC "Thanks, [Dad_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:802
translate chinese MLR4_MS9_con_107a0941:

    # Linda "(And... it looks like they’ve forgotten about me...)"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:804
translate chinese MLR4_MS9_con_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:805
translate chinese MLR4_MS9_con_ffee5174:

    # Bob "Well? What do you think?"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:806
translate chinese MLR4_MS9_con_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:808
translate chinese MLR4_MS9_con_625e8f6a:

    # MC "It’s *Cough* a little bit strong."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:809
translate chinese MLR4_MS9_con_a9346888:

    # Bob "Heh! Takes some getting used to. But that’s a drink that’ll put some actual hair on your chest, champ!"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:812
translate chinese MLR4_MS9_con_323fbe7d:

    # Bob "How about I take you over to Scotland next summer? Just you and me. We’ll do a father-son road trip round the coast and hit up the local distilleries."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:814
translate chinese MLR4_MS9_con_86df71f3:

    # Bob "How about I take you over to Scotland next summer? Just you and me. We’ll do a father-son-style road trip around the coast and hit up the local distilleries. I know I’m not your dad, but what do you say we give it a go?"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:815
translate chinese MLR4_MS9_con_ce3b5f7d:

    # MC "I’d like that, [Dad_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:816
translate chinese MLR4_MS9_con_f18d9c4a:

    # Bob "We’ll get you a proper expensive bottle to kick off your own whiskey collection. Perhaps we can pick up a couple of Scottish girls too on the way?"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:818
translate chinese MLR4_MS9_con_5134f5dc:

    # Linda "Hellllloooo?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:819
translate chinese MLR4_MS9_con_1aaeb6cc:

    # MC "Yeah! And we could rent a fancy car to travel round the coast! Something fast and sporty!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:820
translate chinese MLR4_MS9_con_6fba70ff:

    # Bob "Great idea! Maybe even do Ireland too if we’ve got time!"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:822
translate chinese MLR4_MS9_con_23551cce:

    # Linda "*Ahem* *Cough*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:823
translate chinese MLR4_MS9_con_8823dc4c:

    # MC "Sure! I’d love that!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:824
translate chinese MLR4_MS9_con_d65dbdc1:

    # Linda "There is a naked woman in the room waiting to be fucked!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:826
translate chinese MLR4_MS9_con_10c73fcf:

    # MC "Oh! Sorry, [Mom_name]! Forgot you were there."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:827
translate chinese MLR4_MS9_con_377f15d9:

    # Linda "Uh huh."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:830
translate chinese MLR4_MS9_con_570c4ba3:

    # Bob "You better go and tend to your Mom, champ. Thanks again for the apology. I appreciate it."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:832
translate chinese MLR4_MS9_con_01ff3e87:

    # Bob "You better go and tend to Linda, champ. Thanks again for the apology. I appreciate it."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:833
translate chinese MLR4_MS9_con_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:834
translate chinese MLR4_MS9_con_561d0d06:

    # MC "I love you, [Dad_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:836
translate chinese MLR4_MS9_con_bc1c23c0:

    # Bob "I love you too, son."
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:838
translate chinese MLR4_MS9_con_57a5a529:

    # Bob "I love you too, [player_name]. "
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:840
translate chinese MLR4_MS9_con_0951e06a:

    # Bob "Go and get her!"
    Bob ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:841
translate chinese MLR4_MS9_con_d3cb5541:

    # Linda "Ugh! FINALLY!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:847
translate chinese MLR4_MS9_con_4d4561d1:

    # MC "(I’ll talk to [Dad_name] later. He’s clearly enjoying this, right now - and I don’t want to risk killing the mood with [Mom_name].)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:853
translate chinese MLR4_MS9_con2_716f34f6:

    # Linda "Ah! Yes! Put it inside me!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:854
translate chinese MLR4_MS9_con2_9a554c15:

    # MC "Ohh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:856
translate chinese MLR4_MS9_con2_9d2b76c4:

    # MC "Hnnng... Mmm! God, your pussy is so hot, [Mom_name]! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:857
translate chinese MLR4_MS9_con2_02eede3a:

    # Linda "Ahhh... Oooooohhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:859
translate chinese MLR4_MS9_con2_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:860
translate chinese MLR4_MS9_con2_ab7a7700:

    # Linda "Aayaaahhhhhh!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:862
translate chinese MLR4_MS9_con2_b8778302:

    # Linda "Oh God... Mmmm! Your cock is soooo goooood! *Pant* Ahhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:863
translate chinese MLR4_MS9_con2_f06e1074:

    # MC "Hnnng! Argh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:865
translate chinese MLR4_MS9_con2_df2f138b:

    # Linda "*Gasp* You’re so deep inside me! Ayaahhhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:867
translate chinese MLR4_MS9_con2_df937636:

    # MC "*Pant* Ohh! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:869
translate chinese MLR4_MS9_con2_6560984c:

    # Linda "Ahhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:871
translate chinese MLR4_MS9_con2_46ce16e2:

    # Linda "Ah! AHHHHH!! Ohhh my God! Yes! Mmmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:873
translate chinese MLR4_MS9_con2_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:875
translate chinese MLR4_MS9_con2_6560984c_1:

    # Linda "Ahhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:877
translate chinese MLR4_MS9_con2_3ca8d5dd:

    # Linda "Yes! Fuck me! Ah! Ahh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:879
translate chinese MLR4_MS9_con2_890d50aa:

    # MC "Ugh! Ohh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:881
translate chinese MLR4_MS9_con2_6560984c_2:

    # Linda "Ahhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:883
translate chinese MLR4_MS9_con2_750f23b5:

    # MC "*Pant* I love you, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:884
translate chinese MLR4_MS9_con2_083d0d52:

    # Linda "Ah! Ah"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:886
translate chinese MLR4_MS9_con2_2c315e86:

    # Linda "I love you too, [player_name]! Ah! AHHHH!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:887
translate chinese MLR4_MS9_con2_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:889
translate chinese MLR4_MS9_con2_cb9d8863:

    # Linda "Ayaahhh! I’m cumming again! AAHHHH!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:890
translate chinese MLR4_MS9_con2_a9cf0e5b:

    # MC "HNNNG! OHHHH!!!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:891
translate chinese MLR4_MS9_con2_b1e10249:

    # Linda "Choke me!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:892
translate chinese MLR4_MS9_con2_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:893
translate chinese MLR4_MS9_con2_48615c41:

    # Linda "*Gasp* Put your hand on my throat and choke me!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:895
translate chinese MLR4_MS9_con2_af501839:

    # Linda "Ohhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:896
translate chinese MLR4_MS9_con2_d7a00417:

    # MC "*Pant* Hnnggg!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:898
translate chinese MLR4_MS9_con2_e1aec92b:

    # Linda "*Gasp* Yes! Ohh! Yesss!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:899
translate chinese MLR4_MS9_con2_b6c8e8cc:

    # MC "Ah! Ah! Arrghhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:900
translate chinese MLR4_MS9_con2_0957fa54:

    # Linda "H-Harder! Ah! Ahh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:902
translate chinese MLR4_MS9_con2_c39c3bec:

    # MC "Hnnngg! Ohhh! *Pant* Arrghh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:903
translate chinese MLR4_MS9_con2_0eeeba33:

    # Linda "Yesss! *Gasp* Ahhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:904
translate chinese MLR4_MS9_con2_84f919f6:

    # MC "Okay, go facedown on the bed, [Mom_name]. I’ll fuck you from behind."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:906
translate chinese MLR4_MS9_con2_88a1683a:

    # Linda "*Gasp* Yes! Oh! Ah!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:907
translate chinese MLR4_MS9_con2_decbbc65:

    # MC "Hnng! Argh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:909
translate chinese MLR4_MS9_con2_a5a35a07:

    # Linda "Ah! God! Your dick is huge! *Pant* Ahh"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:910
translate chinese MLR4_MS9_con2_3cc57223:

    # Linda "AH! AH! AH!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:912
translate chinese MLR4_MS9_con2_2a872d7f:

    # Linda "AYAAHHHH! I’M CUMMMMIIINNNG!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:914
translate chinese MLR4_MS9_con2_38326d04:

    # Linda "OHHHHH!!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:916
translate chinese MLR4_MS9_con2_decbbc65_1:

    # MC "Hnng! Argh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:918
translate chinese MLR4_MS9_con2_0023df4d:

    # Linda "Haaaahhhhh.... *Pant* Ohhhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:919
translate chinese MLR4_MS9_con2_9613a71d:

    # MC "Arrghh! Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:920
translate chinese MLR4_MS9_con2_e17eb489:

    # Linda "*Gasp*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:922
translate chinese MLR4_MS9_con2_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:925
translate chinese MLR4_MS9_con2_2e825243:

    # Linda "AHH! Oh God! Yes! Ohhhh! Fuck me, [player_name]! Pound your mommy’s pussy! Aahahhhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:927
translate chinese MLR4_MS9_con2_df0a3b86:

    # Linda "AHH! Oh God! Yes! Ohhhh! Fuck me, [player_name]! Pound your landlady’s pussy! Aahahhhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:929
translate chinese MLR4_MS9_con2_0957fa54_1:

    # Linda "H-Harder! Ah! Ahh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:931
translate chinese MLR4_MS9_con2_1d63bea3:

    # MC "UGH!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:932
translate chinese MLR4_MS9_con2_c23fff52:

    # Linda "OOHHH!H AAAHHHHHHHH!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:934
translate chinese MLR4_MS9_con2_2b437c72:

    # MC "*Pant* Ugh! Ohhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:935
translate chinese MLR4_MS9_con2_a14f1963:

    # Linda "Yessss! Ahhhh! Wreck my pussy with your big dick! Ohhhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:937
translate chinese MLR4_MS9_con2_f31e6fe7:

    # Linda "AH! AHHHHHHHH!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:939
translate chinese MLR4_MS9_con2_be26e7a7:

    # MC "Hnnng! *Pant* Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:941
translate chinese MLR4_MS9_con2_88a1683a_1:

    # Linda "*Gasp* Yes! Oh! Ah!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:943
translate chinese MLR4_MS9_con2_14d23a73:

    # Linda "Ohhh God! Mmmm! Yesss!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:945
translate chinese MLR4_MS9_con2_05a4aa5e:

    # Linda "*Pant* Ahhhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:947
translate chinese MLR4_MS9_con2_9613a71d_1:

    # MC "Arrghh! Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:949
translate chinese MLR4_MS9_con2_da7095f8:

    # Linda "*Pant* You’re enjoying this *Gasp* Bob, aren’t you? Oh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:950
translate chinese MLR4_MS9_con2_e33ef03c:

    # Linda "Ah! You love seeing your wife fucked senseless, right in front of you? Ah!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:952
translate chinese MLR4_MS9_con2_6d873ccf:

    # Linda "Ah! AHhh! How does it ohh... feel, knowing he’s making me aahh... cum harder than you ever mmm... could, Bob?! OHHHH!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:953
translate chinese MLR4_MS9_con2_6ab31951_1:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:954
translate chinese MLR4_MS9_con2_2d805288:

    # Linda "*Pant* I’ll climb on top now, Sweetie!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:956
translate chinese MLR4_MS9_con2_9662bb81:

    # MC "Ohh! [Mom_name]! Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:958
translate chinese MLR4_MS9_con2_5c14ca96:

    # Linda "Ah! Ahh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:959
translate chinese MLR4_MS9_con2_780cd4fb:

    # MC "Hnnng! Ohh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:961
translate chinese MLR4_MS9_con2_ea60bda6:

    # Linda "That’s it. Moan for me, [player_name]! Mmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:962
translate chinese MLR4_MS9_con2_0041b3b1:

    # Linda "I want to hear every ounce of pleasure I give you."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:963
translate chinese MLR4_MS9_con2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:965
translate chinese MLR4_MS9_con2_ecc479b8:

    # Linda "Tell me you love my pussy!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:967
translate chinese MLR4_MS9_con2_9e92f689:

    # MC "*Gasp* I love your pussy, [Mom_name]! Ah!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:968
translate chinese MLR4_MS9_con2_525d4d47:

    # Linda "Oh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:970
translate chinese MLR4_MS9_con2_0ab12c7e:

    # Linda "Ayaahh! Ohhh God! Mmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:971
translate chinese MLR4_MS9_con2_464a4bda:

    # MC "*Pant* [Mom_name]! I’m getting close! Ohh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:973
translate chinese MLR4_MS9_con2_1712af62:

    # MC "Hnnng! *Pant* Ohh! Fuck! Arrghh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:974
translate chinese MLR4_MS9_con2_ac43e897:

    # Linda "Yes! Yes! I’m cumming! I’m-"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:976
translate chinese MLR4_MS9_con2_131d38a0:

    # Linda "AYAAAHHHHH! CUMMMMIIIINNNG!!!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:978
translate chinese MLR4_MS9_con2_11467ee8:

    # Linda "*Pant* *Pant* Ohh... that was... phenomenal..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:979
translate chinese MLR4_MS9_con2_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:981
translate chinese MLR4_MS9_con2_6853fb0f:

    # MC "Arrgghhhhh!!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:983
translate chinese MLR4_MS9_con2_af432681:

    # Linda "W-Wait, don’t move! I’m still ah... trembling! Hahhh..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:985
translate chinese MLR4_MS9_con2_4ef4254b:

    # Linda "*Pant* Where do you want to finish?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:990
translate chinese MLR4_MS9_con2_f7c39a13:

    # MC "Hnnng! Keep riding me, [Mom_name]! I want to finish in your pussy!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:992
translate chinese MLR4_MS9_con2_b15f2019:

    # Linda "*Pant* Ah! Ohh! Oh God! Yes! Fill me up, Sweetie! Fill your mom’s pussy with your hot cum!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:994
translate chinese MLR4_MS9_con2_a5ec80b4:

    # Linda "*Pant* Ah! Ohh! Oh God! Yes! Fill me up, Sweetie! Fill my pussy with your hot cum!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:996
translate chinese MLR4_MS9_con2_e4ae9126:

    # MC "Ah! Yes! Mmmm! I’m cumming! Hnnnngg!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:997
translate chinese MLR4_MS9_con2_b28b228b:

    # Linda "Ohhhh! YESSS! CUM INSIDE ME!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:998
translate chinese MLR4_MS9_con2_f86bf70f:

    # MC "Hnnngg! Arrghhh! Ohhh! *Pant* Mmmm!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1008
translate chinese MLR4_MS9_con2_1ecec03c:

    # MC "*Pant* *Pant* Ohh..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1009
translate chinese MLR4_MS9_con2_79d3cf12:

    # Linda "Ahhhh! Ohhh!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1010
translate chinese MLR4_MS9_con2_7dc352da:

    # Linda "(I can feel it inside me! It’s sooo warm!)"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1011
translate chinese MLR4_MS9_con2_b38beb39:

    # Linda "Mmm... God... Your cum feels so good inside me..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1017
translate chinese MLR4_MS9_con2_212d9fd7:

    # MC "I want to finish in your mouth!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1019
translate chinese MLR4_MS9_con2_9fa6367a:

    # Linda "*Shlurp* *Suck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1020
translate chinese MLR4_MS9_con2_df3955d5:

    # MC "Ah! Arrghh! Hnnng! Ohhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1021
translate chinese MLR4_MS9_con2_d798ff83:

    # MC "(She’s swirling her tongue around the tip! I’m gonna cum!)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1022
translate chinese MLR4_MS9_con2_1336e419:

    # MC "*Pant* AHNNNNGG! OHHHH!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1031
translate chinese MLR4_MS9_con2_e7125bb9:

    # MC "Ahhh! *Pant* Ohhhhh!"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1033
translate chinese MLR4_MS9_con2_5643e142:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1034
translate chinese MLR4_MS9_con2_f632c6ca:

    # Linda "*Gulp* *Gulp*"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1041
translate chinese MLR4_MS9_con3_a067d070:

    # MC "*Yawn*"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1042
translate chinese MLR4_MS9_con3_e05760c6:

    # MC "(That was the best sex I’ve ever had in my life...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1044
translate chinese MLR4_MS9_con3_36a1e196:

    # "*Creak* *Creak*"
    ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1045
translate chinese MLR4_MS9_con3_f38ff0ce:

    # MC "(Sounds like [Dad_name]’s leaving...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1050
translate chinese MLR4_MS9_con3_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1051
translate chinese MLR4_MS9_con3_7d0c6a13:

    # MC "(Oh God... I shouldn’t have looked...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1053
translate chinese MLR4_MS9_con3_15d98c85:

    # MC "(Yup. That is fucking traumatising, right there.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1054
translate chinese MLR4_MS9_con3_cc6eebf4:

    # MC "(That’s DEFINITELY gonna send me back into therapy.)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1055
translate chinese MLR4_MS9_con3_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1056
translate chinese MLR4_MS9_con3_76f76d9f:

    # MC "(And I just realised that if I’m sleeping in here, the only free bed is going to be my room. Ugh...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1062
translate chinese MLR4_MS9_con3_8a6af88a:

    # MC "(Some things are better left unseen...)"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1068
translate chinese MLR4_MS9_end_9ca1753e:

    # MC "It’s a full moon tonight."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1069
translate chinese MLR4_MS9_end_d3fed67a:

    # Linda "I know! This is so peaceful with just you and me..."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1071
translate chinese MLR4_MS9_end_861aae84:

    # MC "I love you, [Mom_name]."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1072
translate chinese MLR4_MS9_end_76a0fd2c:

    # Linda "I love you too, [player_name]."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1073
translate chinese MLR4_MS9_end_21a26c21:

    # Linda "Heh, it took us a long time to get here, didn’t it?"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1075
translate chinese MLR4_MS9_end_b0338f99:

    # MC "Way too long. It was worth it though, right?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1076
translate chinese MLR4_MS9_end_9e7650d0:

    # Linda "It was."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1077
translate chinese MLR4_MS9_end_7ddde0bd:

    # MC "Is Bob gonna be okay?"
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1079
translate chinese MLR4_MS9_end_1251a9b4:

    # Linda "He’ll be fine. He’ll be sticking around. I was being a bit selfish at the start. I didn’t realise how much you, Caroline and Sara needed him."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1080
translate chinese MLR4_MS9_end_05accc4e:

    # MC "Thanks, [Mom_name]. I love you."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1081
translate chinese MLR4_MS9_end_6ddce77e:

    # Linda "I love you too, Sweetie."
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1083
translate chinese MLR4_MS9_end_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1084
translate chinese MLR4_MS9_end_b2cc81f4:

    # Linda "Mmm!"
    Linda ""

# game/scripts/ML_R4/9_MLR4_S9.rpy:1085
translate chinese MLR4_MS9_end_a0b7b3a1:

    # MC "(I guess that’s it. After everything I’ve been through, I finally got a happy ending with a beautiful, stunning woman. This truly is a Milfy City.)"
    MC ""

translate chinese strings:

    # game/scripts/ML_R4/9_MLR4_S9.rpy:423
    old "I want you to suck my cock."
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:423
    old "I want you to use your feet."
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:768
    old "Talk with [Dad_name] and try to apologise for everything that happened."
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:768
    old "Don’t risk ruining the moment. Linda has already talked wth Bob, just fuck her in front of him."
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:987
    old "I want to cum inside your pussy! Keep riding me!"
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:987
    old "I want to blow a hot load of cum deep in your mouth!"
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:1047
    old "Open your eyes."
    new ""

    # game/scripts/ML_R4/9_MLR4_S9.rpy:1047
    old "Keep them closed."
    new ""

