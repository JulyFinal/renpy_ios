﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/6_MLR4_S6.rpy:194
translate chinese MLR4_S6_f367c0bd:

    # MC "(Huh, looks like [Mom_name] left her door open. That’s an invitation to come in, if I ever saw one!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:195
translate chinese MLR4_S6_a9affb47:

    # MC "Hello? [Mom_name]? Are you here?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:197
translate chinese MLR4_S6_c0fa7c42:

    # Linda "You really kept me waiting, didn’t you?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:198
translate chinese MLR4_S6_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:200
translate chinese MLR4_S6_da063bd1:

    # Linda "What’s wrong, Sweetie? Stunned speechless?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:201
translate chinese MLR4_S6_cb0976ed:

    # MC "You’re... Wow!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:203
translate chinese MLR4_S6_b4a75b1d:

    # Linda "Hehe! I thought you’d enjoy this! I wanted to do something... a little bit different tonight."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:204
translate chinese MLR4_S6_1541042f:

    # MC "You look so fucking sexy in those ropes!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:205
translate chinese MLR4_S6_e5eb2e68:

    # Linda "I’m glad you appreciate it. You have NO IDEA how long it took to tie myself up like this."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:214
translate chinese MLR4_S6_questions_bb83329b:

    # MC "Did you really tie those ropes all by yourself?!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:215
translate chinese MLR4_S6_questions_697952b5:

    # Linda "Well, given that Caroline and Sara are the only other people in this house, what do you think?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:216
translate chinese MLR4_S6_questions_dd2dc996:

    # MC "Haha! Of course. It looks really complicated! How did you manage it?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:218
translate chinese MLR4_S6_questions_ed61ae81:

    # Linda "Let’s just say, we’re probably not going to be doing this very often."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:219
translate chinese MLR4_S6_questions_e98757d7:

    # MC "Aww, that’s a shame. I get it though."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:231
translate chinese MLR4_S6_questions_b3e35de2:

    # MC "It looks amazing on you! Where’d you buy it?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:233
translate chinese MLR4_S6_questions_41dfba16:

    # Linda "I stopped by a little sex shop in the city after work. I do have to admit, I was a little nervous. The girl behind the counter was pleasant though."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:245
translate chinese MLR4_S6_questions_01953fef:

    # MC "What happened earlier? You started acting strange after we had sex in the kitchen."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:248
translate chinese MLR4_S6_questions_b3508bec:

    # Linda "I... Sorry... It was... It was just hitting me that your father had actually left now. That he wasn’t coming back."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:250
translate chinese MLR4_S6_questions_059b79d5:

    # Linda "I... Sorry... It was... It was just hitting me that my husband had actually left now. That he wasn’t coming back. "
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:251
translate chinese MLR4_S6_questions_2c1fa7a6:

    # MC "Do you miss him?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:253
translate chinese MLR4_S6_questions_d77e90cc:

    # Linda "No. I honestly don’t. It’s just... It felt surreal that it actually happened."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:254
translate chinese MLR4_S6_questions_7368be80:

    # Linda "What about you? Do you miss him?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:256
translate chinese MLR4_S6_questions_4516f090:

    # MC "Of course I do. I’m really happy to be with you now, Mom... but he’s still my Dad at the end of the day."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:258
translate chinese MLR4_S6_questions_0ef9d11b:

    # MC "Of course I do. I’m really happy to be with you now, Linda... but Bob was still a really supportive guy. He gave me great advice whenever I needed him. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:259
translate chinese MLR4_S6_questions_5759b867:

    # Linda "I get that."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:271
translate chinese MLR4_S6_questions_708fe474:

    # MC "What about my sisters? Should we tell them about us?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:272
translate chinese MLR4_S6_questions_53eb980e:

    # Linda "I don’t think that’s a good idea, [player_name]. Sara and Caroline are still dealing with the shock of your father moving out."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:274
translate chinese MLR4_S6_questions_9d127334:

    # MC "What about Caroline and Sara? Should we tell them about us? "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:275
translate chinese MLR4_S6_questions_e6dbb064:

    # Linda "I don’t think that’s a good idea, [player_name]. Sara and Caroline are still dealing with the shock of him moving out."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:276
translate chinese MLR4_S6_questions_f705e4e1:

    # Linda "The last thing we want to do right now is drop an even bigger bombshell on them."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:277
translate chinese MLR4_S6_questions_3c7e2805:

    # MC "Yeah, that makes sense."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:278
translate chinese MLR4_S6_questions_953217ae:

    # Linda "Give them both some time to adjust. We can introduce them to what’s going on later."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:292
translate chinese MLR4_S6_con_22751478:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:293
translate chinese MLR4_S6_con_91ef34e7:

    # Linda "(I can’t wait any longer! Bob’s gone. I can FINALLY do whatever I want with [player_name], for AS LONG as I want to!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:295
translate chinese MLR4_S6_con_73682427:

    # Linda "I want to suck your cock soooo badly."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:296
translate chinese MLR4_S6_con_fd3f0905:

    # MC "Well, what are you waiting for, [Mom_name]? Crawl over here."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:300
translate chinese MLR4_S6_con_845f42c4:

    # Linda "Do you have any idea how long I fantasised about doing this?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:301
translate chinese MLR4_S6_con_26a6871b:

    # Linda "I imagined sucking your cock, kissing you, fucking you. It was the only way I could get myself off."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:303
translate chinese MLR4_S6_con_2dd33fbe:

    # MC "Mmm... Tell me more."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:304
translate chinese MLR4_S6_con_0be56b44:

    # Linda "I used to spy on you when you showered. Remember those times when I’d come in and grab your dirty clothes off the floor?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:306
translate chinese MLR4_S6_con_d5c04764:

    # Linda "I ALWAYS lingered a little longer than I should have, just to catch a glimpse of your hard cock."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:307
translate chinese MLR4_S6_con_b84fd9d2:

    # MC "That’s very naughty of you, [Mom_name]."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:309
translate chinese MLR4_S6_con_1859aedb:

    # Linda "Hehe, I couldn’t resist you. You were always on my mind, even before Judy’s machinations."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:310
translate chinese MLR4_S6_con_53e5efdb:

    # Linda "Oh God... Your cock looks delicious."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:313
translate chinese MLR4_S6_con_9739e7ed:

    # MC "Go on, Mom. Suck on it. I know you want to."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:315
translate chinese MLR4_S6_con_14d87d57:

    # MC "Go on. Suck on it. I know you want to. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:316
translate chinese MLR4_S6_con_62ba0e75:

    # Linda "*Gulp*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:318
translate chinese MLR4_S6_con_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:319
translate chinese MLR4_S6_con_39c34cc5:

    # Linda "*Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:321
translate chinese MLR4_S6_con_635c4603:

    # MC "Fuck.. Your lips are so soft, Mom."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:323
translate chinese MLR4_S6_con_6467369f:

    # MC "Fuck.. Your lips are so soft."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:325
translate chinese MLR4_S6_con_0a999f7a:

    # Linda "*Suuuuck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:327
translate chinese MLR4_S6_con_d8394f40:

    # MC "OoohH! Mmm! Just like that, Mom! *Pant* Yes!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:329
translate chinese MLR4_S6_con_fd65b0d0:

    # MC "OoohH! Mmm! Just like that! *Pant* Yes!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:331
translate chinese MLR4_S6_con_8fc96cbf:

    # MC "Ooooh... Mmm..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:332
translate chinese MLR4_S6_con_5643e142:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:334
translate chinese MLR4_S6_con_44aafe6a:

    # Linda "*Glompf* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:335
translate chinese MLR4_S6_con_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:336
translate chinese MLR4_S6_con_c8a22bf7:

    # Linda "(I love hearing him groan while I pleasure him. Okay, let’s speed things up a bit!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:338
translate chinese MLR4_S6_con_5bac2c2b:

    # Linda "*Suck* *Shlurp* *Suck* *Shlurp* *Suck *Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:340
translate chinese MLR4_S6_con_cb2c842e:

    # MC "Oh! Mmm! Hnnng! Just like that, Mom! Don’t stop! *Pant* Ooohh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:342
translate chinese MLR4_S6_con_a3aed55c:

    # MC "Oh! Mmm! Hnnng! Just like that! Don’t stop! *Pant* Ooohh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:344
translate chinese MLR4_S6_con_5643e142_1:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:345
translate chinese MLR4_S6_con_0ba05ace:

    # MC "*Pant* Hnnng!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:347
translate chinese MLR4_S6_con_3cd19548:

    # MC "Mmm... You’re amazing at that, [Mom_name]. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:348
translate chinese MLR4_S6_con_dc94cf71:

    # Linda "*Suck* *Shluuuurrrp* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:350
translate chinese MLR4_S6_con_7619e101:

    # MC "Ah... *Pant* Ah!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:351
translate chinese MLR4_S6_con_39aa5087:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:353
translate chinese MLR4_S6_con_93cc3453:

    # MC "Hnnng! I think I’m gonna cum! *Pant*"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:354
translate chinese MLR4_S6_con_5643e142_2:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:355
translate chinese MLR4_S6_con_75a10ffb:

    # MC "Hnnng! I’m gonna-"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:357
translate chinese MLR4_S6_con_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:358
translate chinese MLR4_S6_con_0f927398:

    # Linda "Don’t you DARE finish yet! I didn’t spend two hours getting tangled up in ropes for you to empty your balls at the first hurdle!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:360
translate chinese MLR4_S6_con_025c0858:

    # Linda "I’m expecting a FULL night of sex. You can cum when I tell you that you can cum. Got it?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:361
translate chinese MLR4_S6_con_f1e14ee1:

    # MC "Y-Yeah, I got it! You don’t have to grip it so hard!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:363
translate chinese MLR4_S6_con_104ef3a0:

    # Linda "Good. You’re the man of the house now, so how about you start being a bit more dominant?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:364
translate chinese MLR4_S6_con_6284dadc:

    # MC "More dominant?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:366
translate chinese MLR4_S6_con_1bf24433:

    # Linda "Yeah, be firm with me."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:367
translate chinese MLR4_S6_con_d3c20936:

    # Linda "I’ll bend over the bed. I want you to take charge. Show me you’ve got what it takes."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:371
translate chinese MLR4_S6_con_e220f105:

    # Linda "Well? What are you waiting for? Go on, do it. Fuck me."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:372
translate chinese MLR4_S6_con_8e3e60d4:

    # MC "*Gulp* (I can do this... I’ll pound her harder than she’s ever been fucked in her life!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:374
translate chinese MLR4_S6_con_c9da25e7:

    # MC "(Nice! It looks like there’s a gap in the ropes for me to get her pussy!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:376
translate chinese MLR4_S6_con_f63f96b8:

    # MC "(Alright, I’ll just climb up on the couch and take her from behind.)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:377
translate chinese MLR4_S6_con_9507f258:

    # Linda "There’s no need to be shy about it, Sweetie. Go on. Slide your cock into my pussy. Make me scream your name!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:379
translate chinese MLR4_S6_con_c87ed3f2:

    # Linda "Oh! Mmm! That’s it. Stick it inside me. Fill me up with your cock!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:380
translate chinese MLR4_S6_con_475c63f8:

    # MC "Tell me you want it. Beg for it."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:382
translate chinese MLR4_S6_con_c92f2d04:

    # Linda "I want you to fuck me, [player_name]. Please... wreck my pussy with your big, fat, cock."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:383
translate chinese MLR4_S6_con_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:384
translate chinese MLR4_S6_con_bbec91a5:

    # MC "(I’ll keep the suspense up a little while longer.)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:386
translate chinese MLR4_S6_con_424b5059:

    # Linda "Pleeease! Don’t make me wait any longer! I’m so horny! I need to feel you inside me!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:387
translate chinese MLR4_S6_con_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:388
translate chinese MLR4_S6_con_82e79048:

    # Linda "PLEASE! I need you to fuck me!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:390
translate chinese MLR4_S6_con_913be23e:

    # Linda "AH! YES!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:391
translate chinese MLR4_S6_con_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:392
translate chinese MLR4_S6_con_e263429e:

    # Linda "Oh my God! Mmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:395
translate chinese MLR4_S6_con_70127d13:

    # Linda "I *Pant* keep forgetting how much bigger you are than your father!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:397
translate chinese MLR4_S6_con_a240365b:

    # Linda "I *Pant* keep forgetting how much bigger you are than my husband!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:398
translate chinese MLR4_S6_con_2c4cb45b:

    # Linda "God, you’re stretching my pussy to its limit! Mmmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:400
translate chinese MLR4_S6_con_dfe92c8e:

    # Linda "Ah! Oohhhh..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:402
translate chinese MLR4_S6_con_2659c540:

    # MC "Ugh Hnnnggg... Ohh..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:404
translate chinese MLR4_S6_con_e3837e89:

    # Linda "Ayaaahhhhh!! Yessss!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:407
translate chinese MLR4_S6_con_e7e1d096:

    # Linda "Ohhhhh! Fuuuuuck!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:408
translate chinese MLR4_S6_con_6ab31951_1:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:411
translate chinese MLR4_S6_con_321d001a:

    # MC "Do you like that, Mom? How does it feel having your son bury his dick deep inside your wet cunt?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:413
translate chinese MLR4_S6_con_9f45122d:

    # MC "Do you like that, Linda? How does it feel having a younger guy like me bury his dick deep inside your wet cunt?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:414
translate chinese MLR4_S6_con_3a7b445f:

    # Linda "Ah! Ahh! S-Soooo goood!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:416
translate chinese MLR4_S6_con_e2be5e12:

    # MC "You’re soaking wet, right now."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:417
translate chinese MLR4_S6_con_223dfa9c:

    # Linda "Yesssss! Oooohhhh! Deeper! Pleeeeasse!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:419
translate chinese MLR4_S6_con_020535fa:

    # MC "HNNNG!!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:421
translate chinese MLR4_S6_con_ed828e98:

    # Linda "Ayaaahhhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:423
translate chinese MLR4_S6_con_a6ac6b75:

    # Linda "AHHHHH!! OHHHH GOD! YESSSS! AAAAHHHH!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:425
translate chinese MLR4_S6_con_6ab31951_2:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:427
translate chinese MLR4_S6_con_e7e1d096_1:

    # Linda "Ohhhhh! Fuuuuuck!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:429
translate chinese MLR4_S6_con_c5a5ea45:

    # MC "Ugh! Ah! Mmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:430
translate chinese MLR4_S6_con_55bd39d7:

    # Linda "Ha-Harder! Harder, [player_name]! YES!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:432
translate chinese MLR4_S6_con_4a326cdc:

    # Linda "Oohhh! Yes! Screw me! Ayaahhhhh! I’m cumming! Oh God! I’m cumming!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:433
translate chinese MLR4_S6_con_d66ee2f8:

    # MC "Hnnng! That’s it! Cum for me, [Mom_name]! Cum all over my fat cock!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:434
translate chinese MLR4_S6_con_9a663669:

    # Linda "AAAHHHHHHHH!!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:436
translate chinese MLR4_S6_con_249aac78:

    # Linda "Harder! *Gasp* Fuck me harder! Ayaaahhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:437
translate chinese MLR4_S6_con_6679bcf7:

    # MC "(Alright, let’s give this everything I got!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:439
translate chinese MLR4_S6_con_b50c107e:

    # MC "Arrrghh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:441
translate chinese MLR4_S6_con_4209f572:

    # Linda "*GASP* AAAHAHHHHHHHHH!!! OOOOHHHH!!! AH! AH! YESSSSS!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:443
translate chinese MLR4_S6_con_23b6c8f9:

    # Linda "OH GOD! You’re sooo deep! AAHHHHH!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:445
translate chinese MLR4_S6_con_ef79a5dd:

    # Linda "Ah! Ah! *Pant* I love you! I love you, [player_name]!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:447
translate chinese MLR4_S6_con_cd0de76d:

    # MC "Hnnng! I love you too, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:449
translate chinese MLR4_S6_con_f0d467ae:

    # Linda "*Gasp* Ohhh! Oh my God! It’s too good! Ooohhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:451
translate chinese MLR4_S6_con_7f5219f7:

    # Linda "Mmmm! God! Your dick feels SOOO much better than Bob’s! *Pant* Mmmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:453
translate chinese MLR4_S6_con_6ab31951_3:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:455
translate chinese MLR4_S6_con_f46d9d80:

    # Linda "Ah! Ah! AHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:457
translate chinese MLR4_S6_con_55b8ba25:

    # MC "Oh... Mmmm! *Pant* Oh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:459
translate chinese MLR4_S6_con_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:460
translate chinese MLR4_S6_con_140469b4:

    # MC "(I’m getting close! Time to cum inside her!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:461
translate chinese MLR4_S6_con_d67a6c1a:

    # MC "*Pant* I’m gonna cum!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:463
translate chinese MLR4_S6_con_123dadbf:

    # MC "Hnnngg! Argh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:464
translate chinese MLR4_S6_con_01a47a48:

    # Linda "Ah! Ahhh! W-Wait! Not yet! Ah!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:465
translate chinese MLR4_S6_con_030d8672:

    # MC "Ohhh! Fuck! MMM!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:467
translate chinese MLR4_S6_con_4f684d0e:

    # MC "*Pant* Oh God! Arrrghh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:469
translate chinese MLR4_S6_con_44acfc1d:

    # Linda "Wait! Don’t cum yet!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:472
translate chinese MLR4_S6_con_f46d9d80_1:

    # Linda "Ah! Ah! AHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:474
translate chinese MLR4_S6_con_6b847465:

    # MC "HNNNGG!! Arrgghh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:475
translate chinese MLR4_S6_con_366dadfb:

    # Linda "*GASP* Oh! Aahhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:477
translate chinese MLR4_S6_con_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:478
translate chinese MLR4_S6_con_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:484
translate chinese MLR4_S6_con_a2f74272:

    # MC "Ooof! *Cough*"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:485
translate chinese MLR4_S6_con_e131f0f7:

    # Linda "Whoops, sorry. Didn’t mean to push you THAT hard. I just didn’t want you finishing too early."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:486
translate chinese MLR4_S6_con_723ce29b:

    # MC "*Pant* It’s okay, I was getting a bit carried away there, anyway."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:488
translate chinese MLR4_S6_con_49d55b40:

    # Linda "How about we give some different positions a go?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:489
translate chinese MLR4_S6_con_fdea730c:

    # MC "Any preferences?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:491
translate chinese MLR4_S6_con_b29163a1:

    # Linda "I was thinking sideways... if I spread my legs like this."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:492
translate chinese MLR4_S6_con_91680e98:

    # MC "Mmm! Looks good to me!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:494
translate chinese MLR4_S6_con_274668c1:

    # Linda "It’s so much nicer when it’s just you and me here. There’s no way I could have dressed up like this when Bob was still around."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:495
translate chinese MLR4_S6_con_843073c0:

    # Linda "It’s just so much more... liberating with the two of us."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:497
translate chinese MLR4_S6_con_2a9797e1:

    # MC "I know what you mean. I was always scared shitless of him catching us."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:498
translate chinese MLR4_S6_con_21b59f7a:

    # Linda "C’mon, enough talk about my former husband. Get over here and fuck me."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:500
translate chinese MLR4_S6_con_b2cc81f4:

    # Linda "Mmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:501
translate chinese MLR4_S6_con_8f4f8e1a:

    # MC "Oooohhh..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:503
translate chinese MLR4_S6_con_901250f5:

    # Linda "God... I love the moment when your cock starts sliding inside me. *Gasp* Ooohhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:505
translate chinese MLR4_S6_con_08754c8d:

    # MC "Mmm! *Pant* I love you, Mom."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:507
translate chinese MLR4_S6_con_cf3ed97f:

    # MC "Mmm! *Pant* I love you, Linda. I love you so much! Ah!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:509
translate chinese MLR4_S6_con_7b6d3deb:

    # Linda "*Pant* I love you too, Sweetie! Oh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:511
translate chinese MLR4_S6_con_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:513
translate chinese MLR4_S6_con_5b6e848f:

    # Linda "*Gasp* Oohhh! Just like that, [player_name]! Don’t stop!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:515
translate chinese MLR4_S6_con_6ab31951_4:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:517
translate chinese MLR4_S6_con_330bfe6e:

    # Linda "([player_name] has SO much stamina! It was always just a couple of minutes with Bob and then he was done.)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:519
translate chinese MLR4_S6_con_8d938f04:

    # MC "Hnnng... Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:521
translate chinese MLR4_S6_con_f46d9d80_2:

    # Linda "Ah! Ah! AHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:523
translate chinese MLR4_S6_con_9bd83181:

    # Linda "*Gasp* Ohh! Yes!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:524
translate chinese MLR4_S6_con_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:527
translate chinese MLR4_S6_con_07ad9c0c:

    # MC "Ooohh... Your pussy feels so fucking good, Mom!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:529
translate chinese MLR4_S6_con_f6af96ba:

    # MC "Ooohh... Your pussy feels so fucking good! "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:531
translate chinese MLR4_S6_con_92d7fc98:

    # Linda "*Pant* Keep going! Ah! Ah!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:533
translate chinese MLR4_S6_con_d236237e:

    # Linda "Ayaahhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:535
translate chinese MLR4_S6_con_87e4f695:

    # MC "Mmmm! Ugh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:537
translate chinese MLR4_S6_con_4f2c0301:

    # Linda "*Gasp* Yes! Yes! Ohhhh! God!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:538
translate chinese MLR4_S6_con_2439c284:

    # MC "*Pant* Hnnng! Ohhh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:540
translate chinese MLR4_S6_con_80e507ae:

    # MC "Arrrghh... Hnnggg..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:541
translate chinese MLR4_S6_con_1489f1d6:

    # Linda "Ohh! Ah!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:543
translate chinese MLR4_S6_con_9ff0ae50:

    # Linda "AYAAAHHHHH!!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:545
translate chinese MLR4_S6_con_c2c86ed4:

    # MC "Argh! Fuck! Mmmm! You’re so tight, Mom! *Pant* Hnnngg!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:547
translate chinese MLR4_S6_con_3d805317:

    # MC "Argh! Fuck! Mmmm! You’re so tight! *Pant* Hnnngg! "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:548
translate chinese MLR4_S6_con_6d7b8425:

    # Linda "AH! AHHHH!! CUMMMIIING!!! AHHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:550
translate chinese MLR4_S6_con_9eb2e5cf:

    # MC "HNNNGG! *Pant* I’m gonna cum too!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:551
translate chinese MLR4_S6_con_37f4c0f2:

    # Linda "Ohhh! Nooohhht yet! AHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:552
translate chinese MLR4_S6_con_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:554
translate chinese MLR4_S6_con_d64c1f53:

    # MC "Hey, watch ou-"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:555
translate chinese MLR4_S6_con_958343b4_1:

    # MC "Whoa!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:557
translate chinese MLR4_S6_con_c42ad36b:

    # MC "Oof!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:558
translate chinese MLR4_S6_con_8df8c307:

    # Linda "Ah, ah. Not yet!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:560
translate chinese MLR4_S6_con_6825cb1c:

    # Linda "I’m not having you waste our first proper night alone by cumming so quickly."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:561
translate chinese MLR4_S6_con_5289fd54:

    # Linda "I know what you men are like. You always get so sleepy after you finish."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:562
translate chinese MLR4_S6_con_cf038926:

    # MC "Fine, fine!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:564
translate chinese MLR4_S6_con_36f2a4d0:

    # Linda "Alright, let’s move to the bed next. I want you to fuck me when I’m lying facedown."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:565
translate chinese MLR4_S6_con_a75107fc:

    # MC "I thought you said you wanted me to be dominant tonight?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:566
translate chinese MLR4_S6_con_e524d929:

    # Linda "I changed my mind. That’s something you’re going to have to get used to, now that you’re the man of the house. Haha!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:568
translate chinese MLR4_S6_con_f08fdb98:

    # MC "You may want to be in charge, [Mom_name]. But you’re not gonna stop me finishing, this time."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:569
translate chinese MLR4_S6_con_caf9a16e:

    # Linda "Is that so?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:570
translate chinese MLR4_S6_con_78ce8013:

    # MC "You’ve already edged me twice."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:572
translate chinese MLR4_S6_con_07b67d04:

    # MC "I’m just going to keep fucking you until I cum, this time."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:573
translate chinese MLR4_S6_con_c16e11db:

    # Linda "Oh really? And what if I just push you away again?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:574
translate chinese MLR4_S6_con_2202b463:

    # MC "I don’t think you’re going to be able to push me away when I’ve got your arm pinned to your back with the full weight of my body."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:576
translate chinese MLR4_S6_con_eeb27141:

    # Linda "OHHHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:577
translate chinese MLR4_S6_con_3d0971e7:

    # MC "Did you feel it slide in there, [Mom_name]?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:578
translate chinese MLR4_S6_con_4600e90a:

    # Linda "*Gasp* Ooohh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:580
translate chinese MLR4_S6_con_2e92c67d:

    # MC "Argh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:582
translate chinese MLR4_S6_con_81803aa0:

    # Linda "Ayaahhhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:584
translate chinese MLR4_S6_con_0f29a01e:

    # MC "Go on, [Mom_name]. Try and push me away."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:586
translate chinese MLR4_S6_con_fd0e8fe4:

    # Linda "Ah! Ah! Ahh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:587
translate chinese MLR4_S6_con_7c9afd07:

    # MC "I think you’re ugh... realising it now, aren’t you?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:588
translate chinese MLR4_S6_con_d79dacfb:

    # MC "There’s NOTHING you can do to stop me from giving you a big creampie this time."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:590
translate chinese MLR4_S6_con_3307a4fd:

    # Linda "Ahh! Haah! Ayaaahhh! H-Hold on! I- Ah! Ahhh!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:592
translate chinese MLR4_S6_con_928a78b7:

    # MC "I can feel you wriggling. You’re desperate to escape, aren’t you? Hnnng!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:594
translate chinese MLR4_S6_con_69f3bb18:

    # MC "You’ve teased me for far too long tonight. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:596
translate chinese MLR4_S6_con_633a7dc1:

    # Linda "Ah! Ah! AH! AHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:597
translate chinese MLR4_S6_con_c841a0e9:

    # MC "That’s it. Scream for me. Hnnng! I want to hear you moan louder!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:599
translate chinese MLR4_S6_con_01b54cdd:

    # Linda "Ooohhh! AH! AHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:601
translate chinese MLR4_S6_con_611ad2f4:

    # MC "Hnnng! UGH!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:603
translate chinese MLR4_S6_con_eeb27141_1:

    # Linda "OHHHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:605
translate chinese MLR4_S6_con_d3da7c46:

    # Linda "AYAAAHHHHHHH!!!! I’M CUMMMMIIINNNGG!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:606
translate chinese MLR4_S6_con_ed0944c9:

    # MC "Argghhh!!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:609
translate chinese MLR4_S6_con_6d06869a:

    # MC "Keep screaming like that - and someone’s gonna hear you, Mom."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:611
translate chinese MLR4_S6_con_c96b06ea:

    # MC "Keep screaming like that - and someone’s gonna hear you."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:612
translate chinese MLR4_S6_con_9398b37d:

    # Linda "Ah! AHHH!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:614
translate chinese MLR4_S6_con_3306af44:

    # MC "Maybe Caroline or Sara will walk in and see how I’m fucking their mother senseless? They’d certainly know I was the man of the house then, wouldn't they?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:616
translate chinese MLR4_S6_con_b0590624:

    # MC "Maybe Caroline or Sara will walk in and see how I’m fucking their landlady senseless? They’d certainly know I was the man of the house then, wouldn't they?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:618
translate chinese MLR4_S6_con_df797958:

    # Linda "AHH-Mmmpff!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:620
translate chinese MLR4_S6_con_d9ffcec1:

    # Linda "(Oh God! It’s so fucking hot hearing him talk to me like that. I CAN’T let his sisters hear me though! Seeing me being fucked is bad enough, but being dressed up in these ropes just makes it SO much worse!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:622
translate chinese MLR4_S6_con_441af155:

    # MC "Argh! Hnnng! I’m gonna cum, Mom! *Pant*"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:624
translate chinese MLR4_S6_con_2f2eab3d:

    # Linda "(Oh God! It’s so fucking hot hearing him talk to me like that. I CAN’T let the girls hear me though! Seeing me being fucked is bad enough, but being dressed up in these ropes just makes it SO much more embarrassing!) "
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:626
translate chinese MLR4_S6_con_4d11256b:

    # MC "Argh! Hnnng! I’m gonna cum! *Pant*"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:627
translate chinese MLR4_S6_con_f01c176f:

    # Linda "Mppff! HMMMM!!!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:632
translate chinese MLR4_S6_con_3cc129ac:

    # MC "Argghhh! HNNNGG!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:642
translate chinese MLR4_S6_con_01a4f0bc:

    # Linda "Nmmpfff!! MMMMMM!!!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:643
translate chinese MLR4_S6_con_a25912aa:

    # Linda "(Oh my God! His hot cum is rushing inside me! Oh God! I’m cumming again!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:644
translate chinese MLR4_S6_con_36182a74:

    # Linda "HMMPPFFFFFFF!!! NMMPPFFFFFFF!!! AAHHMMMMPFFFF!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:645
translate chinese MLR4_S6_con_4aa6c100:

    # MC "Arrrgghhhh!!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:651
translate chinese MLR4_S6_con_3cc129ac_1:

    # MC "Argghhh! HNNNGG!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:661
translate chinese MLR4_S6_con_01a4f0bc_1:

    # Linda "Nmmpfff!! MMMMMM!!!!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:662
translate chinese MLR4_S6_con_a25912aa_1:

    # Linda "(Oh my God! His hot cum is rushing inside me! Oh God! I’m cumming again!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:663
translate chinese MLR4_S6_con_36182a74_1:

    # Linda "HMMPPFFFFFFF!!! NMMPPFFFFFFF!!! AAHHMMMMPFFFF!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:664
translate chinese MLR4_S6_con_4aa6c100_1:

    # MC "Arrrgghhhh!!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:670
translate chinese MLR4_S6_con_706f1adf:

    # MC "Hnnngg! Arrghh! I’m cumming!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:680
translate chinese MLR4_S6_con_72dda7fc:

    # MC "Ohhh... Fuck... *Pant* Mmm..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:681
translate chinese MLR4_S6_con_8fc4ed99:

    # Linda "*Pant* *Pant*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:682
translate chinese MLR4_S6_con_7f5a2d10:

    # Linda "That was... *Gasp* ...REALLY intense."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:689
translate chinese MLR4_S6_con2_ac761f2b:

    # MC "*Pant* That was phenomenal, Mom."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:691
translate chinese MLR4_S6_con2_39912407:

    # MC "*Pant* That was phenomenal. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:694
translate chinese MLR4_S6_con2_82472880:

    # Linda "Heh... It was *Pant* absolutely incredible..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:696
translate chinese MLR4_S6_con2_66e3bf8a:

    # MC "I love you so much, [Mom_name]. You mean the world to me. You know that, right?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:697
translate chinese MLR4_S6_con2_c3c560b8:

    # Linda "I know, Sweetie."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:699
translate chinese MLR4_S6_con2_9d754676:

    # Linda "I love you too. Very, very much."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:701
translate chinese MLR4_S6_con2_6de802da:

    # Linda "Try not to worry too much about everything that’s happened with your father. I promise you, we’ll get through it."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:703
translate chinese MLR4_S6_con2_82472880_1:

    # Linda "Heh... It was *Pant* absolutely incredible..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:704
translate chinese MLR4_S6_con2_55d1790e:

    # MC "Sara and Caroline are-"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:706
translate chinese MLR4_S6_con2_ab8d2847:

    # Linda "Let me handle your sisters. Just focus on your own wellbeing for the meantime."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:708
translate chinese MLR4_S6_con2_5727cbc0:

    # MC "Thanks, Mom. You’re the best."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:710
translate chinese MLR4_S6_con2_ebd476a7:

    # Linda "We’ll get through this together. I promise. And we’ll do it as a family. You, me, Sara and Caroline."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:711
translate chinese MLR4_S6_con2_e682aaa9:

    # MC "I only just noticed how beautiful your eyes are, Mom."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:713
translate chinese MLR4_S6_con2_55576273:

    # Linda "Let me handle those two. Just focus on your own wellbeing for the meantime."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:715
translate chinese MLR4_S6_con2_e2f9424e:

    # MC "Thanks, Linda. You’re the best."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:717
translate chinese MLR4_S6_con2_67d20ba1:

    # Linda "We’ll get through this together. I promise. And we’ll do it together. You, me, Sara and Caroline."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:718
translate chinese MLR4_S6_con2_6e64e918:

    # MC "I only just noticed how beautiful your eyes are, Linda."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:721
translate chinese MLR4_S6_con2_30e0d5af:

    # Linda "That’s very sweet, [player_name]. I’m honestly surprised it was my eyes you were looking at, while I’m dressed like this."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:722
translate chinese MLR4_S6_con2_04aea3d6:

    # MC "Trust me, I’ve been looking everywhere. You’re absolutely stunning."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:724
translate chinese MLR4_S6_con2_1ef1b7fd:

    # Linda "Are you too tired to make out? I know you’ve just came, so you’re probably exhausted and Bob always fell asleep after-"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:727
translate chinese MLR4_S6_con2_e7351af8:

    # MC "I’m not too tired. Let’s make out."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:728
translate chinese MLR4_S6_con2_ece3ea09:

    # Linda "Really?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:729
translate chinese MLR4_S6_con2_190e23cb:

    # MC "Yeah, I’d like that."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:731
translate chinese MLR4_S6_con2_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:733
translate chinese MLR4_S6_con2_b2cc81f4:

    # Linda "Mmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:735
translate chinese MLR4_S6_con2_738e3ae5:

    # MC "(I can feel her tongue dancing against my own!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:737
translate chinese MLR4_S6_con2_ec2dce21:

    # Linda "Mmm... Mmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:739
translate chinese MLR4_S6_con2_d0a2be8b:

    # MC "(I’m the luckiest guy in the world right now!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:740
translate chinese MLR4_S6_con2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:742
translate chinese MLR4_S6_con2_22751478:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:743
translate chinese MLR4_S6_con2_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:746
translate chinese MLR4_S6_con2_34d2096c:

    # MC "(My mom is such an amazing kisser!)"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:748
translate chinese MLR4_S6_con2_6094c03c:

    # MC "(She is such an amazing kisser!) "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:749
translate chinese MLR4_S6_con2_22751478_1:

    # Linda "Mmm..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:751
translate chinese MLR4_S6_con2_2cb9a188:

    # Linda "*Gasp* Ohh..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:752
translate chinese MLR4_S6_con2_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:754
translate chinese MLR4_S6_con2_5190e715:

    # Linda "Oh my... perhaps I was wrong about men falling asleep after they cum!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:755
translate chinese MLR4_S6_con2_bb1455e9:

    # MC "Heh, you felt that, did you?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:757
translate chinese MLR4_S6_con2_dd825a32:

    # Linda "It’s impossible to miss, when it’s pressing up against me like that! Haha!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:758
translate chinese MLR4_S6_con2_713b2de2:

    # MC "Heh, sorry."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:760
translate chinese MLR4_S6_con2_66d9c547:

    # Linda "Well, you can hardly go to sleep with that big hard-on. Want me to help you get rid of it?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:761
translate chinese MLR4_S6_con2_17566f8b:

    # MC "Oh, yes please. What position do you want to try this time? Cowgirl?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:763
translate chinese MLR4_S6_con2_00ac281b:

    # Linda "Haha! I don’t think my pussy can take anymore. How about I use my mouth instead?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:764
translate chinese MLR4_S6_con2_64424139:

    # MC "Yeah! That’d be awesome!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:766
translate chinese MLR4_S6_con2_35b86a68:

    # Linda " Okay, you’re in charge this time, [player_name]. Fuck my face as hard and as fast as you want."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:767
translate chinese MLR4_S6_con2_d82dac12:

    # MC "Are you sure about that?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:769
translate chinese MLR4_S6_con2_5ba5e090:

    # Linda "I want you to use me like I’m your sex doll. I want to feel your dick slipping down my throat."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:771
translate chinese MLR4_S6_con2_c744c007:

    # Linda "I want to feel you emptying your balls into my mouth, so I can taste your salty semen."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:774
translate chinese MLR4_S6_con2_97f8c404:

    # Linda "Mmm... Your dick looks so delicious. I want to feel it thrusting across my tongue."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:775
translate chinese MLR4_S6_con2_2930200f:

    # MC "You’re so fucking hot when you talk dirty like that."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:777
translate chinese MLR4_S6_con2_b1d7ab39:

    # Linda "Go on, [player_name]. Fuck my throat until my eyes roll back in my head."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:778
translate chinese MLR4_S6_con2_0e77d798:

    # MC "Open wide for me."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:780
translate chinese MLR4_S6_con2_a61c996e:

    # Linda "Aaahhhhh..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:781
translate chinese MLR4_S6_con2_22f0c18f:

    # MC "Now, reach out and grab my shaft."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:783
translate chinese MLR4_S6_con2_66672952:

    # MC "That’s it. Stroke my dick. Nice and slow."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:784
translate chinese MLR4_S6_con2_9950266a:

    # Linda "*Lick*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:785
translate chinese MLR4_S6_con2_bd8fd5eb:

    # MC "Mmm... Alright, take your hand away. I’m going in now."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:787
translate chinese MLR4_S6_con2_0af0a435:

    # Linda "Aaaaahh..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:788
translate chinese MLR4_S6_con2_517d6aa7:

    # Linda "*Lick* *Lick*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:789
translate chinese MLR4_S6_con2_f74b3f9b:

    # MC "Mmm... Ooohhh..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:791
translate chinese MLR4_S6_con2_25731625:

    # MC "*Pant* That’s it, [Mom_name]. Suck on my fat cock. Mmmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:792
translate chinese MLR4_S6_con2_5643e142:

    # Linda "*Shlurp* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:793
translate chinese MLR4_S6_con2_14d24d01:

    # MC "Hnnnng!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:795
translate chinese MLR4_S6_con2_727d98db:

    # Linda "*Shlurp* *Suuuucck* *Shlurp*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:797
translate chinese MLR4_S6_con2_6b52cb3f:

    # MC "God, I love it when you suck my dick like that, Mom. Let’s see how deep you can take it."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:799
translate chinese MLR4_S6_con2_c7677c2c:

    # MC "God, I love it when you suck my dick like that. Let’s see how deep you can take it. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:801
translate chinese MLR4_S6_con2_39aa5087:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:803
translate chinese MLR4_S6_con2_1447fb84:

    # Linda "*Shluurrp* *Gag*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:804
translate chinese MLR4_S6_con2_fc67b0ee:

    # MC "Hnnngg! Ooohh... God that feels good."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:806
translate chinese MLR4_S6_con2_7b9f24da:

    # Linda " Mppff! *Shlurp* Nmmpff!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:807
translate chinese MLR4_S6_con2_1ad39147:

    # MC "Argh... Ohhh! *Pant* Don’t stop, [Mom_name]!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:809
translate chinese MLR4_S6_con2_acedc26a:

    # MC "C’mon, I know you can take it deeper. Let’s see how far I can get it down your throat."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:811
translate chinese MLR4_S6_con2_e7369c9f:

    # Linda "*Shlurp* *Suuuuck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:813
translate chinese MLR4_S6_con2_cef6e96c:

    # Linda "*Gag* *Choke*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:814
translate chinese MLR4_S6_con2_1ffcc3a9:

    # MC "Ohh! Yeah! Hnnngg! *Pant* Mmm! I can feel your throat constricting around the tip! Ohhh fuck... That feels amazing."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:816
translate chinese MLR4_S6_con2_cd839310:

    # Linda "*Gag* Glompff! *Gag*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:817
translate chinese MLR4_S6_con2_a073645c:

    # MC "Oohh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:818
translate chinese MLR4_S6_con2_33bcb84b:

    # Linda "*Shlurp* *Gag* *Choke*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:820
translate chinese MLR4_S6_con2_8b68eda4:

    # MC "Hnnng! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:821
translate chinese MLR4_S6_con2_39aa5087_1:

    # Linda "*Suck* *Suck*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:825
translate chinese MLR4_S6_con2_14607da5:

    # MC "Fuck! I’m cumming! Hnnng! Ohhhh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:826
translate chinese MLR4_S6_con2_0c1783d0:

    # Linda "*Gag* *Shluuuurrrp*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:827
translate chinese MLR4_S6_con2_1cdcb437:

    # Linda "Nmppff! Mppfff!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:837
translate chinese MLR4_S6_con2_68ab4248:

    # MC "OHHHHH!!!! ARRGHHHH!!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:838
translate chinese MLR4_S6_con2_6c9b17f0:

    # Linda "(Oh my God! How does he still have THAT much cum?! I thought I’d already drained his balls a few minutes ago!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:839
translate chinese MLR4_S6_con2_91d6bfc1:

    # Linda "Aaahhh..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:840
translate chinese MLR4_S6_con2_94f23fe7:

    # MC "Ohhh... *Pant* Your mouth is sooooo good!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:846
translate chinese MLR4_S6_con2_0f2afd3f:

    # MC "I’m gonna cum! Stick your tongue out!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:847
translate chinese MLR4_S6_con2_7cc5c041:

    # Linda "Aaahhhh..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:848
translate chinese MLR4_S6_con2_8c21db29:

    # MC "Hnnng! Ohh! Arrghh!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:858
translate chinese MLR4_S6_con2_cd291c37:

    # MC "Ohh... Fuck! Mmm!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:859
translate chinese MLR4_S6_con2_b30097e6:

    # Linda "(Wow! That is one hell of a cumshot! Where did he even get that from?! I thought I’d just emptied his balls a few minutes ago!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:868
translate chinese MLR4_S6_con3_8fc4ed99:

    # Linda "*Pant* *Pant*"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:869
translate chinese MLR4_S6_con3_00c8f497:

    # MC "Mmm... That was amazing, [Mom_name]. This has been one of the best days of my ENTIRE life!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:870
translate chinese MLR4_S6_con3_8c40fd15:

    # Linda "You were absolutely amazing, [player_name]."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:872
translate chinese MLR4_S6_con3_66edb01b:

    # MC "Heh, are you up for another round?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:873
translate chinese MLR4_S6_con3_30c5d0a4:

    # Linda "Do you honestly think you can go another round?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:874
translate chinese MLR4_S6_con3_0db528ee:

    # MC "Hell yeah! I can keep going till the sun comes up."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:876
translate chinese MLR4_S6_con3_bb63bb74:

    # Linda "Haha! Someone’s confident!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:877
translate chinese MLR4_S6_con3_29535541:

    # MC "Of course I am! How could I not be, when I’m spending my night with the sexiest woman in the world?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:878
translate chinese MLR4_S6_con3_bc844730:

    # MC "I’ll happily fuck you till sunrise if you let me."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:881
translate chinese MLR4_S6_con3_ea715029:

    # Linda "(This is what I’ve been missing out on with Bob. He never had a fraction of the sexual stamina that his son does.)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:883
translate chinese MLR4_S6_con3_c407a78b:

    # Linda "(This is what I’ve been missing out on with Bob. He never had a fraction of the sexual stamina that [player_name] does.) "
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:884
translate chinese MLR4_S6_con3_b2cc81f4:

    # Linda "Mmm!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:886
translate chinese MLR4_S6_con3_9f8258a5:

    # Linda "(I should have acted sooner. Why did I wait so damn long before I made my move on [player_name]? My life could have been so much better if I’d only seized the damn moment!)"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:887
translate chinese MLR4_S6_con3_d952570a:

    # MC "Are you alright, [Mom_name]? You’re very quiet."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:889
translate chinese MLR4_S6_con3_8bb09e46:

    # Linda "Yes, Sweetie. I’m okay. Just... ruminating on things."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:890
translate chinese MLR4_S6_con3_968ad036:

    # MC "Is it something I can help with?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:891
translate chinese MLR4_S6_con3_1fde9c59:

    # Linda "No, I’m afraid not."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:893
translate chinese MLR4_S6_con3_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:895
translate chinese MLR4_S6_con3_9d2782d1:

    # MC "Do you think Dad’s gonna be alright?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:897
translate chinese MLR4_S6_con3_d55b4311:

    # MC "Do you think Bob’s gonna be alright?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:898
translate chinese MLR4_S6_con3_c43b46a9:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:900
translate chinese MLR4_S6_con3_35a3b0e6:

    # MC "It’s just... I’m worried about him. I know you two didn’t get on, but he’s still my old man at the end of the day - and I’m worried he’ll hurt himself or something."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:902
translate chinese MLR4_S6_con3_2db2df40:

    # MC "It’s just... I’m worried about him. I know you two didn’t get on, but he’s still my father figure at the end of the day - and I’m worried he’ll hurt himself or something."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:904
translate chinese MLR4_S6_con3_d7116b34:

    # Linda "I don’t know, [player_name]. I haven’t heard from him since he left."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:905
translate chinese MLR4_S6_con3_f4cdc58f:

    # MC "*Sigh* Maybe... Maybe you could- Do you think you could invite him over for dinner? There’s a new Thai restaurant opening up in that big mall. I’m sure he’d love to join us for that."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:906
translate chinese MLR4_S6_con3_c43b46a9_1:

    # Linda "..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:908
translate chinese MLR4_S6_con3_1b3196e5:

    # Linda "*Sigh* It’s complicated, [player_name]. Can you give me some time to think about it?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:910
translate chinese MLR4_S6_con3_df113ff9:

    # MC "Sure, no problem. Just don’t take too long. He seemed really, really down. I don’t want him to think his whole family has abandoned him."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:912
translate chinese MLR4_S6_con3_c2dd2c0d:

    # MC "Sure, no problem. Just don’t take too long. He seemed really, really down. I don’t want him to think that everyone he knows has abandoned him. "
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:913
translate chinese MLR4_S6_con3_d10eca12:

    # MC "I mean, if he’s feeling completely hopeless, he might just do something stupid..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:914
translate chinese MLR4_S6_con3_2deddaac:

    # Linda "Something stupid?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:915
translate chinese MLR4_S6_con3_dea0a5f9:

    # MC "Yeah... Something that... *Gulp* ...something that he can’t go back on... ever..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:916
translate chinese MLR4_S6_con3_d3b3e8e9:

    # Linda "[player_name]!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:917
translate chinese MLR4_S6_con3_243e55e9:

    # MC "You weren’t the one who spoke to him before he left, [Mom_name]. He was devastated. The man was a shell of his former self. God forbid he take a gun and-"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:919
translate chinese MLR4_S6_con3_b77480fb:

    # Linda "Don’t finish that sentence, [player_name]! Your father would NEVER do anything like-"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:921
translate chinese MLR4_S6_con3_9af3859b:

    # Linda "Don’t finish that sentence, [player_name]! Bob would NEVER do anything like-"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:925
translate chinese MLR4_S6_con3_a792ebb9:

    # "*BANG*"
    ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:927
translate chinese MLR4_S6_con3_24148341:

    # MC "Shit!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:928
translate chinese MLR4_S6_con3_74fa78f3:

    # Linda "Jesus Chrsit! What the hell was that?!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:930
translate chinese MLR4_S6_con3_e4ee43a6:

    # MC "Is... Is someone breaking in?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:931
translate chinese MLR4_S6_con3_fa035810:

    # Linda "I... I don’t know. It came from the garage."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:933
translate chinese MLR4_S6_con3_89632c2c:

    # MC "*Gulp* I’ll check it out..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:935
translate chinese MLR4_S6_con3_48c1e588:

    # "*Creak*"
    ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:937
translate chinese MLR4_S6_con3_3d11d78b:

    # Linda "*Whispered* Be careful..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:940
translate chinese MLR4_S6_con3_36a1e196:

    # "*Creak* *Creak*"
    ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:941
translate chinese MLR4_S6_con3_87083a83:

    # Linda "*Whispered* Take a look out the window. Let me know if you see anything."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:943
translate chinese MLR4_S6_con3_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:944
translate chinese MLR4_S6_con3_62ca6e69:

    # Linda "Well?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:946
translate chinese MLR4_S6_con3_004b5bd9:

    # MC "I can’t see any signs of a break-in, [Mom_name]. The garage still looks closed up."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:947
translate chinese MLR4_S6_con3_a569a349:

    # Linda "Do you think we should check it out?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:948
translate chinese MLR4_S6_con3_2ec47505:

    # MC "Bob locked it when he left. Do you have a spare key?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:949
translate chinese MLR4_S6_con3_40a01fd4:

    # Linda "I’m afraid not..."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:951
translate chinese MLR4_S6_con3_be71cc96:

    # MC "Huh... We can shoot Dad a text message tomorrow, to see if he can swing by and unlock it for us."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:953
translate chinese MLR4_S6_con3_491193ab:

    # MC "Huh... We can shoot Bob a text message tomorrow, to see if he can swing by and unlock it for us."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:956
translate chinese MLR4_S6_con3_741872c8:

    # "*Hoo Hoo*"
    ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:957
translate chinese MLR4_S6_con3_440dadc0:

    # Linda "What was that?!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:958
translate chinese MLR4_S6_con3_7859251a:

    # MC "Just owls, I think."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:960
translate chinese MLR4_S6_con3_81a02a2b:

    # Linda "The house is locked up for the night. It was probably a raccoon knocking over a dustbin."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:961
translate chinese MLR4_S6_con3_316210f9:

    # MC "Yeah... That... That makes sense..."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:963
translate chinese MLR4_S6_con3_a8ba64c7:

    # Linda "C’mon back to bed. We can check around the house in the morning."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:964
translate chinese MLR4_S6_con3_0e8ca8b1:

    # MC "*Yawn* You’re right, [Mom_name]. It’s getting late anyway."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:966
translate chinese MLR4_S6_con3_5690f031:

    # Linda "Heh! Listen to those yawns! So much for saying you could go until sunrise."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:968
translate chinese MLR4_S6_con3_6e900faf:

    # MC "Ahaha! You’re gonna use that line against me for the rest of our lives, aren’t you?"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:969
translate chinese MLR4_S6_con3_defabe85:

    # Linda "Hehe!"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:971
translate chinese MLR4_S6_con3_d310e180:

    # MC "Fine, one more round!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:972
translate chinese MLR4_S6_con3_90d12ebc:

    # Linda "Hehe- wait, you’re serious?"
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:973
translate chinese MLR4_S6_con3_f97f84b7:

    # MC "Of course I am!"
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:975
translate chinese MLR4_S6_con3_f136eb45:

    # Linda "Very well. You’ve talked the talk, now let’s see if you can walk the walk."
    Linda ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:977
translate chinese MLR4_S6_con3_bede8ec6:

    # MC "I think YOU’RE the one who is going to have trouble walking the walk... tomorrow morning, that is."
    MC ""

# game/scripts/ML_R4/6_MLR4_S6.rpy:978
translate chinese MLR4_S6_con3_8cac3090:

    # Linda "Mmm! Get your ass back into bed, Sweetie!"
    Linda ""

translate chinese strings:

    # game/scripts/ML_R4/6_MLR4_S6.rpy:211
    old "You tied those ropes all by yourself?"
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:211
    old "Where did you buy it?"
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:211
    old "What was wrong earlier? You weren’t acting like yourself in the kitchen."
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:211
    old "Do you think we should tell Sara and Caroline?"
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:211
    old "Skip questions."
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:629
    old "Cum inside your Mom’s pussy."
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:629
    old "Cum inside Linda’s pussy."
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:822
    old "Blow your salty load deep in Linda’s mouth."
    new ""

    # game/scripts/ML_R4/6_MLR4_S6.rpy:822
    old "Pull out and finish over her face."
    new ""

