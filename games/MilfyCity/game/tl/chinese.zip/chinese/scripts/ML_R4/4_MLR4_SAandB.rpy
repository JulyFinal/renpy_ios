﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:19
translate chinese MLR4_S4b_f6301588:

    # MC "(Huh... It’s closed.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:22
translate chinese MLR4_S4b_bc5311d2:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:23
translate chinese MLR4_S4b_c3ff6fdb:

    # MC "(And locked too... What’s going on?)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:26
translate chinese MLR4_S4b_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:27
translate chinese MLR4_S4b_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:28
translate chinese MLR4_S4b_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:30
translate chinese MLR4_S4b_116aa4e7:

    # MC "(That’s a little disconcerting...)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:31
translate chinese MLR4_S4b_602eae66:

    # MC "(What the heck is going on?)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:42
translate chinese MLR4_S4a_3197e326:

    # MC "([Dad_name] is cleaning his stuff inside the garage, it's better not to bother him.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:47
translate chinese MLR4_S4a_bc5311d2:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:48
translate chinese MLR4_S4a_0328b6ff:

    # MC "(Huh... Seems like [Dad_name] locked the garage after he left.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:50
translate chinese MLR4_S4a_f33c8a4c:

    # MC "(There’s nothing I need from there anyway. I can take a look later on when it’s open.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:56
translate chinese MLR4_S4a_bc5311d2_1:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:57
translate chinese MLR4_S4a_e7824f91:

    # MC "(Huh... Seems like [Dad_name] locked the garage when he left.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:59
translate chinese MLR4_S4a_f33c8a4c_1:

    # MC "(There’s nothing I need from there anyway. I can take a look later on when it’s open.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:65
translate chinese MLR4_S4a_bc5311d2_2:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:66
translate chinese MLR4_S4a_e7824f91_1:

    # MC "(Huh... Seems like [Dad_name] locked the garage when he left.)"
    MC ""

# game/scripts/ML_R4/4_MLR4_SAandB.rpy:68
translate chinese MLR4_S4a_f33c8a4c_2:

    # MC "(There’s nothing I need from there anyway. I can take a look later on when it’s open.)"
    MC ""

