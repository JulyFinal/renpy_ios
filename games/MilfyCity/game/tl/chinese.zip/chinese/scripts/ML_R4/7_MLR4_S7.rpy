﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/ML_R4/7_MLR4_S7.rpy:49
translate chinese MLR4_S7_bc5311d2:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:50
translate chinese MLR4_S7_92da384b:

    # MC "Hmm... (I wonder if it’s still locked.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:52
translate chinese MLR4_S7_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:53
translate chinese MLR4_S7_371c1d2f:

    # MC "(That’s no good. It’s not budging an inch. It’s weird that he’d leave it locked after he left.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:60
translate chinese MLR4_S7_17891b97:

    # MC "(Maybe Dad dropped by today and unlocked the garage...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:62
translate chinese MLR4_S7_658cdca9:

    # MC "(Maybe Bob dropped by today and unlocked the garage...) "
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:64
translate chinese MLR4_S7_d174ea9d_1:

    # MC "Hnnng..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:66
translate chinese MLR4_S7_bc5311d2_1:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:68
translate chinese MLR4_S7_e4cd4b4e:

    # MC "*Pant* (Nope... Still locked. That’s really weird. Why would you lock a garage when your family was still living in the house and needing to use it?)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:70
translate chinese MLR4_S7_c6f906eb:

    # MC "*Pant* (Nope... Still locked. That’s really weird. Why would you lock a garage when there were still living in the house and needing to use it?) "
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:84
translate chinese MLR4_S7_4d5b45a9:

    # MC "(Maybe [Dad_name] dropped by after work to pick up some more stuff and finally unlock the garage?)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:87
translate chinese MLR4_S7_bc5311d2_2:

    # "*Rattle* *Rattle*"
    ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:88
translate chinese MLR4_S7_55a9b9b5:

    # MC "*Sigh* Fucks sake..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:90
translate chinese MLR4_S7_d69a778e:

    # MC "(It doesn’t make any sense. Why would [Dad_name] lock up the garage after he leaves?)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:91
translate chinese MLR4_S7_f791337a:

    # MC "(Maybe he left some extra private possessions in there that he needs to come back for?)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:94
translate chinese MLR4_S7_898befa4:

    # "*Smash*"
    ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:95
translate chinese MLR4_S7_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:97
translate chinese MLR4_S7_4481e269:

    # MC "(What the...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:98
translate chinese MLR4_S7_d6d6b177:

    # MC "(I could have sworn I heard breaking glass.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:100
translate chinese MLR4_S7_7dfb0436:

    # MC "(Maybe it’s a rat or something knocking over a bottle?)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:101
translate chinese MLR4_S7_e1a009e5:

    # MC "(We might have to hire an exterminator... That’s the last thing [Mom_name] needs right now.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:103
translate chinese MLR4_S7_557d351d:

    # MC "(I might be able to get a better view from the side window...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:105
translate chinese MLR4_S7_baa4f1cb:

    # MC "Ugh..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:106
translate chinese MLR4_S7_63fc6ce4:

    # MC "(It’s pitch black in there. I can’t see a thing!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:108
translate chinese MLR4_S7_2d204a49:

    # MC "..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:109
translate chinese MLR4_S7_60cdec3c:

    # MC "(I wonder if that sound was caused by the same creature that interrupted [Mom_name] and me the other night...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:111
translate chinese MLR4_S7_895f35c9:

    # MC "(If it’s making that much noise, then it’s probably bigger than a rat. God... I hope a raccoon isn’t destroying all the shit we’ve got stored in there.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:112
translate chinese MLR4_S7_6640a52e:

    # MC "(I wonder if my phone’s flashlight would work.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:114
translate chinese MLR4_S7_ec3bb565:

    # MC "(Alright, let’s try this...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:115
translate chinese MLR4_S7_474fa7f9:

    # MC "C’mon..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:117
translate chinese MLR4_S7_7ead6f3d:

    # MC "(Nope... It’s darker than Caroline’s godawful coffee.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:119
translate chinese MLR4_S7_5dc650c7:

    # MC "(I guess I’m gonna have to be the one to sort the raccoon out, now that [Dad_name]’s gone...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:120
translate chinese MLR4_S7_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:121
translate chinese MLR4_S7_11d74b55:

    # MC "(He always used to be the one to handle this kind of shit around the house. I guess this is what he meant when he told me that I was going to be the ‘Man of the House’ now.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:123
translate chinese MLR4_S7_13a21dc9:

    # MC "Alright..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:124
translate chinese MLR4_S7_cbb3a8f0:

    # MC "(First things first, I need to verify what exactly is in the garage before I waste money on an exterminator.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:125
translate chinese MLR4_S7_663aa167:

    # MC "(Hmm... A night vision camera might help me see inside.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:129
translate chinese MLR4_S7_8f955949:

    # MC "(I should swing by the stores. Maybe they have one in stock?)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:153
translate chinese MLR4_S7_con_98626c19:

    # MC "(Good thing I already have a camera!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:154
translate chinese MLR4_S7_con_f660fbad:

    # MC "(Alright, let’s find out what creature is rummaging around in here. I’ll call [Dad_name] in the morning to get the garage unlocked, then hire an exterminator.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:156
translate chinese MLR4_S7_con_9d748472:

    # MC "(Alright... here we go...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:158
translate chinese MLR4_S7_con_9308376d:

    # MC "(And... just a few more seconds while it adjusts...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:161
translate chinese MLR4_S7_con_04782b9f:

    # MC "Huh? What the..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:162
translate chinese MLR4_S7_con_ad9373a1:

    # MC "WHAT THE FUCK?!"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:164
translate chinese MLR4_S7_con_327d66e4:

    # MC "(No... No way! It can’t be!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:165
translate chinese MLR4_S7_con_4e294ecf:

    # MC "No fucking way..."
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:167
translate chinese MLR4_S7_con_379b3fc1:

    # Bob "*Hic* Mmm..."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:168
translate chinese MLR4_S7_con_2291aaa6:

    # Bob "Heh... That’s it... Keep fuckin’ her like *hic* that!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:170
translate chinese MLR4_S7_con_450a366a:

    # MC "(Oh, you have GOT to be kidding me!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:171
translate chinese MLR4_S7_con_c93a7ab5:

    # MC "([Dad_name] must have snuck back in and set up some camera equipment in the garage!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:173
translate chinese MLR4_S7_con_b8ae17c6:

    # MC "(Jesus... He’s planted hidden cameras all over the bedroom!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:174
translate chinese MLR4_S7_con_090be70d:

    # MC "([Mom_name]’s gonna flip when she finds out.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:176
translate chinese MLR4_S7_con_afcf1dfb:

    # Bob "Bwahahaha!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:177
translate chinese MLR4_S7_con_01372acb:

    # Bob "That’s it! Rail her! Pound her good! *Hic*"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:179
translate chinese MLR4_S7_con_92ccd5db:

    # Bob "*Glug* *Glug*"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:180
translate chinese MLR4_S7_con_96f4029f:

    # MC "([Dad_name]’s either completely lost it... or he’s a cuck. I don’t know which is worse...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:182
translate chinese MLR4_S7_con_ccfd9b1a:

    # Bob "Ah..."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:183
translate chinese MLR4_S7_con_70ac233c:

    # Bob "Oh yeah, here comes the best part! Fuck her *hic* face!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:185
translate chinese MLR4_S7_con_37a2dcd9:

    # Bob "Mmm... That’s it. Cum inside my *hic* wife’s pretty little mouth."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:186
translate chinese MLR4_S7_con_ec2344d7:

    # Linda "*Shlurp* *Shlick* *Suck*"
    Linda ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:187
translate chinese MLR4_S7_con_e51301b9:

    # Bob "Ugh! Hnnnggg!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:189
translate chinese MLR4_S7_con_4c5dfe1a:

    # MC "(Fucking hell... He’s watching everything [Mom_name] and I did the other night...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:190
translate chinese MLR4_S7_con_0059ba26:

    # MC "(He recorded it all!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:192
translate chinese MLR4_S7_con_470bf30a:

    # Bob "Ohh... Linda... You’re so damn beautiful. God, I never deserved you."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:193
translate chinese MLR4_S7_con_ff0ce121:

    # Bob "*Pant* Ugh!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:195
translate chinese MLR4_S7_con_58776f21:

    # Bob "Ah... Ugh... Mmm!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:196
translate chinese MLR4_S7_con_628bfbec:

    # Linda "Ah! Yes! Yes! [player_name]! Fuck me! God! You’re SOOO much bigger than Bob!"
    Linda ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:198
translate chinese MLR4_S7_con_1569e577:

    # Linda "Ah! Ahh! Oh God! I’m cumming! Aahhhhhhh!"
    Linda ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:199
translate chinese MLR4_S7_con_28fd3101:

    # Bob "Hnnngg! Arrghh! *Pant* That’s it! Fuck her!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:202
translate chinese MLR4_S7_con_08592c18:

    # Bob "That’s it! *Hic* Fuck her like your old man never could!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:204
translate chinese MLR4_S7_con_bf5056f7:

    # Bob "That’s it! *Hic* Fuck her like your her husband never could!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:205
translate chinese MLR4_S7_con_3e113d43:

    # Linda "Ah! Ah! Ah! Ohhhhh!"
    Linda ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:206
translate chinese MLR4_S7_con_8ef029a9:

    # Bob "Mmm... Hnnng! Oh! Arrghhh!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:215
translate chinese MLR4_S7_con_e25e53f1:

    # Bob "Oh! Fuuuuck! Hnnnngg!"
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:216
translate chinese MLR4_S7_con_46227b9e:

    # Linda "Ah! Yes! Fuck me, [player_name]!"
    Linda ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:217
translate chinese MLR4_S7_con_2a60dc93:

    # Bob "Arrghh! *Pant* God..."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:219
translate chinese MLR4_S7_con_0b0afff2:

    # Bob "Oh... Oh God... here it comes..."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:220
translate chinese MLR4_S7_con_c533f635:

    # Bob "Ugh... post-nut clarity."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:223
translate chinese MLR4_S7_con_907abfb6:

    # Bob "*Sniff* I’ve lost them all... I’ve lost my whole family..."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:225
translate chinese MLR4_S7_con_02846031:

    # Bob "*Sniff* I’ve lost them all... I’ve lost my wife... "
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:226
translate chinese MLR4_S7_con_51a7f56f:

    # Bob "I miss hearing Caroline rant about her job... and the sound of Sara’s gaming..."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:227
translate chinese MLR4_S7_con_12bc1264:

    # Bob "...and I miss my boy. *Sniff* I just want them back."
    Bob ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:229
translate chinese MLR4_S7_con_3b55cfec:

    # MC "(Oh God... I think I’ve seen enough!)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:230
translate chinese MLR4_S7_con_5d9f0fca:

    # MC "(Bob’s obviously getting turned on by me fucking Linda... but it’s even clearer that he misses being around us.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:232
translate chinese MLR4_S7_con_da6113b4:

    # MC "*Sigh* (I need to talk to [Mom_name] about this. This isn’t fair on [Dad_name].)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:233
translate chinese MLR4_S7_con_ab6d0ef5:

    # MC "(It’s not like he can spend the rest of his life hiding out in the garage just so he can still feel close to us.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:236
translate chinese MLR4_S7_con_51a1c035:

    # MC "(Shit... I don’t know how [Mom_name] is gonna react when I tell her [Dad_name]’s set up secret cameras around the bedroom.)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:237
translate chinese MLR4_S7_con_78024eba:

    # MC "(Or that he never really left in the first place...)"
    MC ""

# game/scripts/ML_R4/7_MLR4_S7.rpy:238
translate chinese MLR4_S7_con_6e410ef9:

    # MC "*Whispered* ...fuck."
    MC ""

