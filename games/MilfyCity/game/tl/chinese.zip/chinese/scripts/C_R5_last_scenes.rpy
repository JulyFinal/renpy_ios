﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/C_R5_last_scenes.rpy:61
translate chinese C_R5_last_shop_ef7102b6:

    # MC "(It seems like Caroline's store is doing pretty well lately! She’s been working constantly!)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:62
translate chinese C_R5_last_shop_9af74bd7:

    # MC "(I wonder why she’s still keeping the brick-and-mortar store open, when her online business is doing so well?)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:64
translate chinese C_R5_last_shop_9d85c684:

    # MC "(Hmm... Given that she models all her own clothes. I’m sure there’s plenty of customers that want to come in and see her, in person!)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:65
translate chinese C_R5_last_shop_5dd4733d:

    # MC "(Her ass looks incredible in that tight pantsuit!)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:67
translate chinese C_R5_last_shop_bcd06ba6:

    # MC "Hey there, Caroline. What’s up?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:68
translate chinese C_R5_last_shop_bc4628d7:

    # Caroline "Hmm?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:70
translate chinese C_R5_last_shop_1e490079:

    # Caroline "Oh!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:71
translate chinese C_R5_last_shop_4cdeb2e7:

    # MC "Sorry, didn’t mean to scare you!"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:74
translate chinese C_R5_last_shop_3096957c:

    # Caroline "It’s alright! You just startled me a bit. I was distracted there. Didn’t even hear you come in!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:75
translate chinese C_R5_last_shop_3d47c975:

    # Caroline "So, what’s up, [player_name]? What can I do for you?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:76
translate chinese C_R5_last_shop_d499dd79:

    # MC "Nothing much! Just wanted to drop by and see how you were doing."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:78
translate chinese C_R5_last_shop_ec6740b9:

    # Caroline "Aww, that’s sweet of you. I’m great! Business is booming. Plenty of customers drop by my shop every hour. I can barely keep the shelves stocked!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:79
translate chinese C_R5_last_shop_38ec070e:

    # MC "That’s great!"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:81
translate chinese C_R5_last_shop_09ca82e5:

    # Caroline "Plenty of creeps too, of course. Lotta guys see me modeling the cosplay outfits online, and think they can just come in here and hit on me, in person."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:82
translate chinese C_R5_last_shop_6e865127:

    # MC "Ugh. You okay?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:84
translate chinese C_R5_last_shop_1f3da2d3:

    # Caroline "Oh yeah, I can handle them. Besides, Violet is here, every now and then, to lend me a hand."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:85
translate chinese C_R5_last_shop_3b0ca42a:

    # MC "That’s good. If anyone ever gives you any trouble though, just give me a call. I’ll come straight over and kick their ass."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:87
translate chinese C_R5_last_shop_214619cb:

    # Caroline "Hehe, the same way you kicked Charles’s ass?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:88
translate chinese C_R5_last_shop_3cf4ef44:

    # MC "Haha! Yeah, I kinda underestimated him, didn’t I?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:90
translate chinese C_R5_last_shop_f918cec1:

    # Caroline "Honestly, [player_name], I’ll be fine. You don’t need to worry about anything."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:92
translate chinese C_R5_last_shop_e0a70dac:

    # Caroline "I really appreciate your concern for me though. It’s cute. I’ve always loved how conscientious you were."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:93
translate chinese C_R5_last_shop_0a4e64b4:

    # Caroline "In fact... it’s probably my favourite thing about you."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:95
translate chinese C_R5_last_shop_3de37243:

    # MC "Aww... You’re just saying that."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:96
translate chinese C_R5_last_shop_236522d0:

    # Caroline "I mean it. You’re the only person who really stepped up to help me, when I was in that dark place."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:98
translate chinese C_R5_last_shop_0a56c1a8:

    # Caroline "You’re the best thing that has ever happened to me, [player_name]."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:99
translate chinese C_R5_last_shop_4a8086f3:

    # Caroline "If it wasn’t for you, I’d have probably ended up getting together with another stupid abusive asshole."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:101
translate chinese C_R5_last_shop_ef2f5a8e:

    # Caroline "I love you, [player_name]. Thank you. For everything."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:102
translate chinese C_R5_last_shop_278d5957:

    # MC "I love you too, Caroline."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:103
translate chinese C_R5_last_shop_e5bba369:

    # Caroline "Drop by my room tonight if you’re free. I love it when you come to visit."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:114
translate chinese C_R5_last_shop_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:132
translate chinese C_R5_last_E_4cc4d3e7:

    # Caroline "Heh... Haha!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:133
translate chinese C_R5_last_E_613c5649:

    # MC "(She seems happy this evening!)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:135
translate chinese C_R5_last_E_9547af15:

    # MC "Hey Caroline, whatcha up to?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:136
translate chinese C_R5_last_E_99f1cb21:

    # Caroline "Haha!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:138
translate chinese C_R5_last_E_62f5d128:

    # Caroline "Oh! Hey there! I was just wasting my time, scrolling through some stupid videos."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:139
translate chinese C_R5_last_E_c2b4d4bd:

    # Caroline "What about you? Any plans for this evening?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:141
translate chinese C_R5_last_E_f67c74dd:

    # MC "Nah, just dropped by to see if you wanted to hang out."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:142
translate chinese C_R5_last_E_d2ad6824:

    # Caroline "I think I’ll just chill by myself here. But I wouldn’t mind if you wanted to swing by in a couple of hours, for some fun?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:144
translate chinese C_R5_last_E_5171c7e3:

    # MC "Oh yeah? What kind of fun are you thinking about?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:145
translate chinese C_R5_last_E_0b11a56b:

    # Caroline "Wake me up when you come in, and we’ll talk about it."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:147
translate chinese C_R5_last_E_8bafecfc:

    # MC "Sweet! I’ll catch you then. I’ll let you get back to relaxing with your phone now."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:148
translate chinese C_R5_last_E_8ffe84dd:

    # Caroline "Wait! Don’t go yet!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:150
translate chinese C_R5_last_E_08b62b11:

    # Caroline "Did you really think I was going to let you leave before you kissed me?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:151
translate chinese C_R5_last_E_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:153
translate chinese C_R5_last_E_ab182ef2:

    # Caroline "Wait until it’s dark before you come in. I don’t want anyone else hearing you sneak into my room."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:154
translate chinese C_R5_last_E_626f891f:

    # MC "Of course."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:156
translate chinese C_R5_last_E_14f5fe95:

    # Caroline "Have a think about what you want to do. Perhaps I could suck your dick? Or you could just fuck me senseless?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:157
translate chinese C_R5_last_E_8aeded26:

    # MC "I’ll let you know."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:159
translate chinese C_R5_last_E_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:160
translate chinese C_R5_last_E_278d5957:

    # MC "I love you too, Caroline."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:162
translate chinese C_R5_last_E_3308a9f7:

    # Caroline "See you tonight."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:163
translate chinese C_R5_last_E_b1db8562:

    # MC "See ya then."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:165
translate chinese C_R5_last_E_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:166
translate chinese C_R5_last_E_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:176
translate chinese C_R5_last_E_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:194
translate chinese C_R5_last_M_63e33068:

    # MC "(That’s the shortest dress I think I’ve ever seen, in my life! I can practically see her asscheeks!)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:196
translate chinese C_R5_last_M_00a62fb6:

    # MC "(I wonder what she’s staring at.)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:197
translate chinese C_R5_last_M_a5bcc264:

    # MC "Hey, Caroline. What’s up?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:199
translate chinese C_R5_last_M_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:200
translate chinese C_R5_last_M_56e5d500:

    # MC "Hey Caroline? You okay?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:202
translate chinese C_R5_last_M_fb3dfa69:

    # Caroline "Huh? Oh! Sorry, I didn’t hear you come in, [player_name]. I was a million miles away, there."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:204
translate chinese C_R5_last_M_ba0df824:

    # MC "Everything okay? You seemed a little out of it."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:205
translate chinese C_R5_last_M_e42a0f41:

    # Caroline "Yeah, I’m fine. I was just watching a couple of crows outside. They’re really clever, you know that?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:207
translate chinese C_R5_last_M_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:208
translate chinese C_R5_last_M_13829508:

    # Caroline "Oh yeah, they can use sticks as tools and solve puzzles. They’re nesting nearby. I’ve been watching them every morning for a few weeks now."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:210
translate chinese C_R5_last_M_b7f79424:

    # Caroline "It started out with just one of them, trying to build a nest by itself - and it wasn’t having much luck. A blackbird kept bullying and attacking it."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:211
translate chinese C_R5_last_M_9232e1a8:

    # Caroline "Then, a second Crow appeared a couple of weeks later, and it seems they managed to fend off the blackbird, and actually build a nest together."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:214
translate chinese C_R5_last_M_fd80bc6f:

    # MC "That sounds really sweet. Have they laid any eggs yet?"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:215
translate chinese C_R5_last_M_e738da1b:

    # Caroline "I’m not sure. It’d be really nice if they did, though. I think it would be a very sweet end to their story if they had some babies together. Hehe!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:217
translate chinese C_R5_last_M_ff69bc71:

    # Caroline "Sorry, I’m being soppy and silly!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:218
translate chinese C_R5_last_M_ebb6e64a:

    # MC "You’re not! I think it’s sweet."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:220
translate chinese C_R5_last_M_e47d82e2:

    # MC "(God, her cleavage is incredible!)"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:221
translate chinese C_R5_last_M_6abd6ef5:

    # Caroline "Anyway! I should probably get a move on, or I’m gonna be late, opening the store!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:223
translate chinese C_R5_last_M_e12b5831:

    # MC "No problem, Caroline. I’ll catch you later."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:224
translate chinese C_R5_last_M_2c8ef9e7:

    # Caroline "Swing by if you feel like it. It always brightens up my day when you stop by."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:226
translate chinese C_R5_last_M_e3dfc2d7:

    # Caroline "*Whispered* Or... if you’d prefer... you could swing by my room tonight instead?"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:227
translate chinese C_R5_last_M_68c70d18:

    # MC "Mmm, that sounds fun."
    MC ""

# game/scripts/C_R5_last_scenes.rpy:228
translate chinese C_R5_last_M_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:230
translate chinese C_R5_last_M_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:231
translate chinese C_R5_last_M_1e0ca35d:

    # MC "I love you too, Caroline. "
    MC ""

# game/scripts/C_R5_last_scenes.rpy:233
translate chinese C_R5_last_M_c021a461:

    # MC "See ya later, Caroline!"
    MC ""

# game/scripts/C_R5_last_scenes.rpy:234
translate chinese C_R5_last_M_13a281b8:

    # Caroline "Bye, [player_name]! Enjoy your day!"
    Caroline ""

# game/scripts/C_R5_last_scenes.rpy:245
translate chinese C_R5_last_M_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

