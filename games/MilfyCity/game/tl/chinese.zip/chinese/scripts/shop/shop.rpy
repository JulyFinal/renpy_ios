﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/shop/shop.rpy:78
translate chinese shop_label_4a24d7b6:

    # MC "(Closed. It's open only at the morning and in the afternoon.)"
    MC ""

# game/scripts/shop/shop.rpy:96
translate chinese shop_s1_gustav_33a06902:

    # Gustav "Wellll, hellllooo there, my good fellow!"
    Gustav ""

# game/scripts/shop/shop.rpy:97
translate chinese shop_s1_gustav_748753c0:

    # Sales_A "Hi there. Just these today?"
    Sales_A ""

# game/scripts/shop/shop.rpy:99
translate chinese shop_s1_gustav_bee817a5:

    # Gustav "Just the headphones, my good man!"
    Gustav ""

# game/scripts/shop/shop.rpy:100
translate chinese shop_s1_gustav_f6b26467:

    # Sales_A "No problem."
    Sales_A ""

# game/scripts/shop/shop.rpy:102
translate chinese shop_s1_gustav_15bb36c9:

    # "*BEEP* *ERROR*"
    ""

# game/scripts/shop/shop.rpy:103
translate chinese shop_s1_gustav_ed2d2b50:

    # Sales_A "Ugh... Hang on, the barcode isn’t scanning."
    Sales_A ""

# game/scripts/shop/shop.rpy:105
translate chinese shop_s1_gustav_f3ed733c:

    # Gustav "Barcode not scanning, eh? Do you know what that means..."
    Gustav ""

# game/scripts/shop/shop.rpy:106
translate chinese shop_s1_gustav_1d119845:

    # Sales_A "Please don’t, sir."
    Sales_A ""

# game/scripts/shop/shop.rpy:107
translate chinese shop_s1_gustav_516b6992:

    # Gustav "I SAID, D’YOU KNOW WHAT THAT MEANS?!!!"
    Gustav ""

# game/scripts/shop/shop.rpy:108
translate chinese shop_s1_gustav_47fdbfa5:

    # Sales_A "Please stop. I know where this is going. I hear this joke like fifty times a, day and I-"
    Sales_A ""

# game/scripts/shop/shop.rpy:110
translate chinese shop_s1_gustav_fe17df99:

    # Gustav "It means- *Snigger* Hehe... It means they’re- ahaha! IT MEANS THEY’RE FREE!"
    Gustav ""

# game/scripts/shop/shop.rpy:111
translate chinese shop_s1_gustav_e10e7dcd:

    # Sales_A "..."
    Sales_A ""

# game/scripts/shop/shop.rpy:112
translate chinese shop_s1_gustav_6e9c27de:

    # Gustav "BWAHAHAAHAHAHA!"
    Gustav ""

# game/scripts/shop/shop.rpy:114
translate chinese shop_s1_gustav_e10e7dcd_1:

    # Sales_A "..."
    Sales_A ""

# game/scripts/shop/shop.rpy:115
translate chinese shop_s1_gustav_da82190d:

    # Gustav "AHAAHAHAHA! HEHEHE! HOHO!"
    Gustav ""

# game/scripts/shop/shop.rpy:116
translate chinese shop_s1_gustav_1cc3ade6:

    # Sales_A "Sir, you haven’t paid for those."
    Sales_A ""

# game/scripts/shop/shop.rpy:118
translate chinese shop_s1_gustav_ac8c2bfc:

    # Gustav "AHAHAAHA! They’re FREEE! Get it?! AHAAHAHAHA!"
    Gustav ""

# game/scripts/shop/shop.rpy:119
translate chinese shop_s1_gustav_40d8b245:

    # Sales_A "I fucking hate this job."
    Sales_A ""

# game/scripts/shop/shop.rpy:132
translate chinese shop_s2_charles_28cfc94a:

    # Charles "I’m just *hic* asking if your martini mix comes in mango flavour!"
    Charles ""

# game/scripts/shop/shop.rpy:133
translate chinese shop_s2_charles_1429370a:

    # Sales_A "And I’m telling you, for the third time, that you’re pointing at pancake batter!"
    Sales_A ""

# game/scripts/shop/shop.rpy:135
translate chinese shop_s2_charles_495a0bef:

    # Charles "You’re a fucking *Hic* liar! I know a martini mix when I see one!"
    Charles ""

# game/scripts/shop/shop.rpy:136
translate chinese shop_s2_charles_06366ed7:

    # Sales_A "That’s it! Get out, or I’m calling sthe cops!"
    Sales_A ""

# game/scripts/shop/shop.rpy:138
translate chinese shop_s2_charles_8bb079cd:

    # Charles "Well, fuuuuuucck yooooouuuu!"
    Charles ""

# game/scripts/shop/shop.rpy:139
translate chinese shop_s2_charles_a3a9cdae:

    # MC "(Yikes...)"
    MC ""

# game/scripts/shop/shop.rpy:150
translate chinese shop_s3_bodyfuard_4142b31c:

    # Sales_A "It’s a real scorcher out there, isn’t it?"
    Sales_A ""

# game/scripts/shop/shop.rpy:151
translate chinese shop_s3_bodyfuard_ed634a3d:

    # Bodyguard2 "*Phew* Tell me about it! I’m sweating, like a MILF on the beach!"
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:153
translate chinese shop_s3_bodyfuard_edccad4f:

    # Bodyguard2 "Tell me, do you reckon this thing could cut through metal?"
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:154
translate chinese shop_s3_bodyfuard_bd3c4621:

    # Sales_A "Uh... Probably?"
    Sales_A ""

# game/scripts/shop/shop.rpy:155
translate chinese shop_s3_bodyfuard_124054ef:

    # Bodyguard2 "What about something hard like metal... but a bit more... boney."
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:157
translate chinese shop_s3_bodyfuard_e10e7dcd:

    # Sales_A "..."
    Sales_A ""

# game/scripts/shop/shop.rpy:158
translate chinese shop_s3_bodyfuard_0143582a:

    # Bodyguard2 "..."
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:159
translate chinese shop_s3_bodyfuard_4726733f:

    # Sales_A "Are you asking me if this saw can cut through bone?"
    Sales_A ""

# game/scripts/shop/shop.rpy:161
translate chinese shop_s3_bodyfuard_97c18056:

    # Bodyguard2 "I never said that. But now that you raised that question, can it?"
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:162
translate chinese shop_s3_bodyfuard_97d21d89:

    # Sales_A "I uh... I’ve never tried."
    Sales_A ""

# game/scripts/shop/shop.rpy:163
translate chinese shop_s3_bodyfuard_172080e5:

    # Bodyguard2 "Guess it’ll have to do. How much?"
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:164
translate chinese shop_s3_bodyfuard_f2947277:

    # Sales_A "$1200."
    Sales_A ""

# game/scripts/shop/shop.rpy:165
translate chinese shop_s3_bodyfuard_345b2c2e:

    # Bodyguard2 "$1200?! That’s like... a hundred minigames! Arghh! Fine!"
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:167
translate chinese shop_s3_bodyfuard_9d2ceefd:

    # Sales_A "Have a nice day, sir!"
    Sales_A ""

# game/scripts/shop/shop.rpy:168
translate chinese shop_s3_bodyfuard_ab696ab7:

    # Bodyguard2 "Uh huh. You too."
    Bodyguard2 ""

# game/scripts/shop/shop.rpy:181
translate chinese shop_s4_liza_33db51b9:

    # Sales_A "Is that everything for you today, m’lady?"
    Sales_A ""

# game/scripts/shop/shop.rpy:182
translate chinese shop_s4_liza_619e3a1f:

    # Liza "Yes, just the wine."
    Liza ""

# game/scripts/shop/shop.rpy:183
translate chinese shop_s4_liza_f108a4d6:

    # Sales_A "That’ll be $40."
    Sales_A ""

# game/scripts/shop/shop.rpy:185
translate chinese shop_s4_liza_f6a3b3ba:

    # Sales_A "Are you having a party tonight, then, m’lady?"
    Sales_A ""

# game/scripts/shop/shop.rpy:186
translate chinese shop_s4_liza_2d6dfece:

    # Liza "No, just sitting down by myself and relaxing. I’m alone tonight, so I’ll maybe put on a movie and-"
    Liza ""

# game/scripts/shop/shop.rpy:187
translate chinese shop_s4_liza_81004c34:

    # Sales_A "Perhaps you would like some company from a supreme gentleman like myself?"
    Sales_A ""

# game/scripts/shop/shop.rpy:189
translate chinese shop_s4_liza_1767a49d:

    # Liza "I... uh... I’m married."
    Liza ""

# game/scripts/shop/shop.rpy:190
translate chinese shop_s4_liza_b3f0676b:

    # Sales_A "You’re alone tonight though, m’lady?"
    Sales_A ""

# game/scripts/shop/shop.rpy:193
translate chinese shop_s4_liza_930506a9:

    # Liza "I’m not going to cheat on my wife!"
    Liza ""

# game/scripts/shop/shop.rpy:194
translate chinese shop_s4_liza_2a78763d:

    # Sales_A "(Dammit! Shot down again! I knew I should have worn my fedora today! Ladies love that shit!)"
    Sales_A ""

# game/scripts/shop/shop.rpy:204
translate chinese shop_s5_woman_36ed25dd:

    # Sales_A "And there you go! That’s all your shopping packed."
    Sales_A ""

# game/scripts/shop/shop.rpy:205
translate chinese shop_s5_woman_50476cc0:

    # Woman "How much does that come to?"
    Woman ""

# game/scripts/shop/shop.rpy:206
translate chinese shop_s5_woman_65052d43:

    # Sales_A "It’s sixty... uh... *Ahem*"
    Sales_A ""

# game/scripts/shop/shop.rpy:208
translate chinese shop_s5_woman_88ce0ba4:

    # Woman "Sorry, I didn’t hear you, there. How much was it?"
    Woman ""

# game/scripts/shop/shop.rpy:209
translate chinese shop_s5_woman_86af0d5e:

    # Sales_A "Sixty... *cough* S-Sixty-nine dollars and sixty nine cents..."
    Sales_A ""

# game/scripts/shop/shop.rpy:210
translate chinese shop_s5_woman_5bc0d6f5:

    # Woman "..."
    Woman ""

# game/scripts/shop/shop.rpy:211
translate chinese shop_s5_woman_e10e7dcd:

    # Sales_A "..."
    Sales_A ""

# game/scripts/shop/shop.rpy:212
translate chinese shop_s5_woman_35546594:

    # Sales_A "I’m sorry, that’s a really unfortunate coincidence."
    Sales_A ""

# game/scripts/shop/shop.rpy:213
translate chinese shop_s5_woman_8704bd4d:

    # Woman "You don’t say."
    Woman ""

# game/scripts/shop/shop.rpy:215
translate chinese shop_s5_woman_cd5ae8f9:

    # Sales_A "Thank you for shopping with us! Enjoy the rest of your day!"
    Sales_A ""

# game/scripts/shop/shop.rpy:228
translate chinese shop_s6_dean_d03ffbbe:

    # Headmaster "My man! That is a FINE, FINE selection you have there. These are exquisite."
    Headmaster ""

# game/scripts/shop/shop.rpy:229
translate chinese shop_s6_dean_bec37987:

    # Sales_A "It’s literally just convenience store cigars. We buy these in bulk."
    Sales_A ""

# game/scripts/shop/shop.rpy:231
translate chinese shop_s6_dean_35ca1679:

    # Headmaster "Mmm! And just look at that fine presentational box it comes in. What is that? Oak? Mahogany?"
    Headmaster ""

# game/scripts/shop/shop.rpy:232
translate chinese shop_s6_dean_1e3af57f:

    # Sales_A "I think that’s probably plywood."
    Sales_A ""

# game/scripts/shop/shop.rpy:233
translate chinese shop_s6_dean_68650390:

    # Headmaster "Mmm, finest plywood."
    Headmaster ""

# game/scripts/shop/shop.rpy:235
translate chinese shop_s6_dean_44edd179:

    # Headmaster "I tell you what. I’m gonna make you an offer on these."
    Headmaster ""

# game/scripts/shop/shop.rpy:236
translate chinese shop_s6_dean_84003bec:

    # Sales_A "They’re $2 each."
    Sales_A ""

# game/scripts/shop/shop.rpy:237
translate chinese shop_s6_dean_33f133d5:

    # Headmaster "$300 for the box."
    Headmaster ""

# game/scripts/shop/shop.rpy:238
translate chinese shop_s6_dean_525299f8:

    # Sales_A "Sir, I said they were $2-"
    Sales_A ""

# game/scripts/shop/shop.rpy:239
translate chinese shop_s6_dean_df0c8f63:

    # Headmaster "Oh! You drive a hard bargain, my man! What are these? Cuban cigars?"
    Headmaster ""

# game/scripts/shop/shop.rpy:240
translate chinese shop_s6_dean_107fb2d4:

    # Sales_A "I think they’re mass produced in some Chinese factory..."
    Sales_A ""

# game/scripts/shop/shop.rpy:242
translate chinese shop_s6_dean_e4780dfb:

    # Headmaster "Damn. Fine! You win! $500 - and not a penny more!"
    Headmaster ""

# game/scripts/shop/shop.rpy:243
translate chinese shop_s6_dean_c425295a:

    # Sales_A "...Sure. Okay, then."
    Sales_A ""

# game/scripts/shop/shop.rpy:245
translate chinese shop_s6_dean_1b01b1de:

    # Sales_A "(What the hell is up with this weird-ass city?!)"
    Sales_A ""

# game/scripts/shop/shop.rpy:259
translate chinese shop_s7_cindy_85feff55:

    # Sales_A "*Sigh* I can see you, you know. You’re not being sneaky."
    Sales_A ""

# game/scripts/shop/shop.rpy:260
translate chinese shop_s7_cindy_a827af8a:

    # Cindy "(Heh, he doesn’t suspect a thing!)"
    Cindy ""

# game/scripts/shop/shop.rpy:262
translate chinese shop_s7_cindy_3d93bb34:

    # Sales_A "I can clearly see you pretending to browse the sweets. You always steal the exact same thing."
    Sales_A ""

# game/scripts/shop/shop.rpy:263
translate chinese shop_s7_cindy_ee9ebfa5:

    # Cindy "(The name’s Cindy... Master thief! I’m like a shadow! No one sees me!)"
    Cindy ""

# game/scripts/shop/shop.rpy:265
translate chinese shop_s7_cindy_7ebf29c6:

    # Sales_A "I know you can hear me. I’m just going to call the cops again, like last time, and the time before that."
    Sales_A ""

# game/scripts/shop/shop.rpy:266
translate chinese shop_s7_cindy_e10e7dcd:

    # Sales_A "..."
    Sales_A ""

# game/scripts/shop/shop.rpy:268
translate chinese shop_s7_cindy_f612dc01:

    # Cindy "(Chewing gum today!)"
    Cindy ""

# game/scripts/shop/shop.rpy:269
translate chinese shop_s7_cindy_de588cc1:

    # Sales_A "*Sigh* Hello. Yes. I need the police."
    Sales_A ""

# game/scripts/shop/shop.rpy:270
translate chinese shop_s7_cindy_592e82c5:

    # Sales_A "Uh huh. Yeah, it’s the convenience store again."
    Sales_A ""

# game/scripts/shop/shop.rpy:272
translate chinese shop_s7_cindy_ffa51f21:

    # Sales_A "Yup. It’s the one who looks like a knock-off Cruella de Ville. She’s stealing sweets again!"
    Sales_A ""

# game/scripts/shop/shop.rpy:273
translate chinese shop_s7_cindy_820d7ca8:

    # Cindy "(Super sneaky!)"
    Cindy ""

# game/scripts/shop/shop.rpy:274
translate chinese shop_s7_cindy_170033c2:

    # Sales_A "What do you mean you won’t investigate?! Huh?"
    Sales_A ""

# game/scripts/shop/shop.rpy:276
translate chinese shop_s7_cindy_49e067ec:

    # Sales_A "The value of the product stolen isn’t high enough?!"
    Sales_A ""

# game/scripts/shop/shop.rpy:277
translate chinese shop_s7_cindy_0724a130:

    # Sales_A "Oh, c’mon! She’s just walking in and stealing shit, and you won’t do anything about it?! Milfy City PD is absolutely useless!"
    Sales_A ""

# game/scripts/shop/shop.rpy:278
translate chinese shop_s7_cindy_01f94ccd:

    # Cindy "*Singing* Master thief... master thief... does whatever a master thief does..."
    Cindy ""

# game/scripts/shop/shop.rpy:288
translate chinese shop_s8_BJ_f9534d51:

    # B_J "*WHEEZE*"
    B_J ""

# game/scripts/shop/shop.rpy:289
translate chinese shop_s8_BJ_e1b46c6d:

    # B_J "I gotta... *Wheeeze* I gotta hurry! Super Virgin Magical Girl vs the Tentacle Monster starts streaming in five minutes!"
    B_J ""

# game/scripts/shop/shop.rpy:291
translate chinese shop_s8_BJ_f1ac3c35:

    # B_J "Gotta get my *Wheeze* snacks!"
    B_J ""

# game/scripts/shop/shop.rpy:292
translate chinese shop_s8_BJ_12ad52ee:

    # MC "(Does he have to state every single thought he has, out loud?)"
    MC ""

# game/scripts/shop/shop.rpy:294
translate chinese shop_s8_BJ_7d69a2bb:

    # B_J "Let’s see... Each episode *Wheeze* lasts thirty minutes... If I can eat two burgers every five minutes... accounting for my ten minute wank break, and two minutes for cleanup... then I’m going to need..."
    B_J ""

# game/scripts/shop/shop.rpy:295
translate chinese shop_s8_BJ_cce94343:

    # MC "Eww..."
    MC ""

# game/scripts/shop/shop.rpy:297
translate chinese shop_s8_BJ_fd3ec9f1:

    # B_J "Fourteen burgers!"
    B_J ""

# game/scripts/shop/shop.rpy:298
translate chinese shop_s8_BJ_c7d8be29:

    # Sales_A "Excuse me, sir! You haven’t paid for those yet!"
    Sales_A ""

# game/scripts/shop/shop.rpy:300
translate chinese shop_s8_BJ_c13a77f8:

    # B_J "I’ll come back later!"
    B_J ""

# game/scripts/shop/shop.rpy:301
translate chinese shop_s8_BJ_87236d3a:

    # Sales_A "Sir, I’m going to have to ask you to-"
    Sales_A ""

# game/scripts/shop/shop.rpy:302
translate chinese shop_s8_BJ_0f76fcda:

    # B_J "DON’T GET BETWEEN A MAN AND HIS TENTACLE HENTAI!"
    B_J ""

# game/scripts/shop/shop.rpy:303
translate chinese shop_s8_BJ_e10e7dcd:

    # Sales_A "..."
    Sales_A ""

# game/scripts/shop/shop.rpy:304
translate chinese shop_s8_BJ_fc3b9a19:

    # Sales_A "(I hate this job...)"
    Sales_A ""

# game/scripts/shop/shop.rpy:509
translate chinese b5_web_cam_software_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/shop.rpy:520
translate chinese b1_binoculars_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/shop.rpy:533
translate chinese b2_camera_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/shop.rpy:547
translate chinese b3_controller_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/shop.rpy:562
translate chinese b4_spy_camera_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/shop.rpy:575
translate chinese rope_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/shop.rpy:586
translate chinese night_camera_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

