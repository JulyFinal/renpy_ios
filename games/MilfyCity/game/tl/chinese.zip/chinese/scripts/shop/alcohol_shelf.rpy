﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/shop/alcohol_shelf.rpy:58
translate chinese red_wine_buy_label_f98bef31:

    # MC "I don't have enough money."
    MC ""

# game/scripts/shop/alcohol_shelf.rpy:75
translate chinese white_wine_buy_label_73748dd2:

    # MC "(I don't have enough money."
    MC ""

