﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:11
translate chinese CR3_AS7_label_770075dc:

    # MC "(I should steal her vibrator. It's a good time for that while she's in the shop.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:20
translate chinese CR3_AS7_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:35
translate chinese CR3_AS7_label_641f1f6e:

    # MC "Afternoon, Caroline! How can I help today?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:36
translate chinese CR3_AS7_label_9de631d9:

    # Caroline "Hey there, there’s honestly not much you can do right now."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:37
translate chinese CR3_AS7_label_23d1b710:

    # MC "Huh? Why? Is something wrong?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:41
translate chinese CR3_AS7_label_2c15f9bc:

    # Caroline "God no! Nothing’s wrong. We just, sold out of our stock. I’m currently waiting for the next batch to be delivered."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:42
translate chinese CR3_AS7_label_2e1ecb2b:

    # MC "Really?! That’s amazing! Congratulations!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:43
translate chinese CR3_AS7_label_9c489ccb:

    # Caroline "Yeah, those pictures we took are spreading on the internet - like wildfire. The online store, even crashed from having too many visitors, last night!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:47
translate chinese CR3_AS7_label_3b056653:

    # Caroline "So yeah, I’m basically down to whatever you see sitting around. There were a few customers today, but most people seem interested in waiting until they see the new stuff."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:48
translate chinese CR3_AS7_label_23139095:

    # MC "Have you any idea when it will arrive?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:49
translate chinese CR3_AS7_label_e5d7e908:

    # Caroline "Hopefully in the next few days. Just keep checking back with me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:53
translate chinese CR3_AS7_label_b111ab22:

    # MC "Okay, I guess I’ll enjoy my day off, then!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:54
translate chinese CR3_AS7_label_05232910:

    # Caroline "No problem! Have fun, [player_name]!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:55
translate chinese CR3_AS7_label_43c548fa:

    # MC "Catch you later, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS7.rpy:66
translate chinese CR3_AS7_outfit4_lock_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

