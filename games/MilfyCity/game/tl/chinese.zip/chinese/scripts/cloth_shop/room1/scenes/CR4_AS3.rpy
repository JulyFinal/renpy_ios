﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:92
translate chinese CR4_AS3_label_a5bcc264:

    # MC "Hey, Caroline. What’s up?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:93
translate chinese CR4_AS3_label_c228b6d0:

    # Caroline "Oh, hey."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:94
translate chinese CR4_AS3_label_a97ffa58:

    # MC "Jeez, you sound exhausted!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:97
translate chinese CR4_AS3_label_721260b7:

    # Caroline "I know, I am! It’s just... everything is all happening at once!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:98
translate chinese CR4_AS3_label_fe368fdc:

    # Caroline "I have to man this damn till and serve the customers but in the meantime my online store is going crazy."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:99
translate chinese CR4_AS3_label_6be04924:

    # Caroline "Why the fuck did I promise next day delivery?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:102
translate chinese CR4_AS3_label_247afd0e:

    # Caroline "Say, you couldn’t lend me a hand, could you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:103
translate chinese CR4_AS3_label_650df3e5:

    # MC "What do you need me to do?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:104
translate chinese CR4_AS3_label_35d345fc:

    # Caroline "Honestly, just man the till. Serve any customers you see."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:107
translate chinese CR4_AS3_label_60b7a092:

    # Caroline "I’ll pop out the back and start packing everything up. If I’m fast enough, I MIGHT be able to hit the shipping targets!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:108
translate chinese CR4_AS3_label_e84d5d3a:

    # Caroline "What do you say? Fancy helping me out?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:109
translate chinese CR4_AS3_label_e40ae654:

    # MC "Sure, why not?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:112
translate chinese CR4_AS3_label_06079956:

    # Caroline "Thanks. You’re a lifesaver!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:113
translate chinese CR4_AS3_label_334362c6:

    # Caroline "I’ll be back at the end of the day. It isn’t too difficult - just don’t leave the till unattended, and if you make a large sale, make sure to lock up the money safely."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:114
translate chinese CR4_AS3_label_36712503:

    # MC "Got it!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:117
translate chinese CR4_AS3_label_253b4482:

    # MC "Alright, here we go."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:118
translate chinese CR4_AS3_label_282f2712:

    # MC "How difficult can a job in retail actually be?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:121
translate chinese CR4_AS3_label_fdd4935f:

    # "***5 minutes later***"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:124
translate chinese CR4_AS3_label_c5e713d1:

    # MC "That MUST be at least two hours now. Right?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:125
translate chinese CR4_AS3_label_5c31751c:

    # MC "God... just take me now..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:128
translate chinese CR4_AS3_label_7e350671:

    # "***Several Hours Later***"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:131
translate chinese CR4_AS3_label_bf2cdaed:

    # MC "...waiting for hentai games to update on Patreon is more fun than this."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:132
translate chinese CR4_AS3_label_74dd8103:

    # MC "*Yawn* That’s it. I’m calling it a day."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:139
translate chinese CR4_AS3_label_48902d58:

    # Caroline "Hey again, fancy helping a girl out?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:140
translate chinese CR4_AS3_label_e53221d0:

    # MC "Please don’t make me work the tills again. I’ll do anything. I’ll clean the toilets!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:143
translate chinese CR4_AS3_label_3b64ec2d:

    # Caroline "Only thing I need done is the tills! You’re the best, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:144
translate chinese CR4_AS3_label_1e7c57e2:

    # Caroline "Thank you!!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:147
translate chinese CR4_AS3_label_63f2ff67:

    # MC "Maybe... Maybe if I try counting the seconds pass, it’ll make time feel like it is ACTUALLY passing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:148
translate chinese CR4_AS3_label_2776523e:

    # MC "One... Two... Three..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:154
translate chinese CR4_AS3_label_7b74d118:

    # "***What feels like a hour, but is really only five minutes later***"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:157
translate chinese CR4_AS3_label_b5ed0aa2:

    # MC "(Holy shit. It made things worse.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:158
translate chinese CR4_AS3_label_7e29ca7a:

    # MC "(Focus, [player_name]. Each second that passes is another second that this job can NEVER take back off you! You’ll make it through this!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:161
translate chinese CR4_AS3_label_39dc37dc:

    # "***What feels like the wait time for an update of Malise and the Sexchine later.***"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:164
translate chinese CR4_AS3_label_522fb145:

    # MC "Move over, Sartre... Hell isn’t other people."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:165
translate chinese CR4_AS3_label_9dfad7d5:

    # MC "Hell is retail."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:172
translate chinese CR4_AS3_label_dc674572:

    # Caroline "Ahh, good to see you again! Just one more day, and I should catch up on all my shipping!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:173
translate chinese CR4_AS3_label_c9154623:

    # MC "Please... Please don’t make me work the till..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:176
translate chinese CR4_AS3_label_c30d7416:

    # Caroline "You’re overreacting! "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:177
translate chinese CR4_AS3_label_5ebdec54:

    # MC "I’ll do anything! I’ll... translate one of those Japanese hentai games you like, into English!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:178
translate chinese CR4_AS3_label_9724c6ad:

    # Caroline "Please... You don’t even speak Japanese, and I’m not going to take some crappy machine translation!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:181
translate chinese CR4_AS3_label_4530f602:

    # Caroline "Besides, how do you know I like to play those games?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:182
translate chinese CR4_AS3_label_82589145:

    # Caroline "Were you on my laptop?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:185
translate chinese CR4_AS3_label_ae3ffb77:

    # MC "Let’s just back things up! Fine, I’ll work the till!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:186
translate chinese CR4_AS3_label_0e55db4a:

    # Caroline "Great! See you in a while."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:189
translate chinese CR4_AS3_label_407b94a8:

    # MC "You can do this, [player_name]. It’s a battle of wills. You against the shop."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:190
translate chinese CR4_AS3_label_f904cbf5:

    # Customer "Umm... Who are ya talkin’ to, buddy?"
    Customer ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:191
translate chinese CR4_AS3_label_51fe68d8:

    # MC "*Sigh* Nobody."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:192
translate chinese CR4_AS3_label_ec93e8a2:

    # Customer "Tell me, do you have this one piece dress, but without the top half?"
    Customer ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:193
translate chinese CR4_AS3_label_05b33447:

    # MC "That’s a skirt. You’re looking for a fuc.... *Sigh* You’re looking for a skirt, Ma’am."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:197
translate chinese CR4_AS3_label_bcaa8285:

    # "***What feels like a long enough time for the Proclaimers to reach their destination.***"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:200
translate chinese CR4_AS3_label_8b164a52:

    # MC "Sir. You don’t have a receipt, and that item isn’t even eligible."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:201
translate chinese CR4_AS3_label_ef36e489:

    # Customer "But the sign clearly says I can return any purchase within twenty four hours."
    Customer ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:202
translate chinese CR4_AS3_label_c9f80eb8:

    # MC "The sign says “CLOTHING.” What you’ve got is a fleshlight. And I can see it has been USED!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:203
translate chinese CR4_AS3_label_5190608f:

    # Customer "This is awful customer service. Just wait till I leave you a bad review online!"
    Customer ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:204
translate chinese CR4_AS3_label_eca83b3c:

    # "***Three hours pass, each one concentrated with so much pure boredom that the US government has sanctioned it for use in enhanced interrogation in Guantanamo Bay.***"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:207
translate chinese CR4_AS3_label_183745d4:

    # MC "Kill me now."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:223
translate chinese CR4_AS3_ex_label_4923105c:

    # Charles "Yo, dickwad."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:224
translate chinese CR4_AS3_ex_label_6585aa71:

    # MC "(Aww, shit. This douchebag again.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:227
translate chinese CR4_AS3_ex_label_0da417ec:

    # Charles "Hey, don’t just ignore me, you little shit!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:228
translate chinese CR4_AS3_ex_label_b3ae11da:

    # MC "Caroline isn’t here, Charles. You can fuck right off."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:231
translate chinese CR4_AS3_ex_label_44bd1f22:

    # Charles "I’m calling bullshit. She’s never out of this crappy little store."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:232
translate chinese CR4_AS3_ex_label_cf999c38:

    # Charles "I’m here for the goddamn money. Now, where is she?"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:233
translate chinese CR4_AS3_ex_label_0ab35305:

    # MC "I told you, buddy. She’s not here. Now scram!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:236
translate chinese CR4_AS3_ex_label_2c103a36:

    # Charles "If she’s not around then I’ll just have to get the cash from her till, then."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:237
translate chinese CR4_AS3_ex_label_dc6ad299:

    # MC "Yeah, I don’t think there’s actually that much cash in the till right now. Let me check for you."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:238
translate chinese CR4_AS3_ex_label_d78fdede:

    # MC "Hmm, no cash... oh wait! I did find something for you. Here."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:241
translate chinese CR4_AS3_ex_label_f93f241d:

    # MC "Is this yours? Because you’re more than welcome to have it."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:242
translate chinese CR4_AS3_ex_label_fc462dd3:

    # Charles "That’s it - I’ve had it with you. Get out from behind that fucking desk, you little shit!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:245
translate chinese CR4_AS3_ex_label_a83d3f49:

    # MC "WHOA!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:246
translate chinese CR4_AS3_ex_label_1b201cd8:

    # MC "Hey, let go of me!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:247
translate chinese CR4_AS3_ex_label_9767b602:

    # Charles "Get out here!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:255
translate chinese CR4_AS3_ex_label_c52b0335:

    # Charles "Okay, you fucking little twerp. Where’s the money?"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:256
translate chinese CR4_AS3_ex_label_0f3a9bc8:

    # MC "There is no fucking money, Charles."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:257
translate chinese CR4_AS3_ex_label_83e23b25:

    # Charles "I know Caroline is loaded. I know this place is fucking rolling in dough. So where does the bitch keep it?"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:260
translate chinese CR4_AS3_ex_label_d477114e:

    # MC "Charles, you need to back off before you do something stupid that you’ll regret."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:261
translate chinese CR4_AS3_ex_label_559ef8e0:

    # Charles "I’m not gonna regret kicking your ass - I’ll tell you that much."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:264
translate chinese CR4_AS3_ex_label_bd4a8fd7:

    # Charles "Now, last time. Where is the fucking money?!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:265
translate chinese CR4_AS3_ex_label_47035b65:

    # MC "There is no fucking money! Are you deaf or stupid?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:268
translate chinese CR4_AS3_ex_label_ac3c607c:

    # Charles "I’m gonna break your fucking ribs."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:269
translate chinese CR4_AS3_ex_label_cbf94b91:

    # MC "Right after you break a leg."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:272
translate chinese CR4_AS3_ex_label_c5a8c406:

    # MC "Hyah!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:273
translate chinese CR4_AS3_ex_label_189cc006:

    # Charles "Whoa! Ooof!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:283
translate chinese CR4_AS3_ex_label_414d0bf6:

    # Charles "Fine. Is that how you wanna play this? You looking for a fight, bro?"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:284
translate chinese CR4_AS3_ex_label_d539ff10:

    # MC "I guess I am, dickhead."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:287
translate chinese CR4_AS3_ex_label_c87e28a0:

    # Charles "I eat little punks like you for breakfast."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:288
translate chinese CR4_AS3_ex_label_b59ebb28:

    # MC "Pfft, you weren’t so tough in that nightclub."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:294
translate chinese CR4_AS3_ex_label_6f69150d:

    # MC "Hyah! Take that!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:301
translate chinese CR4_AS3_ex_label_2871888a:

    # MC "Ugh! Fuck off!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:308
translate chinese CR4_AS3_ex_label_ade9e34c:

    # MC "Gotcha! Dammit!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:313
translate chinese CR4_AS3_ex_con1_e41293ee:

    # Charles "My turn."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:316
translate chinese CR4_AS3_ex_con1_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:320
translate chinese CR4_AS3_ex_con1_cbdc3d3b:

    # MC "Ouch!!!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:323
translate chinese CR4_AS3_ex_con1_5ad24933:

    # MC "Aaargghhh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:324
translate chinese CR4_AS3_ex_con1_0d795ffe:

    # Charles "I knew you didn’t have it in you."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:325
translate chinese CR4_AS3_ex_con1_8002cfba:

    # MC "*Spit* I’m not... done yet."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:328
translate chinese CR4_AS3_ex_con1_db520394:

    # Charles "If you won’t tell me where the fucking money is, then I guess I’ll just have to beat it out of you."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:329
translate chinese CR4_AS3_ex_con1_6a7a0219:

    # Charles "Tell me. WHERE IS THE MONEY?!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:332
translate chinese CR4_AS3_ex_con1_57e5e580:

    # Caroline "What the fuck?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:333
translate chinese CR4_AS3_ex_con1_badfa354:

    # Charles "Hah... Haha..."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:334
translate chinese CR4_AS3_ex_con1_e5a0c0f7:

    # Charles "So, you were here after all."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:337
translate chinese CR4_AS3_ex_con1_30645df5:

    # Caroline "Let him go, before I call the cops on your ass."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:338
translate chinese CR4_AS3_ex_con1_d14c05e5:

    # Charles "If you reach for a phone, I’ll pummel his fucking face. You won’t even recognise him by the time I’m done."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:339
translate chinese CR4_AS3_ex_con1_55086c18:

    # Charles "Just give me the money, and I’ll-"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:343
translate chinese CR4_AS3_ex_con1_3c726d8a_1:

    # "*WHACK*"
    ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:344
translate chinese CR4_AS3_ex_con1_047be6dc:

    # Charles "Oooooowwww......"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:347
translate chinese CR4_AS3_ex_con1_67d468ef:

    # Charles "Ouch... That... was a cheap blow..."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:348
translate chinese CR4_AS3_ex_con1_a003bd5f:

    # Charles "Fuck! God..."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:354
translate chinese CR4_AS3_ex_con1_dc9e25dc:

    # Caroline "[player_name]! Are you alright?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:355
translate chinese CR4_AS3_ex_con1_3c57cc2d:

    # MC "Y-Yeah, I’m fine... just catching my breath."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:356
translate chinese CR4_AS3_ex_con1_8eea1e6f:

    # Charles "You fucking... bitch! Ahh..."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:359
translate chinese CR4_AS3_ex_con1_5e21bf1b:

    # Caroline "What happened?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:360
translate chinese CR4_AS3_ex_con1_2ead643b:

    # MC "He was trying to rob the shop. I stopped him from getting money from the till."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:361
translate chinese CR4_AS3_ex_con1_43d139c1:

    # Caroline "Fucking creep. That’s it, I’m calling the police."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:364
translate chinese CR4_AS3_ex_con1_6a2ec7f3:

    # Charles "You... owe me that fucking... money."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:365
translate chinese CR4_AS3_ex_con1_27fa8f7e:

    # Charles "Jesus Christ, this hurts!!!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:366
translate chinese CR4_AS3_ex_con1_c9d65c1f:

    # Caroline "I owe you nothing, Charles. Get yourself a fucking job."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:367
translate chinese CR4_AS3_ex_con1_0e2bff03:

    # Charles "Grrr.... If you won’t give me cash..."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:370
translate chinese CR4_AS3_ex_con1_a9f15637:

    # Charles "Then I guess I’ll just nab this!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:371
translate chinese CR4_AS3_ex_con1_47a9ad53:

    # Caroline "NOOO!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:372
translate chinese CR4_AS3_ex_con1_54da9fa1:

    # Charles "Got it!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:375
translate chinese CR4_AS3_ex_con1_7cff0084:

    # Charles "Ahahaha! So long, fuckers!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:376
translate chinese CR4_AS3_ex_con1_6a7af8e1:

    # Caroline "No! Come back!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:379
translate chinese CR4_AS3_ex_con1_2ee21786:

    # Caroline "Wait! I can give you cash! COME BACK!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:380
translate chinese CR4_AS3_ex_con1_d719e3b7:

    # Charles "Too slow, bitches!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:383
translate chinese CR4_AS3_ex_con1_80ce7427:

    # Caroline "M-My granny’s necklace..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:384
translate chinese CR4_AS3_ex_con1_a47e7ea4:

    # MC "I’ll go after him."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:385
translate chinese CR4_AS3_ex_con1_830a2f79:

    # Caroline "Don’t... you can’t beat him in a fight. You’ll just get yourself killed."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:388
translate chinese CR4_AS3_ex_con1_35de7c4f:

    # MC "What am I supposed to do, then? I can’t just let him get away!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:389
translate chinese CR4_AS3_ex_con1_2e8ba6dc:

    # Caroline "We’ll think of something later... Right now, just stay here."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:392
translate chinese CR4_AS3_ex_con1_120540a3:

    # Caroline "...I can’t believe he actually took it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:393
translate chinese CR4_AS3_ex_con1_5bab2f89:

    # Caroline "It was the only thing I had left of hers..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:394
translate chinese CR4_AS3_ex_con1_83fd4555:

    # MC "It’s not too late, I can still chase him down!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:397
translate chinese CR4_AS3_ex_con1_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:398
translate chinese CR4_AS3_ex_con1_e1972d25:

    # MC "Do you want me to run after him?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:399
translate chinese CR4_AS3_ex_con1_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:400
translate chinese CR4_AS3_ex_con1_42549153:

    # MC "Hey, Caroline?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:403
translate chinese CR4_AS3_ex_con1_79da9db5:

    # Caroline "*Sniff*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:404
translate chinese CR4_AS3_ex_con1_996c1261:

    # MC "H-Hey! It’s going to be alright."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:405
translate chinese CR4_AS3_ex_con1_eb710caf:

    # Caroline "When I had that... that necklace... it was like she was still with me..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:408
translate chinese CR4_AS3_ex_con1_e43ab76f:

    # MC "Hey, everything is going to be okay. I promise."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:409
translate chinese CR4_AS3_ex_con1_dd22072a:

    # Caroline "*Sob* He’s a monster... He knew how much it meant to me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:410
translate chinese CR4_AS3_ex_con1_5c6a3eba:

    # MC "(He must have known it was valuable too, if he tried to steal it.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:413
translate chinese CR4_AS3_ex_con1_ca91436e:

    # MC "C’mon, we’ll think of something. We’ll find out where he lives and we’ll-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:414
translate chinese CR4_AS3_ex_con1_1343eed7:

    # Caroline "It’s over, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:415
translate chinese CR4_AS3_ex_con1_e48d3e4d:

    # MC "But-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:418
translate chinese CR4_AS3_ex_con1_7a772b7e:

    # Caroline "He’ll use Granny’s necklace *Sob* to pay off his debts, and then..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:419
translate chinese CR4_AS3_ex_con1_d90e9fae:

    # Caroline "...then he’ll *Sniff* never hurt me again. Okay? *Sob* This is the end."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:420
translate chinese CR4_AS3_ex_con1_04a3b7e8:

    # MC "No, no, no... This isn’t how it’s going to end."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:423
translate chinese CR4_AS3_ex_con1_3e657583:

    # Caroline "Don’t go after him. Please."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:425
translate chinese CR4_AS3_ex_con1_66eaf208:

    # Caroline "He’s a monster. Just... stay away from him. He already took our gran’s necklace from me - I don’t want him taking you as well."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:427
translate chinese CR4_AS3_ex_con1_7609902a:

    # Caroline "He’s a monster. Just... stay away from him. He already took my gran’s necklace from me - I don’t want him taking you as well."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:430
translate chinese CR4_AS3_ex_con1_01da0df3:

    # MC "Maybe if we-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:431
translate chinese CR4_AS3_ex_con1_782b010f:

    # Caroline "I said, no! He has no reason to come back here anymore. It’s over, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:434
translate chinese CR4_AS3_ex_con1_10454317:

    # Caroline "I’m... sorry for raising my voice at you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:435
translate chinese CR4_AS3_ex_con1_1aca347b:

    # MC "Hey, it’s okay. Shall we call the police?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:436
translate chinese CR4_AS3_ex_con1_b3d7a4fe:

    # Caroline "No. If we’re lucky he’ll go to prison for a few months."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:439
translate chinese CR4_AS3_ex_con1_b210499f:

    # Caroline "Then he’ll just be released and he’ll want revenge on me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:440
translate chinese CR4_AS3_ex_con1_0cc57aa7:

    # Caroline "He made my life a living hell, the first time I tried to leave him. At this point... I just want him gone for good."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:443
translate chinese CR4_AS3_ex_con1_e98a0994:

    # Caroline "Don’t you ever go after him or that necklace. Do you promise?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:444
translate chinese CR4_AS3_ex_con1_a1e764be:

    # MC "What, I-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:445
translate chinese CR4_AS3_ex_con1_3b24bafe:

    # Caroline "Promise me that you won’t go after him or the necklace."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:448
translate chinese CR4_AS3_ex_con1_d1141f26:

    # MC "... I promise."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:449
translate chinese CR4_AS3_ex_con1_b1526488:

    # MC "(I’m not leaving things like this though. That son of a bitch is going to pay for what he’s done.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:466
translate chinese CR4_AS3_ex_adress_lab_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:481
translate chinese CR4_AS3_ex_adress_lab_7662ad36:

    # Caroline "Hey, are you ready to go now? I don’t think we can hold off much longer on trying to get back my necklace."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:482
translate chinese CR4_AS3_ex_adress_lab_d2f71e7b:

    # Caroline "If you’re not free today I might just bring some of my friends along, or maybe call the police."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:483
translate chinese CR4_AS3_ex_adress_lab_11ce70bb:

    # MC "Hey, Caroline, there’s no need to do any of that."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:486
translate chinese CR4_AS3_ex_adress_lab_661710c9:

    # Caroline "Great! So, you’re ready to go? I’ll grab my jacket."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:487
translate chinese CR4_AS3_ex_adress_lab_fbef2377:

    # MC "Umm... There’s no need to go after Charles any longer."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:488
translate chinese CR4_AS3_ex_adress_lab_43cdc422:

    # Caroline "What do you mean?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:489
translate chinese CR4_AS3_ex_adress_lab_40637b74:

    # MC "I’ve... uh... taken care of him myself. He won’t ever bother you again."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:492
translate chinese CR4_AS3_ex_adress_lab_ba4dc51f:

    # Caroline "You WHAT?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:493
translate chinese CR4_AS3_ex_adress_lab_bc7a1f4f:

    # MC "Relax! I’m fine! See? Not a scratch on me-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:496
translate chinese CR4_AS3_ex_adress_lab_c827928b:

    # Caroline "The asshole is a grade A psychopath! What if Charles had decided to break your legs?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:497
translate chinese CR4_AS3_ex_adress_lab_c48dd0e8:

    # MC "I-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:498
translate chinese CR4_AS3_ex_adress_lab_c79ff45c:

    # Caroline "Or worse - what if you never even made it back here today?! What if he killed you!?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:499
translate chinese CR4_AS3_ex_adress_lab_286f1ff4:

    # Caroline "Did you think that I’d just move on with my life?! I love you, you stupid fool!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:500
translate chinese CR4_AS3_ex_adress_lab_fcd35044:

    # Caroline "You PROMISED me that you wouldn’t go there alone!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:503
translate chinese CR4_AS3_ex_adress_lab_058f0d8f:

    # MC "Do you know that fear you’re feeling right now? That’s how I felt at the thought of bringing you there. I knew how dangerous Charles was."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:504
translate chinese CR4_AS3_ex_adress_lab_dfada5af:

    # MC "But Caroline, he’s gone now. He won’t hurt you or me ever again."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:505
translate chinese CR4_AS3_ex_adress_lab_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:506
translate chinese CR4_AS3_ex_adress_lab_0e490536:

    # MC "We won. It’s over. "
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:509
translate chinese CR4_AS3_ex_adress_lab_2cc70eb5:

    # Caroline "*Sigh*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:510
translate chinese CR4_AS3_ex_adress_lab_5f8d1f53:

    # Caroline "What actually happened?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:511
translate chinese CR4_AS3_ex_adress_lab_02c7b91a:

    # MC "I travelled over to his place and I put him in his place."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:514
translate chinese CR4_AS3_ex_adress_lab_41d51ccf:

    # Caroline "Really? You beat up a guy, like a foot taller than you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:515
translate chinese CR4_AS3_ex_adress_lab_27fd3624:

    # MC "Err... yeah!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:516
translate chinese CR4_AS3_ex_adress_lab_c039ab21:

    # Caroline "In a one-to-one fight?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:517
translate chinese CR4_AS3_ex_adress_lab_d8a03296:

    # MC "Yup..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:520
translate chinese CR4_AS3_ex_adress_lab_3ca876f1:

    # Caroline "Without even getting a single scratch on you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:521
translate chinese CR4_AS3_ex_adress_lab_b4d34d0e:

    # MC "I... uh... I’d a lot of adrenaline running through me at the time."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:522
translate chinese CR4_AS3_ex_adress_lab_b1b954a5:

    # Caroline "Fair enough."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:525
translate chinese CR4_AS3_ex_adress_lab_a13db3f5:

    # Caroline "Oh! You didn’t get the necklace, did you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:526
translate chinese CR4_AS3_ex_adress_lab_6c2b6bfb:

    # MC "Ye-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:527
translate chinese CR4_AS3_ex_adress_lab_4080eb00:

    # Caroline "Wait, nevermind. The asshole already sold it, didn’t he?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:530
translate chinese CR4_AS3_ex_adress_lab_d8ed92e7:

    # MC "(She didn’t even let me answer the question... I’ve got it in the pocket of my jeans right now.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:531
translate chinese CR4_AS3_ex_adress_lab_deb1aea7:

    # Caroline "It was the last thing I had from Granny..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:532
translate chinese CR4_AS3_ex_adress_lab_877e0021:

    # MC "(Right, I’ll give her the necklace now before she gets any more upset.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:535
translate chinese CR4_AS3_ex_adress_lab_36f34a20:

    # Caroline "I guess I’ll just have to move on... It was just a piece of metal anyway."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:536
translate chinese CR4_AS3_ex_adress_lab_24083200:

    # MC "Caroline, I-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:539
translate chinese CR4_AS3_ex_adress_lab_38bd6620:

    # Caroline "I’m dwelling too much on the past! We should be celebrating right now!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:540
translate chinese CR4_AS3_ex_adress_lab_d1f996a8:

    # MC "But, I-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:541
translate chinese CR4_AS3_ex_adress_lab_bdeede46:

    # Caroline "We're going somewhere this weekend!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:542
translate chinese CR4_AS3_ex_adress_lab_0b6090ee:

    # MC "Huh? Where? At the weekend?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:545
translate chinese CR4_AS3_ex_adress_lab_ecba7dc5:

    # Caroline "Only the best restaurant in town! My treat, for you helping me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:546
translate chinese CR4_AS3_ex_adress_lab_786e335b:

    # MC "(Hold on - this could actually be a GREAT way to surprise Caroline with the necklace! She won’t expect me to have it! I can give it to her during the meal!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:547
translate chinese CR4_AS3_ex_adress_lab_87368dab:

    # MC "That sounds amazing! I’m looking forward to it!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:548
translate chinese CR4_AS3_ex_adress_lab_356af622:

    # Caroline "I’ll see you there at weekend!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:566
translate chinese CR4_AS3_ex_adress_lab_f03e068f:

    # Caroline "Hey [player_name], I’m ready to get my necklace back whenever you are!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:567
translate chinese CR4_AS3_ex_adress_lab_55eb5192:

    # MC "Uh, about that... (There’s no way I’m bringing her along on such a dangerous task!) I’m not quite ready yet."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:570
translate chinese CR4_AS3_ex_adress_lab_d1717765:

    # MC "Can you give me some more time to prepare?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:571
translate chinese CR4_AS3_ex_adress_lab_8a84cfcd:

    # Caroline "Sure. Don’t take too long though. I don’t want Charles pawning off my necklace to some scumbag!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:583
translate chinese CR4_AS3_ex_adress_lab_3b6891ac:

    # MC "Hey, Caroline!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:584
translate chinese CR4_AS3_ex_adress_lab_02272537:

    # Caroline "Afternoon, [player_name]. What brings you in today? Just dropping by to visit your AMAZING girlfriend?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:585
translate chinese CR4_AS3_ex_adress_lab_8ff9da30:

    # MC "Haha, I wish it was just that..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:588
translate chinese CR4_AS3_ex_adress_lab_4e39bc60:

    # Caroline "Is something wrong, [player_name]?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:589
translate chinese CR4_AS3_ex_adress_lab_7a80d748:

    # MC "I need Charles’s address."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:590
translate chinese CR4_AS3_ex_adress_lab_1175c56d:

    # Caroline "What? Why on Earth would you want that?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:592
translate chinese CR4_AS3_ex_adress_lab_ebb672b0:

    # MC "I’m gonna kick his ass and get our grandma’s necklace back."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:594
translate chinese CR4_AS3_ex_adress_lab_5e96f040:

    # MC "I’m gonna kick his ass and get your grandma’s necklace back."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:597
translate chinese CR4_AS3_ex_adress_lab_567983b1:

    # Caroline "Absolutely not."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:598
translate chinese CR4_AS3_ex_adress_lab_6ab5dab7:

    # MC "I’m sorry, Caroline. I’m not giving up that easily. You mean the world to me, and that necklace meant the world to you. I’m not going down this round without putting up a hell of a fight."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:601
translate chinese CR4_AS3_ex_adress_lab_ac20b64c:

    # Caroline "*Sigh* There’s no way I’m talking you out of this, is there?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:602
translate chinese CR4_AS3_ex_adress_lab_aa5cc619:

    # MC "Not this time."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:603
translate chinese CR4_AS3_ex_adress_lab_7f7aa3a2:

    # Caroline "Fine..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:606
translate chinese CR4_AS3_ex_adress_lab_312aeee7:

    # Caroline "But I’m only giving you his address if you accept two conditions:"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:607
translate chinese CR4_AS3_ex_adress_lab_0c630183:

    # MC "What are they?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:608
translate chinese CR4_AS3_ex_adress_lab_aa0ae6f3:

    # Caroline "Firstly, you’re NOT going there by yourself. I’m not risking you getting hurt over a silly bit of metal."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:611
translate chinese CR4_AS3_ex_adress_lab_1040f3c0:

    # MC "Your necklace isn’t “a silly bit of metal”, but what’s the second condition?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:612
translate chinese CR4_AS3_ex_adress_lab_a3508bf7:

    # Caroline "When it’s compared to your life it is!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:613
translate chinese CR4_AS3_ex_adress_lab_4b4d4638:

    # MC "Fine - what’s the second condition?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:616
translate chinese CR4_AS3_ex_adress_lab_cbed0b97:

    # Caroline "That I’M coming with you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:617
translate chinese CR4_AS3_ex_adress_lab_9cdac25f:

    # MC "What?! I can bring someone else! Like [Dad_name], or a friend from college to back me up!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:618
translate chinese CR4_AS3_ex_adress_lab_77381744:

    # Caroline "Nope, it’s going to be me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:619
translate chinese CR4_AS3_ex_adress_lab_7f30002f:

    # MC "(I guess I’ll have to lie to Caroline now. There’s no way I’m letting her, near that creep again. If she ended up getting hurt I’d never forgive myself.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:620
translate chinese CR4_AS3_ex_adress_lab_19e27304:

    # MC "Fine, it’s a deal."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:623
translate chinese CR4_AS3_ex_adress_lab_d80a2366:

    # Caroline "Alright, hit me up whenever you’re ready to head out."
    Caroline ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:290
    old "Punch"
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:290
    old "High Kick"
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR4_AS3.rpy:290
    old "Low Kick"
    new ""

