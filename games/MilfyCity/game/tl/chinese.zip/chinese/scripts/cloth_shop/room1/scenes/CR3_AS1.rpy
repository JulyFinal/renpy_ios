﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:14
translate chinese CR3_AS1_label_f93a9a05:

    # MC "(Maybe I should speak to her while she's not in the shop? She probably thinking about the stuff we did in here...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:25
translate chinese CR3_AS1_label_5630e9ed:

    # MC "Hey, Caroline. I was walking past, so I thought I’d drop in to check how you’re doing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:26
translate chinese CR3_AS1_label_be59ac27:

    # Caroline "Sorry, I’m up to my eyeballs with work at the minute. Please leave."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:27
translate chinese CR3_AS1_label_4a818cbe:

    # MC "Huh? So cold.. Did I do something wrong?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:29
translate chinese CR3_AS1_label_d3a299ad:

    # Caroline "You know that the deal is over... I.. I just want to move on. Give me a few days."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:30
translate chinese CR3_AS1_label_f93a9a05_1:

    # MC "(Maybe I should speak to her while she's not in the shop? She probably thinking about the stuff we did in here...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:40
translate chinese CR3_AS1_label_da5b7ee5:

    # MC "(I've promised Caroline that I'll talk with Violet. She should be in the dark alley.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:57
translate chinese CR3_AS1_label_4316d460:

    # MC "Hey, Caroline. I was walking past, so I thought I’d drop in, to check how you’re doing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:58
translate chinese CR3_AS1_label_fccfc74a:

    # Caroline "Hi, [player_name]. Sorry, I’m - up to my eyeballs - with work, at the minute."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:59
translate chinese CR3_AS1_label_cd37f66b:

    # MC "You look stressed, what’s wrong?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:60
translate chinese CR3_AS1_label_45dda5e4:

    # Caroline "*Sigh* I still haven’t found a staff member to replace you. The worst part is I bought a whole new set of clothes, but these ones are for couples so I’m going to need to get a SECOND model."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:64
translate chinese CR3_AS1_label_62ea6e50:

    # MC "I could help! I don’t mind!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:65
translate chinese CR3_AS1_label_1884d5c0:

    # Caroline "Listen - I really appreciate the offer. You need to understand that the deal is NOT coming back. I’ll find another way to pay you for your time - but things can’t go back to the way they were."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:66
translate chinese CR3_AS1_label_2b435b13:

    # MC "Fine... I understand. If I volunteer to help, model the clothes, are we good to start work, then?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:71
translate chinese CR3_AS1_label_ef1a1cf2:

    # Caroline "Eh, not quite. We’re halfway there, though!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:72
translate chinese CR3_AS1_label_49a6512e:

    # MC "Huh? What’s missing?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:73
translate chinese CR3_AS1_label_e3d11088:

    # Caroline "Think about it? If we’re BOTH modelling clothes, then who is there to take the pictures?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:74
translate chinese CR3_AS1_label_ce13694a:

    # MC "Ahh... bugger."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:78
translate chinese CR3_AS1_label_d1f02fa3:

    # Caroline "I’ve burned through, my list of potential candidates. None of them are free to work for me. It leaves me with only two options."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:79
translate chinese CR3_AS1_label_b6fbbabd:

    # MC "Who?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:80
translate chinese CR3_AS1_label_85c1639a:

    # Caroline "Well, the first choice was you. So that leaves my second... Violet."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:84
translate chinese CR3_AS1_label_1e6a1418:

    # Caroline "Can you see if you can track Violet down? Last I heard, she was still hanging around - that mangy old alleyway."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:85
translate chinese CR3_AS1_label_192183f0:

    # MC "Sure! No problem. I’ll see if I can find her, then we can - get cracking - on photographing this new range."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:86
translate chinese CR3_AS1_label_10c5449c:

    # MC "I’m super excited to see what you’ve bought!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS1.rpy:87
translate chinese CR3_AS1_label_e54c8ed8:

    # Caroline "Trust me - these new clothes are going to sell like hotcakes!"
    Caroline ""

