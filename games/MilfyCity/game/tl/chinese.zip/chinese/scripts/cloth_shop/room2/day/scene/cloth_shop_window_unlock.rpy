﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room2/day/scene/cloth_shop_window_unlock.rpy:10
translate chinese cloth_shop_window_unlock_label_a8b241ee:

    # "Do you want to unlock the window?"
    ""

translate chinese strings:

    # game/scripts/cloth_shop/room2/day/scene/cloth_shop_window_unlock.rpy:12
    old "Yes."
    new ""

    # game/scripts/cloth_shop/room2/day/scene/cloth_shop_window_unlock.rpy:12
    old "No."
    new ""

