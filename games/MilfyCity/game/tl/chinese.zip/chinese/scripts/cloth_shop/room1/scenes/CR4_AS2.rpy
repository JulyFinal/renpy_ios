﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:28
translate chinese CR4_AS2_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:42
translate chinese CR4_AS2_label_87047fdf:

    # Caroline "I said, get the hell out of here!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:43
translate chinese CR4_AS2_label_4cf689e9:

    # MC "(Huh? Who’s Caroline screaming at?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:44
translate chinese CR4_AS2_label_eaa96278:

    # MC "(Aww, nuts. I recognise this douchebag - it’s Caroline’s dickhead ex-boyfriend I met in the nightclub! What was his name? Charles or something like that?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:48
translate chinese CR4_AS2_label_4d80c089:

    # Charles "I ain’t leaving here without that money!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:49
translate chinese CR4_AS2_label_36401f40:

    # Caroline "Okay, two points, Charles: First of all, you’re not getting a single penny of my money, and secondly: if you refuse to leave, I’m going to call the cops."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:50
translate chinese CR4_AS2_label_55989f4b:

    # MC "(What the hell have I walked in on?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:54
translate chinese CR4_AS2_label_579859b6:

    # Charles "Listen here, you bitch. That nightclub owner is after me for causing damage to their bar."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:55
translate chinese CR4_AS2_label_87bf1547:

    # Charles "If I don’t come up with two grand by the end of the week, they’ve threatened to take me to court!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:56
translate chinese CR4_AS2_label_5d95ea59:

    # Caroline "Tough shit! Not my problem!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:60
translate chinese CR4_AS2_label_a92ef708:

    # Charles "Oh yeah? I think it IS your problem. Because I wasn’t the one who smashed up that bar."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:61
translate chinese CR4_AS2_label_91d2bfcf:

    # Charles "It was that dorky little creep you were hanging out with. The one who ASSAULTED me!"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:62
translate chinese CR4_AS2_label_7f5a63ff:

    # Caroline "Fuck off, Charles. We both know that’s not true. At least a dozen people saw you behaving like a twat that night."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:63
translate chinese CR4_AS2_label_91d86051:

    # Charles "I’m going to-"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:67
translate chinese CR4_AS2_label_8244aafe:

    # Caroline "Enough! You’re not taking any of MY money, to fix your own fucked up life!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:68
translate chinese CR4_AS2_label_ed2d73c1:

    # MC "(I was considering intervening... but it looks like Caroline is holding her own!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:69
translate chinese CR4_AS2_label_000dc083:

    # Charles "But it-"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:73
translate chinese CR4_AS2_label_a1c9f65e:

    # Caroline "Now, get the fuck out of my shop, before I shove a wooden pole up your ass and use you as a mannequin to display my clothes!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:74
translate chinese CR4_AS2_label_3bba3122:

    # Charles "Grr..."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:75
translate chinese CR4_AS2_label_385dbc01:

    # Charles "(I’ll get that money out of you yet, you ignorant bitch!)"
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:79
translate chinese CR4_AS2_label_4a1fa122:

    # Charles "I’m getting that money, Caroline. I’m not letting you and that fucking little twerp screw me over."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:80
translate chinese CR4_AS2_label_2dbf6c97:

    # Caroline "Out. Now."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:84
translate chinese CR4_AS2_label_9ad720a5:

    # Charles "Oh, look who just showed up."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:85
translate chinese CR4_AS2_label_b419705c:

    # MC "(Fuck - he noticed me.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:86
translate chinese CR4_AS2_label_2e3e4948:

    # Caroline "Leave [player_name] out of this. This is between you and me, Charles."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:90
translate chinese CR4_AS2_label_75a91445:

    # Charles "Pfft... Get outta my way, dick."
    Charles ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:91
translate chinese CR4_AS2_label_1b08a95a:

    # MC "Ooof!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:92
translate chinese CR4_AS2_label_98b1ae84:

    # MC "(Asshole...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:99
translate chinese CR4_AS2_label_1c15bdaa:

    # Caroline "Grrr... What a fucking..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:100
translate chinese CR4_AS2_label_a823bcb8:

    # MC "What the heck was that about? How did he get in here?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:101
translate chinese CR4_AS2_label_b15ba35d:

    # Caroline "The asshole just barged his way into the back of the shop. I couldn’t stop him."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:105
translate chinese CR4_AS2_label_8c759393:

    # MC "Shit! He didn’t hurt you, did he?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:106
translate chinese CR4_AS2_label_58c3ba09:

    # Caroline "No, but he just stormed in here and started looking for money. Thankfully I had it locked away."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:107
translate chinese CR4_AS2_label_c41378e0:

    # MC "Have you called the police?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:111
translate chinese CR4_AS2_label_d52ae1dd:

    # Caroline "And what good would that do?! They’d close my business down for a day or two, while they gather evidence!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:112
translate chinese CR4_AS2_label_bacf3f22:

    # Caroline "I’d probably end up LOSING more revenue than Charles wanted off me in the first place!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:113
translate chinese CR4_AS2_label_906b3fa9:

    # MC "O-Okay! How about we calm down and talk about this, to see what we can do?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:114
translate chinese CR4_AS2_label_341dffb0:

    # Caroline "I am calm!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:115
translate chinese CR4_AS2_label_9405f8da:

    # MC "Umm... Your fist?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:119
translate chinese CR4_AS2_label_6be9ca99:

    # Caroline "Shit... Sorry! I was still caught up in the moment, there. That asshole just put me on edge."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:120
translate chinese CR4_AS2_label_41427e09:

    # MC "Relax, Caroline. I understand. It’s okay."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:121
translate chinese CR4_AS2_label_ff1a227e:

    # MC "What can I do to help?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:125
translate chinese CR4_AS2_label_a9ad7dde:

    # Caroline "Nothing, I’m fine. I said ‘no’ to the bastard. He’s not getting any money from me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:126
translate chinese CR4_AS2_label_8b6a4764:

    # Caroline "Thanks for being there though. If you weren’t around, he might have been brave enough to give me a black eye. (Again...)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:127
translate chinese CR4_AS2_label_bca4a6d4:

    # MC "Shit. Well, I’m just glad you’re safe."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:131
translate chinese CR4_AS2_label_41cb257b:

    # Caroline "Listen, I don’t want you getting involved in this, [player_name]. Can you promise me that?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:132
translate chinese CR4_AS2_label_64d913e9:

    # MC "Why? I was there at the nightclub. I saw what happened!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:133
translate chinese CR4_AS2_label_b34c2792:

    # Caroline "I can handle Charles. He left with his tail between his legs today. He won’t show his face around here again for a while."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:137
translate chinese CR4_AS2_label_d307ed31:

    # MC "Well... if you need anything, can you AT LEAST promise to call me?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:138
translate chinese CR4_AS2_label_f2847e8f:

    # Caroline "I’ll be fine."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:140
translate chinese CR4_AS2_label_128a3241:

    # MC "Please? I don’t want you dealing with this dickhead by yourself. I mean... what if he attacked you or tried to rape you in here?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:142
translate chinese CR4_AS2_label_2a7b2c85:

    # MC "Please? I don’t want you dealing with this dickhead by yourself. I mean... what if he attacked you in here?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:146
translate chinese CR4_AS2_label_2cc70eb5:

    # Caroline "*Sigh*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:147
translate chinese CR4_AS2_label_86623297:

    # Caroline "Alright, I promise I’ll call you if things ever get out of hand."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:148
translate chinese CR4_AS2_label_763acb62:

    # MC "Thanks, Caroline. I appreciate it."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:152
translate chinese CR4_AS2_label_0d27fef1:

    # Caroline "Hey, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:153
translate chinese CR4_AS2_label_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:154
translate chinese CR4_AS2_label_30deabae:

    # Caroline "Do you seriously think I couldn’t take that dick on in a fight?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:155
translate chinese CR4_AS2_label_eb547eca:

    # MC "Haha! I’m sure you could kick his ass, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS2.rpy:156
translate chinese CR4_AS2_label_b57f3c87:

    # Caroline "I reckon I could as well. Catch you later, [player_name]."
    Caroline ""

