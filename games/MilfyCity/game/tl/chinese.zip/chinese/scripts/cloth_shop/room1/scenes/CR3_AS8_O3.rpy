﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:66
translate chinese CR3_AS8_O3_3b212eaf:

    # MC "(What the fuck is this outfit, even supposed to be?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:67
translate chinese CR3_AS8_O3_b23bf060:

    # MC "(I mean, the gloves are the only part of the costume, that’s ALMOST normal.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:68
translate chinese CR3_AS8_O3_5c7bfd1a:

    # MC "(I swear to God, these cosplay fanatics get weirder every year!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:72
translate chinese CR3_AS8_O3_5767d4ad:

    # MC "Caroline!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:73
translate chinese CR3_AS8_O3_cb52f098:

    # Caroline "Yes?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:74
translate chinese CR3_AS8_O3_779af57b:

    # MC "What did you say this outfit was supposed to be again?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:75
translate chinese CR3_AS8_O3_0a64fd74:

    # Caroline "It’s a superhero costume!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:80
translate chinese CR3_AS8_O3_6b0a9f22:

    # Violet "What kind of superhero has horns, and - absolutely no chest armour?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:81
translate chinese CR3_AS8_O3_f506c10a:

    # Caroline "It’s Dragon Man! Do neither of you watch anime?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:82
translate chinese CR3_AS8_O3_54572fe2:

    # MC "Nope."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:83
translate chinese CR3_AS8_O3_771eb2c2:

    # Violet "Not really."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:87
translate chinese CR3_AS8_O3_2ca570c6:

    # Caroline "Fine. I guess it’s up to me, to explain the scenario for this one, then."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:88
translate chinese CR3_AS8_O3_af096535:

    # Caroline "Dragon Man got bitten by a radioactive dragon, so he’s now half dragon."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:89
translate chinese CR3_AS8_O3_eb5fb50b:

    # MC "I guess that’s... kinda cool?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:90
translate chinese CR3_AS8_O3_1cba1248:

    # Caroline "I’ll be playing, his long-term love interest, Princess White Lady."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:94
translate chinese CR3_AS8_O3_927bfcb3:

    # Violet "Princess... White Lady?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:95
translate chinese CR3_AS8_O3_38845e85:

    # Caroline "The English translation sucks. Don’t blame me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:96
translate chinese CR3_AS8_O3_a3d9a447:

    # Caroline "Anyway, Princess White Lady and Dragon Man were on a quest - Princess White Lady got captured, and Dragon Man heroically rescued her."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:100
translate chinese CR3_AS8_O3_5e2df1bb:

    # Caroline "Is that enough background, for you two to work with?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:101
translate chinese CR3_AS8_O3_6c8e8147:

    # Violet "Sort of... I guess?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:102
translate chinese CR3_AS8_O3_c716ddcd:

    # MC "Yeah, I think so..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:106
translate chinese CR3_AS8_O3_20ed2ff6:

    # Caroline "Good. I could explain more, but it would take me HOURS! The lore for Dragon Man, is surprisingly deep."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:107
translate chinese CR3_AS8_O3_d8157b41:

    # Violet "...no kidding. This Wikipedia article scrolls forever!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:108
translate chinese CR3_AS8_O3_0129450e:

    # MC "Alright - let’s get started. What are we gonna do?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:109
translate chinese CR3_AS8_O3_a8188c18:

    # Caroline "You’ve just rescued me - so I’m still on my knees, looking up to you, as my hero. I want you to reach out, as if you’re going to put your thumb in my mouth - but just hold before it goes in."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:113
translate chinese CR3_AS8_O3_8f452ab3:

    # MC "It’s a rather... unusual pose."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:114
translate chinese CR3_AS8_O3_f5841f80:

    # Caroline "We’re re-enacting the art of the second season’s promo trailer."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:118
translate chinese CR3_AS8_O3_f4a4d358:

    # MC "That sorta explains it... I guess."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:119
translate chinese CR3_AS8_O3_1830444e:

    # MC "(Damn, I just noticed the pink high heel shoes, she’s wearing. They look so sexy on her!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:120
translate chinese CR3_AS8_O3_0f586402:

    # Caroline "This isn’t the most comfortable position to be sitting in. Can we get things rolling?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:124
translate chinese CR3_AS8_O3_e0d74927:

    # Violet "Okay, are you two finally ready?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:125
translate chinese CR3_AS8_O3_9217205e:

    # MC "Yup! Let’s get this show on the road!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:148
translate chinese CR3_AS8_O3_con2_73c08e0b:

    # MC "Well? Are you happy with the pictures?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:149
translate chinese CR3_AS8_O3_con2_f44a3d19:

    # Caroline "I think I will be! I’m hoping to break into the Japanese market, overseas. It won’t be an easy ride - but if we keep up this targeted advertising, then I stand a solid chance."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:150
translate chinese CR3_AS8_O3_con2_5cd480ec:

    # MC "Good to hear!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:154
translate chinese CR3_AS8_O3_con2_11f74975:

    # Violet "Hey guys, I gotta head on, here. My mom needs me to pick up some groceries, on the way home."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:155
translate chinese CR3_AS8_O3_con2_77dc0cf9:

    # MC "No problem. Catch you later, Violet."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:156
translate chinese CR3_AS8_O3_con2_0e3ded65:

    # Caroline "Thanks for your help today! See you later!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:160
translate chinese CR3_AS8_O3_con2_ded242e0:

    # MC "Well, it’s just you and me now."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:161
translate chinese CR3_AS8_O3_con2_6ad95b42:

    # Caroline "Do you have any plans for the evening?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:162
translate chinese CR3_AS8_O3_con2_9df30360:

    # MC "No, I’m free to spend some time here, if you want to relax together."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:166
translate chinese CR3_AS8_O3_con2_5659c62f:

    # Caroline "Yeah, I’d like that. Now that we’ve got some privacy - perhaps we could fool around?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:167
translate chinese CR3_AS8_O3_con2_238acb35:

    # MC "Mmm... that sounds good!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:168
translate chinese CR3_AS8_O3_con2_54b969b4:

    # Caroline "Go ahead. You can do whatever you want."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:172
translate chinese CR3_AS8_O3_con2_818b33b4:

    # MC "Is this okay?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:173
translate chinese CR3_AS8_O3_con2_424e087b:

    # Caroline "You don’t need to worry about seeking my permission, for every action. The deal’s back on - and I know I’m safe with you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:174
translate chinese CR3_AS8_O3_con2_966a2592:

    # MC "(God, her tits are fucking amazing!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:178
translate chinese CR3_AS8_O3_con2_9d6223ec:

    # Caroline "You really like my breasts, don’t you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:179
translate chinese CR3_AS8_O3_con2_de0bbb9d:

    # MC "They stand out, so well in this outfit!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:180
translate chinese CR3_AS8_O3_con2_ab1e6952:

    # Caroline "How about you strip out of that silly costume, and I’ll show you a good time."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:181
translate chinese CR3_AS8_O3_con2_c8c2ddcd:

    # MC "Great - could I request that you keep YOUR outfit on, though? It’s kinda sexy."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:185
translate chinese CR3_AS8_O3_con2_40b9ff1e:

    # Caroline "Hehe. Of course I’ll keep mine on for you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:186
translate chinese CR3_AS8_O3_con2_0b5b8b86:

    # Caroline "(Fuck, his cock looks so hot. I can’t wait to play with it!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:187
translate chinese CR3_AS8_O3_con2_0d5e3621:

    # Caroline "Remember - no putting your dick in any of my holes. Aside from that, I’m down for almost anything."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:191
translate chinese CR3_AS8_O3_con2_59230c00:

    # MC "No problem, Caroline. That sounds fair enough."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:192
translate chinese CR3_AS8_O3_con2_b3ffaf3a:

    # Caroline "Close your eyes, for me. I want to show you something."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:193
translate chinese CR3_AS8_O3_con2_7661ad86:

    # MC "Okay, what-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:197
translate chinese CR3_AS8_O3_con2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:198
translate chinese CR3_AS8_O3_con2_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:199
translate chinese CR3_AS8_O3_con2_edfbfce0:

    # MC "(Oh wow! She’s an incredible kisser!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:203
translate chinese CR3_AS8_O3_con2_91883ce6:

    # Caroline "Mmm... "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:204
translate chinese CR3_AS8_O3_con2_6150324f:

    # Caroline "(He tastes so good... I could make out with him forever.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:208
translate chinese CR3_AS8_O3_con2_fd223820:

    # Caroline "Well? Enjoy that?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:209
translate chinese CR3_AS8_O3_con2_87f4843d:

    # MC "Oh yeah... That was something else!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:210
translate chinese CR3_AS8_O3_con2_975d5165:

    # Caroline "I think you’re going to enjoy - what comes next - even more."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:214
translate chinese CR3_AS8_O3_con2_19a79f4d:

    # MC "(Is she going to take her panties off?! I wonder if she’ll let me fuck her today!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:215
translate chinese CR3_AS8_O3_con2_6b9b44d3:

    # Caroline "I hope you’re enjoying the view there. I want you - extra hard - by the time I turn around."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:216
translate chinese CR3_AS8_O3_con2_6e8e7971:

    # MC "I’ve been rock-hard, since I saw you in that white costume!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:220
translate chinese CR3_AS8_O3_con2_5c8826c9:

    # Caroline "What do you think?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:221
translate chinese CR3_AS8_O3_con2_a668695e:

    # MC "Wow... "
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:222
translate chinese CR3_AS8_O3_con2_fb72c59a:

    # Caroline "There’s not a lot of guys who get to see those parts. You better damn well appreciate the view!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:226
translate chinese CR3_AS8_O3_con2_ba07198d:

    # Caroline "Now, onto the main show..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:227
translate chinese CR3_AS8_O3_con2_84dac483:

    # MC "Careful - are you not worried about it slipping inside you?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:228
translate chinese CR3_AS8_O3_con2_63a6fa6e:

    # Caroline "Relax, I’ve got your little guy - gripped firmly - between my thighs. He’s not going anywhere."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:232
translate chinese CR3_AS8_O3_con2_af4fb758:

    # Caroline "Well... maybe ‘little’ wasn’t the right adjective to use."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:233
translate chinese CR3_AS8_O3_con2_56ebbc34:

    # MC "Mmm... That feels good."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:237
translate chinese CR3_AS8_O3_con2_b174203a:

    # Caroline "I’m gonna start grinding my hips, up and down. Will you let me know if it feels good?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:238
translate chinese CR3_AS8_O3_con2_b7f88bf1:

    # MC "Yeah, I will. What about you though? You deserve to get some pleasure too."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:239
translate chinese CR3_AS8_O3_con2_1b895bbb:

    # Caroline "Don’t you worry - I can feel your shaft, against my pussy. I’ll be enjoying this, as much as you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:243
translate chinese CR3_AS8_O3_con2_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:244
translate chinese CR3_AS8_O3_con2_557970a3:

    # Caroline "My thighs aren’t too tight around your cock, are they?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:245
translate chinese CR3_AS8_O3_con2_f41f597d:

    # MC "Ah... n-no... that’s perfect."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:246
translate chinese CR3_AS8_O3_con2_affe87d5:

    # Caroline "Good! I want you to enjoy this."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:250
translate chinese CR3_AS8_O3_con2_12c59643:

    # MC "Mmm... That’s so fucking good, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:251
translate chinese CR3_AS8_O3_con2_c4524380:

    # MC "Where did you learn to use your thighs like that?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:252
translate chinese CR3_AS8_O3_con2_b6e09fe6:

    # Caroline "You don’t have a condom on you right now, and I can’t risk letting you into my pussy. This is the safest way to do it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:256
translate chinese CR3_AS8_O3_con2_e65317c6:

    # Caroline "It’s called improvisation! I’ve seen some women do it in porn."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:257
translate chinese CR3_AS8_O3_con2_75e8c457:

    # MC "Huh? That’s pretty clever. Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:258
translate chinese CR3_AS8_O3_con2_2c20909b:

    # Caroline "Yeah, it works most of the time."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:259
translate chinese CR3_AS8_O3_con2_06d3dcba:

    # MC "Why only most of the time?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:263
translate chinese CR3_AS8_O3_con2_bd657f40:

    # Caroline "This position has your cock rub up against my clitoris. I’ve seen a few videos where the woman gets REALLY turned on, and just couldn’t hold herself back any longer."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:264
translate chinese CR3_AS8_O3_con2_e5c707e5:

    # Caroline "Ah... Oh..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:265
translate chinese CR3_AS8_O3_con2_f091866c:

    # Caroline "God... It’s so hot, watching them give in to riding a cock, bareback. They’ve got to be super careful to pull out in time, y’know?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:270
translate chinese CR3_AS8_O3_con2_88deaa12:

    # Caroline "Violet takes birth control, for the exact same reason. Once a guy turns her on, she just needs to fuck him. She’s insatiable like that."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:271
translate chinese CR3_AS8_O3_con2_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:273
translate chinese CR3_AS8_O3_con2_d718f328:

    # MC "(I wonder if I could turn on Caroline, that way.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:277
translate chinese CR3_AS8_O3_con2_7b9c2157:

    # Caroline "H-Hey! Wh-What are you doing?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:278
translate chinese CR3_AS8_O3_con2_ae5e4815:

    # MC "It’s not fair that you’re doing all the work! Let me help, by moving my hips a bit!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:279
translate chinese CR3_AS8_O3_con2_d68b1617:

    # Caroline "W-Wait!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:283
translate chinese CR3_AS8_O3_con2_b6f4d8fd:

    # Caroline "Ah! Ah!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:284
translate chinese CR3_AS8_O3_con2_2d9c88ed:

    # MC "(I can feel my shaft digging into her pussy now. I can definitely stimulate her better, from this angle!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:285
translate chinese CR3_AS8_O3_con2_0fbf5c80:

    # MC "(Plus, I can go much faster than she could, when she was on top of me!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:289
translate chinese CR3_AS8_O3_con2_25e18b84:

    # Caroline "Ah! Oh, my God! Mmm! Oh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:290
translate chinese CR3_AS8_O3_con2_1685b179:

    # Caroline "[player_name]! Y-You have to - ahhh - s-slow down!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:291
translate chinese CR3_AS8_O3_con2_e92db6e1:

    # MC "Mmm! Ah! Ugh!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:295
translate chinese CR3_AS8_O3_con2_c462dfd8:

    # Caroline "OOOHHHHHHH!!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:296
translate chinese CR3_AS8_O3_con2_ebf4b1fc:

    # Caroline "(He’s got the perfect angle on my pussy! It feels so fucking good!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:297
translate chinese CR3_AS8_O3_con2_ee097841:

    # Caroline "(I can’t let him get the better of me like this!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:301
translate chinese CR3_AS8_O3_con2_6624b469:

    # Caroline "Ah! AHHH! AHHH!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:302
translate chinese CR3_AS8_O3_con2_cfc9c2ef:

    # MC "Hnnnng..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:303
translate chinese CR3_AS8_O3_con2_30453b09:

    # MC "(Damn, she is REALLY wet right now!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:307
translate chinese CR3_AS8_O3_con2_73c8ef2a:

    # MC "(Let’s change the angle a bit, so my cock is ALMOST poking at her pussy.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:308
translate chinese CR3_AS8_O3_con2_4a7f34b5:

    # Caroline "Oh... Oh... Ohh... Wow..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:309
translate chinese CR3_AS8_O3_con2_f07d1a2c:

    # Caroline "(The feeling of his cock, against my pussy, is making me melt. This is FAR too risky! Why did I ever think, doing this without panties, would be a good idea?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:313
translate chinese CR3_AS8_O3_con2_d3f961f4:

    # MC "(Okay, I’ve got the angle! Now I can press against her pussy, as if I’m about to go inside.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:314
translate chinese CR3_AS8_O3_con2_7da9379f:

    # MC "(I’ll slip past, at the very last second - and tease her. Haha!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:315
translate chinese CR3_AS8_O3_con2_f35a372a:

    # Caroline "Ah! Ah! W-Wait! Don’t go inside!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:319
translate chinese CR3_AS8_O3_con2_21210980:

    # Caroline "Ohhhhhh!!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:320
translate chinese CR3_AS8_O3_con2_c91e7456:

    # Caroline "(He is sliding the whole length of his cock against my clitoris! It feels soooo good!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:321
translate chinese CR3_AS8_O3_con2_d762ce3c:

    # MC "(Heh, I’m REALLY making her moan here!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:325
translate chinese CR3_AS8_O3_con2_d0a3ae26:

    # Caroline "Ohhh... Mmm... God..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:326
translate chinese CR3_AS8_O3_con2_5c1f4f24:

    # MC "(She’s absolutely loving this! My cock is completely SOAKED with her juices now.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:327
translate chinese CR3_AS8_O3_con2_7aef3915:

    # Caroline "Yeeessss..! Mmmm!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:334
translate chinese CR3_AS8_O3_con2_11aa80fd:

    # MC "(Fuck! I’m about to cum!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:335
translate chinese CR3_AS8_O3_con2_12a56071:

    # MC "AH! Ahhh! Ugh!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:336
translate chinese CR3_AS8_O3_con2_24337985:

    # Caroline "Oh! Oh! AHH!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:340
translate chinese CR3_AS8_O3_con2_0a8cc347:

    # MC "Yes! HNNNGGGG! Arrghhhh!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:342
translate chinese CR3_AS8_O3_con2_8eafbb0a:

    # Caroline "AHHHHH!!!!!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:353
translate chinese CR3_AS8_O3_con2_8114f3fe:

    # MC "*Pant Pant* Wow..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:354
translate chinese CR3_AS8_O3_con2_2ad5f602:

    # MC "Fuck... That was amazing, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:355
translate chinese CR3_AS8_O3_con2_c03a271b:

    # Caroline "(Huh?! He stopped?! I was SOOO close to cumming! Dammit! I want him inside me...)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:359
translate chinese CR3_AS8_O3_con2_a7ade34b:

    # Caroline "(Fuck - this has gone too far again. I need to get home and relieve myself, before I find myself doing something I’ll regret.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:360
translate chinese CR3_AS8_O3_con2_46d16608:

    # Caroline "(This ALWAYS happens when I get too horny.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:361
translate chinese CR3_AS8_O3_con2_1cb19228:

    # MC "Caroline? Where are you going?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:365
translate chinese CR3_AS8_O3_con2_30325659:

    # Caroline "I... er... I have to go and do... something urgent. I completely forgot about it!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:366
translate chinese CR3_AS8_O3_con2_6a0301ae:

    # Caroline "Feel free to clean yourself up and head back home!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:367
translate chinese CR3_AS8_O3_con2_b2280db1:

    # MC "Um, okay? I’ll see you later."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS8_O3.rpy:368
translate chinese CR3_AS8_O3_con2_eafd6105:

    # Caroline "BYE! (Fuck! I was SOOO close to letting him pound my pussy, there. I need to get a grip on myself!)"
    Caroline ""

