﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:19
translate chinese caroline_cloth_shop_afternoon_scene1_label_f1b381f4:

    # MC "Afternoon, Caroline!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:20
translate chinese caroline_cloth_shop_afternoon_scene1_label_25ba9654:

    # Caroline "Hiiii, [player_name]!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:21
translate chinese caroline_cloth_shop_afternoon_scene1_label_cea15366:

    # Caroline "Perfect timing - I’ve just finished planning my idea to save the shop!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:22
translate chinese caroline_cloth_shop_afternoon_scene1_label_bed4ae3f:

    # MC "Great! How can I help?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:25
translate chinese caroline_cloth_shop_afternoon_scene1_label_4f1a5f4d:

    # Caroline "Okay, listen to this. I’ve got a three point plan."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:26
translate chinese caroline_cloth_shop_afternoon_scene1_label_55803515:

    # Caroline "One - I’m going to order in a new range of cosplay outfits."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:27
translate chinese caroline_cloth_shop_afternoon_scene1_label_d3194d01:

    # Caroline "Two - I’m going to market these by modelling them and putting the pictures online."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:32
translate chinese caroline_cloth_shop_afternoon_scene1_label_93995eed:

    # Caroline "Which leads me into point three - I’m starting an online store too!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:33
translate chinese caroline_cloth_shop_afternoon_scene1_label_83f6b89d:

    # Caroline "This will hopefully increase my annual turnover enough to finally make a profit."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:34
translate chinese caroline_cloth_shop_afternoon_scene1_label_9bdc98c9:

    # MC "Sounds like a great idea! What do you need me to do?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:35
translate chinese caroline_cloth_shop_afternoon_scene1_label_faee1999:

    # Caroline "Hiring an actual model to wear these for my website is going to cost me WAY too much. "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:36
translate chinese caroline_cloth_shop_afternoon_scene1_label_16cce071:

    # Caroline "So, in order to save money I’ve decided to do the modelling myself. Can you take some pictures of me in the outfits?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:37
translate chinese caroline_cloth_shop_afternoon_scene1_label_9c4d6185:

    # MC "Of course!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:40
translate chinese caroline_cloth_shop_afternoon_scene1_label_28569b9c:

    # Caroline "Umm... There's just one tiny problem."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:41
translate chinese caroline_cloth_shop_afternoon_scene1_label_b1f2ce5b:

    # Caroline "I don’t have a camera."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:42
translate chinese caroline_cloth_shop_afternoon_scene1_label_58d741fb:

    # MC "Ah... Right."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:43
translate chinese caroline_cloth_shop_afternoon_scene1_label_b21c5ac3:

    # Caroline "If you can get one, come on back and we’ll begin."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:44
translate chinese caroline_cloth_shop_afternoon_scene1_label_3db49645:

    # Caroline "I’ll continue building my online catalogue in the meantime. That means I should be able to quickly add the photos as and when you take them."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:45
translate chinese caroline_cloth_shop_afternoon_scene1_label_be23cfe7:

    # MC "Okay, Caroline. I’ll go and find a camera."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:58
translate chinese caroline_cloth_shop_afternoon_scene1_label_c145bc3d:

    # Caroline "Hey, [player_name]. Did you manage to get any camera?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:59
translate chinese caroline_cloth_shop_afternoon_scene1_label_9095325f:

    # MC "Not yet."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:66
translate chinese caroline_cloth_shop_afternoon_scene1_label_0ba04a8c:

    # MC "Hey, Caroline! I found a camera!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:67
translate chinese caroline_cloth_shop_afternoon_scene1_label_404eec6d:

    # Caroline "Nice work! It looks like a decent make too."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:68
translate chinese caroline_cloth_shop_afternoon_scene1_label_c59ee1d6:

    # Caroline "I’m ready to begin doing some modelling sessions, with the clothes, whenever you’re ready."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:71
translate chinese caroline_cloth_shop_afternoon_scene1_label_22cfa5b8:

    # Caroline "You’re doing the hard work - so how about you pick an outfit?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:72
translate chinese caroline_cloth_shop_afternoon_scene1_label_a405b10e:

    # Caroline "Try and focus on getting good camera angles."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:73
translate chinese caroline_cloth_shop_afternoon_scene1_label_fc395e8f:

    # Caroline "Better pictures means more sales, which means more money!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:84
translate chinese caroline_cloth_shop_afternoon_scene1_label_ea2e4261:

    # Caroline "[player_name]... We should talk privately in the evening, now is not a good moment for this."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:88
translate chinese caroline_cloth_shop_afternoon_scene1_label_be04fd44:

    # Caroline "Oh! Hey, [player_name]! Ready for another photo session?"
    Caroline ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene1.rpy:90
    old "Sure!"
    new ""

