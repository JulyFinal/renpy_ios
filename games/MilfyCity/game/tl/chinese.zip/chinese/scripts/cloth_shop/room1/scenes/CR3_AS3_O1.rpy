﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:28
translate chinese CR3_AS3_O1_018a7330:

    # MC "(When Caroline told me that she had new costumes, for couples, I imagined that they were going to be - super sexy!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:29
translate chinese CR3_AS3_O1_5e32033d:

    # MC "(What - even - is this thing?! I look like a damn bumblebee!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:30
translate chinese CR3_AS3_O1_31846dae:

    # Violet "Are you ready there, [player_name]?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:31
translate chinese CR3_AS3_O1_83602503:

    # MC "Yeah! Coming now!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:35
translate chinese CR3_AS3_O1_600819c3:

    # Violet "Okay everyone - let me set the stage, for you two. It’s a beautiful beach, on the USA’s West Coast, Golden sand, azure waves, sapphire skies-"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:36
translate chinese CR3_AS3_O1_d4624e67:

    # Caroline "Yeah yeah, we get it. Can we just - cut to the chase?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:37
translate chinese CR3_AS3_O1_ea519d4d:

    # Violet "Absolutely not! We’re doing this properly!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:38
translate chinese CR3_AS3_O1_12214844:

    # Caroline "*Sigh* (I knew there was a reason, why she wasn’t higher up my list of potential photographers.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:42
translate chinese CR3_AS3_O1_0e3fe33a:

    # Violet "The brave lifeguard, played by [player_name], is hanging out with his beautiful girlfriend, at the water’s edge. They embrace together, as the California sun sets behind them."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:43
translate chinese CR3_AS3_O1_efc45054:

    # Violet "I’m going to need you two to hug and look lovingly into each other's eyes. Can you do that for me?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:44
translate chinese CR3_AS3_O1_ef6786ca:

    # Caroline "Don't you think you’re taking this a little too seriously?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:48
translate chinese CR3_AS3_O1_863d4e34:

    # Violet "Too seriously?! I am an ARTIST!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:49
translate chinese CR3_AS3_O1_ec71527a:

    # Violet "I spent four YEARS in art school for my degree! This is the first time I have EVER been able to put it to use!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:50
translate chinese CR3_AS3_O1_48e0c5b6:

    # Caroline "Ugh..! Fine! Let’s just get this over with..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:51
translate chinese CR3_AS3_O1_2ab16f87:

    # MC "(I can see why Caroline didn’t go to her first when she was desperate for a photographer! This girl is driving me insane!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:55
translate chinese CR3_AS3_O1_20a99152:

    # Caroline "Umm? How’s this?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:56
translate chinese CR3_AS3_O1_22b9d4e8:

    # Violet "No! No! No! Closer! You’re not making any effort to look like a couple! It just looks... awkward."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:57
translate chinese CR3_AS3_O1_66eda40f:

    # Caroline "*Sigh* Sorry. Let me try again."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:61
translate chinese CR3_AS3_O1_c047da47:

    # Caroline "(I can’t believe I’m doing this again... Hopefully Violet’s presence will act as a restraint on either of us doing stupid stuff again.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:62
translate chinese CR3_AS3_O1_1a4bc6ac:

    # Caroline "(God... I can’t even look him in the eye, right now.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:63
translate chinese CR3_AS3_O1_3e06524a:

    # Caroline "(It feels so nice having his hands hold my body like this though...)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:64
translate chinese CR3_AS3_O1_67ba80b4:

    # Violet "Could you raise your head a bit, Caroline?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:68
translate chinese CR3_AS3_O1_a7f6f3ee:

    # Violet "Yeah, just like that!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:69
translate chinese CR3_AS3_O1_9507adbb:

    # Violet "Hold it, right there! I’m gonna focus the camera lens, and we’ll be ready to shoot."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:70
translate chinese CR3_AS3_O1_4d1418b6:

    # Caroline "(I can feel - every single breath - he makes, against my skin.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:74
translate chinese CR3_AS3_O1_54bb0445:

    # MC "*Whispered* I’m sorry..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:75
translate chinese CR3_AS3_O1_347429bd:

    # Caroline "Huh?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:76
translate chinese CR3_AS3_O1_8af2e196:

    # MC "*Whispered* I said I’m sorry. I know this deal didn't work out for you. I kept asking about it and pushing it. I should have just let it go."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:80
translate chinese CR3_AS3_O1_7b8f1490:

    # MC "*Whispered* You’re my sister, and I would never want to hurt you or drive you away. I’m gonna miss what we had every single day for the rest of my life, but that would pale in comparison to the pain of losing you as a sister."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:82
translate chinese CR3_AS3_O1_560f46dc:

    # MC "*Whispered* You’re my best friend and I would never want to hurt you or drive you away. I’m gonna miss what we had every single day for the rest of my life, but that would pale in comparison to the pain of losing you as my friend."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:83
translate chinese CR3_AS3_O1_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:84
translate chinese CR3_AS3_O1_ab8b4320:

    # Caroline "*Whispered* Shut up, you bastard... you’re gonna make me cry on camera."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:88
translate chinese CR3_AS3_O1_48215c50:

    # Violet "Okay, you two - that’s me ready!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS3_O1.rpy:89
translate chinese CR3_AS3_O1_30ed96c4:

    # Violet "Let’s see you strike a pose!"
    Violet ""

