﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:138
translate chinese CR3_AS9_O4_c6fed14c:

    # MC "(Oh, c’mon! This isn’t even a cosplay! It’s just a... pink dressing gown!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:139
translate chinese CR3_AS9_O4_a43984b0:

    # MC "(How can Caroline seriously be thinking about selling this in her store?! You could buy one of these at any old clothes shop!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:140
translate chinese CR3_AS9_O4_f9a43c02:

    # MC "(Seriously, what was she thinking?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:144
translate chinese CR3_AS9_O4_5a9a7825:

    # MC "(I mean, the dressing gown was bad enough, but the fact that it comes with pink slippers..?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:145
translate chinese CR3_AS9_O4_951c2960:

    # MC "(Oh well... Maybe Caroline’s costume will be so good, that it’ll all make sense. I can only hope!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:149
translate chinese CR3_AS9_O4_ab8e23fb:

    # Violet "Looking good there, [player_name]!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:150
translate chinese CR3_AS9_O4_0f2aad04:

    # MC "Haha, very funny. Do you know what’s going on with this scene? What am I supposed to be?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:151
translate chinese CR3_AS9_O4_d4b807ea:

    # Violet "Hmm..."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:155
translate chinese CR3_AS9_O4_166190f1:

    # Violet "Well, I haven’t seen Caroline’s outfit yet - but based upon what you’re wearing, I’m gonna guess you’re either a man about to go to bed..."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:156
translate chinese CR3_AS9_O4_51728f68:

    # Violet "...or a guy who is just trying out crossdressing for the first time."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:157
translate chinese CR3_AS9_O4_d19aff1b:

    # MC "*Sigh* Great."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:161
translate chinese CR3_AS9_O4_ed9c5ca2:

    # Violet "Hehe! You have to admit, you DO look funny in that!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:162
translate chinese CR3_AS9_O4_97d62fe0:

    # MC "Caroline! Are you almost ready?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:163
translate chinese CR3_AS9_O4_dc029ef3:

    # Violet "Yeah, hurry up, Caroline! A beautiful woman is waiting for you, out here!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:167
translate chinese CR3_AS9_O4_9670641a:

    # MC "Oh, fuck off, Violet!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:168
translate chinese CR3_AS9_O4_f0102fdb:

    # Violet "Hehehe! "
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:169
translate chinese CR3_AS9_O4_991ffa26:

    # Caroline "Umm... two seconds! There’s a lot of parts to this one..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:173
translate chinese CR3_AS9_O4_a58ea7cc:

    # Caroline "And... Ta da!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:174
translate chinese CR3_AS9_O4_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:175
translate chinese CR3_AS9_O4_cd322232:

    # Violet "*Whistle*"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:179
translate chinese CR3_AS9_O4_09b2da96:

    # Caroline "Well? What do you guys think?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:180
translate chinese CR3_AS9_O4_8c501a3d:

    # MC "You look breathtaking! What are you supposed to be?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:181
translate chinese CR3_AS9_O4_c1d59e6d:

    # Caroline "It’s not a cosplay this time - I thought I’d expand into sexy lingerie to try and capture the mainstream market who don’t watch much anime."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:185
translate chinese CR3_AS9_O4_fd675375:

    # Caroline "This is my first foray into this kind of adult lingerie, so a lot of the stuff I ordered was hit or miss."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:186
translate chinese CR3_AS9_O4_753571dd:

    # Caroline "This little number, for example, is gonna fly off the shelves."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:187
translate chinese CR3_AS9_O4_06e8a504:

    # Caroline "On the other hand... your dressing gown might be... err... a slow seller."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:188
translate chinese CR3_AS9_O4_4f728dfd:

    # MC "Yeah, I guessed that."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:192
translate chinese CR3_AS9_O4_c7c33f17:

    # Violet "Oh shit! I forgot, I’m supposed to be at a party this evening. Can we hurry up and get these pictures taken?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:193
translate chinese CR3_AS9_O4_4130eed1:

    # Caroline "Yeah, let’s get a move on."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:194
translate chinese CR3_AS9_O4_9a0742a2:

    # Violet "Okay, what’s the scene?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:195
translate chinese CR3_AS9_O4_a7b2b138:

    # Caroline "Right - go ahead and lie down for me. "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:199
translate chinese CR3_AS9_O4_336e333e:

    # Caroline "Perfect - okay, you’ll be the husband who is EXHAUSTED after a LONG day at work. Meanwhile, I’ll play the part of the wife."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:200
translate chinese CR3_AS9_O4_71790743:

    # Caroline "It’s been AGES since I’ve gotten any action, so I decide to wake you up with a sexy surprise."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:201
translate chinese CR3_AS9_O4_bbd15399:

    # MC "Ahh... gotcha! Let’s do it!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:205
translate chinese CR3_AS9_O4_3cfe7320:

    # Caroline "Two minutes, I’m just gonna knock out the lights. I think we could do a cool blue to simulate night time."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:206
translate chinese CR3_AS9_O4_47943c0f:

    # Violet "Yeah, that’ll work."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:210
translate chinese CR3_AS9_O4_a1f184e9:

    # "*CLICK*"
    ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:211
translate chinese CR3_AS9_O4_5389ddb8:

    # Violet "Yup! That’s perfect. Go ahead and take your place, Caroline. I’ll get the camera ready."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:212
translate chinese CR3_AS9_O4_f1bc3444:

    # Caroline "Great!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:216
translate chinese CR3_AS9_O4_23c5c551:

    # MC "(Damn, Caroline looks incredibly sexy right now - I’ll have to be extra careful, to make sure I don’t get a boner in front of Violet.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:217
translate chinese CR3_AS9_O4_bc50a8d4:

    # MC "(That’s the LAST thing I want her to capture on camera!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:219
translate chinese CR3_AS9_O4_81d49af4:

    # MC "(I hope to God, Mom or Dad never check out Caroline's website... All those photos we have taken so far, do look rather compromising.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:221
translate chinese CR3_AS9_O4_46170a0d:

    # MC "(I hope to God, Linda or Bob never check out Caroline's website... All those photos we have taken so far, do look so awkward.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:225
translate chinese CR3_AS9_O4_8e4d3102:

    # Caroline "Alright, is that you comfortable, [player_name]?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:226
translate chinese CR3_AS9_O4_f992e94f:

    # MC "Mmm... very."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:227
translate chinese CR3_AS9_O4_84e7e8f1:

    # Caroline "Try not to get too relaxed - I don’t want you falling asleep on me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:231
translate chinese CR3_AS9_O4_2b1fafaa:

    # MC "*Whispered* You’re so beautiful, you know that?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:232
translate chinese CR3_AS9_O4_a7d0b09b:

    # Caroline "Hehe, I know."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:233
translate chinese CR3_AS9_O4_3a332d5b:

    # Violet "What are you two whispering about?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:237
translate chinese CR3_AS9_O4_6224fd37:

    # Caroline "Nothing, Violet! Just make sure the camera is ready!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:238
translate chinese CR3_AS9_O4_9313f17c:

    # Caroline "*Whispered* After this photoshoot, maybe you and I could have a little fun?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:239
translate chinese CR3_AS9_O4_9076e39c:

    # MC "*Whispered* Mmm, I’d like that."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:243
translate chinese CR3_AS9_O4_ec64d1fd:

    # Violet "Hehe! You two look like SUCH a couple right now! It’s unbelievable!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:244
translate chinese CR3_AS9_O4_85d94304:

    # Violet "It’s like there’s this natural chemistry between the two of you!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:248
translate chinese CR3_AS9_O4_e76d8618:

    # Violet "Okay, smile for the camera!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:250
translate chinese CR3_AS9_O4_57577691:

    # MC "(Oh dear... I hope Violet hasn’t caught onto the fact that we’re more than brother and sister now...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:253
translate chinese CR3_AS9_O4_92249e59:

    # MC "(Oh dear... I hope Violet hasn’t caught onto the fact that we’re more than just friends now...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:254
translate chinese CR3_AS9_O4_9c7c7ef3:

    # MC "(There’s no way she could tell, just by looking at us in a photoshoot, right?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:255
translate chinese CR3_AS9_O4_3cd09d4a:

    # Violet "It’s funny - I’ve always kinda shipped you two together."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:259
translate chinese CR3_AS9_O4_2d462e06:

    # Caroline "VIOLET! Just take the damn pictures!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:260
translate chinese CR3_AS9_O4_7c91cbb8:

    # Violet "Geez! Don’t lose your head!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:261
translate chinese CR3_AS9_O4_dc41b22f:

    # MC "(Yikes! Even though our deal is back on, she’s still very sensitive about others knowing.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:265
translate chinese CR3_AS9_O4_926b542a:

    # Violet "Okay, three, two, one!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:270
translate chinese CR3_AS9_O4_a1f184e9_1:

    # "*CLICK*"
    ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:272
translate chinese CR3_AS9_O4_98302708:

    # Violet "How about you two give me a hand, picking the best angles?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:273
translate chinese CR3_AS9_O4_a9e925e6:

    # MC "Sure, Violet. No problem."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:298
translate chinese CR3_AS9_O4_con2_84f6c20a:

    # Violet "Well, that went better than I thought it would! That ugly pink dressing gown ain’t half as bad when it’s got violet lying on top of it!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:299
translate chinese CR3_AS9_O4_con2_e7180605:

    # Violet "Anyway, I gotta dash, guys - everyone is waiting for me at the party."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:300
translate chinese CR3_AS9_O4_con2_501bd510:

    # Violet "See ya later!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:305
translate chinese CR3_AS9_O4_con2_b24118d3:

    # MC "Well... That’s her gone now. Finally, there’s some privacy, for just you and me."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:306
translate chinese CR3_AS9_O4_con2_1ac8660b:

    # Caroline "Mmm, there definitely is."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:307
translate chinese CR3_AS9_O4_con2_24c072d7:

    # MC "And didn’t you mention something about us fooling around after she left?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:312
translate chinese CR3_AS9_O4_con2_87ff72ba:

    # Caroline "Did I really say that? I don’t remember."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:313
translate chinese CR3_AS9_O4_con2_301472fc:

    # MC "Oh yeah, I’ll quote you. You said, ‘As soon as Violet leaves, I’m gonna rip my panties off and bounce up and down on your thick co-’"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:314
translate chinese CR3_AS9_O4_con2_7efc61cb:

    # Caroline "Oh, HA HA! Very funny..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:318
translate chinese CR3_AS9_O4_con2_8a22fa87:

    # MC "Let’s take this silly thing off. I want to see your eyes."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:319
translate chinese CR3_AS9_O4_con2_f0f01808:

    # MC "Your eyes are gorgeous - you know that?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:320
translate chinese CR3_AS9_O4_con2_991bee90:

    # Caroline "They’re nothing special."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:321
translate chinese CR3_AS9_O4_con2_b96d8675:

    # MC "Well, they’re special to me. You may as well call them a maze - because I’m getting lost in them."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:322
translate chinese CR3_AS9_O4_con2_04bb087e:

    # Caroline "Hehe, where’d you find that line? The internet?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:323
translate chinese CR3_AS9_O4_con2_0938400b:

    # MC "No - deep within my heart."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:327
translate chinese CR3_AS9_O4_con2_5313da11:

    # Caroline "God, you’re so corny. Just stop talking, and kiss me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:328
translate chinese CR3_AS9_O4_con2_f40a3bed:

    # MC "(I love being able to make her smile like that. I think, deep down, she really enjoys those cheesy lines.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:332
translate chinese CR3_AS9_O4_con2_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:333
translate chinese CR3_AS9_O4_con2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:334
translate chinese CR3_AS9_O4_con2_70965f52:

    # MC "(If it wasn’t for this godforsaken dressing gown, everything would be perfect right now.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:338
translate chinese CR3_AS9_O4_con2_724e8c24:

    # MC "(Ah well, I’ll just try to put it out of my head and enjoy the moment.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:339
translate chinese CR3_AS9_O4_con2_5015ce69:

    # Caroline "Mmm! (God, he tastes so good... Why is he so irresistible?)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:343
translate chinese CR3_AS9_O4_con2_60987446:

    # Caroline "(Every single time I kiss him like this, my mind just goes blank. It’s hard to put it into words, even in my own mind. But it feels like all my cares and problems are simply melting away into nothingness.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:344
translate chinese CR3_AS9_O4_con2_d4f607ad:

    # Caroline "(It feels a bit like how I imagine absolute safety to feel.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:348
translate chinese CR3_AS9_O4_con2_8aa300b4:

    # Caroline "(It’s like a log cabin with a blazing hearth, in the middle of a blizzard - or the basement during a hurricane. There’s something serene and secure to his kisses.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:349
translate chinese CR3_AS9_O4_con2_1f9bb450:

    # MC "(Almost as if, all the problems are ‘out there’, far away where - they can’t hurt you.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:353
translate chinese CR3_AS9_O4_con2_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:354
translate chinese CR3_AS9_O4_con2_0566c072:

    # Caroline "(No financial stress. No tax returns. No abusive ex-boyfriend.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:355
translate chinese CR3_AS9_O4_con2_43d1480a:

    # Caroline "(Just [player_name].)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:356
translate chinese CR3_AS9_O4_con2_5f0c5a10:

    # Caroline "([player_name] and his succulent lips.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:360
translate chinese CR3_AS9_O4_con2_d65408c3:

    # Caroline "Wow..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:361
translate chinese CR3_AS9_O4_con2_baab58ba:

    # MC "You enjoyed that?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:362
translate chinese CR3_AS9_O4_con2_2b656ab2:

    # Caroline "Kissing you is amazing, and I could do it forever. HOWEVER! I did promise you that we would fool around."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:366
translate chinese CR3_AS9_O4_con2_314698f9:

    # Caroline "So, what’s it gonna be for you? Handjob or footjob?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:367
translate chinese CR3_AS9_O4_con2_f4534e9e:

    # MC "Hmm, it’s a tough choice."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:373
translate chinese CR3_AS9_O4_con2_5673f0d6:

    # MC "Okay, I’ve decided. I want you to give me a handjob."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:374
translate chinese CR3_AS9_O4_con2_1e8ece20:

    # Caroline "Great! Let’s get started."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:377
translate chinese CR3_AS9_O4_con2_bc9f9f17:

    # Caroline "Um... before I wank you off, can you do one thing for me?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:378
translate chinese CR3_AS9_O4_con2_b0d91b5e:

    # MC "Certainly. What is it?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:379
translate chinese CR3_AS9_O4_con2_8f9a2032:

    # Caroline "Can you strip out of that disgusting pink abomination?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:380
translate chinese CR3_AS9_O4_con2_50955101:

    # MC "Haha! Sure!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:381
translate chinese CR3_AS9_O4_con2_917e6922:

    # Caroline "Come and stand in front of me, when you’re done - but face away from me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:385
translate chinese CR3_AS9_O4_con2_e50b0aca:

    # MC "Do you mean like this?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:386
translate chinese CR3_AS9_O4_con2_3de31fe2:

    # Caroline "Yeah, that’s great. We’re gonna vary things up a bit tonight. Gotta keep these handjobs fresh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:387
translate chinese CR3_AS9_O4_con2_1cfe8475:

    # Caroline "(God... he’s so huge! Just look at the size of his cock, compared to my fingers!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:391
translate chinese CR3_AS9_O4_con2_95efe868:

    # Caroline "(What would that feel like inside me? Would it even fit properly in my pussy, without hurting me?)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:392
translate chinese CR3_AS9_O4_con2_d2e70306:

    # Caroline "(My ex wasn’t that thick. [player_name] is so much better!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:393
translate chinese CR3_AS9_O4_con2_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:397
translate chinese CR3_AS9_O4_con2_dea714cb:

    # MC "Oohh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:398
translate chinese CR3_AS9_O4_con2_ade9a61b:

    # MC "(Her hands are so soft. It feels great when she strokes my cock like this.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:399
translate chinese CR3_AS9_O4_con2_3f160688:

    # Caroline "(It sounds like he’s really enjoying this! I wonder what else I can do to spice things up.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:403
translate chinese CR3_AS9_O4_con2_cb2ca102:

    # Caroline "(He’s still getting harder! I didn’t know guys were like this!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:405
translate chinese CR3_AS9_O4_con2_aea4f24c:

    # Caroline "(I mean, how much bigger can his cock swell?)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:406
translate chinese CR3_AS9_O4_con2_05d1b90c_1:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:411
translate chinese CR3_AS9_O4_con2_cb58d288:

    # Caroline "You’re really enjoying this, aren’t you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:412
translate chinese CR3_AS9_O4_con2_86e7e604:

    # MC "Ah... yes..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:413
translate chinese CR3_AS9_O4_con2_f2403500:

    # Caroline "You love it when I wrap my fingers around your fat dick and stroke it up and down, don’t you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:417
translate chinese CR3_AS9_O4_con2_2b7252bb:

    # MC "Ah... It’s so good..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:419
translate chinese CR3_AS9_O4_con2_f921e2be:

    # Caroline "Oh yeah, just look at you, getting SOOOO hard because your sister is touching your dick. We’re not even dating and you’re so erect right now."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:421
translate chinese CR3_AS9_O4_con2_daa97a17:

    # Caroline "Oh yeah, just look at you, getting SOOOOO hard when I'm touching your dick. We're not even dating and you're so erect right now."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:422
translate chinese CR3_AS9_O4_con2_9577d6d9:

    # MC "(God, I love it when she talks dirty.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:426
translate chinese CR3_AS9_O4_con2_5ac00b08:

    # Caroline "Would you get this hard for any other girl? Or is it the thrill of knowing how BAD it is that your older sister is the one wanking you off?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:428
translate chinese CR3_AS9_O4_con2_a146b6f4:

    # Caroline "Would you get this hard for any other girl? Or is it the thrill of knowing how BAD it is that your best friend is the one wanking you off?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:429
translate chinese CR3_AS9_O4_con2_4b630759:

    # MC "Oh... Ah... Hnng..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:430
translate chinese CR3_AS9_O4_con2_b7bafb97:

    # Caroline "Mmm... this is SO naughty!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:435
translate chinese CR3_AS9_O4_con2_f63924f5:

    # Caroline "What would [Linda_name] say if I told her you were getting wanked off by me?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:437
translate chinese CR3_AS9_O4_con2_f326587b:

    # Caroline "Hmm? She’d probably be furious."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:438
translate chinese CR3_AS9_O4_con2_4f2631b0:

    # Caroline "Or maybe just shocked that you are perverted enough to get off to the thought of your older sister rubbing your cock."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:440
translate chinese CR3_AS9_O4_con2_fb5adebb:

    # Caroline "Hmm... I don't know how Linda would react to her tenants mingling. It's not something I've ever thought about."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:441
translate chinese CR3_AS9_O4_con2_b2d388d1:

    # Caroline "Or maybe just shocked that you are perverted enough to get off to the thought of your best friend rubbing your cock."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:445
translate chinese CR3_AS9_O4_con2_cb1c0d6b:

    # Caroline "(Damn... I’ve turned myself on, with all that dirty talk... That wasn’t part of the plan!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:446
translate chinese CR3_AS9_O4_con2_5e693abd:

    # Caroline "(Goddamnit... I’ve SOAKED these panties!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:447
translate chinese CR3_AS9_O4_con2_6ae97228:

    # MC "Huh? Why’d you stop? Is something wrong?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:448
translate chinese CR3_AS9_O4_con2_eba4708c:

    # Caroline "Um... could you... turn around?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:452
translate chinese CR3_AS9_O4_con2_54c797f2:

    # Caroline "(I get to watch his dick now, while I wank him off. This will be so much more fun!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:453
translate chinese CR3_AS9_O4_con2_365afdc9:

    # MC "Like this?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:454
translate chinese CR3_AS9_O4_con2_5a9d211f:

    # Caroline "Y-Yeah, just like that."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:458
translate chinese CR3_AS9_O4_con2_90418a0a:

    # Caroline "(Fuck... I can’t think straight, right now. I just want to rip my clothes off and screw him silly!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:459
translate chinese CR3_AS9_O4_con2_90d97c60:

    # Caroline "(I need to hold it together! I can’t let myself give into my lust!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:460
translate chinese CR3_AS9_O4_con2_f689fc9f:

    # MC "You stopped again, Caroline?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:464
translate chinese CR3_AS9_O4_con2_bfe58101:

    # Caroline "Umm... Sorry, I got distracted."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:465
translate chinese CR3_AS9_O4_con2_411dadf5:

    # MC "Something on your mind?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:466
translate chinese CR3_AS9_O4_con2_c9221558:

    # Caroline "No! Just... just enjoy your handjob."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:470
translate chinese CR3_AS9_O4_con2_4c277dce:

    # Caroline "(Fuck... I can feel it throbbing beneath my fingers. It feels so exciting!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:471
translate chinese CR3_AS9_O4_con2_d527904e:

    # Caroline "(If only I could feel that, throbbing deep inside my cunt...)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:472
translate chinese CR3_AS9_O4_con2_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:476
translate chinese CR3_AS9_O4_con2_868bc360:

    # Caroline "(Fuck, I can’t resist it anymore! I have to touch myself!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:477
translate chinese CR3_AS9_O4_con2_e5c707e5:

    # Caroline "Ah... Oh..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:478
translate chinese CR3_AS9_O4_con2_fe54fda8:

    # MC "Ah... Ugh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:482
translate chinese CR3_AS9_O4_con2_378562f0:

    # MC "(Oh shit! She’s masturbating too! She must have excited herself a bit too much!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:483
translate chinese CR3_AS9_O4_con2_165f0f1f:

    # Caroline "Oh... Ah..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:484
translate chinese CR3_AS9_O4_con2_2dd122d1:

    # MC "(I guess it could be my turn to try talking dirty.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:488
translate chinese CR3_AS9_O4_con2_71be6951:

    # MC "You’re imagining it inside you right now, aren’t you? Oh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:489
translate chinese CR3_AS9_O4_con2_ea84f9ed:

    # Caroline "N-No... Oh... Ah..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:490
translate chinese CR3_AS9_O4_con2_0a89df49:

    # MC "Maybe just my fingers, then? Plunging in and out of your wet pussy. Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:494
translate chinese CR3_AS9_O4_con2_f53f3b4d:

    # Caroline "Oh God... fuck... Mmm..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:495
translate chinese CR3_AS9_O4_con2_f905e2fb:

    # MC "Hnng... (Damn, I’m gonna blow my load soon!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:496
translate chinese CR3_AS9_O4_con2_d4eafa77:

    # Caroline "Ah! Ah! Ahhh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:500
translate chinese CR3_AS9_O4_con2_aafe303b:

    # MC "Hnnnnnggg! I’m gonna cum! AHHHHH!!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:501
translate chinese CR3_AS9_O4_con2_443d6580:

    # Caroline "(Holy fuck... he sounds so manly when he cums... God, I’m so turned on right now.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:502
translate chinese CR3_AS9_O4_con2_65af195b:

    # Caroline "Ahh! AHHH! Mmm..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:506
translate chinese CR3_AS9_O4_con2_f2634aca:

    # Caroline "Cum for me! Cum for your big sister!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:508
translate chinese CR3_AS9_O4_con2_540b93b8:

    # Caroline "Cum for me! I want to hear you cum!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:509
translate chinese CR3_AS9_O4_con2_5894548f:

    # MC "HNNNG!!! AHHHHHH!!!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:520
translate chinese CR3_AS9_O4_con2_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:521
translate chinese CR3_AS9_O4_con2_0fd97cfc:

    # Caroline "(Wow... So much cum! He must have been saving that up for days!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:522
translate chinese CR3_AS9_O4_con2_e699dd7b:

    # Caroline "(I don’t recall ever seeing someone in porn, shooting this much cum!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:529
translate chinese CR3_AS9_O4_con2_77991bab:

    # MC "Let’s go for a footjob today."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:530
translate chinese CR3_AS9_O4_con2_8cc179fc:

    # Caroline "Okay! I’ll just slip my shoes off here, and then we’ll be ready to go."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:534
translate chinese CR3_AS9_O4_con2_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:535
translate chinese CR3_AS9_O4_con2_2afa6563:

    # Caroline "(It’s nice to take those things off. High heels look great - but they can really kill your ankles!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:536
translate chinese CR3_AS9_O4_con2_f9502a81:

    # Caroline "Would you like me to slip my tights off too? Or shall I just rub your cock with these stockings on?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:537
translate chinese CR3_AS9_O4_con2_4c77ee64:

    # MC "Keep the stockings on!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:541
translate chinese CR3_AS9_O4_con2_3686debe:

    # Caroline "Okay, [player_name]. Your wish is my command."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:542
translate chinese CR3_AS9_O4_con2_681eff83:

    # MC "Mmm, oh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:543
translate chinese CR3_AS9_O4_con2_2242e00f:

    # Caroline "Y’know, I don’t know anyone else with a foot fetish, besides you..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:547
translate chinese CR3_AS9_O4_con2_5e9e4dec:

    # Caroline "I guess it's a good thing, because I'm starting to love it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:549
translate chinese CR3_AS9_O4_con2_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:550
translate chinese CR3_AS9_O4_con2_5edcb13c:

    # Caroline "I’m not gonna lie - I still remember the first time you asked me. I was shocked! It wasn’t something that I considered part of a normal sexual relationship."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:554
translate chinese CR3_AS9_O4_con2_bfe53aee:

    # Caroline "I’d always viewed it as kinda like BDSM, y’know? Something that you hear about online and in TV shows, but nobody ever really does it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:555
translate chinese CR3_AS9_O4_con2_d8e99da4:

    # MC "Uh huh... Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:556
translate chinese CR3_AS9_O4_con2_8da73a24:

    # Caroline "I guess my opinion of it changed, the more we did it. I’m growing... used to it now. I mean, it really isn’t THAT kinky, is it?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:560
translate chinese CR3_AS9_O4_con2_af5fbd9d:

    # Caroline "Certainly not in the grand scheme of things."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:561
translate chinese CR3_AS9_O4_con2_baf6e51e:

    # Caroline "It’s just like giving a handjob - except you’re using your feet instead. How long have you been interested in feet, [player_name]?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:562
translate chinese CR3_AS9_O4_con2_72d37621:

    # MC "Ah... I... umm... don’t know... oh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:566
translate chinese CR3_AS9_O4_con2_62ef7d2c:

    # Caroline "Hmm, can you even remember a time when you didn’t want a sexy girl to rub, her pretty little feet, all over your shaft?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:567
translate chinese CR3_AS9_O4_con2_0fcf0880:

    # MC "Mmm! N-No..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:568
translate chinese CR3_AS9_O4_con2_7e6a944a:

    # Caroline "Oh, so you’ve always liked them, then?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:572
translate chinese CR3_AS9_O4_con2_31738bab:

    # Caroline "I’m making this up as I go along, and unfortunately I don’t have a cock of my own - but I imagine that doing this should feel REALLY good, right?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:573
translate chinese CR3_AS9_O4_con2_b2d5fa12:

    # MC "Oh yeah, that’s great, Caroline. Mmm..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:574
translate chinese CR3_AS9_O4_con2_36ca71b5:

    # Caroline "Hehe, I’m glad you’re enjoying this. It’s kinda therapeutic, in a strange way."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:578
translate chinese CR3_AS9_O4_con2_979cc4ac:

    # Caroline "I love the way you squirm when I wrap my toes around the tip of your cock, just like this."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:579
translate chinese CR3_AS9_O4_con2_8972f772:

    # Caroline "It’s just so sexy to know that I’ve got such control over your body, with something as simple as my feet."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:580
translate chinese CR3_AS9_O4_con2_c7d4d769:

    # Caroline "Perhaps that’s what turns you on about this?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:584
translate chinese CR3_AS9_O4_con2_05e23b28:

    # MC "Ooohhh!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:585
translate chinese CR3_AS9_O4_con2_b06caed9:

    # Caroline "Oh yeah, that’s the spot I need to work, isn’t it?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:586
translate chinese CR3_AS9_O4_con2_aec01713:

    # Caroline "I suppose the velvety texture of my stockings, only makes things better."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:590
translate chinese CR3_AS9_O4_con2_6b782471:

    # Caroline "I wonder which you prefer - the soft, warm touch of my naked soles...."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:591
translate chinese CR3_AS9_O4_con2_0bdb3351:

    # Caroline "...or the feeling of these silky tights?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:592
translate chinese CR3_AS9_O4_con2_1b31110a:

    # Caroline "Be a good boy and lie down for me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:596
translate chinese CR3_AS9_O4_con2_56b80909:

    # Caroline "Yes, perfect."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:597
translate chinese CR3_AS9_O4_con2_2394cb90:

    # Caroline "I hope you’re enjoying the view, [player_name] - because I’m loving mine."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:598
translate chinese CR3_AS9_O4_con2_da13ff2a:

    # MC "(She seems to be getting more and more into footjobs, the more we do them!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:602
translate chinese CR3_AS9_O4_con2_c1170cce_1:

    # MC "Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:603
translate chinese CR3_AS9_O4_con2_eb661620:

    # Caroline "Let’s see if I can make you cum, using only my feet."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:606
translate chinese CR3_AS9_O4_con2_3073637e:

    # Caroline "Do you always get this hard thinking about women’s feet? Or is there a special allure to knowing that they belong to your big sister?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:608
translate chinese CR3_AS9_O4_con2_05035a27:

    # Caroline "Do you always get this hard thinking about women’s feet? Or is there a special allure about your best friend using her feet?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:613
translate chinese CR3_AS9_O4_con2_1bdda0f6:

    # MC "Ah... (I don’t think she wants me to reply. She’s probably just enjoying monologuing while she teases me!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:614
translate chinese CR3_AS9_O4_con2_08ed5050:

    # Caroline "Whenever you’re about to cum, you’re gonna have to tell me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:615
translate chinese CR3_AS9_O4_con2_f373faf3:

    # Caroline "I know you REALLY want to shoot your cum all over my feet - but this outfit is expensive, and I don’t want white stains on it the first time I’m wearing it!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:620
translate chinese CR3_AS9_O4_con2_b6927d8b:

    # MC "Hnng..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:621
translate chinese CR3_AS9_O4_con2_6bf68204:

    # Caroline "So be a good boy and tell me when you’re about to cum, okay?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:622
translate chinese CR3_AS9_O4_con2_8dc25ff2:

    # MC "Ah... Y-Yeah, I will... Hnng..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:626
translate chinese CR3_AS9_O4_con2_9526e5ef:

    # Caroline "(God, this is so much fun! Why did I never try this sooner?! So many wasted years!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:627
translate chinese CR3_AS9_O4_con2_f83ce374:

    # Caroline "(At least I’ve got a willing participant now, who can help me make up for lost time!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:628
translate chinese CR3_AS9_O4_con2_2a51d5f8:

    # MC "Ah! Ah!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:632
translate chinese CR3_AS9_O4_con2_9e04eeea:

    # Caroline "(Well, there’s no reason why I shouldn’t enjoy myself too. I’m soaked right now - and why should [player_name] have all the fun?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:633
translate chinese CR3_AS9_O4_con2_4bb41bc9:

    # Caroline "Ah... Ohh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:634
translate chinese CR3_AS9_O4_con2_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:638
translate chinese CR3_AS9_O4_con2_5f076627:

    # MC "(Oh wow! She’s actually masturbating in front of me!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:639
translate chinese CR3_AS9_O4_con2_61900e35:

    # Caroline "Ah... yes... You love that, don’t you? Ohh..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:640
translate chinese CR3_AS9_O4_con2_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:644
translate chinese CR3_AS9_O4_con2_b8cb9c46:

    # Caroline "You’re getting very loud there, [player_name]. You’re about to cum, aren’t you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:645
translate chinese CR3_AS9_O4_con2_a9ff199c:

    # MC "Y-Yeah! I’m gonna cum!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:647
translate chinese CR3_AS9_O4_con2_204dd0e4:

    # Caroline "Cum for me. Cum for your big sister, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:649
translate chinese CR3_AS9_O4_con2_bd9badea:

    # Caroline "Cum for me. I want you to cum for me, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:652
translate chinese CR3_AS9_O4_con2_e5ff163c:

    # MC "Ahh! AHHH!!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:654
translate chinese CR3_AS9_O4_con2_eff45f29:

    # Caroline "Oh! Ohh! Yes! Ah!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:655
translate chinese CR3_AS9_O4_con2_5002e198:

    # MC "Hnnnnnggg! I’m cumming!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:665
translate chinese CR3_AS9_O4_con2_2f7b3b4b_1:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:666
translate chinese CR3_AS9_O4_con2_5e616733:

    # Caroline "Hehe. You enjoyed that, didn’t you? You’re such a little slut for feet."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:667
translate chinese CR3_AS9_O4_con2_875c686a:

    # Caroline "I’ll keep that in mind if I ever need to get you off quickly."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:674
translate chinese CR3_AS9_O4_con3_c31b3304:

    # Caroline "Well, we’ve had our fun... I better get changed now."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:675
translate chinese CR3_AS9_O4_con3_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:677
translate chinese CR3_AS9_O4_con3_e9d978b2:

    # Caroline "I’ve got A LOT to do... business stuff, laundry..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:681
translate chinese CR3_AS9_O4_con3_ee869cc9:

    # MC "Hey! I’m not letting you run off on me again. It’s not fair that I’m the one who has all the fun."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:682
translate chinese CR3_AS9_O4_con3_2ca77eb7:

    # Caroline "R-Really! I’m fine, you don’t need to worry about me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:686
translate chinese CR3_AS9_O4_con3_56ca49bb:

    # MC "Oh c’mon, we made a deal! Not a one-sided arrangement, where you’re the one who does ALL the pleasuring!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:687
translate chinese CR3_AS9_O4_con3_1f5fea1a:

    # Caroline "H-Hey! What are you doing?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:691
translate chinese CR3_AS9_O4_con3_5c634e95:

    # MC "I’m gonna give you some pleasure too!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:692
translate chinese CR3_AS9_O4_con3_9a468bdd:

    # Caroline "W-Wait-"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:693
translate chinese CR3_AS9_O4_con3_11eb55f1:

    # MC "Take a seat!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:699
translate chinese CR3_AS9_O4_con3_1dc26ac5:

    # Caroline "Oof!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:700
translate chinese CR3_AS9_O4_con3_dd5ad2b9:

    # Caroline "R-Really! I’m fine! You don’t need to worry. I can take care of myself and-"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:701
translate chinese CR3_AS9_O4_con3_de01fb31:

    # MC "You won’t need to take care of yourself. I’ll be here to help relieve you, instead."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:705
translate chinese CR3_AS9_O4_con3_aa9024b1:

    # MC "I mean, you’re not seriously going to turn down a real man and then run off for a dildo? I mean, I’ve HEARD you masturbating every night. I KNOW how horny you get."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:706
translate chinese CR3_AS9_O4_con3_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:707
translate chinese CR3_AS9_O4_con3_ec15a765:

    # Caroline "Wh-What are you gonna do?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:708
translate chinese CR3_AS9_O4_con3_134bd598:

    # MC "I’m gonna strip your panties off, and then lick your pussy until you’ve cum."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:712
translate chinese CR3_AS9_O4_con3_f28dd19e:

    # Caroline "Ah... O-Okay... but this is a ONE TIME thing. Got it?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:713
translate chinese CR3_AS9_O4_con3_f6e4b451:

    # MC "Uh huh."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:714
translate chinese CR3_AS9_O4_con3_af8abdbf:

    # Caroline "I’m serious, [player_name]. This isn’t a permanent alteration to our deal!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:718
translate chinese CR3_AS9_O4_con3_49e6a328:

    # MC "Just relax and try to enjoy this. You’re worrying far too much."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:719
translate chinese CR3_AS9_O4_con3_ba1e2f34:

    # Caroline "I don’t even know if I’ll be able to cum if you’re doing that. No one’s ever gone down on-."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:720
translate chinese CR3_AS9_O4_con3_d7774dfe:

    # MC "Trust me. You’ll cum."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:724
translate chinese CR3_AS9_O4_con3_a90970e7:

    # Caroline "(Well, he’s confident. I’ll give him that!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:725
translate chinese CR3_AS9_O4_con3_1449f8d6:

    # MC "(Okay, let’s give Caroline the best pussy eating she’s ever had!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:726
translate chinese CR3_AS9_O4_con3_2faaf8ad:

    # MC "(I’ll have her shaking and squealing my name, by the time I’m done with her!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:730
translate chinese CR3_AS9_O4_con3_b7c518c4:

    # MC "Just move your ankles a little bit more so I can get these off."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:731
translate chinese CR3_AS9_O4_con3_9ccb25ef:

    # Caroline "Is that okay?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:732
translate chinese CR3_AS9_O4_con3_1c0a41d6:

    # MC "Good. okay, here we go!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:736
translate chinese CR3_AS9_O4_con3_6e22eaf1_1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:737
translate chinese CR3_AS9_O4_con3_53baca74:

    # MC "You sound nervous. Just try to relax."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:738
translate chinese CR3_AS9_O4_con3_64d0457c:

    # Caroline "Okay... I’ll try..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:739
translate chinese CR3_AS9_O4_con3_9fd3bf3c:

    # MC "And... I’m gonna need you to spread your legs too. Haha!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:740
translate chinese CR3_AS9_O4_con3_565deb4e:

    # Caroline "Oops... Sorry..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:744
translate chinese CR3_AS9_O4_con3_cf74c3a7:

    # MC "(Alright, here we go. Let’s see what I can do.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:746
translate chinese CR3_AS9_O4_con3_7020cf25:

    # MC "(I should start, by focusing on her clit - she’s already wet and sensitive. I can kick things off by lapping my tongue across that.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:750
translate chinese CR3_AS9_O4_con3_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:751
translate chinese CR3_AS9_O4_con3_638f29e8:

    # Caroline "Mmmm! Ahmmmmm!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:752
translate chinese CR3_AS9_O4_con3_89f5b465:

    # MC "(It sounds like she’s stifling her moans! I must be licking the right places!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:756
translate chinese CR3_AS9_O4_con3_347ad41f:

    # Caroline "(Oh, my God! It feels incredible!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:757
translate chinese CR3_AS9_O4_con3_5acb7402:

    # Caroline "(How does he know where to touch?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:758
translate chinese CR3_AS9_O4_con3_e1c28c43:

    # Caroline "(His tongue is so hot and flexible... God... It’s like my dildo on steroids!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:763
translate chinese CR3_AS9_O4_con3_e743d242:

    # MC "*Lick Shlurp*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:764
translate chinese CR3_AS9_O4_con3_8b510b17:

    # Caroline "Ahh! AHHH!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:765
translate chinese CR3_AS9_O4_con3_02c7e5cf:

    # MC "(Her legs are quivering like crazy, right now! I think she’s about to cum!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:769
translate chinese CR3_AS9_O4_con3_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:770
translate chinese CR3_AS9_O4_con3_126ee468:

    # Caroline "Ohhhh! MMMM!! AHHH!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:774
translate chinese CR3_AS9_O4_con3_c298f5f7:

    # MC "*Shlurp*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:775
translate chinese CR3_AS9_O4_con3_ccdb4109:

    # Caroline "(How the heck is he SOOO good at this?! He’s barely been going for thirty seconds, and I’m already melting!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:776
translate chinese CR3_AS9_O4_con3_4b2980e0:

    # Caroline "(Shit! I think I’m gonna cum!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:780
translate chinese CR3_AS9_O4_con3_1060eba7:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:781
translate chinese CR3_AS9_O4_con3_3b66b146:

    # Caroline "AHHHHH!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:782
translate chinese CR3_AS9_O4_con3_e8f0723e:

    # Caroline "(Oh God! He’s sucking on my clitoris! It’s so fucking good! I’m gonna cum!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:786
translate chinese CR3_AS9_O4_con3_fa663386:

    # Caroline "Hnnnnnnggg! UGH! AAAAHHHH!!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:787
translate chinese CR3_AS9_O4_con3_12d659e0:

    # MC "(Yup! That’s her cumming! I guess she never expected me to be THIS good with my mouth!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:788
translate chinese CR3_AS9_O4_con3_94f648cd:

    # MC "(Given how well I performed, I won’t be surprised if Caroline WANTS to permanently alter our deal to include cunnilingus!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:792
translate chinese CR3_AS9_O4_con3_d8d38d0d:

    # Caroline "*Pant* Wow..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:793
translate chinese CR3_AS9_O4_con3_7bedc530:

    # MC "Heh, I’m glad you enjoyed that. I’ll let you get changed now."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:794
translate chinese CR3_AS9_O4_con3_42fab5a1:

    # Caroline "Huh? What makes you think we’re finished?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:799
translate chinese CR3_AS9_O4_con3_c42ad36b:

    # MC "Oof!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:800
translate chinese CR3_AS9_O4_con3_c556cf9d:

    # MC "(Jesus! What’s gotten into her?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:801
translate chinese CR3_AS9_O4_con3_18a3281b:

    # MC "What are you doing, Caroline?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:805
translate chinese CR3_AS9_O4_con3_2589a47b:

    # Caroline "I haven’t had my pussy licked in my life before - I’m not letting you get away with just one session!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:806
translate chinese CR3_AS9_O4_con3_1611e239:

    # MC "You want to go again?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:807
translate chinese CR3_AS9_O4_con3_4cd0b892:

    # Caroline "Unlike men, women are capable of having multiple orgasms before we tire out."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:811
translate chinese CR3_AS9_O4_con3_2044d277:

    # Caroline "I hope you’ve still got some energy left in that tongue of yours!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:812
translate chinese CR3_AS9_O4_con3_ca47bd6b:

    # MC "(Holy shit, she’s serious! I’ve never seen her this horny before!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:816
translate chinese CR3_AS9_O4_con3_5ff58e26:

    # Caroline "Mmm... That’s it..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:817
translate chinese CR3_AS9_O4_con3_4742d564:

    # Caroline "Ahh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:818
translate chinese CR3_AS9_O4_con3_83bd14bb_2:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:822
translate chinese CR3_AS9_O4_con3_63ffde6d:

    # Caroline "God... Mmm!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:823
translate chinese CR3_AS9_O4_con3_3b13ab3e:

    # Caroline "Bury your tongue deep inside me! Fuck! Move it everywhere... Ahh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:824
translate chinese CR3_AS9_O4_con3_99bff545:

    # MC "(I knew she’d enjoy me eating her pussy out - but I never realised it would feel THIS good for her!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:828
translate chinese CR3_AS9_O4_con3_c298f5f7_1:

    # MC "*Shlurp*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:829
translate chinese CR3_AS9_O4_con3_7e31b53f:

    # Caroline "Oooohhh! Yesssss! Mmm! Fuck!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:830
translate chinese CR3_AS9_O4_con3_b302c924:

    # MC "(She tastes delicious! I could lick and suck at her pussy all day!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:834
translate chinese CR3_AS9_O4_con3_8d9183bd:

    # Caroline "Ah! Oh yes! Don’t stop!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:835
translate chinese CR3_AS9_O4_con3_d8e039ca:

    # MC "*SUCK* *SHLURP*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:836
translate chinese CR3_AS9_O4_con3_5db89485:

    # Caroline "Deeper! Faster! MMM!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:840
translate chinese CR3_AS9_O4_con3_284535ac:

    # Caroline "Yessss.... Lick my fucking pussy! Suck on my little clitty! Ahhh!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:841
translate chinese CR3_AS9_O4_con3_1060eba7_1:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:842
translate chinese CR3_AS9_O4_con3_e72fe17d:

    # Caroline "(God... why didn’t I think to put this in the original deal?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:846
translate chinese CR3_AS9_O4_con3_8980eb2f:

    # Caroline "(I could have saved a FORTUNE in batteries for my vibrator!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:847
translate chinese CR3_AS9_O4_con3_97d49009:

    # Caroline "Hnnng...."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:848
translate chinese CR3_AS9_O4_con3_d2b3b753:

    # Caroline "(Okay, here we go - time for orgasm number two!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:852
translate chinese CR3_AS9_O4_con3_c964e84a:

    # Caroline "AHH! AHHH! AHHHHH!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:854
translate chinese CR3_AS9_O4_con3_d6f82fc5:

    # Caroline "(Thank God we’re not at home - I couldn’t scream like this in the house, without Mom or Sara hearing me!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:855
translate chinese CR3_AS9_O4_con3_851a5c86:

    # Caroline "(Actually, come to think of it, it’s probably a good thing that I DIDN’T include this in the deal! There’s no way I’d be able to resist him doing this, and I’d probably just end up accidentally ruining it, by attracting our family’s attention to our little deal.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:857
translate chinese CR3_AS9_O4_con3_2bcf7df6:

    # Caroline "(Thank God we’re not at home - I couldn’t scream like this in the house, without Linda or Sara hearing me!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:858
translate chinese CR3_AS9_O4_con3_63b5b351:

    # Caroline "(Actually, come to think of it, it’s probably a good thing that I DIDN’T include this in the deal! There’s no way I’d be able to resist him doing this, and I’d probably just end up accidentally ruining it, by attracting our roommates attention to our little deal.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:862
translate chinese CR3_AS9_O4_con3_50470947:

    # MC "(Wow! Her juices are flowing all over my face, right now! She’s rocking back and forth like crazy!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:863
translate chinese CR3_AS9_O4_con3_4f8262fc:

    # Caroline "Hnnnnnggg! AAAAAHHHHHH!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:864
translate chinese CR3_AS9_O4_con3_dda296d9:

    # Caroline "C-CUMMMMIINNNNNGGG!!!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:868
translate chinese CR3_AS9_O4_con3_9fc85780:

    # Caroline "*Pant* *Pant*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:869
translate chinese CR3_AS9_O4_con3_f123d99f:

    # Caroline "H-H-Holy... Shit... Wow..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:870
translate chinese CR3_AS9_O4_con3_88b845cc:

    # MC "(She’s still trembling, after she came! I guess things got a WHOLE lot more sensitive the second time around!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:874
translate chinese CR3_AS9_O4_con3_28aebe7a:

    # MC "Hehe, so - what was that you were saying about me not being able to make you cum?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:875
translate chinese CR3_AS9_O4_con3_f2dbb8cb:

    # Caroline "*Ahem*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:876
translate chinese CR3_AS9_O4_con3_54592fda:

    # MC "I think I counted... twice?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:881
translate chinese CR3_AS9_O4_con3_bdcbc50b:

    # Caroline "Shut up."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:882
translate chinese CR3_AS9_O4_con3_38a163ad:

    # MC "So, when’s my tongue’s next appointment with your delicious cunt?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:883
translate chinese CR3_AS9_O4_con3_c97d3306:

    # Caroline "One time thing. Remember?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:884
translate chinese CR3_AS9_O4_con3_125e9da4:

    # MC "*Sigh* Fine. I’m sure you’ll change your mind though."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:885
translate chinese CR3_AS9_O4_con3_402b8fc9:

    # Caroline "We’ll see."
    Caroline ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:369
    old "Handjob"
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR3_AS9_O4.rpy:369
    old "Footjob"
    new ""

