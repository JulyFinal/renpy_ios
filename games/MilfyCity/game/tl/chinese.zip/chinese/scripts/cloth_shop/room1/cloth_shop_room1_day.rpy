﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/cloth_shop_room1_day.rpy:13
translate chinese cloth_shop_label_29b80ed4:

    # MC "Closed. It's open only in the afternoon."
    MC ""

# game/scripts/cloth_shop/room1/cloth_shop_room1_day.rpy:28
translate chinese cloth_shop_open_label_81338fa6:

    # MC "Eh!? What the fuck happened in here!? "
    MC ""

# game/scripts/cloth_shop/room1/cloth_shop_room1_day.rpy:29
translate chinese cloth_shop_open_label_7ff175e2:

    # MC "Where’s Caroline!?"
    MC ""

