﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:19
translate chinese CR3_AS2_label_6f641bc4:

    # Violet "So then I said to him, “I know this trick! You deliberately forgot the condom, and now you’re expecting me to just let you put the tip in?” I mean, how naive does this guy think I am?!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:20
translate chinese CR3_AS2_label_663ca604:

    # Caroline "What did you do?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:21
translate chinese CR3_AS2_label_41e3ef88:

    # Violet "Ugh..! He ended up saying, he’d just put the tip in, for a second. Then I got too horny, to tell him to take it out. Thank God, I was on my birth control."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:22
translate chinese CR3_AS2_label_733f6842:

    # Caroline "Aww, that’s always how it is. The trick is to not let them get inside you. Don’t give guys an inch, or they’ll take a mile."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:27
translate chinese CR3_AS2_label_48f25a26:

    # MC "Hey, guys!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:28
translate chinese CR3_AS2_label_b56dcaeb:

    # Caroline "Oh hey! We were just waiting for you. We’re ready to go, whenever you are."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:29
translate chinese CR3_AS2_label_8ff4eed3:

    # MC "Great! Let’s get changed."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:38
translate chinese CR3_AS2_label_a126a958:

    # Violet "Umm... before we begin. I have a degree in art - but I’m not entirely sure, what kinda of pictures Caroline is looking for. She told me that you’d helped her out, in the past. Could you maybe help me, direct the camera shots?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:39
translate chinese CR3_AS2_label_167b2aaa:

    # MC "Sure, Violet! Happy to help."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:40
translate chinese CR3_AS2_label_ce7c6e03:

    # Caroline "Alright... I guess we’re ready to start, whenever you are... *Gulp*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:41
translate chinese CR3_AS2_label_11c37d11:

    # MC "(She seems a little hesitant and nervous. It’s probably, the fact that we’ll be really close to each other, when we’re taking the pictures.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:48
translate chinese CR3_AS2_label_e3e0c817:

    # MC "I need a few more minutes, to prepare myself."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:49
translate chinese CR3_AS2_label_07e917e0:

    # Caroline "Take your time. Violet and I can always work on other stuff, while we’re waiting for you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:59
translate chinese CR3_AS2_label_4ce5e1bf:

    # Caroline "Glad you could make it! Are you ready for the photoshoot?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:60
translate chinese CR3_AS2_label_32683582:

    # MC "(She looks a little happier, this time - Even eager, maybe! Perhaps this is because the deal is back on, between us.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:68
translate chinese CR3_AS2_label_d6ab997a:

    # MC "I need a few more minutes to prepare myself."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:69
translate chinese CR3_AS2_label_2167953b:

    # Caroline "Take your time, Violet and I can always work on other stuff while we’re waiting for you."
    Caroline ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:43
    old "I’m ready to start."
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:43
    old "I need a few more minutes, to prepare myself."
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR3_AS2.rpy:63
    old "I need a few more minutes to prepare myself."
    new ""

