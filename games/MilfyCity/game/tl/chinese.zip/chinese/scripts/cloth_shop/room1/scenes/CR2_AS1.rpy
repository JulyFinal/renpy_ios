﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:31
translate chinese CR2_AS1_label_a33a94ea:

    # MC "Sooo, I’ve helped you out quite a bit with your photos."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:32
translate chinese CR2_AS1_label_ee9f0a03:

    # Caroline "Uh huh, you sure have."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:33
translate chinese CR2_AS1_label_448dbf1f:

    # MC "Do you remember our deal?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:34
translate chinese CR2_AS1_label_84e7fa3b:

    # Caroline "Of course I do."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:35
translate chinese CR2_AS1_label_1ac1b214:

    # MC "Well, I was looking at your outfit, and I thought, it would be REALLY fun to fuck your tits."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:39
translate chinese CR2_AS1_label_5dc3f488:

    # Caroline "My tits?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:40
translate chinese CR2_AS1_label_57864ea4:

    # Caroline "I guess they do appear, rather provocative, in this tight top."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:41
translate chinese CR2_AS1_label_7fc2e9bf:

    # MC "So, can you?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:42
translate chinese CR2_AS1_label_81709324:

    # Caroline "Hmm... "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:47
translate chinese CR2_AS1_label_ce58a5f3:

    # Caroline "Yeah, why not!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:49
translate chinese CR2_AS1_label_ce8a7cbd:

    # MC "Awesome! Thanks, sis! You’re the best!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:50
translate chinese CR2_AS1_label_1334e8d3:

    # Caroline "Maybe don’t call me “sis” when we’re doing stuff like this..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:52
translate chinese CR2_AS1_label_86adc474:

    # MC "Awesome! Thanks Caroline, you’re the best friend a guy could ask for!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:53
translate chinese CR2_AS1_label_685835ed:

    # Caroline "Maybe don’t call me “friend” when we’re doing stuff like this..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:55
translate chinese CR2_AS1_label_d22a98ff:

    # Caroline "Kinda makes things a little awkward, y’know?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:56
translate chinese CR2_AS1_label_1efb7b48:

    # MC "Heh. My bad."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:57
translate chinese CR2_AS1_label_8d70f86e:

    # Caroline "Lie back on the couch and take your pants off."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:61
translate chinese CR2_AS1_label_146c315b:

    # Caroline "Oh, you’re already hard!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:62
translate chinese CR2_AS1_label_52c40edf:

    # Caroline "I guess that shouldn’t really be a surprise though, if experience is anything to go by."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:63
translate chinese CR2_AS1_label_ee7bd273:

    # MC "How could I not be hard, looking at you in an outfit like that?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:67
translate chinese CR2_AS1_label_c04bfd4c:

    # Caroline "You’re a real charmer. Let’s get your little guy tucked in here."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:68
translate chinese CR2_AS1_label_f4ae03ff:

    # Caroline "How’s that? Comfortable?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:69
translate chinese CR2_AS1_label_3784a103:

    # MC "Oh yeah, it feels great!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:73
translate chinese CR2_AS1_label_bf0c2fb7:

    # Caroline "And.... here we go!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:74
translate chinese CR2_AS1_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:76
translate chinese CR2_AS1_label_db2173b8:

    # Caroline "You enjoy that? Does it feel good?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:82
translate chinese CR2_AS1_label_c71e172e:

    # Caroline "Do you like it when your big sister uses her big titties on your big cock?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:83
translate chinese CR2_AS1_label_03b6f042:

    # MC "(I thought she told me not to call her sister! Women are weird!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:85
translate chinese CR2_AS1_label_656d23f2:

    # Caroline "Do you like it when your “friend” uses her big titties on your fat cock?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:86
translate chinese CR2_AS1_label_b2842ffa:

    # MC "(I thought she told me not to call her “friend” anymore! Women are weird!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:87
translate chinese CR2_AS1_label_d0fa14c9:

    # MC "Yeah, it’s amazing! Ooh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:91
translate chinese CR2_AS1_label_6f19433a:

    # Caroline "Well? Do you feel like you’re being adequately rewarded for your services?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:92
translate chinese CR2_AS1_label_079eed2c:

    # MC "This is ugh... so much better than money! Ahh...."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:93
translate chinese CR2_AS1_label_d465f805:

    # Caroline "For an eighteen age guy, I'm sure it is!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:97
translate chinese CR2_AS1_label_bf05fb10:

    # Caroline "Let’s do a few more REALLY deep plunges between my breasts."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:98
translate chinese CR2_AS1_label_c5384a32:

    # MC "I’d love that, Caroline. Mmm... don’t stop."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:99
translate chinese CR2_AS1_label_cc1a5a2d:

    # Caroline "Don’t worry, I’m not gonna stop, till you cum."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:103
translate chinese CR2_AS1_label_8431aa75:

    # MC "Ooh, right there. Your tits are amazing!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:105
translate chinese CR2_AS1_label_4a0a21f1:

    # Caroline "Are you gonna cum soon?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:106
translate chinese CR2_AS1_label_e15546d2:

    # MC "Y-Yeah, I am."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:110
translate chinese CR2_AS1_label_187031ae:

    # Caroline "Guess I better angle myself, then - I can’t have you squirting your cum over my merchandise!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:111
translate chinese CR2_AS1_label_ecb6d641:

    # MC "Why don’t you want me cumming on your tits?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:112
translate chinese CR2_AS1_label_f2a8d070:

    # Caroline "I’m not talking about my tits! I have to sell this outfit to somebody!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:113
translate chinese CR2_AS1_label_45d11c98:

    # MC "Ooh!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:117
translate chinese CR2_AS1_label_059b2b2f:

    # MC "Fuck! I’m about to cum! Don’t stop!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:118
translate chinese CR2_AS1_label_9f9ff80a:

    # Caroline "That’s it. I can feel your cock pulsing between my breasts. Cum for me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:119
translate chinese CR2_AS1_label_8363be66:

    # Caroline "Cum for your best friend- Cum for me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:120
translate chinese CR2_AS1_label_4934c7dd:

    # MC "Hnnnnngggg!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:129
translate chinese CR2_AS1_label_d7b62e55:

    # MC "Oh Gooooddd! Yes!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:130
translate chinese CR2_AS1_label_0d136177:

    # Caroline "Wow! That’s a LOT of cum! You mustn’t have had much fun in a few days!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:131
translate chinese CR2_AS1_label_241a88d5:

    # MC "*Phew...* Thank you, Caroline, that was amazing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:135
translate chinese CR2_AS1_label_49d5b0b7:

    # Caroline "Don’t think anything of it. Just keep helping me, build my online portfolio, and I’ll keep helping you get off."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:136
translate chinese CR2_AS1_label_dfb15c9d:

    # Caroline "We’ve got a deal, right?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:137
translate chinese CR2_AS1_label_28d6b1fd:

    # MC "Yeah... *Phew...*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS1.rpy:138
translate chinese CR2_AS1_label_0868ca75:

    # Caroline "I’ll leave you alone now, to catch your breath."
    Caroline ""

