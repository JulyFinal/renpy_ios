﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:22
translate chinese CR2_AS5_label_b76f4f44:

    # MC "(I thought her laptop was stolen...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:23
translate chinese CR2_AS5_label_6b9ddb77:

    # MC "(I thought she didn't have any money left.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:27
translate chinese CR2_AS5_label_8446379b:

    # MC "Hey, Caroline. Wha-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:33
translate chinese CR2_AS5_label_a02ec373:

    # Caroline "Ah! [player_name]! "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:34
translate chinese CR2_AS5_label_f79efa44:

    # Caroline "You scared me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:38
translate chinese CR2_AS5_label_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:39
translate chinese CR2_AS5_label_872aa375:

    # Caroline "Is something wrong?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:40
translate chinese CR2_AS5_label_10046447:

    # MC "No. I just noticed that the shop was open."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:41
translate chinese CR2_AS5_label_7a39a0fa:

    # Caroline "At the current moment, it's not like there's a reason to close it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:51
translate chinese CR2_AS5_menu_9760e40e:

    # MC "How could you afford that laptop? Did you get your money back?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:53
translate chinese CR2_AS5_menu_b7af2948:

    # Caroline "No... It's Mom's laptop. I only borrowed it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:55
translate chinese CR2_AS5_menu_ec5ce4ed:

    # Caroline "No... It's Linda's laptop. I only borrowed it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:57
translate chinese CR2_AS5_menu_b030ad34:

    # MC "Does Mom know?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:59
translate chinese CR2_AS5_menu_3e393007:

    # MC "Does Linda's know?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:60
translate chinese CR2_AS5_menu_a3393f15:

    # Caroline "N-No..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:61
translate chinese CR2_AS5_menu_032fb88e:

    # Caroline "I’ll return it to her today. I only needed it for a couple of hours."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:62
translate chinese CR2_AS5_menu_599c5e82:

    # MC "Okay. I understand."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:72
translate chinese CR2_AS5_menu_b0821a08:

    # Caroline "I'm checking all the incoming shipments. "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:73
translate chinese CR2_AS5_menu_63d19cc0:

    # Caroline "I have some good news and some bad news for you. Which one do you want to hear first?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:80
translate chinese CR2_AS5_menu_g_b_40afcf9d:

    # Caroline "There's one shipment that I already paid for online! So I'll have new customers for the new catalog."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:81
translate chinese CR2_AS5_menu_g_b_82cecf9d:

    # MC "That's good. I can still be your photographer."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:82
translate chinese CR2_AS5_menu_g_b_87e50908:

    # Caroline "Yes.. No..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:83
translate chinese CR2_AS5_menu_g_b_19570c32:

    # MC "What?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:96
translate chinese CR2_AS5_menu_g_b_e09d630e:

    # Caroline "The bad news, is that this new catalog will have costumes for both, men and ladies."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:97
translate chinese CR2_AS5_menu_g_b_71d3047b:

    # MC "I think... I know where this is going..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:98
translate chinese CR2_AS5_menu_g_b_22aa73be:

    # Caroline "Yes. We both will be wearing costumes, which leaves us with a need for one more person, as a photographer."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:99
translate chinese CR2_AS5_menu_g_b_11daa409:

    # Caroline "But no need to panic. I have some time to find someone."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:113
translate chinese CR2_AS5_continue_b807cf33:

    # Caroline "Oh no! It’s nearly time! Mom will be back at home soon!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:115
translate chinese CR2_AS5_continue_633feb3e:

    # Caroline "Oh no! It’s nearly time! Linda will be back at home soon!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:116
translate chinese CR2_AS5_continue_b99acd47:

    # Caroline "Come on! Turn off!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:118
translate chinese CR2_AS5_continue_ea8370a4:

    # MC "You better hurry up. Mom will be really mad if she notices her laptop missing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:120
translate chinese CR2_AS5_continue_4e312ef8:

    # MC "You better hurry up. Linda will be really mad if she notices her laptop missing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:121
translate chinese CR2_AS5_continue_9f93e06c:

    # Caroline "I know!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:123
translate chinese CR2_AS5_continue_ee66a4d6:

    # Caroline "I should have finished a while ago! But there were just too many incest stories on the desktop and it made it hard to find every new file I downloaded!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:125
translate chinese CR2_AS5_continue_430031bf:

    # Caroline "I should have finished a while ago! But there were just too many shota stories on the desktop and it made it hard to find every new file I downloaded!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:126
translate chinese CR2_AS5_continue_7d309d86:

    # MC "(What!?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:127
translate chinese CR2_AS5_continue_e974ffd2:

    # Caroline "I wonder what they were all for anyway!?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:128
translate chinese CR2_AS5_continue_913e64d5:

    # MC "M-maybe some kind of Virus..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:129
translate chinese CR2_AS5_continue_8f27f8a4:

    # MC "Well.. A-anyway.. See you later."
    MC ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:48
    old "How could you afford that laptop? "
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:48
    old "What are you doing?"
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:78
    old "Good."
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR2_AS5.rpy:78
    old "Bad"
    new ""

