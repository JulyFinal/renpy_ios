﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:29
translate chinese CR3_AS4_O2_091de8d0:

    # MC "(Is this supposed to be one of those British uniforms?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:30
translate chinese CR3_AS4_O2_8fe5ff23:

    # MC "(I’m not even sure if I’ve got this, damn tie done up properly...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:31
translate chinese CR3_AS4_O2_b4e9b75f:

    # Violet "Stop! Don’t pull it up, any further - just leave your tie like that."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:32
translate chinese CR3_AS4_O2_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:33
translate chinese CR3_AS4_O2_cabd1545:

    # Violet "Yeah, it gives you that delinquent look! That’s EXACTLY what we’re looking for."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:34
translate chinese CR3_AS4_O2_9650629f:

    # Violet "Caroline! Are you almost ready? I need my naughty teacher out here!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:38
translate chinese CR3_AS4_O2_0e3d407f:

    # Caroline "I’m coming! I’m coming!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:39
translate chinese CR3_AS4_O2_7410f687:

    # Caroline "(Jesus Christ! Has Violet forgotten, that I’m supposed to be HER boss?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:40
translate chinese CR3_AS4_O2_91dbfeb0:

    # Violet "Perfect! Okay, if you two could just approach each other - just like the lifeguard scene, from last time."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:41
translate chinese CR3_AS4_O2_dca9f9ae:

    # MC "(Holy shit! Caroline was right when she said, these new clothes were too tight for her! I can see the edges of her areolas! I wonder if she’s even noticed that?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:45
translate chinese CR3_AS4_O2_46cea394:

    # Violet "Okay, good. Hmm... How can I set the scene?"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:46
translate chinese CR3_AS4_O2_1ba63612:

    # MC "*Whispered* Wow... You look stunning, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:47
translate chinese CR3_AS4_O2_859402d8:

    # Caroline "*Whispered* I wish... this damn outfit makes my ass look fat."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:48
translate chinese CR3_AS4_O2_1de5061b:

    # MC "*Whispered* It wasn’t your ass that I was looking at."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:49
translate chinese CR3_AS4_O2_e70e05d2:

    # Caroline "What?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:53
translate chinese CR3_AS4_O2_0593b6b2:

    # Violet "Okay, I’ve got it! This delinquent hadn’t been doing his homework properly."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:54
translate chinese CR3_AS4_O2_d023982b:

    # Violet "The seductive teacher comes up with a plan to reward him. For every A he gets - she will give him a naughty prize. He just got his first A today - so she is rubbing her ass, up against his pants!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:55
translate chinese CR3_AS4_O2_5614e2cf:

    # Violet "Hurry up! Get in your places, people!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:59
translate chinese CR3_AS4_O2_4b5fc565:

    # Caroline "*Sigh* Just like this?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:60
translate chinese CR3_AS4_O2_66946a4f:

    # Violet "Can you bend over, just a little bit more? Keep your head, looking up at me. I want to see your eyes, in the picture."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:61
translate chinese CR3_AS4_O2_a380314a:

    # MC "(Heh. I’ve got quite the view now!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:65
translate chinese CR3_AS4_O2_9e6f7465:

    # MC "(Maybe Caroline was right, her ass DOES look big in this dress - but I don’t see how that’s a bad thing!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:66
translate chinese CR3_AS4_O2_b0eda6de:

    # MC "(I’ll just enjoy her, rubbing up against me for a while.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:67
translate chinese CR3_AS4_O2_a566174d:

    # Violet "[player_name], I need you to put your hands up, on Caroline’s hips. Actually, go a little higher than her hips. Wrap them around her belly."
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:71
translate chinese CR3_AS4_O2_af2b8394:

    # MC "How’s this?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:72
translate chinese CR3_AS4_O2_e24d1da4:

    # Violet "Absolutely perfect!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:73
translate chinese CR3_AS4_O2_0062538e:

    # MC "(Damn, I can feel myself starting to get hard... Hopefully, Caroline will be too focused on the photoshoot, to notice.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:77
translate chinese CR3_AS4_O2_43757a59:

    # Caroline "(Oh, my God... Is [player_name] getting an erection, right now?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:78
translate chinese CR3_AS4_O2_b9574961:

    # Caroline "(He IS! I can feel it poking at my ass! Dammit! I can’t say a word, without Violet finding out... If she hears about this, she’ll never stop tormenting me about it.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:79
translate chinese CR3_AS4_O2_b90432fb:

    # Caroline "(On the other hand, it doesn't exactly feel... bad? I mean, I could just endure it, for a few more minutes.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:83
translate chinese CR3_AS4_O2_e0f77635:

    # Caroline "(What the hell am I thinking?! OF COURSE it is bad! He’s my little brother and I can’t just mess him about like this. I ended our deal and I have to stick to my guns!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:85
translate chinese CR3_AS4_O2_c9bab3ba:

    # Caroline "(What the hell am I thinking?! Of COURSE it is bad! He’s my friend and I can’t just mess him about like this. I ended our deal and I have to stick to my guns!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:86
translate chinese CR3_AS4_O2_40bac3e5:

    # Caroline "*Whispered* Umm... You couldn’t... move your hips a little bit, could you? I think there might be a... pen or something in your pocket."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:87
translate chinese CR3_AS4_O2_6dd0d831:

    # MC "*Whispered* Oops, sorry, I’ll do that now."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:88
translate chinese CR3_AS4_O2_4b3037d1:

    # MC "(Damn, I think she might have felt my erection...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:92
translate chinese CR3_AS4_O2_303d4f52:

    # Violet "Annnnnd.... Showtime!"
    Violet ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS4_O2.rpy:93
translate chinese CR3_AS4_O2_aebcc312:

    # Violet "Hold that position, guys! We are good to start!"
    Violet ""

