﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:25
translate chinese CR4_AS1_label_010bea47:

    # MC "(I've already talked to her.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:40
translate chinese CR4_AS1_label_0108ed45:

    # Caroline "Hey there, handsome! Glad you could make it!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:41
translate chinese CR4_AS1_label_aabd1f6e:

    # MC "Hey, Caroline! Did you honestly doubt that I would come?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:42
translate chinese CR4_AS1_label_03d9ed57:

    # Caroline "Nah, I’m just teasing you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:46
translate chinese CR4_AS1_label_db0aef69:

    # Caroline "Can I get you something to drink? A tea? Maybe a coffee?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:48
translate chinese CR4_AS1_label_cdd45061:

    # MC "Sure, I’ll take a coffee if you’re having one."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:49
translate chinese CR4_AS1_label_ada55a4b:

    # Caroline "Great! I’ll put the kettle on."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:53
translate chinese CR4_AS1_label_68591231:

    # Caroline "I’ll close the shop up for fifteen minutes. Go ahead into the staff room. I’ll see you back there."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:54
translate chinese CR4_AS1_label_5387e4c0:

    # MC "Are you not worried about losing customers?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:55
translate chinese CR4_AS1_label_6d423b14:

    # Caroline "Pfft! If my shop can’t survive a fifteen minute break then I must be running a very shoddy business. I’ll be fine!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:64
translate chinese CR4_AS1_label_087f50a1:

    # Caroline "Be careful with that coffee - it’s scalding!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:65
translate chinese CR4_AS1_label_7fe7c081:

    # MC "And still not as hot as you are!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:66
translate chinese CR4_AS1_label_3365e8f1:

    # Caroline "Very funny! Do you need any sugar?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:67
translate chinese CR4_AS1_label_947db723:

    # MC "I’ll be fine, thanks..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:71
translate chinese CR4_AS1_label_1d8b62b0:

    # Caroline "So, you’re here to plan our date with me, aren't you?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:72
translate chinese CR4_AS1_label_be0e9a02:

    # MC "Yeah, I was thinking of-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:73
translate chinese CR4_AS1_label_0644815a:

    # Caroline "Before you get carried away, I actually had an idea that I think you’ll REALLY like!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:77
translate chinese CR4_AS1_label_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:78
translate chinese CR4_AS1_label_e5f64ea9:

    # Caroline "So, do you remember where we had our first kiss?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:79
translate chinese CR4_AS1_label_587a0ae9:

    # MC "(That was the time we made out by the lake in the park!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:80
translate chinese CR4_AS1_label_cc36be13:

    # MC "Yeah, that was-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:84
translate chinese CR4_AS1_label_5c29da85:

    # Caroline "No need to check with me - I hope you remembered."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:85
translate chinese CR4_AS1_label_1338f6ae:

    # MC "Yeah, I do. Are we meeting there?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:86
translate chinese CR4_AS1_label_390087d2:

    # Caroline "Yup. I thought that would be a nice place to start everything together. What do you think?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:90
translate chinese CR4_AS1_label_388d6c66:

    # MC "It sounds like a lovely idea. What time do you want to meet?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:91
translate chinese CR4_AS1_label_528307c0:

    # Caroline "Let’s meet at night. After [Linda_name], [Bob_name], and [Sara_name] have all gone to bed. It means we won’t be disturbed."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:92
translate chinese CR4_AS1_label_230aa4b3:

    # MC "Great, it’s a date!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:96
translate chinese CR4_AS1_label_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:97
translate chinese CR4_AS1_label_a376ba0f:

    # Caroline "(I really hope he remembers where our first kiss was... If he doesn’t remember he's clearly just another asshole like Charles.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:98
translate chinese CR4_AS1_label_bfab4c6f:

    # Caroline "(I wonder what he’s thinking about right now. He’s probably trying to remember the exact place we kissed to make sure he doesn’t fuck this up.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:99
translate chinese CR4_AS1_label_10544572:

    # Caroline "(God... I wish I could read guys’ minds. I wonder what they think about when they’re quiet.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:103
translate chinese CR4_AS1_label_ca7a725b_1:

    # MC "*Slurp*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:104
translate chinese CR4_AS1_label_ea83a7de:

    # MC "(I wonder when the next version of DefinitelyNotRelatedPeopleFucking comes out on Patreon. That game feels like it’s been on v0.04 for YEARS now!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:106
translate chinese CR4_AS1_label_ca7a725b_2:

    # MC "*Slurp*"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:107
translate chinese CR4_AS1_label_79af3da1:

    # MC "(There’s like 16 million people today with genetic links to Ghengis Khan. I wonder how many women he impregnated each day in order to achieve this!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:108
translate chinese CR4_AS1_label_5f4150e0:

    # Caroline "(I bet it’s something super deep and romantic.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:113
translate chinese CR4_AS1_label_491f0aa3:

    # Caroline "Anyway, I better get the shop opened up again. I’ll see you tonight."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:114
translate chinese CR4_AS1_label_fca55279:

    # MC "I’m looking forward to it, [Caroline_name]. I’ll see you at the college gates tonight."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:118
translate chinese CR4_AS1_label_a371de54:

    # Caroline "Wait- the college gates?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:119
translate chinese CR4_AS1_label_f740f0f9:

    # Caroline "(Does this dickhead think our first time was making out in front of his college?!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:120
translate chinese CR4_AS1_label_bb43a752:

    # MC "Haha! I’m kidding - sorry, I couldn’t resist. I know that’s not where we had our first kiss."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:124
translate chinese CR4_AS1_label_3ddbd18e:

    # Caroline "Ahaha, you’re awful!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:125
translate chinese CR4_AS1_label_e9086f94:

    # MC "Haha, I’ll let you get back to work. I’ll see you tonight at the actual spot where we first kissed!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR4_AS1.rpy:126
translate chinese CR4_AS1_label_04ba26e6:

    # Caroline "See you then, [player_name]."
    Caroline ""

