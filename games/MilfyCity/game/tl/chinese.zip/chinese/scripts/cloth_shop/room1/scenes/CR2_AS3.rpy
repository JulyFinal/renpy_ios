﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:59
translate chinese CR2_AS3_label_8452c3ee:

    # Caroline "*Sniff Sniff*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:60
translate chinese CR2_AS3_label_4365f561:

    # MC "(Huh?! Is she crying?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:61
translate chinese CR2_AS3_label_e60c7fb9:

    # MC "Caroline? Are you okay?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:66
translate chinese CR2_AS3_label_6c3230b8:

    # MC "(Jesus Christ! She’s crying her eyes out!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:67
translate chinese CR2_AS3_label_87609cdc:

    # MC "(What the hell happened?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:68
translate chinese CR2_AS3_label_caad2f75:

    # MC "Hey, I’m here, Caroline. What’s wrong?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:72
translate chinese CR2_AS3_label_7f525a4f:

    # Caroline "It’s... *Sniff* It’s all gone..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:73
translate chinese CR2_AS3_label_5b07a39b:

    # MC "What’s all gone?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:74
translate chinese CR2_AS3_label_9bf5b494:

    # Caroline "My money... Some of my stock..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:75
translate chinese CR2_AS3_label_6244b3da:

    # MC "Wait- You’re not saying-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:76
translate chinese CR2_AS3_label_fbdc3e11:

    # Caroline "I got robbed!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:80
translate chinese CR2_AS3_label_462be670:

    # MC "Shit! It’s okay... C’mere."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:81
translate chinese CR2_AS3_label_c0b95805:

    # MC "(She’s shaking like a leaf in the wind!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:82
translate chinese CR2_AS3_label_e927aa7c:

    # MC "(I have to do something to try and calm her down.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:86
translate chinese CR2_AS3_label_7f42d4e2:

    # MC "It’s gonna be okay, Caroline. Just sit and compose yourself there."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:87
translate chinese CR2_AS3_label_ec678dd4:

    # MC "Let me take a look around the shop and I’ll see what I can salvage for you, okay?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:88
translate chinese CR2_AS3_label_6a82360b:

    # Caroline "Y-You don’t have to d-do this..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:89
translate chinese CR2_AS3_label_f2037c4f:

    # MC "Nonsense. Just sit back and relax. Let me do the cleaning."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:93
translate chinese CR2_AS3_label_606d84d9:

    # Caroline "Are you sure?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:94
translate chinese CR2_AS3_label_406aed29:

    # MC "Honestly, just leave this to me. I’ll pack away anything and sort the furniture back into its proper place."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:95
translate chinese CR2_AS3_label_1c3f1dfd:

    # Caroline "Thank you, [player_name]. You’re so sweet."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:99
translate chinese CR2_AS3_label_a42a2935:

    # MC "Do you have any idea who might have done this?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:100
translate chinese CR2_AS3_label_7614c689:

    # Caroline "I... uh... I’m not sure."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:101
translate chinese CR2_AS3_label_97111e85:

    # MC "Tell you what - leave the cleaning to me. You report the robbery to the police, okay?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:102
translate chinese CR2_AS3_label_c149fcfc:

    # Caroline "O-Okay."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:124
translate chinese CR2_AS3a_label_b1dac1a6:

    # MC "(I have to clean up the mess here first.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:142
translate chinese CR2_AS3a_label_9f33f2f3:

    # MC "Okay! That’s me done with the cleaning. Your shop is almost back to normal!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:143
translate chinese CR2_AS3a_label_11131369:

    # Caroline "Thank you so much, [player_name]. You’re really taking the stress off me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:144
translate chinese CR2_AS3a_label_2d4d0602:

    # MC "I’m happy to help. We’ll get you through this."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:148
translate chinese CR2_AS3a_label_7660daf8:

    # MC "Have you had a chance to call the police?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:149
translate chinese CR2_AS3a_label_4bc459d2:

    # Caroline "Yeah, I reported the crime and was given an incident number. The police don’t have anyone available right now to tackle a non-urgent crime scene, but they say they’ll be in touch."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:150
translate chinese CR2_AS3a_label_44117b7a:

    # MC "Non-urgent?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:154
translate chinese CR2_AS3a_label_b06026d6:

    # Caroline "Not enough money was stolen, and nobody was physically hurt. So, it’s not an urgent case for them."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:155
translate chinese CR2_AS3a_label_9d9d63b0:

    # MC "Damn."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:156
translate chinese CR2_AS3a_label_325ba00f:

    # Caroline "I still have no money and I don’t know where to begin fixing things..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:161
translate chinese CR2_AS3a_label_dd0525ac:

    # MC "It’s okay, Caroline. I’ll be with you, every step of the way."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:162
translate chinese CR2_AS3a_label_d9c771e2:

    # Caroline "You don’t need to do this. I know this is a job for you, but I... I’m not even paying you in cash."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:164
translate chinese CR2_AS3a_label_7e6256b7:

    # MC "Your're my sister. I’ve told you this before - No matter what happens, I’ll be there to help you."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:166
translate chinese CR2_AS3a_label_1834ed4e:

    # MC "No matter what happens, I’ll be there to help you."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:170
translate chinese CR2_AS3a_label_bdb8cb2a:

    # Caroline "*Sniff* Thank you so much! You’re the best brother I could ever ask for."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:172
translate chinese CR2_AS3a_label_1abfe478:

    # Caroline "*Sniff* Thank you so much! You’re the best friend I could ever ask for."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:173
translate chinese CR2_AS3a_label_b366fb80:

    # MC "(It looks like I’ve cheered her up a bit!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:174
translate chinese CR2_AS3a_label_2d8f0561:

    # MC "(I shouldn’t rest now though - I’ll find this burglar and get revenge on them!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:178
translate chinese CR2_AS3a_label_cc9ce6a7:

    # MC "(I don’t think Caroline thought this through when she decided to give me a hug.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:179
translate chinese CR2_AS3a_label_6cd0c6c6:

    # MC "(Oh well! I’m not gonna complain! The view is amazing!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:183
translate chinese CR2_AS3a_label_87d023ca:

    # Caroline "Thanks again, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:184
translate chinese CR2_AS3a_label_0f101e21:

    # Caroline "I don’t know what I’d do without, you in my life."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:185
translate chinese CR2_AS3a_label_2b2ef32d:

    # Caroline "You’re my biggest - my ONLY - source of support, right now."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:189
translate chinese CR2_AS3a_label_3dc5b236:

    # MC "We’ll get through this together, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:190
translate chinese CR2_AS3a_label_c9075b2d:

    # MC "We just need to take it one day at a time. You focus on getting your shop back up and running."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:191
translate chinese CR2_AS3a_label_d03070ca:

    # MC "I’ll focus on the criminal side of things. Okay?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS3.rpy:192
translate chinese CR2_AS3a_label_9c295843:

    # Caroline "Okay, but be careful."
    Caroline ""

