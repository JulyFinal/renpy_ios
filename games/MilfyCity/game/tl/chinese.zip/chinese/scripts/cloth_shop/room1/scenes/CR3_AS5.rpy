﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:20
translate chinese CR3_AS5_label_ea60327e:

    # MC "(She told me to wait a few days.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:28
translate chinese CR3_AS5_label_49aa8d08:

    # MC "(I should meet up with her at the weekend.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:46
translate chinese CR3_AS5_label_d3dedb97:

    # Caroline "Thanks for coming to see me, [player_name]. I wanted to talk with you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:47
translate chinese CR3_AS5_label_923257e6:

    # MC "(Oh my God! Is she thinking of starting a new deal? I’ve definitely felt some sexual tension during our photoshoots - she HAS to have felt the same way!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:48
translate chinese CR3_AS5_label_56aa5318:

    # MC "No problem, Caroline. What’s up?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:52
translate chinese CR3_AS5_label_b6cf7ea9:

    # Caroline "I’ve sent off, my sales figures and stock details, to my accountant. I’m waiting for him to get back to me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:53
translate chinese CR3_AS5_label_6b92b2cb:

    # Caroline "I can’t guarantee it, yet - but I think we’re set, to post - record profits."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:54
translate chinese CR3_AS5_label_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:55
translate chinese CR3_AS5_label_44c57caf:

    # Caroline "Oh yeah!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:59
translate chinese CR3_AS5_label_b45c2fb0:

    # Caroline "Come back and speak with me in a few days. I should have my accountant’s breakdown then. If things are as good as I hope, then we’ll go out and celebrate together. How does that sound?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:60
translate chinese CR3_AS5_label_29f7c13f:

    # MC "Sounds great! I’ll come back in a few days."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:62
translate chinese CR3_AS5_label_828f09c7:

    # MC "(Sweet! I think I’ve just scored a date with my sister!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:64
translate chinese CR3_AS5_label_5d06f50c:

    # MC "(Sweet! I think I’ve just scored a date!) "
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:77
translate chinese CR3_AS5_label_d316abf9:

    # MC "Hey again! Did you get your accountant’s breakdown yet?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:78
translate chinese CR3_AS5_label_ffbef818:

    # Caroline "Oh yeah! And it was even better, than I hoped! The new clothes are selling faster, than guns in Texas!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:79
translate chinese CR3_AS5_label_fba2d05f:

    # MC "That’s quite the inappropriate metaphor."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:83
translate chinese CR3_AS5_label_a7b1d83c:

    # Caroline "Haha! It was the first thing to come into my head."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:84
translate chinese CR3_AS5_label_5b5a2660:

    # Caroline "I just wanted to say, thanks for your help. I know I promised that we would celebrate together, so I’ve come up with a great idea, for both of us."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:85
translate chinese CR3_AS5_label_42c50370:

    # MC "Yeah? What is it?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:89
translate chinese CR3_AS5_label_87f42a15:

    # Caroline "Well, before I tell you, I just wanted to do - one quick thing - to show my appreciation, for all you’ve done for me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:90
translate chinese CR3_AS5_label_810c268b:

    # MC "(Oh wow! She’s getting pretty close to me now.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:91
translate chinese CR3_AS5_label_dc38240f:

    # Caroline "Seriously - that’s twice now, you’ve helped save and grow my business. I owe you - big time - for that."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:95
translate chinese CR3_AS5_label_b69d8125:

    # Caroline "I couldn’t have asked for a better brother. I know I used to be quite hard on you, back when we were in elementary school together, but I wanted to let you know that I really do care about you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:97
translate chinese CR3_AS5_label_3f94daca:

    # Caroline "I couldn’t have asked for a better friend. I know I used to be quite hard on you, back when we were in elementary school together, but I wanted to let you know that I really do care about you."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:98
translate chinese CR3_AS5_label_82313b50:

    # MC "You don’t have to do anyth-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:102
translate chinese CR3_AS5_label_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:103
translate chinese CR3_AS5_label_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:104
translate chinese CR3_AS5_label_5d75cffc:

    # MC "(She just kissed me on the cheek! The deal is back on! It has to be! Right?!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:108
translate chinese CR3_AS5_label_7aa1bf08:

    # Caroline "Haha! You’re blushing!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:109
translate chinese CR3_AS5_label_b43298ba:

    # Caroline "Anyway - I wanted to let you know that I’m taking us out to celebrate."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:110
translate chinese CR3_AS5_label_a1a8be0b:

    # MC "Where are we going? Dinner? Movie?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:114
translate chinese CR3_AS5_label_6f4c3ac3:

    # Caroline "Ahaha... Not quite. Those are a bit too romantic, for the two of us - especially after what has happened."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:115
translate chinese CR3_AS5_label_a3126d30:

    # MC "Oh, so it’s not a date?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:116
translate chinese CR3_AS5_label_bf551b8d:

    # Caroline "No - at least, not between you and me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:117
translate chinese CR3_AS5_label_70634e5c:

    # MC "Huh? I’m not following you."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:121
translate chinese CR3_AS5_label_0a0ff1dc:

    # Caroline "We’re going to go out clubbing together. And - using my womanly intuition, I’m gonna help you find a girlfriend - or at the very least, get you laid."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:122
translate chinese CR3_AS5_label_bd0fbd82:

    # MC "(I... never saw that one coming. I guess the deal between us, really is dead then.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:123
translate chinese CR3_AS5_label_38339af3:

    # MC "That’s... great. What about you, though? Will it not be really awkward for you, just - watching me - chat up girls?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:124
translate chinese CR3_AS5_label_cc489075:

    # Caroline "Don’t be silly - YOU’RE gonna help ME, find a boyfriend too!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:125
translate chinese CR3_AS5_label_44288fdb:

    # MC "Oh... that’s... great!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:126
translate chinese CR3_AS5_label_a4c3310f:

    # MC "(Caroline is looking for a boyfriend? If she’s that serious about it, then the deal is definitely dead, for good. I’ll never be with her again...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:127
translate chinese CR3_AS5_label_3de2dd29:

    # Caroline "Let's go at the weekend. Just let me know, a little ahead of time. And bring about $200, to spend."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS5.rpy:128
translate chinese CR3_AS5_label_cde146c7:

    # MC "G-Good! I’m looking forward to it..."
    MC ""

