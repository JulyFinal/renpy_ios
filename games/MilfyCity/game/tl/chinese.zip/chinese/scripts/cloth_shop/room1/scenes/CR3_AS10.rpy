﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:9
translate chinese CR3_AS10_label_451a26f1:

    # MC "I've already talked with her."
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:25
translate chinese CR3_AS10_label_4f7358b2:

    # MC "Hey Caroline? Where’s Violet?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:26
translate chinese CR3_AS10_label_80897cc8:

    # Caroline "Hi, [player_name]. She’s off today. I don’t need her in."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:27
translate chinese CR3_AS10_label_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:31
translate chinese CR3_AS10_label_4b97dbdf:

    # Caroline "Sales are through the roof, right now! I don’t actually need to do any additional advertising. "
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:32
translate chinese CR3_AS10_label_2b447cfe:

    # Caroline "In fact, if I kept advertising, it would be stupid - because I can’t even keep up with the level of current orders I’m getting through."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:33
translate chinese CR3_AS10_label_baf374ba:

    # MC "(Damn, that’s a shame. I was hoping to do some more photography sessions with her.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:37
translate chinese CR3_AS10_label_066ffc1a:

    # MC "Do you think you’ll be doing any more cosplay sessions in the future?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:38
translate chinese CR3_AS10_label_c55e8301:

    # Caroline "I honestly don’t know what the future will bring. Right now though, my business is stable and growing faster than I can control it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:42
translate chinese CR3_AS10_label_86088f7b:

    # MC "I guess congratulations are in order, then!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:43
translate chinese CR3_AS10_label_cc79463d:

    # Caroline "Hehe, thanks. I’m really proud of how things are turning out!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:44
translate chinese CR3_AS10_label_f22a831d:

    # Caroline "Anyway, I’ve got two dozen more orders to pack and process before tonight’s post leaves. I’ll talk to you later."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR3_AS10.rpy:45
translate chinese CR3_AS10_label_1f5b5b97:

    # MC "No problem. Catch you later, Caroline!"
    MC ""

