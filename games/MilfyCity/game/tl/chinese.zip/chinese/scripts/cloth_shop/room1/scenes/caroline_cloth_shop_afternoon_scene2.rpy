﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:26
translate chinese caroline_cloth_shop_afternoon_scene2_label_8e68e73a:

    # Caroline "This one’s a little bit embarrassing."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:27
translate chinese caroline_cloth_shop_afternoon_scene2_label_3ed55468:

    # MC "Relax! It’s just for your business, remember? Think of the sales you’ll make!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:28
translate chinese caroline_cloth_shop_afternoon_scene2_label_800a1784:

    # Caroline "Yeah, I suppose so."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:31
translate chinese caroline_cloth_shop_afternoon_scene2_label_daf0897a:

    # MC "You do look great in it, by the way."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:32
translate chinese caroline_cloth_shop_afternoon_scene2_label_4481138e:

    # Caroline "Aww - you don’t have to say that. It’s AT LEAST one size too small, on me, anyway!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:33
translate chinese caroline_cloth_shop_afternoon_scene2_label_3cc05a35:

    # Caroline "Just look at how tight it is!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:34
translate chinese caroline_cloth_shop_afternoon_scene2_label_04bc7163:

    # MC "(It sure is!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:37
translate chinese caroline_cloth_shop_afternoon_scene2_label_8de3ee20:

    # Caroline "I’m off to get changed over here."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:38
translate chinese caroline_cloth_shop_afternoon_scene2_label_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:39
translate chinese caroline_cloth_shop_afternoon_scene2_label_4521c7a8:

    # MC "(Damn, that’s a REALLY skinny thong on that costume!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:42
translate chinese caroline_cloth_shop_afternoon_scene2_label_7ff9edeb:

    # MC "(Hmm... she normally takes a while to change out of her cosplay outfits.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:43
translate chinese caroline_cloth_shop_afternoon_scene2_label_da02a7bb:

    # MC "(Maybe I’ll have enough time to peek at her while she’s undressing!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:44
translate chinese caroline_cloth_shop_afternoon_scene2_label_9495487a:

    # MC "(Just a little bit closer...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:47
translate chinese caroline_cloth_shop_afternoon_scene2_label_401bc18e:

    # MC "(Here we go - perfect view.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:48
translate chinese caroline_cloth_shop_afternoon_scene2_label_501d8cb3:

    # MC "(I’m well hidden, so she won’t be able to see me - and I can duck around the corner if she turns quickly.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:49
translate chinese caroline_cloth_shop_afternoon_scene2_label_76b24aac:

    # MC "(Time to sit back and enjoy the show!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:52
translate chinese caroline_cloth_shop_afternoon_scene2_label_2b3e4562:

    # MC "(C’mon, Caroline. Time to undress...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:53
translate chinese caroline_cloth_shop_afternoon_scene2_label_7f1627e1:

    # MC "(Let’s see those big titties of yours!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:56
translate chinese caroline_cloth_shop_afternoon_scene2_label_bf8d289b:

    # MC "(Okay. She’s searching the drawer for her clothes.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:57
translate chinese caroline_cloth_shop_afternoon_scene2_label_2546573d:

    # MC "(God, my heart’s racing right now! Just a few more seconds, and she’ll be-)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:61
translate chinese caroline_cloth_shop_afternoon_scene2_label_8c059dd4:

    # MC "WHOOAAAAA!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:64
translate chinese caroline_cloth_shop_afternoon_scene2_label_c02ee0b1:

    # Caroline "Eeek!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:65
translate chinese caroline_cloth_shop_afternoon_scene2_label_c3aa675a:

    # Caroline "Wh-What the hell?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:66
translate chinese caroline_cloth_shop_afternoon_scene2_label_9c509c21:

    # MC "Ouch..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:67
translate chinese caroline_cloth_shop_afternoon_scene2_label_e7e9a805:

    # MC "(Fuck! The shelf broke, as I was leaning on it!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:72
translate chinese caroline_cloth_shop_afternoon_scene2_label_dab5dcab:

    # Caroline "[player_name]! What the FUCK were you doing?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:73
translate chinese caroline_cloth_shop_afternoon_scene2_label_bd19a78a:

    # MC "I... um..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:79
translate chinese caroline_cloth_shop_afternoon_scene2_label_debe0cf8:

    # MC "I was... err... dusting the shelf!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:80
translate chinese caroline_cloth_shop_afternoon_scene2_label_174f5ad9:

    # Caroline "Oh really?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:81
translate chinese caroline_cloth_shop_afternoon_scene2_label_84d56729:

    # MC "Y-Yeah?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:84
translate chinese caroline_cloth_shop_afternoon_scene2_label_796b3074:

    # Caroline "With what?! You CLEARLY don’t have a cloth or any polish!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:85
translate chinese caroline_cloth_shop_afternoon_scene2_label_a70bdc3f:

    # Caroline "PLUS, I dusted this whole place, like two hours ago!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:86
translate chinese caroline_cloth_shop_afternoon_scene2_label_1a91e5ad:

    # MC "OW! OW!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:92
translate chinese caroline_cloth_shop_afternoon_scene2_label_8f87c8d0:

    # MC "I was... um... checking if you needed any help!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:93
translate chinese caroline_cloth_shop_afternoon_scene2_label_f862f2ee:

    # Caroline "You were checking if I needed any help changing?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:94
translate chinese caroline_cloth_shop_afternoon_scene2_label_27102036:

    # MC "Yeah- I mean, NO! Err..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:97
translate chinese caroline_cloth_shop_afternoon_scene2_label_c5e01799:

    # Caroline "You little pervert! I’m paying you to take photos of me, not to perv on me while I’m changing!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:99
translate chinese caroline_cloth_shop_afternoon_scene2_label_95c7cd27:

    # Caroline "I’m your sister!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:101
translate chinese caroline_cloth_shop_afternoon_scene2_label_7b16c8f9:

    # Caroline "I’m your friend!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:102
translate chinese caroline_cloth_shop_afternoon_scene2_label_0adcc62c:

    # MC "Ouch! Ahh! I’m sorry!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:108
translate chinese caroline_cloth_shop_afternoon_scene2_label_720afbf4:

    # MC "I saw a... big... spider... over on the uhh... shelf!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:111
translate chinese caroline_cloth_shop_afternoon_scene2_label_06fb5360:

    # Caroline "A big spider, Huh?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:112
translate chinese caroline_cloth_shop_afternoon_scene2_label_dc11732f:

    # MC "Y-Yeah! A tarantula or something..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:113
translate chinese caroline_cloth_shop_afternoon_scene2_label_406659a1:

    # Caroline "You’re an awful liar."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:114
translate chinese caroline_cloth_shop_afternoon_scene2_label_33950c19:

    # MC "N-No! Really! It was... uh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:117
translate chinese caroline_cloth_shop_afternoon_scene2_label_ff70ecd9:

    # Caroline "It’s bad enough that you were spying on me while I changed..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:118
translate chinese caroline_cloth_shop_afternoon_scene2_label_75f00f18:

    # MC "OW! I’M SORRY!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:119
translate chinese caroline_cloth_shop_afternoon_scene2_label_b80c266d:

    # Caroline "But then you had to go and make things WORSE by lying to me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:120
translate chinese caroline_cloth_shop_afternoon_scene2_label_df747be1:

    # Caroline "Do you think I’m stupid?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:121
translate chinese caroline_cloth_shop_afternoon_scene2_label_e969426f:

    # MC "I’m sorry!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:126
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_0e573df9:

    # Caroline "WHAT THE FUCK?!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:127
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:128
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_6a103c1f:

    # Caroline "You’ve got a boner!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:129
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_be35a9d2:

    # MC "(Jesus Christ! Not now!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:132
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_69f9cca4:

    # MC "I-I’m sorry! I have no control over it!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:133
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_177d1600:

    # Caroline "Yes you do! You were the one SPYING on me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:134
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_147be4c4:

    # MC "(Damn, she actually has a point there...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:137
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_ace5603c:

    # Caroline "Get out of my store, this instant."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:138
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_91da422d:

    # Caroline "This evening, when I get home, we’re going to have a VERY serious discussion about boundaries."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:139
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_6cbbe8f9:

    # MC "I’m sorry, Caroline."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:140
translate chinese caroline_cloth_shop_afternoon_scene2_after_menu_a4f3901a:

    # Caroline "Just leave."
    Caroline ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:75
    old "Err... I was... dusting the shelf!"
    new ""

    # game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:75
    old "I... um... was checking if you needed any help!"
    new ""

    # game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene2.rpy:75
    old "I saw a... big... um... spider! And I had to try and catch it!"
    new ""

