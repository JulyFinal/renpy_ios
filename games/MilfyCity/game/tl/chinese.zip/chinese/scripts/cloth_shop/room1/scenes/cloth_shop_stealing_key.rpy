﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:13
translate chinese cloth_shop_stealing_key_label_d43c9b95:

    # MC "Hmm.. Let’s check.."
    MC ""

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:14
translate chinese cloth_shop_stealing_key_label_f642e9cc:

    # MC "Great! The window is still unlocked, but I should be quiet anyway."
    MC ""

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:16
translate chinese cloth_shop_stealing_key_label_5422bdef:

    # MC "Okay... I'm in. Where could she hide her spare key..?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:17
translate chinese cloth_shop_stealing_key_label_02f2277c:

    # MC "I should probably check the drawers."
    MC ""

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:19
translate chinese cloth_shop_stealing_key_label_d317cec3:

    # MC "Please.. Be here.."
    MC ""

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:21
translate chinese cloth_shop_stealing_key_label_088b155d:

    # MC "Bingo! Nice - with this I could get into her bedroom at night.."
    MC ""

# game/scripts/cloth_shop/room1/scenes/cloth_shop_stealing_key.rpy:22
translate chinese cloth_shop_stealing_key_label_ac73a6e5:

    # MC "Just in case, of course!"
    MC ""

