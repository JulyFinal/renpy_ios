﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:35
translate chinese caroline_cloth_shop_afternoon_scene3_label_1d3d84e9:

    # Caroline "Okay - that’s me ready to go."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:36
translate chinese caroline_cloth_shop_afternoon_scene3_label_e272c290:

    # Caroline "Let’s just get this photo session over, as soon as possible."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:37
translate chinese caroline_cloth_shop_afternoon_scene3_label_00cc2527:

    # MC "No problem. Do you want to strike a pose and I’ll get the camera ready."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:40
translate chinese caroline_cloth_shop_afternoon_scene3_label_b609a98c:

    # Caroline "(Oh, my God... he’s got a boner again!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:41
translate chinese caroline_cloth_shop_afternoon_scene3_label_e34edb3a:

    # Caroline "(Again?! I guess it must be his age.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:42
translate chinese caroline_cloth_shop_afternoon_scene3_label_c4784fd8:

    # Caroline "(That’s.. That’s not my problem anyway...)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:43
translate chinese caroline_cloth_shop_afternoon_scene3_label_380c85aa:

    # Caroline "Okay, let’s start."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:49
translate chinese caroline_cloth_shop_afternoon_scene3_label_1d3d84e9_1:

    # Caroline "Okay - that’s me ready to go."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:50
translate chinese caroline_cloth_shop_afternoon_scene3_label_e272c290_1:

    # Caroline "Let’s just get this photo session over, as soon as possible."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:51
translate chinese caroline_cloth_shop_afternoon_scene3_label_00cc2527_1:

    # MC "No problem. Do you want to strike a pose and I’ll get the camera ready."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:54
translate chinese caroline_cloth_shop_afternoon_scene3_label_b609a98c_1:

    # Caroline "(Oh, my God... he’s got a boner again!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:55
translate chinese caroline_cloth_shop_afternoon_scene3_label_b6bbc6c3:

    # Caroline "(I guess it must be his age. College guys have MUCH higher libidos!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:56
translate chinese caroline_cloth_shop_afternoon_scene3_label_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:60
translate chinese caroline_cloth_shop_afternoon_scene3_label_64fb50ef:

    # Caroline "(And he REALLY needs to buy himself a proper belt.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:61
translate chinese caroline_cloth_shop_afternoon_scene3_label_4d484688:

    # Caroline "(He can’t just have his dick pop out, every time he gets turned on!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:62
translate chinese caroline_cloth_shop_afternoon_scene3_label_e46d7792:

    # MC "Is everything alright, Caroline? Did you hear what I said?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:65
translate chinese caroline_cloth_shop_afternoon_scene3_label_4e6b150f:

    # Caroline "You’ve... umm... got a problem."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:66
translate chinese caroline_cloth_shop_afternoon_scene3_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:67
translate chinese caroline_cloth_shop_afternoon_scene3_label_575b486d:

    # Caroline "It’s happening again, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:68
translate chinese caroline_cloth_shop_afternoon_scene3_label_d9ab25bf:

    # MC "Wh-What?!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:72
translate chinese caroline_cloth_shop_afternoon_scene3_label_bf9b51ad:

    # MC "Oh shit! I’m so sorry!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:73
translate chinese caroline_cloth_shop_afternoon_scene3_label_e3ee35ec:

    # MC "I didn’t even notice. It was the costume!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:74
translate chinese caroline_cloth_shop_afternoon_scene3_label_48878b17:

    # Caroline "You are a sick pervert, [player_name]."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:77
translate chinese caroline_cloth_shop_afternoon_scene3_label_3ddaf962:

    # Caroline "I swear to God... after I caught you peeping last time, I thought we had this sorted."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:78
translate chinese caroline_cloth_shop_afternoon_scene3_label_d5cb263e:

    # MC "I’m sorry, Caroline! I didn’t mean to-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:79
translate chinese caroline_cloth_shop_afternoon_scene3_label_ebb08b71:

    # Caroline "Ugh! You disgust me."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:80
translate chinese caroline_cloth_shop_afternoon_scene3_label_a5e7dea4:

    # MC "I- I didn’t mean to!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:83
translate chinese caroline_cloth_shop_afternoon_scene3_label_34bc329a:

    # Caroline "Jesus Christ... You are SO hard right now!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:85
translate chinese caroline_cloth_shop_afternoon_scene3_label_d4b70626:

    # Caroline "I can’t believe you get turned on, by your own sister like this!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:87
translate chinese caroline_cloth_shop_afternoon_scene3_label_33c6b795:

    # Caroline "I can’t believe you get turned on in front of me like this!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:89
translate chinese caroline_cloth_shop_afternoon_scene3_label_689a8352:

    # Caroline "We share the same parents, you fucking sicko!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:91
translate chinese caroline_cloth_shop_afternoon_scene3_label_a2f11756:

    # Caroline "I’m LITERALLY your boss right now and you’re flashing your big cock at me!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:92
translate chinese caroline_cloth_shop_afternoon_scene3_label_d7c29c6b:

    # MC "(I’m so fucked... She’s actually gonna kill me!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:95
translate chinese caroline_cloth_shop_afternoon_scene3_label_44a2aa1e:

    # Caroline "Sit down and stay the Hell away from me, you pervert!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:96
translate chinese caroline_cloth_shop_afternoon_scene3_label_1ecd2709:

    # MC "Caroline, I SWEAR - I didn’t mean to get an erection!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:97
translate chinese caroline_cloth_shop_afternoon_scene3_label_f8648f8f:

    # MC "I can’t control them!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:101
translate chinese caroline_cloth_shop_afternoon_scene3_label_f96a7b10:

    # Caroline "Bullshit! You’re just a horny little creep."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:103
translate chinese caroline_cloth_shop_afternoon_scene3_label_7839ce8c:

    # Caroline "God... I’m gonna have to tell Dad about this."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:104
translate chinese caroline_cloth_shop_afternoon_scene3_label_eec0ad12:

    # MC "NO! Don’t say anything to Dad! PLEASE!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:105
translate chinese caroline_cloth_shop_afternoon_scene3_label_ec81d126:

    # Caroline "I’m gonna have to advertise for a new photographer too."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:106
translate chinese caroline_cloth_shop_afternoon_scene3_label_bcb72589:

    # MC "PLEASE DON’T TELL DAD!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:108
translate chinese caroline_cloth_shop_afternoon_scene3_label_bf5732ea:

    # Caroline "God... I'm gonna have to tell everybody about this."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:109
translate chinese caroline_cloth_shop_afternoon_scene3_label_7fb59d46:

    # MC "NO! Don’t say anything to anyone! PLEASE! My life at college would be ruined!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:110
translate chinese caroline_cloth_shop_afternoon_scene3_label_ec81d126_1:

    # Caroline "I’m gonna have to advertise for a new photographer too."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:111
translate chinese caroline_cloth_shop_afternoon_scene3_label_4034af69:

    # MC "PLEASE DON’T TELL ANYBODY!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:112
translate chinese caroline_cloth_shop_afternoon_scene3_label_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:116
translate chinese caroline_cloth_shop_afternoon_scene3_label_d9ba22b5:

    # Caroline "Haha..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:117
translate chinese caroline_cloth_shop_afternoon_scene3_label_a64a5a20:

    # Caroline "AHAHAHAAHAHAHA!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:118
translate chinese caroline_cloth_shop_afternoon_scene3_label_e79ed82a_1:

    # MC "Huh?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:119
translate chinese caroline_cloth_shop_afternoon_scene3_label_fe2dd8e9:

    # Caroline "Your face! HAHA! You were terrified!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:120
translate chinese caroline_cloth_shop_afternoon_scene3_label_e2e521b0:

    # MC "Is... Is this a joke?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:121
translate chinese caroline_cloth_shop_afternoon_scene3_label_b3fa27e8:

    # Caroline "Hahaha! I couldn’t resist!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:124
translate chinese caroline_cloth_shop_afternoon_scene3_label_51059a8b:

    # Caroline "My anger may have been fake - but this boner is very much real."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:125
translate chinese caroline_cloth_shop_afternoon_scene3_label_2522d56d:

    # Caroline "I’m not gonna fuck you, but let’s see what I can do to help you out."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:126
translate chinese caroline_cloth_shop_afternoon_scene3_label_050c723d:

    # MC "Caroline, you don’t have t-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:129
translate chinese caroline_cloth_shop_afternoon_scene3_label_4d4fe0bf:

    # Caroline "Shush. Don’t try to talk me out of it."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:130
translate chinese caroline_cloth_shop_afternoon_scene3_label_413e3dab:

    # Caroline "Do you seriously want me to change my mind?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:131
translate chinese caroline_cloth_shop_afternoon_scene3_label_d946a27c:

    # MC "Haha! I guess not!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:132
translate chinese caroline_cloth_shop_afternoon_scene3_label_c5a7ff7a:

    # Caroline "Good."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:135
translate chinese caroline_cloth_shop_afternoon_scene3_label_3df0e466:

    # Caroline "Now, sit back, shut up, and enjoy this."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:137
translate chinese caroline_cloth_shop_afternoon_scene3_label_2d204a49:

    # MC "..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:138
translate chinese caroline_cloth_shop_afternoon_scene3_label_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:139
translate chinese caroline_cloth_shop_afternoon_scene3_label_fe4ba86d:

    # MC "(My cock is sliding between her asscheeks!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:141
translate chinese caroline_cloth_shop_afternoon_scene3_label_7ca30957:

    # MC "Ah... She sped up..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:142
translate chinese caroline_cloth_shop_afternoon_scene3_label_1e81a9e7:

    # MC "It feels amazing..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:145
translate chinese caroline_cloth_shop_afternoon_scene3_label_eacad81f:

    # Caroline "(Shit... maybe this was a bad idea...)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:146
translate chinese caroline_cloth_shop_afternoon_scene3_label_4f61c967:

    # Caroline "(His shaft keeps brushing against my pussy.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:147
translate chinese caroline_cloth_shop_afternoon_scene3_label_28e9259d:

    # Caroline "(If I keep letting him do this I’ll get far too turned on... It would be more awkward if I just stopped now, though.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:150
translate chinese caroline_cloth_shop_afternoon_scene3_label_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:152
translate chinese caroline_cloth_shop_afternoon_scene3_label_68bc07b5:

    # MC "This is sooo good, Caroline..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:153
translate chinese caroline_cloth_shop_afternoon_scene3_label_9751a214:

    # Caroline "(And I’ve started making him happy... I’d only blueball him if I stopped now.)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:157
translate chinese caroline_cloth_shop_afternoon_scene3_label_aa808abb:

    # MC "Mmm! Yes..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:158
translate chinese caroline_cloth_shop_afternoon_scene3_label_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:159
translate chinese caroline_cloth_shop_afternoon_scene3_label_cea72b48:

    # Caroline "(Shit! I can’t let myself moan. He can’t think I’m enjoying this!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:162
translate chinese caroline_cloth_shop_afternoon_scene3_label_c3b9a031:

    # MC "(Well, this was certainly an unexpected surprise!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:163
translate chinese caroline_cloth_shop_afternoon_scene3_label_826e7cd4:

    # MC "(I didn’t think Caroline would even be, slightly open to doing something like this.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:164
translate chinese caroline_cloth_shop_afternoon_scene3_label_cbeed64c:

    # MC "(Especially after how angry she got, when she caught me peeping on her!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:167
translate chinese caroline_cloth_shop_afternoon_scene3_label_168b926e:

    # MC "(Women are strange creatures - I don’t think I’ll ever fully understand them!)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:168
translate chinese caroline_cloth_shop_afternoon_scene3_label_0a9b1258:

    # Caroline "Are you enjoying this?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:169
translate chinese caroline_cloth_shop_afternoon_scene3_label_f5ce37e0:

    # MC "Yeah, Caroline. It’s great! Can you go a bit faster?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:172
translate chinese caroline_cloth_shop_afternoon_scene3_label_1c62dcfa:

    # Caroline "Like this?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:174
translate chinese caroline_cloth_shop_afternoon_scene3_label_26230ca8:

    # MC "Ahh... That’s perfect!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:175
translate chinese caroline_cloth_shop_afternoon_scene3_label_082c097c:

    # MC "Yeee.. ahh..."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:176
translate chinese caroline_cloth_shop_afternoon_scene3_label_091f787c:

    # MC "Ahh! Mmmm!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:179
translate chinese caroline_cloth_shop_afternoon_scene3_label_90025e78:

    # MC "Fuck! I’m getting close!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:180
translate chinese caroline_cloth_shop_afternoon_scene3_label_47086bfd:

    # Caroline "You’re gonna cum?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:181
translate chinese caroline_cloth_shop_afternoon_scene3_label_41cf0485:

    # Caroline "Just be careful that you don’t get any over the costume! I still have to sell this!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:184
translate chinese caroline_cloth_shop_afternoon_scene3_label_e2cebd21:

    # MC "Ahhhh! I’m cumming!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:192
translate chinese caroline_cloth_shop_afternoon_scene3_label_0bbede25:

    # MC "Ugh! Fuck!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:193
translate chinese caroline_cloth_shop_afternoon_scene3_label_f59bce66:

    # Caroline "(Wow! He came REALLY hard there! I think he enjoyed that!)"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:196
translate chinese caroline_cloth_shop_afternoon_scene3_label_e06ee05c:

    # MC "Phew... That was amazing."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:197
translate chinese caroline_cloth_shop_afternoon_scene3_label_90197bc7:

    # MC "Thanks for that, Caroline. You were incredible!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:198
translate chinese caroline_cloth_shop_afternoon_scene3_label_6029e81e:

    # Caroline "I don’t know what you’re talking about?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:201
translate chinese caroline_cloth_shop_afternoon_scene3_label_697bd21a:

    # MC "What you just did there now-"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:202
translate chinese caroline_cloth_shop_afternoon_scene3_label_77205b10:

    # Caroline "We were about to take some photos. Hurry up and get the camera ready!"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:203
translate chinese caroline_cloth_shop_afternoon_scene3_label_fc70cf49:

    # MC "Uh, okay! Sure. But seriously, you were amazing with your ass, back there."
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:204
translate chinese caroline_cloth_shop_afternoon_scene3_label_3bbe7747:

    # Caroline "I think your imagination has run a little wild, [player_name]. Nothing happened."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:205
translate chinese caroline_cloth_shop_afternoon_scene3_label_ecea3bc0:

    # MC "(Huh?! Why is she acting like she didn’t just, grind against my cock?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/caroline_cloth_shop_afternoon_scene3.rpy:206
translate chinese caroline_cloth_shop_afternoon_scene3_label_aea8892f:

    # Caroline "Come on! We have photos to take! Chop chop!"
    Caroline ""

