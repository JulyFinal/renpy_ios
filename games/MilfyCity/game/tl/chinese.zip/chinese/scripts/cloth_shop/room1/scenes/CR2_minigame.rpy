﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR2_minigame.rpy:10
translate chinese CR2_minigame_label_a74d5abe:

    # Caroline "Hi again, [player_name]. Back to help me with some more cosplay photoshoots?"
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_minigame.rpy:12
translate chinese CR2_minigame_label_782d6bd9:

    # MC "Sure, Caroline! What have you got in stock this time?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_minigame.rpy:16
translate chinese CR2_minigame_label_a723c8a5:

    # Caroline "I’ve got for a real mixture of things again. Give me a shout whenever you’re ready."
    Caroline ""

# game/scripts/cloth_shop/room1/scenes/CR2_minigame.rpy:17
translate chinese CR2_minigame_label_7aef8ac9:

    # Caroline "I’ve got a strong feeling you’ll really like them."
    Caroline ""

translate chinese strings:

    # game/scripts/cloth_shop/room1/scenes/CR2_minigame.rpy:19
    old "Sure! We can start."
    new ""

    # game/scripts/cloth_shop/room1/scenes/CR2_minigame.rpy:19
    old "Not now."
    new ""

