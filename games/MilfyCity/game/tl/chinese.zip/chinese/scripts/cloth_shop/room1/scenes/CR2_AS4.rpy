﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:16
translate chinese CR2_AS4_label_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:17
translate chinese CR2_AS4_label_2dc4fd97:

    # MC "(What’s this thing? A bottle of perfume maybe?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:22
translate chinese CR2_AS4_label_32751dc8:

    # MC "(It’s made of glass, and there’s a thick black liquid inside.)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:23
translate chinese CR2_AS4_label_997bfaa0:

    # MC "(Could it be... nail polish?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:24
translate chinese CR2_AS4_label_39fcf974:

    # MC "(Caroline never wears black nail polish...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:28
translate chinese CR2_AS4_label_0dda33e6:

    # MC "(Oh no...)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:29
translate chinese CR2_AS4_label_882849fd:

    # MC "(That girl that Caroline brought to our house... What was her name? Violet?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:33
translate chinese CR2_AS4_label_b153345c:

    # MC "Shit! Violet must have been here!"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:34
translate chinese CR2_AS4_label_912f6cef:

    # MC "(Could she be involved in the robbery?)"
    MC ""

# game/scripts/cloth_shop/room1/scenes/CR2_AS4.rpy:35
translate chinese CR2_AS4_label_463f81ee:

    # MC "(Maybe I'll ask Caroline where Violet is.)"
    MC ""

