﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/intro.rpy:79
translate chinese intro_efe69313:

    # "Hey there! W-wait! Don’t skip ME!"
    ""

# game/scripts/intro.rpy:80
translate chinese intro_20d2e74a:

    # "Before we get to the prologue, give me a chance to quickly tell you a few things!"
    ""

# game/scripts/intro.rpy:83
translate chinese intro_6ef66332:

    # "The first important piece of information is that this game is fully interactive! Maps, inventory, items, minigames, freedom to interact with whichever characters you want to!"
    ""

# game/scripts/intro.rpy:84
translate chinese intro_3451195c:

    # "YOU get to decide which stories you want to progress and which girls you want to pursue! Some characters are connected in some way, but not all of them! Be sure to just check most of them!"
    ""

# game/scripts/intro.rpy:87
translate chinese intro_873336b2:

    # "The second important piece of information is that this game has animated sex scenes!"
    ""

# game/scripts/intro.rpy:88
translate chinese intro_1ed1cf80:

    # "Yep! That’s it! A-N-I-M-A-T-E-D!! You heard me well!"
    ""

# game/scripts/intro.rpy:92
translate chinese intro_ea0a101e:

    # "Just check out THIS shit!"
    ""

# game/scripts/intro.rpy:97
translate chinese intro_015af003:

    # "Alright! With that out of the way, you’re ready to jump into the game. Have fun!"
    ""

# game/scripts/intro.rpy:108
translate chinese intro_7e6bc7c1:

    # Judy "Are you alright?"
    Judy ""

# game/scripts/intro.rpy:109
translate chinese intro_11fcbeff:

    # Judy "Hey, you need to wake up."
    Judy ""

# game/scripts/intro.rpy:112
translate chinese intro_b222605a:

    # MC "Huh?! Where am I?!"
    MC ""

# game/scripts/intro.rpy:113
translate chinese intro_3535fe3d:

    # Judy "It’s me, Judy - the campus therapist."
    Judy ""

# game/scripts/intro.rpy:115
translate chinese intro_377055fc:

    # Judy "I asked you to close your eyes and try to recall yesterday’s events. However, judging by your, rather sonorous snoring, it appears that you fell asleep on me."
    Judy ""

# game/scripts/intro.rpy:116
translate chinese intro_370460db:

    # MC "Oh, oh yeah. Sorry, I didn’t really sleep last night."
    MC ""

# game/scripts/intro.rpy:117
translate chinese intro_17819aa1:

    # Judy "Hmm, that’s understandable given what happened. Try sitting back in your chair and relaxing. Make yourself comfortable."
    Judy ""

# game/scripts/intro.rpy:120
translate chinese intro_6a73eb1c:

    # MC "Okay, no problem."
    MC ""

# game/scripts/intro.rpy:121
translate chinese intro_8d8a5b17:

    # Judy "In fact, before we continue, I just need to check that I have your details correct. You know, GDPR and all that crap."
    Judy ""

# game/scripts/intro.rpy:122
translate chinese intro_dade9d13:

    # Judy "You’re in Ms. Celia’s class, is that correct?"
    Judy ""

# game/scripts/intro.rpy:123
translate chinese intro_afc8cc1f:

    # MC "Yeah..."
    MC ""

# game/scripts/intro.rpy:124
translate chinese intro_4f3ffc86:

    # Judy "Good, and is your name spelled correctly here?"
    Judy ""

# game/scripts/intro.rpy:132
translate chinese intro_2c1698ad:

    # Judy "And your mother is... Linda?"
    Judy ""

# game/scripts/intro.rpy:133
translate chinese intro_ef7f6b72:

    # MC "Yes, that’s her."
    MC ""

# game/scripts/intro.rpy:135
translate chinese intro_b2c6d00e:

    # Judy "And you are currently residing at this address?"
    Judy ""

# game/scripts/intro.rpy:136
translate chinese intro_07266d13:

    # MC "Yes."
    MC ""

# game/scripts/intro.rpy:137
translate chinese intro_5989062e:

    # Judy "And your emergency contact is... your landlady, Linda?"
    Judy ""

# game/scripts/intro.rpy:138
translate chinese intro_41a403e2:

    # MC "Correct."
    MC ""

# game/scripts/intro.rpy:142
translate chinese intro_148dad38:

    # Judy "Okay, everything seems to be in order."
    Judy ""

# game/scripts/intro.rpy:143
translate chinese intro_9bdab984:

    # Judy "I’m gonna take a couple of minutes to go over everything again."
    Judy ""

# game/scripts/intro.rpy:144
translate chinese intro_12254481:

    # Judy "My name’s Judy Reneaux. As I previously mentioned, I’m the campus therapist."
    Judy ""

# game/scripts/intro.rpy:145
translate chinese intro_5a2d66c0:

    # Judy "What happened yesterday was-"
    Judy ""

# game/scripts/intro.rpy:148
translate chinese intro_f737bece:

    # MC "Relax! Everything is fine! Really - I promise."
    MC ""

# game/scripts/intro.rpy:149
translate chinese intro_88b5edad:

    # Judy "[player_name], what happened was very serious. You can’t just-"
    Judy ""

# game/scripts/intro.rpy:150
translate chinese intro_e6806bf2:

    # MC "Everything’s cool - I can handle myself."
    MC ""

# game/scripts/intro.rpy:151
translate chinese intro_964f48ec:

    # Judy "I’m not satisfied that everything is “fine.” The college provides this counseling service for your own wellbeing. I would strongly encourage you to engage with the process."
    Judy ""

# game/scripts/intro.rpy:152
translate chinese intro_7f153f1c:

    # MC "I- I don’t want to think about yesterday ever again. I’m going to leave now and pretend like it never happened."
    MC ""

# game/scripts/intro.rpy:153
translate chinese intro_e1eddbfb:

    # MC "Haha! Honestly, it’s a joke that I’m even here at all. This has been blown WAY out of proportion."
    MC ""

# game/scripts/intro.rpy:156
translate chinese intro_bc0cfe0f:

    # Judy "But it DID happen, [player_name]. The fact that you simply choose not to address it isn’t a healthy response to this situation."
    Judy ""

# game/scripts/intro.rpy:157
translate chinese intro_9ac434b4:

    # Judy "Avoidant behaviours are common in people recovering from trauma."
    Judy ""

# game/scripts/intro.rpy:158
translate chinese intro_7b681c9c:

    # Judy "Besides, if you do leave this room right now, I will have no choice but to countersign this letter of expulsion."
    Judy ""

# game/scripts/intro.rpy:162
translate chinese intro_4184402a:

    # Judy "I see you’ve stopped walking towards the door. Were you unaware that I report directly to the Dean?"
    Judy ""

# game/scripts/intro.rpy:163
translate chinese intro_c7f0b614:

    # Judy "He asked me to monitor your progress and behaviour, [player_name]."
    Judy ""

# game/scripts/intro.rpy:164
translate chinese intro_5f1a0a6e:

    # Judy "I know you don’t feel like talking right now, but I promise you [player_name], this is for your own good."
    Judy ""

# game/scripts/intro.rpy:169
translate chinese intro_a1a29a27:

    # Judy "What happened to you was embarrassing. Tremendously so. I can’t even begin to imagine how you must feel right now."
    Judy ""

# game/scripts/intro.rpy:170
translate chinese intro_56d722c3:

    # Judy "But running away from this won’t fix anything. Please, help me to help you. Take a seat. Let’s talk things through."
    Judy ""

# game/scripts/intro.rpy:171
translate chinese intro_45e8005a:

    # Judy "You can trust me."
    Judy ""

# game/scripts/intro.rpy:172
translate chinese intro_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/intro.rpy:174
translate chinese intro_9e829852:

    # MC "Fine... Please don’t send that letter to the Dean though. I really need to graduate, and my mom will kill me. She’s got a real hatred of NEETs."
    MC ""

# game/scripts/intro.rpy:175
translate chinese intro_f263bce9:

    # Judy "(I know she would. Linda would be raging if you will be kicked out of college.)"
    Judy ""

# game/scripts/intro.rpy:177
translate chinese intro_a97d0bf5:

    # MC "Fine... Please don’t send that letter to the Dean though. I really need to graduate, and my landlady will kick me out if I get expelled. She’s got a real hatred of NEETs..."
    MC ""

# game/scripts/intro.rpy:178
translate chinese intro_42e44fb9:

    # Judy "(Oh, I KNOW she would. Linda would be furious if one of her tenants dropped out of college. No enrollment means no college grants, which means no rent!)"
    Judy ""

# game/scripts/intro.rpy:179
translate chinese intro_38912d8d:

    # Judy "I’m glad you changed your mind. Take a seat. Let’s start at the beginning."
    Judy ""

# game/scripts/intro.rpy:184
translate chinese q1_intro_8a888b74:

    # Judy "Before we begin, is there anything you’d like to ask me?"
    Judy ""

# game/scripts/intro.rpy:197
translate chinese q1_a1_intro_14220640:

    # Judy "Of course, [player_name]. It’s best when patients feel comfortable with their therapist."
    Judy ""

# game/scripts/intro.rpy:198
translate chinese q1_a1_intro_9c16e345:

    # Judy "My full name is Judy Reneaux. I’m a qualified therapist. I graduated from the University of Wisconsin four years ago. I’ve been working in this institution ever since."
    Judy ""

# game/scripts/intro.rpy:201
translate chinese q1_a2_intro_c920a580:

    # Judy "As long as it is required. You can’t rush these things, [player_name]."
    Judy ""

# game/scripts/intro.rpy:202
translate chinese q1_a2_intro_d193fc6c:

    # Judy "Some people can be out of therapy in three or four sessions. Other people take... a bit longer. What matters is that you are making progress."
    Judy ""

# game/scripts/intro.rpy:203
translate chinese q1_a2_intro_5b49dcf1:

    # Judy "Don’t view your treatment as a race to the finish line. Think of it as... a meandering journey."
    Judy ""

# game/scripts/intro.rpy:204
translate chinese q1_a2_intro_45538c90:

    # MC "Huh... I guess so. I don’t like the idea of it going on for a long time though."
    MC ""

# game/scripts/intro.rpy:205
translate chinese q1_a2_intro_7e93b208:

    # Judy "I’ll tell you what. If your therapy starts to drag on for a long time we can have some discussions about some alternative treatments. "
    Judy ""

# game/scripts/intro.rpy:206
translate chinese q1_a2_intro_a160e4e5:

    # Judy "Let’s give this therapy a shot first. I don’t like immediately jumping to medications to treat those experiencing trauma."
    Judy ""

# game/scripts/intro.rpy:209
translate chinese after_q1_intro_3747d6f3:

    # Judy "Now tell me, [player_name], what happened yesterday?"
    Judy ""

# game/scripts/intro.rpy:216
translate chinese after_q1_intro_347ac3fe:

    # Sara "Hey, [player_name]! Wake up! You’re gonna be late for college!"
    Sara ""

# game/scripts/intro.rpy:217
translate chinese after_q1_intro_2f7e4652:

    # MC "*Yawn* Five more minutes, Sara..."
    MC ""

# game/scripts/intro.rpy:219
translate chinese after_q1_intro_6047ca06:

    # Sara "You’re gonna be laaaate!"
    Sara ""

# game/scripts/intro.rpy:222
translate chinese after_q1_intro_bc50fcf3:

    # MC "*Sigh* Fine! I’m awake..."
    MC ""

# game/scripts/intro.rpy:223
translate chinese after_q1_intro_b5bfb578:

    # Sara "So, are you actually gonna do it?"
    Sara ""

# game/scripts/intro.rpy:224
translate chinese after_q1_intro_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/intro.rpy:225
translate chinese after_q1_intro_74218fbc:

    # Sara "Are you really gonna ask Ms. Celia out today?"
    Sara ""

# game/scripts/intro.rpy:226
translate chinese after_q1_intro_6e64d9b9:

    # MC "Yeah, of course I am."
    MC ""

# game/scripts/intro.rpy:229
translate chinese after_q1_intro_9c20de95:

    # Sara "I don’t think it’s a good idea, [player_name]. It seems unusual for a student to ask their Professor out on a date... I mean, she’s DEFINITELY gonna reject you."
    Sara ""

# game/scripts/intro.rpy:230
translate chinese after_q1_intro_57ab69ae:

    # MC "Pfft! You’re worrying too much, Sara! Everything is going to be fine. She’ll say yes and I will FINALLY get laid!"
    MC ""

# game/scripts/intro.rpy:231
translate chinese after_q1_intro_d7964b1d:

    # Sara "Is getting laid the only thing you ever think about?!"
    Sara ""

# game/scripts/intro.rpy:232
translate chinese after_q1_intro_f1284558:

    # Sara "Besides, what makes you think that Ms. Celia is even interested in dating you?!"
    Sara ""

# game/scripts/intro.rpy:235
translate chinese after_q1_intro_d579e017:

    # MC "Because we’re on a first-name basis! She lets me call her Celia!"
    MC ""

# game/scripts/intro.rpy:236
translate chinese after_q1_intro_58e7c08b:

    # Sara "So? I call some of my professors by their first names."
    Sara ""

# game/scripts/intro.rpy:237
translate chinese after_q1_intro_35b7af71:

    # MC "It’s not just that! She’s ALWAYS looking at me and smiling."
    MC ""

# game/scripts/intro.rpy:238
translate chinese after_q1_intro_a0e5991b:

    # Sara "Maybe she’s just a happy person?"
    Sara ""

# game/scripts/intro.rpy:239
translate chinese after_q1_intro_ea09c72b:

    # MC "Plus, this one time she touched my ass when I was walking down the corridor!"
    MC ""

# game/scripts/intro.rpy:242
translate chinese after_q1_intro_f1cd4155:

    # Sara "Are you sure her hand didn’t just slip?"
    Sara ""

# game/scripts/intro.rpy:243
translate chinese after_q1_intro_e8746b04:

    # MC "What?! No! She definitely touched me on purpose!"
    MC ""

# game/scripts/intro.rpy:244
translate chinese after_q1_intro_cf645880:

    # MC "(At least... I think so...)"
    MC ""

# game/scripts/intro.rpy:245
translate chinese after_q1_intro_a1aca83c:

    # Sara "Hey! What are you doing?! I’m still here!"
    Sara ""

# game/scripts/intro.rpy:248
translate chinese after_q1_intro_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/intro.rpy:249
translate chinese after_q1_intro_1a4b526b:

    # Sara "You’re getting changed! At least give me a warning, so I don’t have to see your icky ass!"
    Sara ""

# game/scripts/intro.rpy:250
translate chinese after_q1_intro_11c1104e:

    # MC "Oh please - you’ve got one too. If it really bothers you then get out of my room!"
    MC ""

# game/scripts/intro.rpy:251
translate chinese after_q1_intro_38999832:

    # Sara "It’s just not-"
    Sara ""

# game/scripts/intro.rpy:254
translate chinese after_q1_intro_a13aa0ad:

    # Sara "Eeek! [player_name]! Put some clothes on!"
    Sara ""

# game/scripts/intro.rpy:255
translate chinese after_q1_intro_edb16d40:

    # MC "I DID tell you to get out of my room!"
    MC ""

# game/scripts/intro.rpy:256
translate chinese after_q1_intro_67291328:

    # Sara "Eww! Fine! But please listen to my advice - DON’T ask out Ms. Celia! This will end badly."
    Sara ""

# game/scripts/intro.rpy:257
translate chinese after_q1_intro_cdf8988a:

    # MC "Relax, Sara. What’s the worst that could happen?"
    MC ""

# game/scripts/intro.rpy:263
translate chinese after_q1_intro_b083f9e8:

    # Judy "Hmm... Interesting... Do you mind if I ask you a few questions about Sara?"
    Judy ""

# game/scripts/intro.rpy:264
translate chinese after_q1_intro_b9fb767d:

    # MC "I guess so."
    MC ""

# game/scripts/intro.rpy:269
translate chinese q2_intro_c44a0f8e:

    # Judy "What’s Sara like?"
    Judy ""

# game/scripts/intro.rpy:272
translate chinese q2_intro_ae25ca5b:

    # MC "Sara’s a huge nerd. She spends her free time playing video games, going to comic-cons, and watching geeky British TV shows."
    MC ""

# game/scripts/intro.rpy:273
translate chinese q2_intro_5d276310:

    # Judy "Do you enjoy these things yourself?"
    Judy ""

# game/scripts/intro.rpy:274
translate chinese q2_intro_98b696a1:

    # MC "I mean, video games are fun - but I don’t really get the appeal of comic-cons or the shows she watches."
    MC ""

# game/scripts/intro.rpy:281
translate chinese q2_intro_9c736e2a:

    # MC "She’s acing her college modules in Maths, Biology, and Chemistry. I think she actually wants to become a computer scientist someday."
    MC ""

# game/scripts/intro.rpy:283
translate chinese q2_intro_7243d22b:

    # Judy "She sounds very intelligent. You must be very proud to have her as a sister."
    Judy ""

# game/scripts/intro.rpy:285
translate chinese q2_intro_65336da5:

    # Judy "She sounds very intelligent. You must be very proud to have a friend as clever as her."
    Judy ""

# game/scripts/intro.rpy:286
translate chinese q2_intro_8e7df339:

    # MC "I guess so. I’ve never really thought about it. "
    MC ""

# game/scripts/intro.rpy:293
translate chinese q2_intro_fc3ac392:

    # MC "Sara keeps to herself mostly. She’s got a couple of close friends from her classes, like Lily. I think she prefers hanging out with small groups of people rather than large crowds."
    MC ""

# game/scripts/intro.rpy:294
translate chinese q2_intro_66cc2dd8:

    # Judy "Hmm... In my profession, we would call that ‘introverted’. Basically, she finds time in smaller groups more rewarding."
    Judy ""

# game/scripts/intro.rpy:295
translate chinese q2_intro_ce2e3812:

    # Judy "Consequently, large social situations can be particularly tiresome for introverts."
    Judy ""

# game/scripts/intro.rpy:304
translate chinese after_q2_intro_06619993:

    # Judy "Thank you for answering my question. My next one might... be a little awkward, but we are going to have to delve into some Freudian psychoanalysis techniques."
    Judy ""

# game/scripts/intro.rpy:305
translate chinese after_q2_intro_28c7f0f2:

    # MC "Psycho-what?"
    MC ""

# game/scripts/intro.rpy:307
translate chinese after_q2_intro_a677e793:

    # Judy "Freudian Psychoanalysis. Tell me, [player_name], do you find your sister, Sara, sexually attractive?"
    Judy ""

# game/scripts/intro.rpy:309
translate chinese after_q2_intro_244d760d:

    # Judy "Freudian Psychoanalysis. Tell me, [player_name], do you find your friend, Sara, sexually attractive?"
    Judy ""

# game/scripts/intro.rpy:311
translate chinese after_q2_intro_d9ab25bf:

    # MC "Wh-What?!"
    MC ""

# game/scripts/intro.rpy:313
translate chinese after_q2_intro_03ee9192:

    # Judy "Do you think your sister is sexy?"
    Judy ""

# game/scripts/intro.rpy:315
translate chinese after_q2_intro_2b07450a:

    # Judy "Do you think your friend is sexy?"
    Judy ""

# game/scripts/intro.rpy:316
translate chinese after_q2_intro_85c549dd:

    # MC "I- How- This isn’t an appropriate question!"
    MC ""

# game/scripts/intro.rpy:319
translate chinese after_q2_intro_bdc9d531:

    # Judy "I assure you, it absolutely is. Freudian Psychology delves into the nature of human sexuality. "
    Judy ""

# game/scripts/intro.rpy:320
translate chinese after_q2_intro_17458b2f:

    # Judy "Given the nature of this incident, which brought you to me, a sexualised element of psychology is most definitely relevant."
    Judy ""

# game/scripts/intro.rpy:322
translate chinese after_q2_intro_1421982c:

    # MC "But... She’s my sister..."
    MC ""

# game/scripts/intro.rpy:324
translate chinese after_q2_intro_20166526:

    # MC "But... We're living in the same house... We're tenants and we're going to the same college."
    MC ""

# game/scripts/intro.rpy:325
translate chinese after_q2_intro_84ec5e5b:

    # Judy "How often do you fantasise about having sex with Sara?"
    Judy ""

# game/scripts/intro.rpy:328
translate chinese after_q2_intro_a59da6d0:

    # MC "(Honestly? I’ve thought about fucking her more than once. I bumped into her as she came out of the shower last week. Her towel fell off and I caught a glimpse of her naked body.)"
    MC ""

# game/scripts/intro.rpy:329
translate chinese after_q2_intro_f47f6223:

    # MC "(I must have wanked to that mental image for a solid week!)"
    MC ""

# game/scripts/intro.rpy:330
translate chinese after_q2_intro_fd9a4d7c:

    # MC "These questions are really weird. I’m not... I’m not comfortable talking about these."
    MC ""

# game/scripts/intro.rpy:333
translate chinese after_q2_intro_76a96796:

    # Judy "Understandable. You are still in the early stages of your treatment. It may take you some time to fully open up. "
    Judy ""

# game/scripts/intro.rpy:334
translate chinese after_q2_intro_e5b7aef2:

    # Judy "It is essential that you are honest with me, if you want to completely heal."
    Judy ""

# game/scripts/intro.rpy:336
translate chinese after_q2_intro_51cbc8ec:

    # MC "*Sigh* Fine. I guess I’ve... maybe... fantasised about my sisters, a couple of times."
    MC ""

# game/scripts/intro.rpy:338
translate chinese after_q2_intro_9f3d089d:

    # MC "*Sigh* Fine. I guess I’ve... maybe... fantasised about Sara a couple of times."
    MC ""

# game/scripts/intro.rpy:339
translate chinese after_q2_intro_7ea8f131:

    # Judy "Interesting..."
    Judy ""

# game/scripts/intro.rpy:340
translate chinese after_q2_intro_32ea5ea7:

    # Judy "We can return to this subject-matter another time. For now, please tell me what happened next, on the day of the incident."
    Judy ""

# game/scripts/intro.rpy:341
translate chinese after_q2_intro_d6b4a5d4:

    # MC "Let me think... I was just about to leave for college."
    MC ""

# game/scripts/intro.rpy:348
translate chinese after_q2_intro_f7c85611:

    # MC "(Crap! Sara was right! I’m gonna be late if I don’t hurry!)"
    MC ""

# game/scripts/intro.rpy:349
translate chinese after_q2_intro_1fefb54f:

    # MC "(I think she already started walking ten minutes ago! I shouldn’t have spent so much time in the shower!)"
    MC ""

# game/scripts/intro.rpy:356
translate chinese after_q2_intro_bfa0c88e:

    # Mom "Where are you rushing off to?"
    Mom ""

# game/scripts/intro.rpy:357
translate chinese after_q2_intro_10b26c98:

    # MC "I’m gonna be late for college!"
    MC ""

# game/scripts/intro.rpy:358
translate chinese after_q2_intro_2136e876:

    # Mom "Have you not forgotten to say good morning to someone?"
    Mom ""

# game/scripts/intro.rpy:360
translate chinese after_q2_intro_2aabc9df:

    # MC "Morning, Mom! I’ll see you late-"
    MC ""

# game/scripts/intro.rpy:362
translate chinese after_q2_intro_609b9ccf:

    # MC "Morning, Linda! I’ll see you late-"
    MC ""

# game/scripts/intro.rpy:364
translate chinese after_q2_intro_1aac1058:

    # Mom "Oh, come on. You’ve got time to greet me properly."
    Mom ""

# game/scripts/intro.rpy:365
translate chinese after_q2_intro_f2a6cd22:

    # Mom "You’ll stress yourself out if you keep rushing around."
    Mom ""

# game/scripts/intro.rpy:366
translate chinese after_q2_intro_857742b6:

    # MC "I really AM in a hurry."
    MC ""

# game/scripts/intro.rpy:367
translate chinese after_q2_intro_a76eb07f:

    # Mom "Why? Is something special happening today?"
    Mom ""

# game/scripts/intro.rpy:368
translate chinese after_q2_intro_2b5fb030:

    # MC "Uhh... N-No!"
    MC ""

# game/scripts/intro.rpy:371
translate chinese after_q2_intro_a0c91f34:

    # Mom "Then come over and give me a kiss, at the very least."
    Mom ""

# game/scripts/intro.rpy:372
translate chinese after_q2_intro_f1f163dd:

    # MC "Fine, no problem."
    MC ""

# game/scripts/intro.rpy:373
translate chinese after_q2_intro_661344de:

    # Mom "On the lips."
    Mom ""

# game/scripts/intro.rpy:375
translate chinese after_q2_intro_c0a044b9:

    # MC "Seriously, Mom? NOBODY my age kisses their mom on the lips anymore! If anyone on campus found out I’d get laughed out of college!"
    MC ""

# game/scripts/intro.rpy:377
translate chinese after_q2_intro_9821c466:

    # MC "Seriously Linda? I don’t know ANYBODY who kisses their landlady! If anyone on campus found out I’d get laughed out of college!"
    MC ""

# game/scripts/intro.rpy:378
translate chinese after_q2_intro_40b00825:

    # Mom "You'd better make sure nobody finds out, then."
    Mom ""

# game/scripts/intro.rpy:388
translate chinese choice1_intro_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/intro.rpy:389
translate chinese choice1_intro_47af8d01:

    # MC "Sorry Mom, I’m too old for that now. I’ll see you later, when I get home from college."
    MC ""

# game/scripts/intro.rpy:392
translate chinese choice1_intro_fa68aa9e:

    # Mom "Hmmpf!"
    Mom ""

# game/scripts/intro.rpy:393
translate chinese choice1_intro_d8a70321:

    # Mom "(Why won’t he kiss me?! It’s not like any of his classmates are around to see him do it...)"
    Mom ""

# game/scripts/intro.rpy:399
translate chinese choice1_intro_475bf5d7:

    # MC "Haha, okay Mom. If it’ll make you happy."
    MC ""

# game/scripts/intro.rpy:400
translate chinese choice1_intro_babe1dc8:

    # Mom "It will...."
    Mom ""

# game/scripts/intro.rpy:403
translate chinese choice1_intro_5f42c72e:

    # Mom "*Whispered* It really will..."
    Mom ""

# game/scripts/intro.rpy:404
translate chinese choice1_intro_e213044f:

    # MC "(Huh? Mom’s acting a little strange today. I wonder if she’s feeling alright.)"
    MC ""

# game/scripts/intro.rpy:407
translate chinese choice1_intro_7f0c53e5_1:

    # MC "*Mwah*"
    MC ""

# game/scripts/intro.rpy:408
translate chinese choice1_intro_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/intro.rpy:409
translate chinese choice1_intro_dd929047:

    # Mom "(God... I wish I could just pin him down on the bed and make out with him.)"
    Mom ""

# game/scripts/intro.rpy:415
translate chinese choice1_intro_7f0c53e5_2:

    # MC "*Mwah*"
    MC ""

# game/scripts/intro.rpy:416
translate chinese choice1_intro_6721c277:

    # MC "Sorry Linda, I’m not comfortable kissing you on the lips. I’ll see you later when I get back from college."
    MC ""

# game/scripts/intro.rpy:419
translate chinese choice1_intro_fa68aa9e_1:

    # Mom "Hmmpf!"
    Mom ""

# game/scripts/intro.rpy:420
translate chinese choice1_intro_d8a70321_1:

    # Mom "(Why won’t he kiss me?! It’s not like any of his classmates are around to see him do it...)"
    Mom ""

# game/scripts/intro.rpy:426
translate chinese choice1_intro_5c56d596:

    # MC "Haha, okay Linda. If it’ll make you happy."
    MC ""

# game/scripts/intro.rpy:427
translate chinese choice1_intro_babe1dc8_1:

    # Mom "It will...."
    Mom ""

# game/scripts/intro.rpy:430
translate chinese choice1_intro_5f42c72e_1:

    # Mom "*Whispered* It really will..."
    Mom ""

# game/scripts/intro.rpy:431
translate chinese choice1_intro_41b172a7:

    # MC "(Huh, Linda is acting a little strange today. I wonder if she’s feeling alright.)"
    MC ""

# game/scripts/intro.rpy:434
translate chinese choice1_intro_7f0c53e5_3:

    # MC "*Mwah*"
    MC ""

# game/scripts/intro.rpy:435
translate chinese choice1_intro_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/intro.rpy:436
translate chinese choice1_intro_dd929047_1:

    # Mom "(God... I wish I could just pin him down on the bed and make out with him.)"
    Mom ""

# game/scripts/intro.rpy:443
translate chinese after_choice1_intro_3f31412c:

    # MC "I’ll see you later, Mom. Make sure you study hard!"
    MC ""

# game/scripts/intro.rpy:444
translate chinese after_choice1_intro_de15a1de:

    # Mom "See you tonight, Sweetpea!"
    Mom ""

# game/scripts/intro.rpy:446
translate chinese after_choice1_intro_5e2df142:

    # MC "I’ll see you later, Linda."
    MC ""

# game/scripts/intro.rpy:449
translate chinese after_choice1_intro_118a741a:

    # Mom "(Ooh... I’m starting to get wet, just thinking about making out with him.)"
    Mom ""

# game/scripts/intro.rpy:458
translate chinese after_choice1_intro_6437994d:

    # Judy "Your mother sounds like a very interesting person. She clearly cares about you, an awful lot."
    Judy ""

# game/scripts/intro.rpy:460
translate chinese after_choice1_intro_cce0a410:

    # Judy "Your landlady sounds like a very interesting person. She clearly cares about you an awful lot."
    Judy ""

# game/scripts/intro.rpy:461
translate chinese after_choice1_intro_424bcb89:

    # MC "Yeah, I guess she does."
    MC ""

# game/scripts/intro.rpy:462
translate chinese after_choice1_intro_293d86da:

    # Judy "We’ll come back to talk about HER later. For now though, please tell me about the incident."
    Judy ""

# game/scripts/intro.rpy:463
translate chinese after_choice1_intro_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/intro.rpy:464
translate chinese after_choice1_intro_9571d75f:

    # Judy "I know this is difficult. Please take your time. If you need to take a break, just let me know."
    Judy ""

# game/scripts/intro.rpy:473
translate chinese after_choice1_intro_380cca05:

    # MC "Ms. Celia?"
    MC ""

# game/scripts/intro.rpy:474
translate chinese after_choice1_intro_baec6574:

    # Celia "Please, I told you to just call me Celia. You can forget about the “Ms.” Now, what can I do for you, [player_name]?"
    Celia ""

# game/scripts/intro.rpy:475
translate chinese after_choice1_intro_2c7adb04:

    # MC "Ms. Cel- I mean, just Celia, I was wondering *Gulp* if you would like to go... to... to... Beniza’s Pizza with me and... *Gulp* c-catch a m-movie afterwards?"
    MC ""

# game/scripts/intro.rpy:476
translate chinese after_choice1_intro_02170ad5:

    # Celia "Are you asking me out on a date, [player_name]?"
    Celia ""

# game/scripts/intro.rpy:479
translate chinese after_choice1_intro_4916b901:

    # MC "Y-Yes."
    MC ""

# game/scripts/intro.rpy:480
translate chinese after_choice1_intro_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/intro.rpy:481
translate chinese after_choice1_intro_e4a529a3:

    # MC "Well?"
    MC ""

# game/scripts/intro.rpy:482
translate chinese after_choice1_intro_868633fe_1:

    # Celia "..."
    Celia ""

# game/scripts/intro.rpy:483
translate chinese after_choice1_intro_b196a2f0:

    # Celia "Hahahahaha! Are you seriously asking your Professor out on a date?"
    Celia ""

# game/scripts/intro.rpy:484
translate chinese after_choice1_intro_ccfe6183:

    # MC "I- Um- Ah..."
    MC ""

# game/scripts/intro.rpy:487
translate chinese after_choice1_intro_88f8845f:

    # Celia "Oh, my God! This is too funny!"
    Celia ""

# game/scripts/intro.rpy:488
translate chinese after_choice1_intro_0aa501b3:

    # MC "I thought... Oh...."
    MC ""

# game/scripts/intro.rpy:489
translate chinese after_choice1_intro_8235a2f3:

    # Celia "Hehehehe!"
    Celia ""

# game/scripts/intro.rpy:492
translate chinese after_choice1_intro_a0037bcd:

    # Students "Did he just ask her out?!"
    Students ""

# game/scripts/intro.rpy:493
translate chinese after_choice1_intro_16b4e130:

    # Students "Oh, my God! He did!"
    Students ""

# game/scripts/intro.rpy:494
translate chinese after_choice1_intro_41328e02:

    # Students "I’d be mortified if that happened to me!"
    Students ""

# game/scripts/intro.rpy:495
translate chinese after_choice1_intro_8c58d6db:

    # Students "Ahahaha!"
    Students ""

# game/scripts/intro.rpy:496
translate chinese after_choice1_intro_3d41cd82:

    # Students "What a LOSER! HAHAHA!"
    Students ""

# game/scripts/intro.rpy:504
translate chinese after_choice1_intro_a8a8b0d9:

    # MC "I was SO... fucking angry."
    MC ""

# game/scripts/intro.rpy:505
translate chinese after_choice1_intro_f8fe0b02:

    # Judy "I can see that. You’re displaying extremely aggressive body language - Your clenched fists, your hunched posture."
    Judy ""

# game/scripts/intro.rpy:506
translate chinese after_choice1_intro_42db15bc:

    # Judy "You still are angry, aren’t you?"
    Judy ""

# game/scripts/intro.rpy:507
translate chinese after_choice1_intro_c7c1d21f:

    # MC "Of course I fucking am! She embarrassed me in front of the whole campus!"
    MC ""

# game/scripts/intro.rpy:510
translate chinese after_choice1_intro_b470f54b:

    # Judy "I think it’s a good thing that you were referred to me so promptly. What you experienced was incredibly embarrassing, but we can actually focus on the healing process now."
    Judy ""

# game/scripts/intro.rpy:511
translate chinese after_choice1_intro_2bff0865:

    # Judy "Tell me, [player_name]. Do you have strong feelings to exact revenge upon Ms. Celia?"
    Judy ""

# game/scripts/intro.rpy:514
translate chinese after_choice1_intro_2d204a49:

    # MC "..."
    MC ""

# game/scripts/intro.rpy:515
translate chinese after_choice1_intro_3d7d8b41:

    # Judy "You can tell me the truth. Please be honest."
    Judy ""

# game/scripts/intro.rpy:516
translate chinese after_choice1_intro_3ff19409:

    # MC "Yeah... I hate her right now."
    MC ""

# game/scripts/intro.rpy:519
translate chinese after_choice1_intro_5d9d8f78:

    # Judy "Thank you for being honest. Let’s talk more about Ms. Celia later. For now, could you tell me what happened after?"
    Judy ""

# game/scripts/intro.rpy:521
translate chinese after_choice1_intro_9ff96d66:

    # MC "Let me think... I... I went and stole my sister’s whiskey from her room."
    MC ""

# game/scripts/intro.rpy:523
translate chinese after_choice1_intro_f3eefc43:

    # MC "Let me think... I... I went and stole my friend’s whiskey from her room."
    MC ""

# game/scripts/intro.rpy:524
translate chinese after_choice1_intro_84e42aca:

    # Judy "Sara has whiskey in her bedroom? (This sounds like something I should report to the Dean. He’s taking a very hard stance against the drinking culture on campus. He doesn’t want our college becoming one of those disreputable party campuses.)"
    Judy ""

# game/scripts/intro.rpy:526
translate chinese after_choice1_intro_c5ab4cae:

    # MC "No, this was my older sister, Caroline."
    MC ""

# game/scripts/intro.rpy:528
translate chinese after_choice1_intro_56e9e577:

    # MC "No, I got it from another tenant who lives in the house - Caroline. She’s a bit older than I am. She graduated college a couple of years ago."
    MC ""

# game/scripts/intro.rpy:529
translate chinese after_choice1_intro_8064e752:

    # Judy "(Oh, okay.)"
    Judy ""

# game/scripts/intro.rpy:537
translate chinese after_choice1_intro_c342a6b3:

    # Caroline "Hmm? Oh hey, [player_name]! Don’t you know it’s polite to knock first?"
    Caroline ""

# game/scripts/intro.rpy:538
translate chinese after_choice1_intro_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/intro.rpy:541
translate chinese after_choice1_intro_bb746585:

    # Caroline "Uh... is something wrong, [player_name]?"
    Caroline ""

# game/scripts/intro.rpy:542
translate chinese after_choice1_intro_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/intro.rpy:543
translate chinese after_choice1_intro_0d584b48:

    # Caroline "(What’s up with him? He’s not usually the quiet type.)"
    Caroline ""

# game/scripts/intro.rpy:546
translate chinese after_choice1_intro_56ad8f73:

    # Caroline "If you’re looking for your phone charger, I already returned it. It’s beside your bed."
    Caroline ""

# game/scripts/intro.rpy:547
translate chinese after_choice1_intro_75d50d2c:

    # MC "I... I need your whiskey."
    MC ""

# game/scripts/intro.rpy:548
translate chinese after_choice1_intro_c83d608d:

    # Caroline "Huh? Why?"
    Caroline ""

# game/scripts/intro.rpy:549
translate chinese after_choice1_intro_9fecd616:

    # MC "I... I need a drink."
    MC ""

# game/scripts/intro.rpy:550
translate chinese after_choice1_intro_c9836c56:

    # Caroline "Is everything alright? Do you need some cash to buy your own?"
    Caroline ""

# game/scripts/intro.rpy:551
translate chinese after_choice1_intro_cd6aaed6:

    # MC "I can’t be bothered leaving the house..."
    MC ""

# game/scripts/intro.rpy:554
translate chinese after_choice1_intro_e5937aef:

    # Caroline "I’m getting a little worried about you..."
    Caroline ""

# game/scripts/intro.rpy:555
translate chinese after_choice1_intro_98e80b77:

    # MC "Yeah, whatever..."
    MC ""

# game/scripts/intro.rpy:556
translate chinese after_choice1_intro_41ffb12a:

    # Caroline "(What’s up with him? I’ve never seen him acting this weird before.)"
    Caroline ""

# game/scripts/intro.rpy:557
translate chinese after_choice1_intro_755b468a:

    # Caroline "(Could he be suffering from depression, or something?)"
    Caroline ""

# game/scripts/intro.rpy:560
translate chinese after_choice1_intro_1a4abfd3:

    # Caroline "Anyway, I’ve got to finish three more chapters of this book by tomorrow morning."
    Caroline ""

# game/scripts/intro.rpy:561
translate chinese after_choice1_intro_a5420047:

    # Caroline "Go ahead and take the bottle - you owe me a favour for that though."
    Caroline ""

# game/scripts/intro.rpy:562
translate chinese after_choice1_intro_9df51ef7:

    # MC "Sure..."
    MC ""

# game/scripts/intro.rpy:563
translate chinese after_choice1_intro_74feaa55:

    # Caroline "(I wonder if something happened in college today. I should talk to Sara when I get a chance.)"
    Caroline ""

# game/scripts/intro.rpy:571
translate chinese after_choice1_intro_8a44ed8d:

    # Judy "What happened after you took the whiskey, [player_name]?"
    Judy ""

# game/scripts/intro.rpy:574
translate chinese after_choice1_intro_f8223973:

    # MC "I drank a lot of it... The next couple of hours were a bit of a blur. I remember lying on my bed, just wishing that... that..."
    MC ""

# game/scripts/intro.rpy:575
translate chinese after_choice1_intro_5e3ce08b:

    # Judy "That the world would swallow you whole?"
    Judy ""

# game/scripts/intro.rpy:576
translate chinese after_choice1_intro_afc8cc1f:

    # MC "Yeah..."
    MC ""

# game/scripts/intro.rpy:577
translate chinese after_choice1_intro_2a51d572:

    # Judy "A lot of patients have said similar things."
    Judy ""

# game/scripts/intro.rpy:578
translate chinese after_choice1_intro_993b485a:

    # Judy "Tell me - what happened to bring you out of this slump?"
    Judy ""

# game/scripts/intro.rpy:580
translate chinese after_choice1_intro_3e384021:

    # MC "My mom. She came into my room, that evening - I hadn’t shown up for family dinner."
    MC ""

# game/scripts/intro.rpy:582
translate chinese after_choice1_intro_d6e73637:

    # MC "...Linda. She came into my room that evening. I hadn’t come downstairs for dinner."
    MC ""

# game/scripts/intro.rpy:591
translate chinese after_choice1_intro_70bb6974:

    # MC "(Oh God... what have I done? I can’t ever show my face in college again.)"
    MC ""

# game/scripts/intro.rpy:592
translate chinese after_choice1_intro_8697c16e:

    # MC "(Ms. Celia thinks I’m a joke. Everyone else on campus thinks I’m a loser.)"
    MC ""

# game/scripts/intro.rpy:593
translate chinese after_choice1_intro_4b0e601d:

    # MC "(My life is ruined...)"
    MC ""

# game/scripts/intro.rpy:596
translate chinese after_choice1_intro_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/intro.rpy:597
translate chinese after_choice1_intro_ced51066:

    # Mom "Hey there, sweetie. What’s wrong? I haven’t seen you down in the kitchen yet. Did you skip dinner? You’re looking glum..."
    Mom ""

# game/scripts/intro.rpy:599
translate chinese after_choice1_intro_4a85b894:

    # MC "It’s nothing, Mom. I’m fine."
    MC ""

# game/scripts/intro.rpy:601
translate chinese after_choice1_intro_70775dae:

    # MC "It’s nothing, Linda. I’m fine."
    MC ""

# game/scripts/intro.rpy:602
translate chinese after_choice1_intro_6d6cd9b5:

    # Mom "You don’t look fine. And it stinks of alcohol in here. Have you been drinking?"
    Mom ""

# game/scripts/intro.rpy:603
translate chinese after_choice1_intro_05adec8a:

    # MC "Just a bit..."
    MC ""

# game/scripts/intro.rpy:604
translate chinese after_choice1_intro_dbeb1c11:

    # Mom "*Sigh*"
    Mom ""

# game/scripts/intro.rpy:607
translate chinese after_choice1_intro_cb716ff0:

    # Mom "Caroline told me what happened in college today. She’d been worried about you and asked Sara if something had happened. Apparently Sara had seen your encounter with Ms. Celia."
    Mom ""

# game/scripts/intro.rpy:609
translate chinese after_choice1_intro_026293d7:

    # Mom "It seems everybody in this family knows what happened - before me. I was hoping you’d open-up to me."
    Mom ""

# game/scripts/intro.rpy:611
translate chinese after_choice1_intro_92a8c97d:

    # Mom "It seems everybody in this house knows what happened - before me. I was hoping you’d open up to me."
    Mom ""

# game/scripts/intro.rpy:613
translate chinese after_choice1_intro_11e4c377:

    # MC "Mom?"
    MC ""

# game/scripts/intro.rpy:614
translate chinese after_choice1_intro_90b0cc89:

    # Mom "Yes, Sweetpea?"
    Mom ""

# game/scripts/intro.rpy:616
translate chinese after_choice1_intro_ec00da41:

    # MC "Linda?"
    MC ""

# game/scripts/intro.rpy:617
translate chinese after_choice1_intro_cb99bb5a:

    # Linda "Yes, [player_name]?"
    Linda ""

# game/scripts/intro.rpy:618
translate chinese after_choice1_intro_9bd7464e:

    # MC "Am... Am I ugly?"
    MC ""

# game/scripts/intro.rpy:621
translate chinese after_choice1_intro_8bfed030:

    # Mom "What?! Who told you that?"
    Mom ""

# game/scripts/intro.rpy:622
translate chinese after_choice1_intro_8847c511:

    # MC "Nobody... But I feel like I am."
    MC ""

# game/scripts/intro.rpy:623
translate chinese after_choice1_intro_b79a06e5:

    # Mom "You’re a very handsome young man."
    Mom ""

# game/scripts/intro.rpy:625
translate chinese after_choice1_intro_fb05c5da:

    # MC "*Sigh* You have to say that - You’re my mom."
    MC ""

# game/scripts/intro.rpy:627
translate chinese after_choice1_intro_da3a2be2:

    # MC "*Sigh* You have to say that. I’m paying you rent each month."
    MC ""

# game/scripts/intro.rpy:628
translate chinese after_choice1_intro_91e80b55:

    # Mom "Look at me, [player_name]."
    Mom ""

# game/scripts/intro.rpy:632
translate chinese after_choice1_intro_d1cf4b75:

    # Mom "You’re not ugly. And I’m not saying that, just because I’m your mom. If anything, it means even more when it comes from me. I think you are incredibly handsome."
    Mom ""

# game/scripts/intro.rpy:633
translate chinese after_choice1_intro_420680f2:

    # MC "...thanks, Mom. I still don’t believe it’s true though."
    MC ""

# game/scripts/intro.rpy:635
translate chinese after_choice1_intro_5cffae73:

    # Mom "You’re not ugly. And I’m not saying that just because I’m your landlady. If anything, it means even more when it comes from me. I think you are incredibly handsome."
    Mom ""

# game/scripts/intro.rpy:636
translate chinese after_choice1_intro_2a101ad5:

    # MC "...thanks, Linda. I still don’t believe it’s true though."
    MC ""

# game/scripts/intro.rpy:638
translate chinese after_choice1_intro_9c3f9e0f:

    # MC "Mmpff!"
    MC ""

# game/scripts/intro.rpy:640
translate chinese after_choice1_intro_ce026135:

    # MC "(What the heck, Mom?!)"
    MC ""

# game/scripts/intro.rpy:642
translate chinese after_choice1_intro_8e61b6f9:

    # MC "(What the heck, Linda?!)"
    MC ""

# game/scripts/intro.rpy:643
translate chinese after_choice1_intro_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/intro.rpy:646
translate chinese after_choice1_intro_ead9997e:

    # Mom "(Holy shit! I can’t believe I just did that!)"
    Mom ""

# game/scripts/intro.rpy:647
translate chinese after_choice1_intro_8d14e5e9:

    # Mom "(Crap! I completely lost control and let my lust take over there!)"
    Mom ""

# game/scripts/intro.rpy:649
translate chinese after_choice1_intro_7bd88e8c:

    # MC "(What’s Mom doing?!)"
    MC ""

# game/scripts/intro.rpy:651
translate chinese after_choice1_intro_ce1a1701:

    # MC "(What she’s doing?!)"
    MC ""

# game/scripts/intro.rpy:653
translate chinese after_choice1_intro_d83330cb:

    # MC "Wh-What was THAT for?!"
    MC ""

# game/scripts/intro.rpy:655
translate chinese after_choice1_intro_6e0d7ecc:

    # MC "M-Mom! You just kissed me!?"
    MC ""

# game/scripts/intro.rpy:657
translate chinese after_choice1_intro_b2ad6f80:

    # MC "L-Linda! You just kissed me!?"
    MC ""

# game/scripts/intro.rpy:659
translate chinese after_choice1_intro_2b965616:

    # Mom "Well, you owed me a proper kiss, since you only pecked me on the cheek this morning."
    Mom ""

# game/scripts/intro.rpy:660
translate chinese after_choice1_intro_2d204a49_3:

    # MC "..."
    MC ""

# game/scripts/intro.rpy:661
translate chinese after_choice1_intro_d6850d86:

    # Mom "..."
    Mom ""

# game/scripts/intro.rpy:665
translate chinese after_choice1_intro_1e1b07b9:

    # Mom "What? How is that any different to you kissing me, like you did this morning?"
    Mom ""

# game/scripts/intro.rpy:666
translate chinese after_choice1_intro_2d204a49_4:

    # MC "..."
    MC ""

# game/scripts/intro.rpy:667
translate chinese after_choice1_intro_d6850d86_1:

    # Mom "..."
    Mom ""

# game/scripts/intro.rpy:674
translate chinese after_conditional_mom_kiss_cheek_lips_intro_522de1c9:

    # Mom "*Sigh* I’m sorry. I got carried away, and couldn’t hold myself back this time."
    Mom ""

# game/scripts/intro.rpy:675
translate chinese after_conditional_mom_kiss_cheek_lips_intro_e543e41b:

    # MC "Wh-"
    MC ""

# game/scripts/intro.rpy:676
translate chinese after_conditional_mom_kiss_cheek_lips_intro_9799beb4:

    # Mom "I should go. Bob and I had some extra food left over. I’ve put it in the oven to keep it warm. Make sure you eat when you’re hungry."
    Mom ""

# game/scripts/intro.rpy:679
translate chinese after_conditional_mom_kiss_cheek_lips_intro_0a3d9db9:

    # MC "(What the heck did she mean by “hold myself back this time”?)"
    MC ""

# game/scripts/intro.rpy:687
translate chinese after_conditional_mom_kiss_cheek_lips_intro_5b2d91ff:

    # MC "So yeah, that was pretty much what happened."
    MC ""

# game/scripts/intro.rpy:688
translate chinese after_conditional_mom_kiss_cheek_lips_intro_4c079cbb:

    # Judy "Hmm, when did the Dean find out about the incident with Ms. Celia?"
    Judy ""

# game/scripts/intro.rpy:689
translate chinese after_conditional_mom_kiss_cheek_lips_intro_f68b4d59:

    # MC "About four hours ago - early this morning."
    MC ""

# game/scripts/intro.rpy:692
translate chinese after_conditional_mom_kiss_cheek_lips_intro_7e66a836:

    # Judy "I really AM sorry to hear about what happened to you. It sounds terribly embarrassing. I can’t even begin to imagine, how it must feel to be in your position right now."
    Judy ""

# game/scripts/intro.rpy:693
translate chinese after_conditional_mom_kiss_cheek_lips_intro_39079c64:

    # Judy "Trust me though - with regular therapy sessions, we will get you through this."
    Judy ""

# game/scripts/intro.rpy:694
translate chinese after_conditional_mom_kiss_cheek_lips_intro_074dd5e9:

    # Judy "You are clearly - *ahem* - WERE clearly attracted to Ms. Celia. I was wondering, does this attraction apply to other women of a similar age?"
    Judy ""

# game/scripts/intro.rpy:695
translate chinese after_conditional_mom_kiss_cheek_lips_intro_4fd22518:

    # MC "Uhh... like who?"
    MC ""

# game/scripts/intro.rpy:697
translate chinese after_conditional_mom_kiss_cheek_lips_intro_f281c4d4:

    # Judy "Oh, I don’t know... How about... your mother?"
    Judy ""

# game/scripts/intro.rpy:699
translate chinese after_conditional_mom_kiss_cheek_lips_intro_a92b1181:

    # Judy "Oh, I don’t know. How about... Linda?"
    Judy ""

# game/scripts/intro.rpy:702
translate chinese after_conditional_mom_kiss_cheek_lips_intro_b794746d:

    # MC "What?! Are you asking me if I’m attracted to my mother?"
    MC ""

# game/scripts/intro.rpy:704
translate chinese after_conditional_mom_kiss_cheek_lips_intro_66f0e39e:

    # MC "What?! Are you asking me if I'm attracted to Linda? My landlady?"
    MC ""

# game/scripts/intro.rpy:705
translate chinese after_conditional_mom_kiss_cheek_lips_intro_1f1074da:

    # Judy "You did just tell me you were, kissing her while lying down on your bed."
    Judy ""

# game/scripts/intro.rpy:706
translate chinese after_conditional_mom_kiss_cheek_lips_intro_2db2c152:

    # MC "She was the one who kissed me!"
    MC ""

# game/scripts/intro.rpy:708
translate chinese after_conditional_mom_kiss_cheek_lips_intro_fa6d3811:

    # Judy "Ahh, so you pushed your mom away when she tried to kiss you?"
    Judy ""

# game/scripts/intro.rpy:710
translate chinese after_conditional_mom_kiss_cheek_lips_intro_74fff7fc:

    # Judy "Ahh, so you pushed her away when she tried to kiss you?"
    Judy ""

# game/scripts/intro.rpy:711
translate chinese after_conditional_mom_kiss_cheek_lips_intro_6d37c5f1:

    # MC "N-Not exactly- but-"
    MC ""

# game/scripts/intro.rpy:715
translate chinese after_conditional_mom_kiss_cheek_lips_intro_d3c01480:

    # Judy "So, let me ask you the question again. Do you have sexual fantasies about your mother?"
    Judy ""

# game/scripts/intro.rpy:717
translate chinese after_conditional_mom_kiss_cheek_lips_intro_ba4da4e1:

    # Judy "So, let me ask you the question again. Do you have sexual fantasies about your landlady?"
    Judy ""

# game/scripts/intro.rpy:718
translate chinese after_conditional_mom_kiss_cheek_lips_intro_745374ee:

    # MC "No!"
    MC ""

# game/scripts/intro.rpy:720
translate chinese after_conditional_mom_kiss_cheek_lips_intro_50a1e441:

    # Judy "Why not? You stated you were attracted to your sister, Sara."
    Judy ""

# game/scripts/intro.rpy:722
translate chinese after_conditional_mom_kiss_cheek_lips_intro_123d569d:

    # Judy "Why not? You stated you were attracted to your roommate, Sara."
    Judy ""

# game/scripts/intro.rpy:724
translate chinese after_conditional_mom_kiss_cheek_lips_intro_f0fc2ede:

    # MC "It doesn’t matter - even if I did like her, I wouldn’t do anything! She’s my mother! It’s just... weird. Y’know?"
    MC ""

# game/scripts/intro.rpy:726
translate chinese after_conditional_mom_kiss_cheek_lips_intro_14739805:

    # MC "It doesn't matter - even if I did like her, I wouldn't do anything! She’s far older than me! She’s also my landlady! It’s just... weird? Y’know?"
    MC ""

# game/scripts/intro.rpy:729
translate chinese after_conditional_mom_kiss_cheek_lips_intro_83dc9344:

    # Judy "You seem like a good-natured boy. Obviously, you want what’s best for your family, right? You want them to be happy?"
    Judy ""

# game/scripts/intro.rpy:731
translate chinese after_conditional_mom_kiss_cheek_lips_intro_fe43ad2c:

    # Judy "You seem like a good-natured lad. Obviously, you want what’s best for everyone in that household, right? You want them to be happy?"
    Judy ""

# game/scripts/intro.rpy:732
translate chinese after_conditional_mom_kiss_cheek_lips_intro_977d3bfe:

    # MC "Of course?"
    MC ""

# game/scripts/intro.rpy:734
translate chinese after_conditional_mom_kiss_cheek_lips_intro_920900ac:

    # Judy "What if that meant accepting your mother as a romantic partner? What if that is, what was required, to really make your mother happy?"
    Judy ""

# game/scripts/intro.rpy:736
translate chinese after_conditional_mom_kiss_cheek_lips_intro_c9c32302:

    # Judy "What if that meant accepting the possibility of your landlady as a romantic partner? What if that is what was required to really make Linda happy?"
    Judy ""

# game/scripts/intro.rpy:737
translate chinese after_conditional_mom_kiss_cheek_lips_intro_0c6a3bc3:

    # MC "What kind of questions are these?!"
    MC ""

# game/scripts/intro.rpy:738
translate chinese after_conditional_mom_kiss_cheek_lips_intro_a0626a0f:

    # Judy "I already told you, it’s Freudian psychology. Feel free to read about it in the Milfy City Library if you don’t believe me."
    Judy ""

# game/scripts/intro.rpy:740
translate chinese after_conditional_mom_kiss_cheek_lips_intro_a857037c:

    # Judy "So, let me rephrase. If you had the opportunity to fuck your mother, would you take it? "
    Judy ""

# game/scripts/intro.rpy:742
translate chinese after_conditional_mom_kiss_cheek_lips_intro_17b1b663:

    # Judy "So, let me rephrase. If you had the opportunity to fuck your landlady, would you take it?"
    Judy ""

# game/scripts/intro.rpy:744
translate chinese after_conditional_mom_kiss_cheek_lips_intro_1a27dc05:

    # Judy "We’ve already established that you want to make your mom happy. And it’s pretty obvious you want to get laid. Is this not a win-win situation?"
    Judy ""

# game/scripts/intro.rpy:746
translate chinese after_conditional_mom_kiss_cheek_lips_intro_f3b27eb7:

    # Judy "We’ve already established that you want to make Linda happy. And it’s pretty obvious you want to get laid. Is this not a win-win situation?"
    Judy ""

# game/scripts/intro.rpy:748
translate chinese after_conditional_mom_kiss_cheek_lips_intro_b9121ae9:

    # MC "I... No! I’ve never thought about her like that!"
    MC ""

# game/scripts/intro.rpy:750
translate chinese after_conditional_mom_kiss_cheek_lips_intro_092ddd4a:

    # MC "She’s my mother! I’ve already said that I wouldn’t do anything with her!"
    MC ""

# game/scripts/intro.rpy:752
translate chinese after_conditional_mom_kiss_cheek_lips_intro_9490ad90:

    # MC "She’s my landlady and she is far older than me! She also has a husband! I’ve already said that I wouldn't do anything with her!"
    MC ""

# game/scripts/intro.rpy:756
translate chinese after_conditional_mom_kiss_cheek_lips_intro_c038c7f2:

    # Judy "Interesting... I think that will do for today’s session. I’m going to ask you to visit me again, if anything noteworthy happens between you and your mother. Or even, perhaps, your sisters."
    Judy ""

# game/scripts/intro.rpy:758
translate chinese after_conditional_mom_kiss_cheek_lips_intro_693147a2:

    # Judy "Interesting, I think that will do for today’s session. I’m going to ask you to visit me again if anything... noteworthy happens between you and your landlady, or even perhaps your two roommates."
    Judy ""

# game/scripts/intro.rpy:759
translate chinese after_conditional_mom_kiss_cheek_lips_intro_093df17e:

    # MC "Noteworthy? Like what?"
    MC ""

# game/scripts/intro.rpy:760
translate chinese after_conditional_mom_kiss_cheek_lips_intro_e3c400cb:

    # Judy "I’m sure you’ll recognise something noteworthy when it happens."
    Judy ""

# game/scripts/intro.rpy:761
translate chinese after_conditional_mom_kiss_cheek_lips_intro_c9ff2644:

    # Judy "Now, try and get some rest, [player_name]. Relaxation is very important in recovering from trauma."
    Judy ""

# game/scripts/intro.rpy:769
translate chinese after_conditional_mom_kiss_cheek_lips_intro_02d608fc:

    # MC "*Yawn!*"
    MC ""

# game/scripts/intro.rpy:770
translate chinese after_conditional_mom_kiss_cheek_lips_intro_b96cf836:

    # MC "(It’s the start of a brand new day. Let’s make the most of it!)"
    MC ""

# game/scripts/intro.rpy:771
translate chinese after_conditional_mom_kiss_cheek_lips_intro_00c23998:

    # MC "(I need to focus on getting my life back on track after that... mishap yesterday.)"
    MC ""

# game/scripts/intro.rpy:775
translate chinese after_conditional_mom_kiss_cheek_lips_intro_432a2114:

    # MC "(Let’s get my confidence back, get a hot girl, and get laid!)"
    MC ""

# game/scripts/intro.rpy:776
translate chinese after_conditional_mom_kiss_cheek_lips_intro_183d6bd7:

    # MC "(Picking up chicks would be so much easier if I was in one of those sex games from Patreon.)"
    MC ""

# game/scripts/intro.rpy:777
translate chinese after_conditional_mom_kiss_cheek_lips_intro_adb8ba1a:

    # MC "(I can’t give up though!)"
    MC ""

translate chinese strings:

    # game/scripts/intro.rpy:185
    old "Could you tell me a little more about yourself?"
    new ""

    # game/scripts/intro.rpy:185
    old "How long will this therapy take?"
    new ""

    # game/scripts/intro.rpy:185
    old "No further questions"
    new ""

    # game/scripts/intro.rpy:270
    old "Tell her about Sara’s hobbies"
    new ""

    # game/scripts/intro.rpy:270
    old "Tell her about Sara’s college life"
    new ""

    # game/scripts/intro.rpy:270
    old "Tell her about Sara’s social life"
    new ""

    # game/scripts/intro.rpy:383
    old "Kiss Mom on the cheek"
    new ""

    # game/scripts/intro.rpy:383
    old "Kiss Mom on the lips"
    new ""

    # game/scripts/intro.rpy:383
    old "Kiss Linda on the cheek"
    new ""

    # game/scripts/intro.rpy:383
    old "Kiss Linda on the lips"
    new ""

