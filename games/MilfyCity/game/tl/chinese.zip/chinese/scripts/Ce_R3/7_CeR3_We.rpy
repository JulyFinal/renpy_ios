﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/7_CeR3_We.rpy:229
translate chinese CeR3_We_start_56cb2c48:

    # Celia "Well, hello sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:231
translate chinese CeR3_We_start_7bc0d498:

    # MC "Hey Celia. You’re properly dressed. Good to see you still remember your training."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:233
translate chinese CeR3_We_start_86dfe6a3:

    # Celia "So, what did you have in mind for me today, sir? Would you like to fuck me in the bedroom?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:235
translate chinese CeR3_We_start_77318965:

    # Celia "Or perhaps you’d like me lie back and suck your cock on the living room table?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:237
translate chinese CeR3_We_start_40851df9:

    # Celia "Or... you could always treat me rough and just pound me from behind? I love it when you destroy my ass."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:257
translate chinese CeR3_We_Bedroom_72e2dc18:

    # MC "Hey Celia, could you grab me a beer?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:259
translate chinese CeR3_We_Bedroom_04a15ccb:

    # Celia "Sure, no problem, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:263
translate chinese CeR3_We_Bedroom_67eed5fb:

    # MC "(Nice! Just look at that sexy ass! Celia looks amazing in that mesh lingerie.)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:265
translate chinese CeR3_We_Bedroom_f2318cd5:

    # MC "(God, I can’t wait to rip it off her and fuck her senseless tonight. This is gonna be great!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:269
translate chinese CeR3_We_Bedroom_5a3d7bef:

    # Celia "Here you go, sir. Chilled straight from the fridge."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:271
translate chinese CeR3_We_Bedroom_41aa22d6:

    # MC "Cheers, Celia! Pass it over here and pose for me at the bottom of the bed."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:273
translate chinese CeR3_We_Bedroom_bd0bab1e:

    # Celia "Absolutely, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:281
translate chinese CeR3_We_Bedroom_fe73486a:

    # Celia "How’s this, sir?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:283
translate chinese CeR3_We_Bedroom_2a3b2340:

    # MC "Mmm... Fucking perfect."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:287
translate chinese CeR3_We_Bedroom_5e238a6c:

    # Celia "Well? Are you just planning to spend the entire night staring at me, sir? Or did you have some other plans for my body?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:289
translate chinese CeR3_We_Bedroom_2d145140:

    # MC "Why don’t you join me on the bed and find out?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:293
translate chinese CeR3_We_Bedroom_373a4334:

    # Celia "Have you noticed how obedient I’ve been today, sir?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:295
translate chinese CeR3_We_Bedroom_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:297
translate chinese CeR3_We_Bedroom_305c1658:

    # Celia "I was waiting here for you. I dressed up in my sexiest lingerie, and I haven’t touched myself since your last visit."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:301
translate chinese CeR3_We_Bedroom_85bbd855:

    # MC "What are you getting at, Celia?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:305
translate chinese CeR3_We_Bedroom_2d597482:

    # Celia "Is it not obvious, sir?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:309
translate chinese CeR3_We_Bedroom_b8dfc791:

    # MC "Perhaps, but I’d much rather hear you plainly tell me what you want."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:313
translate chinese CeR3_We_Bedroom_ebc3f583:

    # Celia "I want... I want you to make me cum today. I can’t stand the thought of being made to endure another day without release."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:315
translate chinese CeR3_We_Bedroom_52d46689:

    # Celia "I’ll do whatever you ask. No matter what it is - just promise that you’ll FINALLY let me cum."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:317
translate chinese CeR3_We_Bedroom_108e06c1:

    # MC "You’re still going to have to earn your right to cum."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:321
translate chinese CeR3_We_Bedroom_9291a0de:

    # Celia "Oh? And what do I need to do? Just tell me what you want. I will do ANYTHING you desire."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:323
translate chinese CeR3_We_Bedroom_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:325
translate chinese CeR3_We_Bedroom_fe97c059:

    # MC "You really mean anything?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:329
translate chinese CeR3_We_Bedroom_b8da75a9:

    # Celia "Absolutely. I’ll deepthroat your dick if that’s what you want. Or you can thrust your cock deep in my ass."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:331
translate chinese CeR3_We_Bedroom_b5771357:

    # Celia "I’m all yours, sir. Just tell me what I need to do to earn my orgasm."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:333
translate chinese CeR3_We_Bedroom_6198e7eb:

    # MC "Well, how about we start with you crawling up here and giving me a blowjob?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:337
translate chinese CeR3_We_Bedroom_3a0fd784:

    # Celia "Mmm, yes sir. Just lie back and enjoy your beer. Let me take care of your fat cock."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:339
translate chinese CeR3_We_Bedroom_75ccae8d:

    # MC "(She’s completely wrapped around my finger now! The woman who once rejected me is now crawling on her hands and knees to suck my dick!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:343
translate chinese CeR3_We_Bedroom_72146d64:

    # Celia "Are you already hard, sir? I bet you are."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:345
translate chinese CeR3_We_Bedroom_818aa163:

    # Celia "I bet you can’t wait to feel your personal fucktoy wrap her lips around your thick cock. I bet you’re getting all excited at the thought of your shaft slipping down my tight, wet throat."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:349
translate chinese CeR3_We_Bedroom_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:351
translate chinese CeR3_We_Bedroom_843c41b3:

    # MC "(I can feel her fingers caressing my dick through my underwear.)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:355
translate chinese CeR3_We_Bedroom_68fd0486:

    # Celia "Mmm! I can feel you getting harder and harder. You’re going to love the main event, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:357
translate chinese CeR3_We_Bedroom_480638b2:

    # Celia "Let’s slip these pants off you. We wouldn’t want them getting in the way of my lips now, would we?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:359
translate chinese CeR3_We_Bedroom_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:363
translate chinese CeR3_We_Bedroom_f337df55:

    # MC "(I can feel her warm breath against my glans. I’m so hard right now!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:365
translate chinese CeR3_We_Bedroom_244b9487:

    # Celia "I hope you're ready sir, because I'm about to rock your world."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:367
translate chinese CeR3_We_Bedroom_506dfbbc:

    # Celia "...and something else."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:371
translate chinese CeR3_We_Bedroom_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:373
translate chinese CeR3_We_Bedroom_3b36bced:

    # Celia "I’m going to try my best today, sir. I’m going to make sure every single inch of your dick is thoroughly satisfied."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:377
translate chinese CeR3_We_Bedroom_21a0fe37:

    # Celia "And by the time I’m done, you’re going to be sooo proud of me. You’re going to have no choice but to let me cum."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:379
translate chinese CeR3_We_Bedroom_72d57574:

    # MC "Is that so? You sound very confident, Celia."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:381
translate chinese CeR3_We_Bedroom_1bb041e3:

    # Celia "Oh, I really am."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:385
translate chinese CeR3_We_Bedroom_0386001d:

    # Celia "*Mwah*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:387
translate chinese CeR3_We_Bedroom_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:389
translate chinese CeR3_We_Bedroom_2bbc1d90:

    # MC "*Pant* (God, her lips feel incredible when she kisses my cock like that!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:393
translate chinese CeR3_We_Bedroom_05ac408d:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:395
translate chinese CeR3_We_Bedroom_f2364a02:

    # MC "Ooohh... Mmm!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:397
translate chinese CeR3_We_Bedroom_1b006ab6:

    # Celia "*Suck* *Shlurp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:401
translate chinese CeR3_We_Bedroom_05ac408d_1:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:404
translate chinese CeR3_We_Bedroom_057ece05:

    # MC "Ah! Ohhhh! Mmmm!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:405
translate chinese CeR3_We_Bedroom_f84d2f83:

    # Celia "(I love looking up into his eyes when I suck his shaft. It’s adorable watching him squirm and tremble in ecstasy.)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:409
translate chinese CeR3_We_Bedroom_c4c14336:

    # MC "*Pant* F-Fuck! This is amazing, Celia."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:411
translate chinese CeR3_We_Bedroom_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:413
translate chinese CeR3_We_Bedroom_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:415
translate chinese CeR3_We_Bedroom_afd7e90c:

    # Celia "*Suck* *Suck* *Suck*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:419
translate chinese CeR3_We_Bedroom_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:421
translate chinese CeR3_We_Bedroom_74656c65:

    # MC "(This is the life! Being treated like a king and enjoying an ice-cold beer while a beautiful woman sucks my dick.)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:423
translate chinese CeR3_We_Bedroom_f8a7de9b:

    # Celia "*Shluuurrrp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:427
translate chinese CeR3_We_Bedroom_58167e2f:

    # MC "*Glug Glug*"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:429
translate chinese CeR3_We_Bedroom_b6c4c6d7:

    # Celia "*Shlurp* *SUCK*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:431
translate chinese CeR3_We_Bedroom_d809a818:

    # Celia "Mmmmpff! *Shlurp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:436
translate chinese CeR3_We_Bedroom_b47c9b13:

    # "*Clink*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:438
translate chinese CeR3_We_Bedroom_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:440
translate chinese CeR3_We_Bedroom_05ac408d_2:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:442
translate chinese CeR3_We_Bedroom_cfffef1c:

    # MC "That was incredible, Celia. Y’know what? I think you’ve earned yourself an orgasm already."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:444
translate chinese CeR3_We_Bedroom_c5a8805c:

    # Celia "*Shlurp* *Pant* R-Really?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:448
translate chinese CeR3_We_Bedroom_d796bd8f:

    # MC "Oh yeah. I think I’m gonna fuck you from behind."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:450
translate chinese CeR3_We_Bedroom_4dca67e8:

    # MC "But, first things first, I need to get this bodysuit out of the way."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:452
translate chinese CeR3_We_Bedroom_df363283:

    # Celia "(I can’t believe it! Is he actually going to fuck me and make me cum?!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:457
translate chinese CeR3_We_Bedroom_a611df57:

    # MC "Let’s free your breasts first."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:463
translate chinese CeR3_We_Bedroom_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:467
translate chinese CeR3_We_Bedroom_3f0187a9:

    # "*Rrriiiippp*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:469
translate chinese CeR3_We_Bedroom_e752746f:

    # Celia "(Oh my God! He’s going to ravage me, isn’t he?)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:471
translate chinese CeR3_We_Bedroom_f36154d0:

    # Celia "(I’m getting so wet at the thought of him completely dominating me right now, and wrecking my pussy.)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:475
translate chinese CeR3_We_Bedroom_885dd206:

    # MC "There we go. There’s nothing blocking my cock from slipping inside you now."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:477
translate chinese CeR3_We_Bedroom_689bb393:

    # MC "I think we’ll keep your fishnet stockings on. You look good in those."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:479
translate chinese CeR3_We_Bedroom_7cf8ce55:

    # Celia "Y-Yes, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:483
translate chinese CeR3_We_Bedroom_5f495a36:

    # Celia "Ah!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:485
translate chinese CeR3_We_Bedroom_4fc1dbf9:

    # MC "Wow, did you just moan from my squeezing your breast?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:487
translate chinese CeR3_We_Bedroom_4eca4cd5:

    # Celia "You’ve kept me ah... edging FOR DAYS now, sir! The slightest touch is oohhh...s-soo sensitive!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:491
translate chinese CeR3_We_Bedroom_a9dc4126:

    # MC "I’ll have to keep that in mind."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:493
translate chinese CeR3_We_Bedroom_cd44b9c4:

    # Celia "Please, sir. Please stick it in. I want to feel your fat cock inside me."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:495
translate chinese CeR3_We_Bedroom_35ee3e5e:

    # MC "You really ARE desperate, aren’t you?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:497
translate chinese CeR3_We_Bedroom_52c02f36:

    # Celia "Please, sir! I’m so horny, I need to feel your-"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:501
translate chinese CeR3_We_Bedroom_f6da79d2:

    # Celia "AaaaAAAahhHHAHAAHHHHHHH!!!! Yeessssssssss!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:503
translate chinese CeR3_We_Bedroom_f717dd4d:

    # MC "Did you just cum from that? You really WERE horny, weren’t you?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:505
translate chinese CeR3_We_Bedroom_ec1fe720:

    # Celia "*Pant* Aaaahhhhh!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:509
translate chinese CeR3_We_Bedroom_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:511
translate chinese CeR3_We_Bedroom_5f495a36_1:

    # Celia "Ah!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:513
translate chinese CeR3_We_Bedroom_f70674b1:

    # Celia "Ah! Ahh! Yesss! Fill me up, sir!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:515
translate chinese CeR3_We_Bedroom_ec402844:

    # Celia "Your fat cock is stretching my pussy! Aaahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:519
translate chinese CeR3_We_Bedroom_4a1500bf:

    # MC "Are you enjoying this?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:521
translate chinese CeR3_We_Bedroom_af8b84a9:

    # Celia "Oooohhhh! Yeeesssss! Don’t stooooohhhp!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:523
translate chinese CeR3_We_Bedroom_157f622b:

    # Celia "*Pant* Aahhhh! *Pant* Aaahhhhhhhhh!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:527
translate chinese CeR3_We_Bedroom_b27503a1:

    # Celia "Keep fucking meee! Yessss! I’m cummmmiiinnng! I’m cummiiinnng!! AAHHHHH!!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:529
translate chinese CeR3_We_Bedroom_4a9ca6d1:

    # MC "Hnnngg! Ugh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:531
translate chinese CeR3_We_Bedroom_fcc923e0:

    # Celia "Pound my slutty little pussy! Ayaaahhhhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:535
translate chinese CeR3_We_Bedroom_873c6969:

    # Celia "*Pant* *Gasp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:537
translate chinese CeR3_We_Bedroom_0e4b8496:

    # Celia "Oh... wow... that was *Pant* indescribable!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:541
translate chinese CeR3_We_Bedroom_1f154f4d:

    # MC "Well, now that you’ve finally had your orgasm, I think it’s time I had some of my own fun."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:543
translate chinese CeR3_We_Bedroom_ee5a19eb:

    # Celia "*Pant* What do you mean?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:546
translate chinese CeR3_We_Bedroom_5e2cc3e0:

    # MC "I’m gonna spread your cheeks and pound your tight little asshole."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:548
translate chinese CeR3_We_Bedroom_32f30e4a:

    # Celia "*Pant* I don’t know if *Pant* I can do it, I’m exhausted and super *Pant* sensitive after that orgasm."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:552
translate chinese CeR3_We_Bedroom_70931f4b:

    # MC "(Fuck, her asshole looks incredible! I can’t wait to shove my shaft deep inside it!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:554
translate chinese CeR3_We_Bedroom_82bc96ff:

    # MC "You’ll be fine! We’ve already done anal before."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:558
translate chinese CeR3_We_Bedroom_207dadcc:

    # Celia "(I’m still trembling from the aftershocks of my first climax! I don’t think I’m going to be able to handle another!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:560
translate chinese CeR3_We_Bedroom_6ef15d9c:

    # Celia "*Pant* Oh... *Gulp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:564
translate chinese CeR3_We_Bedroom_70086610:

    # MC "Here it comes, Celia. I’m about to destroy your ass. You’d like that, wouldn’t you?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:566
translate chinese CeR3_We_Bedroom_294cda01:

    # Celia "N-No!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:568
translate chinese CeR3_We_Bedroom_d53c3ffa:

    # Celia "(Oh fuck, it sounds so hot when he says it that way.)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:572
translate chinese CeR3_We_Bedroom_bf280614:

    # MC "Can you feel that, Celia? Can you feel my thick cock stretching your anus?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:574
translate chinese CeR3_We_Bedroom_9cb60075:

    # Celia "Ooohhhhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:576
translate chinese CeR3_We_Bedroom_ee525ee1:

    # MC "It’s only going to get more intense as I push it in deeper."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:580
translate chinese CeR3_We_Bedroom_a9d0b847:

    # Celia "OOOHHH!!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:582
translate chinese CeR3_We_Bedroom_195076e6:

    # MC "That’s it, Celia. Scream for me. I want to hear you howling in pleasure as I thrust my dick, deep into your derriere."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:584
translate chinese CeR3_We_Bedroom_0bba671c:

    # Celia "Ahhhhh!! *Pant* Ooooooooohhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:588
translate chinese CeR3_We_Bedroom_d1e5d232:

    # MC "What’s wrong, Celia? Ugh! Is it too intense?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:590
translate chinese CeR3_We_Bedroom_319443fe:

    # Celia "Haaahh! Ahhh! Its’hhh toooohhh muuuchhh! Hnnnngg! OOOHHH!!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:593
translate chinese CeR3_We_Bedroom_6b037bbf:

    # Celia "(I can barely think! Too much pleasure! Can’t concentrate.)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:597
translate chinese CeR3_We_Bedroom_a809681c:

    # Celia "Ahhh! AHHHHHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:599
translate chinese CeR3_We_Bedroom_fe4830da:

    # MC "Ugh! Argghhh! Hnnng! God, I love using your tight ass! So much better than your pussy!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:601
translate chinese CeR3_We_Bedroom_d83577b6:

    # Celia "Haaaaahhh! AAAAAHHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:605
translate chinese CeR3_We_Bedroom_62a7a868:

    # MC "How does it feel, knowing that every single hole of your body is simply another place for me to fuck?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:607
translate chinese CeR3_We_Bedroom_5930eaa0:

    # Celia "Ahhhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:609
translate chinese CeR3_We_Bedroom_872153e1:

    # MC "Your pussy, your mouth, your ass. I’m going to spend the rest of our time together, filling them up with my thick, salty cum."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:611
translate chinese CeR3_We_Bedroom_2ce5c306:

    # Celia "Ah! Ah! Ah!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:615
translate chinese CeR3_We_Bedroom_f41bd734:

    # MC "Because that’s what your purpose is to me, Celia. You’re a fucktoy. My own personal sexdoll."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:617
translate chinese CeR3_We_Bedroom_9ae04f0c:

    # Celia "Ahh! AHHHH! Y-Yes! Fuck me! Aaahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:619
translate chinese CeR3_We_Bedroom_0af4664d:

    # MC "What are you?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:623
translate chinese CeR3_We_Bedroom_21c68eb1:

    # Celia "Ayaaah! I’m your sexdoll! I’m ah! Ah! I’m your mmm... I’m your sex toy! Fuck meeeeee!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:625
translate chinese CeR3_We_Bedroom_8a472e65:

    # MC "Ugh! Hnnngg!!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:627
translate chinese CeR3_We_Bedroom_92e603e4:

    # MC "(Oh God, I’m about to cum! Where should I finish?)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:633
translate chinese CeR3_We_Bedroom_26b28d94:

    # MC "Hnnng! I’m cumming!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:635
translate chinese CeR3_We_Bedroom_35d7646d:

    # Celia "YEEESSSS! Fill me up! Fill my ass! AHHH! Make me your buttslut! AH! AH! AHHHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:637
translate chinese CeR3_We_Bedroom_c38a7d78:

    # MC "HNNNGGG! UUGGGHHH!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:648
translate chinese CeR3_We_Bedroom_e7b7640b:

    # MC "Oh fuck! Fuck! Aarrghhhh!!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:650
translate chinese CeR3_We_Bedroom_1c0662e8:

    # Celia "Ahhhhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:652
translate chinese CeR3_We_Bedroom_9a5ff0dd:

    # Celia "(I can feel it filling me up! It’s soooo hot!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:656
translate chinese CeR3_We_Bedroom_5ab33baa:

    # MC "*Pant* That was amazing."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:658
translate chinese CeR3_We_Bedroom_676f12bc:

    # Celia "*Pant* *Pant* Ooohh..."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:666
translate chinese CeR3_We_Bedroom_83dce4e6:

    # MC "Ughh! I’m about to cum!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:668
translate chinese CeR3_We_Bedroom_68c13916:

    # Celia "*Pant* Ohh! Yes, cum for me!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:678
translate chinese CeR3_We_Bedroom_cba51f81:

    # MC "Hnnnggg! Aaaahhh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:680
translate chinese CeR3_We_Bedroom_52198056:

    # Celia "Oooh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:684
translate chinese CeR3_We_Bedroom_35e6b26b:

    # MC "*Pant* That was incredible."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:686
translate chinese CeR3_We_Bedroom_192c68ba:

    # Celia "*Pant* I can’t believe how intense it got at the end, there! *Pant*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:693
translate chinese CeR3_We_Bedroom_con_d94a8d08:

    # Celia "Mmm... That was phenomenal, sir. I don’t think I’ve ever been fucked that hard before, in my entire life!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:695
translate chinese CeR3_We_Bedroom_con_bb34eded:

    # MC "I’m glad you enjoyed it."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:699
translate chinese CeR3_We_Bedroom_con_69efb586:

    # Celia "When do you think you’ll be able to come back?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:701
translate chinese CeR3_We_Bedroom_con_7965ddb9:

    # MC "Maybe next weekend. We’ll see."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:703
translate chinese CeR3_We_Bedroom_con_feeec6b1:

    # Celia "I promise I won’t play with myself until you return."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:707
translate chinese CeR3_We_Bedroom_con_9e73d8f6:

    # MC "You don’t have to do that. Go ahead and have fun, if you want to."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:709
translate chinese CeR3_We_Bedroom_con_58084b21:

    # Celia "Hmm, we’ll see. I quite enjoyed being denied release."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:711
translate chinese CeR3_We_Bedroom_con_e81c2dd0:

    # MC "I strung you along for quite a while, didn’t I?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:715
translate chinese CeR3_We_Bedroom_con_7e56caba:

    # Celia "Almost too long, you bastard. Haha!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:717
translate chinese CeR3_We_Bedroom_con_c5700098:

    # MC "Heh! Alright, I’ll swing by next time I’m free."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:723
translate chinese CeR3_We_Bedroom_con_c3671491:

    # Celia "[player_name]?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:725
translate chinese CeR3_We_Bedroom_con_5779a0f8:

    # MC "Yeah, Celia?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:727
translate chinese CeR3_We_Bedroom_con_9d874aa3:

    # Celia "Don’t keep a girl waiting too long."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:734
translate chinese CeR3_We_Livingroom_a0080ee2:

    # MC "How about we have some fun in the living room today?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:736
translate chinese CeR3_We_Livingroom_bd0bab1e:

    # Celia "Absolutely, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:738
translate chinese CeR3_We_Livingroom_30fc188a:

    # MC "Lead the way."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:742
translate chinese CeR3_We_Livingroom_c4076130:

    # Celia "My heart was always racing, every time you came to visit, sir. You know that?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:744
translate chinese CeR3_We_Livingroom_2fa74202:

    # Celia "I was always nervous that Gustav would come back home and catch us. It thrilled me in a way I can’t describe though."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:746
translate chinese CeR3_We_Livingroom_30c429b3:

    # Celia "The risk of getting caught was... Mmm! It was the cherry on the cake."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:753
translate chinese CeR3_We_Livingroom_7c26e44b:

    # Celia "It wasn’t just that though. I’ve had butterflies in my tummy each time you came over. Even when we were playing our “cat and mouse” games."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:755
translate chinese CeR3_We_Livingroom_2416cba9:

    # MC "Haha!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:758
translate chinese CeR3_We_Livingroom_7a6d484e:

    # Celia "I have to admit, you were far better than I expected, sir. You never once broke character, right up until the very end."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:763
translate chinese CeR3_We_Livingroom_5bd1bdd3:

    # MC "You enjoyed it though, didn’t you? All our dirty little fucks through the glory hole?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:765
translate chinese CeR3_We_Livingroom_a80b8955:

    # Celia "I enjoyed it all. Well, maybe not having to listen to Fat Jake talk about his My Little Pony collection. Ugh, something about storing them in glass jars. I couldn’t follow him."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:769
translate chinese CeR3_We_Livingroom_d549faf2:

    # Celia "So, here we are in the living room, sir. What did you want to do with me today?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:771
translate chinese CeR3_We_Livingroom_2cb0233a:

    # Celia "Something rough, I hope."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:773
translate chinese CeR3_We_Livingroom_f02bd9f1:

    # MC "You want me to be rough with you today?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:775
translate chinese CeR3_We_Livingroom_f9c39b41:

    # Celia "You’ve been nothing but tame so far, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:779
translate chinese CeR3_We_Livingroom_152c987f:

    # Celia "I’m beginning to think you’re a little bit weak, to be hon-"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:781
translate chinese CeR3_We_Livingroom_f4d97c49:

    # MC "(Fine, I’ll show her just how rough I can be!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:786
translate chinese CeR3_We_Livingroom_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:788
translate chinese CeR3_We_Livingroom_5f495a36:

    # Celia "Ah!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:790
translate chinese CeR3_We_Livingroom_97dd80a2:

    # Celia "(Holy crap! I didn’t think he’d actually do it!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:794
translate chinese CeR3_We_Livingroom_653e16a5:

    # Celia "Whoa!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:796
translate chinese CeR3_We_Livingroom_391d9aff:

    # MC "(Oops! I may have slapped her a little too hard! Didn’t mean to knock her off her feet!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:801
translate chinese CeR3_We_Livingroom_933aa022:

    # "*THUD*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:803
translate chinese CeR3_We_Livingroom_e357941d:

    # MC "Shit! I’m sorry Celia, I-"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:805
translate chinese CeR3_We_Livingroom_30504ec2:

    # Celia "Oh no, you’ve pushed me down. I hope you don’t ravage me before I can get myself back up."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:807
translate chinese CeR3_We_Livingroom_250e1625:

    # MC "Are you alright? You aren’t hurt or-"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:811
translate chinese CeR3_We_Livingroom_16126b02:

    # Celia "I said, “I HOPE YOU DON’T RAVAGE ME BEFORE I GET BACK UP.”"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:813
translate chinese CeR3_We_Livingroom_a3b7c592:

    # MC "Oh, right! Y-Yeah!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:815
translate chinese CeR3_We_Livingroom_eab6cd0b:

    # MC "(Jesus Christ! I knocked her back onto a glass table - and she’s STILL begging to be fucked!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:819
translate chinese CeR3_We_Livingroom_b8bcd6a3:

    # Celia "Ahmm... What are you planning to do to me?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:824
translate chinese CeR3_We_Livingroom_0e4674f6:

    # "*Zzziiip*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:826
translate chinese CeR3_We_Livingroom_e01c702c:

    # MC "You’re about to find out. Open wide."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:828
translate chinese CeR3_We_Livingroom_653e16a5_1:

    # Celia "Whoa!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:832
translate chinese CeR3_We_Livingroom_84089754:

    # Celia "(It looks even bigger from this angle! That’s a monster cock, right there!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:834
translate chinese CeR3_We_Livingroom_aad5a4fd:

    # MC "C’mon, you can open your mouth wider than that, Celia!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:836
translate chinese CeR3_We_Livingroom_4b81581a:

    # Celia "I-"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:838
translate chinese CeR3_We_Livingroom_3580d202:

    # MC "Fine, let me give you a hand."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:842
translate chinese CeR3_We_Livingroom_1a28c6b2:

    # Celia "Mmpff!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:844
translate chinese CeR3_We_Livingroom_1db981fd:

    # MC "Ugh, there we go. Bend your head back a bit more. Ah... Perfect!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:846
translate chinese CeR3_We_Livingroom_a7cdfa5f:

    # Celia "(He’s going to throatfuck me from this angle, isn’t he?)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:850
translate chinese CeR3_We_Livingroom_f5b4d6a9:

    # Celia "(God, I’m so horny right now. How does it manage to make me so wet, so quickly?!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:852
translate chinese CeR3_We_Livingroom_5dea299b:

    # MC "That’s it, Celia. Just hold right there."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:856
translate chinese CeR3_We_Livingroom_0dd8df86:

    # MC "There we go. You might want to take a deep breath before the next part."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:858
translate chinese CeR3_We_Livingroom_33e8ea3c:

    # Celia "(What’s the next part?)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:860
translate chinese CeR3_We_Livingroom_eed1522d:

    # Celia "Hmm?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:864
translate chinese CeR3_We_Livingroom_d1ef86c9:

    # Celia "*Glommpfff!* *GAG*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:866
translate chinese CeR3_We_Livingroom_c1105292:

    # MC "Ugghh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:868
translate chinese CeR3_We_Livingroom_54c4a143:

    # MC "(Holy crap! My dick slipped so easily down her throat! I may as well have been fucking her wet pussy!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:872
translate chinese CeR3_We_Livingroom_b921ab04:

    # MC "Arrghh! Do you like it when I squeeze your tits while I fuck your throat, Celia?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:874
translate chinese CeR3_We_Livingroom_5ceee379:

    # Celia "*Shlurp* *Suck* *Glompff*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:876
translate chinese CeR3_We_Livingroom_ff0bff40:

    # MC "Ugh! Ahh! Mmm!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:880
translate chinese CeR3_We_Livingroom_a91b6730:

    # MC "Oh fuck! That’s it! Hnnng! Suck on my cock, you slut!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:882
translate chinese CeR3_We_Livingroom_e6bc5b9d:

    # Celia "*Suck* *GAG* *SHLLURRRP*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:884
translate chinese CeR3_We_Livingroom_54cb9077:

    # MC "Hnnng! Ugh! Ugh! Aarrrghh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:888
translate chinese CeR3_We_Livingroom_bcdf6890:

    # MC " How does it feel to be manhandled and used like this, Celia? Are you enjoying having your ugh... tits groped while I fuck your face?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:890
translate chinese CeR3_We_Livingroom_7897cc33:

    # Celia "Mmppff! *SHLURP* *SUCK*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:892
translate chinese CeR3_We_Livingroom_15251bdc:

    # MC "Aahhh! Fuck! Your mouth feels so damn good!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:897
translate chinese CeR3_We_Livingroom_a97a1ffe:

    # MC "Hnnngg... Ugh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:899
translate chinese CeR3_We_Livingroom_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:901
translate chinese CeR3_We_Livingroom_97375398:

    # Celia "(Mmm! I love it when he uses my body like this!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:905
translate chinese CeR3_We_Livingroom_ce64f08a:

    # Celia "*Shlurp* *Suck* *Suck* *GAG*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:907
translate chinese CeR3_We_Livingroom_f987de99:

    # MC "Mmm! Hnnngg! *Pant* I’m getting close, Celia!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:910
translate chinese CeR3_We_Livingroom_56278310_1:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:912
translate chinese CeR3_We_Livingroom_5854f660:

    # MC "Fuck! I’m gonna cum!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:914
translate chinese CeR3_We_Livingroom_1d344265:

    # Celia "*Shlurp* *Gag*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:921
translate chinese CeR3_We_Livingroom_b4c27f8b:

    # MC "Hnnngg! I’m cumming!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:923
translate chinese CeR3_We_Livingroom_83383a32:

    # Celia "MPPFFF!! *Gag* *Shlurp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:925
translate chinese CeR3_We_Livingroom_ec67b5c8:

    # MC "Arrghhh!!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:935
translate chinese CeR3_We_Livingroom_b3c8f02a:

    # MC "Ohhh! Fuck..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:937
translate chinese CeR3_We_Livingroom_b898e3c7:

    # Celia "*Shlurp* *Gulp* *Gulp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:939
translate chinese CeR3_We_Livingroom_777aae3b:

    # MC "Mmm! Ah... That’s it. Swallow my cum!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:946
translate chinese CeR3_We_Livingroom_12bd73f6:

    # MC "Hnnngg! I’m gonna cum!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:948
translate chinese CeR3_We_Livingroom_3fdbf962:

    # Celia "*Cough* *Gasp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:950
translate chinese CeR3_We_Livingroom_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:961
translate chinese CeR3_We_Livingroom_37755d73:

    # MC "Hnnng! Ugh! Ohhh fuck! Aahh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:963
translate chinese CeR3_We_Livingroom_c1496aff:

    # Celia "Wow! That was *Pant* a lot!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:970
translate chinese CeR3_We_Livingroom_con_a98e967b:

    # Celia "Wait, is that us done for the day?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:972
translate chinese CeR3_We_Livingroom_con_3805ec25:

    # MC "Yup. All done."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:974
translate chinese CeR3_We_Livingroom_con_3f9b146a:

    # Celia "Aww... I was hoping we’d maybe get to fuck a bit more..."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:978
translate chinese CeR3_We_Livingroom_con_2e6bb835:

    # MC "Maybe next weekend."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:980
translate chinese CeR3_We_Livingroom_con_24126244:

    # Celia "Is that a promise, sir?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:982
translate chinese CeR3_We_Livingroom_con_e13ff0b7:

    # MC "Depends how busy I am. You can play with yourself, if you get desperate."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:986
translate chinese CeR3_We_Livingroom_con_653b8bf1:

    # Celia "*Sigh* Please come back soon, sir."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:988
translate chinese CeR3_We_Livingroom_con_6d4817e3:

    # MC "I’ll catch you later, Celia."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:990
translate chinese CeR3_We_Livingroom_con_9a052479:

    # Celia "(God damn, I love how rough he was with me today!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:995
translate chinese CeR3_We_Hallway_2b4dfa0d:

    # Celia "So, any preferences on where we fuck today, sir?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:997
translate chinese CeR3_We_Hallway_ced4a6b9:

    # MC "Hmm... I was thinking that we should do it..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1001
translate chinese CeR3_We_Hallway_a24d0a7d:

    # MC "...right here in the hallway!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1003
translate chinese CeR3_We_Hallway_c339f9d0:

    # Celia "*Gasp* Oh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1007
translate chinese CeR3_We_Hallway_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1009
translate chinese CeR3_We_Hallway_3dd592f7:

    # Celia "Mmm!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1012
translate chinese CeR3_We_Hallway_5b1b2fc3:

    # MC "You liked that, didn’t you?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1014
translate chinese CeR3_We_Hallway_3de1dd31:

    # Celia "I love it when you treat me rough like that, sir. What are you planning to do to me?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1018
translate chinese CeR3_We_Hallway_72afc8af:

    # MC "I was going to start by pinning you against the wall like this."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1020
translate chinese CeR3_We_Hallway_8dfca62c:

    # Celia "Ah! Yes!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1022
translate chinese CeR3_We_Hallway_fbb7a908:

    # MC "And then..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1026
translate chinese CeR3_We_Hallway_0fd603fe:

    # Celia "Yes? What next?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1028
translate chinese CeR3_We_Hallway_81ef3a14:

    # MC "And then I’m going to rip that sexy mesh bodysuit off you."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1030
translate chinese CeR3_We_Hallway_20429fd2:

    # Celia "You love ripping those off me, don’t you, sir?"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1034
translate chinese CeR3_We_Hallway_738c7840:

    # Celia "(Thank God I put in a bulk order on these bodysuits from Milfazon.)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1036
translate chinese CeR3_We_Hallway_2ec15ac3:

    # MC "Of course I do. And after I tear it off your body, I’m going to thrust my hard cock into your tight little asshole."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1038
translate chinese CeR3_We_Hallway_3dd592f7_1:

    # Celia "Mmm!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1042
translate chinese CeR3_We_Hallway_e8320ea4:

    # MC "And you’re going to take it, Celia. I’m going to hold you against the wall as I pound you over, and over again."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1044
translate chinese CeR3_We_Hallway_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1046
translate chinese CeR3_We_Hallway_f62fa526:

    # MC "I want to hear you scream in ecstasy as I fuck you silly. Are you going to do that for me?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1050
translate chinese CeR3_We_Hallway_52796b62:

    # Celia "Yes, sir! Fuck me! Please fuck my slutty ass!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1053
translate chinese CeR3_We_Hallway_69148702:

    # "*Zzzip*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1055
translate chinese CeR3_We_Hallway_f016c007:

    # Celia "*Pant* Pleeeaasssee! Hurry up! I’m so horny, sir!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1059
translate chinese CeR3_We_Hallway_e9288f80:

    # Celia "(I can feel his cock resting against my ass! God, it’s so fucking big!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1061
translate chinese CeR3_We_Hallway_0a8787f5:

    # MC "I want you to beg for it. Tell me you want me to rip your clothes off and ravage your body."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1063
translate chinese CeR3_We_Hallway_93b21f34:

    # Celia "Please sir!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1067
translate chinese CeR3_We_Hallway_1cd6d8e8:

    # Celia "Please! Tear my lingerie off! Strip me naked! Fuck me! I need to feel your thick cock, pounding deep inside my bowels!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1069
translate chinese CeR3_We_Hallway_1fd14cf4:

    # MC "You can do better than that."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1071
translate chinese CeR3_We_Hallway_17072899:

    # Celia "I want your hard cock thrusting deep inside me! I want you to stretch out my tight asshole with your huge dick!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1075
translate chinese CeR3_We_Hallway_575ada9e:

    # Celia "God, I want to feel your hot cum filling up my ass! I want to feel your creampie, deep inside me as you pound me again and again!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1077
translate chinese CeR3_We_Hallway_78fc74d7:

    # MC "Go on!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1079
translate chinese CeR3_We_Hallway_3ea88eb8:

    # Celia "*Pant* I need to feel you ravage my ass without mercy! I don’t care how much it’s going to hurt! I love the pain! Fuck me, sir! Destroy my ass!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1083
translate chinese CeR3_We_Hallway_2e4601fa:

    # "*Rrrriiiipp*"
    ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1085
translate chinese CeR3_We_Hallway_ca934746:

    # MC "Good girl."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1087
translate chinese CeR3_We_Hallway_9adaacef_1:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1091
translate chinese CeR3_We_Hallway_752fc169:

    # MC "Now, let’s see how loudly I can make you scream."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1093
translate chinese CeR3_We_Hallway_93d65f5e:

    # Celia "Yessss! Pleeeasse!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1097
translate chinese CeR3_We_Hallway_277a86c5:

    # Celia "*Pant* I can’t wait any longer! Shove your cock inside me! I need to feel you in me!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1099
translate chinese CeR3_We_Hallway_55b73c14:

    # Celia "Please, I need to cum!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1101
translate chinese CeR3_We_Hallway_c615b474:

    # MC "(Okay, I think I’ve kept her begging long enough. Let’s give Celia what she so badly wants!)"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1105
translate chinese CeR3_We_Hallway_99f6437b:

    # Celia "*Gasp* AH!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1107
translate chinese CeR3_We_Hallway_e8bca240:

    # MC "Mmm! Fuck, you’re tighter than I remembered!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1109
translate chinese CeR3_We_Hallway_289eaefa:

    # Celia "Ow! Ahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1113
translate chinese CeR3_We_Hallway_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1115
translate chinese CeR3_We_Hallway_e08d0539:

    # Celia "OOWWWW!! Ahhh! *Pant* Aaahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1117
translate chinese CeR3_We_Hallway_7dafb198:

    # MC "That’s it, Celia. Scream for me while I pound your ass."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1119
translate chinese CeR3_We_Hallway_722fbd0f:

    # Celia "Put your- Put your hand around my ahhh... throat!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1123
translate chinese CeR3_We_Hallway_1d835bc8:

    # Celia "Yes *Gasp* Just like -ow... that! Aaahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1125
translate chinese CeR3_We_Hallway_06d90154:

    # MC "Hnng! Ugh! Ah!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1127
translate chinese CeR3_We_Hallway_adb9e3d1:

    # Celia "*Pant* Harder! Fuck me *Gasp* harder, sir! I can take it!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1131
translate chinese CeR3_We_Hallway_9a7a3bdb:

    # MC "Ugh! Argh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1133
translate chinese CeR3_We_Hallway_18f88a86:

    # Celia "*Gasp* *Pant* Ah! Ah! Ahh! Ahhhh! YESSSS!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1135
translate chinese CeR3_We_Hallway_f6c95703:

    # Celia "*Weakly* H-Harder... Mmm!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1139
translate chinese CeR3_We_Hallway_c6e24919:

    # MC "You want me to go even harder?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1141
translate chinese CeR3_We_Hallway_69a3930e:

    # Celia "*Weakly* Yes, makemecum makemecum... pleeeeassee..."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1143
translate chinese CeR3_We_Hallway_85e37f0d:

    # Celia "Oh God, oh God, I’m fucking... I’m fucking cumming... I’m gonna cum..."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1146
translate chinese CeR3_We_Hallway_06d90154_1:

    # MC "Hnng! Ugh! Ah!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1148
translate chinese CeR3_We_Hallway_ac4a1b82:

    # Celia "*Weakly* Please push my head against the wall."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1150
translate chinese CeR3_We_Hallway_8fc09455:

    # MC "What did you say?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1152
translate chinese CeR3_We_Hallway_eff33ed1:

    # Celia "*Weakly* Push my *Pant* head against the wall. I want to feel you ah... completely dominating me, like I’ve no control at all! Ah!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1155
translate chinese CeR3_We_Hallway_06d90154_2:

    # MC "Hnng! Ugh! Ah!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1157
translate chinese CeR3_We_Hallway_f4a98d09:

    # Celia "*GASP* Oh God! Yesssss! I’m cumminnnngg! AAAAAAAHHHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1159
translate chinese CeR3_We_Hallway_d1d6cc34:

    # MC "You like that, you slut?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1161
translate chinese CeR3_We_Hallway_819751ac:

    # Celia "Yeesssssss, sir! AAAAAAAHHHHHHH!!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1165
translate chinese CeR3_We_Hallway_0af4664d:

    # MC "What are you?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1167
translate chinese CeR3_We_Hallway_f142e7fc:

    # Celia "I’m youuuuurr sluuuut! Haaaahhh! I’m your stupid little buttslut! Aaaahhhhhhhh!!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1169
translate chinese CeR3_We_Hallway_30997c98:

    # MC "Hnnngg! Fuck!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1173
translate chinese CeR3_We_Hallway_1c1da4d5:

    # Celia "AAAHHHH!!! AH! AHHH!!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1175
translate chinese CeR3_We_Hallway_ea56b70c:

    # MC "Hnnngg! UGH! Fuck! I’m gonna cum soon!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1177
translate chinese CeR3_We_Hallway_289eaefa_1:

    # Celia "Ow! Ahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1180
translate chinese CeR3_We_Hallway_4fd138dd:

    # Celia "Ow! Ah! OW!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1182
translate chinese CeR3_We_Hallway_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1184
translate chinese CeR3_We_Hallway_a5b99566:

    # Celia "Ow! D-Don’t stop! OWWW! Ahh! I like the *Gasp* pain! Aaahhhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1187
translate chinese CeR3_We_Hallway_289eaefa_2:

    # Celia "Ow! Ahhh!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1189
translate chinese CeR3_We_Hallway_720d94e7:

    # MC "Ah! Hnnngg!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1191
translate chinese CeR3_We_Hallway_e3dfb252:

    # Celia "Oh God! Ow! Oh! FUCK! AAAHHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1195
translate chinese CeR3_We_Hallway_2f169097:

    # Celia "HARDER! HARDER! AAHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1197
translate chinese CeR3_We_Hallway_63675356:

    # MC "HNNNGGG! UGGHH! I’m gonna cum!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1199
translate chinese CeR3_We_Hallway_261533ab:

    # Celia "YEESSSS! FILL ME UP! AYAAAAHHHHHH!!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1205
translate chinese CeR3_We_Hallway_465652b2:

    # MC "Aaahhh! Ughhh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1207
translate chinese CeR3_We_Hallway_a9f3cf15:

    # Celia "OHHH! I’M CUMMMMIIINNNGGG!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1209
translate chinese CeR3_We_Hallway_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1220
translate chinese CeR3_We_Hallway_0caf4c47:

    # MC "*Pant* Ugghhh!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1222
translate chinese CeR3_We_Hallway_70bb4af7:

    # Celia "*GASP* Aaaahh oooohhhh! Ssssooooo hoooott!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1226
translate chinese CeR3_We_Hallway_aefd7e9f:

    # Celia "Ooohhh..."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1228
translate chinese CeR3_We_Hallway_c3b44af2:

    # Celia "(I can feel his cum trickling out of my ass. God, this is turning me on so much!)"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1230
translate chinese CeR3_We_Hallway_74470929:

    # MC "Mmm... That was good. *Pant*"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1238
translate chinese CeR3_We_Hallway_42b6e3ea:

    # MC "Hnnngg! Ugh! I’m cumming!"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1240
translate chinese CeR3_We_Hallway_0326baa6:

    # Celia "Yes! Cum for me!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1250
translate chinese CeR3_We_Hallway_a01d756a:

    # MC "Hnnng! UGH! Ahhh..."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1252
translate chinese CeR3_We_Hallway_0c7f43f4:

    # Celia "*Pant* *Pant* Ooohhh..."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1259
translate chinese CeR3_We_Hallway_con_7206fff1:

    # Celia "*Pant* *Gasp* That was... *Pant* ...fucking incredible."
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1261
translate chinese CeR3_We_Hallway_con_5115d23a:

    # Celia "I can’t *Pant* feel my legs. *Pant"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1263
translate chinese CeR3_We_Hallway_con_ed1dd751:

    # MC "Are you masturbating, Celia?"
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1265
translate chinese CeR3_We_Hallway_con_a222e4ce:

    # Celia "Yeah, I *Pant* just need one more orgasm!"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1269
translate chinese CeR3_We_Hallway_con_084170c2:

    # MC "No playing with yourself until I come back."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1271
translate chinese CeR3_We_Hallway_con_a79ede7b:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1273
translate chinese CeR3_We_Hallway_con_b4021699:

    # MC "I already gave you a few orgasms there. If you want more, you’ll have to wait until I come back."
    MC ""

# game/scripts/Ce_R3/7_CeR3_We.rpy:1275
translate chinese CeR3_We_Hallway_con_b834c035:

    # Celia "*Pant* P-Please don’t keep me waiting too long, sir."
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R3/7_CeR3_We.rpy:241
    old "I want to fuck you in the bedroom."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:241
    old "Go lie down on the coffee table. I’m going to fuck your face."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:241
    old "Up against the wall now. I want to fuck your ass."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:629
    old "Empty your load into her ass."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:629
    old "Pull out and cum over her asscheeks."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:916
    old "Finish deep, down Celia’s throat."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:916
    old "Pull out and cum over her face."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:1201
    old "Cum inside her ass."
    new ""

    # game/scripts/Ce_R3/7_CeR3_We.rpy:1201
    old "Pull out and cum over her ass."
    new ""

