﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:79
translate chinese CeR3_NS1_lock_f33e7a65:

    # MC "(Celia must be somewhere around the house.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:91
translate chinese CeR3_NS1_180c4150:

    # MC "(I’ve been teasing Celia for a few days now. It’s starting to get close to the time when I should probably offer her some relief and let her climax.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:93
translate chinese CeR3_NS1_1c5fc329:

    # MC "(She’s been getting more and more desperate with each passing day. I mean, last time I visited she was on her hands and knees BEGGING me to finally let her cum!)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:95
translate chinese CeR3_NS1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:97
translate chinese CeR3_NS1_d483f398:

    # MC "(Has Celia left her front door open?)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:101
translate chinese CeR3_NS1_07b5a812:

    # MC "(What’s going on?)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:103
translate chinese CeR3_NS1_91203382:

    # MC "(Maybe Gustav forgot to close it after he left for work?)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:115
translate chinese CeR3_NS1_step1_ded8efd7:

    # MC "(Celia’s just standing there...)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:117
translate chinese CeR3_NS1_step1_701ec5a2:

    # MC "(I wonder what she’s up to.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:145
translate chinese CeR3_NS1_step3_48c1e588:

    # "*Creak*"
    ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:147
translate chinese CeR3_NS1_step3_9e159786:

    # MC "(She didn’t react when I opened the door. Is she literally just waiting for me to ravage her again?)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:151
translate chinese CeR3_NS1_step3_7100fcfa:

    # Celia "*Gasp* You’re back!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:153
translate chinese CeR3_NS1_step3_d20a168f:

    # MC "You sound surprised."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:155
translate chinese CeR3_NS1_step3_8aa62a22:

    # Celia "I was waiting for you. I haven’t touched myself since you left, I promise. Just please, please let me cum, sir."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:162
translate chinese CeR3_NS1_step3_31b306fb:

    # MC "I will consider your request. Stay right there while I get undressed. Don’t move a muscle."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:164
translate chinese CeR3_NS1_step3_4a22d9e9:

    # Celia "*Gulp* Yes, sir."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:166
translate chinese CeR3_NS1_step3_86309c6f:

    # Celia "(My pussy has been aching and my clit has been throbbing FOR DAYS now! I don’t know if I can go much longer without some kind of release.)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:168
translate chinese CeR3_NS1_step3_6ac83ea7:

    # Celia "(Every time I’m walking down the corridors on campus, I can feel my panties rubbing against my clitoris. It was driving me mad, so I had to stop wearing them.)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:174
translate chinese CeR3_NS1_step3_faa575d7:

    # Celia "Ahahmmmmm!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:176
translate chinese CeR3_NS1_step3_773c2a17:

    # MC "*Whispered* We’re going to play a little game tonight, Celia. If you win, you get to cum. If you lose, you’ll have to get down on your knees and suck my cock. Now, listen closely as I tell you the rules."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:178
translate chinese CeR3_NS1_step3_5e433b52:

    # Celia "Mmm hmm?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:180
translate chinese CeR3_NS1_step3_e598bcf9:

    # MC "*Whispered* I’m going to play with your body for the next few minutes and, during that time, you can’t make a single sound. If I hear one moan, one gasp, or one scream - you lose."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:184
translate chinese CeR3_NS1_step3_3b58216e:

    # MC "However, if you are able to stay silent until you cum, then you get to enjoy your orgasm. Does that sound fair?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:186
translate chinese CeR3_NS1_step3_9a5dd8d0:

    # Celia "Mmm hmm!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:188
translate chinese CeR3_NS1_step3_c6bc3125:

    # MC "Good girl. We’re starting... now."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:192
translate chinese CeR3_NS1_step3_42e0034e:

    # MC "*Whispered* How does it feel when I squeeze your breast like this? I bet you want to moan so badly, right now."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:194
translate chinese CeR3_NS1_step3_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:196
translate chinese CeR3_NS1_step3_a217790e:

    # MC "You’re probably imagining, my finger in your mouth is actually a hard cock, slipping in and out of your wet hole."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:198
translate chinese CeR3_NS1_step3_f9d06cbb:

    # Celia "... *Pant*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:200
translate chinese CeR3_NS1_step3_8b6978cb:

    # MC "Nothing? Not even a little moan? Alright, let’s up the ante a bit."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:204
translate chinese CeR3_NS1_step3_6a0340e0:

    # Celia "...mf..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:206
translate chinese CeR3_NS1_step3_39e3668b:

    # MC "Oh? Was that a sound there?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:208
translate chinese CeR3_NS1_step3_868633fe_1:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:210
translate chinese CeR3_NS1_step3_51606f1c:

    # MC "I guess not."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:212
translate chinese CeR3_NS1_step3_a031197f:

    # Celia "(I almost moaned when he pinched my nipple! C’mon, Celia! You can do this! All you have to do is endure until he makes you cum. As soon as that happens, you can be as loud as you want to be!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:216
translate chinese CeR3_NS1_step3_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:218
translate chinese CeR3_NS1_step3_d77332cf:

    # Celia "(Shit! Shit! Keep it together, Celia! You’re going to FINALLY get to cum if you can just keep quiet!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:220
translate chinese CeR3_NS1_step3_4dba76ab:

    # MC "Still nothing? Your nipple has gotten quite stiff, Celia. I bet it’s feeling SUPER sensitive right now."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:222
translate chinese CeR3_NS1_step3_df0000fb:

    # Celia "... *Pant* *Pant* ..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:224
translate chinese CeR3_NS1_step3_4ef67a06:

    # MC "Alright, if you’re finding this too easy, let’s increase the difficulty again."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:228
translate chinese CeR3_NS1_step3_2d5a711f:

    # Celia "*Sharp Inhale*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:230
translate chinese CeR3_NS1_step3_cf594143:

    # MC "Ohh, it sounds like that hit the spot, didn’t it, Celia? I bet your sensitive little clitoris is burning with a need to be touched right now."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:232
translate chinese CeR3_NS1_step3_6bca4af9:

    # MC "How does it feel to have my hard cock slide back and forth? How does it feel to have your soft silk panties stroke against your sensitive pleasure nub?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:234
translate chinese CeR3_NS1_step3_188c4383:

    # Celia "*PANT* *PANT*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:237
translate chinese CeR3_NS1_step3_044c9e0e:

    # Celia "(God, my legs are shaking, right now! It’s taking every ounce of willpower I have, not to scream out and beg him to fuck me!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:243
translate chinese CeR3_NS1_step3_f9f3b3d6:

    # MC "*Whispered* This must be torture, Celia. Feeling my cock SO close to your pussy. Feeling it slowly slip back and forth, but having those panties in the way."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:245
translate chinese CeR3_NS1_step3_d2f39537:

    # Celia "*Pant* *Gasp* ..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:247
translate chinese CeR3_NS1_step3_90a22d9f:

    # MC "*Whispered* Your breathing is getting louder. I can feel your legs starting to shake. You can barely stand this. Go on, scream for me. Moan for me. I know you want to."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:249
translate chinese CeR3_NS1_step3_3a005b7a:

    # Celia "...m... a.... *Pant*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:253
translate chinese CeR3_NS1_step3_6949adf3:

    # MC "*Whispered* You’re so soaking wet. Just give in and moan - you won’t get to cum, but I’ll still let you suck my cock."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:257
translate chinese CeR3_NS1_step3_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:263
translate chinese CeR3_NS1_step3_a79ede7b:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:265
translate chinese CeR3_NS1_step3_8aa1a6f9:

    # MC "*Whispered* I can see you curling your fingers. It’s horrible, isn’t it? Not being allowed to vocalise your deepest desires. You must REALLY want to tell me to shove my cock in you right now."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:267
translate chinese CeR3_NS1_step3_54ea35ec:

    # Celia "*Pant* ..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:269
translate chinese CeR3_NS1_step3_876a45da:

    # Celia "(Don’t give in to him, Celia! You’re stronger than this! If you moan, then you’re going to have to spend another day with your body on the edge!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:271
translate chinese CeR3_NS1_step3_4a580236:

    # MC "Let’s see how you react to a very fast thrust."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:275
translate chinese CeR3_NS1_step3_6d214b08:

    # Celia "*GASP*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:277
translate chinese CeR3_NS1_step3_64b8cd13:

    # MC "Oh, that was VERY close to a moan there, Celia. If I wasn’t a fair man, I would probably have disqualified you for that."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:279
translate chinese CeR3_NS1_step3_6148f0eb:

    # Celia "*Pant* *Pant*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:281
translate chinese CeR3_NS1_step3_834659ac:

    # MC "Okay, I think that’s enough of a warm-up. Let’s see how long you can handle the main event."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:283
translate chinese CeR3_NS1_step3_f7966494:

    # Celia "(Wait, that was just a warm-up?!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:287
translate chinese CeR3_NS1_step3_7f9e8b09:

    # MC "*Whispered* What’s wrong, Celia? You seem surprised."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:289
translate chinese CeR3_NS1_step3_00f772e5:

    # MC "Did you honestly think I was going to let you play on easy-mode the whole time? It’s time to slip your panties out of the way. Let’s see how long you can last when faced with an ACTUAL challenge."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:291
translate chinese CeR3_NS1_step3_f074e617:

    # Celia "(Oh crap! No way! There’s no way I can stay silent if he starts rubbing his cock directly against my bare pussy!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:295
translate chinese CeR3_NS1_step3_9adaacef_1:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:297
translate chinese CeR3_NS1_step3_3c31b651:

    # Celia "(His dick feels so warm! God, my clit is so swollen it feels like it’s burning!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:301
translate chinese CeR3_NS1_step3_ecb06201:

    # MC "*Whispered* I know you’re enjoying this, Celia. I can feel the juices from your pussy dripping down onto my shaft."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:305
translate chinese CeR3_NS1_step3_cf44389f:

    # Celia "*Pant* *PANT*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:307
translate chinese CeR3_NS1_step3_7155f926:

    # MC "*Whispered* Just give in. One nice loud moan, and you can be down on your knees, sucking and slurping my cock. That’s what you want, isn’t it?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:309
translate chinese CeR3_NS1_step3_9adaacef_2:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:311
translate chinese CeR3_NS1_step3_f913ec20:

    # Celia "(N-No! I want to cum! I want to cum! I’m not giving in!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:316
translate chinese CeR3_NS1_step3_06c5fcb9:

    # MC "Okay, you seem to be holding on longer than I thought you would. Perhaps your clitoris needs some special attention."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:318
translate chinese CeR3_NS1_step3_425bfe98:

    # MC "How does it feel if it rub my cock directly against your swollen pleasure-button?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:320
translate chinese CeR3_NS1_step3_2dccf277:

    # Celia "*GASP* ...m.... A.... hn...."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:322
translate chinese CeR3_NS1_step3_07a78cb3:

    # MC "Oh, that seems VERY effective. Go on. Scream for me you slut. I want to hear you moan with pleasure and lose your ONLY chance at an orgasm."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:326
translate chinese CeR3_NS1_step3_e8e2b762:

    # Celia "(No! You’re not gonna make me moan! I’m gonna hold out until I cum! I can do this. Deep breaths, Celia. In and out. You can do th-)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:330
translate chinese CeR3_NS1_step3_ab5d25ef:

    # Celia "*GASP* A.... A.... H...a...h...."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:332
translate chinese CeR3_NS1_step3_a1f09522:

    # MC "*Whispered* My, my, my... Such a sensitive clitoris. Your entire body is convulsing simply from having my cock slide over it."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:334
translate chinese CeR3_NS1_step3_188c4383_1:

    # Celia "*PANT* *PANT*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:336
translate chinese CeR3_NS1_step3_679d1f99:

    # MC "*Whispered* Breathe as hard as you want, Celia. We both know you’re not going to last much longer. Especially if I decide to slip the tip inside you."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:340
translate chinese CeR3_NS1_step3_f05a06e3:

    # Celia "(No! No! No! I’m not ready! I’m not gonna be able to stay quiet!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:342
translate chinese CeR3_NS1_step3_3c755ef9:

    # MC "Hnnngg..."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:347
translate chinese CeR3_NS1_step3_9bc39412:

    # Celia "....h....n.....g.....*GASP... *Pant*... a....h...."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:348
translate chinese CeR3_NS1_step3_9adaacef_3:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:352
translate chinese CeR3_NS1_step3_086de67e:

    # MC "You must love the feeling of my hands cupping your breasts. I can feel you getting wetter each time I squeeze them."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:354
translate chinese CeR3_NS1_step3_bae524e7:

    # Celia "*Pant* A.... h.... *Gulp* ...o...."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:356
translate chinese CeR3_NS1_step3_79705ff3:

    # Celia "(No, no, no! I can’t focus when he’s groping my tits and thrusting into me at the same time! I’m going crazy!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:360
translate chinese CeR3_NS1_step3_4bddcb54:

    # MC "Mmm! You’re absolutely soaked right now, Celia. How about you do me a favour and let out a BIG moan for me? I’ll thrust extra deep, I promise."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:362
translate chinese CeR3_NS1_step3_a79ede7b_1:

    # Celia "*Pant*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:364
translate chinese CeR3_NS1_step3_b12b8ab3:

    # Celia "(Shit! I’m ALMOST there! Just a few more thrusts and I think I’ll cum! Then I can scream as loud as I want to! I just have to hold on for a little bit lon-)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:367
translate chinese CeR3_NS1_step3_a5eaafe5:

    # MC "HNNNG!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:371
translate chinese CeR3_NS1_step3_b2a0e3b0:

    # Celia "...h....n...g...."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:373
translate chinese CeR3_NS1_step3_30d6977d:

    # MC "Ugh! That’s it, Celia. Scream for me!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:375
translate chinese CeR3_NS1_step3_b3b2ce3c:

    # Celia "(NO! I can’t! I can’t-)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:377
translate chinese CeR3_NS1_step3_5dceca85:

    # Celia "Hn... *Pant* A... H.... H..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:379
translate chinese CeR3_NS1_step3_c32b8dc5:

    # Celia "(Sh-Shit! I’m gonna- I’m gonna scream!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:381
translate chinese CeR3_NS1_step3_fecf61f3:

    # Celia "HNNNGG!! AAAYYAAAAAAHHHHH!!!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:385
translate chinese CeR3_NS1_step3_dbae37d5:

    # MC "Ha! Gotcha!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:387
translate chinese CeR3_NS1_step3_e8fb591b:

    # Celia "*Pant* P-Please! Please let me try again!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:389
translate chinese CeR3_NS1_step3_cb99996d:

    # MC "You already knew the rules, Celia. If you made ANY sound before you came, then you would have to give me a blowjob."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:393
translate chinese CeR3_NS1_step3_a2892928:

    # Celia "Wh-What if I give you a REALLY good blowjob? Will you let me cum then?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:395
translate chinese CeR3_NS1_step3_d0af2a19:

    # MC "If you give me an absolutely phenomenal blowjob, then I will... CONSIDER allowing you to cum."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:397
translate chinese CeR3_NS1_step3_1a1b79ef:

    # Celia "(Screw it. That’s good enough for me.)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:401
translate chinese CeR3_NS1_step3_c63c0090:

    # Celia "I hope you’re ready for this, sir. I’m going to absolutely rock your world."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:403
translate chinese CeR3_NS1_step3_7d439032:

    # Celia "I promise you, by the time I’m finished with your cock, you’re going to WANT to let me cum."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:405
translate chinese CeR3_NS1_step3_df345806:

    # MC "We’ll see."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:409
translate chinese CeR3_NS1_step3_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:413
translate chinese CeR3_NS1_step3_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:415
translate chinese CeR3_NS1_step3_51803123:

    # Celia "God, your dick looks delicious. I can’t wait to take it in my mouth and suck on it until you release your thick semen all over my tongue."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:417
translate chinese CeR3_NS1_step3_cbc83cfc:

    # Celia "(If I can keep him distracted with a blowjob, maybe he won’t notice me fingering myself. Let’s see if I can get away with this.)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:421
translate chinese CeR3_NS1_step3_42159a59:

    # Celia "Your dick is soooo big! I can barely wrap my fingers around it! I just want to worship your fat cock ALL night long, sir!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:423
translate chinese CeR3_NS1_step3_8fd0995a:

    # Celia "Mmm! I’m getting all horny at the thought of taking your shaft deep down my tight, wet, throat."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:427
translate chinese CeR3_NS1_step3_a5eaafe5_1:

    # MC "HNNNG!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:431
translate chinese CeR3_NS1_step3_c41c9335:

    # MC "(Celia is being rather sus right now. She doesn’t usually monologue this much. Is she up to something?)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:433
translate chinese CeR3_NS1_step3_539803c7:

    # Celia "You’re going to love it when I slowly drag my tongue up the length of your shaft, sir. I can’t wait to ah... taste your-"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:435
translate chinese CeR3_NS1_step3_e9d0f3bc:

    # MC "(She just moaned there!)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:438
translate chinese CeR3_NS1_step3_57803f87:

    # MC "Celia, you’re masturbating, aren’t you?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:440
translate chinese CeR3_NS1_step3_aac510ec:

    # Celia "Umm... no?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:442
translate chinese CeR3_NS1_step3_356b3b31:

    # MC "Yes, you are! I can see your hand down there!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:444
translate chinese CeR3_NS1_step3_5a9126dd:

    # Celia "N-No, I’m not. Just focus on the blowjob!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:446
translate chinese CeR3_NS1_step3_e7e20808:

    # MC "You’re gaslighting me, right now - I can CLEARLY see you fingering yourself!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:448
translate chinese CeR3_NS1_step3_212c3615:

    # Celia "Gaslighting? There you go making up words again, sir."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:450
translate chinese CeR3_NS1_step3_2714fe54:

    # MC "Right. Final warning. If you don’t stop fingering yourself, this instance, then I’m walking out of here."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:454
translate chinese CeR3_NS1_step3_5c242c12:

    # Celia "*Sigh* Fine."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:456
translate chinese CeR3_NS1_step3_3c427cbd:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:461
translate chinese CeR3_NS1_step3_05ac408d:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:463
translate chinese CeR3_NS1_step3_d6f8746a:

    # MC "(Celia is getting EXTREMELY desperate, right now. I think I’ve pushed her so far, that she’s openly defying me right - in front of me.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:465
translate chinese CeR3_NS1_step3_ca18148e:

    # MC "(I think one more session of being denied an orgasm will finally seal the deal. I’ll let her finish her blowjob first though.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:469
translate chinese CeR3_NS1_step3_0b5ad02c:

    # Celia "I hope you’re ready, sir. I’m about to blow your mind. (And something else!)"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:471
translate chinese CeR3_NS1_step3_85297651:

    # MC "Ready when you are, Celia."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:475
translate chinese CeR3_NS1_step3_1b006ab6:

    # Celia "*Suck* *Shlurp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:477
translate chinese CeR3_NS1_step3_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:481
translate chinese CeR3_NS1_step3_05f71d93:

    # MC "(I can feel her lips wrapped around the tip. It’s still hard to believe that this is the same woman who, so publicly rejected me, so publicly DESPISED me.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:486
translate chinese CeR3_NS1_step3_19de7dd6:

    # Celia "*SHLURP* *Gag* *SUUUCCCK*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:488
translate chinese CeR3_NS1_step3_a97a1ffe:

    # MC "Hnnngg... Ugh!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:490
translate chinese CeR3_NS1_step3_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:494
translate chinese CeR3_NS1_step3_16b963c9:

    # Celia "*Glompf* *Shllurrrp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:496
translate chinese CeR3_NS1_step3_47d0d9b1:

    # MC "Oh... Mmm!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:500
translate chinese CeR3_NS1_step3_9b414cab:

    # MC "(It’s amazing how much effort it took to finally turn Celia into my personal slut. I got there in the end though.)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:506
translate chinese CeR3_NS1_step3_efde2501:

    # Celia "*Shlurp* *Suck* *Gag* Shlurp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:508
translate chinese CeR3_NS1_step3_8c5a821e:

    # MC "Ugh! Fuck! Ah!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:512
translate chinese CeR3_NS1_step3_05ac408d_1:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:514
translate chinese CeR3_NS1_step3_6ecbbbc0:

    # MC "I’m gonna cum!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:518
translate chinese CeR3_NS1_step3_5f08294f:

    # Celia "*SUCK* *SUCK* *SUCK*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:526
translate chinese CeR3_NS1_step3_c2119b70:

    # MC "Oh fuck! I’m gonna cum!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:528
translate chinese CeR3_NS1_step3_351a4406:

    # Celia "*Shlurp* *Suck* SHLLURRRRP*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:538
translate chinese CeR3_NS1_step3_ebf0a353:

    # MC "Hnnngg! Ugghhh!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:540
translate chinese CeR3_NS1_step3_c6e08e51:

    # Celia "*Shlurrrp* *Suck* *Gulp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:542
translate chinese CeR3_NS1_step3_f27b05d5:

    # MC "Oh fuuuuck... Your mouth is amazing!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:549
translate chinese CeR3_NS1_step3_74be9b8a:

    # MC "Hnnng! Stop sucking, Celia! I’m going to pull out and finish over your face."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:551
translate chinese CeR3_NS1_step3_05ac408d_2:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:555
translate chinese CeR3_NS1_step3_f81fbc19:

    # Celia "C’mon, sir. Coat my face with your hot semen! I want to feel it spray all over me!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:557
translate chinese CeR3_NS1_step3_9f5b8db0:

    # MC "Hnnngg! Aaarghh!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:559
translate chinese CeR3_NS1_step3_0326baa6:

    # Celia "Yes! Cum for me!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:569
translate chinese CeR3_NS1_step3_d490081d:

    # MC "Aaahhh! Ooohh fuuuuck!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:571
translate chinese CeR3_NS1_step3_ab57ff80:

    # Celia "Mmm! Yes! Just like that!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:576
translate chinese CeR3_NS1_step3_80c0d2be:

    # Celia "Oh wow... You’ve been saving up A LOT for me, haven’t you?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:578
translate chinese CeR3_NS1_step3_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:580
translate chinese CeR3_NS1_step3_a787c91f:

    # Celia "Hehe, such a naughty boy!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:587
translate chinese CeR3_NS1_step3_17fe4ef9:

    # Celia "*Shlurrrp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:589
translate chinese CeR3_NS1_step3_a5c20ef8:

    # MC "Hnnnng! I’m cumming!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:593
translate chinese CeR3_NS1_step3_a9b0e5a2:

    # Celia "*Shlurp* *Shluuurrrp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:595
translate chinese CeR3_NS1_step3_9d3a046b:

    # MC "*Pant* Hnnngg! I’m gonna finish over your face!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:599
translate chinese CeR3_NS1_step3_e82cb59b:

    # MC "Oohhh fuck!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:601
translate chinese CeR3_NS1_step3_bc8d85eb:

    # Celia "Go on, cum for me!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:611
translate chinese CeR3_NS1_step3_0914bf97:

    # MC "Hnnng! Arrghh!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:613
translate chinese CeR3_NS1_step3_65827db7:

    # Celia "Mmm! Yes! Blow your load all over my face!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:619
translate chinese CeR3_NS1_step3_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:621
translate chinese CeR3_NS1_step3_fdeb868c:

    # Celia "It seems like someone enjoyed that."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:623
translate chinese CeR3_NS1_step3_12dd9202:

    # MC "I want to see you lick it up."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:627
translate chinese CeR3_NS1_step3_7ce0cbbf:

    # Celia "Of course. sir. All you had to do was ask."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:629
translate chinese CeR3_NS1_step3_e6b7a565:

    # MC "(Alright! It’s nice having Celia wrapped around my finger like this!)"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:633
translate chinese CeR3_NS1_step3_3dd592f7:

    # Celia "Mmm!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:635
translate chinese CeR3_NS1_step3_91297491:

    # MC "That’s it. Good girl. Well done!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:637
translate chinese CeR3_NS1_step3_ee160ad3:

    # Celia "*Shlurp* Mmmm!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:645
translate chinese CeR3_NS1_step3_con_1bb79ef1:

    # Celia "Well?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:647
translate chinese CeR3_NS1_step3_con_40d07962:

    # MC "Hm?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:649
translate chinese CeR3_NS1_step3_con_50026781:

    # Celia "Was I good enough? Are you FINALLY going to let me cum?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:651
translate chinese CeR3_NS1_step3_con_4acb710f:

    # MC "Hmm... Tell you what, if you can hold off masturbating until next time we meet, then I PROMISE I will let you cum. Is that a fair deal?"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:655
translate chinese CeR3_NS1_step3_con_5910c262:

    # Celia "Promise?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:657
translate chinese CeR3_NS1_step3_con_c7fc5d12:

    # MC "Promise."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:661
translate chinese CeR3_NS1_step3_con_3e5b4384:

    # Celia "...Okay, I can handle one more day without cumming. You better not go back on your word though!"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:663
translate chinese CeR3_NS1_step3_con_587b3805:

    # MC "I promise, next time I see you, I’m going to make you cum."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:667
translate chinese CeR3_NS1_step3_con_294cd2e2:

    # Celia "You’re coming back soon, aren’t you, sir?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:669
translate chinese CeR3_NS1_step3_con_eff34780:

    # MC "We’ll see. I’m a busy man. Places to be, things to do, mini-games to repeatedly play to get more cash. You know how it is."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:673
translate chinese CeR3_NS1_step3_con_942408db:

    # Celia "Hmm. Don’t be too long. I’m a horny woman. Who's to say I won’t just find another man who will satisfy me instead?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:675
translate chinese CeR3_NS1_step3_con_748b1855:

    # MC "Ha! Ahahaha!"
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:677
translate chinese CeR3_NS1_step3_con_595c4cc6:

    # Celia "Something funny?"
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:681
translate chinese CeR3_NS1_step3_con_a524fa95:

    # MC "There isn’t another man out there who could satisfy you the way I do. If there WAS, then I have no doubt you’d have already called them."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:683
translate chinese CeR3_NS1_step3_con_62fe79cd:

    # MC "Face it, Celia, I’m the only one who can give you what you actually want."
    MC ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:685
translate chinese CeR3_NS1_step3_con_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/Ce_R3/4_CeR3_NS1.rpy:687
translate chinese CeR3_NS1_step3_con_ec1591c5:

    # Celia "([player_name] knows me too well.)"
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R3/4_CeR3_NS1.rpy:522
    old "Cum inside Celia’s mouth"
    new ""

    # game/scripts/Ce_R3/4_CeR3_NS1.rpy:522
    old "Cum over Celia’s face"
    new ""

    # game/scripts/Ce_R3/4_CeR3_NS1.rpy:522
    old "Ask Celia to taste/lick your cum"
    new ""

