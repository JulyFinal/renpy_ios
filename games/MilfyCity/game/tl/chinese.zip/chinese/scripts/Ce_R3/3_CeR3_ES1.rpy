﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:114
translate chinese CeR3_ES1_1499d174:

    # MC "(The last time I was at Celia’s place, I left her unsatisfied. If my plan has worked, then she is going to be even hornier today!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:116
translate chinese CeR3_ES1_9d530bfa:

    # MC "(I think I’m going to keep edging her like this, bringing her closer and closer to a climax, but continually denying her until she fully submits to me.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:120
translate chinese CeR3_ES1_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:122
translate chinese CeR3_ES1_9bcee162:

    # MC "(Yeah, that plan sounds like it’ll work. I’ll have her wrapped around my finger in no time at all!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:127
translate chinese CeR3_ES1_a8084d9e:

    # "*Creeaak*"
    ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:128
translate chinese CeR3_ES1_2ce5963e:

    # Celia "[player_name]! You came back! I mean, sir! Sorry, got a little too excited there, and forgot."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:130
translate chinese CeR3_ES1_3dc54a42:

    # MC "I like the outfit, Celia."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:132
translate chinese CeR3_ES1_5d5dca5d:

    # Celia "Thank you, I’m just out of the bath. Thought I’d freshen up in case you dropped by. You did tell me to ALWAYS be ready for you."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:136
translate chinese CeR3_ES1_762a1750:

    # MC "Well done for remembering."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:138
translate chinese CeR3_ES1_bc3f44aa:

    # Celia "Don’t just stand out there in the cold hallway! Come on in!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:140
translate chinese CeR3_ES1_d670be96:

    # MC "You’re home alone tonight?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:144
translate chinese CeR3_ES1_e48cf5d8:

    # Celia "Yeah, Gustav is away at some work conference this evening. We have the rest of the night to ourselves."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:146
translate chinese CeR3_ES1_27829016:

    # MC "No chance of us being interrupted, then? I don’t quite fancy being murdered by your husband today."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:148
translate chinese CeR3_ES1_8376886d:

    # Celia "I promise you, he’s NOT gonna show up."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:150
translate chinese CeR3_ES1_b570485f:

    # MC "The amount of emphasis we’re both putting into this conversation, sure makes it feel like foreshadowing of what is about to happen."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:152
translate chinese CeR3_ES1_83d4e3cb:

    # Celia "You’re being paranoid, sir."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:155
translate chinese CeR3_ES1_d5c2e1e8:

    # Celia "See? It’s nice and toasty in here. I’ve had the heating on so we can both be comfortable, even when we’re naked."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:157
translate chinese CeR3_ES1_4cda061b:

    # Celia "So, what did you have in mind for today, sir?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:159
translate chinese CeR3_ES1_9ed0d4b6:

    # MC "How about we take things to the master bedroom?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:161
translate chinese CeR3_ES1_101a59af:

    # Celia "Mmm, I’d like that. Lead the way, sir."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:165
translate chinese CeR3_ES1_74649fe3:

    # Celia "Well, this is the bedroom, sir. What would you like me to do for you tonight? Or, perhaps, I should ask, what would you like to do to ME?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:167
translate chinese CeR3_ES1_6f8e3892:

    # MC "Mmm, you can start by slowly stripping out of your dressing gown."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:169
translate chinese CeR3_ES1_9f50c777:

    # Celia "Hehe, of course, sir."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:176
translate chinese CeR3_ES1_5ed3a6fd:

    # Celia "How is this? Do you like my big, round breasts?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:178
translate chinese CeR3_ES1_6a36e609:

    # MC "(Damn, she’s so fucking hot. I almost feel guilty, knowing that I’m probably going to deny her, orgasms today as well.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:180
translate chinese CeR3_ES1_1d8f98ca:

    # MC "Yeah, you look fucking great. Lose the rest of the robes."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:185
translate chinese CeR3_ES1_f376a912:

    # Celia "Well? What did you have planned for me tonight, sir? Are you perhaps going to thrust your big, fat cock into my tight pussy?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:187
translate chinese CeR3_ES1_30797037:

    # MC "Perhaps. I was also debating using your asshole."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:189
translate chinese CeR3_ES1_7cbc9347:

    # Celia "M-My ass?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:193
translate chinese CeR3_ES1_9665d058:

    # MC "Yeah, why not? It’s not like you’ve NEVER done anal before. Besides, your ass is perfect - it’s just begging to be pounded."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:195
translate chinese CeR3_ES1_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:197
translate chinese CeR3_ES1_2d63f3e3:

    # Celia "(I really wasn’t prepared for him to suggest doing anal tonight! This definitely came WAY out of the blue!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:201
translate chinese CeR3_ES1_965aef97:

    # MC "How about you bend over and let me get a better look at your holes, before I choose one?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:203
translate chinese CeR3_ES1_7cf8ce55:

    # Celia "Y-Yes, sir."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:205
translate chinese CeR3_ES1_3b666791:

    # MC "Bend over as far as you can. I want the perfect view of your slutty body."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:209
translate chinese CeR3_ES1_313f6123:

    # Celia "How is this, sir?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:211
translate chinese CeR3_ES1_e3614db5:

    # MC "I didn’t realise you were that flexible, Celia!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:213
translate chinese CeR3_ES1_e9d41915:

    # Celia "I do kickboxing, remember?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:215
translate chinese CeR3_ES1_2e692893:

    # MC "Ahh, of course."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:219
translate chinese CeR3_ES1_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:221
translate chinese CeR3_ES1_6a9ebd95:

    # MC "(Which one of her holes should I fuck tonight? Her pussy is already nice and wet, but I’d love to see if Celia gains any pleasure from being fucked in the ass.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:223
translate chinese CeR3_ES1_fd0b2987:

    # MC "(Maybe pounding her ass would be a good way to deny her another orgasm? She’d probably prefer me fucking her pussy.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:227
translate chinese CeR3_ES1_97932d7c:

    # Celia "I’m ready whenever you are, sir. Please don’t keep me waiting. I’m soooo horny after last time."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:229
translate chinese CeR3_ES1_c1955f92:

    # MC "Shush, be patient, Celia. I’m still looking."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:233
translate chinese CeR3_ES1_d4372957:

    # MC "(Let’s start by teasing her with some fingering. Should I start with her pussy or ass?)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:239
translate chinese CeR3_ES1_52198056:

    # Celia "Oooh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:241
translate chinese CeR3_ES1_d798bcee:

    # MC "I can’t believe you’re so wet already, Celia. We’ve barely begun!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:243
translate chinese CeR3_ES1_d5d0dc30:

    # Celia "Mmm! I’ve been ah... soaking since you ahhhbandoned me during our last oohh... session, sir. I had to cahhhhrry extra pairs of panties in my handbag to work! MMM!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:247
translate chinese CeR3_ES1_f5353623:

    # Celia "Oh God! Mmm! Yes! Right there! Ahh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:249
translate chinese CeR3_ES1_a562b036:

    # Celia "(I can feel his finger pressing against my g-spot! I’m gonna cum if he keeps this up!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:251
translate chinese CeR3_ES1_8c180e4e:

    # Celia "*Moan* Mmmm! Yes, deeeper! Ahhh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:258
translate chinese CeR3_ES1_8efdc8ab:

    # MC "Let’s find out how tight your ass is, Celia. I might decide to pound your back door instead tonight."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:260
translate chinese CeR3_ES1_3a4662f5:

    # Celia "W-Wait, hold on. Let’s just-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:264
translate chinese CeR3_ES1_52bb6114:

    # Celia "*Gasp*!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:266
translate chinese CeR3_ES1_811a6c11:

    # MC "Mmm, VERY tight! I’d thought about using lube, but then I remembered how much you enjoy the pain. I think you’re going to love me driving my fat cock, deep inside your tight little asshole."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:268
translate chinese CeR3_ES1_e5de5a2f:

    # Celia "Oohh..."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:275
translate chinese CeR3_ES1_con_182a055c:

    # Celia "H-Hey, why’d you stop?!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:277
translate chinese CeR3_ES1_con_4a7698f9:

    # MC "Did you honestly think I came all the way over here just to finger you? I’m expecting some reciprocation here."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:279
translate chinese CeR3_ES1_con_b19fdf61:

    # Celia "Oh, sorry, sir."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:283
translate chinese CeR3_ES1_con_775bb1d1:

    # Celia "Here, let me see if I can..."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:285
translate chinese CeR3_ES1_con_6435d224:

    # MC "Oh wow."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:287
translate chinese CeR3_ES1_con_19ca02ec:

    # Celia "See? Pretty flexible, right?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:291
translate chinese CeR3_ES1_con_305eb115:

    # MC "Mmm! Not bad!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:293
translate chinese CeR3_ES1_con_d1895a0a:

    # Celia "How about you keep fingering me while I massage your cock?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:295
translate chinese CeR3_ES1_con_f28fbeff:

    # MC "No, I think I’ve got a better idea."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:299
translate chinese CeR3_ES1_con_351e121c:

    # Celia "Oh?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:301
translate chinese CeR3_ES1_con_76808ae5:

    # MC "You’re going to sit on my dick and ride it until I cum. I want to feel you bouncing up and down as hard as you can. Is that understood?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:303
translate chinese CeR3_ES1_con_b78cee52:

    # Celia "Yes, sir!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:307
translate chinese CeR3_ES1_con_d7b5deef:

    # Celia "Ahhhh! Ooohh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:309
translate chinese CeR3_ES1_con_c601f10b:

    # MC "Mmm! Fuck"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:311
translate chinese CeR3_ES1_con_aa0ad91b:

    # Celia "Sir! Your cock’s ahh... s-so big!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:315
translate chinese CeR3_ES1_con_2ce5c306:

    # Celia "Ah! Ah! Ah!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:317
translate chinese CeR3_ES1_con_887afc6a:

    # MC "(I can feel her pussy clamping down around my cock as she bounces! This is fucking amazing!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:319
translate chinese CeR3_ES1_con_545b36bc:

    # MC "Ahhnnn..."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:323
translate chinese CeR3_ES1_con_effd64b9:

    # Celia "Oh! Oh yes! Yes! Your big dick feels SO good inside my pussy, sir! YES! Ahhh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:325
translate chinese CeR3_ES1_con_be1bedce:

    # MC "Mmm! (It sounds like she’s getting close to cumming!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:327
translate chinese CeR3_ES1_con_f0666601:

    # Celia "Ahhh! *Pant* Ahhh! "
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:331
translate chinese CeR3_ES1_con_41ebf222:

    # Celia "Yeesssss! I love rocking my hips back and fooooorth on your fat cock! Ooohhh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:333
translate chinese CeR3_ES1_con_5b9b5fe4:

    # MC "Hnng... *Pant*"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:335
translate chinese CeR3_ES1_con_8dc5f47e:

    # Celia "Ah! Ah!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:339
translate chinese CeR3_ES1_con_ba1b0482:

    # Celia "It feels soooo good, riding your bare cock! Mmm! It slides in sooo easily, without a condom getting in the way!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:341
translate chinese CeR3_ES1_con_74be0316:

    # Celia "Ooohhh! Fuuuuuuck!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:343
translate chinese CeR3_ES1_con_545b36bc_1:

    # MC "Ahhnnn..."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:346
translate chinese CeR3_ES1_con_2d106231:

    # MC "(She’s getting louder! I think she’s DEFINITELY getting closer to cumming! I think I’ll let her go right up to the very edge before I stop her.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:348
translate chinese CeR3_ES1_con_b83bbd4c:

    # MC "(I’ll keep doing it over and over to her, making her more and more desperate until she is BEGGING for release!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:352
translate chinese CeR3_ES1_con_aba183c8:

    # Celia "Ah! AHHH!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:354
translate chinese CeR3_ES1_con_4e8c602b:

    # MC "(It’ll be spectacular! The woman who once rejected me, will be the one begging ME to make her cum.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:356
translate chinese CeR3_ES1_con_f5ba6a21:

    # MC "(God, I love how the tables have turned.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:360
translate chinese CeR3_ES1_con_d8b07938:

    # Celia "Yes! Yes! Ahh! YESSS!!! MMMM!!!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:362
translate chinese CeR3_ES1_con_c11863d6:

    # MC "Hnnng! Ugh! Faster, Celia!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:364
translate chinese CeR3_ES1_con_a478f679:

    # Celia "Ah! Ah! AH! AHHH!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:368
translate chinese CeR3_ES1_con_ff35a79c:

    # MC "Are you getting close?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:370
translate chinese CeR3_ES1_con_cf544b2e:

    # Celia "Y-Yes, sir! Ahh! I’m getting AHHH... s-sooooohhh cl-clooohhsse!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:372
translate chinese CeR3_ES1_con_4150a410:

    # MC "I want you to ugh... tell me right before you are about to cum, okay?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:376
translate chinese CeR3_ES1_con_b88d6776:

    # Celia "*Pant* Y-Yes, sir!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:378
translate chinese CeR3_ES1_con_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:382
translate chinese CeR3_ES1_con_044eb687:

    # Celia "*Pant* It’s getting s-so intense! Haaaa! AAHHHHH!!!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:384
translate chinese CeR3_ES1_con_7d4dde68:

    # MC "Remember, Celia, no cumming without telling me first."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:386
translate chinese CeR3_ES1_con_3c1433fa:

    # Celia "Y-Yes, sir! Ahhh! OOOHHHH!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:390
translate chinese CeR3_ES1_con_49cae69a:

    # MC "Hnnnngg!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:392
translate chinese CeR3_ES1_con_a8ab5251:

    # MC "(She’s absolutely crazy! She’s riding my cock so hard right now!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:394
translate chinese CeR3_ES1_con_b6050e10:

    # Celia "I’m gonna cum! I’m- ayaaahhh! I’m about to c-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:398
translate chinese CeR3_ES1_con_9a02c117:

    # MC "Stop!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:400
translate chinese CeR3_ES1_con_2732d629:

    # Celia "Ah! AHHH! AHHHH!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:402
translate chinese CeR3_ES1_con_956c0387:

    # MC "I ordered you to stop, Celia!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:404
translate chinese CeR3_ES1_con_7fdbdebc:

    # Celia "*Pant* Wh-What? Why? I was about to cum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:406
translate chinese CeR3_ES1_con_022447bf:

    # MC "Right, we’re gonna take a short break for thirty seconds, then we’re going to slide up onto the bed with you sitting on my stomach."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:410
translate chinese CeR3_ES1_con_16f05178:

    # Celia "*Pant* Like this?"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:412
translate chinese CeR3_ES1_con_1c145b2c:

    # Celia "(My body’s so sensitive right now! Everywhere is tingling since he denied me that orgasm!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:414
translate chinese CeR3_ES1_con_d9f4fe56:

    # MC "Perfect, I’m going to slide my dick in now."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:418
translate chinese CeR3_ES1_con_93ab0733:

    # Celia "Oooohhh! S-Sir!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:420
translate chinese CeR3_ES1_con_b38780ba:

    # MC "Oops, did I brush against your clit, there?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:422
translate chinese CeR3_ES1_con_e21f2e41:

    # Celia "S-Stop *Pant* teasing me!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:426
translate chinese CeR3_ES1_con_ccebb97c:

    # Celia "Ahhh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:428
translate chinese CeR3_ES1_con_e8abbfeb:

    # MC "Hnnng! There we go!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:430
translate chinese CeR3_ES1_con_aaef5271:

    # Celia "Ohh! *Gasp* You’re ahh... hitting my g-spot at this angle!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:434
translate chinese CeR3_ES1_con_b224eadb:

    # Celia "Ohhh! *GASP* Oh God! Yes! Ahh! Fuck! It’s so intense! MMM!!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:436
translate chinese CeR3_ES1_con_6ca71ad5:

    # MC "Hnngg!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:438
translate chinese CeR3_ES1_con_c55c2410:

    # Celia "*Pant* Yes! Keep *pant* thrusting! I want to feel your fat cock ahhh... ruin my pussy! YES! I’m gonna cum! I’m gonna-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:442
translate chinese CeR3_ES1_con_759ab868:

    # MC "And, we’re gonna stop."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:444
translate chinese CeR3_ES1_con_d573ec8d:

    # Celia "*Pant* Nooooo! Whyyyy?!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:446
translate chinese CeR3_ES1_con_0268cc98:

    # MC "Let’s change up positions again. Lie back on the bed. I’m gonna be on top this time."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:448
translate chinese CeR3_ES1_con_24ca0739:

    # Celia "(I was sooooo close! Why does he keep insisting on switching up positions, right as I’m about to finish?!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:454
translate chinese CeR3_ES1_con_98df39ac:

    # MC "I think your pussy has had enough attention for one day. Let’s see if that tight ass of yours is ready to handle my cock."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:456
translate chinese CeR3_ES1_con_d7e4891b:

    # Celia "Pleeeeasse, my pussy’s so wet! Please fuck my pussy, sir!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:458
translate chinese CeR3_ES1_con_369887f3:

    # MC "Let go of my cock, Celia."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:460
translate chinese CeR3_ES1_con_46882cf0:

    # Celia "Pllleease! I’m sooo horny! I want you to pound my pussy, sir! I can’t cum as easily when you fuck my-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:462
translate chinese CeR3_ES1_con_d125d480:

    # MC "I ordered you to let go, Celia."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:466
translate chinese CeR3_ES1_con_a1a03cb5:

    # MC "Good girl. Mmm! See? It slid right in!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:468
translate chinese CeR3_ES1_con_de9c3e61:

    # Celia "Owww!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:470
translate chinese CeR3_ES1_con_c559e13e:

    # MC "Aw, c’mon, I know you love it when it hurts. The pain only turns you on even more."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:472
translate chinese CeR3_ES1_con_72976f07:

    # Celia "(Oh fuck! He knows me too well!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:474
translate chinese CeR3_ES1_con_92718842:

    # Celia "Ahh *gasp* Y-You bastard! Ah! I’m *choke* I’m gonna... Fuck! Ahh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:478
translate chinese CeR3_ES1_con_c932216c:

    # MC "That’s no way to speak to me, Celia. Besides, I can tell you’re enjoying my fingers wrapped around your pretty neck. I can feel your sphincter tightening around my shaft."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:480
translate chinese CeR3_ES1_con_6bfd5af0:

    # Celia "Ah! Ahhh *choke* Oohhh! *Gasp*"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:482
translate chinese CeR3_ES1_con_0037080c:

    # Celia "(Oh God! It feels so fucking good!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:484
translate chinese CeR3_ES1_con_6f8eaaf6:

    # MC "Let’s see how deep your ass can take my cock, Celia."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:488
translate chinese CeR3_ES1_con_fda11205:

    # Celia "AAHAHHHHHH!! *Choke* OOOHHHHH!!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:490
translate chinese CeR3_ES1_con_718e1125:

    # MC "Y’know, for someone who claims to be unable to cum as easily from anal, you sure are screaming your head off right now."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:492
translate chinese CeR3_ES1_con_269782ea:

    # MC "Ugh! Goddamn, your ass is tight!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:496
translate chinese CeR3_ES1_con_bbca6dc9:

    # MC "Fuck! I’m gonna cum! Hnnngg!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:498
translate chinese CeR3_ES1_con_80a20e45:

    # Celia "N-Nooh! W-Wait, I’m *choke* n-not done yet! I’m not *choke* going to cum ye-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:500
translate chinese CeR3_ES1_con_a9a1baf9:

    # MC "(Should I pull out and cum over her asshole? Or bury my cock in deep and fill her up with my semen?)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:506
translate chinese CeR3_ES1_con_c5adba3e:

    # MC "Uggghh! HNNNGG!!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:508
translate chinese CeR3_ES1_con_ff9a8b56:

    # Celia "Nooo! Not yet! Pleeeeasse! Let me cuuum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:510
translate chinese CeR3_ES1_con_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:520
translate chinese CeR3_ES1_con_36e7a281:

    # Celia "Ohhhh fuuuuck!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:522
translate chinese CeR3_ES1_con_9517ec20:

    # Celia "(I can feel his hot cum, rushing inside me! Why couldn’t he have just came inside my pussy instead?! This is torture!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:524
translate chinese CeR3_ES1_con_72e89b1a:

    # MC "Arrghh... *Pant* Oohhh..."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:531
translate chinese CeR3_ES1_con_8b68eda4:

    # MC "Hnnng! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:533
translate chinese CeR3_ES1_con_3d4635c5:

    # Celia "Nooo! Please, finish me off! Pleaseee! I wanna cum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:543
translate chinese CeR3_ES1_con_3cf35841:

    # MC "Ahhnnnggg! UGH!!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:545
translate chinese CeR3_ES1_con_5cb98ec7:

    # Celia "Ohhh..."
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:547
translate chinese CeR3_ES1_con_f05636c7:

    # Celia "(I can feel his hot cum, splashing against my pussy and asshole! Why couldn’t he just fuck my pussy and finish me off?!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:554
translate chinese CeR3_ES1_con_207d06c3:

    # Celia "Ohh! Oh fuck! Yes! Please, put it inside me! Stick your fat cock in my pussy, sir! I want to feel you deep inside me!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:556
translate chinese CeR3_ES1_con_0cea57c5:

    # MC "Here we go."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:558
translate chinese CeR3_ES1_con_fd1c33ac:

    # Celia "Ah! Yessss!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:562
translate chinese CeR3_ES1_con_6981fba0:

    # Celia "Holy shit! You’re so big! Mmm! Oh God! You’re going to make me cum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:564
translate chinese CeR3_ES1_con_cfffdf1b:

    # MC "Ah, no cumming until I give you permission to. If you even THINK about cumming without letting me know, then it’s the last orgasm I’ll ever give you."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:566
translate chinese CeR3_ES1_con_af9c3448:

    # Celia "Pllleeease! I need to feel you inside me!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:570
translate chinese CeR3_ES1_con_5c20ab3a:

    # Celia "Ahhh! Yesssss! Aaaahhhhh!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:572
translate chinese CeR3_ES1_con_b1e452d9:

    # MC "You’re soaking wet right now, Celia. My cock slipped inside so easily."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:574
translate chinese CeR3_ES1_con_52b9fb27:

    # Celia "That’s because you ohhhh... have left me soooo horny! God! I can feel your dick thobbing inside me!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:578
translate chinese CeR3_ES1_con_e69f0e66:

    # MC "Hnnng!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:580
translate chinese CeR3_ES1_con_20bbe2d0:

    # Celia "YES! YES! FUCK ME! SCREW ME! POUND ME LIKE I’M YOUR SLUTTY LITTLE WHORE!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:584
translate chinese CeR3_ES1_con_f01d26a4:

    # Celia "YEESSSSSS!! AAAAAHHHH!!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:586
translate chinese CeR3_ES1_con_4ffc3c0f:

    # MC "(She’s growing louder with each passing minute! I can’t wait to see her reaction when I deny her yet another orgasm!)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:588
translate chinese CeR3_ES1_con_1fbb6a75:

    # Celia "*PANT* AAAHHH! Oh GOD! I’m gonna cum! I’m-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:592
translate chinese CeR3_ES1_con_c8e20dcb:

    # Celia "NOOOO!! WHY DID YOU STOP?!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:594
translate chinese CeR3_ES1_con_aac7c549:

    # MC "I just needed a bit of a breather. Give me a couple of minutes."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:596
translate chinese CeR3_ES1_con_002d0528:

    # Celia "I WAS SO CLOSE! You’re doing this on purpose!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:600
translate chinese CeR3_ES1_con_abfb110e:

    # MC "No, I’m not. See?"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:602
translate chinese CeR3_ES1_con_48325c3f:

    # Celia "Ooohhh! Mmmm! Yes! Yes! Just like that! Deeper! DEEPER! Ah! God! I’m gonna cum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:604
translate chinese CeR3_ES1_con_c1e356e9:

    # MC "(Heh, I think I’m about to cum as well. Let’s see if I can finish myself off before she does.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:608
translate chinese CeR3_ES1_con_1e59de41:

    # Celia "YES! FUCK! Fill me up! AAHHHH!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:610
translate chinese CeR3_ES1_con_9d3166da:

    # MC "(Her body has started shaking! It looks like she’s on the precipice of another climax.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:612
translate chinese CeR3_ES1_con_8f4e2bc7:

    # Celia "(Oh God! Just a couple more thrusts and I’m FINALLY going to cum!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:618
translate chinese CeR3_ES1_con_3bdacde5:

    # Celia "Yes! Yes! W-Wait, don’t stop!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:620
translate chinese CeR3_ES1_con_be15eb61:

    # MC "I’m cumming! HNNNGG!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:622
translate chinese CeR3_ES1_con_5784f840:

    # Celia "NOO! Don’t stop thrusting! Keep going! Don’t sttooooooohhhp!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:633
translate chinese CeR3_ES1_con_7b1f850b:

    # MC "HNNNG!! UHHGGGHHH! Ahhhh!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:635
translate chinese CeR3_ES1_con_171122cc:

    # Celia "NOOO! THIS ISN’T FAIR! PLLLEEEAAASSE STOP TEASING MEEEE!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:642
translate chinese CeR3_ES1_con_1651c763:

    # Celia "Oh God! I’m gonna cum! I’m gonna-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:644
translate chinese CeR3_ES1_con_c7ce45d3:

    # Celia "WHY’D YOU PULL IT OUT?!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:646
translate chinese CeR3_ES1_con_2ccbefff:

    # MC "Hnnng! Ugh! Aaahhh!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:657
translate chinese CeR3_ES1_con_d492a083:

    # MC "Aaarrghhh!"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:659
translate chinese CeR3_ES1_con_bd0a5fea:

    # Celia "(Oh fuck! I can feel his hot cum trickling down my clitoris! The bastard is fucking edging me! This is hell!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:661
translate chinese CeR3_ES1_con_df08f46b:

    # Celia "*Pant* Pllleeeease! I’m begging you, sir. Please let me cum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:668
translate chinese CeR3_ES1_con2_1c493fbe:

    # Celia "Please, please... I can’t take it anymore! Please! Stick your cock back inside me, [player_name]!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:670
translate chinese CeR3_ES1_con2_542dc709:

    # MC "I can’t. I’m done. And you’re forgetting to call me ‘sir’."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:672
translate chinese CeR3_ES1_con2_5b586e70:

    # Celia "Nooo! Please, sir! I’m begging you!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:676
translate chinese CeR3_ES1_con2_bd8804c3:

    # MC "(Just a little bit more training, and then I’ll consider allowing her to finish.)"
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:678
translate chinese CeR3_ES1_con2_60962e90:

    # MC "I said, no, Celia. I’m done."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:682
translate chinese CeR3_ES1_con2_374ce6b8:

    # Celia "You can’t just leave me like this! I’m soooo horny!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:684
translate chinese CeR3_ES1_con2_6480c41b:

    # Celia "Please! I NEED to cum!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:686
translate chinese CeR3_ES1_con2_ceeb4d2f:

    # Celia "(My clitoris feels like it’s on fire! I just need some release!)"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:688
translate chinese CeR3_ES1_con2_a99f00b8:

    # MC "No."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:692
translate chinese CeR3_ES1_con2_2119f774:

    # Celia "H-How about if you tie me up to that electrostimulation dildo again? I’ll do whatever you want!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:694
translate chinese CeR3_ES1_con2_0033b16e:

    # Celia "Yeah! I’ll even let you film me when I’m doing it. And then- and then- I’ll... I’ll suck your cock! You can creampie my pussy! You can-"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:698
translate chinese CeR3_ES1_con2_7f130710:

    # MC "You’re desperate, Celia. Nobody likes a desperate woman."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:700
translate chinese CeR3_ES1_con2_648d9d3f:

    # Celia "W-What?!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:702
translate chinese CeR3_ES1_con2_f6cd15c7:

    # MC "No masturbating when I’m away. And trust me, I will KNOW if you touched yourself. I want to see you EXACTLY like this when I return - a cock-hungry slut, desperate for cock."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:704
translate chinese CeR3_ES1_con2_f22f066d:

    # Celia "Wh-When are you coming back? I’m on the verge right now! I can’t take much more of this!"
    Celia ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:706
translate chinese CeR3_ES1_con2_8b8e301a:

    # MC "You’re just gonna have to wait and hope it isn’t too long."
    MC ""

# game/scripts/Ce_R3/3_CeR3_ES1.rpy:708
translate chinese CeR3_ES1_con2_faef8b4f:

    # Celia "...Please come back soon."
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:235
    old "Play with Celia’s pussy"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:235
    old "Play with Celia’s ass"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:450
    old "Fuck Celia’s asshole while wrapping your hand around her throat"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:450
    old "Fuck Celia’s pussy, but slow down every time she seems close to cumming"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:502
    old "Plunge your cock in deep and fill Celia’s body with your cum"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:502
    old "Pull out and show your load"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:614
    old "Cum inside her pussy"
    new ""

    # game/scripts/Ce_R3/3_CeR3_ES1.rpy:614
    old "Pull out and cum over her pussy"
    new ""

