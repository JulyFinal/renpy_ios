﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:32
translate chinese CeR3_MS3_6f920799:

    # Celia "Thank you, Doctor, I appreciate you coming so quickly."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:34
translate chinese CeR3_MS3_5c22f5fa:

    # MC "(What the...? I knew Gustav was in a bad way when I left, but I didn’t think he was THIS injured!)"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:38
translate chinese CeR3_MS3_8417aa5d:

    # Doctor "Honestly, Ma'am Celia, it is almost unbelievable what happened. Your husband fell down the stairs... several times."
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:40
translate chinese CeR3_MS3_203786d3:

    # Celia "Yes, Doctor."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:42
translate chinese CeR3_MS3_2ef793ca:

    # Doctor "You claim he tried to climb the stairs after he fell down the first time, only to fall down them again."
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:44
translate chinese CeR3_MS3_f5ae4f61:

    # Celia "Yes."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:46
translate chinese CeR3_MS3_ee0a34ff:

    # Doctor "Gustav then, according to you, repeated this event three more times before crawling back into your apartment, where you then dialed for an ambulance."
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:48
translate chinese CeR3_MS3_ec123c8f:

    # Doctor "I have to say, your story sounds very sus-"
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:53
translate chinese CeR3_MS3_e10a38f6:

    # Celia "Oh, hi, [player_name]! Good to see you."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:55
translate chinese CeR3_MS3_204e0b23:

    # MC "What... uh... what happened to Gustav?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:57
translate chinese CeR3_MS3_30b41087:

    # Doctor "Stairs... apparently."
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:59
translate chinese CeR3_MS3_e3e107e4:

    # Celia "Yeah, Gustav is going to need to go away for a while to get better. He’s VERY kindly agreed to let me keep the apartment in his permanent absence though."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:63
translate chinese CeR3_MS3_10de81b1:

    # Doctor "Permanent absence? What do you mean?"
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:65
translate chinese CeR3_MS3_443e57b6:

    # Celia "Those stairs are VERY slippery, Doctor. I wouldn’t suggest you pry too much."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:67
translate chinese CeR3_MS3_b59d4900:

    # Doctor "*Gulp*"
    Doctor ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:71
translate chinese CeR3_MS3_b7b2cc5c:

    # MC "How... uh... How are you feeling, Gustav?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:73
translate chinese CeR3_MS3_180a22f9:

    # Gustav "...fine."
    Gustav ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:75
translate chinese CeR3_MS3_249bdb28:

    # Celia "See? He just needs to rest. I’m sure your mother will be very happy to see you, while you’re recovering at her place!"
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:79
translate chinese CeR3_MS3_3800ca24:

    # MC "He, uh... Gustav wasn’t... wasn’t that badly injured when I left you two alone."
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:81
translate chinese CeR3_MS3_f34a3625:

    # Celia "No, he wasn’t."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:83
translate chinese CeR3_MS3_4a2919e4:

    # MC "How did...? Did he attack you?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:87
translate chinese CeR3_MS3_9f407c97:

    # Celia "Let’s just say we had a very... intense... heart-to-heart chat about the future of our lives."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:89
translate chinese CeR3_MS3_19f4c7fa:

    # Celia "We were never really meant for each other anyway. It was a desperate arrangement between our parents trying to set up their sleazy son who couldn’t stick to one girl, and a daughter who scared off every guy she dated."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:91
translate chinese CeR3_MS3_3cbfca71:

    # MC "Yeah, you almost scared me off too."
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:95
translate chinese CeR3_MS3_0c8d2fc2:

    # MC "Did you actually intend to kill him, there?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:97
translate chinese CeR3_MS3_82e7e027:

    # Celia "What? Of course not! I’ve not killed anyone..."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:99
translate chinese CeR3_MS3_d96921d6:

    # MC "Oh thank God."
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:103
translate chinese CeR3_MS3_9a7fd43b:

    # Celia "...yet."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:105
translate chinese CeR3_MS3_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:107
translate chinese CeR3_MS3_480c52d8:

    # MC "Well, what about the divorce? You mentioned that Gustav would be leaving you with the apartment?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:111
translate chinese CeR3_MS3_a8eb27f9:

    # Celia "Yeah, I got the apartment - he gets to keep his investments and all that crap."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:113
translate chinese CeR3_MS3_661213c4:

    # MC "He’ll be okay though, right?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:115
translate chinese CeR3_MS3_3ca55d22:

    # Celia "Of course he will. His family comes from money. Plus, you and I now have a permanent place to hang out and have some uninterrupted fun."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:119
translate chinese CeR3_MS3_f699ff67:

    # MC "Hang on, so we’ll be able to fuck here whenever we want?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:121
translate chinese CeR3_MS3_bfa81586:

    # Celia "The best time is probably the weekends. I understand you enjoy having me at your beck and call, but I won’t be able to afford to keep this apartment if I end up getting sacked from teaching."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:125
translate chinese CeR3_MS3_efa96be7:

    # MC "Ah, of course. So I can just swing by here any weekend then, and - you’ll be free?"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:127
translate chinese CeR3_MS3_1c842b54:

    # Celia "Does that work for you?"
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:129
translate chinese CeR3_MS3_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:133
translate chinese CeR3_MS3_2ed7af20:

    # Celia "Then it looks like we’ve got a deal. Promise me you’ll swing by on the weekends as often as you can, sir."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:135
translate chinese CeR3_MS3_d922b001:

    # MC "I will, Celia. We’ll make the most of this!"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:139
translate chinese CeR3_MS3_74342f05:

    # Celia "I’m looking forward to it. This is gonna be some unrestrained fun. I can’t wait to really let myself go wild - without having to worry about that dumb oaf catching us."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:141
translate chinese CeR3_MS3_d1dcd8cf:

    # MC "I know, it’s gonna be great!"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:143
translate chinese CeR3_MS3_73cffe2f:

    # Celia "Right, I better go and clean the bloodstains before they sink into the woodwork."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:145
translate chinese CeR3_MS3_8a494d6f:

    # MC "Yeah... I think I’m gonna go now."
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:149
translate chinese CeR3_MS3_8699d835:

    # MC "See you this weekend, Celia."
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:151
translate chinese CeR3_MS3_d1c11e17:

    # MC "(There’s so many things I've planned to do to you! I’m gonna make you cum your brains out!)"
    MC ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:155
translate chinese CeR3_MS3_dc4c4a64:

    # Celia "Mmm... Catch you then, sir."
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:157
translate chinese CeR3_MS3_f8a40847:

    # Celia "(I’m already wet with excitement. I hope he won’t mind if I make a little head start after I finish cleaning the apartment up. God... I wish he had left that electrosimulation dildo behind...)"
    Celia ""

# game/scripts/Ce_R3/6_CeR3_MS3.rpy:159
translate chinese CeR3_MS3_6b20a1cb:

    # Celia "(Oh well, I always have my other toys!)"
    Celia ""

