﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:38
translate chinese CeR3_MS1_f2d6abaa:

    # MC "(I've already talked with her.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:53
translate chinese CeR3_MS1_0bb1f0f5:

    # Celia "Ah, [player_name], you came."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:57
translate chinese CeR3_MS1_a23a0216:

    # MC "(I should take the opportunity to put Ms. Celia in her place. She seems to be under the impression that she can simply text me and expect me to meet her at a moment’s notice.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:59
translate chinese CeR3_MS1_2cafc827:

    # MC "You asked to see me, Celia."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:61
translate chinese CeR3_MS1_49c22e0b:

    # Celia "Yes, I did. I needed to-"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:65
translate chinese CeR3_MS1_f98b5b94:

    # MC "It appears that you’ve forgotten your place. I’m not your lapdog anymore, that you can just order around whenever you want."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:67
translate chinese CeR3_MS1_0c60acdb:

    # MC "I was under the impression that the boundaries of our relationship had been pretty clearly established when I recorded that tape of us. Or are you still under the delusion that you have ANY power over me?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:71
translate chinese CeR3_MS1_987e5430:

    # Celia "Gustav has left for some business in Bern for a few days. He’s going to..."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:75
translate chinese CeR3_MS1_3735c5a2:

    # Celia "*Sigh* This would be so much easier if you just took a seat. Please, [player_name], there’s no need to be so antagonistic. Just sit down."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:77
translate chinese CeR3_MS1_09555e36:

    # MC "(She’s actually trying to control the conversation again? Has she forgotten that I can upload that video of us fucking any time I want?)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:79
translate chinese CeR3_MS1_df1317dc:

    # MC "(She’s actually trying to control the relationship again? Has she forgotten that I’M the dominant one now?)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:81
translate chinese CeR3_MS1_953a2ba2:

    # MC "(I need to start showing I’m in control of the situation. Should I grab her cheeks and calmly explain that she can’t go around barking orders anymore? Or should I try a more dramatic approach, and kick the chair over?)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:87
translate chinese CeR3_MS1_34df3a3a:

    # Celia "Hurry up and sit down so we can-"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:91
translate chinese CeR3_MS1_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:93
translate chinese CeR3_MS1_8d133be4:

    # Celia "(Oh my God! I can’t move my head! He’s holding it in place!)"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:97
translate chinese CeR3_MS1_d332b41a:

    # MC "No, Celia. You’re not going to be giving orders anymore."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:99
translate chinese CeR3_MS1_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:101
translate chinese CeR3_MS1_1f51a358:

    # MC "Look at me. Things are going to be markedly different from- Celia! I said, look at me."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:105
translate chinese CeR3_MS1_98830baa:

    # Celia "S-Sorry."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:109
translate chinese CeR3_MS1_c57ce3d7:

    # MC "Things are going to be markedly different from now on. I have the video, I hold all the cards, I am the one who determines whether or not you have a future as an educator. So, when I speak, you WILL listen."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:111
translate chinese CeR3_MS1_7e8c4e25:

    # MC "When I say ‘No Panties’, you wear no panties. When I tell you to wear a vibrator in class, you wear a vibrator in class."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:113
translate chinese CeR3_MS1_5fb89aab:

    # MC "And when I tell you to suck my cock..."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:117
translate chinese CeR3_MS1_e0bb5ee2:

    # Celia "...I’ll suck your cock."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:119
translate chinese CeR3_MS1_d739c384:

    # Celia "(Oh God... I’m going to need to change my panties after [player_name] leaves. I’m soaking wet, right now.)"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:123
translate chinese CeR3_MS1_885a0cfb:

    # MC "Correct. However, you interrupted me while I was speaking. Don’t you dare do that again."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:125
translate chinese CeR3_MS1_35a8fb48:

    # Celia "Oh, I thought you wanted me to finish your sentence."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:127
translate chinese CeR3_MS1_d7dc3aa0:

    # MC "I didn’t."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:129
translate chinese CeR3_MS1_c373a0b5_1:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:133
translate chinese CeR3_MS1_d3b79ba3:

    # MC "I think we’re going to have to set a new ground rule for how we operate things, going forward. You’re going to address me as ‘Sir’, is that clear?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:135
translate chinese CeR3_MS1_f5ae4f61:

    # Celia "Yes."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:137
translate chinese CeR3_MS1_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:139
translate chinese CeR3_MS1_5131aaaa:

    # Celia "Yes, Sir."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:141
translate chinese CeR3_MS1_b5c81a31:

    # MC "Better."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:148
translate chinese CeR3_MS1_34df3a3a_1:

    # Celia "Hurry up and sit down so we can-"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:154
translate chinese CeR3_MS1_29898e32:

    # "*CRASH*"
    ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:158
translate chinese CeR3_MS1_499f8e11:

    # MC "(I’m not going to let this bitch boss me around again. She shoved my head into a toilet bowl. She snuck into my house and beat me up. She threatened me with a box cutter!)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:160
translate chinese CeR3_MS1_079d89d6:

    # MC "(There’s no way I’m EVER going to risk, this cunt, bossing me around ever again!)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:164
translate chinese CeR3_MS1_2770528a:

    # Celia "What the fuck?!"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:166
translate chinese CeR3_MS1_c95ea1ef:

    # MC "I’m not your goddamn slave, Celia. You don’t get to tell me when to stand, where to sit, or how to act."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:168
translate chinese CeR3_MS1_c373a0b5_2:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:172
translate chinese CeR3_MS1_355bcc0b:

    # MC "Does it look like I could actually sit in that chair?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:174
translate chinese CeR3_MS1_49bd355c:

    # Celia "I, uh..."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:176
translate chinese CeR3_MS1_6a44b453:

    # MC "It was a simple question, Celia. Does it look like I could sit in that chair, right now?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:178
translate chinese CeR3_MS1_b1630989:

    # Celia "N-No."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:180
translate chinese CeR3_MS1_b6d6e6f3:

    # MC "Then it sounds like you have two choices. You either pick it up for me, or I walk away right now and leave you here."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:184
translate chinese CeR3_MS1_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:186
translate chinese CeR3_MS1_df55b6f5:

    # MC "(I might have to follow through with my threat to leave. Celia is the one who asked me to be here today, so it’s clear SHE’S the one who NEEDS something from me. I’ve got nothing to lose by just turning 360 degrees and walking away right now.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:188
translate chinese CeR3_MS1_aba1cd19:

    # MC "Not gonna pick it up? Fine, I’m away."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:192
translate chinese CeR3_MS1_d59eb794:

    # Celia "(He’s actually leaving?!)"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:194
translate chinese CeR3_MS1_bd9d05b2:

    # Celia "W-Wait! [player_name], don’t go!"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:196
translate chinese CeR3_MS1_fbeda2b7:

    # MC "Too late, Celia. You had your chance."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:200
translate chinese CeR3_MS1_b022cd9b:

    # Celia "Hold on, [player_name], stay right there. Let me get this for you. "
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:202
translate chinese CeR3_MS1_401cb0bc:

    # MC "And...?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:204
translate chinese CeR3_MS1_332d7760:

    # Celia "And... uh..."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:206
translate chinese CeR3_MS1_1e6c663a:

    # MC "Are you not going to apologise?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:208
translate chinese CeR3_MS1_6e0f483e:

    # Celia "Oh! Sorry, I don’t know why I asked you to sit on that knocked-over chair - it was clearly very silly of me."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:212
translate chinese CeR3_MS1_b8b4eb9e:

    # MC "That’s good, but we can do better. Now, instead of barking orders at me, how about you address me with some respect."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:214
translate chinese CeR3_MS1_6870edb2:

    # Celia "Please, sit down and relax, [player_name]."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:216
translate chinese CeR3_MS1_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:218
translate chinese CeR3_MS1_7457bce8:

    # MC "(She kowtowed very quickly there. Whatever she asked me to come here today for, is something that she desperately needs. I think this could be my opportunity to press more concessions out of her.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:223
translate chinese CeR3_MS1_0f80ba22:

    # MC "Once again, better. But there’s still plenty of room for improvement. Let’s do that again, but this time, you call me “Sir.”"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:225
translate chinese CeR3_MS1_16abc0e4:

    # Celia "Please, sit down and relax... sir."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:231
translate chinese CeR3_MS1_con_f6827daf:

    # MC "Now, Celia, what did you need from me, so badly that you had to interrupt my day?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:233
translate chinese CeR3_MS1_con_41148365:

    # Celia "Well, I actually had a proposal for you. A proposal that I think you will quite enjoy."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:235
translate chinese CeR3_MS1_con_674ea425:

    # MC "And you couldn’t have made that proposal over a text message?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:240
translate chinese CeR3_MS1_con_68e8e8a7:

    # Celia "I don’t think I could have accurately conveyed the... significance of my proposal over a simple text. Plus, I think you will appreciate the proposal much more when you hear it from me, in person."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:244
translate chinese CeR3_MS1_con_c778e69f:

    # MC "Alright, you’ve got my attention."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:248
translate chinese CeR3_MS1_con_0349864a:

    # Celia "I’ve had some time to... reflect on what has happened between us. Everything that has happened between us."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:250
translate chinese CeR3_MS1_con_f2d3e6a4:

    # Celia "We both did some rather hateful things to each other."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:252
translate chinese CeR3_MS1_con_7b2a2c61:

    # Celia "We both did some rather hateful things to each other, even considering strong BDSM and roleplay."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:254
translate chinese CeR3_MS1_con_03db7f5e:

    # MC "Like threatening me with a knife?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:256
translate chinese CeR3_MS1_con_2a7f3e9e:

    # Celia "Let’s not dwell on the specifics. What I wanted to suggest was that it wasn’t ENTIRELY bad. I had my share of fun, making you eat my pussy, and I KNOW you certainly had your share of fun too with that glory hole."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:260
translate chinese CeR3_MS1_con_ba51722e:

    # MC "What are you getting at?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:262
translate chinese CeR3_MS1_con_44ed418f:

    # Celia "I’d like to propose an arrangement. We continue this... funny, little relationship of ours, but we take it in turns dominating each other. That way we can both get what we want."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:266
translate chinese CeR3_MS1_con_5ac6ef54:

    # Celia "What do you say, [player_name]?"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:272
translate chinese CeR3_MS1_con_8940c811:

    # MC "(Celia wants to think she can have a chance to dominate me again? As if I’m going to let that happen. She was the one who started this whole damned mess by humiliating me in front of everyone.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:274
translate chinese CeR3_MS1_con_d1a93fd5:

    # MC "(She could have politely turned me down - but she had to go one step further and mock me. No - I’m NOT letting her get away with having any control over me ever again.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:276
translate chinese CeR3_MS1_con_dc4938a1:

    # MC "(I’ll just get up and walk away now. I have that video tape, and I hold all the cards. Celia is the one who is going to have to start making some concessions if she actually wants to negotiate with me.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:278
translate chinese CeR3_MS1_con_f35102a6:

    # MC "No, Celia. It’s over."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:282
translate chinese CeR3_MS1_con_648d9d3f:

    # Celia "W-What?!"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:286
translate chinese CeR3_MS1_con_354aa9f3:

    # MC "I don’t want your deal. It doesn’t interest me. I’m leaving."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:288
translate chinese CeR3_MS1_con_f8f53837:

    # Celia "Wait!"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:290
translate chinese CeR3_MS1_con_326855ef:

    # MC "Goodbye, Celia."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:294
translate chinese CeR3_MS1_con_bdd0adee:

    # Celia "Stop! Wait! I... I... I was just joking!"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:296
translate chinese CeR3_MS1_con_9198970a:

    # Celia "Don’t go! You can ALWAYS be the one to dominate me! You can do whatever you want with my body! Just... don’t leave."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:300
translate chinese CeR3_MS1_con_0469e21b:

    # MC "(Heh, worked like a charm.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:302
translate chinese CeR3_MS1_con_d6a07f74:

    # MC "Oh really? That was a very abrupt change in tone, Celia. What made you change your mind?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:304
translate chinese CeR3_MS1_con_0d3a3b60:

    # Celia "I..."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:308
translate chinese CeR3_MS1_con_30f19ee4:

    # Celia "Nobody has ever done... the things you did to me before."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:310
translate chinese CeR3_MS1_con_a5b53f35:

    # MC "Not Gustav?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:312
translate chinese CeR3_MS1_con_88aef22d:

    # Celia "Not even Gustav. I’ve always kept my... proclivities to myself. But, as you can imagine, it isn’t easy to dominate oneself. It wasn’t until you used that electrostimulation dildo on me, that I realised the true heights of pleasure I could be taken to."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:319
translate chinese CeR3_MS1_con_8940c811_1:

    # MC "(Celia wants to think she can have a chance to dominate me again? As if I’m going to let that happen. She was the one who started this whole damned mess by humiliating me in front of everyone.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:321
translate chinese CeR3_MS1_con_d1a93fd5_1:

    # MC "(She could have politely turned me down - but she had to go one step further and mock me. No - I’m NOT letting her get away with having any control over me ever again.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:323
translate chinese CeR3_MS1_con_3d50c9e2:

    # MC "(I’m the one who has the videotape of her cumming her brains out on an electrostimulation dildo. I’m the one who has the records of her selling grades for cash. Celia has NOTHING. I should put her back in her place.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:328
translate chinese CeR3_MS1_con_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:330
translate chinese CeR3_MS1_con_25e7fbc0:

    # Celia "Ow!"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:332
translate chinese CeR3_MS1_con_727a9c94:

    # MC "Are you forgetting the tape I made? Have you forgotten all about the evidence I have on you for selling grades?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:336
translate chinese CeR3_MS1_con_2254f851:

    # MC "You’re in no position to bargain with me. You’ve got NOTHING to negotiate with. You have no leverage to fall back on, no evidence of anything I did to you."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:338
translate chinese CeR3_MS1_con_d03e0fbe:

    # MC "And if you think, even for a second, that this is going to be a relationship of equals, then you are SORELY mistaken."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:340
translate chinese CeR3_MS1_con_d81c9549:

    # MC "You treated me like shit after I asked you out, Celia. You could have rejected me politely, in private. But you didn’t. You humiliated me publicly. You mocked me CONSTANTLY after the event."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:342
translate chinese CeR3_MS1_con_616db742:

    # MC "Try anything like that ever again, and the next slap will be twice as..."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:346
translate chinese CeR3_MS1_con_4d14d545:

    # MC "...why are you smiling?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:348
translate chinese CeR3_MS1_con_77cc842f:

    # Celia "Please, keep going."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:350
translate chinese CeR3_MS1_con_78129843:

    # MC "You actually liked it when I slapped you?"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:352
translate chinese CeR3_MS1_con_6b51b3ab:

    # Celia "My panties are soaked right now, [player_name]. Does that answer your question?"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:354
translate chinese CeR3_MS1_con_32614abb:

    # MC "(The first time Celia had me over to her apartment we got to make out for a while. I remember spanking her ass back then and she almost killed me for doing it! I wonder what’s changed between now and then? Perhaps I’ve finally tamed her?)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:358
translate chinese CeR3_MS1_con_b88246ee:

    # MC "Fine. From now on, I’m the one who dominates in this relationship. Step out of line again, and I’ll have to slap you somewhere else."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:362
translate chinese CeR3_MS1_con_52491690:

    # Celia "Oooh, stop tempting me."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:369
translate chinese CeR3_MS1_con2_0d427c3e:

    # MC "(Okay, if Celia’s going to be my plaything, then I need to establish our relationship, going forward.)"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:371
translate chinese CeR3_MS1_con2_448a7647:

    # MC "Alright, let’s set some ground rules. If we’re going to be doing this, then I’m going to need unlimited access to your apartment whenever I want."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:373
translate chinese CeR3_MS1_con2_b0bced00:

    # MC "You must ALWAYS be ready for me. I don’t care if you’re working overtime, grading papers, showering, sleeping - whatever. If I ask you to do something, you do it."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:377
translate chinese CeR3_MS1_con2_4509e2b9:

    # Celia "Mmm, okay. It would be better if you dropped by my place in the evenings though. "
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:378
translate chinese CeR3_MS1_con2_4d947dc1:

    # Celia "Implementing morning or afternoon visits to my apartment would probably result in more work for the programmer and further delays to the final release of this gam-"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:382
translate chinese CeR3_MS1_con2_1e53251b:

    # MC "Celia, what the fuck are you talking about? Ugh, nevermind. "
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:384
translate chinese CeR3_MS1_con2_44b03727:

    # MC "It’s not going to be your decision as to what time I drop by. If I’m there in the morning, you better be ready. If I show up in the afternoon, then you better be there, mouth open, ready to suck on my shaft."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:388
translate chinese CeR3_MS1_con2_10f08c7a:

    # Celia "[player_name], I’ve got Gustav in the house, I’ve got... I’ve got a job here! I can’t always be-"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:390
translate chinese CeR3_MS1_con2_ef878d3f:

    # MC "If you are not at home when I show up, then I reserve the right to punish you in any way I see fit. These are the terms of the relationship, going forward."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:392
translate chinese CeR3_MS1_con2_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:396
translate chinese CeR3_MS1_con2_1d772778:

    # MC "I’ll see you later, Celia. Don’t forget, I ALWAYS want you to be ready for me."
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:398
translate chinese CeR3_MS1_con2_09f97e45:

    # MC "Let this be your only warning. Disappoint me, and you’ll be in for a whole world of p-"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:400
translate chinese CeR3_MS1_con2_2754507b:

    # Celia "...pleasure."
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:402
translate chinese CeR3_MS1_con2_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:405
translate chinese CeR3_MS1_con2_e37781a3:

    # Celia "(Mmm... This is going to be fun.)"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:407
translate chinese CeR3_MS1_con2_61136bf6:

    # Celia "(I hadn’t realised it at the time, but something had been awakening in me, from the moment that [player_name] had started blackmailing me and using my body in the toilet’s glory hole.)"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:409
translate chinese CeR3_MS1_con2_bc5dc51d:

    # Celia "(I hadn’t realised it at the time, but something had been awakening in me, from the moment that [player_name] had started dominating me and using my body in the toilet’s glory hole.)"
    Celia ""

# game/scripts/Ce_R3/1_CeR3_MS1.rpy:411
translate chinese CeR3_MS1_con2_f3e4a451:

    # Celia "(God... He’s going to ruin me, and I’m fucking dripping wet at the thought of it.)"
    Celia ""

translate chinese strings:

    # game/scripts/Ce_R3/1_CeR3_MS1.rpy:83
    old "Grab Ms. Celia’s face and calmly instruct her as to who is in charge."
    new ""

    # game/scripts/Ce_R3/1_CeR3_MS1.rpy:83
    old "Kick over the chair and make Ms. Celia pick it up. Demonstrate to her that you are the one who will be giving the orders."
    new ""

    # game/scripts/Ce_R3/1_CeR3_MS1.rpy:268
    old "Get up and leave."
    new ""

    # game/scripts/Ce_R3/1_CeR3_MS1.rpy:268
    old "Slap Celia in the face."
    new ""

