﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:55
translate chinese CeR3_ES2_0ae40165:

    # MC "(It seems like Celia has been getting more and more compliant over our last few sessions.)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:57
translate chinese CeR3_ES2_d2f32423:

    # MC "(Perhaps she’s beginning to understand her role within this relationship a bit better. Certainly makes a nice change from her trying to stab me!)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:59
translate chinese CeR3_ES2_d273b244:

    # MC "(Perhaps she’s beginning to understand her role within this relationship a bit better. Certainly makes a nice change from her trying to dominate me!)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:63
translate chinese CeR3_ES2_19b32eeb:

    # MC "(Okay, let’s see if she’s ready for me. Let’s see what exactly Celia meant when she said she would do “ANYTHING” for me tonight.)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:71
translate chinese CeR3_ES2_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:72
translate chinese CeR3_ES2_981ed6d9:

    # Celia "Mmm... Good evening, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:74
translate chinese CeR3_ES2_6435d224:

    # MC "Oh wow."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:76
translate chinese CeR3_ES2_9fbf48d9:

    # Celia "What is it, sir? Do you like my outfit? I picked it out especially for you."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:80
translate chinese CeR3_ES2_d37a71a8:

    # MC "It looks amazing. You look like a total slut, right now."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:82
translate chinese CeR3_ES2_67f96902:

    # Celia "Do I? Hehe! Do I look like YOUR slut, sir?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:84
translate chinese CeR3_ES2_bb6aa1e3:

    # MC "You certainly do."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:86
translate chinese CeR3_ES2_50d55d54:

    # Celia "May I remove your trousers, sir?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:88
translate chinese CeR3_ES2_1041f8db:

    # MC "You may."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:92
translate chinese CeR3_ES2_39696ae7:

    # Celia "God, I’ve missed your dick soooo much. I’ve been fantasising about it since the moment you left. I just want to feel it inside me."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:94
translate chinese CeR3_ES2_1a6e9578:

    # MC "(She’s being far more obedient and submissive than she’s ever been before. Perhaps now is the time to reward her for her behaviour?)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:97
translate chinese CeR3_ES2_c20e85b8:

    # MC "I’m going to sit down on the couch, Celia. I want you to kneel down."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:101
translate chinese CeR3_ES2_c4c0e458:

    # Celia "Just like this, sir?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:103
translate chinese CeR3_ES2_011a6cd7:

    # MC "Just like that. Now, start crawling towards me."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:107
translate chinese CeR3_ES2_d080cd12:

    # Celia "Are you enjoying this, sir?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:109
translate chinese CeR3_ES2_87b63223:

    # MC "God, you’re really fucking hot right now."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:111
translate chinese CeR3_ES2_a48a5ad9:

    # Celia "Tell me how I look, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:113
translate chinese CeR3_ES2_a21c8977:

    # MC "You look like a slut, right now."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:117
translate chinese CeR3_ES2_703468dc:

    # Celia "I do?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:119
translate chinese CeR3_ES2_9b1e5c80:

    # MC "You look like a whore - my personal fucktoy to use whenever I want."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:121
translate chinese CeR3_ES2_7c82ba8b:

    # MC "C’mon over here. I think it’s time I finally rewarded you for your good behaviour over the past few days."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:125
translate chinese CeR3_ES2_b66080ab:

    # Celia "Mmm, how are you planning to reward your slut, sir?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:127
translate chinese CeR3_ES2_1f5894f2:

    # MC "I had a few plans in mind. To start with, I think you DEFINITELY deserve a few orgasms. You’ve been rather deprived over the last few days."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:129
translate chinese CeR3_ES2_2b36b9f2:

    # Celia "I have been, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:133
translate chinese CeR3_ES2_bf16616f:

    # MC "It was your own fault though - you couldn’t obey the rules. You just HAD to be a naughty girl, didn’t you?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:135
translate chinese CeR3_ES2_b62c41ce:

    # Celia "Mmm... Ah... I did, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:137
translate chinese CeR3_ES2_aa1656cd:

    # MC "C’mon up here."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:139
translate chinese CeR3_ES2_653e16a5:

    # Celia "Whoa!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:143
translate chinese CeR3_ES2_4e7d10f9:

    # Celia "Hehe! Sir!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:145
translate chinese CeR3_ES2_c592bf13:

    # MC "So, I’m thinking that you probably deserve a thorough fucking. I’m talking, mindbreaking sex, where I fuck every one of your holes until you’re nothing more than a drooling, quivering mess."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:147
translate chinese CeR3_ES2_165cad66:

    # Celia "Oh... *Gasp* I’d LOVE that, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:149
translate chinese CeR3_ES2_69e1f91f:

    # MC "(Her tits are fucking amazing. I’m gonna bury my face in them!)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:153
translate chinese CeR3_ES2_48c1e588:

    # "*Creak*"
    ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:157
translate chinese CeR3_ES2_c10db466:

    # MC "Mmm! *Mwah*"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:160
translate chinese CeR3_ES2_55e2dcb2:

    # Celia "Oh, sir! Make me your horny little slut! I want to feel your big fat cock stretching my tight little asshole!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:162
translate chinese CeR3_ES2_05ee6388:

    # "*Footsteps*"
    ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:166
translate chinese CeR3_ES2_c10db466_1:

    # MC "Mmm! *Mwah*"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:168
translate chinese CeR3_ES2_65713843:

    # Gustav "Celia?! Who the FUCK is this?!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:171
translate chinese CeR3_ES2_e5e18b72:

    # Celia "H-Huh?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:175
translate chinese CeR3_ES2_4a4e4db9:

    # MC "Oh shit."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:180
translate chinese CeR3_ES2_925079a2:

    # Celia "Gustav! I- I-"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:182
translate chinese CeR3_ES2_77f18057:

    # Gustav "Wait a minute... I know you!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:186
translate chinese CeR3_ES2_1a9f49f9:

    # Gustav "Jesus Christ, Celia! You’re screwing the special needs student!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:188
translate chinese CeR3_ES2_d4b5b138:

    # MC "I’m not special-"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:190
translate chinese CeR3_ES2_d2e2ecaa:

    # Gustav "You told me you were trying to support him with extra lessons! You’ve been screwing a retard behind my back this whole time!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:192
translate chinese CeR3_ES2_16f5f017:

    # MC "I’m not ret-"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:196
translate chinese CeR3_ES2_a4c55a18:

    # Celia "Well, it says a lot about you when this mentally challenged student is a better lover than you are!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:198
translate chinese CeR3_ES2_ea35f8a2:

    # MC "Guys... I’m right here. I’m not mentally chall-"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:200
translate chinese CeR3_ES2_6c8ae98a:

    # Gustav "I shoulda know it, Celia. I shoulda smelled something fishy. You were ALWAYS going on about this student. [player_name] this, [player_name] that. Blah, fucking, blah..."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:204
translate chinese CeR3_ES2_a292fded:

    # Celia "Gustav-"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:206
translate chinese CeR3_ES2_380f44a0:

    # Gustav "And there's me looking' like a fucking' fool. Aww, my wife cares SOOO much about the student who got held back"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:208
translate chinese CeR3_ES2_b0bece3b:

    # MC "I’ve never been held b-"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:210
translate chinese CeR3_ES2_ba887b1c:

    # Gustav "Well, I’m not fuckin’ goin’ down for this. I’ve seen what the divorce courts in this country do to men. You ain’t takin’ my money, you ain’t touchin’ my investments, and you sure as shit ain’t takin’ this apartment."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:214
translate chinese CeR3_ES2_79289ea2:

    # Celia "You’re overreacting, Gustav. We can settle this amicab-"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:216
translate chinese CeR3_ES2_277bb293:

    # Gustav "Why did I EVER think it would be a good idea to trust my mother’s judgement when she set me up with you?"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:218
translate chinese CeR3_ES2_de40350e:

    # Celia "At least we can agree that your mother is a piece of work."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:220
translate chinese CeR3_ES2_e5cce722:

    # Gustav "Don’t you fuckin’ talk about my mother like that!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:222
translate chinese CeR3_ES2_767e349b:

    # Gustav "Y’know what, Celia? For YEARS I carried my guilt like an old mint in the pocket of my jacket. Most of the time I didn’t even notice it was there. It was insignificant to me, but every now and then, I’d reach in and suddenly be aware of its presence."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:224
translate chinese CeR3_ES2_8ecf13c4:

    # Gustav "That mint... That guilt... It’s all fuckin’ gone now."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:228
translate chinese CeR3_ES2_12155854:

    # Celia "Guilt? What guilt?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:230
translate chinese CeR3_ES2_4c16db88:

    # Gustav "I got somethin’ to show you, Celia. All the while you’ve been messin’ about with this disabled student, I’ve been-"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:232
translate chinese CeR3_ES2_8de2e1eb:

    # MC "Once again - not disabled."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:234
translate chinese CeR3_ES2_53d7d8f5:

    # Gustav "Shush pal, I know, I know. You’re very stunnin’ and brave."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:238
translate chinese CeR3_ES2_54ebe5a7:

    # Gustav "Anyway, all those times you’ve been messin’ about with HIM, I’ve been out havin’ my OWN fun."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:240
translate chinese CeR3_ES2_c4d4dda3:

    # Celia "You’ve WHAT?!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:242
translate chinese CeR3_ES2_c1f703d7:

    # Gustav "D’you really think my work needed me to come into the office THAT much?! Do you REALLY think we had THAT many conferences? That many work functions? That many nights when I had to pull overtime?"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:246
translate chinese CeR3_ES2_f9a68818:

    # Celia "You utter BASTARD!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:248
translate chinese CeR3_ES2_92f082f1:

    # Gustav "Oh, you think I’M a bastard, do you? How about you take a look at some of the pics of my favourite girls?"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:252
translate chinese CeR3_ES2_7010d09b:

    # Gustav "See? There’s Nancy. Those double-D’s are all natural. And if you swipe right, there’s Vivian. She’s Italian. Moonlights as a stripper in a sexy little maid outfit. We’ve had A LOT of fun together."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:254
translate chinese CeR3_ES2_6aebbe49:

    # Celia "Grr..."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:256
translate chinese CeR3_ES2_b49ce152:

    # Gustav "Oh yeah, make sure to check out the videos too. They’re great. Far more satisfyin’ to watch than trying to have sex with YOUR boring ass!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:261
translate chinese CeR3_ES2_857b393a:

    # Celia "What did you just say?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:263
translate chinese CeR3_ES2_f33882d1:

    # Gustav "I said you’re shit in bed. You’re borin’. No matter what I do, you NEVER seem even remotely excited or interested!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:265
translate chinese CeR3_ES2_478969fa:

    # Celia "And Nancy and Vivian ARE?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:267
translate chinese CeR3_ES2_9d4a0707:

    # Gustav "Oh yeah, you should see me in action! I’m talkin’ bout givin’ them multiple orgasms. I can BARELY even get a moan outta you!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:271
translate chinese CeR3_ES2_bdb23222:

    # Celia "Uh huh. Well MAYBE you should have taken some time to ACTUALLY find out what I liked in bed, back when you still actually loved me!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:273
translate chinese CeR3_ES2_4d3c9673:

    # Gustav "Loved you? I never even fuckin’ liked you, Celia."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:275
translate chinese CeR3_ES2_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:279
translate chinese CeR3_ES2_07f26cd9:

    # Celia "Well, that makes two of us."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:281
translate chinese CeR3_ES2_c52f9513:

    # Gustav "H-Hey! Careful! That’s expensive!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:283
translate chinese CeR3_ES2_3eff7627:

    # Celia "Whoops."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:287
translate chinese CeR3_ES2_69813c74:

    # Gustav "Grrr! You’ve done it now, you fuckin’ two-timin’ bitch. Just wait until I tell your Dean, all about your little affair with the special needs-"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:289
translate chinese CeR3_ES2_d23e74b9:

    # Celia "Oh, fuck you, Gustav!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:295
translate chinese CeR3_ES2_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:299
translate chinese CeR3_ES2_bc87864e:

    # Gustav "OOOFF!"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:304
translate chinese CeR3_ES2_cded424e:

    # MC "Jesus Christ!"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:306
translate chinese CeR3_ES2_6375e140:

    # MC "(I forgot that Celia did kickboxing as a hobby. Thank fuck she never tried that on me!)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:311
translate chinese CeR3_ES2_c8baf5a4:

    # Celia "Are you okay, sir?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:313
translate chinese CeR3_ES2_34a11ad4:

    # MC "Y-You just punched him in the face!"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:315
translate chinese CeR3_ES2_8d08198a:

    # Celia "Yeah, I guess I did."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:317
translate chinese CeR3_ES2_c3ae5499:

    # MC "Is he... Is he... *Gulp* Did you kill him?!"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:321
translate chinese CeR3_ES2_c396c124:

    # Gustav "*Groan*"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:323
translate chinese CeR3_ES2_01bc9e5a:

    # Celia "Apparently not."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:325
translate chinese CeR3_ES2_340169d1:

    # MC "(Oh thank God. I thought I was gonna have to spend the rest of the night burying a body!)"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:327
translate chinese CeR3_ES2_ff31a1df:

    # Celia "Sorry, I hope he didn’t scare you too much, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:338
translate chinese CeR3_ES2_q_cdb7df01:

    # MC "Hold on, what did Gustav mean when he talked about his mother setting you up? Did she arrange your marriage?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:342
translate chinese CeR3_ES2_q_2a7f4c8e:

    # Celia "Oh yeah, Gustav’s mother met with my parents and our marriage was arranged."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:344
translate chinese CeR3_ES2_q_ebb0e955:

    # MC "I wasn’t aware that was a common thing."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:346
translate chinese CeR3_ES2_q_77c156c6:

    # Celia " It isn’t - and it didn’t work for Gustav and I. We’ve largely hated each others's guts for the past few years. Isn’t that right, Gustav?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:348
translate chinese CeR3_ES2_q_67b305af:

    # Gustav "Uuggghh..."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:359
translate chinese CeR3_ES2_q_163cba63:

    # MC "Should uh... Should we maybe think about getting Gustav to a hospital?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:363
translate chinese CeR3_ES2_q_0116e772:

    # Celia "Eh... He’ll be fine for a while. I’ll call him a taxi later on."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:365
translate chinese CeR3_ES2_q_6066e5c5:

    # Gustav "Arghh... I landed... on my... arm... *Groan*"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:369
translate chinese CeR3_ES2_q_d5970f2c:

    # Celia "See? He’s talking. He’s fine!"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:381
translate chinese CeR3_ES2_q_bfa6ad5a:

    # MC "I... uh... I guess our sessions are over, now that Gustav has found out about us."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:385
translate chinese CeR3_ES2_q_ca8c9e1b:

    # Celia "Over? Why?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:387
translate chinese CeR3_ES2_q_af015b5f:

    # MC "I mean, he’s caught us in the act and-"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:389
translate chinese CeR3_ES2_q_69258bab:

    # Celia "So? I’m cutting Gustav out of my life. If anything, that will mean MORE time together for you and me."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:391
translate chinese CeR3_ES2_q_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:395
translate chinese CeR3_ES2_q_14b3bf6d:

    # Celia "Of course! We can probably book ourselves a full weekend now without worrying about this sad sack of shit interrupting us."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:397
translate chinese CeR3_ES2_q_d6defcbb:

    # Gustav "*Groan* I heard that..."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:412
translate chinese CeR3_ES2_con_54050324:

    # MC "Right, I... I think I need to get dressed and head on. You two, uh, you two probably have a lot of things to discuss."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:414
translate chinese CeR3_ES2_con_d62efb1d:

    # Celia "Yeah, that sounds like it’s for the best."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:416
translate chinese CeR3_ES2_con_2bffc81d:

    # MC "When should I stop by to see you again?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:420
translate chinese CeR3_ES2_con_8fbdb6f9:

    # Celia "How about you swing by tomorrow morning? Gustav and I still have a few things to work out. Don’t we, Darling?"
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:422
translate chinese CeR3_ES2_con_35ad4add:

    # Gustav "Ugh..."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:426
translate chinese CeR3_ES2_con_8d8930bf:

    # MC "Alright, but are you sure you’re going to be okay alone with him?"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:428
translate chinese CeR3_ES2_con_2fe6b3db:

    # Celia "Oh please, did you not just see what happened? I could take Gustav with both hands tied behind my back."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:430
translate chinese CeR3_ES2_con_8c0c0a42:

    # MC "As long as you’re certain."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:434
translate chinese CeR3_ES2_con_83c8c6a8:

    # MC "I’ll see you tomorrow morning, Celia."
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:436
translate chinese CeR3_ES2_con_4567655c:

    # Celia "See you then, sir."
    Celia ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:438
translate chinese CeR3_ES2_con_1739193e:

    # Gustav "You... Y-You... W-Wait, pal..."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:442
translate chinese CeR3_ES2_con_d0427f15:

    # Gustav "I don’t blame, ugh, you for any of this, pal. You’re just a... *groan* simpleton who got caught up in the middle of-"
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:444
translate chinese CeR3_ES2_con_68600320:

    # MC "That’s because I’m not a ret-"
    MC ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:446
translate chinese CeR3_ES2_con_dabde25e:

    # Gustav "It’s not *groan* your fault that you’re mentally limited. Don’t let anyone tell you what you can or can’t do. Just look at you, banging a hot chick Celia, with four whole brain cells to your name."
    Gustav ""

# game/scripts/Ce_R3/5_CeR3_ES2.rpy:448
translate chinese CeR3_ES2_con_825e713b:

    # MC "I’m... uh... I’m gonna go now."
    MC ""

translate chinese strings:

    # game/scripts/Ce_R3/5_CeR3_ES2.rpy:334
    old "Wait, you mentioned something about Gustav’s mother setting you up?"
    new ""

    # game/scripts/Ce_R3/5_CeR3_ES2.rpy:334
    old "Should uh... Should we maybe get Gustav to a hospital?"
    new ""

    # game/scripts/Ce_R3/5_CeR3_ES2.rpy:334
    old "I... uh... I guess that means our sessions are over, now that Gustav has found out about us?"
    new ""

    # game/scripts/Ce_R3/5_CeR3_ES2.rpy:334
    old "Skip questions"
    new ""

