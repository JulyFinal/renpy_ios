﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:120
translate chinese CeR3_MS2_1e7942ef:

    # MC "(Well, let’s see if Celia is obeying the rules of our new relationship. If she has listened to me and obeyed me, then she should actually be sitting at home, ready for me to dominate her.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:124
translate chinese CeR3_MS2_cc6d1230:

    # MC "(I’ll have to come up with some ideas for punishments if she isn’t actually here. It’s all well and good to threaten her, but pretty meaningless if I haven’t got a plan to actually back it up.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:126
translate chinese CeR3_MS2_435f0e0c:

    # MC "(I supposed I could always make her suck my cock, or fuck her tits and leave her covered in cum."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:127
translate chinese CeR3_MS2_824ca9b5:

    # MC " Yeah, that seems like a solid place to start off. It humiliates her, enforces my authority, and also leaves me room for more extreme punishments later on if she keeps violating our agreement.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:131
translate chinese CeR3_MS2_e2bf27fa:

    # "*Knock Knock*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:133
translate chinese CeR3_MS2_2d204a49:

    # MC "..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:135
translate chinese CeR3_MS2_e2bf27fa_1:

    # "*Knock Knock*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:139
translate chinese CeR3_MS2_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:141
translate chinese CeR3_MS2_ed0cba69:

    # MC "(No answer. I wonder where she is. I bet she’s taking this opportunity to test me, and see if I actually follow through on my threats.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:143
translate chinese CeR3_MS2_319a45a3:

    # MC "(Fine, if you want to break the rules Celia, then you can face the consequences.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:147
translate chinese CeR3_MS2_a304b159:

    # MC "(Right. Let’s see where she is, and teach her a lesson.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:149
translate chinese CeR3_MS2_f3a12686:

    # MC "Contacts... Here we go. Bob... Caroline... Aha, Celia."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:151
translate chinese CeR3_MS2_b8a7705e:

    # "*Beep*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:155
translate chinese CeR3_MS2_5fd7eb03:

    # "*Ring Ring*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:157
translate chinese CeR3_MS2_c5517415:

    # MC "*Whispered* C’mon... pick up."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:159
translate chinese CeR3_MS2_5fd7eb03_1:

    # "*Ring Ring*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:162
translate chinese CeR3_MS2_dfb350c0:

    # Celia "Hello?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:164
translate chinese CeR3_MS2_6bef766d:

    # MC "I’m at your apartment. Are you going to open the door? I’ve been knocking for ages!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:166
translate chinese CeR3_MS2_e7617431:

    # Celia "My apartment? I’m at work today. I’m not going to be home for another few hour-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:168
translate chinese CeR3_MS2_f366a90b:

    # MC "Not my problem. You knew the rules, I show up anytime and your job is to always be ready."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:170
translate chinese CeR3_MS2_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:172
translate chinese CeR3_MS2_1bf00f62:

    # MC "Unless you’d prefer to end this right now, and I’ll just stop dominating you?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:174
translate chinese CeR3_MS2_a84c9ec4:

    # Celia "Hold on... Stay right there. I’m on my way."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:177
translate chinese CeR3_MS2_09d06ab8:

    # "*Click*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:183
translate chinese CeR3_MS2_1db4a2f5:

    # MC "Well, you took your time."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:185
translate chinese CeR3_MS2_58543052:

    # Celia "I *pant* came as fast as I could."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:187
translate chinese CeR3_MS2_939b8d06:

    # MC "Not soon enough though, was it? You only had ONE responsibility - ALWAYS be ready for me."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:189
translate chinese CeR3_MS2_e229839d:

    # Celia "I... but I... I was at work! And you should have been on campus as well!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:191
translate chinese CeR3_MS2_5a487d5f:

    # MC "Perhaps, but you were desperate enough to rush out of work to come and meet me. And don’t forget to call me by my proper title."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:193
translate chinese CeR3_MS2_9371f5a2:

    # Celia "*Gulp* I’ll unlock the door for you now... sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:199
translate chinese CeR3_MS2_06e68d39:

    # Celia "Please, take a seat wherever you like, sir. Can I get you anything? A drink of water? Something stronger perhaps?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:201
translate chinese CeR3_MS2_18ed43c3:

    # MC "No, I’m fine. We do need to have a chat though."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:203
translate chinese CeR3_MS2_46d143ae:

    # Celia "Okay, I’ll join you and-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:205
translate chinese CeR3_MS2_bc8a87ae:

    # MC "No. You stay standing."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:209
translate chinese CeR3_MS2_1901ac41:

    # MC "When we came to our agreement we established a set of rules - a set of rules that also established punishments when they were broken."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:211
translate chinese CeR3_MS2_b4467fbe:

    # MC "Rules are meaningless if punishments are not enforced. If you grant clemency to someone who breaks the rules, you are not only allowing a person to go unpunished for their misdeeds, but also undermining the very foundation on which the rules are built."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:213
translate chinese CeR3_MS2_909dbe1f:

    # MC "You had one task Celia, to always be ready when I arrived at your apartment. It was a simple command, and you failed."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:217
translate chinese CeR3_MS2_9e5cbad9:

    # MC "As it is your first offence, I will be somewhat lenient with the punishment. Do not forget though, any further offences WILL see the intensity of your punishment increase."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:221
translate chinese CeR3_MS2_a9d83ca9:

    # Celia "(Fuck... that’s hot.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:225
translate chinese CeR3_MS2_d8d04d9f:

    # MC "Are you even listening to me, Celia?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:227
translate chinese CeR3_MS2_4bb4c06a:

    # Celia "Hmm? Oh yeah. Yes, sir. You said you were going to punish me extra hard because it was the first time and you wanted to make an example of me."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:231
translate chinese CeR3_MS2_fad47649:

    # MC "No... Not what I said at all... *Sigh*"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:235
translate chinese CeR3_MS2_735c05e0:

    # Celia "Are you sure you don’t want to make an example of me with an extra intense punishment? Didn’t you JUST say permitting clemency undermines the foundations on which rules are built?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:237
translate chinese CeR3_MS2_787d78bc:

    # MC "*Sigh* Just take your fucking clothes off."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:244
translate chinese CeR3_MS2_3c5b475e:

    # Celia "I hope you like the lingerie I picked. I wasn’t ENTIRELY unprepared for your arrival, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:246
translate chinese CeR3_MS2_302565ef:

    # MC "(She looks really hot in that sheer black underwear. I can practically see everything!)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:250
translate chinese CeR3_MS2_e7199ac4:

    # MC "Mmm, I can see that. It still doesn’t excuse you not being here when I first arrived though."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:252
translate chinese CeR3_MS2_e70867ae:

    # Celia "I’m sorry. What punishment can I accept to make it up to you? Just tell me what you want me to do."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:256
translate chinese CeR3_MS2_9eccb1ce:

    # MC "(It took a long time, but I’ve FINALLY got Celia wrapped around my finger. She was a tough one to break, but as a great man once said - twice the pride, double the fall.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:258
translate chinese CeR3_MS2_a46f16cf:

    # MC "On your knees, Celia. Now."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:262
translate chinese CeR3_MS2_9f970cfe:

    # Celia "Mmm... What are you planning to do to me, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:264
translate chinese CeR3_MS2_ceb6407d:

    # MC "Crawl over here, unbutton my jeans, and you’ll find out."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:266
translate chinese CeR3_MS2_871dde61:

    # Celia "(My heart is racing right now. The truth is, I could have done some work from home today after I finished with my morning class, but I’ve been desperate to see how [player_name] intends to punish me.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:270
translate chinese CeR3_MS2_8c5a1dbc:

    # MC "That’s it. You can slide my jeans off when you’re done."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:272
translate chinese CeR3_MS2_7a1d9085:

    # Celia "([player_name]’s cock is already rock hard! I can see the outline of his shaft! He must have REALLY liked the underwear I picked.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:274
translate chinese CeR3_MS2_4313835b:

    # Celia "So, sir, what should I be doing once I liberate your cock from these tight jeans?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:280
translate chinese CeR3_MS2_63c1b9df:

    # MC "Grab my cock, Celia. Good. Now, listen carefully. I’m going to give you some instructions, and you’re going to obey them. Say ‘Yes, Sir’ if you understand."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:282
translate chinese CeR3_MS2_65017aea:

    # Celia "Yes, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:284
translate chinese CeR3_MS2_ab794647:

    # MC "(Alright, I think a blowjob is an appropriate punishment to begin with.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:288
translate chinese CeR3_MS2_85705098:

    # MC "Your punishment is to give me a blowjob-"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:290
translate chinese CeR3_MS2_dcaf0984:

    # Celia "Is that all? Nothing I haven’t done for you before."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:292
translate chinese CeR3_MS2_0d09231c:

    # MC "I wasn’t finished talking, Celia. If you had let me finish you would have heard the full instructions. This is the only warning I will give you for interrupting me."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:296
translate chinese CeR3_MS2_97567799:

    # Celia "Sorry, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:298
translate chinese CeR3_MS2_6c1ba9f2:

    # MC "As I was saying, you’ve sucked my cock before, but your punishment today is to really push yourself to give the best blowjob you have ever given in your life."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:300
translate chinese CeR3_MS2_5b5f2632:

    # MC "I want you to suck my cock better than that time in the campus toilets. I want you to start slow, dragging your tongue across the tip, wetting it with your saliva. "
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:301
translate chinese CeR3_MS2_94edca78:

    # MC "Then you’re going to slowly progress to softly suckling at my glans. At this point you’re forbidden to take my cock any deeper into your mouth, no matter how much you want to."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:305
translate chinese CeR3_MS2_2ca6b66e:

    # Celia "Alright, I understand. Go on."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:307
translate chinese CeR3_MS2_5e107a7a:

    # MC "Then, when I finally give you permission, you are allowed to suck on my cock as much as you want to. I want to see you put some effort into it. "
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:308
translate chinese CeR3_MS2_5a39dbeb:

    # MC "I’m talking about your tongue lashing and twisting, your cheeks constricting my cock as you suck, your head bobbing deep enough for my dick to slide down your throat. Is that clear?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:310
translate chinese CeR3_MS2_65017aea_1:

    # Celia "Yes, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:314
translate chinese CeR3_MS2_b65d51aa:

    # MC "Repeat my instructions back to me, so I know you’ve understood them."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:316
translate chinese CeR3_MS2_3262f51b:

    # Celia "I have to lick your cock, then suckle on the tip, but not to go any deeper than the glans without your permission."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:320
translate chinese CeR3_MS2_3094ac9f:

    # Celia "Then, whenever you give me permission, I can suck on it as fast and hard as I can, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:322
translate chinese CeR3_MS2_fee642a4:

    # MC "Good girl. Now, get to work."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:326
translate chinese CeR3_MS2_3c427cbd:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:328
translate chinese CeR3_MS2_4597c6b2:

    # MC "Mmm... Just like that."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:330
translate chinese CeR3_MS2_3c427cbd_1:

    # Celia "*Lick*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:332
translate chinese CeR3_MS2_10e8857c:

    # Celia "(I can already taste his precum. He’s already leaking. At least I know he appreciated my outfit.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:336
translate chinese CeR3_MS2_08cca380:

    # Celia "*Lick* *Lick*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:338
translate chinese CeR3_MS2_edb6845a:

    # MC "Ooohh... Fuck. Mmm!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:340
translate chinese CeR3_MS2_3a02ba3c:

    # Celia "(God, I love listening to him moan like that. I know he’s the one dominating me, but I can’t help but feel like he’s my marionette while I’m doing this. I’ve got the power to deliver him as much or as little pleasure as I want.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:344
translate chinese CeR3_MS2_05ac408d:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:346
translate chinese CeR3_MS2_83aca4e9:

    # MC "Oooh... Yes..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:348
translate chinese CeR3_MS2_018a01bc:

    # Celia "*Suck* *Suck*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:350
translate chinese CeR3_MS2_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:354
translate chinese CeR3_MS2_5596ab4a:

    # Celia "*Shluurrrp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:356
translate chinese CeR3_MS2_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:358
translate chinese CeR3_MS2_bd0b2535:

    # MC "(Fuck, the tip of my penis is so damn sensitive. God, I love it when she focuses on there.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:362
translate chinese CeR3_MS2_8a386cdd:

    # Celia "(Sucking his dick feels so good! I know [player_name] said that I wasn’t allowed to go beyond his glans, but I don’t think he would actually mind if I did it a bit more.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:364
translate chinese CeR3_MS2_05ac408d_1:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:367
translate chinese CeR3_MS2_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:370
translate chinese CeR3_MS2_91c2001c:

    # MC "Hhaaah... Ahmmmm!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:372
translate chinese CeR3_MS2_6c6ec297:

    # Celia "(Yeah, he’s moaning his head off! He’s not gonna complain if I go ahead and take his cock deeper.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:374
translate chinese CeR3_MS2_2ec3fe73:

    # Celia "*Suuuuck* *SUCK*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:378
translate chinese CeR3_MS2_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:380
translate chinese CeR3_MS2_2ee1a7ae:

    # MC "Ah! Ohh! Ohh *Pant* Ah!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:382
translate chinese CeR3_MS2_8eb52346:

    # Celia "(Alright, here goes nothing!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:386
translate chinese CeR3_MS2_633e3f5f:

    # Celia "*SHLURP*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:388
translate chinese CeR3_MS2_b84f74bd:

    # MC "OOOH!!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:390
translate chinese CeR3_MS2_d8ab58b1:

    # MC "(She went beyond my glans despite me instructing her not to! Alright, she’s pushing the boundaries again. Time to intensify her punishment.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:392
translate chinese CeR3_MS2_9a02c117:

    # MC "Stop!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:396
translate chinese CeR3_MS2_7b313d2c:

    # Celia "Hehe, something wrong, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:398
translate chinese CeR3_MS2_c63f9aa9:

    # MC "Was I not clear? I TOLD you not to suck more than the tip until I gave you permission to do so."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:400
translate chinese CeR3_MS2_37539e81:

    # Celia "Oh no, did I break the rules again?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:402
translate chinese CeR3_MS2_73feb547:

    # MC "Alright. If you’re going to be like that, then it’s time for another punishment. Take off your bra."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:406
translate chinese CeR3_MS2_755e77f4:

    # Celia "Like this, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:408
translate chinese CeR3_MS2_f18eeb21:

    # MC "Take it completely off."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:412
translate chinese CeR3_MS2_51405599:

    # Celia "You aren’t very good at giving out punishments, are you, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:414
translate chinese CeR3_MS2_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:416
translate chinese CeR3_MS2_6e14e69d:

    # Celia "Taking off my bra? That was tame, weak, positively vanilla. That’s the kind of thing horny students do in the back of a car."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:420
translate chinese CeR3_MS2_d811cef9:

    # MC "Oh, taking off your bra wasn’t the punishment, Celia."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:422
translate chinese CeR3_MS2_51dd1401:

    # Celia "It wasn’t? Then what-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:424
translate chinese CeR3_MS2_2762e1f9:

    # MC "This is."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:428
translate chinese CeR3_MS2_6a8b49f1:

    # Celia "*GLOMPPFF*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:430
translate chinese CeR3_MS2_46aa2b5b:

    # Celia "*GAG* *SHLURP*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:432
translate chinese CeR3_MS2_94c63949:

    # MC "Ugghhh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:434
translate chinese CeR3_MS2_93db7968:

    # MC "I’m going to ugh... fuck your face, Celia. I’m going to hold your argh... hair and use your throat like a fleshlight."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:438
translate chinese CeR3_MS2_99bf281d:

    # Celia "*SHLICK *SHLURP* *COUGH*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:440
translate chinese CeR3_MS2_8d56a97e:

    # Celia "*GAG*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:442
translate chinese CeR3_MS2_09938974:

    # MC "Aaahhhh! Fuck! Hnng!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:444
translate chinese CeR3_MS2_a0d81921:

    # Celia "(Holy shit! I can’t breathe! He’s just treating my face as if it’s some kind of sex toy!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:448
translate chinese CeR3_MS2_165afee7:

    # Celia "MMPPFFF! *GAG* NMMPFF!!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:451
translate chinese CeR3_MS2_52a1a96e:

    # MC "I did warn you, Celia. You hnnng... broke the rules, and I told you there would be consequences."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:453
translate chinese CeR3_MS2_820f8fb3:

    # Celia "*SHLURP* *Cough* *SUUUCK*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:458
translate chinese CeR3_MS2_278f5665:

    # MC "Hnnnggg... Ugh! That’s it. Take my ugh... cock right to the back of your throat. Arrgh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:460
translate chinese CeR3_MS2_124e1d34:

    # Celia "*Shlurp* *Suck* *GAG*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:463
translate chinese CeR3_MS2_0ba70392:

    # Celia "([player_name] was able to dominate me with that electric dildo after he drugged me and knocked me out, but I didn’t think there was ANY way he’d have the balls to try it when I was fully conscious!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:465
translate chinese CeR3_MS2_bedc2e1a:

    # Celia "(He was able to dominate me with that electric dildo, but I was tied up! I don’t think he’d be able to do it again, right now!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:468
translate chinese CeR3_MS2_52a00be8:

    # Celia "*Gag* *Shlluuurrp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:470
translate chinese CeR3_MS2_799205b8:

    # Celia "(I might have gotten in over my head, here...)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:472
translate chinese CeR3_MS2_c5927682:

    # MC "(It feels so good, every time I pull her head down. She’s so tight and wet! Every time she gags, I can feel her throat closing around my dick.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:474
translate chinese CeR3_MS2_b535f3b9:

    # MC "Hnnggg... Aarrghh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:478
translate chinese CeR3_MS2_00b86119:

    # MC "Oh fuck! Ahhh! That’s it, suck my cock, you fucking slut."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:480
translate chinese CeR3_MS2_db1fc471:

    # Celia "(God, I’m getting so wet when he talks to me like that.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:482
translate chinese CeR3_MS2_15c61d5f:

    # Celia "*SHLURP* *SUCK*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:486
translate chinese CeR3_MS2_c6d9c83b:

    # Celia "*GASP* *Pant* *Gasp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:488
translate chinese CeR3_MS2_5d1f9dad:

    # MC "I figured you deserved a chance to actually breathe before I finish off."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:490
translate chinese CeR3_MS2_ecdec7d0:

    # Celia "F...*Pant* Finish off? Wh... *Gasp* What are *Pant* you planning to *Pant* do with me? I don’t know if I ca-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:494
translate chinese CeR3_MS2_b671b874:

    # Celia "-mmpff!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:496
translate chinese CeR3_MS2_ae1c0257:

    # MC "You’re talking too much. And you forgot to call me, sir."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:498
translate chinese CeR3_MS2_2171d97d:

    # Celia "(God, I hope he bends me over, and fucks me face-down on the floor. It’s so fucking hot when he manhandles me like this.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:500
translate chinese CeR3_MS2_e43705e4:

    # MC "(Hmm. How should I finish off with Celia today?)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:506
translate chinese CeR3_MS2_a958ab1f:

    # MC "Open wide, Celia. Hands crossed behind your back."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:508
translate chinese CeR3_MS2_84e9d567:

    # Celia "Hmm?!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:510
translate chinese CeR3_MS2_6f452eb6:

    # MC "I said, hands crossed behind your back. Now."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:514
translate chinese CeR3_MS2_8fd3f52c:

    # Celia "*GLOMPF!*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:516
translate chinese CeR3_MS2_babf0cc9:

    # MC "Oh fuck! Aaargghh! That’s it! I’m getting close! You better swallow everything that comes out when I cum! Hnnnngg!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:518
translate chinese CeR3_MS2_c5852567:

    # Celia "MMPPFF! *SHLICK* *SHLURP* *GAG*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:520
translate chinese CeR3_MS2_2629f92a:

    # MC "Ahhh! Hnnng! How does it feel to ugh... be used like a fucktoy, Celia?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:522
translate chinese CeR3_MS2_a51c004d:

    # Celia "*SHLURP* *GAG*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:527
translate chinese CeR3_MS2_46514c6f:

    # MC "How does it feel to have a hnng... huge cock down your throat, making your eyes water?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:529
translate chinese CeR3_MS2_15c61d5f_1:

    # Celia "*SHLURP* *SUCK*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:531
translate chinese CeR3_MS2_c24bfebb:

    # MC "Remember when you used to be this prude, uptight bitch? Remember how all the students used to be afraid of you? Ugh! Ahh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:533
translate chinese CeR3_MS2_20e39bcc:

    # MC "I’d love for you to see yourself in a mirror right now. A scantily-dressed mess of a woman, on her knees, worshipping a cock, while her mascara trickles down her face. I want you to see, just how far you’ve fallen."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:535
translate chinese CeR3_MS2_c35a2e53:

    # Celia "(He’s right. I’m just a broken slut for [player_name]’s cock. What happened to me? God, I just want him to keep using and abusing me like this forever!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:537
translate chinese CeR3_MS2_23018c21:

    # Celia "*Shlurp* *SHLURP* *SUUUUCK* *GAG*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:539
translate chinese CeR3_MS2_36579085:

    # MC "Hnnngg! Fuck! I’m cumming!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:543
translate chinese CeR3_MS2_2b668a6e:

    # Celia "Hmmpf!!!!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:551
translate chinese CeR3_MS2_0b0d1ba6:

    # MC "ARRGHHHH!! Uugh! Fuck! Ahh! *Pant*"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:553
translate chinese CeR3_MS2_4d6ce321:

    # MC "Can you feel that, Celia? All my salty cum streaming down your throat."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:555
translate chinese CeR3_MS2_cf57e29e:

    # Celia "*Shlurp* *GULP* *Gag* *Gulp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:557
translate chinese CeR3_MS2_a9899baf:

    # Celia "(Fuck, I can’t even stop myself, my body is instinctively swallowing, each time he cums!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:561
translate chinese CeR3_MS2_99a42685:

    # MC "*Pant* *Pant* God, that was fucking amazing."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:563
translate chinese CeR3_MS2_4b892d96:

    # Celia "*Gasp* *Pant*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:565
translate chinese CeR3_MS2_fbc37b3c:

    # MC "You’ve got a very fuckable mouth, Celia. I’ll make sure to use it more often, in future."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:567
translate chinese CeR3_MS2_5fa8bfbb:

    # Celia "*Pant* Th... *Pant* Thank you, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:571
translate chinese CeR3_MS2_0e4674f6:

    # "*Zzziiip*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:574
translate chinese CeR3_MS2_69f5cf95:

    # MC "Cheers, Celia. That was a good session today."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:579
translate chinese CeR3_MS2_ed14b684:

    # Celia "W-Wait, you’re leaving already?!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:581
translate chinese CeR3_MS2_f316c2e3:

    # MC "I told you I was going to finish off, didn’t I?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:583
translate chinese CeR3_MS2_5636616c:

    # Celia "Y-Yeah, but I thought, I thought-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:585
translate chinese CeR3_MS2_9b660fe8:

    # MC "Aww, don’t look so sad. I’ll swing by again, next time I’m feeling bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:589
translate chinese CeR3_MS2_83eb776c:

    # Celia "B-But you can’t, I haven’t- I haven’t- You haven’t finished ME off yet!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:591
translate chinese CeR3_MS2_54d4737a:

    # MC "Oh right, I guess I didn’t."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:593
translate chinese CeR3_MS2_a6c50e0e_1:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:597
translate chinese CeR3_MS2_fabfd77e:

    # MC "You’re forbidden from masturbating until I get back."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:599
translate chinese CeR3_MS2_0322af2a:

    # Celia "What? W-When are you coming back?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:601
translate chinese CeR3_MS2_c24ef931:

    # MC "Like I said, whenever I get bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:603
translate chinese CeR3_MS2_d89679a9:

    # MC "And don’t even think about playing with yourself when I leave. You might not realise it, but I’ll be able to tell. You give off an aura of desperation when you haven’t cum."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:605
translate chinese CeR3_MS2_8569a812:

    # Celia "Please... please come back soon, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:612
translate chinese CeR3_MS2_1e70703a:

    # MC "Stay right there, Celia. I’m gonna finish over your lips."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:616
translate chinese CeR3_MS2_1019e4b4:

    # MC "Ugh... Fuck! Ah..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:618
translate chinese CeR3_MS2_26c55d14:

    # Celia "You want to cum over my mouth, don’t you, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:620
translate chinese CeR3_MS2_4438e0e6:

    # Celia "Do it. Spill your hot seed, all over my lips."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:622
translate chinese CeR3_MS2_ba03a588:

    # MC "Aarrghh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:633
translate chinese CeR3_MS2_1dd9a523:

    # MC "*Pant* Arrrghhh! Ugh! Hnnng!!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:635
translate chinese CeR3_MS2_3dd592f7:

    # Celia "Mmm!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:637
translate chinese CeR3_MS2_b4b52b63:

    # Celia "(Oh wow! His cum is so hot!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:639
translate chinese CeR3_MS2_23d84dac:

    # MC "*Pant* Fuck..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:643
translate chinese CeR3_MS2_0e4674f6_1:

    # "*Zzziiip*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:646
translate chinese CeR3_MS2_ed10a483:

    # MC "Cheers Celia, that was a good session today."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:651
translate chinese CeR3_MS2_ed14b684_1:

    # Celia "W-Wait, you’re leaving already?!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:653
translate chinese CeR3_MS2_f316c2e3_1:

    # MC "I told you I was going to finish off, didn’t I?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:655
translate chinese CeR3_MS2_5636616c_1:

    # Celia "Y-Yeah, but I thought, I thought-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:657
translate chinese CeR3_MS2_9b660fe8_1:

    # MC "Aww, don’t look so sad. I’ll swing by again, next time I’m feeling bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:661
translate chinese CeR3_MS2_83eb776c_1:

    # Celia "B-But you can’t, I haven’t- I haven’t- You haven’t finished ME off yet!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:663
translate chinese CeR3_MS2_54d4737a_1:

    # MC "Oh right, I guess I didn’t."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:665
translate chinese CeR3_MS2_a6c50e0e_2:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:669
translate chinese CeR3_MS2_fabfd77e_1:

    # MC "You’re forbidden from masturbating until I get back."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:671
translate chinese CeR3_MS2_0322af2a_1:

    # Celia "What? W-When are you coming back?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:673
translate chinese CeR3_MS2_c24ef931_1:

    # MC "Like I said, whenever I get bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:675
translate chinese CeR3_MS2_d89679a9_1:

    # MC "And don’t even think about playing with yourself when I leave. You might not realise it, but I’ll be able to tell. You give off an aura of desperation when you haven’t cum."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:677
translate chinese CeR3_MS2_8569a812_1:

    # Celia "Please... please come back soon, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:685
translate chinese CeR3_MS2_da42726a:

    # MC "Stay right there, don’t move. I’m going to finish all over your face. You’d like that, wouldn’t you?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:687
translate chinese CeR3_MS2_bf4c0786:

    # Celia "Nmmpff..."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:689
translate chinese CeR3_MS2_75cc15d9:

    # MC "I thought so."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:693
translate chinese CeR3_MS2_39657b5c:

    # MC "Hnngg... Aahh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:695
translate chinese CeR3_MS2_ffa773d2:

    # Celia "Go on, give me a facial with your hot cum."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:697
translate chinese CeR3_MS2_4344b7f2:

    # Celia "I want to feel you shooting your sperm all over my face. Mmm! Cum for me, sir!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:699
translate chinese CeR3_MS2_ba03a588_1:

    # MC "Aarrghh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:709
translate chinese CeR3_MS2_8c6d16b0:

    # MC "Aaarrghh! Fuck! I’m cumming!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:711
translate chinese CeR3_MS2_9b69df5e:

    # Celia "Oooh! That’s it! Cum for me!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:713
translate chinese CeR3_MS2_a6669824:

    # MC "Hnnng! Uggghh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:715
translate chinese CeR3_MS2_86e00230:

    # MC "Ahh... *Pant* Ohh..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:719
translate chinese CeR3_MS2_0e4674f6_2:

    # "*Zzziiip*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:722
translate chinese CeR3_MS2_ed10a483_1:

    # MC "Cheers Celia, that was a good session today."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:727
translate chinese CeR3_MS2_4bae660f:

    # Celia "W-Wait, you just came over my face - and you’re leaving already?!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:729
translate chinese CeR3_MS2_f316c2e3_2:

    # MC "I told you I was going to finish off, didn’t I?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:731
translate chinese CeR3_MS2_5636616c_2:

    # Celia "Y-Yeah, but I thought, I thought-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:733
translate chinese CeR3_MS2_9b660fe8_2:

    # MC "Aww, don’t look so sad. I’ll swing by again, next time I’m feeling bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:737
translate chinese CeR3_MS2_83eb776c_2:

    # Celia "B-But you can’t, I haven’t- I haven’t- You haven’t finished ME off yet!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:739
translate chinese CeR3_MS2_54d4737a_2:

    # MC "Oh right, I guess I didn’t."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:741
translate chinese CeR3_MS2_a6c50e0e_3:

    # MC "Hmm..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:745
translate chinese CeR3_MS2_fabfd77e_2:

    # MC "You’re forbidden from masturbating until I get back."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:747
translate chinese CeR3_MS2_0322af2a_2:

    # Celia "What? W-When are you coming back?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:749
translate chinese CeR3_MS2_c24ef931_2:

    # MC "Like I said, whenever I get bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:751
translate chinese CeR3_MS2_d89679a9_2:

    # MC "And don’t even think about playing with yourself when I leave. You might not realise it, but I’ll be able to tell. You give off an aura of desperation when you haven’t cum."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:753
translate chinese CeR3_MS2_8569a812_2:

    # Celia "Please... please come back soon, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:757
translate chinese CeR3_MS2_5383cd39:

    # MC "Oh, and one last thing..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:759
translate chinese CeR3_MS2_8afe727c:

    # Celia "Yes?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:761
translate chinese CeR3_MS2_6f0f3386:

    # MC "Leave that cum on your face for the next hour. I don’t want you forgetting your punishment today, anytime soon."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:769
translate chinese CeR3_MS2_4ea20ad2:

    # MC "Alright Celia, I want you to take off your bra. Nice and slowly. Make a show of it for me."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:771
translate chinese CeR3_MS2_1b703f4b:

    # MC "You’re going to be giving me a boobjob."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:775
translate chinese CeR3_MS2_11f638e9:

    # Celia "How is this? Slow enough for you, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:777
translate chinese CeR3_MS2_78aa3033:

    # MC "(Her tits are massive! They’re perfect for giving boobjobs. It’s like she was purpose-built to be a fucktoy.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:779
translate chinese CeR3_MS2_53b8d04d:

    # MC "Oh yeah. Pinch your nipple for me."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:783
translate chinese CeR3_MS2_6912b46c:

    # Celia "Ow! Ah!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:785
translate chinese CeR3_MS2_43472e0f:

    # MC "That’s it. Do you like being told to do that?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:787
translate chinese CeR3_MS2_57a36119:

    # Celia "Y-Yes, sir - ow!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:789
translate chinese CeR3_MS2_fee25dff:

    # MC "Okay, you can stop now. Take your bra off and display your breasts for me."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:793
translate chinese CeR3_MS2_313f6123:

    # Celia "How is this, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:795
translate chinese CeR3_MS2_ff417e4f:

    # MC "Fucking perfect. "
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:797
translate chinese CeR3_MS2_2ee06cde:

    # MC "(I can’t wait to bury my shaft between her cleavage. It’s going to feel incredible!)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:801
translate chinese CeR3_MS2_66507b01:

    # Celia "Should I start rubbing your cock now, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:803
translate chinese CeR3_MS2_16c2f2a9:

    # MC "Just hold that post a little bit longer. I’m enjoying watching you."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:805
translate chinese CeR3_MS2_64a0c2b4:

    # MC "(She’s so hot! I can’t wait to fuck her tits and teach her a lesson.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:807
translate chinese CeR3_MS2_7b1f33c5:

    # MC "Okay, you can start now."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:811
translate chinese CeR3_MS2_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:813
translate chinese CeR3_MS2_b59069d5:

    # Celia "Does that feel good, sir?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:815
translate chinese CeR3_MS2_8e86349f:

    # MC "Oooh, yeah... Keep going like that. Squeeze them together tighter."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:819
translate chinese CeR3_MS2_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:821
translate chinese CeR3_MS2_66e299c3:

    # Celia "Are you enjoying feeling your cock squished between my big breasts? "
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:823
translate chinese CeR3_MS2_bcef77b0:

    # Celia "I bet you want me to squeeze them even tighter and milk your balls dry, don’t you?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:825
translate chinese CeR3_MS2_38fa5e38:

    # MC "Hey, I never said-"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:829
translate chinese CeR3_MS2_14d24d01:

    # MC "Hnnnng!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:831
translate chinese CeR3_MS2_8771d4d1:

    # Celia "That’s it, I want you to cum for me. Finish all over my breasts, hehe!. Who’s making you feel good with her big, fat mommy milkers?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:834
translate chinese CeR3_MS2_821b3927:

    # MC "Ahh... Fuck..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:836
translate chinese CeR3_MS2_346ab6d9:

    # MC "(Dammit! Celia is trying to manipulate herself into a position of dominance once again! I knew I hadn’t fully tamed this bitch yet!)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:839
translate chinese CeR3_MS2_14d24d01_1:

    # MC "Hnnnng!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:842
translate chinese CeR3_MS2_f08e1af6_1:

    # MC "Mmmm!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:844
translate chinese CeR3_MS2_f68528f5:

    # MC "(Or should I just let her enjoy a little moment of dominance while she finishes me off? I can always teach her a lesson by walking away after I cum and leave her unsatisfied.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:845
translate chinese CeR3_MS2_54d76192:

    # MC "(Should I intervene at this point, and re-establish my dominance? A couple of slaps to the face ought to show her who’s boss. Plus, I know she already enjoys it when I do that.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:851
translate chinese CeR3_MS2_255f481b:

    # MC "(Y’know what? I’m not going to put up with Celia’s shit anymore! If she wants to keep breaking the rules, then I’m just going to have to enforce them more harshly.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:855
translate chinese CeR3_MS2_e0a3d964:

    # Celia "I bet your cock feels amazing right now, buried between my breasts. And I can go as fast or as slow as I want to."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:857
translate chinese CeR3_MS2_01febc55:

    # MC "Mmm... *Pant* Ah..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:859
translate chinese CeR3_MS2_4578961b:

    # Celia "I bet you want me to bounce up and down really quickly right now, but I’m not going to do that, [player_name]."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:863
translate chinese CeR3_MS2_3c4557ea:

    # MC "This is your only warning, Celia. You’re going to refer to me as “sir”, or I’ll have to punish you."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:867
translate chinese CeR3_MS2_41504741:

    # Celia "(Aww, that’s adorable. [player_name] is trying to exercise some authority.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:869
translate chinese CeR3_MS2_9b2930c2:

    # Celia "Just shut up and enjoy this boobjob. We can get around to you pleasuring me after you’re done."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:871
translate chinese CeR3_MS2_ef8d7b45:

    # MC "I did warn you."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:873
translate chinese CeR3_MS2_c59b3422:

    # Celia "Aww, what are you gonna do? Threaten to-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:877
translate chinese CeR3_MS2_fea6d86e:

    # Celia "Wh-What are-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:882
translate chinese CeR3_MS2_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:884
translate chinese CeR3_MS2_25e7fbc0:

    # Celia "Ow!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:886
translate chinese CeR3_MS2_b2e594be:

    # MC "What did I tell you to call me?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:890
translate chinese CeR3_MS2_0aae99b0:

    # Celia "(Holy shit! He actually had the balls to do it. I didn’t think he’d be able to do that.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:892
translate chinese CeR3_MS2_13510f7f:

    # Celia "(Let’s see if I can coax him into doing it a couple more times.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:894
translate chinese CeR3_MS2_61b6e2c0:

    # Celia "What should I call you? It’s obviously, [player_name]."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:898
translate chinese CeR3_MS2_36da6b01:

    # MC "Stop messing around, Celia. I gave you crystal clear instructions."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:900
translate chinese CeR3_MS2_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:905
translate chinese CeR3_MS2_3f5d5df2:

    # Celia "Ohhh! *Moan*"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:907
translate chinese CeR3_MS2_f13c69dd:

    # MC "(That almost sounded like a moan, rather than a cry of pain.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:911
translate chinese CeR3_MS2_a5bb3316:

    # MC "What do you call me?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:913
translate chinese CeR3_MS2_56fe3768:

    # Celia "S-Sir! I call you, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:915
translate chinese CeR3_MS2_f8aff8dd:

    # MC "That’s better. Now, how about you finish off that boobjob without the attitude?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:919
translate chinese CeR3_MS2_65017aea_2:

    # Celia "Yes, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:921
translate chinese CeR3_MS2_662d4043:

    # Celia "(God, I’m so fucking wet from him slapping my cheeks.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:923
translate chinese CeR3_MS2_65751594:

    # Celia "(I hope he has the energy to bend me over the couch and pound me senseless. Mmm!)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:925
translate chinese CeR3_MS2_8cc21742:

    # MC "Ugh... Ah..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:929
translate chinese CeR3_MS2_71b89018:

    # MC "Oh fuck... *pant* Just like that, Celia. Keep rubbing my cock between your tits. Ah..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:931
translate chinese CeR3_MS2_1cbbd3f6:

    # Celia "(I wish [player_name] was inside me right now. I’d love to be on top of him, grinding on his thick dick, rocking my hips back and forth.)"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:933
translate chinese CeR3_MS2_04848c6a:

    # MC "Ahhnn... Hnnggg.."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:937
translate chinese CeR3_MS2_bb9a863d:

    # MC "*Pant* I’m getting close. Squeeze your tits together tighter! *Pant* I’m about to cum!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:939
translate chinese CeR3_MS2_90e1e2f5:

    # Celia "That’s it, sir. Cum for me! Finish all over my big, beautiful breasts."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:941
translate chinese CeR3_MS2_f471ad5a:

    # MC "Aaarrgghhh! Hnnnnnggggg!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:951
translate chinese CeR3_MS2_a895f388:

    # MC "Aarrrrggghhh! Ugghh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:953
translate chinese CeR3_MS2_8595c86b:

    # Celia "Oh wow! Sooo much cum!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:955
translate chinese CeR3_MS2_0eb80360:

    # MC "*Pant* Ohhh fuck... Mmm..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:959
translate chinese CeR3_MS2_0e4674f6_3:

    # "*Zzziiip*"
    ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:962
translate chinese CeR3_MS2_b58f53cc:

    # MC "Maybe next time you’ll remember to ACTUALLY be here when I arrive."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:967
translate chinese CeR3_MS2_5c0fc28e:

    # Celia "W-Wait? What do you mean next time? We haven’t-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:969
translate chinese CeR3_MS2_f316c2e3_3:

    # MC "I told you I was going to finish off, didn’t I?"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:971
translate chinese CeR3_MS2_a2ec344a:

    # Celia "W-Wait, you just came over my tits, and you’re leaving already?! What about me? You can’t just leave me horny like this!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:973
translate chinese CeR3_MS2_0e1f9725:

    # MC "Aww, don’t look so sad. I’ll swing by again when I’m feeling bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:977
translate chinese CeR3_MS2_cd6d204d:

    # Celia "B-But you can’t, I haven’t- I haven’t- I haven’t got to CUM yet! What am I supposed to do?!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:979
translate chinese CeR3_MS2_2b94a641:

    # MC "You do realise this was supposed to be a punishment, Celia. Punishments aren’t meant to be enjoyable."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:983
translate chinese CeR3_MS2_6ca9512f:

    # MC "Oh, and one last thing - you’re forbidden from masturbating until I get back."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:985
translate chinese CeR3_MS2_0322af2a_3:

    # Celia "What? W-When are you coming back?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:987
translate chinese CeR3_MS2_c24ef931_3:

    # MC "Like I said, whenever I get bored."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:989
translate chinese CeR3_MS2_d89679a9_3:

    # MC "And don’t even think about playing with yourself when I leave. You might not realise it, but I’ll be able to tell. You give off an aura of desperation when you haven’t cum."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:991
translate chinese CeR3_MS2_8569a812_3:

    # Celia "Please... please come back soon, sir."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:999
translate chinese CeR3_MS2_236a4a0d:

    # MC "(Screw it. She’s doing this on purpose because she obviously WANTS me to escalate my punishment. I’m not giving into her trickery. I’ll let her give me a boobjob, and when I’m finally finished I’ll just walk away and leave her.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1001
translate chinese CeR3_MS2_e3f6e83f:

    # MC "(Celia is going to be super horny after giving me a boobjob, so the last thing she’ll expect is for me to just abandon her when she’s dripping wet.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1003
translate chinese CeR3_MS2_e36dec73:

    # MC "(Yeah, that would be the best punishment I could give right now.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1007
translate chinese CeR3_MS2_44cce07f:

    # Celia "Is something wrong, [player_name]? "
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1009
translate chinese CeR3_MS2_3c8cf750:

    # MC "(She isn't even calling me “sir” anymore. She’s DEFINITELY testing the waters to see what she can get away with.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1011
translate chinese CeR3_MS2_86eb126b:

    # MC "Mmm, nothing. That’s good."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1015
translate chinese CeR3_MS2_e0a3d964_1:

    # Celia "I bet your cock feels amazing right now, buried between my breasts. And I can go as fast or as slow as I want to."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1017
translate chinese CeR3_MS2_01febc55_1:

    # MC "Mmm... *Pant* Ah..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1019
translate chinese CeR3_MS2_4578961b_1:

    # Celia "I bet you want me to bounce up and down really quickly right now, but I’m not going to do that, [player_name]."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1023
translate chinese CeR3_MS2_9c133c2a:

    # Celia "I’m going to take my time. I’m going to make you cum at the pace I decide."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1025
translate chinese CeR3_MS2_5b9b5fe4:

    # MC "Hnng... *Pant*"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1027
translate chinese CeR3_MS2_a234d502:

    # Celia "Is there anything you’re going to do about that?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1029
translate chinese CeR3_MS2_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1031
translate chinese CeR3_MS2_e27b2e85:

    # Celia "I didn’t think so."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1035
translate chinese CeR3_MS2_99e60210:

    # Celia "So, I’m going to rub your hard dick between my tits, and you’re going to moan."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1037
translate chinese CeR3_MS2_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1039
translate chinese CeR3_MS2_2192bac9:

    # Celia "Because the truth is, I’ve got you in the palm of my hand right now. You DESPERATELY want to cum - more than you want to try and dominate me."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1043
translate chinese CeR3_MS2_00056801:

    # Celia "You’re weak, [player_name]. You’re a weak, angry little man who couldn’t handle my rejection. That’s why you bully women like me, isn’t it? You want to bring us down a peg?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1045
translate chinese CeR3_MS2_881bce64:

    # MC "(She really believes that she is the one in charge here. I can’t wait to see the expression on her face when I just abandon her and leave her a horny mess.)"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1047
translate chinese CeR3_MS2_0d71100b:

    # MC "Hnnng! Fuck... Ugh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1049
translate chinese CeR3_MS2_28ad1612:

    # Celia "Yeah, I thought so. You don’t have the balls to actually punish me. So, right now, we’re going to play a little game. In a few seconds I’m going to give you permission to-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1053
translate chinese CeR3_MS2_ac2c33a5:

    # Celia "No... I’m going to TELL you to cum. And when I do, you’re going to finish over my breasts."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1055
translate chinese CeR3_MS2_cfa607ac:

    # MC "Ah *Pant* Oh! Ahh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1057
translate chinese CeR3_MS2_acc7acae:

    # Celia "You’re breathing quicker now. Fine. I guess even little worms like you deserve their release. "
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1059
translate chinese CeR3_MS2_061391a9:

    # Celia "Cum for me."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1063
translate chinese CeR3_MS2_31d75db6:

    # MC "Hnnnnggg! AAHHHHH!!!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1065
translate chinese CeR3_MS2_922d618b:

    # Celia "That’s it! Cum harder! Cover my tits in your thick, warm cum! Hehe!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1067
translate chinese CeR3_MS2_c33a3ff7:

    # MC "Oohhh! F-Fuck! Ugghhh!"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1077
translate chinese CeR3_MS2_8aad0ece:

    # Celia "Wow, I can’t believe you came so hard from that. What an absolutely pathetic display. Ahaha!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1079
translate chinese CeR3_MS2_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1081
translate chinese CeR3_MS2_4fd1a495:

    # Celia "I can’t believe I ACTUALLY thought you were capable of dominating me. Looks like you can’t control a girl unless you knock her out first."
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1083
translate chinese CeR3_MS2_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1087
translate chinese CeR3_MS2_60bc5b03:

    # Celia "Seriously, I tried domination with Gustav years ago, and I thought HE was bad - but you’re even worse than-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1089
translate chinese CeR3_MS2_012f2f2c:

    # Celia "H-Hey, where are you going?"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1091
translate chinese CeR3_MS2_aa2a3480:

    # MC "I’m done."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1095
translate chinese CeR3_MS2_106315e6:

    # Celia "Wh-What do you mean you’re done?!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1099
translate chinese CeR3_MS2_932e1281:

    # MC "You honestly thought you were in control, Celia? I literally made you travel across town just to give me a boobjob."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1103
translate chinese CeR3_MS2_8afc7ec3:

    # Celia "Y-You can’t just leave yet! I haven’t- You haven’t done anything to- to-"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1107
translate chinese CeR3_MS2_c6b9ec60:

    # MC "I’m not going to make you cum, Celia. You stopped calling me ‘sir’ halfway through our session. You didn’t respect me as the dominant partner."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1109
translate chinese CeR3_MS2_e652b5dc:

    # MC "You taunted me. You mocked me. You didn’t obey the rules I set."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1113
translate chinese CeR3_MS2_15ea8ab1:

    # MC "So now you get to lie there, dripping with my cum. Perhaps, if you’re lucky, you’ll be able to use your dildo to give yourself a good enough orgasm to satisfy yourself."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1115
translate chinese CeR3_MS2_8512f0c3:

    # MC "I honestly doubt it though. I don’t think you’re capable of experiencing the same heights of pleasure I gave you with that electrostimulation dildo."
    MC ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1117
translate chinese CeR3_MS2_204b6757:

    # Celia "N-No, no, no! Wait! I’ll be good, sir! I promise! I’ll do whatever you ask, sir! Just don’t go yet! PLEASE! DON’T GO!"
    Celia ""

# game/scripts/Ce_R3/2_CeR3_MS2.rpy:1121
translate chinese CeR3_MS2_5aa5fda6:

    # MC "Catch ya later, Celia. I’ll be back when I’m feeling horny."
    MC ""

translate chinese strings:

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:276
    old "You’re going to wrap your lips around my cock, and suck it as hard and as fast as you possibly can."
    new ""

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:276
    old "Take off your bra, Celia. You’re going to massage my cock between your boobs."
    new ""

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:502
    old "Force Celia’s head down with both hands and creampie her throat."
    new ""

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:502
    old "Hold Celia’s head in place and cum over her lips."
    new ""

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:502
    old "Hold Celia’s head in place and give her a facial she’ll never forget."
    new ""

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:847
    old "Discipline Celia for disrespecting you. Show her who is the boss."
    new ""

    # game/scripts/Ce_R3/2_CeR3_MS2.rpy:847
    old "Don’t discipline Celia, just finish over her tits and leave her unsatisfied."
    new ""

