﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:7
translate chinese caroline_visit_bjfjhj_v1_f28c318c:

    # Caroline "(Well... this is it. I’ve thought things through, and I know my limitations.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:8
translate chinese caroline_visit_bjfjhj_v1_25e8d212:

    # Caroline "(I’ll lay down the boundaries with [player_name] and see if he’s interested in a deal.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:9
translate chinese caroline_visit_bjfjhj_v1_37c0a2b8:

    # Caroline "(God... I hope I’m doing the right thing.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:12
translate chinese caroline_visit_bjfjhj_v1_73a88263:

    # Caroline "[player_name]? Are you awake?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:13
translate chinese caroline_visit_bjfjhj_v1_dabaf0fc:

    # MC "*Snooooree...*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:14
translate chinese caroline_visit_bjfjhj_v1_fbb20bf2:

    # Caroline "(He’s in a deep sleep... I guess that gives me an excuse to break the ice before I have to try and have this difficult conversation.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:21
translate chinese caroline_visit_bjfjhj_v1_ccc620ff:

    # Caroline "BOO!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:22
translate chinese caroline_visit_bjfjhj_v1_007dcd03:

    # MC "AHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:23
translate chinese caroline_visit_bjfjhj_v1_d46af2ae:

    # MC "Jesus Christ! You scared the shit out of me, Caroline! What the Hell?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:26
translate chinese caroline_visit_bjfjhj_v1_e51822ee:

    # Caroline "Aww, come on. You’re happy to see me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:29
translate chinese caroline_visit_bjfjhj_v1_39fe1185:

    # MC "Yeah - but couldn’t you have woken me up gently?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:30
translate chinese caroline_visit_bjfjhj_v1_dd69a703:

    # MC "Y’know - maybe a hug or pat on the shoulder..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:31
translate chinese caroline_visit_bjfjhj_v1_860c3643:

    # Caroline "Pfft! That’s no fun!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:34
translate chinese caroline_visit_bjfjhj_v1_28d9be90:

    # Caroline "Anyway, I have something important to tell you. So I need you to be fully awake."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:35
translate chinese caroline_visit_bjfjhj_v1_2d25befd:

    # MC "Uh huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:36
translate chinese caroline_visit_bjfjhj_v1_f685b95e:

    # Caroline "I’m willing to help you out with your... problem."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:37
translate chinese caroline_visit_bjfjhj_v1_5e900ee0:

    # MC "Do you mean my erection?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:40
translate chinese caroline_visit_bjfjhj_v1_2f6d268b:

    # Caroline "Yeah... that. However, there are some conditions and rules I want to lay down first."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:41
translate chinese caroline_visit_bjfjhj_v1_3c734d6b:

    # MC "Like what?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:42
translate chinese caroline_visit_bjfjhj_v1_866dff39:

    # Caroline "I need you to promise me something, first."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:43
translate chinese caroline_visit_bjfjhj_v1_e68773c7:

    # MC "Anything!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:44
translate chinese caroline_visit_bjfjhj_v1_89ed0769:

    # Caroline "You have to respect these rules and not try to push me to do something I’m uncomfortable with. Does that sound fair to you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:45
translate chinese caroline_visit_bjfjhj_v1_190f8f14:

    # MC "Sure, I guess so. What are you comfortable with?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:49
translate chinese caroline_visit_bjfjhj_v1_fb908a32:

    # Caroline "I’m happy to help you get off using my hands or butt again, but there’s two conditions."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:50
translate chinese caroline_visit_bjfjhj_v1_a61319b9:

    # Caroline "The first is that you start working for free when I need photo sessions done. I don’t have the spare cash to take on a part-time employee."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:51
translate chinese caroline_visit_bjfjhj_v1_26289e4d:

    # MC "Fair enough. I understand."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:52
translate chinese caroline_visit_bjfjhj_v1_23959a90:

    # Caroline "The second condition is that this ends when you find yourself a girlfriend. From then on, it’s her job."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:53
translate chinese caroline_visit_bjfjhj_v1_48c2db1f:

    # Caroline "Does that sound fair to you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:54
translate chinese caroline_visit_bjfjhj_v1_ca08d846:

    # MC "Yeah, that sounds fair."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:57
translate chinese caroline_visit_bjfjhj_v1_d14db211:

    # Caroline "Ahh, I see you could probably use some help, RIGHT NOW."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:58
translate chinese caroline_visit_bjfjhj_v1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:61
translate chinese caroline_visit_bjfjhj_v1_5fff9b0c:

    # MC "Aw, crap. Sorry. I’ve no control over it - I swear!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:62
translate chinese caroline_visit_bjfjhj_v1_d8ff8c20:

    # Caroline "Would you like to begin our deal RIGHT NOW?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:63
translate chinese caroline_visit_bjfjhj_v1_2b515de7:

    # MC "Definitely!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:64
translate chinese caroline_visit_bjfjhj_v1_23f67ca2:

    # Caroline "Let’s get this started, then - Kick off your boxer shorts."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:67
translate chinese caroline_visit_bjfjhj_v1_1cd3255c:

    # Caroline "Well, that was fast! Shall I begin with my hand today, since you had my ass last time?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:68
translate chinese caroline_visit_bjfjhj_v1_4c987f37:

    # MC "Yeah, that works for me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:69
translate chinese caroline_visit_bjfjhj_v1_bbd25215:

    # Caroline "Okay, here we go."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:72
translate chinese caroline_visit_bjfjhj_v1_3273a3bd:

    # Caroline "Hehe... You’ve got such a hard cock. Do I really turn you on THAT MUCH?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:73
translate chinese caroline_visit_bjfjhj_v1_68eb99a2:

    # MC "Any beautiful girl would, to be honest."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:74
translate chinese caroline_visit_bjfjhj_v1_211aad25:

    # Caroline "Oh, so you think I’m beautiful then?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:75
translate chinese caroline_visit_bjfjhj_v1_741a2f58:

    # MC "Of course I do. You’re stunning."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:78
translate chinese caroline_visit_bjfjhj_v1_cd33d6ea:

    # Caroline "How’s this? Am I holding your cock too hard?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:79
translate chinese caroline_visit_bjfjhj_v1_ba83cc5f:

    # MC "Mmmm... No, that’s good, right there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:80
translate chinese caroline_visit_bjfjhj_v1_93050b21:

    # Caroline "Okay then, I’ll keep stroking your thick dick like this then."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:83
translate chinese caroline_visit_bjfjhj_v1_9eae3fc7:

    # Caroline "You are a pervert. You know that, right?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:87
translate chinese caroline_visit_bjfjhj_v1_16180b3a:

    # Caroline "Getting, all hard and horny, because of your older sister. Don’t think I didn’t know that you used to perv on me when I was sitting in my bedroom in my underwear."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:89
translate chinese caroline_visit_bjfjhj_v1_b86c7bf8:

    # Caroline "Getting all hard and horny from looking at me like this. Don’t think I didn’t know that you used to perv on me when I was sitting in my bedroom in my underwear."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:92
translate chinese caroline_visit_bjfjhj_v1_7b7325d6:

    # MC "Well, it seems being a pervert, comes with benefits."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:93
translate chinese caroline_visit_bjfjhj_v1_7961385c:

    # Caroline "So, have you been thinking of me, when you masturbate?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:94
translate chinese caroline_visit_bjfjhj_v1_85f705c4:

    # MC "What? I don’t-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:97
translate chinese caroline_visit_bjfjhj_v1_dbbafff3:

    # Caroline "Are you trying to tell me that you, don’t wank yourself? That’s bullshit!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:98
translate chinese caroline_visit_bjfjhj_v1_cab940e8:

    # MC "Of course I do that... but I’m not gonna just tell you what or who I fantasise about."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:101
translate chinese caroline_visit_bjfjhj_v1_de5e0d85:

    # Caroline "Oh well... Maybe you’ll open up to me, someday soon."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:104
translate chinese caroline_visit_bjfjhj_v1_109237fd:

    # Caroline "Are you enjoying this, by the way? Do you want me to do anything different?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:110
translate chinese caroline_visit_bjfjhj_v1_4fb5d7f9:

    # MC "It’s amazing! Don’t stop! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:111
translate chinese caroline_visit_bjfjhj_v1_3ed61d5e:

    # Caroline "In that case, I’ll use both my hands, then!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:112
translate chinese caroline_visit_bjfjhj_v1_eb3bf8af:

    # MC "Ah! I’m so close to cumming! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:117
translate chinese caroline_visit_bjfjhj_v1_f2634aca:

    # Caroline "Cum for me! Cum for your big sister!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:119
translate chinese caroline_visit_bjfjhj_v1_dba5eba9:

    # Caroline "Cum for me! Blow your hot cum all over my hands!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:120
translate chinese caroline_visit_bjfjhj_v1_1f2a47b3:

    # MC "Hnnng! Ahhh! Ugh! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:121
translate chinese caroline_visit_bjfjhj_v1_2a539d84:

    # MC "(She’s amazing with her hands!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:132
translate chinese caroline_visit_bjfjhj_v1_c31d1970:

    # Caroline "Remember, it only lasts until you get a girlfriend - and you’re working for free, with me now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:133
translate chinese caroline_visit_bjfjhj_v1_4f4c09f6:

    # Caroline "Come back to my shop, when you get a chance. I’m ordering in some new stock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:134
translate chinese caroline_visit_bjfjhj_v1_afdcdc5c:

    # MC "Will do, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:135
translate chinese caroline_visit_bjfjhj_v1_591d46f7:

    # MC "Phew... I’m exhausted after that..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:136
translate chinese caroline_visit_bjfjhj_v1_e3688b64:

    # Caroline "Well, I hate to break the bad news - but it’s time for you to get up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:145
translate chinese caroline_visit_bjfjhj_v1_7ec749ec:

    # MC "Could you try using your feet instead?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:146
translate chinese caroline_visit_bjfjhj_v1_6c7561a6:

    # Caroline "M-My feet?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:147
translate chinese caroline_visit_bjfjhj_v1_16fb6d15:

    # MC "I know you said you would get me off with your hand or ass, as part of the deal - but can we make an exception for feet too?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:150
translate chinese caroline_visit_bjfjhj_v1_521570d5:

    # Caroline "Sure, I guess so."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:151
translate chinese caroline_visit_bjfjhj_v1_059f239d:

    # Caroline "To be honest, my real limitations were oral and actual sex. I didn’t imagine you had a foot fetish."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:152
translate chinese caroline_visit_bjfjhj_v1_985fe578:

    # Caroline "I’ve never actually used my feet on a guy before. So you’ll need to guide me a bit. How is this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:157
translate chinese caroline_visit_bjfjhj_v1_ed749b12:

    # MC "That’s good. Just keep moving your feet up and down."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:158
translate chinese caroline_visit_bjfjhj_v1_80d0ccaf:

    # Caroline "It feels a little awkward."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:159
translate chinese caroline_visit_bjfjhj_v1_574523da:

    # MC "Don’t worry about it - you’re doing fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:160
translate chinese caroline_visit_bjfjhj_v1_af3d86f6:

    # MC "If you wanted - you could also try holding my balls with your toes and caressing my cock with your other foot."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:163
translate chinese caroline_visit_bjfjhj_v1_4ba0da28:

    # Caroline "Kinda like this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:164
translate chinese caroline_visit_bjfjhj_v1_64fee7b5:

    # MC "Yeah, just like that! Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:165
translate chinese caroline_visit_bjfjhj_v1_799566bd:

    # Caroline "(This is kinda fun actually!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:168
translate chinese caroline_visit_bjfjhj_v1_924b3b29:

    # Caroline "Are you gonna cum soon? My legs are getting a bit tired."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:169
translate chinese caroline_visit_bjfjhj_v1_b356b6b1:

    # MC "Soon-ish. If it helps, though, you can use your hand as well."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:170
translate chinese caroline_visit_bjfjhj_v1_9ccb25ef:

    # Caroline "Is that okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:171
translate chinese caroline_visit_bjfjhj_v1_63873555:

    # MC "Absolutely!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:174
translate chinese caroline_visit_bjfjhj_v1_d3ca72f4:

    # MC "Oh God... yes! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:175
translate chinese caroline_visit_bjfjhj_v1_8bd80efe:

    # Caroline "Oh! You’re about to cum! I’m gonna use my hand, to finish you, now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:176
translate chinese caroline_visit_bjfjhj_v1_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:179
translate chinese caroline_visit_bjfjhj_v1_db433e78:

    # Caroline "Here we go!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:180
translate chinese caroline_visit_bjfjhj_v1_0ca3fba5:

    # MC "Ah! Ahhh! Ahhhhhh! HNNNNGGGGG!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:181
translate chinese caroline_visit_bjfjhj_v1_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:192
translate chinese caroline_visit_bjfjhj_v1_ec8d31b9:

    # Caroline "Oh wow... That’s A LOT of cum right there!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:194
translate chinese caroline_visit_bjfjhj_v1_e2872de8:

    # Caroline "(I think [player_name] really enjoyed this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:196
translate chinese caroline_visit_bjfjhj_v1_e2872de8_1:

    # Caroline "(I think [player_name] really enjoyed this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:197
translate chinese caroline_visit_bjfjhj_v1_e8530e51:

    # MC "Phew, that was incredible, Caroline. Thank you so much... *Yaaawwwn!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:198
translate chinese caroline_visit_bjfjhj_v1_21b0c43c:

    # Caroline "I hope you aren’t tired! It’s time to get up!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:201
translate chinese caroline_visit_bjfjhj_v1_58b96e51:

    # MC "Aww... Thanks anyway, Caroline. I’m going to enjoy this deal we made!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:202
translate chinese caroline_visit_bjfjhj_v1_53f6a2cd:

    # Caroline "Remember, it only lasts until you get a girlfriend - and you’re working for me for free now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:203
translate chinese caroline_visit_bjfjhj_v1_4f4c09f6_1:

    # Caroline "Come back to my shop, when you get a chance. I’m ordering in some new stock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:204
translate chinese caroline_visit_bjfjhj_v1_afdcdc5c_1:

    # MC "Will do, Caroline!"
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:106
    old "It’s amazing! Don’t stop!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/caroline_visit_bjfjhj_v1.rpy:106
    old "Could you maybe use your feet instead?"
    new ""

