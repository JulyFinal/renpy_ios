﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:8
translate chinese CeR2_NS1_rep_c7844892:

    # Celia "I’m going give you the best makeout session you’ve ever had."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:9
translate chinese CeR2_NS1_rep_daf31614:

    # Celia "And in return, you’re going to give me the best you can do to help me catch this fucker. Deal?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:10
translate chinese CeR2_NS1_rep_3c690260:

    # MC "Ab-so-lutely!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:13
translate chinese CeR2_NS1_rep_40293ef1:

    # Celia "*Sigh* Alright, let’s get this over with."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:14
translate chinese CeR2_NS1_rep_555f9e00:

    # MC "(This is gonna be awesome! She’s dressed so sexily too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:17
translate chinese CeR2_NS1_rep_3dd592f7:

    # Celia "Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:18
translate chinese CeR2_NS1_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:21
translate chinese CeR2_NS1_rep_6e12088b:

    # MC "(Fuck, she is so hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:22
translate chinese CeR2_NS1_rep_940ea3ba:

    # MC "(I wish she had just said yes to being my girlfriend when I first asked her. We’d be doing stuff like this all the time!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:25
translate chinese CeR2_NS1_rep_2e589664:

    # MC "(It’s hardly a makeout session if there’s no second base, right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:26
translate chinese CeR2_NS1_rep_eb11726f:

    # MC "(She won’t mind if I give her tits a little bit of a feel.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:27
translate chinese CeR2_NS1_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:30
translate chinese CeR2_NS1_rep_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:31
translate chinese CeR2_NS1_rep_d2801b97:

    # MC "(Hey! She didn’t slap me! I think she actually likes me touching there!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:33
translate chinese CeR2_NS1_rep_3a04f391:

    # Celia "(Ugh, he’s touching my tits now. Oh well, I’ve already had to do FAR worse to him. This is a blessing in comparison.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:35
translate chinese CeR2_NS1_rep_05d08dd1:

    # Celia "(Mmm... He’s touching my tits now. I wonder how things are going to progress over the next few days. I’ve got a couple of ideas floating in my head about what direction to take this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:38
translate chinese CeR2_NS1_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:39
translate chinese CeR2_NS1_rep_d2fdfba5:

    # Celia "MMM!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:42
translate chinese CeR2_NS1_rep_00e08ef4:

    # MC "(Oh wow, she’s climbing on top of me now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:43
translate chinese CeR2_NS1_rep_537eac57:

    # Celia "(Oh crap, I think I hit the cups!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:47
translate chinese CeR2_NS1_rep_5d6a8ef7:

    # "*CLATTER*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:48
translate chinese CeR2_NS1_rep_5cc148fa:

    # MC "Shit! Did something fall?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:51
translate chinese CeR2_NS1_rep_70e5aa17:

    # Celia "Just the cups. Don’t worry, they didn’t shatter."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:52
translate chinese CeR2_NS1_rep_d72cde2c:

    # MC "Oh, good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:55
translate chinese CeR2_NS1_rep_cd88c9a6:

    # MC "I love you lying on top of me like this."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:56
translate chinese CeR2_NS1_rep_6098f84c:

    # MC "It kinda feels like... you’re my girlfriend and we’re..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:57
translate chinese CeR2_NS1_rep_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:58
translate chinese CeR2_NS1_rep_bdff4dd6:

    # Celia "(Shit, I think I’ve led him on too much. Judy will kill me if she thinks I’ve interfered with his therapy.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:61
translate chinese CeR2_NS1_rep_b8cd0e06:

    # MC "(God, I’m so fucking horny right now. This is like a fantasy come true!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:62
translate chinese CeR2_NS1_rep_0652f26b:

    # MC "(I must have dreamt about Celia a dozen times!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:63
translate chinese CeR2_NS1_rep_a53d2073:

    # MC "(She won’t mind me lightly spanking her ass, will she? That’s part of making out too.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:66
translate chinese CeR2_NS1_rep_58d8bcb5:

    # MC "(Here goes nothing...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:67
translate chinese CeR2_NS1_rep_83b4b5b0:

    # Celia "(I’ve gone too far. If Judy finds out, she'll report me, and then I’ll have to endure another Godawful staff review meeting.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:71
translate chinese CeR2_NS1_rep_0c4b6ba1:

    # "*Whack*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:72
translate chinese CeR2_NS1_rep_db696836:

    # Celia "OUCH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:73
translate chinese CeR2_NS1_rep_1292b001:

    # MC "(Uh oh...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:76
translate chinese CeR2_NS1_rep_2770528a:

    # Celia "What the fuck?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:77
translate chinese CeR2_NS1_rep_23ff7e7e:

    # Celia "Did you just spank me?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:78
translate chinese CeR2_NS1_rep_c405af36:

    # MC "M-My hand slipped! Sorry!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:79
translate chinese CeR2_NS1_rep_84b9c9cf:

    # Celia "It better have JUST been your hand slipping!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:82
translate chinese CeR2_NS1_rep_d325d6bc:

    # Celia "Time to go and uphold your end of the bargain. We start tracking down this bastard ASAP."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:83
translate chinese CeR2_NS1_rep_a3af909b:

    # MC "Gotcha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:86
translate chinese CeR2_NS1_rep_94e65389:

    # MC "Oh, Celia? One last thing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:87
translate chinese CeR2_NS1_rep_1983e7f6:

    # Celia "Yes, [player_name]?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:88
translate chinese CeR2_NS1_rep_6a70efbf:

    # MC "Thanks for making out with me. It was REALLY hot."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1_rep.rpy:89
translate chinese CeR2_NS1_rep_104cadc2:

    # Celia "*Sigh*"
    Celia ""

