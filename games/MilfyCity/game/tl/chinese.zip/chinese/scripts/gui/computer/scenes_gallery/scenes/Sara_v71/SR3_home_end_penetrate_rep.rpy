﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:11
translate chinese SR3_home_end_penetrate_rep_128ebc87:

    # Sara "Are you okay if I lie back like this? I think I’ll feel safer if I’m facing you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:13
translate chinese SR3_home_end_penetrate_rep_993a175f:

    # Sara "Are you okay if I lie back like this? I think I'll feel better if I'm facing you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:14
translate chinese SR3_home_end_penetrate_rep_13d0c6ca:

    # MC "No problem at all, Sara. Just stay in whatever position makes you feel most comfortable."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:15
translate chinese SR3_home_end_penetrate_rep_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:18
translate chinese SR3_home_end_penetrate_rep_31600954:

    # Sara "If... If I ask you to stop... are you going to hate me?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:19
translate chinese SR3_home_end_penetrate_rep_f85ed88a:

    # MC "What? Why would I hate you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:20
translate chinese SR3_home_end_penetrate_rep_21d19e9d:

    # Sara "I know you’ve really wanted to have sex with me for a long time now... and if I get scared or it hurts... I might need some more time."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:21
translate chinese SR3_home_end_penetrate_rep_e24fae1a:

    # MC "Don’t worry, Sara. We’ll take things at your pace. I’m not going to be angry with you or hate you. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:23
translate chinese SR3_home_end_penetrate_rep_b692f6b0:

    # Sara "If... If I ask you to stop... Are you going to be sad?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:24
translate chinese SR3_home_end_penetrate_rep_41ac4f7e:

    # MC "What? Why would I be sad?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:25
translate chinese SR3_home_end_penetrate_rep_c26f0597:

    # Sara "I know you've really wanted to have sex with me for a long time now... and if I get nervous... I could say that I need some more time."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:26
translate chinese SR3_home_end_penetrate_rep_c562febf:

    # MC "Don’t worry, Sara. We’ll take things at your pace. I’m not going to be sad with you or anything. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:28
translate chinese SR3_home_end_penetrate_rep_5f42c4a9:

    # Sara "Okay... Let’s try this..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:29
translate chinese SR3_home_end_penetrate_rep_f091d6e1:

    # MC "Your pussy looks really beautiful, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:30
translate chinese SR3_home_end_penetrate_rep_213fd67c:

    # Sara "You’re just saying that to make me feel better..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:32
translate chinese SR3_home_end_penetrate_rep_860ea985:

    # MC "I’m not! It really is gorgeous. It’s so smooth and your vulva is amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:33
translate chinese SR3_home_end_penetrate_rep_c12333f2:

    # MC "It looks so ready for me to just slide my cock right inside you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:34
translate chinese SR3_home_end_penetrate_rep_5212ad7e:

    # MC "(I’m one hell of a lucky guy to fuck a pussy looking this pristine! Her body’s impeccable.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:36
translate chinese SR3_home_end_penetrate_rep_3f2bc93c:

    # MC "Alright, I’m just going to line myself up here. If you need me to slow down or stop, just let me know, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:37
translate chinese SR3_home_end_penetrate_rep_3734572c:

    # Sara "*Gulp* Okay... I think... Go ahead."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:39
translate chinese SR3_home_end_penetrate_rep_da40e8b6:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:40
translate chinese SR3_home_end_penetrate_rep_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:41
translate chinese SR3_home_end_penetrate_rep_6d1c1b47:

    # Sara "Y-Yeah, I just felt... it was nice when your dick brushed against my clitoris there. Like a sharp burst of pleasure. It's completely different than with a cold vibrator."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:43
translate chinese SR3_home_end_penetrate_rep_6900e9f9:

    # MC "I promise you Sara, this is going to feel amazing. We just have to get past the first hurdle and then you’ll be enjoying it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:44
translate chinese SR3_home_end_penetrate_rep_3466bc0b:

    # MC "That feeling of my dick touching your clit? It will pale in comparison to the sensation of it plunging deep inside you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:46
translate chinese SR3_home_end_penetrate_rep_b46fa9a9:

    # Sara "O-Okay... I can’t look. C-Can you just do it slowly?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:47
translate chinese SR3_home_end_penetrate_rep_d64727db:

    # MC "Are you sure you don’t want to see me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:49
translate chinese SR3_home_end_penetrate_rep_8bae13d6:

    # Sara "J-Just do it before I chicken out."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:51
translate chinese SR3_home_end_penetrate_rep_6f421df3:

    # Sara "Just do it! [player_name]! "
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:53
translate chinese SR3_home_end_penetrate_rep_d53160ee:

    # MC "Okay, Sara. I want you to take some deep breaths for me. This is going to be fun."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:54
translate chinese SR3_home_end_penetrate_rep_0df973fe:

    # Sara "*Gulp* A-Alright, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:55
translate chinese SR3_home_end_penetrate_rep_5dbe4851:

    # Sara "(I’m going to enjoy this... I’m going to enjoy this...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:58
translate chinese SR3_home_end_penetrate_rep_334d2cfc:

    # MC "Do you remember that time [Mom_name], you, and me all went to Xtremeland together?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:60
translate chinese SR3_home_end_penetrate_rep_79cc5634:

    # MC "Do you remember that time we all went to Xtremeland together?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:61
translate chinese SR3_home_end_penetrate_rep_c9e69812:

    # Sara "Y-Yeah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:62
translate chinese SR3_home_end_penetrate_rep_57beeace:

    # MC "That was some time ago. Do you remember the big roller coasters?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:64
translate chinese SR3_home_end_penetrate_rep_5a9bf7e4:

    # Sara "Ah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:65
translate chinese SR3_home_end_penetrate_rep_d79b5923:

    # MC "Do you remember the roller coasters, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:66
translate chinese SR3_home_end_penetrate_rep_c9e69812_1:

    # Sara "Y-Yeah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:68
translate chinese SR3_home_end_penetrate_rep_40ee629b:

    # MC "You were so so scared when we were in the queue. You were clinging to [Mom_name]’s arm the entire time."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:70
translate chinese SR3_home_end_penetrate_rep_593500f1:

    # MC "You were so hyped when we were in the queue!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:72
translate chinese SR3_home_end_penetrate_rep_da40e8b6_1:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:75
translate chinese SR3_home_end_penetrate_rep_9afbc9e2:

    # MC "And by the time we got you locked into your seat you were trembling in terror."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:77
translate chinese SR3_home_end_penetrate_rep_50ceddd2:

    # MC "And by the time we got you locked into your seat, you were so excited!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:78
translate chinese SR3_home_end_penetrate_rep_2536b745:

    # MC "Do you remember what happened next, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:80
translate chinese SR3_home_end_penetrate_rep_19241e69:

    # Sara "I- I- I-"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:81
translate chinese SR3_home_end_penetrate_rep_fcfffff2:

    # MC "Easy, deep breaths. Nice and calm. You’re safe."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:83
translate chinese SR3_home_end_penetrate_rep_d510b434:

    # Sara "I... I..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:85
translate chinese SR3_home_end_penetrate_rep_59d78907:

    # MC "The roller coaster started going, and as we went down the first big dip you screamed in excitement."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:87
translate chinese SR3_home_end_penetrate_rep_baa4f1cb:

    # MC "Ugh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:89
translate chinese SR3_home_end_penetrate_rep_da87d088:

    # Sara "Ohhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:90
translate chinese SR3_home_end_penetrate_rep_be768ec6:

    # MC "Because, as soon as you were on that ride you discovered that you REALLY loved it. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:92
translate chinese SR3_home_end_penetrate_rep_7224268b:

    # Sara "Oohh... oh, [player_name]... This feels..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:94
translate chinese SR3_home_end_penetrate_rep_e5410465:

    # MC "We had to take you back to that roller coaster five times. [Mom_name] and I took it in turns bringing you on it. Once you had a taste of the excitement the roller coaster offered, you never wanted it to end."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:96
translate chinese SR3_home_end_penetrate_rep_889c69d2:

    # MC "We had to take you back to that roller coaster five times. Once you had a taste of the excitement the roller coaster offered, you never wanted it to end. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:97
translate chinese SR3_home_end_penetrate_rep_3cba20d2:

    # Sara "It’s... so big..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:99
translate chinese SR3_home_end_penetrate_rep_27fcebbb:

    # MC "You were having so much fun, you were squealing your little lungs out. And you know what, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:100
translate chinese SR3_home_end_penetrate_rep_3cd7ed60:

    # MC "You’re about to experience the same thing again now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:101
translate chinese SR3_home_end_penetrate_rep_f5551280:

    # Sara "*Gasp* Ooohhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:103
translate chinese SR3_home_end_penetrate_rep_e68f2701:

    # Sara "AHHHH!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:104
translate chinese SR3_home_end_penetrate_rep_6f145f48:

    # Sara "(Holy shit! [player_name] went all the way in! I can feel his fat cock buried deep inside my pussy!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:106
translate chinese SR3_home_end_penetrate_rep_a5741998:

    # MC "Mmm! God, you’re really tight. I mean, I expected your pussy to be good, but this is fucking amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:107
translate chinese SR3_home_end_penetrate_rep_260599e7:

    # Sara "Oohhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:109
translate chinese SR3_home_end_penetrate_rep_d1bf2919:

    # MC "Are you in pain?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:110
translate chinese SR3_home_end_penetrate_rep_c429df9e:

    # Sara "It- It doesn’t hurt much... There was a little prick of pain, but it wasn’t like that time you, ahh... put it in my butt."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:112
translate chinese SR3_home_end_penetrate_rep_55f77075:

    # MC "Are you feeling okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:113
translate chinese SR3_home_end_penetrate_rep_c680c2f7:

    # Sara "It- It doesn't feel weird... There was a little prick at the beginning, but it's a completely different feeling... Then that time when you.. put it in my butt."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:115
translate chinese SR3_home_end_penetrate_rep_bf84ce92:

    # MC "I’m going to start moving it now, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:116
translate chinese SR3_home_end_penetrate_rep_ab8fd624:

    # Sara "Uh huh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:118
translate chinese SR3_home_end_penetrate_rep_6590ac97:

    # Sara "Oh! Ahh... H-Holy crap... Oooh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:119
translate chinese SR3_home_end_penetrate_rep_492a820d:

    # MC "Feeling good?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:120
translate chinese SR3_home_end_penetrate_rep_f391bdf1:

    # Sara "Y-Yeah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:126
translate chinese SR3_home_end_penetrate_rep_318a9580:

    # Sara "I-Is there any blood?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:127
translate chinese SR3_home_end_penetrate_rep_ba2c6ed9:

    # MC "Probably if it was your first time."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:128
translate chinese SR3_home_end_penetrate_rep_96855617:

    # Sara "That’s so embarrassing... Can you check and wash if that’s the case?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:130
translate chinese SR3_home_end_penetrate_rep_bba81930:

    # MC "Yeah, there’s a small amount. I’ll go and wash it off now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:131
translate chinese SR3_home_end_penetrate_rep_f3b8fc37:

    # Sara "I’m sorry..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:132
translate chinese SR3_home_end_penetrate_rep_32ef795c:

    # MC "Shush, it’s not your fault. You didn’t do anything wrong."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:134
translate chinese SR3_home_end_penetrate_rep_38f1bc5e:

    # Sara "Do you find it disgusting?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:135
translate chinese SR3_home_end_penetrate_rep_8ba65b4e:

    # MC "There’s nothing disgusting about you at all. It’s just part of your bodily function."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:137
translate chinese SR3_home_end_penetrate_rep_071b04f8:

    # MC "Sara, you were a virgin! Most virgins are going to bleed after their first time having sex. It’s perfectly natural as the hymen tears."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:139
translate chinese SR3_home_end_penetrate_rep_1298f043:

    # Sara "R-Really?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:140
translate chinese SR3_home_end_penetrate_rep_d424ab6d:

    # MC "I promise. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:142
translate chinese SR3_home_end_penetrate_rep_a56f19fe:

    # Sara "I know that, [player_name]... It’s just nasty..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:143
translate chinese SR3_home_end_penetrate_rep_e181bed7:

    # MC "I don't care about that. Don’t worry, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:145
translate chinese SR3_home_end_penetrate_rep_a42b3399:

    # Sara "*Phew* That’s a relief."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:146
translate chinese SR3_home_end_penetrate_rep_eaae6822:

    # Sara "Y’know, this wasn’t even half as bad as I thought it was going to be."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:147
translate chinese SR3_home_end_penetrate_rep_96f92bce:

    # MC "Yeah, you really got yourself worked up. Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:149
translate chinese SR3_home_end_penetrate_rep_f135394a:

    # MC "Just give me one minute to wash this. I’ll be right back and we can pick up where we left off."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:150
translate chinese SR3_home_end_penetrate_rep_6849c12c:

    # MC "Stay right there, I won’t be long!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:152
translate chinese SR3_home_end_penetrate_rep_fcf4cd1d:

    # Sara "(I really did blow this out of proportion in my mind...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:153
translate chinese SR3_home_end_penetrate_rep_2b439eb7:

    # Sara "(I guess I have a habit of doing things like that. Especially when [player_name] hangs around with other women like Lily.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:154
translate chinese SR3_home_end_penetrate_rep_c540c60c:

    # Sara "(Maybe I just need to take a step back, relax, and chill the fuck out every now and then.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:160
translate chinese SR3_home_end_penetrate_rep_6fbe92b5:

    # Sara "(Yeah... that’s right. Not everything is going to hurt me, and not every girl is trying to steal [player_name] away from me.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:162
translate chinese SR3_home_end_penetrate_rep_9774bdb7:

    # Sara "(Yeah... that's right. [player_name] wants the best for me, and it's not like every girl is trying to steal him away from me.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:163
translate chinese SR3_home_end_penetrate_rep_3fad2e8d:

    # Sara "God... Haha... I’m an idiot."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:165
translate chinese SR3_home_end_penetrate_rep_100c1bcb:

    # MC "What was that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:166
translate chinese SR3_home_end_penetrate_rep_de4131cf:

    # Sara "I was just laughing that I’m an idiot. I see how ridiculous my reaction was now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:168
translate chinese SR3_home_end_penetrate_rep_fc0035a1:

    # MC "Haha, it’s alright, Sara. You were scared. I understand. Shall we get back to it?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:170
translate chinese SR3_home_end_penetrate_rep_ca9f2f6b:

    # MC "Haha, it’s alright, Sara. You were nervous. I understand. Shall we get back to it?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:171
translate chinese SR3_home_end_penetrate_rep_c3eacd8a:

    # Sara "Mmm, yes please!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:173
translate chinese SR3_home_end_penetrate_rep_4a3593d6:

    # Sara "Oohh... That’s nice, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:174
translate chinese SR3_home_end_penetrate_rep_90e6e921:

    # MC "Mmm... Your pussy really is fucking perfect, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:175
translate chinese SR3_home_end_penetrate_rep_7ba253e6:

    # MC "Are you okay if I plunge my cock in all the way now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:177
translate chinese SR3_home_end_penetrate_rep_1435b319:

    # Sara "Yes, [player_name]! Do it. Fuck me hard!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:179
translate chinese SR3_home_end_penetrate_rep_73601410:

    # Sara "Ahh! Ah! Ah! Yes! This feels amazing!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:181
translate chinese SR3_home_end_penetrate_rep_8eba8007:

    # Sara "Oh [player_name]! I love you! You’re amazing!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:183
translate chinese SR3_home_end_penetrate_rep_1f4aab86:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:184
translate chinese SR3_home_end_penetrate_rep_058fa951:

    # MC "(Her pussy feels like it’s grabbing onto my cock, she’s so tight! This is phenomenal!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:186
translate chinese SR3_home_end_penetrate_rep_c6ce6b7b:

    # Sara "Your cock *gasp* is so massive! Ohh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:187
translate chinese SR3_home_end_penetrate_rep_8f45c6c0:

    # MC "How does it hnngg... feel now, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:189
translate chinese SR3_home_end_penetrate_rep_0b62ad51:

    # Sara "It’s like oohh.. it’s like that time I came when ah.. ah... you were fucking my butt with the lube on. Ahh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:190
translate chinese SR3_home_end_penetrate_rep_499e6d52:

    # MC "Do you want to try some other positions?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:192
translate chinese SR3_home_end_penetrate_rep_6a9c9419:

    # Sara "Can we do it with you behind me? Like we did on the roof?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:193
translate chinese SR3_home_end_penetrate_rep_c0ebc05b:

    # MC "Sure, Sara. It might be easier if you stand up though. Try leaning against the couch."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:195
translate chinese SR3_home_end_penetrate_rep_8e637806:

    # Sara "How’s this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:196
translate chinese SR3_home_end_penetrate_rep_612e3fa9:

    # MC "Absolutely perfect. God, your butt is fucking amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:198
translate chinese SR3_home_end_penetrate_rep_bac819f4:

    # Sara "You’re not going to put it in my ass again, are you?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:199
translate chinese SR3_home_end_penetrate_rep_c0663349:

    # MC "Haha, no. Not today. I was just admiring it. You’ve got this perfect bubble butt."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:200
translate chinese SR3_home_end_penetrate_rep_5cef2c67:

    # Sara "Hehe, thanks!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:202
translate chinese SR3_home_end_penetrate_rep_6549257f:

    # MC "I’m gonna go a bit faster and harder now. You’ll see just how good sex can be."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:203
translate chinese SR3_home_end_penetrate_rep_542b1fec:

    # Sara "Hurry up and put it in! Don’t keep me waiting!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:205
translate chinese SR3_home_end_penetrate_rep_39a1464a:

    # Sara "Mmm! Yes... Just like that, [player_name]. Plunge your thick cock deep inside me!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:206
translate chinese SR3_home_end_penetrate_rep_8b9866ea:

    # Sara "(I’m soaking wet right now!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:208
translate chinese SR3_home_end_penetrate_rep_1547b503:

    # MC "Here we go, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:209
translate chinese SR3_home_end_penetrate_rep_9068bb6c:

    # MC "I’m going to pound your pussy until you’re cumming so hard you can barely stand."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:210
translate chinese SR3_home_end_penetrate_rep_8e93edb0:

    # Sara "(Oh wow, that sounds so hot!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:212
translate chinese SR3_home_end_penetrate_rep_22adba9e:

    # MC "Hnngg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:214
translate chinese SR3_home_end_penetrate_rep_cca43758:

    # Sara "Ohhh! Yes! Fill me up with your big cock, [player_name]!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:216
translate chinese SR3_home_end_penetrate_rep_1f4aab86_1:

    # MC "Ugh! Ah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:218
translate chinese SR3_home_end_penetrate_rep_700ab215:

    # MC "Mmm! Your little fuckhole is so damn tight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:220
translate chinese SR3_home_end_penetrate_rep_5df79537:

    # Sara "Ah! God, yes! Mmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:222
translate chinese SR3_home_end_penetrate_rep_a5dbdc50:

    # Sara "Pound me, [player_name]! Fuck me harder! Ahh! AHHHHH!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:224
translate chinese SR3_home_end_penetrate_rep_71039872:

    # Sara "Smash your thick OOHHHHH... cock into my tight teen pussy! AAAAHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:226
translate chinese SR3_home_end_penetrate_rep_7d936ca3:

    # Sara "Smash your thick OOHHHHH... cock into my tight pussy! AAAAHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:228
translate chinese SR3_home_end_penetrate_rep_c5dcf0b9:

    # MC "Ohh... fuck! Ugh! Hnnngg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:229
translate chinese SR3_home_end_penetrate_rep_1492a2ae:

    # Sara "Ohhhh myyyy Godddd! It’s soooo fucking good! Mmmmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:231
translate chinese SR3_home_end_penetrate_rep_f02dd5ba:

    # Sara "T-Talk dirty to me! I want to ahh... hear your voice!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:233
translate chinese SR3_home_end_penetrate_rep_f4d550d6:

    # MC "(She wants me to talk dirty to her? I guess I could start with some tamer stuff to see if she enjoys it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:235
translate chinese SR3_home_end_penetrate_rep_4bf2da7d:

    # MC "Ohh... fuck! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:237
translate chinese SR3_home_end_penetrate_rep_450c2d85:

    # MC "I’m going to slam my cock into your tight little cunt again and again."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:238
translate chinese SR3_home_end_penetrate_rep_a5b56a9e:

    # Sara "Yeeesssss!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:239
translate chinese SR3_home_end_penetrate_rep_d767f067:

    # MC "I’m not gonna stop until you’re cumming your brains out."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:241
translate chinese SR3_home_end_penetrate_rep_60920b31:

    # Sara "Ahh! Ahhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:242
translate chinese SR3_home_end_penetrate_rep_ca60ec0d:

    # MC "And when you start begging me to stop fucking you because you can’t take it any more, I’m going to speed up."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:244
translate chinese SR3_home_end_penetrate_rep_a64d397c:

    # Sara "Ohhhh Hoooolyyy shit! Ayyaaaaahhhh!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:246
translate chinese SR3_home_end_penetrate_rep_4bf2da7d_1:

    # MC "Ohh... fuck! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:248
translate chinese SR3_home_end_penetrate_rep_77aaa918:

    # MC "Whenever you’re-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:249
translate chinese SR3_home_end_penetrate_rep_d6883394:

    # Sara "Oh fuck! It’s happening! I’m cumming! I’m cumming! AAAHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:251
translate chinese SR3_home_end_penetrate_rep_6a0c5786:

    # Sara "Ahhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:252
translate chinese SR3_home_end_penetrate_rep_b3cd62b0:

    # Sara "(My whole body is contracting and twitching! It feels like electricity is running through my veins right now!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:254
translate chinese SR3_home_end_penetrate_rep_3ea1b7a3:

    # MC "That’s it, Sara. Cum for me. I want you to cum for me again."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:255
translate chinese SR3_home_end_penetrate_rep_d4727c09:

    # Sara "Hnnnggg... Ohhhh!!!!! GOD! It’s t-too intense!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:256
translate chinese SR3_home_end_penetrate_rep_51cef0ff:

    # MC "Cum again! I want to feel your wet hole clamping down around my dick."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:258
translate chinese SR3_home_end_penetrate_rep_9c647c9a:

    # Sara "Haaaahhhhhh! AAAAHHHH!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:259
translate chinese SR3_home_end_penetrate_rep_a57c537b:

    # Sara "(It isn’t stopping! The pleasure just keeps coming and coming in waves!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:260
translate chinese SR3_home_end_penetrate_rep_aeef0cb5:

    # MC "Are you enjoying my cock forcing you to cum over and over? Of course you are."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:262
translate chinese SR3_home_end_penetrate_rep_82f5b4a9:

    # Sara "I...ahhhh... love it! Sooo goood!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:263
translate chinese SR3_home_end_penetrate_rep_99bfe986:

    # MC "You’ve cum so hard you can barely string a sentence together. Look up at me. I want to look into your beautiful green eyes as you climax."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:265
translate chinese SR3_home_end_penetrate_rep_2b490aee:

    # Sara "[player_name].... Aaahhhhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:266
translate chinese SR3_home_end_penetrate_rep_700247fb:

    # MC "You’re going to cum again for me now. Do it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:268
translate chinese SR3_home_end_penetrate_rep_711a1213:

    # Sara "AHHHHH!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:269
translate chinese SR3_home_end_penetrate_rep_c3541316:

    # MC "(Her pussy is contacting around my cock with each orgasmic convulsion! I’m gonna cum inside her if she keeps this up!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:271
translate chinese SR3_home_end_penetrate_rep_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:272
translate chinese SR3_home_end_penetrate_rep_b26bbb44:

    # Sara "(Holy crap! He’s balls deep inside me now! I’m so sensitive down there, I can feel his veiny cock stirring me up!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:274
translate chinese SR3_home_end_penetrate_rep_a268ed85:

    # MC "Now, where should I cum? Ugh! Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:275
translate chinese SR3_home_end_penetrate_rep_5857e55e:

    # Sara "Ah! Ah! Ahhhh! Ahh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:276
translate chinese SR3_home_end_penetrate_rep_b3a0f0f6:

    # MC "Should I pull out and blow my hot load all over your ass?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:278
translate chinese SR3_home_end_penetrate_rep_8bef11d5:

    # MC "Or should I just keep fucking you until I empty my balls deep into your womb?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:280
translate chinese SR3_home_end_penetrate_rep_37d74855:

    # Sara "Ahhh! Yessss! Please! I want your cuummmmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:282
translate chinese SR3_home_end_penetrate_rep_b9b3a994:

    # Sara "Ah! Ah! Ahhhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:284
translate chinese SR3_home_end_penetrate_rep_c5dcf0b9_1:

    # MC "Ohh... fuck! Ugh! Hnnngg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:286
translate chinese SR3_home_end_penetrate_rep_a58e563d:

    # MC "It’s probably dangerous for me to cum inside you right now. You’re not on the pill, and we didn’t use a condom, did we Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:288
translate chinese SR3_home_end_penetrate_rep_09efefb2:

    # Sara "Ah! Ahh! N-No, we didn’t! Ohhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:289
translate chinese SR3_home_end_penetrate_rep_b689119a:

    # MC "But you’re too horny to resist right now, aren't you? You’re going to let me dump a thick creamy load deep inside your pussy if I want to, aren’t you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:291
translate chinese SR3_home_end_penetrate_rep_ca4e1078:

    # Sara "(I... I have to resist... I can’t let... I might get pregnant... I...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:292
translate chinese SR3_home_end_penetrate_rep_6760fb90:

    # MC "I can tell you’re trying to resist it, but deep down you’re wondering what it feels like to have your pussy pumped full of hot, sticky cum."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:293
translate chinese SR3_home_end_penetrate_rep_0887e71c:

    # Sara "(No... I... I shouldn’t let... It’s too risky... I...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:294
translate chinese SR3_home_end_penetrate_rep_7c26bd02:

    # Sara "Cum inside me! PLEASE! I want to feel your hot cum fill me up!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:298
translate chinese SR3_home_end_penetrate_rep_85c7bdc7:

    # MC "Aaahh! Fuck! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:299
translate chinese SR3_home_end_penetrate_rep_06429b9c:

    # Sara "Oohh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:307
translate chinese SR3_home_end_penetrate_rep_77e8401a:

    # MC "Hnnngg! Ugh!! Aaaahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:308
translate chinese SR3_home_end_penetrate_rep_35836c8f:

    # Sara "Oh... wow... Mmm! It’s so warm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:309
translate chinese SR3_home_end_penetrate_rep_2a92540a:

    # MC "*Pant* Fuck... That was... intense."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:310
translate chinese SR3_home_end_penetrate_rep_44ff1d0a:

    # Sara "Haha... You can say that again... *Phew*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:319
translate chinese SR3_home_end_penetrate_rep_65729f1c:

    # MC "Ugh! I’m gonna cum, Sara. I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:321
translate chinese SR3_home_end_penetrate_rep_d7f0a805:

    # Sara "(F-Fuck, this is so unsafe! I... I need to stop him... I need to... It’s so good... I should tell him to cum outside!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:323
translate chinese SR3_home_end_penetrate_rep_5bc4ddaa:

    # Sara "(F-Fuck, this is so unsafe! I... I need to... It's so good... But maybe I should tell him to cum outside!?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:324
translate chinese SR3_home_end_penetrate_rep_39c9421d:

    # Sara "Ah! Ahhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:325
translate chinese SR3_home_end_penetrate_rep_fa19d982:

    # MC "Hnnngg! Get ready, Sara. Your fertile pussy is about to be aaahh... filled with semen!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:327
translate chinese SR3_home_end_penetrate_rep_18026de7:

    # Sara "(N-No! He might get me pregnant! His sperm are going to fertilise my eggs and... oh God, why am I getting even more turned on thinking about that?! Shit! I think I’m gonna cum again!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:329
translate chinese SR3_home_end_penetrate_rep_a8e661c1:

    # Sara "(Y-Yes! He might get me pregnant! His sperm is going to fertilize my eggs and... Oh God! Why am I getting, even more, turned on thinking about that?! Shit! I think I'm gonna cum again!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:330
translate chinese SR3_home_end_penetrate_rep_d7a902c5:

    # Sara "I... I... Ohhh!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:331
translate chinese SR3_home_end_penetrate_rep_1d2724e3:

    # MC "Aarggghhh! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:332
translate chinese SR3_home_end_penetrate_rep_a9d8923b:

    # Sara "(Holy shit! I can feel his cock pulsating. There’s a hot sensation flooding my pussy!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:333
translate chinese SR3_home_end_penetrate_rep_4810a788:

    # Sara "YESSS [player_name]! CUM INSIDE ME! FILL ME UP! AAHHHH!!! I’m cuuummmmiiinnnnggg! Ayaaaahhhhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:341
translate chinese SR3_home_end_penetrate_rep_c1f8c6f4:

    # MC "*Pant* *Pant* That was... fucking... amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:342
translate chinese SR3_home_end_penetrate_rep_038b3936:

    # Sara "W-Wow... I’m still... *Gasp* trembling..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:343
translate chinese SR3_home_end_penetrate_rep_12aae51a:

    # MC "Did you enjoy your first time?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:345
translate chinese SR3_home_end_penetrate_rep_6f47a162:

    # Sara "It was *pant* so... so hot when you came inside me. I wasn’t expecting that. It really turned me on."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:347
translate chinese SR3_home_end_penetrate_rep_f8d531a2:

    # Sara "It was *pant* so... so hot when you came inside me. It really turned me on, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:348
translate chinese SR3_home_end_penetrate_rep_e27aed97:

    # MC "Heh, I’m glad you enjoyed it. I love you, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:349
translate chinese SR3_home_end_penetrate_rep_368b48b9:

    # Sara "I love you too, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:350
translate chinese SR3_home_end_penetrate_rep_ffcef8e4:

    # Sara "Hehe, I can feel it leaking out. I guess it’s my turn to wash now!"
    Sara ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:295
    old "Pull out and cum over Sara’s ass. It was fun teasing her with dirty talk, but now it’s best to play it safe."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_home_end_penetrate_rep.rpy:295
    old "Sara is in too much ecstasy to object to you cumming inside her. Live in the moment and empty your balls into her tight cunt."
    new ""

