﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:15
translate chinese MLR3_NS1_rep_a4d1c8fd:

    # MC "(Let’s see what [Mom_name] and [Dad_name] are up to now. I can’t hear anything, so they’re probably both asleep anyway.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:22
translate chinese MLR3_NS1_rep_10f7a572:

    # Dad "Zzz..."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:23
translate chinese MLR3_NS1_rep_fda7bc81:

    # Mom "*Heavy Breathing*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:24
translate chinese MLR3_NS1_rep_a8c11f1d:

    # Mom "(Why do I feel so damn hot right now? I can’t get [player_name] out of my head."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:28
translate chinese MLR3_NS1_rep_5baf3980:

    # Mom "(And every single time I close my eyes, I think back to that night in the beach house.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:29
translate chinese MLR3_NS1_rep_5f7f741a:

    # Mom "(His raw hard cock, felt so good, deep inside me. It’s like a damn addiction. I need to feel it again. I NEED to be fucked by [player_name] again.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:30
translate chinese MLR3_NS1_rep_fda7bc81_1:

    # Mom "*Heavy Breathing*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:33
translate chinese MLR3_NS1_rep_fbb3e5f5:

    # MC "([Mom_name]’s breathing really loudly. I wonder if she’s alright.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:37
translate chinese MLR3_NS1_rep_427759a3:

    # Mom "(Fuck... I loved it when I felt his thick shaft, pushing up against my pussy for the first time.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:38
translate chinese MLR3_NS1_rep_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:39
translate chinese MLR3_NS1_rep_a395f2d8:

    # MC "(Is [Mom_name] masturbating?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:43
translate chinese MLR3_NS1_rep_dc1eee29:

    # Mom "Ah..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:44
translate chinese MLR3_NS1_rep_722d4fec:

    # MC "(She’s moaning right, now! There’s no doubt about it - she’s fingering herself while [Dad_name] sleeps.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:45
translate chinese MLR3_NS1_rep_5a7f0a7c:

    # Mom "(Oh God... I need to book another night away with [player_name]. It needs to be longer next time though.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:49
translate chinese MLR3_NS1_rep_f35839e7:

    # Mom "(One night wasn’t enough. I don’t want to feel rushed into leaving, when I wake up the next day.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:50
translate chinese MLR3_NS1_rep_86b43224:

    # Mom "(I want to be able to hold him and cuddle beside him without stressing about having to come back to Bob.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:51
translate chinese MLR3_NS1_rep_8b0d872c:

    # Mom "Ah... Ohh... Yes..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:55
translate chinese MLR3_NS1_rep_17ac4e16:

    # Mom "(I can just imagine him, thrusting his thick cock, deep into me. No condom, just his hard dick, plunging again and again, into my soaking wet pussy.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:57
translate chinese MLR3_NS1_rep_a7d22198:

    # Mom "Ah! Ahhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:58
translate chinese MLR3_NS1_rep_459c3de1:

    # MC "(Wow! She’s really getting loud now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:62
translate chinese MLR3_NS1_rep_e0a8c3fd:

    # Mom "Oh! AH! AHHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:63
translate chinese MLR3_NS1_rep_30287ffe:

    # MC "(It’s weird that [Dad_name] hasn’t woken up yet! Caroline and Sara can probably hear her, from the other side of the house!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:64
translate chinese MLR3_NS1_rep_8edc9bf7:

    # Dad "Hmm..."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:68
translate chinese MLR3_NS1_rep_9c1ef1f5:

    # Mom "AH! AHHH! OHH FUCK!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:69
translate chinese MLR3_NS1_rep_ae0baad1:

    # Dad "Huh? What the..."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:70
translate chinese MLR3_NS1_rep_76dd25c1:

    # Dad "(Is she... masturbating in the middle of the night?!)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:74
translate chinese MLR3_NS1_rep_1c0e0cad:

    # Mom "(I can’t wait until I can feel his, steaming hot cum, flowing into my pussy again. The warmth spreading, deep inside me, as my boy fills me up.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:76
translate chinese MLR3_NS1_rep_153168dd:

    # Mom "(I can’t wait until I can feel his steaming hot cum, flowing into my pussy again. The warmth spreading, deep inside me as [player_name] fills me up.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:77
translate chinese MLR3_NS1_rep_54d149c3:

    # Mom "Ah! AHHHHHH! Mmmmmmm! OHHHHH!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:78
translate chinese MLR3_NS1_rep_c89f7710:

    # MC "(Uh oh... It looks like she’s woken up [Dad_name]!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:85
translate chinese MLR3_NS1_rep_aafd0738:

    # Dad "Christ, Linda... What in God’s name are you doing? It’s the middle of the night."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:86
translate chinese MLR3_NS1_rep_650f1e9a:

    # Dad "I don’t know about you, but I’m exhausted from my job - and if I can’t have sex in this bed, then for the love of God, at least let me have a good night’s sleep in it!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:87
translate chinese MLR3_NS1_rep_b40f0669:

    # Dad "I mean, seriously, Linda. You don’t want to have sex with me, but you’re creaming yourself, at 2am in the bloody morning!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:91
translate chinese MLR3_NS1_rep_fe1b5f2b:

    # Mom "Shit... Sorry for waking you. My bad."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:92
translate chinese MLR3_NS1_rep_709b46d3:

    # Dad "My bad? Is that all you have to say about this?"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:93
translate chinese MLR3_NS1_rep_70ba2273:

    # Mom "Yeah, I was too loud. My fault. Sorry."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:97
translate chinese MLR3_NS1_rep_49fcf3f4:

    # Dad "Linda... I know this relationship is headed the way of the Titanic, but can we at least TRY to resolve our issues?"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:98
translate chinese MLR3_NS1_rep_dd3e0e53:

    # Dad "The only thing I want right now, is for you to open up and actually talk to me."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:99
translate chinese MLR3_NS1_rep_570b132b:

    # Dad "Please... "
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:103
translate chinese MLR3_NS1_rep_72daaeaf:

    # Mom " ..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:104
translate chinese MLR3_NS1_rep_46abe98b:

    # Mom "I’m tired, Bob. I’m going to go to sleep now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:105
translate chinese MLR3_NS1_rep_d91ab79c:

    # Dad "*Sigh*"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:106
translate chinese MLR3_NS1_rep_2af8d1e3:

    # Mom "I’m sorry for waking you up."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:107
translate chinese MLR3_NS1_rep_b403152c:

    # Dad "Goodnight, Linda. Sorry I shouted, there. I love you."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS1_rep.rpy:109
translate chinese MLR3_NS1_rep_49ffb530:

    # MC "(Jesus Christ, they’re getting worse with each passing day. I wonder if I am the only cause of this. Maybe they were already on the rocks, before [Mom_name] and me hit it off?)"
    MC ""

