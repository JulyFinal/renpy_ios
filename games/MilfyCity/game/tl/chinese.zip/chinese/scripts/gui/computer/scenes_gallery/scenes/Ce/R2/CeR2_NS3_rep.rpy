﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:7
translate chinese CeR2_NS3_rep_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:8
translate chinese CeR2_NS3_rep_0d0848e6:

    # MC "(It’s okay, [player_name]. Try to relax. You can do this...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:11
translate chinese CeR2_NS3_rep_9830fd45:

    # MC "(All you have to do is sneak in, gather the evidence, and then escape.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:12
translate chinese CeR2_NS3_rep_de0f5e11:

    # MC "(I guess I’ll check out the bedroom first. Maybe there are some photos or sex toys in there I can use!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:16
translate chinese CeR2_NS3_rep_c0613901:

    # Celia "HMMM!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:17
translate chinese CeR2_NS3_rep_f6083f2d:

    # Celia "MMMPFFF!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:19
translate chinese CeR2_NS3_rep_9376faae:

    # MC "*Whispered* What the..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:22
translate chinese CeR2_NS3_rep_563268fd:

    # MC "(Oh, my God!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:23
translate chinese CeR2_NS3_rep_a762ff65:

    # MC "(Holy fucking shit!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:24
translate chinese CeR2_NS3_rep_a649ff04:

    # Celia "Hnnng! Mmmmmm! AAHMMMMM!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:30
translate chinese CeR2_NS3_rep_d3a329bf:

    # MC "Whoa..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:31
translate chinese CeR2_NS3_rep_f7061f20:

    # MC "(Judy was right! Celia is into some seriously lewd stuff!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:34
translate chinese CeR2_NS3_rep_b85d4a67:

    # MC "(A gag, vibrating nipple clamps, a handheld vibrator...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:35
translate chinese CeR2_NS3_rep_e7bd0866:

    # MC "(What the fuck is she doing with a tennis racket though?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:38
translate chinese CeR2_NS3_rep_a4e1fbf6:

    # Celia "Hnnggg.... Mmmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:39
translate chinese CeR2_NS3_rep_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:40
translate chinese CeR2_NS3_rep_c9eb920b:

    # Celia "AAAHHHHMMMM!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:43
translate chinese CeR2_NS3_rep_73720b7e:

    # Celia "Aaahhmmmffff...."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:44
translate chinese CeR2_NS3_rep_5963817a:

    # MC "(And just look at how hot that mesh bodysuit is!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:47
translate chinese CeR2_NS3_rep_ddcd503f:

    # MC "(She’s moving that tennis racket close to her boob. Is it for spanking?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:48
translate chinese CeR2_NS3_rep_918d215f:

    # MC "(I don’t think I’ve ever seen ANYTHING like it, in my life.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:49
translate chinese CeR2_NS3_rep_53247e6f:

    # MC "(Is it even a sex toy?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:53
translate chinese CeR2_NS3_rep_371aeb52:

    # "*ZAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:54
translate chinese CeR2_NS3_rep_a7948724:

    # Celia "HMMPPFFFFF!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:55
translate chinese CeR2_NS3_rep_f2fbf408:

    # MC "H-Holy shit..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:58
translate chinese CeR2_NS3_rep_6b9e2504:

    # Celia "Aahhmmm..... Mmmm....."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:59
translate chinese CeR2_NS3_rep_e2133e83:

    # MC "(She’s into being electrocuted!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:62
translate chinese CeR2_NS3_rep_c1da3b76:

    # MC "(Oh wow!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:63
translate chinese CeR2_NS3_rep_d38bcac5:

    # MC "(I never could have predicted this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:64
translate chinese CeR2_NS3_rep_752bf6a9:

    # MC "(Judy is going to LOVE hearing about this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:68
translate chinese CeR2_NS3_rep_371aeb52_1:

    # "*ZAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:69
translate chinese CeR2_NS3_rep_a9010fa6:

    # Celia "AHHHMMM!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:70
translate chinese CeR2_NS3_rep_a5c1c391:

    # Celia "OHHMMMMM!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:73
translate chinese CeR2_NS3_rep_adb4ca4a:

    # Celia "Hnnnnnngggg...."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:74
translate chinese CeR2_NS3_rep_189c5668:

    # Celia "HNNNGGGGG!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:75
translate chinese CeR2_NS3_rep_13d7b9a8:

    # MC "(She’s trembling right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:78
translate chinese CeR2_NS3_rep_71a10401:

    # Celia "(Oh fuck! I’m going to cum again!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:79
translate chinese CeR2_NS3_rep_19678efc:

    # Celia "NMMPFFFFF!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:80
translate chinese CeR2_NS3_rep_85ed899e:

    # Celia "(F-Fuck... That’s number six!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:83
translate chinese CeR2_NS3_rep_0702ceae:

    # MC "(And now she’s choking herself!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:84
translate chinese CeR2_NS3_rep_25595a8b:

    # MC "(Holy crap, this woman is seriously kinky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:88
translate chinese CeR2_NS3_rep_d150605b:

    # MC "(She probably enjoyed me blackmailing her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:90
translate chinese CeR2_NS3_rep_3d0fd9bd:

    # MC "(She probably enjoyed our roleplaying as blackmailing her, as a fun sexy joke...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:91
translate chinese CeR2_NS3_rep_1dd826ab:

    # MC "(I really have to tell Judy about all of this! She’ll know what to do next!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:94
translate chinese CeR2_NS3_rep_1103eb28:

    # Celia "HNNNNGGGGG!! MMMPFFFF!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:95
translate chinese CeR2_NS3_rep_a829be74:

    # Celia "(Oh fuck! Oh fuck! That’s the spot!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:98
translate chinese CeR2_NS3_rep_935fe48a:

    # MC "(Holy shit, she’s really putting on a great show for me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:99
translate chinese CeR2_NS3_rep_ca8045da:

    # Celia "MMMPPFFF! HNNNNGGGG!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:102
translate chinese CeR2_NS3_rep_6cf7289a:

    # Celia "(Where did I put my electric bat?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:103
translate chinese CeR2_NS3_rep_10583be3:

    # Celia "(I need it for my climax!!!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:107
translate chinese CeR2_NS3_rep_371aeb52_2:

    # "*ZAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:108
translate chinese CeR2_NS3_rep_9cdaa881:

    # Celia "HNNNGGGGGFFFFF!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:109
translate chinese CeR2_NS3_rep_49405fd7:

    # MC "(Oh my God! She just used it directly on her pussy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:113
translate chinese CeR2_NS3_rep_bedf0713:

    # MC "(This couldn’t have worked out any better for me. I’ll have everything I need to end Celia’s torture!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:115
translate chinese CeR2_NS3_rep_874fb633:

    # MC "(This couldn’t have worked out any better! I have everything I need to regain the upper hand in our roleplay!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:116
translate chinese CeR2_NS3_rep_b9b23b8d:

    # MC "Mwahahaha..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:120
translate chinese CeR2_NS3_rep_371aeb52_3:

    # "*ZAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:122
translate chinese CeR2_NS3_rep_6afada55:

    # "*ZAP ZAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:123
translate chinese CeR2_NS3_rep_e7827d35:

    # Celia "Eeaaaayyaahhhhhhhh!!!! MMPFFFF!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:126
translate chinese CeR2_NS3_rep_6d214b08:

    # Celia "*GASP*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:127
translate chinese CeR2_NS3_rep_8a328116:

    # MC "(I wish I could just dive onto her right now and start slamming my cock into her pussy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:130
translate chinese CeR2_NS3_rep_5e55e8e3:

    # Celia "(F-Fuck! I’m cumming again!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:131
translate chinese CeR2_NS3_rep_da0d8c46:

    # Celia "AAAAYAAAAHHHHHHHHH!!! HNNNNGGGG!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:134
translate chinese CeR2_NS3_rep_9657d606:

    # Celia "AAAHHHHHMMMMMM!!!! MMMMMFFFFF!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:135
translate chinese CeR2_NS3_rep_2452de5c:

    # Celia "*Pant Pant*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:138
translate chinese CeR2_NS3_rep_be4ca4dc:

    # MC "(She’s shaking and trembling like crazy right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:139
translate chinese CeR2_NS3_rep_aa8ff184:

    # MC "(I don’t think I’ve ever seen a woman climax, so hard, in my life!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:141
translate chinese CeR2_NS3_rep_d2c67290:

    # MC "(I better leave now. I’m so dead if she catches me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:143
translate chinese CeR2_NS3_rep_4024a1ec:

    # MC "(I better leave right now... Got a lot of work to do!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:146
translate chinese CeR2_NS3_rep_48c1e588:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:149
translate chinese CeR2_NS3_rep_2452de5c_1:

    # Celia "*Pant Pant*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:150
translate chinese CeR2_NS3_rep_9adaacef:

    # Celia "*Gasp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS3_rep.rpy:151
translate chinese CeR2_NS3_rep_27d34b07:

    # Celia "W-Wow... That was... fucking amazing..."
    Celia ""

