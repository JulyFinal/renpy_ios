﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:9
translate chinese CeR2_NS1a_rep_1582bd93:

    # Celia "Alright. Please, PLEASE tell me you’ve got some good news."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:10
translate chinese CeR2_NS1a_rep_34629128:

    # MC "Don’t worry, I’ve made some progress. We’re closing in on them."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:11
translate chinese CeR2_NS1a_rep_0ab51aab:

    # Celia "Excellent."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:14
translate chinese CeR2_NS1a_rep_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:15
translate chinese CeR2_NS1a_rep_aad4648f:

    # MC "(Time to misdirect her attention to a completely different set of students now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:18
translate chinese CeR2_NS1a_rep_cdfe1e0b:

    # MC "It was risky having me investigate this though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:19
translate chinese CeR2_NS1a_rep_5f923e68:

    # Celia "What are you talking about?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:22
translate chinese CeR2_NS1a_rep_7fc3bc0f:

    # MC "I mean, what if the blackmailer noticed me? He, or she, could try and blackmail me too!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:23
translate chinese CeR2_NS1a_rep_98edb1f1:

    # Celia "*Sigh* I see what you’re getting at. Fine, what do you want this time?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:24
translate chinese CeR2_NS1a_rep_89318d0a:

    # MC "I simply want you to suck my dick."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:27
translate chinese CeR2_NS1a_rep_fdc321d1:

    # Celia "Tell me what you know, first, and I’ll decide if the information is worth a blowjob."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:28
translate chinese CeR2_NS1a_rep_0b2ce7ac:

    # MC "How do I know you’ll actually do it for me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:29
translate chinese CeR2_NS1a_rep_c99ae696:

    # Celia "Do you have any doubts that it is good information you are giving me?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:30
translate chinese CeR2_NS1a_rep_a99f00b8:

    # MC "No."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:31
translate chinese CeR2_NS1a_rep_27c6c4f4:

    # Celia "Then I’ll be sucking your dick, but you’re going to need to tell me what you know first."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:34
translate chinese CeR2_NS1a_rep_2862f011:

    # MC "Fine. Deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:35
translate chinese CeR2_NS1a_rep_1b09a671:

    # MC "I’ve searched my entire class. I’ve spoken with everyone and listened in to all the gossip of the day."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:36
translate chinese CeR2_NS1a_rep_c845bf07:

    # Celia "And?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:39
translate chinese CeR2_NS1a_rep_9fd4a214:

    # MC "None of them are linked to this."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:40
translate chinese CeR2_NS1a_rep_ad059d70:

    # Celia "God dammit..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:41
translate chinese CeR2_NS1a_rep_8e94d07b:

    # MC "This is good news! We can rule out your students! It has to be someone in a different professor's group!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:44
translate chinese CeR2_NS1a_rep_66f01b63:

    # Celia "Hmm, I do teach quite a few classes."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:45
translate chinese CeR2_NS1a_rep_de33da21:

    # Celia "You have no idea who did it? A name? A description?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:46
translate chinese CeR2_NS1a_rep_352a4c90:

    # MC "The only thing I know, is that they are probably male."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:49
translate chinese CeR2_NS1a_rep_00094839:

    # Celia "Ugh! Well, at least we've ruled out one batch of students."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:50
translate chinese CeR2_NS1a_rep_9797bab9:

    # MC "True, it knocks off about twenty students. We’re making great progress."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:53
translate chinese CeR2_NS1a_rep_6583ea43:

    # Celia "I need to ask a favour of you now."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:54
translate chinese CeR2_NS1a_rep_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:55
translate chinese CeR2_NS1a_rep_b3ede99d:

    # Celia "Do you know the security camera room?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:56
translate chinese CeR2_NS1a_rep_75381924:

    # MC "Yeah, I think so."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:58
translate chinese CeR2_NS1a_rep_a730b94b:

    # Celia "I reckon we can catch the blackmailer on camera."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:59
translate chinese CeR2_NS1a_rep_4ab2f375:

    # Celia "There’s a camera positioned directly outside the men’s toilets. All I have to do is look and see who goes into there before me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:61
translate chinese CeR2_NS1a_rep_c28fb025:

    # Celia "(Haha! That would end our BDSM relationship if he did not even think of that! I hope [player_name] is not that stupid.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:62
translate chinese CeR2_NS1a_rep_5fb1e495:

    # MC "(Shit! Why didn’t I think about the cameras?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:64
translate chinese CeR2_NS1a_rep_5fcca09c:

    # MC "Th-That’s a great idea! (Fuck! She’s really smart!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:65
translate chinese CeR2_NS1a_rep_ffc7408b:

    # Celia "I can’t do it myself though. The guard would see me walking into the boy’s toilets."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:66
translate chinese CeR2_NS1a_rep_c504c37f:

    # MC "So, that’s why you need me! I can go in and view the footage for you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:69
translate chinese CeR2_NS1a_rep_7a8a191b:

    # Celia "Bingo."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:70
translate chinese CeR2_NS1a_rep_ea865e0d:

    # MC "Okay, I think we’ve got a solid plan going on here."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:72
translate chinese CeR2_NS1a_rep_87fec9ea:

    # Celia "Bingo. Of course, I want you to record that as well with your smartphone. That wouldn't be a problem [player_name]?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:73
translate chinese CeR2_NS1a_rep_f663ea50:

    # MC "N-No not all. I think we’ve got a solid plan going on here."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:76
translate chinese CeR2_NS1a_rep_012c6970:

    # MC "So, about that blowjob..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:77
translate chinese CeR2_NS1a_rep_42dd7e20:

    # Celia "Yeah, yeah. You did alright..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:80
translate chinese CeR2_NS1a_rep_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:82
translate chinese CeR2_NS1a_rep_26ef2ba2:

    # Celia "I need you to keep working this case for me though. You’ve made more progress in a day than I have in a week!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:84
translate chinese CeR2_NS1a_rep_5dc3ef34:

    # Celia "I need you to keep working on this case for me though. You've made more progress in a day than I have in a week! (Also... This whole acting is starting to be nice in a different way...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:90
translate chinese CeR2_NS1a_rep_a9230c82:

    # MC "Thanks, Celia. Now it’s time for you to use that pretty little mouth of yours!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:91
translate chinese CeR2_NS1a_rep_0148a7e8:

    # Celia "Yeah... fine."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:92
translate chinese CeR2_NS1a_rep_c3efda89:

    # MC "Mind if I put my finger in first?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:95
translate chinese CeR2_NS1a_rep_2af1372b:

    # Celia "Wha-"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:96
translate chinese CeR2_NS1a_rep_65ed375e:

    # MC "Mmm, I can’t wait to feel your lips wrapped tightly around my shaft."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:100
translate chinese CeR2_NS1a_rep_20c73366:

    # "*Slap*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:101
translate chinese CeR2_NS1a_rep_fe52187c:

    # Celia "Alright, enough of this nonsense. Stand up and take your clothes off."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:102
translate chinese CeR2_NS1a_rep_90c52b84:

    # MC "Okay!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:105
translate chinese CeR2_NS1a_rep_9eb42abf:

    # MC "Ready!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:106
translate chinese CeR2_NS1a_rep_a1e7ef78:

    # Celia "You’ve still got your pants on."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:107
translate chinese CeR2_NS1a_rep_e7601482:

    # MC "I was kinda hoping you’d help with that part."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:110
translate chinese CeR2_NS1a_rep_104cadc2:

    # Celia "*Sigh*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:111
translate chinese CeR2_NS1a_rep_2ca4b487:

    # Celia "You’re not making this easy for me, you know that?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:112
translate chinese CeR2_NS1a_rep_2ff890a3:

    # MC "Sorry. I just worked hard to get you that information, and now I really want to enjoy the reward for it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:115
translate chinese CeR2_NS1a_rep_e4137da9:

    # MC "(Fuck, her breasts look incredible from this angle!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:116
translate chinese CeR2_NS1a_rep_85f970a0:

    # MC "(I can see right down her cleavage!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:119
translate chinese CeR2_NS1a_rep_0ecd0010:

    # Celia "Hard already?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:120
translate chinese CeR2_NS1a_rep_d9d31f7b:

    # MC "What can I say? I was excited from the moment you agreed to suck my dick."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:121
translate chinese CeR2_NS1a_rep_97280197:

    # Celia "Fine, let’s get this finished."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:124
translate chinese CeR2_NS1a_rep_009dc290:

    # Celia "*Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:125
translate chinese CeR2_NS1a_rep_2786c3d7:

    # MC "Ohh... yeah... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:128
translate chinese CeR2_NS1a_rep_cbcec2e8:

    # MC "(Ugh! Her mouth is so hot and wet! It feels amazing wrapped around my cock like that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:129
translate chinese CeR2_NS1a_rep_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:130
translate chinese CeR2_NS1a_rep_eb0a0c57:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:133
translate chinese CeR2_NS1a_rep_c445d6f2:

    # Celia "(Okay, time to go to town on this boy’s dick. He won’t last two minutes if I put some effort into this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:135
translate chinese CeR2_NS1a_rep_009dc290_1:

    # Celia "*Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:136
translate chinese CeR2_NS1a_rep_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:139
translate chinese CeR2_NS1a_rep_98352518:

    # Celia "Mppfff!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:140
translate chinese CeR2_NS1a_rep_77f7ca97:

    # MC "Ohhhh... holy fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:141
translate chinese CeR2_NS1a_rep_198a3323:

    # Celia "*Shlluurrrp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:144
translate chinese CeR2_NS1a_rep_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:145
translate chinese CeR2_NS1a_rep_f1bedc9e:

    # MC "Mmm! Damn, you’re so good at this, Celia!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:146
translate chinese CeR2_NS1a_rep_009dc290_2:

    # Celia "*Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:149
translate chinese CeR2_NS1a_rep_0a72f13a:

    # Celia "*Shlurp* *Suck* *SHLUURRRRP*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:151
translate chinese CeR2_NS1a_rep_bcfc55da:

    # MC "Ahh! Ahhh... Hnnnnggg.... Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:154
translate chinese CeR2_NS1a_rep_15c61d5f:

    # Celia "*SHLURP* *SUCK*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:156
translate chinese CeR2_NS1a_rep_6fefa6cf:

    # MC "Ahh... H-Holy fuck... Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:157
translate chinese CeR2_NS1a_rep_b9d9e23e:

    # MC "(Fuck, I’m going to start thrusting! I want to feel my cock in her throat!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:160
translate chinese CeR2_NS1a_rep_9ce16e89:

    # Celia "NNNMMPFFFF?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:162
translate chinese CeR2_NS1a_rep_cc61c6e4:

    # Celia "*SPLUTTER* *GAG*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:164
translate chinese CeR2_NS1a_rep_ad55eeff:

    # MC "HNNNGGG!! UGH!!! Oh fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:166
translate chinese CeR2_NS1a_rep_009dc290_3:

    # Celia "*Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:169
translate chinese CeR2_NS1a_rep_75c6d02a:

    # Celia "(Fuck! He gave me no warning at all!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:170
translate chinese CeR2_NS1a_rep_59627aab:

    # Celia "(I’m gonna need to change my panties after he leaves - he’s making me all wet, treating me like this!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:171
translate chinese CeR2_NS1a_rep_46aa2b5b:

    # Celia "*GAG* *SHLURP*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:174
translate chinese CeR2_NS1a_rep_65302a41:

    # MC "Ah! Ugh! Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:175
translate chinese CeR2_NS1a_rep_a550070a:

    # Celia "*SHLURP* *SUCK SUCK*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:176
translate chinese CeR2_NS1a_rep_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:179
translate chinese CeR2_NS1a_rep_27952c5d:

    # Celia "*GAG* *SPLUTTER*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:180
translate chinese CeR2_NS1a_rep_a8e62204:

    # MC "Hnnnggg! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:181
translate chinese CeR2_NS1a_rep_c114ec84:

    # Celia "*SUCK SUCK SUCK*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:184
translate chinese CeR2_NS1a_rep_7483a7dc:

    # MC "Aaahh! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:185
translate chinese CeR2_NS1a_rep_1232e993:

    # MC "(Should I cum in her mouth or over her face?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:189
translate chinese CeR2_NS1a_rep_097f355d:

    # MC "I’m gonna cum! Stick out your tongue!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:192
translate chinese CeR2_NS1a_rep_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:193
translate chinese CeR2_NS1a_rep_df786ee5:

    # MC "UGHHH! AAHHHHH! Hnnnngg!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:202
translate chinese CeR2_NS1a_rep_e7cd61bb:

    # Celia "(Ugh, the things a girl has to do to get by in the world...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:204
translate chinese CeR2_NS1a_rep_92d1c390:

    # Celia "(Mmm... It really turns me on when he uses my body like that. I’m gonna have some fun with my vibrator when he leaves.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:214
translate chinese CeR2_NS1a_rep_9434b032:

    # MC "Fuck, I’m going to blow my load over your face!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:217
translate chinese CeR2_NS1a_rep_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:218
translate chinese CeR2_NS1a_rep_9d747446:

    # Celia "(This is fine.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:219
translate chinese CeR2_NS1a_rep_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:220
translate chinese CeR2_NS1a_rep_c1e5aa30:

    # Celia "(I’m honestly okay with this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:221
translate chinese CeR2_NS1a_rep_643f27ba:

    # MC "Fuck! Ahhh! Hnnnggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:230
translate chinese CeR2_NS1a_rep_89c49931:

    # Celia "(It’s not like I spent half an hour putting my fucking makeup together.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:231
translate chinese CeR2_NS1a_rep_18224611:

    # MC "*Pant* That was amazing..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS1a_rep.rpy:232
translate chinese CeR2_NS1a_rep_622ab713:

    # Celia "(Dickhead.)"
    Celia ""

