﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:7
translate chinese CeR2_NS2_rep_4ecebbcf:

    # MC "(Wow, I came at the perfect time!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:8
translate chinese CeR2_NS2_rep_ad02068a:

    # MC "(She hasn’t even stepped into the shower yet!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:12
translate chinese CeR2_NS2_rep_c976f868:

    # "*Creeak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:13
translate chinese CeR2_NS2_rep_09519923:

    # MC "(She must have spent more time training, after I left.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:14
translate chinese CeR2_NS2_rep_9c9c81c3:

    # MC "(Or maybe she just wanted to hide that picture of me she had hanging up.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:17
translate chinese CeR2_NS2_rep_c7b09304:

    # MC "(Hehe, this is going to be awesome!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:18
translate chinese CeR2_NS2_rep_c149b0fd:

    # MC "(She won’t suspect a thing. I’ll be back in the living room before she leaves.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:21
translate chinese CeR2_NS2_rep_343f60ec:

    # MC "(Oh yeah, that’s it, Celia. Soap your body up for me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:22
translate chinese CeR2_NS2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:25
translate chinese CeR2_NS2_rep_6aaac2b3:

    # MC "(God, I wish I was in that shower with her right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:26
translate chinese CeR2_NS2_rep_f1ffb5e5:

    # MC "(I would do unspeakably dirty things to her in there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:29
translate chinese CeR2_NS2_rep_478feb75:

    # MC "(And her ass is fucking perfect!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:30
translate chinese CeR2_NS2_rep_0bcc8a82:

    # MC "(I’d bend her over, make her put her hands up against the glass, and then ram my cock inside her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:33
translate chinese CeR2_NS2_rep_906d1d4e:

    # MC "(She’d be screaming with pleasure as I fucked her, over and over.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:34
translate chinese CeR2_NS2_rep_59f7dc83:

    # MC "(And I’d play with those massive tits she has, while I’m doing it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:38
translate chinese CeR2_NS2_rep_efebe60a:

    # MC "(I’d make that bitch cum so hard, that she would wish she’d never turned me down.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:40
translate chinese CeR2_NS2_rep_e384b72e:

    # MC "(I’d make her cum soooo fucking hard, that the neighbours would hear her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:41
translate chinese CeR2_NS2_rep_d4265a79:

    # MC "(She would be screaming my name as she climaxed again and again.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:44
translate chinese CeR2_NS2_rep_865e2f17:

    # MC "(Fuck, I wish I had a camera on me right now to take some pictures.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:45
translate chinese CeR2_NS2_rep_75d4389e:

    # MC "(Probably too risky anyway. I wouldn’t get a good photo with all the condensation in the room.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:48
translate chinese CeR2_NS2_rep_845c19ac:

    # MC "(Oh yeah, just like that, Celia. Let’s see those big titties of yours!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:49
translate chinese CeR2_NS2_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:52
translate chinese CeR2_NS2_rep_be94fa59:

    # MC "(You’re so fucking hot.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:55
translate chinese CeR2_NS2_rep_0daff976:

    # MC "(Wash your boobs and pussy for me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:56
translate chinese CeR2_NS2_rep_5ed906d9:

    # MC "(I want to see your hands rub all over your body.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:59
translate chinese CeR2_NS2_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:60
translate chinese CeR2_NS2_rep_7c7a1871:

    # MC "(That’s it, Celia. Just like that!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:63
translate chinese CeR2_NS2_rep_e4ad642b:

    # MC "(Damn, I’ve got the biggest boner right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:64
translate chinese CeR2_NS2_rep_2c0a537e:

    # MC "(At least Celia will be able to help me out with that when she finishes her shower.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:67
translate chinese CeR2_NS2_rep_96ff609e:

    # MC "(I wonder if I should request another blowjob tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:68
translate chinese CeR2_NS2_rep_926f64a5:

    # MC "(Or maybe to fuck her tits?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:69
translate chinese CeR2_NS2_rep_fe10e82b:

    # Celia "Huh?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:72
translate chinese CeR2_NS2_rep_84cde9b7:

    # MC "(Shit, time to abort!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:73
translate chinese CeR2_NS2_rep_eec566cc:

    # MC "(I don’t think she saw me yet. I won’t risk it though.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:77
translate chinese CeR2_NS2_rep_48c1e588:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:79
translate chinese CeR2_NS2_rep_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:85
translate chinese CeR2_NS2_rep_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:86
translate chinese CeR2_NS2_rep_ce366a8d:

    # MC "(My heart’s pounding right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:87
translate chinese CeR2_NS2_rep_4fc7adc3:

    # MC "(This is gonna be okay, just relax. Breathe. She didn't see you.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:90
translate chinese CeR2_NS2_rep_5b438910:

    # MC "(I’ll just go back to the living room and wait for her there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:91
translate chinese CeR2_NS2_rep_d6b10443:

    # MC "(I can act as if nothing happened.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:94
translate chinese CeR2_NS2_rep_983de9fb:

    # MC "(Fuck, I better be quick!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_NS2_rep.rpy:95
translate chinese CeR2_NS2_rep_5761a25d:

    # MC "(She won’t take long drying her body down!)"
    MC ""

