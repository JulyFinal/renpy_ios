﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:13
translate chinese CR4_NS1_rep_498f28db:

    # MC "(Ahh, there she is! I don’t know why I was worried - Caroline told me to meet her where we had our first kiss.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:14
translate chinese CR4_NS1_rep_7affdba5:

    # MC "(She’s on the exact same stone bench. I can still remember that night as clearly as I’m looking at her right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:15
translate chinese CR4_NS1_rep_6ba09790:

    # MC "Evening, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:16
translate chinese CR4_NS1_rep_ad2cb933:

    # Caroline "Hey! You remembered the spot!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:17
translate chinese CR4_NS1_rep_36f4c818:

    # MC "Haha, of course I did! And now that I’m here, I’ve got something very important to tell you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:21
translate chinese CR4_NS1_rep_1ac7ef12:

    # Caroline "Oh? Is everything alright?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:22
translate chinese CR4_NS1_rep_82544783:

    # Caroline "(Oh no... He’s going to break up with me, isn’t he?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:23
translate chinese CR4_NS1_rep_f23fb640:

    # MC "Don’t look so worried! Everything’s fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:24
translate chinese CR4_NS1_rep_ca1437e3:

    # Caroline "Okay, but... what’s the super important thing you wanted to tell me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:25
translate chinese CR4_NS1_rep_a2933087:

    # MC "There is a gorgeous reflection of the moon shining over the lake right in front of me - but I’d rather keep my eyes on you. You’re far more beautiful than the clearest night sky."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:29
translate chinese CR4_NS1_rep_a9820957:

    # Caroline "Thank you, [player_name]. That’s the most beautiful thing anyone has ever said to me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:30
translate chinese CR4_NS1_rep_f691e4c9:

    # MC "May I kiss you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:31
translate chinese CR4_NS1_rep_1b144d19:

    # Caroline "I’d love that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:35
translate chinese CR4_NS1_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:36
translate chinese CR4_NS1_rep_f788a7c2:

    # MC "(I don’t know how I came up with that line so quickly. Being near Caroline awakens an intense creativity within me I’ve never felt before.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:37
translate chinese CR4_NS1_rep_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:41
translate chinese CR4_NS1_rep_a40b039a:

    # Caroline "(My heart’s still fluttering from what he said. He must have spent all day trying to come up with that one.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:42
translate chinese CR4_NS1_rep_4bf4bcde:

    # Caroline "(Or maybe he just searched for pick-up lines on the internet.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:46
translate chinese CR4_NS1_rep_d51e6539:

    # Caroline "So... Tell me the truth."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:47
translate chinese CR4_NS1_rep_a7de562d:

    # MC "The truth? About what?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:48
translate chinese CR4_NS1_rep_657e672b:

    # Caroline "Oh, c’mon. You know! That line about the moon! Where’d you learn it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:52
translate chinese CR4_NS1_rep_d2587398:

    # MC "I didn’t learn it anywhere, Caroline. It just came to me while I was looking at you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:53
translate chinese CR4_NS1_rep_9767219a:

    # Caroline "Suuure."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:54
translate chinese CR4_NS1_rep_ec43ba42:

    # MC "I’m serious!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:58
translate chinese CR4_NS1_rep_5028e296:

    # Caroline "When have YOU ever been a Shakespeare?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:59
translate chinese CR4_NS1_rep_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:61
translate chinese CR4_NS1_rep_44424f01:

    # Caroline "I mean, I’ve known you for your whole life and I’ve never heard you speak like that about anything or to anyone!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:63
translate chinese CR4_NS1_rep_c3969a77:

    # Caroline "I mean, I've known you for a while now and I've never heard you seak like that to anything or anyone!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:67
translate chinese CR4_NS1_rep_03174e02:

    # MC "I told you, it just came to me. I was inspired by seeing you sit under the moonlight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:68
translate chinese CR4_NS1_rep_7989d147:

    # MC "Is everything okay, Caroline? You seem a little on edge tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:69
translate chinese CR4_NS1_rep_7cf6f761:

    # Caroline "No, I mean, yeah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:73
translate chinese CR4_NS1_rep_88121271:

    # MC "(Huh, something seems to be worrying her. I wonder if she wants to talk about it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:74
translate chinese CR4_NS1_rep_23072611:

    # MC "Can you tell me what's going on? If there’s a problem, I can help fix it. You know I will. Think back to when you needed money for your shop - I ALWAYS had your back."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:75
translate chinese CR4_NS1_rep_c1b7500e:

    # MC "And I always will."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:79
translate chinese CR4_NS1_rep_7e42f5cb:

    # Caroline "Alright, listen... I..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:80
translate chinese CR4_NS1_rep_d5aefe35:

    # MC "It’s okay. Just take your time and think of what you want to say. Don’t rush it out."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:84
translate chinese CR4_NS1_rep_92696398:

    # Caroline "When I... Umm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:85
translate chinese CR4_NS1_rep_96467ca0:

    # Caroline "(Fuck. This is tough...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:86
translate chinese CR4_NS1_rep_67913229:

    # Caroline "When I was with... Charles... I..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:87
translate chinese CR4_NS1_rep_5461960b:

    # Caroline "He always kept..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:91
translate chinese CR4_NS1_rep_1e06ace6:

    # Caroline "Y-You better not hurt me like he did, okay?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:92
translate chinese CR4_NS1_rep_4d2ba7a5:

    # Caroline "I’m not going to go through hell again for some stupid guy!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:93
translate chinese CR4_NS1_rep_88b8dea0:

    # MC "(Ahh, I see where this is going.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:97
translate chinese CR4_NS1_rep_438dea58:

    # Caroline "So, if you feel like... cheating on me or... shouting at me in the middle of a crowded shopping mall."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:98
translate chinese CR4_NS1_rep_1931e776:

    # Caroline "Or if you think you’d ever hit me after drinking a bit too much after a night out with your buddies... please just... go now - and we’ll finish it before this gets any more serious."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:99
translate chinese CR4_NS1_rep_a3bb982c:

    # Caroline "I don’t think I’d survive going through that again."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:103
translate chinese CR4_NS1_rep_19af2154:

    # MC "Caroline..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:104
translate chinese CR4_NS1_rep_d71affb8:

    # MC "I’m not your ex. I’m not going to hurt you like your ex did."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:105
translate chinese CR4_NS1_rep_a6e164a0:

    # MC "I’m not going to leave during the trailers. I’m by your side until the credits roll."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:112
translate chinese CR4_NS1_rep_0b195746:

    # Caroline "Okay, now I KNOW for CERTAIN that you searched these lines before our date tonight!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:113
translate chinese CR4_NS1_rep_b833c882:

    # MC "Haha! I didn’t, I swear!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:114
translate chinese CR4_NS1_rep_d2ade0cb:

    # Caroline "Hmm, alright, I’ll give you the benefit of the doubt this time! Haha!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:115
translate chinese CR4_NS1_rep_10cb5130:

    # Caroline "Now, how about I give you something else too?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:116
translate chinese CR4_NS1_rep_1b83645d:

    # MC "What were you thinking of?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:117
translate chinese CR4_NS1_rep_b892d18a:

    # Caroline "Would you like me to wrap my lips around your fat cock, and suck you dry?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:118
translate chinese CR4_NS1_rep_2f72bc4d:

    # MC "Mmm, fuck yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:122
translate chinese CR4_NS1_rep_88296784:

    # Caroline "Oh my, you’re already hard! I thought my breakdown there might have turned you off!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:123
translate chinese CR4_NS1_rep_86bc2254:

    # MC "Relax. Nothing you do is going to turn me off, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:124
translate chinese CR4_NS1_rep_63a20bd6:

    # Caroline "You have a really beautiful cock, you know that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:128
translate chinese CR4_NS1_rep_64992a73:

    # MC "Seems kinda weird to call a cock “beautiful”."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:129
translate chinese CR4_NS1_rep_7bfecc74:

    # Caroline "Hehe, I suppose so. Yours looks really nice though. Very suckable."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:130
translate chinese CR4_NS1_rep_cb0b1342:

    # Caroline "Now, are you ready for me to blow your mind?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:134
translate chinese CR4_NS1_rep_69a69a87:

    # MC "I’m looking forward to it!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:135
translate chinese CR4_NS1_rep_02de43a5:

    # Caroline "Can you spread your legs a little more for me? I just need a bit more room to work."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:136
translate chinese CR4_NS1_rep_4255fe22:

    # MC "How’s that now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:137
translate chinese CR4_NS1_rep_b2b43a26:

    # Caroline "Absolutely perfect."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:141
translate chinese CR4_NS1_rep_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:142
translate chinese CR4_NS1_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:143
translate chinese CR4_NS1_rep_f697ae3f:

    # Caroline "(I can feel his thighs clench each time I drag my tongue over his frenulum. He’s really enjoying this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:147
translate chinese CR4_NS1_rep_26bfecfa:

    # MC "Ah... fuck."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:148
translate chinese CR4_NS1_rep_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:150
translate chinese CR4_NS1_rep_d3a12f84:

    # MC "God... Just like that. Mmm! Can you start at the base and work your way up?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:151
translate chinese CR4_NS1_rep_8d19b83a:

    # Caroline "Uh huh."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:155
translate chinese CR4_NS1_rep_cba6a38a:

    # MC "Ahh... Shit..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:156
translate chinese CR4_NS1_rep_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:158
translate chinese CR4_NS1_rep_1f9e6117:

    # Caroline "*Sluuurrrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:162
translate chinese CR4_NS1_rep_6c72382b:

    # Caroline "(It’s so quiet out here at night - there’s nothing in the air except the sound of chirping cicadas.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:163
translate chinese CR4_NS1_rep_0b2482b9:

    # Caroline "(His breathing is getting faster now, I’ll go up and down his shaft a couple more times, and then engulf his cock in my mouth.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:167
translate chinese CR4_NS1_rep_9a76b28e:

    # MC "Oh fuck, just like that, Caroline. Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:169
translate chinese CR4_NS1_rep_951cc58a:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:173
translate chinese CR4_NS1_rep_1aa36d5b:

    # MC "Ahh... Fuck... Yes..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:174
translate chinese CR4_NS1_rep_c12b37dd:

    # Caroline "*Liiiiiccccck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:175
translate chinese CR4_NS1_rep_c159c162:

    # Caroline "(His cock is twitching with each flick of my tongue. I wonder how long he’ll last?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:179
translate chinese CR4_NS1_rep_bcf6065d:

    # MC "(I wish this moment would never end. This is heavenly!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:180
translate chinese CR4_NS1_rep_a61d2fd8:

    # MC "You’re so good at that. Mmm! Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:181
translate chinese CR4_NS1_rep_951cc58a_1:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:185
translate chinese CR4_NS1_rep_e538bc98:

    # Caroline "(I think that’s [player_name] suitably warmed up - time for the main event!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:186
translate chinese CR4_NS1_rep_7d191740_2:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:187
translate chinese CR4_NS1_rep_47fd04f8:

    # MC "(Her tongue is so warm! I love the feeling of her, slowly lapping her way up my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:191
translate chinese CR4_NS1_rep_fb32e779_1:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:192
translate chinese CR4_NS1_rep_ff5ba78d:

    # Caroline "(I can hear his heart beating through his shirt. It looks like my tongue’s really got his blood flowing!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:193
translate chinese CR4_NS1_rep_f733f981:

    # Caroline "*Slurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:194
translate chinese CR4_NS1_rep_9c1ed6bb:

    # Caroline "(Time to take the tip of his cock in my mouth now.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:198
translate chinese CR4_NS1_rep_8a391467:

    # MC "Ahh... Yes! Ohhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:199
translate chinese CR4_NS1_rep_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:200
translate chinese CR4_NS1_rep_f2f49b9f:

    # Caroline "(He’s quivering now. I love the way he can’t resist my mouth pleasuring him, down there.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:204
translate chinese CR4_NS1_rep_1ae8aaf4:

    # MC "Oh my God... You’re so good at that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:205
translate chinese CR4_NS1_rep_e0cee18c:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:206
translate chinese CR4_NS1_rep_d7fb4eb4:

    # MC "Can you ugh... go deeper? "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:210
translate chinese CR4_NS1_rep_a1f5f8b7:

    # Caroline "*Shlurrrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:211
translate chinese CR4_NS1_rep_23da9308_1:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:212
translate chinese CR4_NS1_rep_8f2a8573:

    # MC "Oh fuck! Hnnnggg.... Deeper! Ah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:216
translate chinese CR4_NS1_rep_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:217
translate chinese CR4_NS1_rep_5ecb200d:

    # Caroline "*SHLUUURRRRP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:219
translate chinese CR4_NS1_rep_0fcbb5c5:

    # MC "Ugh! Ahhhhhh! Yes! Mmmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:220
translate chinese CR4_NS1_rep_1f48ebd4:

    # Caroline "(Time to suck you dry, [player_name]!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:224
translate chinese CR4_NS1_rep_35aeaed4:

    # Caroline "*SHLLUURRRRRRP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:226
translate chinese CR4_NS1_rep_b3f0608d:

    # MC "Oh, my God! Yes! Mmm! Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:227
translate chinese CR4_NS1_rep_f1a30237:

    # MC "(Holy shit, it’s so fucking intense!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:231
translate chinese CR4_NS1_rep_14b73e35:

    # MC "You’re ah-aaahhmmazing! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:233
translate chinese CR4_NS1_rep_7d31255b:

    # Caroline "*SUCK SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:235
translate chinese CR4_NS1_rep_3cbcaad7:

    # MC "Don’t stop! Keep sucking my cock! Hnnnggg.... Aaarrghh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:239
translate chinese CR4_NS1_rep_a0307c02:

    # Caroline "(I’ll start picking up the pace now. This should really bring him close to a climax.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:241
translate chinese CR4_NS1_rep_e0cee18c_1:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:243
translate chinese CR4_NS1_rep_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:247
translate chinese CR4_NS1_rep_7abe0eef:

    # MC "Mmm, holy fuck! Yes! Yes! Keep going, I’m so fucking close!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:248
translate chinese CR4_NS1_rep_2e746551:

    # Caroline "Mmmpfff!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:249
translate chinese CR4_NS1_rep_c25752a2:

    # Caroline "*SHLURP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:253
translate chinese CR4_NS1_rep_39da96e9:

    # MC "Fuck! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:255
translate chinese CR4_NS1_rep_7d31255b_1:

    # Caroline "*SUCK SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:256
translate chinese CR4_NS1_rep_cd3a1094:

    # MC "Ahhh! HNNNGGG!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:261
translate chinese CR4_NS1_rep_24e3b64a:

    # Caroline "(Oh wow! I can taste his hot salty cum, filling up my mouth!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:262
translate chinese CR4_NS1_rep_a96656a6:

    # MC "Hnnng! Ugh! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:263
translate chinese CR4_NS1_rep_54d3900c:

    # Caroline "*Suck* *Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:274
translate chinese CR4_NS1_rep_c821daf5:

    # MC "*Pant* That was *Pant* incredible."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:275
translate chinese CR4_NS1_rep_32053a88:

    # Caroline "Ahh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:279
translate chinese CR4_NS1_rep_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:280
translate chinese CR4_NS1_rep_7c6f49c1:

    # MC "(Oh fuck... That’s hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:284
translate chinese CR4_NS1_rep_a98290a3:

    # Caroline "Well? What did you think? I got that last part from a porno I watched, a few nights back."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:285
translate chinese CR4_NS1_rep_18a588b4:

    # MC "It was insanely sexy, watching you swallow my cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:286
translate chinese CR4_NS1_rep_ab0d02ab:

    # Caroline "Hehe, I’m glad you liked it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:287
translate chinese CR4_NS1_rep_0de80242:

    # Caroline "That wasn’t the only surprise I have for you tonight though. I’m going to need you to give me five minutes, for the next surprise."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:288
translate chinese CR4_NS1_rep_36daacf1:

    # MC "Sure, what do you want me to do?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:289
translate chinese CR4_NS1_rep_65e9a16f:

    # Caroline "Just sit and wait right here. Focus on getting your guy stiff again - you’ll be needing him."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:290
translate chinese CR4_NS1_rep_af21b99c:

    # MC "Ohh, I like the sound of this!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1_rep.rpy:291
translate chinese CR4_NS1_rep_761d9fd6:

    # Caroline "I’ll be back in five! No peeking!"
    Caroline ""

