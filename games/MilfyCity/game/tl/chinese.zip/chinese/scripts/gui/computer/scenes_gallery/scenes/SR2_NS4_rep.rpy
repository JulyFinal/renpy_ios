﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:15
translate chinese SR2_NS4_rep_382bb2dd:

    # MC "(Sara is still looking especially nervous. The whole, painful sex on the roof, must have really gotten to her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:16
translate chinese SR2_NS4_rep_22ea7ceb:

    # MC "(I’ll have to tread carefully and take things slowly. I don’t want to hurt her again.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:18
translate chinese SR2_NS4_rep_c203311f:

    # MC "(Sara is still looking especially nervous. The whole, sex on the roof, must have really gotten to her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:19
translate chinese SR2_NS4_rep_2165986d:

    # MC "(I’ll have to tread carefully and take things slowly. I want it to be pleasant for her too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:20
translate chinese SR2_NS4_rep_89f52b5b:

    # MC "Hey, Sara. Thanks for coming over."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:24
translate chinese SR2_NS4_rep_3cd94aeb:

    # Sara "N-No problem. I love sneaking over to see you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:25
translate chinese SR2_NS4_rep_d33b02c9:

    # MC "You’re still scared about the anal thing, aren’t you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:27
translate chinese SR2_NS4_rep_f42163ca:

    # Sara "N-No problem. I love coming over to see you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:28
translate chinese SR2_NS4_rep_2a44698f:

    # MC "You’re still concerned about the anal thing, aren’t you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:29
translate chinese SR2_NS4_rep_8881bf12:

    # Sara "Just a little bit, yeah."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:30
translate chinese SR2_NS4_rep_8402f18c:

    # MC "A little bit?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:32
translate chinese SR2_NS4_rep_47c0d22f:

    # Sara "Okay, that was a lie. I’m, like, REALLY scared."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:34
translate chinese SR2_NS4_rep_742250b5:

    # Sara "Okay, that was a lie. I’m, like, REALLY confused."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:38
translate chinese SR2_NS4_rep_c772a71a:

    # MC "Just try to relax, Sara. I’ve said this already, and I’m sure you’re sick of hearing me repeat myself..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:39
translate chinese SR2_NS4_rep_15ffaa60:

    # MC "...but we’re going to take this nice and slow. If you need me to stop or it hurts too much, just say."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:40
translate chinese SR2_NS4_rep_a2aeaf58:

    # Sara "I will."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:41
translate chinese SR2_NS4_rep_bb3ff7ab:

    # MC "I promise you, the lube will make things MUCH easier."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:42
translate chinese SR2_NS4_rep_04e8880b:

    # Sara "It’d be easier if I could just relax a bit too."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:46
translate chinese SR2_NS4_rep_f2e718f7:

    # MC "Is there anything I can do to help you relax?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:47
translate chinese SR2_NS4_rep_4896cd33:

    # Sara "(If he told me that he loves me and that I was his girlfriend it would certainly help.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:48
translate chinese SR2_NS4_rep_b092e0f8:

    # Sara "(I don’t want to press the topic on him again. He seemed hesitant to answer last time, and I don’t want to drive him away.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:49
translate chinese SR2_NS4_rep_2b4ef9d5:

    # Sara "N-No, let’s just get started."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:53
translate chinese SR2_NS4_rep_ff536593:

    # MC "(She’s shaking slightly. I have to try and calm her down.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:54
translate chinese SR2_NS4_rep_f3556577:

    # MC "(Starting off with a kiss isn’t a bad idea.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:55
translate chinese SR2_NS4_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:59
translate chinese SR2_NS4_rep_8bf799d1:

    # Sara "(God... It’s like an electric current, zapping through my body, every time he kisses me.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:61
translate chinese SR2_NS4_rep_98343c3a:

    # Sara "(I thought it would pass, after the novelty of our first kiss... but the feeling hasn’t ever faded.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:62
translate chinese SR2_NS4_rep_1ce29e7c:

    # Sara "(It’s a strange sensation, but it leaves me melting in his arms. I love it when he holds me, just like this.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:66
translate chinese SR2_NS4_rep_312847cd:

    # MC "Mmm...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:67
translate chinese SR2_NS4_rep_1f793de6:

    # Sara "Mmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:68
translate chinese SR2_NS4_rep_cf12e919:

    # Sara "(I love you, [player_name]. There isn’t a girl in the whole damn world as lucky as ME right now.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:72
translate chinese SR2_NS4_rep_3581212e:

    # MC "I bet I can guess what you’re thinking."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:73
translate chinese SR2_NS4_rep_5d2d42da:

    # Sara "Haha! Oh really?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:74
translate chinese SR2_NS4_rep_de40568f:

    # MC "You’re thinking, how did I ever get so lucky to date such a hot and handsome guy?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:75
translate chinese SR2_NS4_rep_7f4d5ca4:

    # Sara "Haha! You’re REALLY overconfident, you know that?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:79
translate chinese SR2_NS4_rep_315ab6c0:

    # MC "Do you want to know what I was thinking?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:80
translate chinese SR2_NS4_rep_7e55cd43:

    # Sara "Yeah, tell me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:81
translate chinese SR2_NS4_rep_fb29699d:

    # MC "Just how much I love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:85
translate chinese SR2_NS4_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:87
translate chinese SR2_NS4_rep_5f2ec5ea:

    # Sara "(I’m so close to just giving... everything to him right now.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:88
translate chinese SR2_NS4_rep_12224535:

    # Sara "(Does he even know how good he makes me feel?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:93
translate chinese SR2_NS4_rep_b69d6024:

    # Sara "Wow... That was amazing!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:94
translate chinese SR2_NS4_rep_51116ec2:

    # MC "Am I a good kisser?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:95
translate chinese SR2_NS4_rep_95abac24:

    # Sara "You’re the best I’ve ever kissed."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:96
translate chinese SR2_NS4_rep_6d0d0adf:

    # MC "Wait - I’m the ONLY guy you’ve ever kissed!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:97
translate chinese SR2_NS4_rep_65b119b7:

    # Sara "Hehe! Okay, I’m gonna strip down for you now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:101
translate chinese SR2_NS4_rep_acc7d400:

    # Sara "(Damn... My nerves are starting to kick off again. I shouldn’t be so scared about this.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:102
translate chinese SR2_NS4_rep_c5462963:

    # Sara "(I mean, I’ve already done it before! And this time it should be easier - we have the lube, after all.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:104
translate chinese SR2_NS4_rep_70564cd8:

    # Sara "(Damn... I'm having butterflies in my tummy again! I can't believe I'm so nervous about this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:106
translate chinese SR2_NS4_rep_30c910c5:

    # MC "(I get so hard every time I see her perky tits. They’re unbelievable!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:111
translate chinese SR2_NS4_rep_a26130a2:

    # MC "(And that ass is just stunning! I can’t wait to fuck it again tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:112
translate chinese SR2_NS4_rep_125a58f9:

    # MC "(I’d love to bury my cock, balls-deep in her, and just shoot my cum, deep into her body.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:113
translate chinese SR2_NS4_rep_840005b8:

    # Sara "(I’m starting to get wet, now that he’s leering at me like that.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:117
translate chinese SR2_NS4_rep_cfb94d1f:

    # Sara "Okay... *Phew*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:118
translate chinese SR2_NS4_rep_c82be1a5:

    # Sara "(Here we go - deep breaths! I can do this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:119
translate chinese SR2_NS4_rep_e31e3cc6:

    # Sara "I’m ready whenever you are."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:120
translate chinese SR2_NS4_rep_f673695a:

    # MC "Okay, let me grab the lube."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:124
translate chinese SR2_NS4_rep_a6a8c6a6:

    # Sara "How do we do this, then?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:125
translate chinese SR2_NS4_rep_f2c5c7b0:

    # MC "You just roll over and lie on your side. I’ll get some of the lube in my hand and begin to spread it on your ass."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:127
translate chinese SR2_NS4_rep_84c0dc48:

    # Sara "It’s not gonna be cold, is it?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:129
translate chinese SR2_NS4_rep_cd8e6374:

    # Sara "It’s gonna be cold as other lubes, is it?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:133
translate chinese SR2_NS4_rep_81559a9d:

    # MC "I’ll make sure to warm it up with my fingers first."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:134
translate chinese SR2_NS4_rep_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:135
translate chinese SR2_NS4_rep_94226072:

    # Sara "(This is it... ) *Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:140
translate chinese SR2_NS4_rep_d0e462fa:

    # Sara "Just before we begin - can you promise me that you’ll definitely stop if it starts to hurt?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:142
translate chinese SR2_NS4_rep_396eab6a:

    # Sara "Just before we begin - can you promise me that you'll definitely stop when I tell you?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:143
translate chinese SR2_NS4_rep_cc50ea08:

    # MC "Of course I will, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:144
translate chinese SR2_NS4_rep_b3f48b0e:

    # Sara "Okay, whenever you’re ready."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:148
translate chinese SR2_NS4_rep_19b61e2e:

    # MC "I’m just gonna spread your asscheeks here so I can get inside."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:150
translate chinese SR2_NS4_rep_5fbee909:

    # MC "(Damn, look how tight her little hole is! No wonder my fat cock hurt her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:152
translate chinese SR2_NS4_rep_f8dc99ff:

    # MC "(Damn! Look how tight her little hole is!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:153
translate chinese SR2_NS4_rep_40de3cb0:

    # MC "(This lube should definitely do the trick!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:157
translate chinese SR2_NS4_rep_1aa768d3:

    # Sara "Oh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:158
translate chinese SR2_NS4_rep_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:159
translate chinese SR2_NS4_rep_2b9edb68:

    # Sara "Y-Yeah, I was just a little shocked when your finger went in."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:160
translate chinese SR2_NS4_rep_6f2d4e75:

    # MC "How does that feel?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:161
translate chinese SR2_NS4_rep_4ebd96d2:

    # Sara "Err... A bit strange... But not really painful at all."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:162
translate chinese SR2_NS4_rep_1903d282:

    # MC "Okay, I’m gonna use two fingers now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:166
translate chinese SR2_NS4_rep_2b253959:

    # Sara "Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:167
translate chinese SR2_NS4_rep_59829ef9:

    # MC "Is this sore?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:168
translate chinese SR2_NS4_rep_f579b084:

    # Sara "Um... On a scale of one to ten, with ten being the worst pain ever... It's like two right now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:173
translate chinese SR2_NS4_rep_10f68c07:

    # MC "What was the pain like, on the roof the other night?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:174
translate chinese SR2_NS4_rep_ef0e1615:

    # Sara "Like a... seven, maybe an eight."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:175
translate chinese SR2_NS4_rep_fadb6bf0:

    # MC "Aww, I’m sorry. I didn’t realise it was that sore."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:176
translate chinese SR2_NS4_rep_73e5f070:

    # Sara "It’s okay. You’re doing things to try and make it hurt less. That means you care about me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:178
translate chinese SR2_NS4_rep_52196ad6:

    # MC "What was the feeling like, on the roof the other night?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:179
translate chinese SR2_NS4_rep_85103af4:

    # Sara "Like a... nevermind..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:180
translate chinese SR2_NS4_rep_a828f189:

    # Sara "It’s okay. You're doing things to make me feel pleasure just as yourself. That means you care about me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:184
translate chinese SR2_NS4_rep_6df4baee:

    # MC "Okay, I’m bringing my cock up now. I’m gonna slide it in, slowly and gently."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:185
translate chinese SR2_NS4_rep_04177990:

    # MC "If you need me to stop - just say, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:186
translate chinese SR2_NS4_rep_56c2e20f:

    # MC "(I think I’ve applied enough lube. It should HOPEFULLY slide in much easier this time.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:190
translate chinese SR2_NS4_rep_c67573a9:

    # Sara "Ah...."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:191
translate chinese SR2_NS4_rep_2bc01b43:

    # Sara "(Oh shit... here we go... I can do this...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:192
translate chinese SR2_NS4_rep_cf125997:

    # Sara "(Just keep breathing and clench your teeth.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:196
translate chinese SR2_NS4_rep_a523bec2:

    # Sara "Oooohh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:197
translate chinese SR2_NS4_rep_2b84bca2:

    # MC "Sorry, a bit more slipped in than I intended!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:198
translate chinese SR2_NS4_rep_5b72e012:

    # Sara "Ow..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:199
translate chinese SR2_NS4_rep_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:203
translate chinese SR2_NS4_rep_a7835e8e:

    # Sara "Y-Yeah! (Fuck!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:206
translate chinese SR2_NS4_rep_14778c02:

    # Sara "(Even with the lube, this is still hurting like hell!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:207
translate chinese SR2_NS4_rep_934c8571:

    # Sara "(How do women in porn take it in the ass so easily?! Is it practice? Or is it because they’ve got bigger bodies than I do?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:209
translate chinese SR2_NS4_rep_28fbeb47:

    # Sara "(Even with the lube, I can still feel that strange feeling... But... It’s not so bad!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:210
translate chinese SR2_NS4_rep_e81da301:

    # Sara "(How do women in porn take it in the ass so easily?! Is it practice? Or is it because they are milfs?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:214
translate chinese SR2_NS4_rep_256b85e4:

    # MC "How does it feel now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:217
translate chinese SR2_NS4_rep_0ce69dc0:

    # Sara "Like... a four. It’s hurting a bit."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:219
translate chinese SR2_NS4_rep_3d7f5e25:

    # Sara "It’s weird... But I'm starting to like it more and more..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:220
translate chinese SR2_NS4_rep_28b91e37:

    # MC "Am I going too fast?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:221
translate chinese SR2_NS4_rep_861073d7:

    # Sara "N-No... you can speed up a LITTLE bit, if you want."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:225
translate chinese SR2_NS4_rep_a0d35193:

    # MC "Okay, if you’re sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:227
translate chinese SR2_NS4_rep_80742e70:

    # Sara "(Uh oh... maybe this was a bad idea.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:228
translate chinese SR2_NS4_rep_ad155ffe:

    # Sara "Ah! Ow! Ouch!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:233
translate chinese SR2_NS4_rep_1fbf0ed8:

    # Sara "Ah! AHH! It hurts! Ow!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:235
translate chinese SR2_NS4_rep_531fea76:

    # Sara "Ah! AHH! Let’s stop!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:236
translate chinese SR2_NS4_rep_4d7084eb:

    # MC "I’m sorry! I’m sorry!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:237
translate chinese SR2_NS4_rep_da63a008:

    # MC "(Fuck! I thrust my cock in too deep, there. I better pull out and make sure she’s okay.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:243
translate chinese SR2_NS4_rep_2b00cd3f:

    # Sara "Owww..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:244
translate chinese SR2_NS4_rep_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:245
translate chinese SR2_NS4_rep_b559db00:

    # Sara "(I couldn’t do it... I couldn’t go through with it. Now [player_name]’s going to be disappointed in me.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:249
translate chinese SR2_NS4_rep_6a476a30:

    # MC "Sara? Are you okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:250
translate chinese SR2_NS4_rep_8eea1b83:

    # Sara "*Sniff*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:251
translate chinese SR2_NS4_rep_484cf5b0:

    # MC "(Shit! I think I’ve made her cry!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:255
translate chinese SR2_NS4_rep_9c34d15e:

    # Sara "I’m sorry.... I’m just not good at this sex thing."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:257
translate chinese SR2_NS4_rep_dd266e21:

    # Sara "I’m sorry... I’m just not good at this anal thing."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:258
translate chinese SR2_NS4_rep_492af58f:

    # Sara "You should just go and find another hot girl, who can do the things that you want."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:259
translate chinese SR2_NS4_rep_3d23ce79:

    # MC "Hey! That’s not true! You’re absolutely perfect."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:260
translate chinese SR2_NS4_rep_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:261
translate chinese SR2_NS4_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:262
translate chinese SR2_NS4_rep_fe5e5074:

    # MC "Give me a sec and we can talk. I’ll go-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:266
translate chinese SR2_NS4_rep_53c5ded2:

    # Sara "-I’m sorry! I just can’t relax when we’re doing it. It’s... different to when I’m giving you a blowjob."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:267
translate chinese SR2_NS4_rep_c7354125:

    # Sara "I can’t explain why... it’s more... intimate when I use my ass."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:268
translate chinese SR2_NS4_rep_cf4e28e2:

    # MC "Sara, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:272
translate chinese SR2_NS4_rep_bc03f348:

    # Sara "Can you call me your girlfriend?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:273
translate chinese SR2_NS4_rep_19570c32:

    # MC "What?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:274
translate chinese SR2_NS4_rep_1d7f6a60:

    # Sara "Please, just tell me I’m your girlfriend. I need to hear those words. I think I can relax when I know that you’re committed to me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:275
translate chinese SR2_NS4_rep_79d1df5e:

    # MC "Sara... I love you. And... I want you to be my girlfriend."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:276
translate chinese SR2_NS4_rep_80d1d31e:

    # Sara "Really?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:277
translate chinese SR2_NS4_rep_a65f733f:

    # MC "Really. I mean it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:278
translate chinese SR2_NS4_rep_b8bb3e3f:

    # Sara "Lie back down beside me. I want to try one last time."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:282
translate chinese SR2_NS4_rep_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:283
translate chinese SR2_NS4_rep_95f478c3:

    # Sara "I think... I think I can go through with it. Maybe try lifting my leg up?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:290
translate chinese SR2_NS4_rep_be6dd1da:

    # MC "Just like this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:291
translate chinese SR2_NS4_rep_ee826b86:

    # Sara "Yeah, that feels a little better already."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:292
translate chinese SR2_NS4_rep_f46479c5:

    # MC "(I can’t wait till I get to fuck her pussy someday. It’s so gorgeous.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:296
translate chinese SR2_NS4_rep_2b253959_1:

    # Sara "Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:298
translate chinese SR2_NS4_rep_26d81e11:

    # MC "It’s okay. I'm not going to hurt you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:299
translate chinese SR2_NS4_rep_4bf708c6:

    # Sara "Tell me it again. Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:303
translate chinese SR2_NS4_rep_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:304
translate chinese SR2_NS4_rep_e165edae:

    # Sara "N-No, the other one. I want- need to hear you say it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:305
translate chinese SR2_NS4_rep_1471d848:

    # MC "You’re my girlfriend, Sara. You’re the one I want to be with. That’s the truth."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:309
translate chinese SR2_NS4_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:310
translate chinese SR2_NS4_rep_2d012949:

    # MC "(Now that she’s relaxed a bit, this is starting to feel much better for me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:312
translate chinese SR2_NS4_rep_eb501a61:

    # MC "(She doesn’t seem to be in much pain at all now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:314
translate chinese SR2_NS4_rep_ce74ff19:

    # MC "(She seems to be enjoing it a lot more now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:318
translate chinese SR2_NS4_rep_246bd3ab:

    # Sara "Ah... Oh.... Mmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:321
translate chinese SR2_NS4_rep_0d92e2e2:

    # Sara "(This is starting to feel... strange now. It isn’t as sore as it used to be.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:323
translate chinese SR2_NS4_rep_ce9184cf:

    # Sara "(This is starting to feel... GOOD now. It isn't the same feeling as it used to be.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:324
translate chinese SR2_NS4_rep_2110d0c2:

    # MC "(It sounds like Sara’s moans are getting quieter. Maybe her body is getting used to it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:328
translate chinese SR2_NS4_rep_1fce08ff:

    # MC "How are you doing there, Sara? Do you need me to slow down at all?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:329
translate chinese SR2_NS4_rep_bed3023e:

    # Sara "Ah... Mmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:330
translate chinese SR2_NS4_rep_e2d0cf56:

    # MC "(Her nipples have gone stiff. Maybe she’s actually beginning to enjoy this?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:334
translate chinese SR2_NS4_rep_c8b711b7:

    # Sara "Could we... ah... change positions?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:335
translate chinese SR2_NS4_rep_a3ff5a94:

    # MC "What way do you want to go?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:336
translate chinese SR2_NS4_rep_c8c5b000:

    # Sara "I want to face you when we’re fucking. I want to be able to see your eyes."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:340
translate chinese SR2_NS4_rep_365afdc9:

    # MC "Like this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:341
translate chinese SR2_NS4_rep_21f1978d:

    # Sara "Ahh! Y-Yeah, like this."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:342
translate chinese SR2_NS4_rep_0cecbf5d:

    # Sara "(God, I’m getting so wet right now. Am I actually beginning to enjoy being fucked in the ass?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:346
translate chinese SR2_NS4_rep_7d58ad3b:

    # Sara "Ah! Ah! Ahh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:347
translate chinese SR2_NS4_rep_71418457:

    # MC "Are you okay, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:348
translate chinese SR2_NS4_rep_70a678b4:

    # Sara "Y-yeah, it’s... mmm! Starting to feel good!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:352
translate chinese SR2_NS4_rep_9d0253f9:

    # Sara "MMMM! OHHH!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:355
translate chinese SR2_NS4_rep_56ddf9c7:

    # MC "Shush, you don’t want to wake up Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:356
translate chinese SR2_NS4_rep_fc099a01:

    # MC "This would be REALLY difficult to explain to her. Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:358
translate chinese SR2_NS4_rep_0bfb6c58:

    # MC "Shush! You don’t want to wake up anybody!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:359
translate chinese SR2_NS4_rep_c191a852:

    # MC "We’re in a very private situation... Are we? Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:360
translate chinese SR2_NS4_rep_268369df:

    # Sara "Hehe! Ohhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:364
translate chinese SR2_NS4_rep_8f48db05:

    # Sara "Fuck... *GASP*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:365
translate chinese SR2_NS4_rep_dd6422e5:

    # MC "Do you need me to slow down?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:366
translate chinese SR2_NS4_rep_d2c37a39:

    # Sara "N-No... You can speed up a little, if you want to. Just... ah... don’t go much deeper. Okay?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:370
translate chinese SR2_NS4_rep_5468574b:

    # Sara "I love you, [player_name]. Thank you for having me over, in your room."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:371
translate chinese SR2_NS4_rep_bfc3b44f:

    # MC "You’re ALWAYS welcome to come over, Sara. I love you too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:372
translate chinese SR2_NS4_rep_2d7ad50d:

    # MC "Plus, you’re my girlfriend now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:376
translate chinese SR2_NS4_rep_e6a95c7f:

    # MC "Ugh! Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:377
translate chinese SR2_NS4_rep_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:378
translate chinese SR2_NS4_rep_d8b3262d:

    # MC "Mmm! (I just put my hand on her face for balance, but she’s already started sucking on my thumb!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:382
translate chinese SR2_NS4_rep_d63b0594:

    # MC "I’m gonna cum soon - can we make out while I finish?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:383
translate chinese SR2_NS4_rep_2f31a332:

    # Sara "Sure, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:384
translate chinese SR2_NS4_rep_b48bfc73:

    # MC "Are you okay if I cum in your ass?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:385
translate chinese SR2_NS4_rep_9a64e39c:

    # Sara "Finish wherever you want."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:389
translate chinese SR2_NS4_rep_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:390
translate chinese SR2_NS4_rep_a44ee2be:

    # Sara "Ohhhmmmm! MMMMM!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:391
translate chinese SR2_NS4_rep_89793c95:

    # Sara "(This almost feels as good as the vibrator [player_name] bought for me.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:395
translate chinese SR2_NS4_rep_0361910e:

    # MC "MMM! HNNNNGGGG!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:396
translate chinese SR2_NS4_rep_90ac8d0e:

    # MC "UGH! AAHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:397
translate chinese SR2_NS4_rep_c072896c:

    # Sara "(Wow! I can feel his hot cum flooding into my ass! It feels amazing!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:398
translate chinese SR2_NS4_rep_21c0841c:

    # Sara "(Fuck... I wonder how it would feel in my pussy...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:407
translate chinese SR2_NS4_rep_d27542c6:

    # MC "*Pant* Th-That was fucking amazing, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:408
translate chinese SR2_NS4_rep_0cc8d77f:

    # Sara "You enjoyed that?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:409
translate chinese SR2_NS4_rep_4dc73c16:

    # MC "Oh yeah... How about you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:410
translate chinese SR2_NS4_rep_fd806f9b:

    # Sara "I’m not gonna lie, it’s growing on me. I actually kind of found it... pleasurable that time."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:411
translate chinese SR2_NS4_rep_451951e1:

    # MC "C’mon, let’s cuddle for a while before you go back to your room."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:421
translate chinese SR2_NS4_rep_6559f47d:

    # Sara "Yay! Hehe! This is the best part."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:422
translate chinese SR2_NS4_rep_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:426
translate chinese SR2_NS4_rep_800755f2:

    # Sara "I could just close my eyes and drift off to sleep like this."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:427
translate chinese SR2_NS4_rep_4a4fce81:

    # Sara "I love the feeling of your soft skin against mine. It just feels so perfect..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:428
translate chinese SR2_NS4_rep_b06f5213:

    # Sara "Like everything is just right in the world."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:432
translate chinese SR2_NS4_rep_138332f3:

    # Sara "*Sigh*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:433
translate chinese SR2_NS4_rep_fd14fda2:

    # MC "Is something wrong, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:434
translate chinese SR2_NS4_rep_9d5118f7:

    # Sara "I just realised... you’re my boyfriend, but I can’t hang out with you like normal girlfriends do."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:435
translate chinese SR2_NS4_rep_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:437
translate chinese SR2_NS4_rep_fc5be3a9:

    # Sara "Everybody in this town knows us. And Mom and Dad would DEFINITELY not approve."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:439
translate chinese SR2_NS4_rep_9e8017b7:

    # Sara "Everybody in this town knows us for a while now. A nerdy girl like me and a handsome man like you? Together? It's all wrong... Lily would be better for you than I am..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:443
translate chinese SR2_NS4_rep_9a64ddd3:

    # MC "Oh c’mon! You’re thinking too much about this."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:446
translate chinese SR2_NS4_rep_e05bd261:

    # MC "We can do LOTS of things together, sure we’ll have to be a little more careful than most couples, but we can still have fun!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:447
translate chinese SR2_NS4_rep_bfac8e05:

    # MC "And don’t worry about Mom and Dad - we haven’t been caught yet."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:449
translate chinese SR2_NS4_rep_a6d0686f:

    # MC "I don’t fucking care about that kind of thing! The feeling between us is what is most important. Also, who says that you're a nerd?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:450
translate chinese SR2_NS4_rep_0383b342:

    # MC "Even if that is true, you're my lovely nerd. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:454
translate chinese SR2_NS4_rep_bc2b3485:

    # Sara "Yeah, I guess you’re right. I just wish things were simpler."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:456
translate chinese SR2_NS4_rep_37b96a61:

    # Sara "It sounds bad... but I kinda wish you weren’t my brother. Maybe just a hot guy at college."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:458
translate chinese SR2_NS4_rep_5945b0f2:

    # Sara "It sounds bad... but I kinda wish you weren’t living in the same house as me. Maybe just another hot guy at college. That would be easier."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:459
translate chinese SR2_NS4_rep_4a3eac11:

    # Sara "That way I could bring you over and hang out with you. Watch TV and stuff like that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:463
translate chinese SR2_NS4_rep_69e1b9eb:

    # MC "Sara, you’re overthinking this. You’re my girlfriend now and we’re gonna make this work. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:464
translate chinese SR2_NS4_rep_f97a0e6d:

    # Sara "Thanks, [player_name]. I love you so much."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS4_rep.rpy:465
translate chinese SR2_NS4_rep_f7f96222:

    # MC "I love you, too, Sara."
    MC ""

