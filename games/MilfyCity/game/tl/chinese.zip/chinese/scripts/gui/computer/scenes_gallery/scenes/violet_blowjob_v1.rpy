﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:7
translate chinese violet_blowjob_v1_7df4ad07:

    # MC "Oh! Hey, Caroline. What are you doing in my room?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:8
translate chinese violet_blowjob_v1_c98c4453:

    # MC "And who’s this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:9
translate chinese violet_blowjob_v1_435d42ef:

    # Caroline "Hiii, [player_name]! I want you to meet Violet!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:10
translate chinese violet_blowjob_v1_369f194c:

    # Violet "Hey there."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:11
translate chinese violet_blowjob_v1_75a91ab5:

    # Caroline "I promised you a surprise - so Violet’s going to help you relieve some of that stress you’ve built up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:14
translate chinese violet_blowjob_v1_a5f6e8df:

    # MC "You brought a prostitute to my bedroom!?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:15
translate chinese violet_blowjob_v1_6069cd87:

    # Violet "WHAT?!"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:16
translate chinese violet_blowjob_v1_781e97ef:

    # Caroline "Ahahaha! Oh, my God! I’m so sorry, Violet!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:19
translate chinese violet_blowjob_v1_54ae8849:

    # Violet "Fuck you! I’m not some whore!"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:20
translate chinese violet_blowjob_v1_b3163b44:

    # Violet "Caroline made a deal with me - she owes me a favour if I help you relax."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:21
translate chinese violet_blowjob_v1_d634feb6:

    # MC "Huh? Like a massage?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:24
translate chinese violet_blowjob_v1_ab6d0afa:

    # Caroline "She’s not a prostitute. She’s one of my friends."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:25
translate chinese violet_blowjob_v1_8f04cd5e:

    # Caroline "I’ve made a deal with her - I owe her a favour now, but in exchange she’s going to do something for you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:26
translate chinese violet_blowjob_v1_e13c98ce:

    # MC "Do something?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:29
translate chinese violet_blowjob_v1_156ef6a8:

    # Caroline "Are you seriously THAT dense? She’s going to get you off!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:30
translate chinese violet_blowjob_v1_e5093ef0:

    # MC "OH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:31
translate chinese violet_blowjob_v1_a63cc2e2:

    # MC "Sorry, Violet! I didn’t realise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:32
translate chinese violet_blowjob_v1_1b27cdf6:

    # Caroline "I’m gonna leave you two alone now. Have fun!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:35
translate chinese violet_blowjob_v1_d07f9764:

    # Violet "See you later, Caroline. Follow me, [player_name]."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:36
translate chinese violet_blowjob_v1_442788eb:

    # MC "What are we going to do, then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:37
translate chinese violet_blowjob_v1_4f693c88:

    # MC "Like... sex? Or anal?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:40
translate chinese violet_blowjob_v1_804b98d6:

    # Violet "We’re going to get this over with, quickly."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:41
translate chinese violet_blowjob_v1_d127f103:

    # Violet "I’ll lie back on the bed and let you fuck my mouth."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:42
translate chinese violet_blowjob_v1_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:45
translate chinese violet_blowjob_v1_114b70ec:

    # Violet "Well? Are you ready? I have places to be."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:46
translate chinese violet_blowjob_v1_4e7044c1:

    # MC "S-Sure!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:48
translate chinese violet_blowjob_v1_03979f50:

    # MC "What deal did you make with my sister, by the way?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:50
translate chinese violet_blowjob_v1_0209ebf5:

    # MC "What deal did you make with Caroline, by the way?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:51
translate chinese violet_blowjob_v1_2568ebcf:

    # Violet "She owes me one. I’ll probably end up making her suck off one of my male friends, just to even the score."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:54
translate chinese violet_blowjob_v1_a45c5b4d:

    # Violet "Okay - let’s get this party started."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:55
translate chinese violet_blowjob_v1_07ec537a:

    # Violet "First things first - we need to get you hard."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:56
translate chinese violet_blowjob_v1_ec5eb49c:

    # MC "(She’s REALLY sexy! Caroline has good taste in friends!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:57
translate chinese violet_blowjob_v1_e37c34fe:

    # MC "(Let’s see if she’s as slutty as she looks!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:60
translate chinese violet_blowjob_v1_9617ae6b:

    # Violet "Ahh...."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:61
translate chinese violet_blowjob_v1_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:62
translate chinese violet_blowjob_v1_3fa5d3e7:

    # MC "(I can feel her tongue, licking the tip of my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:63
translate chinese violet_blowjob_v1_25aed3ce:

    # MC "(She’s swirling it around - she’s clearly done this A LOT of times before.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:66
translate chinese violet_blowjob_v1_b405566c:

    # MC "(Taking pictures for Caroline, has gotta be one of the best decisions I’ve made all year!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:68
translate chinese violet_blowjob_v1_f09c71e8:

    # MC "(I never imagined it would end up, with me getting a blowjob from a cocksucking slut!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:70
translate chinese violet_blowjob_v1_1e18d554:

    # MC "(I never imagined it would end up with me getting my cock sucked by her slutty friend!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:74
translate chinese violet_blowjob_v1_6764e270:

    # Violet "Ah, there we go. Now we can properly begin."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:75
translate chinese violet_blowjob_v1_0b702f6b:

    # MC "I know you said a quick blowjob, but can I use your tits too?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:76
translate chinese violet_blowjob_v1_69c23a62:

    # Violet "*Sigh* Fine."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:79
translate chinese violet_blowjob_v1_224508ec:

    # MC "Awesome! "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:80
translate chinese violet_blowjob_v1_496df01c:

    # Violet "Do you need me to hold my breasts together?"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:81
translate chinese violet_blowjob_v1_5fa4e903:

    # MC "Could you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:82
translate chinese violet_blowjob_v1_7c2f5a1b:

    # Violet "Sure."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:85
translate chinese violet_blowjob_v1_d8f5acb0:

    # Violet "How’s that?"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:86
translate chinese violet_blowjob_v1_041648e4:

    # MC "Much better!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:89
translate chinese violet_blowjob_v1_df859db7:

    # MC "(I can feel her warm breasts, wrapped around my cock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:92
translate chinese violet_blowjob_v1_1e3c558b:

    # Violet "(Ugh! How long is this little twerp gonna take to cum?)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:93
translate chinese violet_blowjob_v1_ec08e087:

    # Violet "(I thought my boobs would be enough, but maybe I should give him a helping hand?)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:96
translate chinese violet_blowjob_v1_e206ed83:

    # MC "OOOHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:97
translate chinese violet_blowjob_v1_5da3d66d:

    # MC "(Holy shit! She’s licking my ass! I never imagined it would be so sensitive there!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:98
translate chinese violet_blowjob_v1_9a898dff:

    # MC "(Crap! If she keeps that up, I’ll cum before, I even get a blowjob from her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:101
translate chinese violet_blowjob_v1_d757dfd9:

    # MC "(I’ll try to endure it for a while - it feels amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:102
translate chinese violet_blowjob_v1_d229a396:

    # Violet "(Time to hold my breasts a little closer together. Let’s see if we can make him cum, before I have to go through with a blowjob.)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:103
translate chinese violet_blowjob_v1_061b6594:

    # MC "Ahh... Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:106
translate chinese violet_blowjob_v1_52c83cd2:

    # MC "God, yes! Ahh... Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:107
translate chinese violet_blowjob_v1_1b383315:

    # Violet "(Time to twist and flick my tongue even faster.)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:108
translate chinese violet_blowjob_v1_6769d89e:

    # MC "AHhhhh! OH! OH OH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:111
translate chinese violet_blowjob_v1_2db08e16:

    # MC "(Between her breasts and her tongue, licking my ass, I feel like I’m about to cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:112
translate chinese violet_blowjob_v1_a786ee93:

    # MC "(I better stop this and get my blowjob, to finish things off!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:113
translate chinese violet_blowjob_v1_51a29a6e:

    # MC "Okay, ahh- that’s enough. I want you to use your mouth now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:114
translate chinese violet_blowjob_v1_8368e32e:

    # Violet "Ugh! Fine."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:117
translate chinese violet_blowjob_v1_9dbd5014:

    # Violet "*Suck Suck*"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:118
translate chinese violet_blowjob_v1_7304a397:

    # MC "Ooohh - that’s the spot!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:119
translate chinese violet_blowjob_v1_53cb3258:

    # MC "(I can’t hold back anymore. I REALLY HAVE TO fuck her face!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:122
translate chinese violet_blowjob_v1_caf68afa:

    # Violet "MMPFFFFF!"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:124
translate chinese violet_blowjob_v1_dd7f674d:

    # Violet "(Fuck! I wasn’t expecting him to thrust his cock into my mouth like that!)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:125
translate chinese violet_blowjob_v1_a1a1fd1d:

    # MC "Oooh yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:128
translate chinese violet_blowjob_v1_9bb8e373:

    # MC "Damn, you’re a great cocksucker. You know that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:129
translate chinese violet_blowjob_v1_17fd1251:

    # Violet "(Smooth... That’s just the kind of compliment a girl wants to hear, from a guy she just met...)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:130
translate chinese violet_blowjob_v1_e4c56a5e:

    # Violet "Mmpfff mmmm...."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:133
translate chinese violet_blowjob_v1_9654d4b0:

    # MC "Ahh, fuck... I’m gonna cum soon!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:134
translate chinese violet_blowjob_v1_17c63f15:

    # Violet "(At least he gave me a warning. That’s more than I can say for any of my exes.)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:137
translate chinese violet_blowjob_v1_1f85237b:

    # MC "Ah! Ugh! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:138
translate chinese violet_blowjob_v1_432b631e:

    # Violet "*Shlurrrp*"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:140
translate chinese violet_blowjob_v1_934e7966:

    # Violet "*Suck Suck Suck*"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:141
translate chinese violet_blowjob_v1_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:144
translate chinese violet_blowjob_v1_49e51dfc:

    # MC "Open wide!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:145
translate chinese violet_blowjob_v1_563b0d5b:

    # MC "Ahhh! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:146
translate chinese violet_blowjob_v1_c7ecf997:

    # Violet "(That favour Caroline owes me better be worth it...)"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:156
translate chinese violet_blowjob_v1_8e6949d2:

    # MC "UGH! Ahhhhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:157
translate chinese violet_blowjob_v1_89c3e729:

    # MC "*Pant...* Ooohh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:158
translate chinese violet_blowjob_v1_5c15efa7:

    # MC "Do you need me to get you a tissue or anything, to spit it-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:159
translate chinese violet_blowjob_v1_413e144f:

    # Violet "*Gulp!*"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:160
translate chinese violet_blowjob_v1_cfda8a59:

    # MC "Or you could just do that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:163
translate chinese violet_blowjob_v1_1f5fb641:

    # Violet "So, Caroline was telling me, you got a boner while looking at her. Is that true?"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:164
translate chinese violet_blowjob_v1_22c08df1:

    # MC "Uh... Yeah, but it’s not the full story."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:165
translate chinese violet_blowjob_v1_14cb8666:

    # Violet "What’s the story, then?"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:166
translate chinese violet_blowjob_v1_b97353f5:

    # MC "She was dressed up in a sexy costume. A guy doesn’t really have any control over his cock, in a situation like that. So you can’t really say it’s my fault."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:167
translate chinese violet_blowjob_v1_909073f0:

    # Violet "Eh... fair enough."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:168
translate chinese violet_blowjob_v1_2f3d144d:

    # Violet "Just one more question - do you prefer me or Caroline?"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:172
translate chinese violet_blowjob_v1_7cde3286:

    # MC "Come on - I can’t answer that. She’s my sister."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:174
translate chinese violet_blowjob_v1_5f31e0ce:

    # MC "Come on - I can't answer that. You might reveal my response to her."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:175
translate chinese violet_blowjob_v1_92f2a645:

    # Violet "Sure you can!"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:176
translate chinese violet_blowjob_v1_438a7437:

    # MC "*Sigh* You’re hot, but... Caroline’s more my type. She’s really gorgeous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:179
translate chinese violet_blowjob_v1_4c225a54:

    # Caroline "*Gasp!*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:181
translate chinese violet_blowjob_v1_f76ad3be:

    # Caroline "([player_name] is actually... attracted to me. It wasn’t just the costume I was wearing.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:183
translate chinese violet_blowjob_v1_a5e1e515:

    # Caroline "(He’s actually attracted to... me? It wasn’t just the costume I was wearing.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/violet_blowjob_v1.rpy:184
translate chinese violet_blowjob_v1_feb61845:

    # Caroline "(What the Hell am I supposed to do now? Is it even fair of me, to let him keep taking pictures of me? Or is that just torturing him?)"
    Caroline ""

