﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:18
translate chinese CR3_NS5_rep_adbeb322:

    # Caroline "(Okay, let’s think about this logically. My vibrator has gone missing. There are four other people in this house: Mom, Dad, Sara, and [player_name].)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:19
translate chinese CR3_NS5_rep_8e0bc463:

    # Caroline "(What would have happened if Mom had found it under my bed.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:21
translate chinese CR3_NS5_rep_650acb59:

    # Caroline "(Okay, let’s think about this logically. My vibrator has gone missing. There are four other people in this house: Linda, Bob, Sara, and [player_name].)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:22
translate chinese CR3_NS5_rep_1d0422cd:

    # Caroline "(What would have happened if Linda had found it under my bed.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:24
translate chinese CR3_NS5_rep_e56b248e:

    # Caroline "(Well, I’m a fully grown adult and her tenant - she almost certainly would have left it where it was.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:28
translate chinese CR3_NS5_rep_cb9832cb:

    # Caroline "(There’s no way Dad would have found my vibrator - he hardly pays me any attention. I can’t remember him even coming into my room in years.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:29
translate chinese CR3_NS5_rep_a75ba45b:

    # Caroline "(This narrows things down to my two siblings...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:30
translate chinese CR3_NS5_rep_e43fc0f2:

    # Caroline "(Sara is far too naive to even know what a dildo is. Right? I mean, there’s no way she would actually want to steal it for herself.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:32
translate chinese CR3_NS5_rep_e59103ae:

    # Caroline "(There’s no way Bob would have found my vibrator - he hardly pays me any attention.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:33
translate chinese CR3_NS5_rep_922aa51c:

    # Caroline "(This narrows things down to the other two tenants...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:35
translate chinese CR3_NS5_rep_ab61cafb:

    # Caroline "(Sara is far too nerdy to be interested in sex. Right? I mean there’s no way she would actually want to steal it for herself.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:39
translate chinese CR3_NS5_rep_9f855b8f:

    # Caroline "(So, that leaves [player_name].)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:40
translate chinese CR3_NS5_rep_a3bdb3ba:

    # Caroline "(He already admitted to me at my job that he has been listening to me masturbate. That means he is aware I’ve been using a vibrator.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:42
translate chinese CR3_NS5_rep_54f8555c:

    # Caroline "(Now, if I was my brother, and I stole a dildo, where would I hide it?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:44
translate chinese CR3_NS5_rep_cf5a3846:

    # Caroline "(Now, if I was [player_name], and I stole a dildo, where would I hide it?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:48
translate chinese CR3_NS5_rep_ab97d42a:

    # Caroline "(Under my bed would be far too obvious.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:49
translate chinese CR3_NS5_rep_df16d9c5:

    # Caroline "(Any hiding place around my desk would be too risky - [Mom_name] could easily spot it when she was cleaning.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:50
translate chinese CR3_NS5_rep_7ab28e2b:

    # Caroline "(Which leaves... the drawers.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:54
translate chinese CR3_NS5_rep_7bc7d58a:

    # Caroline "(These are out of sight, and Mom would never need to go poking around in them.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:56
translate chinese CR3_NS5_rep_33fe2c25:

    # Caroline "(These are out of sight, and Linda would never need to go poking around in them.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:57
translate chinese CR3_NS5_rep_5c70cdd8:

    # Caroline "Aha! (I think I’ve got it...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:61
translate chinese CR3_NS5_rep_bccfa7c7:

    # Caroline "Well, fuck me... It was [player_name], after all."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:62
translate chinese CR3_NS5_rep_0d307850:

    # Caroline "(Alright, time to confront this little bastard! He has absolutely NO respect for private property!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:63
translate chinese CR3_NS5_rep_dc3cb3b6:

    # Caroline "(He’s in for a very rude awakening!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:70
translate chinese CR3_NS5_rep_22b3d350:

    # Caroline "Psst! Hey!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:71
translate chinese CR3_NS5_rep_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:72
translate chinese CR3_NS5_rep_9c0e7b40:

    # Caroline "Wake up!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:73
translate chinese CR3_NS5_rep_bfd45551:

    # MC "Oh, hey Caroline, what’s up?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:77
translate chinese CR3_NS5_rep_a965193a:

    # Caroline "Don’t you ‘hey Caroline’ me! Look what I just found in your drawer!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:78
translate chinese CR3_NS5_rep_652f8bb3:

    # MC "Oh shit..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:79
translate chinese CR3_NS5_rep_749a0642:

    # Caroline "Yeah, you’re in big shit!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:85
translate chinese CR3_NS5_rep_b2d9e7d3:

    # Caroline "What the HELL were you thinking?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:86
translate chinese CR3_NS5_rep_05af9488:

    # MC "Sh-Shush! You’re gonna wake up [Mom_name], if you keep shouting!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:88
translate chinese CR3_NS5_rep_92c3a20e:

    # Caroline "Oh, I’m not worried about THAT! I’m not the one who’s been stealing his sister’s dildo!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:90
translate chinese CR3_NS5_rep_5c4cb244:

    # Caroline "Oh, I’m not worried about THAT! I’m not the one who’s been stealing his best friend’s dildo!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:94
translate chinese CR3_NS5_rep_a48500da:

    # Caroline "I mean, what the hell where you doing?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:95
translate chinese CR3_NS5_rep_39cc2ea1:

    # Caroline "Wait- You haven’t been... USING it, have you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:96
translate chinese CR3_NS5_rep_4450fb36:

    # MC "God! No! I just wanted to... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:100
translate chinese CR3_NS5_rep_e89ca926:

    # Caroline "This thing was bloody expensive! If it’s been up your ass, I swear to God you’re buying me a new one!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:101
translate chinese CR3_NS5_rep_1c206cd7:

    # Caroline "I mean, Jesus Christ, how did you even steal it? Did you sneak in when I was asleep?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:105
translate chinese CR3_NS5_rep_82dde0d6:

    # MC "NO! I haven’t been using it!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:106
translate chinese CR3_NS5_rep_7ed67d16:

    # Caroline "Then why the HELL would you want my dildo?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:110
translate chinese CR3_NS5_rep_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:111
translate chinese CR3_NS5_rep_8349d786:

    # MC "I just wanted you to come to me instead of some stupid plastic toy, when you were horny..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:112
translate chinese CR3_NS5_rep_6f66cf96:

    # Caroline "Wh-What?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:116
translate chinese CR3_NS5_rep_cbde957f:

    # Caroline "Are you serious??"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:117
translate chinese CR3_NS5_rep_9e0b4def:

    # MC "You were always so horny after our sessions together. I knew you were loving the encounters more than you would ever admit - but you always ended up running back to your room to play with that dildo."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:121
translate chinese CR3_NS5_rep_100a4407:

    # MC "I was hoping that by hiding it, you might change your mind and come running to me instead. I wanted to be the one who could make you cum."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:122
translate chinese CR3_NS5_rep_73785629:

    # MC "I was kinda hoping our deal would be more two-way when we first made it. I don’t want to be the one constantly receiving from you, but never giving anything back."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:123
translate chinese CR3_NS5_rep_386d47b6:

    # MC "I know I can make you happy - just look at what happened when you were in that black lingerie at your work. You loved that day, right?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:127
translate chinese CR3_NS5_rep_d3d1fda6:

    # Caroline "*Sigh* Why didn’t you just speak to me about this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:128
translate chinese CR3_NS5_rep_3ddbb0e9:

    # MC "Because any time I tried to talk to you about the deal, you shut me down. I mean, if you want an example: look at the time I ate your pussy at your work."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:129
translate chinese CR3_NS5_rep_f53635c3:

    # MC "I literally had to throw you down on a couch to stop you running away again. You weren’t up for having a productive conversation on the topic."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:130
translate chinese CR3_NS5_rep_ba7c2298:

    # Caroline "Oh, [player_name]..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:131
translate chinese CR3_NS5_rep_11fcc0a1:

    # MC "I’m sorry, Caroline. I shouldn’t have snuck into your room and stolen your vibrator. I was at my wit’s end though. I didn’t know what else I could do to attract your attention."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:132
translate chinese CR3_NS5_rep_06cbdf12:

    # MC "The way I saw it, the only thing I could think of was physically separating you from that dildo."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:136
translate chinese CR3_NS5_rep_09e13737:

    # MC "And... I... I want to be with you more than just as part of a stupid deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:137
translate chinese CR3_NS5_rep_1f077125:

    # MC "I’m in love with you, Caroline. I really am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:138
translate chinese CR3_NS5_rep_d6282a8c:

    # Caroline "(Oh, my God...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:139
translate chinese CR3_NS5_rep_3643f1d9:

    # MC "Please, I know you’re shocked, but just sit beside me for a few minutes. We can talk about it - and if you’re uncomfortable, you can walk out the door and I’ll never mention it again. Okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:143
translate chinese CR3_NS5_rep_483a38d3:

    # MC "You told me you loved me, that night in the club."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:144
translate chinese CR3_NS5_rep_ca749541:

    # Caroline "[player_name]... I was drunk."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:145
translate chinese CR3_NS5_rep_4a93431e:

    # MC "That doesn’t mean it wasn’t true though. I know you were being honest with me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:149
translate chinese CR3_NS5_rep_169bb239:

    # MC "When you were drunk, it was the most honest you’d been with me, in weeks. You always put up these barriers and excuses when I’m around."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:150
translate chinese CR3_NS5_rep_10c0c975:

    # MC "We could both be happy with each other - the only thing that is keeping us apart, are these walls you keep throwing up. Why?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:151
translate chinese CR3_NS5_rep_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:155
translate chinese CR3_NS5_rep_0597f2cf:

    # Caroline "*Sigh* It’s true..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:158
translate chinese CR3_NS5_rep_daa24d0b:

    # Caroline "But this is why we can’t have this deal any more. It’s affecting both of us."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:159
translate chinese CR3_NS5_rep_a4c7b370:

    # Caroline "I mean, there’s no future for any potential relationship. We can’t go outside together where anyone who knows us might be around."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:163
translate chinese CR3_NS5_rep_26f6a857:

    # MC "W-Wait, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:164
translate chinese CR3_NS5_rep_3f58ddd8:

    # Caroline "It’s over, [player_name]. There’s no future for us. I love you, I’ll admit that - but we’re heading straight for a dead end."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:165
translate chinese CR3_NS5_rep_df112457:

    # Caroline "The deal is off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:169
translate chinese CR3_NS5_rep_5767d4ad:

    # MC "Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:170
translate chinese CR3_NS5_rep_6b4d63c8:

    # Caroline "I’m gonna lock my bedroom door from now on. Apart from saying hello when we pass, I’d rather we didn’t talk for a while."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:171
translate chinese CR3_NS5_rep_ad4cedb4:

    # Caroline "I need to focus on clearing my head."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:175
translate chinese CR3_NS5_rep_6a139c32:

    # MC "Caroline! Please don’t leave!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:176
translate chinese CR3_NS5_rep_cb083fac:

    # Caroline "I’m sorry, [player_name]. This is partly my fault too."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:177
translate chinese CR3_NS5_rep_0701c463:

    # Caroline "I know you’re gonna hate my guts right now - but you’ll look back in five or six years and remember this moment. Then you’ll know, what I was doing is for the best."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:181
translate chinese CR3_NS5_rep_5c73b72e:

    # MC "No! I’m not having any more of this deal on/deal off nonsense!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:182
translate chinese CR3_NS5_rep_fe0f31fd:

    # MC "I want to be with you romantically, and I know that you want the same. If you’re worried about what other people think, then to HELL with them!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:188
translate chinese CR3_NS5_rep_7bd64f2e:

    # Caroline "[player_name]... It’s more complicated than that. Have you actually thought about all the consequences of what would happen if we were together?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:190
translate chinese CR3_NS5_rep_73507b82:

    # Caroline "Mom, Dad, Sara, our friends, extended family, the neighbours... The list of people who would disapprove of us is endless."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:191
translate chinese CR3_NS5_rep_86a5d97a:

    # Caroline "Just let me go and try to forget about me. I’ll look about moving out in the next week."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:193
translate chinese CR3_NS5_rep_1b3bbf2d:

    # Caroline "I’m four years older than you. I’m running my own business, you’re in college. We’re at different places in our lives. You should really be with a woman your own age."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:194
translate chinese CR3_NS5_rep_fb68475c:

    # MC "I’m an adult too!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:195
translate chinese CR3_NS5_rep_b8f545db:

    # Caroline "Just let me go and try to forget about me. I’ll speak to Linda about terminating my lease and moving out within the week."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:199
translate chinese CR3_NS5_rep_e8fde204:

    # MC "I’m not gonna let you leave this room and make the biggest mistake of your life."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:200
translate chinese CR3_NS5_rep_b7c9a7b0:

    # MC "Because, I know in five or six years when YOU look back on this moment, the only thing you’re gonna feel is regret, for not following your heart."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:201
translate chinese CR3_NS5_rep_a6faff16:

    # Caroline "[player_name], I-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:205
translate chinese CR3_NS5_rep_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:206
translate chinese CR3_NS5_rep_68121895:

    # MC "(Here goes nothing... I’ve got to give this moment everything, if I am to have any chance of making her stay.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:210
translate chinese CR3_NS5_rep_30607fec:

    # MC "Please, Caroline. Don’t run away from me tonight because you’re afraid."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:211
translate chinese CR3_NS5_rep_14fcd723:

    # MC "It’s okay to be scared - I’m a little scared too. We can overcome it together though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:213
translate chinese CR3_NS5_rep_63229443:

    # Caroline "Our parents are gonna kill us when they find out..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:214
translate chinese CR3_NS5_rep_9f7c42da:

    # MC "Then we’ll just have to make sure they don’t find out."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:218
translate chinese CR3_NS5_rep_3e005fba:

    # Caroline "(I’ve spent my whole life standing on my own two feet. I’ve always been wary of relying on anyone else.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:219
translate chinese CR3_NS5_rep_b232ee87:

    # Caroline "(Perhaps I’ve been shutting people out, who were only trying to make my life better.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:220
translate chinese CR3_NS5_rep_aaa99e5c:

    # Caroline "O-Okay..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:224
translate chinese CR3_NS5_rep_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:225
translate chinese CR3_NS5_rep_36113a7c:

    # Caroline "I said, okay. I’m staying."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:226
translate chinese CR3_NS5_rep_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:230
translate chinese CR3_NS5_rep_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:231
translate chinese CR3_NS5_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:232
translate chinese CR3_NS5_rep_fd4ac290:

    # Caroline "(I can’t believe this is happening...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:236
translate chinese CR3_NS5_rep_cf236af5:

    # Caroline "(Is our deal gone now? What are [player_name] and I?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:237
translate chinese CR3_NS5_rep_719f1140:

    # Caroline "(Is he my boyfriend? Are we supposed to go on dates and stuff now?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:238
translate chinese CR3_NS5_rep_d9069323:

    # Caroline "(Gah - I’m overthinking this again! I need to calm down and try to live in the moment.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:242
translate chinese CR3_NS5_rep_a4cb44a4:

    # MC "(Hopefully, this means Caroline has had a permanent change of heart. This constant deal on/deal off couldn't go on.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:243
translate chinese CR3_NS5_rep_03e4db13:

    # MC "(With each passing day, she was falling more and more in love with me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:244
translate chinese CR3_NS5_rep_609432c2_1:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:248
translate chinese CR3_NS5_rep_28852a2f:

    # MC "(Wow! That was sudden! I wasn’t expecting her to do that!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:249
translate chinese CR3_NS5_rep_936e5b4f:

    # MC "(It feels like she’s finally given herself in to this, entirely...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:253
translate chinese CR3_NS5_rep_9d6027c8:

    # MC "I wasn’t expecting that, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:254
translate chinese CR3_NS5_rep_1363a095:

    # Caroline "Oh, you don’t enjoy me wrapping my legs around you like this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:255
translate chinese CR3_NS5_rep_a9e65168:

    # MC "No! I’m loving it - I just didn’t expect you to be so into it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:259
translate chinese CR3_NS5_rep_777ef62f:

    # Caroline "Hehe, of course I’m into it. Now, let’s take this over to your bed!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:260
translate chinese CR3_NS5_rep_a85f79c6:

    # MC "M-My bed?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:261
translate chinese CR3_NS5_rep_da05907e:

    # Caroline "Of course! You ARE strong enough to carry me over there, right?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:266
translate chinese CR3_NS5_rep_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:267
translate chinese CR3_NS5_rep_5901ba69:

    # Caroline "(God, I love being held by him like this. He’s just so strong and muscular!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:268
translate chinese CR3_NS5_rep_ecd143e4:

    # MC "(I can feel her getting wet through her panties! I wonder if I’ll get to fuck her tonight?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:272
translate chinese CR3_NS5_rep_609432c2_2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:273
translate chinese CR3_NS5_rep_ad9b70a2:

    # Caroline "(I should probably decide, how far I’m willing to go with him tonight. If we’re in a relationship now, then we should probably take things at a normal pace.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:274
translate chinese CR3_NS5_rep_9efbd101:

    # Caroline "(I mean, outside of him coming to my job and us going out to the club together, we haven’t even been on a proper date!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:278
translate chinese CR3_NS5_rep_12210ead:

    # MC "(I can’t believe it’s finally happening. I was losing a little more faith, with each passing day, that we’d ever be together.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:279
translate chinese CR3_NS5_rep_472b9ed8:

    # MC "(Especially during that time when she ended our deal. Why do women have to be so complicated? Can’t they just admit how they feel? Everything would be so much simpler!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:283
translate chinese CR3_NS5_rep_d6c12d2a:

    # MC "Caroline, can we have sex tonight?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:284
translate chinese CR3_NS5_rep_dbe54012:

    # Caroline "Hehe, that’s a little bit fast for me. But there is something else I can do for you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:285
translate chinese CR3_NS5_rep_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:289
translate chinese CR3_NS5_rep_c7aebcd6:

    # Caroline "I don’t think I’ve ever told you how good I am at blowjobs, have I?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:290
translate chinese CR3_NS5_rep_35ec42cb_1:

    # MC "Really?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:291
translate chinese CR3_NS5_rep_623cd168:

    # Caroline "Absolutely. I’m a pro. You’ll cum, the hardest you ever have in your life."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:295
translate chinese CR3_NS5_rep_f77c3837:

    # Caroline "Now, close your eyes. I’m going to strip down."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:296
translate chinese CR3_NS5_rep_53180ef0:

    # MC "Huh?! Why do you want me to close my eyes? I’ve seen everything before!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:297
translate chinese CR3_NS5_rep_99f1cb21:

    # Caroline "Haha!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:301
translate chinese CR3_NS5_rep_230d846c:

    # Caroline "I was just teasing you! Sorry, I couldn't resist!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:302
translate chinese CR3_NS5_rep_a87dcb9a:

    # Caroline "Just lie back and enjoy the view while I strip off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:303
translate chinese CR3_NS5_rep_31fb1b0c:

    # MC "God, your boobs are amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:304
translate chinese CR3_NS5_rep_db5064ea:

    # Caroline "You really like them?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:305
translate chinese CR3_NS5_rep_01a9fabf:

    # MC "I love them! They’re the best!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:309
translate chinese CR3_NS5_rep_a23c0bac:

    # Caroline "Okay, stand up for me. Let’s get this started."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:310
translate chinese CR3_NS5_rep_89e61c0f:

    # MC "(I wonder if she’s exaggerating her blowjob skills, at all?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:314
translate chinese CR3_NS5_rep_bbbc11c1:

    # MC "(I love how she keeps her pubic hair trimmed down. I can just about make out the tip of her clitoris at the bottom of it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:315
translate chinese CR3_NS5_rep_6805c50e:

    # MC "(It certainly made it easy to find, when I was licking her pussy the other day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:319
translate chinese CR3_NS5_rep_e0ae9b91:

    # Caroline "I hope you’re ready. I don’t want you blowing your load in the first couple of minutes."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:320
translate chinese CR3_NS5_rep_f19ec08e:

    # MC "Haha, that would NEVER happen!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:321
translate chinese CR3_NS5_rep_3ed40cff:

    # Caroline "Oh, I wouldn’t be so sure about that. My ex never lasted very long when I put my mouth to work."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:325
translate chinese CR3_NS5_rep_af9d21f2:

    # Caroline "The record is three minutes - so if you can outlast that you’re already outperforming him."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:326
translate chinese CR3_NS5_rep_921a722f:

    # MC "*Gulp* Yeah, I can hold off cumming."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:327
translate chinese CR3_NS5_rep_50f3f1e5:

    # Caroline "We’ll see..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:331
translate chinese CR3_NS5_rep_827bfbe2:

    # Caroline "The trick is to start off by rubbing the guy’s cock, a bit."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:333
translate chinese CR3_NS5_rep_da7d20cb:

    # Caroline "If you stroke it before you use your mouth, you can really build up the anticipation."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:337
translate chinese CR3_NS5_rep_2695dab5:

    # Caroline "Your cock is so hard already. You’re really looking forward to this, aren’t you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:338
translate chinese CR3_NS5_rep_f1367ba1:

    # MC "Oh yeah."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:339
translate chinese CR3_NS5_rep_7dd49b84:

    # Caroline "Well, you won’t be disappointed. I can promise you that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:343
translate chinese CR3_NS5_rep_af3ea908:

    # MC "Ahh... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:344
translate chinese CR3_NS5_rep_b9677fe2:

    # MC "(She’s so good with her hand. I can only imagine how amazing her mouth will feel, once she slips my cock inside it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:345
translate chinese CR3_NS5_rep_da1e7a62:

    # Caroline "(Here we go!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:349
translate chinese CR3_NS5_rep_eec57016:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:350
translate chinese CR3_NS5_rep_061b6594:

    # MC "Ahh... Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:351
translate chinese CR3_NS5_rep_292ee025:

    # Caroline "(Mmm! His cock is delicious! I was kinda worried I’d have to make him wear a condom if the taste was bad.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:355
translate chinese CR3_NS5_rep_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:356
translate chinese CR3_NS5_rep_f4864c18:

    # MC "Mmm... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:357
translate chinese CR3_NS5_rep_1b756506:

    # MC "(She’s swirling her tongue around the tip of my cock while she’s sucking. God, it feels fucking amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:361
translate chinese CR3_NS5_rep_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:362
translate chinese CR3_NS5_rep_bdd88b6f:

    # MC "(Oh wow! She’s going so fast! I never imagined that she would pick up the pace, this quickly!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:363
translate chinese CR3_NS5_rep_c1567567:

    # MC "Ah! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:367
translate chinese CR3_NS5_rep_c258b696:

    # MC "(No wonder her past boyfriends came so fast! She’s relentless!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:368
translate chinese CR3_NS5_rep_2fcc2bc0:

    # Caroline "Hehe, you’re not gonna blow your load already, are you? We haven’t even started the main event yet!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:370
translate chinese CR3_NS5_rep_89beee9f:

    # MC "Th-That wasn’t you giving a blowjob?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:371
translate chinese CR3_NS5_rep_b5535d52:

    # Caroline "Of course not! That was amateur stuff!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:375
translate chinese CR3_NS5_rep_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:376
translate chinese CR3_NS5_rep_75954572:

    # Caroline "I’m just getting you warmed up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:377
translate chinese CR3_NS5_rep_f0c4fa68:

    # MC "(Uh oh... Maybe I won’t last very long...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:381
translate chinese CR3_NS5_rep_e2c07e81_1:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:382
translate chinese CR3_NS5_rep_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:383
translate chinese CR3_NS5_rep_3af181eb:

    # MC "(Damn, she’s licking the underside of my cock near the frenulum. It’s sooo sensitive there!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:387
translate chinese CR3_NS5_rep_e2c07e81_2:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:388
translate chinese CR3_NS5_rep_ea09c733:

    # MC "Ah! Ah! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:389
translate chinese CR3_NS5_rep_03393d73:

    # Caroline "Are you okay there, [player_name]? You’re moaning an AWFUL lot!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:393
translate chinese CR3_NS5_rep_bcaf60d2:

    # MC "Y-Yeah, all good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:394
translate chinese CR3_NS5_rep_bd035b8e:

    # MC "(I need to focus on taking deep breaths. If she keeps this up, I won’t even make it to her ‘main event’ - as she describes it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:398
translate chinese CR3_NS5_rep_23da9308_1:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:399
translate chinese CR3_NS5_rep_cb4277d2:

    # MC "Oh God... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:404
translate chinese CR3_NS5_rep_59d9120c:

    # MC "Ahh.... Hnng! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:405
translate chinese CR3_NS5_rep_449046e4:

    # MC "(Fuck! I’m not gonna last much longer! Her mouth is just too good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:406
translate chinese CR3_NS5_rep_ed63ee98:

    # MC "AHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:410
translate chinese CR3_NS5_rep_3ee6ad2c:

    # MC "I’m cumming! Hnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:420
translate chinese CR3_NS5_rep_119d2ca1:

    # Caroline "(Oh wow! I can feel his hot sticky semen, filling my mouth! I can’t believe he came already!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:421
translate chinese CR3_NS5_rep_bac0bb42:

    # Caroline "*GULP GULP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:422
translate chinese CR3_NS5_rep_a23a104f:

    # MC "(Wow! She swallowed it all!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:426
translate chinese CR3_NS5_rep_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:427
translate chinese CR3_NS5_rep_f657766c:

    # Caroline "You came already!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:428
translate chinese CR3_NS5_rep_dc6381e8:

    # MC "I couldn't help it! You were moving your head so fast, and your tongue was-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:432
translate chinese CR3_NS5_rep_2896e54b:

    # Caroline "We didn't even get to the main event, and you’re already getting soft."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:433
translate chinese CR3_NS5_rep_aba3ce79:

    # MC "Hey, it’s not my fault! You were-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:434
translate chinese CR3_NS5_rep_d5c8eccf:

    # Caroline "I guess I’m gonna have to take drastic measures."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:435
translate chinese CR3_NS5_rep_5b2bfd1d:

    # MC "Huh? What do you mean?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:439
translate chinese CR3_NS5_rep_bad20fee:

    # Caroline "Well, you still haven’t gotten a proper blowjob from me - so I’m just gonna have to figure out a way to make you hard again, so we can continue."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:440
translate chinese CR3_NS5_rep_8a10443c:

    # MC "I’m a guy, Caroline! We don’t cum multiple times like girls do!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:444
translate chinese CR3_NS5_rep_9d9f9ad9:

    # Caroline "We’ll see about that. I still have a few tricks up my sleeve."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:445
translate chinese CR3_NS5_rep_b3a2183b:

    # MC "Seriously, Caroline. There’s no way I’m gonna get hard again."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:446
translate chinese CR3_NS5_rep_e58181fa:

    # MC "Just give me an hour to rest and I’ll be back up and-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:450
translate chinese CR3_NS5_rep_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:451
translate chinese CR3_NS5_rep_4530ccc8:

    # Caroline "Sit down and shut up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:452
translate chinese CR3_NS5_rep_c42ad36b:

    # MC "Oof!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:456
translate chinese CR3_NS5_rep_327c6efc:

    # Caroline "Now, let’s get your little guy all hard again."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:457
translate chinese CR3_NS5_rep_a68a4721:

    # MC "I’m telling you, this isn’t how it works! If you just want to cuddle for a while then I can continue when I’ve recovered!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:458
translate chinese CR3_NS5_rep_872a5520:

    # Caroline "I’m too damn horny for cuddling!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:462
translate chinese CR3_NS5_rep_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:463
translate chinese CR3_NS5_rep_e5931120:

    # MC "What are you thinking of doing? I don’t have any viagra or anything like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:464
translate chinese CR3_NS5_rep_74fa4bde:

    # Caroline "Oh please... You don’t need viagra to get a guy hard!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:468
translate chinese CR3_NS5_rep_a50c9c65:

    # Caroline "The trick is to grip the base like this... to get the blood flowing once more."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:469
translate chinese CR3_NS5_rep_cb677b2e:

    # Caroline "Then, when you’ve got it started, you want to take your other hand and..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:473
translate chinese CR3_NS5_rep_f05f03be:

    # Caroline "...slap a little life back into the guy!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:474
translate chinese CR3_NS5_rep_1132031c:

    # MC "W-WAIT! You can’t be serious!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:475
translate chinese CR3_NS5_rep_d53b1199:

    # Caroline "Trust me! I’m an expert at this!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:493
translate chinese CR3_NS5_rep_c2f58b27:

    # MC "(Huh, it didn't actually hurt... She just slapped it gently enough for it to sting a tiny bit.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:494
translate chinese CR3_NS5_rep_f1b69f71:

    # Caroline "I told you to trust me. I’m good at this. The trick is to slap the guy’s dick a few times. It triggers pleasure sensations, gets the adrenaline flowing, and almost always makes him hard again."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:495
translate chinese CR3_NS5_rep_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:496
translate chinese CR3_NS5_rep_ea915575:

    # MC "(I can feel it starting to get stiff again!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:501
translate chinese CR3_NS5_rep_20c73366:

    # "*Slap*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:502
translate chinese CR3_NS5_rep_1324e203:

    # MC " OHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:503
translate chinese CR3_NS5_rep_5401950d:

    # Caroline "There we go! We’re getting there, now. Soon, you’ll be hard enough for the main event!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:507
translate chinese CR3_NS5_rep_efb47f26:

    # Caroline "And there we go! Perfect!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:508
translate chinese CR3_NS5_rep_f5e6b07e:

    # MC "Okay, so what’s the main event?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:509
translate chinese CR3_NS5_rep_2ba05216:

    # Caroline "Wait and see!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:513
translate chinese CR3_NS5_rep_23da9308_2:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:514
translate chinese CR3_NS5_rep_5593ab44:

    # MC "W-Wow... Holy fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:515
translate chinese CR3_NS5_rep_39019953:

    # Caroline "(Hehe, I love seeing a guy’s face when I do this for the first time to them!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:519
translate chinese CR3_NS5_rep_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:520
translate chinese CR3_NS5_rep_6aaec685:

    # MC "(The view is incredible from here! I can see her pussy perfectly!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:521
translate chinese CR3_NS5_rep_3fc687f1:

    # MC "(She must be really enjoying this. She is soaking wet right now! If only she’d lower her hips a bit, I could lick her out at the same time she is sucking me off!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:525
translate chinese CR3_NS5_rep_46d31bae:

    # Caroline "*SUCK SHLURP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:526
translate chinese CR3_NS5_rep_cb4277d2_1:

    # MC "Oh God... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:527
translate chinese CR3_NS5_rep_de1191f1:

    # Caroline "*Shllluuurrrrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:531
translate chinese CR3_NS5_rep_2326707c:

    # Caroline "*GAG*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:532
translate chinese CR3_NS5_rep_73f83dcb:

    # MC "HNNNNGGGG!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:533
translate chinese CR3_NS5_rep_29761a29:

    # MC "OH WOW!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:534
translate chinese CR3_NS5_rep_f53af25a:

    # Caroline "(Hehe, I love listening to a guy’s reaction when I do that. It’s so, fun surprising them when they least expect it!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:539
translate chinese CR3_NS5_rep_e381923c:

    # Caroline "*Shlurp Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:540
translate chinese CR3_NS5_rep_b45a90c7:

    # MC "Oh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:541
translate chinese CR3_NS5_rep_a5a6d826:

    # MC "(I can’t believe how quickly things turned around. Less than ten minutes ago she was ready to open my bedroom door and walk out of my life forever.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:545
translate chinese CR3_NS5_rep_bc91f3ee_1:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:546
translate chinese CR3_NS5_rep_a7d1081f_2:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:547
translate chinese CR3_NS5_rep_a89d83af:

    # MC "(If I didn’t have the confidence to confront her about it, everything would be over, right now. I came so close to losing her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:551
translate chinese CR3_NS5_rep_054db30c:

    # Caroline "*SHLURRP* *GAG*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:552
translate chinese CR3_NS5_rep_fc1dfb27:

    # MC "Hnnngg! Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:553
translate chinese CR3_NS5_rep_2a67fc5b:

    # MC "(I can feel my cock sliding down her throat. She’s taking me so deep into her mouth!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:557
translate chinese CR3_NS5_rep_38023485:

    # MC "Ahhh! HNNNNGGG! Fuck! I’m gonna cum again!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:558
translate chinese CR3_NS5_rep_8d230fbb:

    # Caroline "(Hehe, twice in one night! Hopefully, [player_name], will realise how good I am with my mouth and how damn lucky he is!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:559
translate chinese CR3_NS5_rep_ba647409:

    # Caroline "*SHLURP SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:563
translate chinese CR3_NS5_rep_e2053b99:

    # MC "Ahhh! Hnnng! Ugh! Arghhh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:565
translate chinese CR3_NS5_rep_95176477:

    # Caroline "*Gulp Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:576
translate chinese CR3_NS5_rep_9e1de0fa:

    # Caroline "(Wow! I’m actually surprised he produced a second load! I thought I’d drained his balls dry after that first climax!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:577
translate chinese CR3_NS5_rep_ea8cceaa:

    # MC "(She swallowed all my cum again!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:581
translate chinese CR3_NS5_rep_e4b5d049:

    # Caroline "Well? What do you think?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:582
translate chinese CR3_NS5_rep_6678f8c6:

    # MC "*Pant Pant* H-Holy shit... That was fucking good..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:583
translate chinese CR3_NS5_rep_4430171a:

    # Caroline "Hehe, I know. I told you I give the best blowjobs."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:587
translate chinese CR3_NS5_rep_b7c55df8:

    # Caroline "I’m glad you enjoyed that. I could PROBABLY get you hard again for a third round... but I wouldn’t do that to you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:588
translate chinese CR3_NS5_rep_cb47bef2:

    # Caroline "It would leave you exhausted tomorrow morning."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:589
translate chinese CR3_NS5_rep_cea3bc49:

    # MC "N-No... Twice was enough."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:593
translate chinese CR3_NS5_rep_3a477019:

    # Caroline "Go and get some sleep. You and I will need to have a chat tomorrow about where we stand."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:594
translate chinese CR3_NS5_rep_59a691e1:

    # MC "Yeah, that sounds like a good idea."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:595
translate chinese CR3_NS5_rep_321b3f0d:

    # Caroline "Okay, I better get dressed here and sneak back into my room. I’ll be KEEPING my vibrator, by the way. Just in case you’re ever away."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:596
translate chinese CR3_NS5_rep_87cecde8:

    # MC "Haha, I understand. See you tomorrow, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS5_rep.rpy:597
translate chinese CR3_NS5_rep_687dc46b:

    # Caroline "Sleep tight, [player_name]."
    Caroline ""

