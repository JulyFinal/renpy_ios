﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:7
translate chinese celia_toilet_kiss_v1_1dd81b76:

    # Celia "(There he is...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:9
translate chinese celia_toilet_kiss_v1_a8c50544:

    # Celia "(God... I can’t believe I have to go through with this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:11
translate chinese celia_toilet_kiss_v1_814e54ec:

    # Celia "(God... I can’t believe I’m actually going through with this!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:12
translate chinese celia_toilet_kiss_v1_a1ffbc56:

    # Celia "(Sigh...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:15
translate chinese celia_toilet_kiss_v1_c3671491:

    # Celia "[player_name]?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:16
translate chinese celia_toilet_kiss_v1_ab2d3372:

    # MC "(Mwahaha! She came, after all!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:17
translate chinese celia_toilet_kiss_v1_56282d17:

    # MC "Huh?! M-Ms. Celia?! What are you doing in here?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:20
translate chinese celia_toilet_kiss_v1_3686f6d1:

    # MC "This is the men’s bathroom! I think you’ve got the wrong room!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:21
translate chinese celia_toilet_kiss_v1_7adce1a1:

    # Celia "That’s... not what I’m here for."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:22
translate chinese celia_toilet_kiss_v1_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:25
translate chinese celia_toilet_kiss_v1_6f5aa8de:

    # MC "(Wow... she pushed me up against the stall wall.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:26
translate chinese celia_toilet_kiss_v1_c00d3240:

    # MC "What are YOU doing?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:27
translate chinese celia_toilet_kiss_v1_44384256:

    # Celia "Just... shut up."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:30
translate chinese celia_toilet_kiss_v1_32e1eb7a:

    # MC "What’s going on? Are you-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:31
translate chinese celia_toilet_kiss_v1_667b6470:

    # Celia "I’m going to kiss you. And you’re not going to tell anyone. Do you understand?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:32
translate chinese celia_toilet_kiss_v1_e3782e01:

    # MC "But I thought you hated me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:33
translate chinese celia_toilet_kiss_v1_aab39c70:

    # Celia "Just shut up and let it happen."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:37
translate chinese celia_toilet_kiss_v1_d299d50f:

    # MC "(Mwahahaha! As long as I keep playing innocent, she doesn’t know who to believe or how to react!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:39
translate chinese celia_toilet_kiss_v1_e5df1b50:

    # MC "(Heh! She’s REALLY getting into this fantasy! I’ll keep acting completely innocent, and she can keep acting like she doesn’t really want me - even though she TOTALLY does!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:40
translate chinese celia_toilet_kiss_v1_01b6bd78:

    # MC "(Now that I know she’s willing to kiss me, perhaps I can push her to do naughtier things in the future?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:43
translate chinese celia_toilet_kiss_v1_411c9804:

    # Celia "Mmm..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:44
translate chinese celia_toilet_kiss_v1_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:46
translate chinese celia_toilet_kiss_v1_521818de:

    # Celia "(God... I can’t believe I’m being blackmailed into kissing this creep.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:48
translate chinese celia_toilet_kiss_v1_6cbf410c:

    # Celia "(I can’t believe I’m making out in a bathroom stall like this!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:52
translate chinese celia_toilet_kiss_v1_c1cab330:

    # Celia "(When I find the bastard who has that picture, I’ll break his fucking legs!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:53
translate chinese celia_toilet_kiss_v1_5c72d42f:

    # Celia "(This has to be one of the most humiliating experiences of my life! It’s even worse than that lesbian hazing at my sorority house!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:55
translate chinese celia_toilet_kiss_v1_ce182674:

    # Celia "(And yet, here I am. Making out with [player_name], and loving every second of this little fantasy we’ve concocted.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:56
translate chinese celia_toilet_kiss_v1_f01ab216:

    # Celia "(This has to be one of the most humiliating things I’ve ever done. It’s even worse than that lesbian hazing at my sorority house! I wonder if that’s where I got my humiliation kink from?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:57
translate chinese celia_toilet_kiss_v1_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:60
translate chinese celia_toilet_kiss_v1_84ea568f:

    # MC "(She’s properly kissing me - tongue and everything!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:61
translate chinese celia_toilet_kiss_v1_ec076fbb:

    # MC "(And she doesn’t seem to mind me putting my hands on her ass!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:62
translate chinese celia_toilet_kiss_v1_4bfe4b46:

    # MC "(Let’s see how she reacts if I pull her skirt up.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:66
translate chinese celia_toilet_kiss_v1_02951fce:

    # Celia "(Gah! This little pervert is lifting my skirt. But if I try to stop him, I might cause that blackmailing bastard to release the picture.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:67
translate chinese celia_toilet_kiss_v1_b2f2893c:

    # Celia "(I’ll just have to endure it for a while.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:69
translate chinese celia_toilet_kiss_v1_43dce77b:

    # Celia "(My, my... He’s actually lifting my skirt up! I wonder how far he thinks he can take things today!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:70
translate chinese celia_toilet_kiss_v1_0a43c592:

    # Celia "(I’ll humour him for a while, but if he takes things too far I’ll make sure he knows to stop.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:74
translate chinese celia_toilet_kiss_v1_59d1f0f9:

    # Celia "(Okay, this has been going on long enough. I’ve done MORE than what was requested of me.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:75
translate chinese celia_toilet_kiss_v1_d9607046:

    # Celia "(I just hope that creep considers this make-out session enough...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:77
translate chinese celia_toilet_kiss_v1_414863c7:

    # Celia "(Okay, this has gone on for long enough. I’ll end it now and we can play out more scenarios in the future.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:78
translate chinese celia_toilet_kiss_v1_feb7c00b:

    # Celia "(I do hope he enjoyed our make-out session though...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:81
translate chinese celia_toilet_kiss_v1_ecde4c3b:

    # MC "W-Wow! Wh-What was that for, Ms. Celia?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:82
translate chinese celia_toilet_kiss_v1_ec099534:

    # Celia "Shut up."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:83
translate chinese celia_toilet_kiss_v1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:84
translate chinese celia_toilet_kiss_v1_6a5574d4:

    # Celia "Don’t say a word to anyone about this."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:85
translate chinese celia_toilet_kiss_v1_a84eaa7d:

    # MC "I’m confused."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:88
translate chinese celia_toilet_kiss_v1_1064d480:

    # Celia "This is our little secret."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:89
translate chinese celia_toilet_kiss_v1_5bd9f738:

    # MC "R-Really? Will it be happening again?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:91
translate chinese celia_toilet_kiss_v1_7edcaa0e:

    # Celia "(I fucking hope not!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:93
translate chinese celia_toilet_kiss_v1_8f0e50c2:

    # Celia "(Heh, you absolutely know it will!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:94
translate chinese celia_toilet_kiss_v1_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:97
translate chinese celia_toilet_kiss_v1_66551ba0:

    # MC "(Mwahahah! It worked! Her kissing technique is amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_kiss_v1.rpy:98
translate chinese celia_toilet_kiss_v1_70e7873b:

    # MC "(Now I can try, pushing her to go further!)"
    MC ""

