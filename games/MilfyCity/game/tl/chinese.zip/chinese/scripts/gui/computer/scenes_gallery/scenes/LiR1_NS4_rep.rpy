﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:15
translate chinese LiR1_NS4_rep_762b0a40:

    # MC "*Pant* Phew... (It’s a hell of a climb, to get up here!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:16
translate chinese LiR1_NS4_rep_94c6bf04:

    # MC "(Looks like I made it, just in time! They must not have been going for long!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:17
translate chinese LiR1_NS4_rep_5f6bc325:

    # Yazmin "Oh yeah! Right there, baby!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:22
translate chinese LiR1_NS4_rep_0acc467a:

    # MC "(Damn! Yazmin’s holding [Liza_name]’s face, right against her pussy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:24
translate chinese LiR1_NS4_rep_066139c7:

    # Yazmin "Oooh... fuck... Just like that... Work that tongue! Ugh!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:25
translate chinese LiR1_NS4_rep_076e86d6:

    # Liza "*Lick Shlurp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:26
translate chinese LiR1_NS4_rep_33b218c8:

    # Yazmin "Ahhh!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:30
translate chinese LiR1_NS4_rep_9160c384:

    # MC "(Yazmin told me I could come and watch. I wonder if this was what she planned for me to see tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:31
translate chinese LiR1_NS4_rep_3cb7bfdd:

    # MC "(If she knows I’m here, then she must be putting on a show for me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:32
translate chinese LiR1_NS4_rep_ca4283f9:

    # MC "(Perhaps that’s why she’s being - so loud and vocal right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:36
translate chinese LiR1_NS4_rep_c28ace02:

    # Yazmin "I love the way you look up at me, when you’re on your knees. There’s something REALLY sexy about, seeing you so submissive."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:37
translate chinese LiR1_NS4_rep_f13f2c19:

    # Liza "Am I doing good?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:38
translate chinese LiR1_NS4_rep_9c436440:

    # Yazmin "Oh yeah! You’re a fucking - wizard with that tongue."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:42
translate chinese LiR1_NS4_rep_80fd2ba9:

    # Liza "*Shlurp Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:43
translate chinese LiR1_NS4_rep_aabe204e:

    # Yazmin "Hnnnnggg! Ugh! Yes! God, lick my clitty! Just like that! Mmm!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:44
translate chinese LiR1_NS4_rep_9bf85ce0:

    # Yazmin "Oh fuck! Fuck!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:48
translate chinese LiR1_NS4_rep_6e863558:

    # Yazmin "Ahhh! I’m cummmming!!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:49
translate chinese LiR1_NS4_rep_d24e7ef8:

    # Liza "*Lick Lick*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:50
translate chinese LiR1_NS4_rep_2d2c3bb1:

    # Yazmin "Eeeeekkkk! AHHHHHHH!!!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:51
translate chinese LiR1_NS4_rep_4f913e7e:

    # MC "(Holy shit! She was loud, there!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:55
translate chinese LiR1_NS4_rep_3d37b3dd:

    # Yazmin "*Pant Pant*"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:56
translate chinese LiR1_NS4_rep_5889b29a:

    # Liza "Did I do a good job?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:57
translate chinese LiR1_NS4_rep_30c2d957:

    # Yazmin "Oh... Oh yeah... *Pant* Fucking phenomenal... In fact, you did such a good job that I'm going to give you a surprise present now."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:58
translate chinese LiR1_NS4_rep_63d0f3ef:

    # Liza "A surprise?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:62
translate chinese LiR1_NS4_rep_3681ff4e:

    # Yazmin "Yeah. I’m gonna have to blindfold you, though - so it doesn’t get spoiled!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:63
translate chinese LiR1_NS4_rep_699de453:

    # Liza "Oooh, I’m getting all excited!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:64
translate chinese LiR1_NS4_rep_1f36354d:

    # Yazmin "This surprise comes with a couple of rules. Firstly, you are NOT allowed to take the blindfold off."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:65
translate chinese LiR1_NS4_rep_e179347d:

    # Liza "Err, okay? What’s the second rule?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:69
translate chinese LiR1_NS4_rep_525e6ec7:

    # Yazmin "The second rule is, that you must, correctly guess, what I am putting in your mouth. If you get all three right, then you’ll win a HUGE prize."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:70
translate chinese LiR1_NS4_rep_de9734c0:

    # Liza "Yay! Let’s get started! What’s first?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:71
translate chinese LiR1_NS4_rep_33e56959:

    # MC "(Oh, this is gonna be good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:75
translate chinese LiR1_NS4_rep_25eea9a0:

    # Yazmin "Hmm... Let me see? Which one should I do first?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:76
translate chinese LiR1_NS4_rep_b8ceb120:

    # Yazmin "(The ice lolly could be fun, to begin with - But it might be less sexual than the dildo, and I don’t want to kill the mood.)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:77
translate chinese LiR1_NS4_rep_c971d0fd:

    # Yazmin "(I think I’ll play it safe and go with the dildo - I can try the ice lolly after.)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:81
translate chinese LiR1_NS4_rep_60e8c112:

    # Yazmin "Okay, open wide, Dear!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:82
translate chinese LiR1_NS4_rep_c026708c:

    # Liza "This isn’t going to be something disgusting, is it?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:83
translate chinese LiR1_NS4_rep_d5e5f9b0:

    # Yazmin "God no! I wouldn’t do that to you!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:84
translate chinese LiR1_NS4_rep_8aade332:

    # Liza "Okay then... Ahhh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:88
translate chinese LiR1_NS4_rep_c952f276:

    # Liza "*Shlurp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:89
translate chinese LiR1_NS4_rep_5d251229:

    # Liza "Hmm... (It feels cool and hard. It’s very smooth around my lips.)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:90
translate chinese LiR1_NS4_rep_83a6d365:

    # Yazmin "Any ideas yet? Or do you need me to push a bit more in?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:94
translate chinese LiR1_NS4_rep_1b59a664:

    # Liza "Mmpff!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:95
translate chinese LiR1_NS4_rep_d175726f:

    # Liza "(Yeah, this is almost certainly that neon pink dildo that she loves so much. I’ll pretend I don't know for a few more seconds. It’s easier in the long run to just let Yazmin have her fun!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:96
translate chinese LiR1_NS4_rep_972f073d:

    # Yazmin "Well? Are you any closer to guessing?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:100
translate chinese LiR1_NS4_rep_1e6ac963:

    # Liza "*Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:101
translate chinese LiR1_NS4_rep_cea55bf8:

    # Yazmin "Do you need a hint?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:102
translate chinese LiR1_NS4_rep_166dd4f0:

    # Yazmin "It’s something that you LOVE playing with. We share this thing, a lot, together."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:103
translate chinese LiR1_NS4_rep_172aed85:

    # Liza "(Yeah, I have no doubt about it now. It’s definitely that pink dildo.)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:107
translate chinese LiR1_NS4_rep_2d4955bc:

    # Liza "Ahh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:108
translate chinese LiR1_NS4_rep_bde19ca2:

    # Yazmin "Okay, time to guess. Let’s see if you get it."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:109
translate chinese LiR1_NS4_rep_0306dcc3:

    # MC "(There’s no way she’ll get this wrong. [Liza_name]’s not that naive, right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:113
translate chinese LiR1_NS4_rep_ae1afdf6:

    # Liza "It’s your pink dildo, isn’t it?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:114
translate chinese LiR1_NS4_rep_2e65a996:

    # Yazmin "Correct! One point to my beautiful wife!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:115
translate chinese LiR1_NS4_rep_c0469a19:

    # Yazmin "And now for round two..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:119
translate chinese LiR1_NS4_rep_ca7a1aa0:

    # Yazmin "This one is a little bit trickier... Be prepared - This one has a taste to it."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:120
translate chinese LiR1_NS4_rep_bf3e0898:

    # Liza "Ooh... It sounds like this one will be easier, then!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:121
translate chinese LiR1_NS4_rep_3e25becb:

    # Yazmin "You sound very confident! If you’re so sure, then you can give me the name of the object AND what flavour it is."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:122
translate chinese LiR1_NS4_rep_63e22425:

    # Yazmin "(Hehe, there’s no way she’ll be able to give me the flavour - there’s like seven different ones in this ice lolly!)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:126
translate chinese LiR1_NS4_rep_d0e25cdc:

    # Yazmin "Open wide!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:127
translate chinese LiR1_NS4_rep_2d4955bc_1:

    # Liza "Ahh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:128
translate chinese LiR1_NS4_rep_748239b2:

    # MC "(Didn’t Yazmin say that there would be three different items that would go in [Liza_name]’s mouth? I can only see the ice lolly and the dildo on that tray.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:129
translate chinese LiR1_NS4_rep_f8f18544:

    # MC "(I wonder what else she has in mind.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:134
translate chinese LiR1_NS4_rep_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:135
translate chinese LiR1_NS4_rep_ef98e40e:

    # Liza "Hmm... (It’s definitely an ice lolly... But the flavour is difficult to pinpoint. Is that lime? No wait - it’s lemon! And there’s a hint of strawberry too!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:136
translate chinese LiR1_NS4_rep_694c7541:

    # Yazmin "Okay, time up!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:140
translate chinese LiR1_NS4_rep_c952f276_1:

    # Liza "*Shlurp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:141
translate chinese LiR1_NS4_rep_df8ef745:

    # Yazmin "I’m pulling the object out now. I’m gonna need your guess."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:142
translate chinese LiR1_NS4_rep_8466b13b:

    # Liza "(This is a tricky one!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:148
translate chinese LiR1_NS4_rep_15f9c826:

    # Yazmin "Well?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:149
translate chinese LiR1_NS4_rep_b0190519:

    # Liza "Err... I’m not completely sure. I tasted a LOT of different flavours going on. Is it perhaps, one of those multi-coloured lollies?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:150
translate chinese LiR1_NS4_rep_bafb803a:

    # Yazmin "Yup! That’s right! Now for round three."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:154
translate chinese LiR1_NS4_rep_5e3b6d7a:

    # Yazmin "Just sit back and relax, Dear, I’m going to grab the third object."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:155
translate chinese LiR1_NS4_rep_96e5351c:

    # Liza "Okay, Honey!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:156
translate chinese LiR1_NS4_rep_96e86bbf:

    # Yazmin "*Whispered* Come on in, [player_name]. Be very quiet."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:178
translate chinese LiR1_NS4_label_open_win_done_rep_01855fb5:

    # MC "Huh? (What does she want with me?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:187
translate chinese LiR1_NS4_label_open_win_done_rep_b09b9c25:

    # MC "*Whispered* What’s going on, Yazmin? [Liza_name] might see me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:191
translate chinese LiR1_NS4_label_open_win_done_rep_6a56706e:

    # Yazmin " *Whispered* It’s fine. She’s blindfolded. I’ve covered her ears, as well - so she probably won’t hear us."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:192
translate chinese LiR1_NS4_label_open_win_done_rep_b4600f09:

    # MC " *Whispered* Probably?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:193
translate chinese LiR1_NS4_label_open_win_done_rep_f9d295d7:

    # Yazmin " *Whispered* YOU’RE my third object. I need you to get over there and whip your cock out."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:194
translate chinese LiR1_NS4_label_open_win_done_rep_30965637:

    # MC " *Whispered* You’re insane!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:195
translate chinese LiR1_NS4_label_open_win_done_rep_3fe3c2fc:

    # Yazmin " *Whispered* If you don’t get over there, right now, I’ll just take her blindfold off and let YOU do the explaining, for why you are in our bedroom!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:199
translate chinese LiR1_NS4_label_open_win_done_rep_9ab8e812:

    # MC "(Fuck, she’s got me there... What the hell is Yazmin getting out of this?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:200
translate chinese LiR1_NS4_label_open_win_done_rep_2054b721:

    # MC "(Why does she want to see her own wife give a blowjob to a man?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:201
translate chinese LiR1_NS4_label_open_win_done_rep_e2b3c50d:

    # Yazmin "*Whispered* Hurry up! She’s been waiting long enough."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:205
translate chinese LiR1_NS4_label_open_win_done_rep_d7f0ba9a:

    # Liza "Uhh... Yazmin? Are you still there?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:206
translate chinese LiR1_NS4_label_open_win_done_rep_b20e1206:

    # Yazmin "I’m still here, sweetie. Just keep your mouth open. Here comes the final item!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:207
translate chinese LiR1_NS4_label_open_win_done_rep_2d4955bc:

    # Liza "Ahh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:211
translate chinese LiR1_NS4_label_open_win_done_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:212
translate chinese LiR1_NS4_label_open_win_done_rep_227e476a:

    # Yazmin "*Whispered* You better keep your moans down. Don’t you DARE spoil this for me!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:213
translate chinese LiR1_NS4_label_open_win_done_rep_07218026:

    # MC "*Whispered* Shit... I’ll try..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:217
translate chinese LiR1_NS4_label_open_win_done_rep_e0399c3e:

    # Liza "Hmm... (This one has a funny taste to it. It’s... slightly salty?)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:218
translate chinese LiR1_NS4_label_open_win_done_rep_1465acf4:

    # Liza "(And it’s warm to the touch... This is weird. What on Earth is it?!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:219
translate chinese LiR1_NS4_label_open_win_done_rep_973a7085:

    # Yazmin "Hehe... Are you having trouble guessing there, Dear? Try taking a bit more in your mouth. It will help you figure it out."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:223
translate chinese LiR1_NS4_label_open_win_done_rep_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:225
translate chinese LiR1_NS4_label_open_win_done_rep_079c454e:

    # MC "Ohh... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:226
translate chinese LiR1_NS4_label_open_win_done_rep_affc8ff1:

    # MC "(Damn, it’s near impossible to keep myself quiet, when she’s slurping on my dick like this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:230
translate chinese LiR1_NS4_label_open_win_done_rep_23eda47e:

    # Liza "Mmm... *Suck* Hmm..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:232
translate chinese LiR1_NS4_label_open_win_done_rep_d546865b:

    # Yazmin "Still can’t figure it out, can you?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:233
translate chinese LiR1_NS4_label_open_win_done_rep_50b3c1f0:

    # Yazmin "Perhaps I bought a new toy for us, as a surprise?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:237
translate chinese LiR1_NS4_label_open_win_done_rep_95f9eb15:

    # MC "(Yazmin is deliberately misleading Liza to try and make her keep sucking on it! To be fair, if [Liza_name] figured out she was actually sucking a cock right now - she would freak the fuck out!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:238
translate chinese LiR1_NS4_label_open_win_done_rep_4e8fa878:

    # Liza "(I just can’t work it out - it almost feels like skin. Perhaps it’s a hyper-realistic dildo? Why would Yazmin get one of those? She KNOWS I don’t like cocks...)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:240
translate chinese LiR1_NS4_label_open_win_done_rep_52f9a96b:

    # Liza "(I just can’t work it out - it almost feels like skin. Perhaps it’s a hyper-realistic dildo?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:241
translate chinese LiR1_NS4_label_open_win_done_rep_1e6ac963:

    # Liza "*Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:245
translate chinese LiR1_NS4_label_open_win_done_rep_266e9d72:

    # Yazmin "*Whispered* You’re doing a great job... Just keep going, a little bit longer."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:246
translate chinese LiR1_NS4_label_open_win_done_rep_67ae833b:

    # MC "*Whispered* W-Wait, you can’t be serious? What if I accidentally cum in her mouth?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:247
translate chinese LiR1_NS4_label_open_win_done_rep_583a514c:

    # Yazmin "*Whispered* It’s okay - just make sure you pull out in time!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:248
translate chinese LiR1_NS4_label_open_win_done_rep_89c8f1c5:

    # MC "*Whispered* Err... if you’re sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:252
translate chinese LiR1_NS4_label_open_win_done_rep_6d2f29b8:

    # Yazmin "Oh c’mon, Dear! There’s NO way you’ll ever guess it, if you only take in the tip!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:253
translate chinese LiR1_NS4_label_open_win_done_rep_0fb2cf34:

    # Yazmin "I mean - ah... the TIP of the object!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:254
translate chinese LiR1_NS4_label_open_win_done_rep_58b512a4:

    # Yazmin "(Shit! I almost gave myself away, there!)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:258
translate chinese LiR1_NS4_label_open_win_done_rep_e44b6429:

    # Liza "(It REALLY feels like I’m giving a blowjob, right now... but if Yazmin insists that I need to go deeper, then I guess it’s worth the effort?)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:259
translate chinese LiR1_NS4_label_open_win_done_rep_4a400b0f:

    # Liza "(Who knows? Maybe I’ll actually like this surprise, once I see it!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:260
translate chinese LiR1_NS4_label_open_win_done_rep_c952f276:

    # Liza "*Shlurp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:261
translate chinese LiR1_NS4_label_open_win_done_rep_0f756bc9:

    # MC "Hnng...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:265
translate chinese LiR1_NS4_label_open_win_done_rep_9693717c:

    # Yazmin "Oh Honey... Do you call THAT going deep?!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:266
translate chinese LiR1_NS4_label_open_win_done_rep_887065a1:

    # Yazmin "You can do MUCH better than that! Take another inch into that pretty little mouth of yours!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:267
translate chinese LiR1_NS4_label_open_win_done_rep_72c0143e:

    # Liza "*Shlllurrrrp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:271
translate chinese LiR1_NS4_label_open_win_done_rep_7cd09096:

    # Liza "MMPFFF!!! *GAG*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:273
translate chinese LiR1_NS4_label_open_win_done_rep_cfb4f93f:

    # Liza "(It’s almost going down my throat! And I’m STILL no closer to figuring out what this is!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:274
translate chinese LiR1_NS4_label_open_win_done_rep_d83c8c64:

    # Liza "(What on Earth is Yazmin playing at?! There’s NO WAY I’ll guess this, without a hint!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:278
translate chinese LiR1_NS4_label_open_win_done_rep_e2b716fd:

    # MC "(Fuck... this is incredible! I’m not gonna last much longer!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:279
translate chinese LiR1_NS4_label_open_win_done_rep_437e45c1:

    # Yazmin "(This is even better than I thought it would be! Seeing her suck a cock is so fucking enticing!)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:280
translate chinese LiR1_NS4_label_open_win_done_rep_c8c7b6f7_1:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:284
translate chinese LiR1_NS4_label_open_win_done_rep_bdc11180:

    # Liza "(It seems to be getting saltier the more I suck on it. Actually, come to think of it, it seems to be getting HARDER too!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:285
translate chinese LiR1_NS4_label_open_win_done_rep_f0bc9965:

    # Liza "(There’s no way this is a real cock - so it must be an extremely expensive sex toy!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:289
translate chinese LiR1_NS4_label_open_win_done_rep_2f036875:

    # Yazmin "Okay, you can start taking it out of your mouth now. Get ready to make your guess, Honey!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:291
translate chinese LiR1_NS4_label_open_win_done_rep_8e0a7927:

    # Liza "(Dammit - I haven’t got the slightest clue! I should try sucking on it REALLY hard for the last few seconds.)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:292
translate chinese LiR1_NS4_label_open_win_done_rep_b6927d8b:

    # MC "Hnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:293
translate chinese LiR1_NS4_label_open_win_done_rep_1fbdda20:

    # MC "(W-Wait! She’s sucking too hard! I’m gonna cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:297
translate chinese LiR1_NS4_label_open_win_done_rep_1f9dfac9:

    # Yazmin "(This has been so much fun to watch... I’ll be able to fantasise about this, for WEEKS!)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:298
translate chinese LiR1_NS4_label_open_win_done_rep_dd889bbe:

    # MC "Hnnnngggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:299
translate chinese LiR1_NS4_label_open_win_done_rep_cb1ff1cc:

    # Yazmin "Huh? Oh shit!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:306
translate chinese LiR1_NS4_label_open_win_done_rep_3b6f312d:

    # Yazmin "Nooooo!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:307
translate chinese LiR1_NS4_label_open_win_done_rep_2ed371d9:

    # MC "Hnnngg! AHHHHHHH!!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:308
translate chinese LiR1_NS4_label_open_win_done_rep_59acb895:

    # MC "Ugh! Ahhhh! (Dammit! I came so hard!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:319
translate chinese LiR1_NS4_label_open_win_done_rep_b51ff55c:

    # Liza "Ahh... Uh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:320
translate chinese LiR1_NS4_label_open_win_done_rep_53d41a98:

    # Liza "(What’s this salty taste in my mouth? It’s like... a sticky fluid?)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:321
translate chinese LiR1_NS4_label_open_win_done_rep_f8098fbf:

    # Liza "Wh-What’s going on, Yazmin?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:325
translate chinese LiR1_NS4_label_open_win_done_rep_201b88f0:

    # Yazmin "DON’T TAKE YOUR BLINDFOLD OFF!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:326
translate chinese LiR1_NS4_label_open_win_done_rep_7f6d136c:

    # Liza "Huh?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:327
translate chinese LiR1_NS4_label_open_win_done_rep_447843bb:

    # MC "Oh fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:331
translate chinese LiR1_NS4_label_open_win_done_rep_812c6478:

    # Liza "EEEEEEEKKKKK!!! AHHHHH!!!!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:332
translate chinese LiR1_NS4_label_open_win_done_rep_87baf62a:

    # MC "(SHIT!! SHIT!! SHIT!!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:333
translate chinese LiR1_NS4_label_open_win_done_rep_5134d3ad:

    # Yazmin "Fuck! I told you not to cum!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:337
translate chinese LiR1_NS4_label_open_win_done_rep_c7ff3a39:

    # Yazmin "Hey, it’s okay! It’s okay! Let me wipe all that away."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:339
translate chinese LiR1_NS4_label_open_win_done_rep_8a59ad63:

    # Liza "(Muffled screams)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:340
translate chinese LiR1_NS4_label_open_win_done_rep_de19abd6:

    # MC "Shit! I better go!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:341
translate chinese LiR1_NS4_label_open_win_done_rep_44eef807:

    # Yazmin "You’re not going anywhere, right now! You helped cause this mess!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:346
translate chinese LiR1_NS4_label_open_win_done_rep_eb781484:

    # Liza "Wh-Wh-Wh-Wh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:347
translate chinese LiR1_NS4_label_open_win_done_rep_96f205a5:

    # Yazmin "Deep breaths, Honey."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:348
translate chinese LiR1_NS4_label_open_win_done_rep_a7dc0ebd:

    # Liza "Wh-Wh-Why a-are you n-naked in my bedroom, [player_name]?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:349
translate chinese LiR1_NS4_label_open_win_done_rep_559979ce:

    # MC "I was-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:354
translate chinese LiR1_NS4_label_open_win_done_rep_d8f33b30:

    # Liza "You TRICKED me into sucking your disgusting cock, you FILTHY PERVERT!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:356
translate chinese LiR1_NS4_label_open_win_done_rep_92f89c5f:

    # Liza "I- I- I sucked your cock!!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:357
translate chinese LiR1_NS4_label_open_win_done_rep_75642192:

    # MC "W-Wait, this wasn’t my-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:359
translate chinese LiR1_NS4_label_open_win_done_rep_dfdec5f8:

    # Liza "Just wait until I tell your MOTHER about this! I will report you to the police and-"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:361
translate chinese LiR1_NS4_label_open_win_done_rep_1b0f6aba:

    # Liza "Just wait until I tell Linda about this! She’ll kick you out of her house and-"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:365
translate chinese LiR1_NS4_label_open_win_done_rep_e77e202c:

    # Yazmin "Liza! Shut up!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:366
translate chinese LiR1_NS4_label_open_win_done_rep_a434d925:

    # Liza "Wh-What?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:367
translate chinese LiR1_NS4_label_open_win_done_rep_addd225a:

    # Yazmin "It was MY idea. I was the one who organised this."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:369
translate chinese LiR1_NS4_label_open_win_done_rep_9e3f7812:

    # Liza "Wh-Why? Why would you DO something like that?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:371
translate chinese LiR1_NS4_label_open_win_done_rep_b351f925:

    # Liza "Wh-Why? Why? "
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:375
translate chinese LiR1_NS4_label_open_win_done_rep_2a82ffc9:

    # Yazmin "I’m... I’m sorry... I just wanted to involve you - more in my fantasies."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:376
translate chinese LiR1_NS4_label_open_win_done_rep_5daefd26:

    # Yazmin "I’ve always gone both ways, and I wanted to introduce you gradually to some threesomes with actual cocks."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:378
translate chinese LiR1_NS4_label_open_win_done_rep_0f94455a:

    # Liza "B-By tricking me?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:380
translate chinese LiR1_NS4_label_open_win_done_rep_40ac35c6:

    # Liza "Could we not have talked about this first?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:384
translate chinese LiR1_NS4_label_open_win_done_rep_5552e6f4:

    # Liza "How could you do something like that?! Have you NO conscience?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:385
translate chinese LiR1_NS4_label_open_win_done_rep_0f93656e:

    # Liza "I’m not being dense here - you DO understand what LESBIAN means, right?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:387
translate chinese LiR1_NS4_label_open_win_done_rep_0f6cb1f4:

    # Liza "How could you do something like that?! Was me sucking on that strap-on not enough for you? "
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:389
translate chinese LiR1_NS4_label_open_win_done_rep_58ce47dc:

    # MC "(Fuck! Now I’m stuck in the middle of a full blown domestic argument...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:396
translate chinese LiR1_NS4_label_open_win_done_rep_67b8c24d:

    # Yazmin "I’m sorry... I couldn’t think of another way to bring a man into this relationship, without scaring you off."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:397
translate chinese LiR1_NS4_label_open_win_done_rep_79abf043:

    # Yazmin "And this way, it’s at least a man that you know and trust. Can you see where I was coming from?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:398
translate chinese LiR1_NS4_label_open_win_done_rep_a494c4af:

    # Yazmin "He wasn’t supposed to cum in your mouth, by the way - That was an accident."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:402
translate chinese LiR1_NS4_label_open_win_done_rep_23f35df3:

    # Liza "*Sigh* I... I sort of see where you’re coming from."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:403
translate chinese LiR1_NS4_label_open_win_done_rep_d939772c:

    # Yazmin "Thanks for understanding. I’m sorry, again, for doing it in such an underhanded way."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:407
translate chinese LiR1_NS4_label_open_win_done_rep_2a4a3fd3:

    # Liza "I’m sorry too. Perhaps I wasn’t the most open, to sexual experimentation with you. I’ll try to be more open, to talking with you about these things. I never realised how much this meant to you."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:408
translate chinese LiR1_NS4_label_open_win_done_rep_6852b208:

    # Yazmin "That’s okay, Honey. I think we both learned a lesson tonight."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:412
translate chinese LiR1_NS4_label_open_win_done_rep_91b5428b:

    # Liza "Listen, [player_name] - I’m sorry that this happened... I NEVER wanted you to be roped into ANYTHING like THIS."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:413
translate chinese LiR1_NS4_label_open_win_done_rep_10f528f7:

    # MC "It’s okay, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:414
translate chinese LiR1_NS4_label_open_win_done_rep_8833c015:

    # Liza "Promise me one thing."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:415
translate chinese LiR1_NS4_label_open_win_done_rep_dc19c5b0:

    # MC "Anything."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:417
translate chinese LiR1_NS4_label_open_win_done_rep_ea97c95c:

    # Liza "Don’t say A WORD to my sister, okay?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:419
translate chinese LiR1_NS4_label_open_win_done_rep_3eddfc7b:

    # Liza "Don’t say A WORD to Linda, okay?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:420
translate chinese LiR1_NS4_label_open_win_done_rep_52beaed3:

    # MC "My lips are sealed."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:424
translate chinese LiR1_NS4_label_open_win_done_rep_0e8d23b3:

    # Yazmin "Well, now that we’re all sorted here - how about I get you on the bed?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:425
translate chinese LiR1_NS4_label_open_win_done_rep_19b4e23a:

    # Liza "Me?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:426
translate chinese LiR1_NS4_label_open_win_done_rep_1611f42c:

    # Yazmin "No! I’m talking about [player_name]. He’s already half naked and raring to go!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:427
translate chinese LiR1_NS4_label_open_win_done_rep_4118a9f1:

    # Yazmin "I’ve waited YEARS, to be fucked again, by a cock - and now that we’re being open about our relationship..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:428
translate chinese LiR1_NS4_label_open_win_done_rep_f26b6003:

    # Yazmin "I think it’s time that you got to see how fun a big dick can be. Watch this, Liza!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:435
translate chinese LiR1_NS4_label_open_win_done_rep_b8dc1d42:

    # Yazmin "The best way to start, is the cowgirl position. It gives you control over, how deep, you want to - take the dick inside you. And it also gives you a GREAT workout!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:436
translate chinese LiR1_NS4_label_open_win_done_rep_1ea3a0b6:

    # Liza "Uh huh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:438
translate chinese LiR1_NS4_label_open_win_done_rep_5fda7e9e:

    # Liza "(What the hell is going on...? Why am I suddenly watching my wife ride my nephew?! Why am I not jealous?)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:440
translate chinese LiR1_NS4_label_open_win_done_rep_fc99f7b8:

    # Liza "(What the hell is going on? Why am I suddenly watching my wife ride a guy?!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:444
translate chinese LiR1_NS4_label_open_win_done_rep_9ffad4a7:

    # Yazmin "It feels great, if you grind along the length of it. Coat his cock in your juices - It’ll make it easier for it to slide in, when the time comes."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:445
translate chinese LiR1_NS4_label_open_win_done_rep_91167a6c:

    # Liza "Wow..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:446
translate chinese LiR1_NS4_label_open_win_done_rep_e049d159:

    # Yazmin "Mmm... It brushes nicely against your clitoris, if you apply a little pressure. Plus, it feels great for the man too."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:450
translate chinese LiR1_NS4_label_open_win_done_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:451
translate chinese LiR1_NS4_label_open_win_done_rep_1291c89a:

    # Yazmin "See? Just look at that expression on [player_name]’s face. He’s LOVING this!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:452
translate chinese LiR1_NS4_label_open_win_done_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:456
translate chinese LiR1_NS4_label_open_win_done_rep_4d8e846c:

    # Liza "D-Does it not hurt you at all, [player_name]?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:457
translate chinese LiR1_NS4_label_open_win_done_rep_732b3646:

    # MC "Why would it hurt me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:458
translate chinese LiR1_NS4_label_open_win_done_rep_4923046b:

    # Liza "I was just thinking... she was sitting on your... thing - and it might hurt."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:459
translate chinese LiR1_NS4_label_open_win_done_rep_38df4456:

    # MC "No, there’s no pain. It feels really good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:463
translate chinese LiR1_NS4_label_open_win_done_rep_5f238525:

    # Liza "*Gulp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:464
translate chinese LiR1_NS4_label_open_win_done_rep_117af9b1:

    # Liza "Is he going to cum again?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:465
translate chinese LiR1_NS4_label_open_win_done_rep_5e7fcc20:

    # Yazmin "Honestly? Most guys take at least an hour to recharge, between orgasms. However, I’m pretty damn good on top. I reckon I can make him squirt again, for you."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:469
translate chinese LiR1_NS4_label_open_win_done_rep_2358e244:

    # Yazmin "I just gotta slide my hips back and forth like this, to get him nice and hard."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:470
translate chinese LiR1_NS4_label_open_win_done_rep_4b2bdc60:

    # MC "Hgh... Ohh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:471
translate chinese LiR1_NS4_label_open_win_done_rep_131a9ce6:

    # Yazmin "Yeah, you’re enjoying this, aren’t you?!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:475
translate chinese LiR1_NS4_label_open_win_done_rep_8f9e53d9:

    # MC "(This feels soooo good! Her vulva is massaging, up and down my shaft. I reckon, she probably WILL get another orgasm out of me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:476
translate chinese LiR1_NS4_label_open_win_done_rep_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:477
translate chinese LiR1_NS4_label_open_win_done_rep_a2333938:

    # Yazmin "Y’know Liza, you can do more than just sit there. Go ahead and touch yourself, if you want!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:478
translate chinese LiR1_NS4_label_open_win_done_rep_61e2224d:

    # Liza "I... uh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:482
translate chinese LiR1_NS4_label_open_win_done_rep_af23e0a8:

    # Yazmin "I hope you’re ready, [player_name] because you’re about to have the ride of your life."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:483
translate chinese LiR1_NS4_label_open_win_done_rep_3a5585e1:

    # MC "Yeah, but aren’t you - like six years out of practice?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:484
translate chinese LiR1_NS4_label_open_win_done_rep_9dd62f9e:

    # Yazmin "Maybe... But I’ve ridden more cocks, before I met Liza, than you ever will have gotten, in your whole life."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:485
translate chinese LiR1_NS4_label_open_win_done_rep_ca60b4ac:

    # MC "(She’s certainly confident! I gotta give her that!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:489
translate chinese LiR1_NS4_label_open_win_done_rep_e1275175:

    # Liza "(Oh, my God... It’s actually going in! She’s ACTUALLY going to screw him!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:490
translate chinese LiR1_NS4_label_open_win_done_rep_ca37f39e:

    # Liza "(Why can’t I turn my head away?!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:491
translate chinese LiR1_NS4_label_open_win_done_rep_a5ce446d:

    # MC "Ah... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:495
translate chinese LiR1_NS4_label_open_win_done_rep_b841c90c:

    # MC "Ohhh... holy fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:496
translate chinese LiR1_NS4_label_open_win_done_rep_488c202f:

    # Yazmin "Mmm! Yeeessss!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:497
translate chinese LiR1_NS4_label_open_win_done_rep_075d6cf2:

    # Yazmin "How’s that, [player_name]? Pretty tight, right?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:501
translate chinese LiR1_NS4_label_open_win_done_rep_42ae8262:

    # Liza "OH, MY GOD!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:502
translate chinese LiR1_NS4_label_open_win_done_rep_6ce02787:

    # Yazmin "I know that expression, Liza. You’re longing to try this yourself, aren’t you?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:503
translate chinese LiR1_NS4_label_open_win_done_rep_d328f9fb:

    # Yazmin "You REALLY want to feel a thick hard cock buried deep, in that virgin pussy of yours. If it wasn’t for me and my dildos, you’d still have your hymen intact!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:507
translate chinese LiR1_NS4_label_open_win_done_rep_2b01ba45:

    # Yazmin "Ah... Ohh..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:508
translate chinese LiR1_NS4_label_open_win_done_rep_5bee8127:

    # Yazmin "I’ve missed having a fat cock inside me. I can’t wait to feel you blow your load, deep in my soaking wet cunt."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:509
translate chinese LiR1_NS4_label_open_win_done_rep_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:513
translate chinese LiR1_NS4_label_open_win_done_rep_156eca17:

    # Yazmin "*Gasp* Oh yeah, that’s it! Mmm!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:514
translate chinese LiR1_NS4_label_open_win_done_rep_ca1c8c0a:

    # Liza "I-It’s so big... D-Does it hurt?!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:515
translate chinese LiR1_NS4_label_open_win_done_rep_963a4453:

    # Yazmin "Ah! Ohh... It feels... like a dildo, but sooo much better."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:519
translate chinese LiR1_NS4_label_open_win_done_rep_3e05671c:

    # Yazmin "Ahh! Ahhh! Yes!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:520
translate chinese LiR1_NS4_label_open_win_done_rep_58c7d365:

    # MC "Ah! Uh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:521
translate chinese LiR1_NS4_label_open_win_done_rep_7b83119e:

    # MC "(She’s bouncing up and down on my cock faster now! I don’t know if I’ll be able to last much longer!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:525
translate chinese LiR1_NS4_label_open_win_done_rep_b26228a4:

    # MC "Hnnnnnng! Auntie Yazmin, I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:527
translate chinese LiR1_NS4_label_open_win_done_rep_7e4c7376:

    # MC "Hnnnnnng! Yazmin, I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:528
translate chinese LiR1_NS4_label_open_win_done_rep_f0f7dfd7:

    # Yazmin "Cum for me! Shoot your load, deep inside my pussy!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:529
translate chinese LiR1_NS4_label_open_win_done_rep_a92bed53:

    # Liza "(This... is insane... I have to be dreaming!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:533
translate chinese LiR1_NS4_label_open_win_done_rep_71ed01aa:

    # Yazmin "YEEESSSS! I can feel your cock pulsing inside me!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:539
translate chinese LiR1_NS4_label_open_win_done_rep_bcefeac8:

    # Yazmin "Fill me with your hot cum! AHHHHH!!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:541
translate chinese LiR1_NS4_label_open_win_done_rep_0891f1e4:

    # MC "HNNNNG!!! UGH!! AHHHHHHH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:542
translate chinese LiR1_NS4_label_open_win_done_rep_6e04bc9d:

    # Yazmin "AHHHHH!!!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:543
translate chinese LiR1_NS4_label_open_win_done_rep_d2dd9bb3:

    # MC "(Holy fuck! Her whole body is shaking, on top of me! We’re cumming at the same time!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:554
translate chinese LiR1_NS4_label_open_win_done_rep_c7e328ea:

    # MC "HNNNNGGG! UGH! Aaaahhhhh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:555
translate chinese LiR1_NS4_label_open_win_done_rep_6677c4c2:

    # Yazmin "Yeeessss... Ohh... *Pant Pant*"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:556
translate chinese LiR1_NS4_label_open_win_done_rep_f205fb6b:

    # Yazmin "Fuck... That was good!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:560
translate chinese LiR1_NS4_label_open_win_done_rep_06f49c8f:

    # Liza "Y-You just... came inside her!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:561
translate chinese LiR1_NS4_label_open_win_done_rep_14eb898f:

    # Liza "Wh-What if you get her pregnant?! This is SO unsafe!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:568
translate chinese LiR1_NS4_label_open_win_done_rep_35359c52:

    # MC "I’m pulling out! It’s too risky to cum inside!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:572
translate chinese LiR1_NS4_label_open_win_done_rep_046854b4:

    # MC "Ahhh! Ugh! Hnnnnnggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:573
translate chinese LiR1_NS4_label_open_win_done_rep_cedaf9d7:

    # Liza "(Phew... At least he pulled out. If he came inside her, I’d be worried sick that Yazmin would get pregnant!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:584
translate chinese LiR1_NS4_label_open_win_done_rep_82f1ca63:

    # MC "Aahhhhhh! Fuck! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:586
translate chinese LiR1_NS4_label_open_win_done_rep_39915154:

    # Yazmin "Wow! So much cum! I thought you emptied your balls when your Auntie Liza sucked you off!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:588
translate chinese LiR1_NS4_label_open_win_done_rep_db3ae35d:

    # Yazmin "Wow! So much cum! I thought you emptied your balls when Liza sucked you off!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:595
translate chinese LiR1_NS4_continue_rep_397f6e49:

    # Yazmin "Well? What’d you think, [player_name]?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:596
translate chinese LiR1_NS4_continue_rep_76fd5d24:

    # Yazmin "Wasn’t that the best - cowgirl sex - you’ve ever had?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:597
translate chinese LiR1_NS4_continue_rep_0b716bdc:

    # MC "It was... pretty fucking awesome!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:601
translate chinese LiR1_NS4_continue_rep_451451ba:

    # Liza "[player_name]! Language!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:602
translate chinese LiR1_NS4_continue_rep_1c41ea04:

    # Liza "And as for YOU, Yazmin! We need to have a serious talk."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:604
translate chinese LiR1_NS4_continue_rep_b985671e:

    # Liza "[player_name], let yourself out of the house. Your Aunt Yazmin and I, have A LOT to discuss. Including, what constitutes HEALTHY boundaries in a relationship."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS4_rep.rpy:606
translate chinese LiR1_NS4_continue_rep_e03ba06a:

    # Liza "[player_name], let yourself out of the house. Yazmin and I, have A LOT to discuss. Including, what constitutes HEALTHY boundaries in a relationship."
    Liza ""

