﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:23
translate chinese Z_ES4_rep_946f9916:

    # Zuri "Well, [player_name], it seems like I made the right decision to trust you."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:25
translate chinese Z_ES4_rep_de127828:

    # Suri "Yeah, you really pulled through for us, kid."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:27
translate chinese Z_ES4_rep_f417904d:

    # Suri "Yeah, you really pulled through for us, pal."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:28
translate chinese Z_ES4_rep_ca85e44d:

    # Zuri "Those names have made us a WHOLE lotta money."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:32
translate chinese Z_ES4_rep_9d1cbb4b:

    # MC "Hey, I’m just happy I could be of help."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:33
translate chinese Z_ES4_rep_c813105e:

    # Zuri "Well, we’re grateful."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:34
translate chinese Z_ES4_rep_46bd04fc:

    # Suri "Very grateful."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:35
translate chinese Z_ES4_rep_1fab15bd:

    # Zuri "Take a seat and we’ll show you just how grateful we are."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:39
translate chinese Z_ES4_rep_d09b945b:

    # Zuri "You may not have realised it yet, but what you did for us, means we will never need to work another day in our lives."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:40
translate chinese Z_ES4_rep_caad7d5e:

    # MC "R-Really?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:41
translate chinese Z_ES4_rep_bcf4c897:

    # Zuri "Oh, yes. The mortgage on this house has been fully paid. All our debts are gone, and the interest we get from our investments is more than the average salary in this country!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:42
translate chinese Z_ES4_rep_cbee4c43:

    # MC "Wow... That’s insane!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:46
translate chinese Z_ES4_rep_292f9e52:

    # Suri "You better enjoy every last moment of this, kid. You earned it!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:48
translate chinese Z_ES4_rep_9cc782bb:

    # Suri "You better enjoy every last moment of this, pal. You earned it!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:49
translate chinese Z_ES4_rep_1c018eb7:

    # Suri "This is a multi-million dollar ass, right here!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:50
translate chinese Z_ES4_rep_accd44b2:

    # Suri "You’ll probably never see a pussy this expensive again, in your whole life!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:54
translate chinese Z_ES4_rep_45e087b4:

    # Suri "Sit back, relax, and take it ALL in."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:55
translate chinese Z_ES4_rep_673b3295:

    # Zuri "Take your pants off, [player_name]. We need your cock out for the next part."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:56
translate chinese Z_ES4_rep_29af55f8:

    # MC "Oh yeah... I’ll do that now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:60
translate chinese Z_ES4_rep_0f550d04:

    # Suri "Mmm! Hard, as always! I’m looking forward to riding this boner!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:61
translate chinese Z_ES4_rep_f8eb3beb:

    # MC "D-Do you want me to use a condom or-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:62
translate chinese Z_ES4_rep_d6cf3b01:

    # Zuri "Relax - we’re both on the pill."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:66
translate chinese Z_ES4_rep_91acbaa4:

    # MC "*Phew* Good, I just had to check. Don’t want a surprise to bite me in the ass, in nine months!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:67
translate chinese Z_ES4_rep_b5627913:

    # Suri "Haha! You’re cute!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:68
translate chinese Z_ES4_rep_1307a953:

    # Zuri "Line your cock up with her pussy, and get ready for some fun!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:72
translate chinese Z_ES4_rep_1e20d78e:

    # MC "(I can feel the warmth, from her body against mine...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:73
translate chinese Z_ES4_rep_c78bcef1:

    # MC "(The tip of my dick is pressing, right against her vulva! She’s so wet right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:74
translate chinese Z_ES4_rep_66bf3aca:

    # MC "(I don’t know if I can last very long, with such a hot girl riding my dick!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:78
translate chinese Z_ES4_rep_e94d9fff:

    # Suri "That’s it! You can do it..."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:79
translate chinese Z_ES4_rep_f325a4a6:

    # Suri "Rub it on my pussy a little, before putting it in.."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:81
translate chinese Z_ES4_rep_50579f4a:

    # Suri "Mmm...Good.. Your cock is so big... Push it inside me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:82
translate chinese Z_ES4_rep_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:86
translate chinese Z_ES4_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:87
translate chinese Z_ES4_rep_280ab3a6:

    # Suri "God... Yessssss!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:88
translate chinese Z_ES4_rep_d83384ae:

    # Zuri "You look like you’re enjoying that, Suri!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:89
translate chinese Z_ES4_rep_6eddced4:

    # Suri "It’s sooo thick! Mmm!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:93
translate chinese Z_ES4_rep_05641a8c:

    # Suri "Oh God! I love your cock, [player_name]!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:94
translate chinese Z_ES4_rep_8b0d2fd2:

    # Suri "Ah! Ahh!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:95
translate chinese Z_ES4_rep_e603e888:

    # MC "(She’s so tight and wet! It feels like her pussy is sucking my cock, every time she bounces!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:99
translate chinese Z_ES4_rep_ed577c3e:

    # MC "(And her breasts are just incredible! She couldn’t be any more than a B Cup, but they’re so perky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:100
translate chinese Z_ES4_rep_c2632e0c:

    # Suri "Ah! Ah! Ahh!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:102
translate chinese Z_ES4_rep_5c27af67:

    # Suri "Why are you looking at my tits, kid?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:104
translate chinese Z_ES4_rep_e71637b0:

    # Suri "Why are you looking at my tits, pal?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:108
translate chinese Z_ES4_rep_ba238991:

    # MC "I- uh... S-sorry."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:110
translate chinese Z_ES4_rep_a8bfdddd:

    # Suri "Hehe, I’m just teasing you. You look as much as you want to."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:111
translate chinese Z_ES4_rep_bba1100f:

    # Suri "You’ve made Zuri and me very rich women. You can do whatever you want to our bodies."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:115
translate chinese Z_ES4_rep_4489c4fa:

    # Zuri "She’s right, you know. If you want to fuck both of us, you can."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:116
translate chinese Z_ES4_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:117
translate chinese Z_ES4_rep_9465d496:

    # Zuri "Uh huh."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:118
translate chinese Z_ES4_rep_bd561b01:

    # Suri "I think he’d- ahh... like that, Zuri! Oooh!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:122
translate chinese Z_ES4_rep_f1fee296:

    # Zuri "Well, [player_name], how would you like to fuck twins at the same time?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:124
translate chinese Z_ES4_rep_8bdb6d35:

    # Zuri "Well, [player_name], how would you like to fuck both us girls at the same time?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:125
translate chinese Z_ES4_rep_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:126
translate chinese Z_ES4_rep_9ce89404:

    # Suri "Hehe, ooh! Let’s blow his mind, Zuri!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:130
translate chinese Z_ES4_rep_d9310047:

    # Suri "How do you want to do this?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:131
translate chinese Z_ES4_rep_82d43ce6:

    # Zuri "Remember that time in university, at the gymnastics club?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:132
translate chinese Z_ES4_rep_f755038e:

    # Suri "Was that the one with the football team or the hockey team?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:133
translate chinese Z_ES4_rep_983df367:

    # Zuri "The football team."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:134
translate chinese Z_ES4_rep_f313295d:

    # Suri "Oooh! Yes! Let’s do that for him!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:138
translate chinese Z_ES4_rep_ea7f9876:

    # Zuri "Well? What do you think?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:139
translate chinese Z_ES4_rep_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:140
translate chinese Z_ES4_rep_603ae27d:

    # Suri "I think he likes it, Zuri!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:144
translate chinese Z_ES4_rep_148fa1e0:

    # Suri "Why do I always have to be on the bottom though?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:146
translate chinese Z_ES4_rep_8ff9da53:

    # Zuri "It’s tradition at this point, I guess. Plus, since I’m the older twin..."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:147
translate chinese Z_ES4_rep_04958e4f:

    # Suri "Oh c’mon! You came out thirty minutes before me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:149
translate chinese Z_ES4_rep_57d209ba:

    # Zuri "It’s tradition at this point, I guess. Plus, I’m older."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:150
translate chinese Z_ES4_rep_90c88740:

    # Suri "Oh, c'mon! You're not THAT much older than me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:151
translate chinese Z_ES4_rep_83a88e59:

    # Zuri "Still technically older!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:156
translate chinese Z_ES4_rep_aff64af2:

    # Zuri "So, which of us would you like to ram your hard cock into first?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:157
translate chinese Z_ES4_rep_30169569:

    # MC "It’s a tough decision! You both look so fucking hot!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:158
translate chinese Z_ES4_rep_e128dbe8:

    # Suri "Pick me! Pick me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:162
translate chinese Z_ES4_rep_b7025ab5:

    # Zuri "MmM! Ahh!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:164
translate chinese Z_ES4_rep_9f8be114:

    # Suri "Aww... He chose you, didn’t he!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:165
translate chinese Z_ES4_rep_ec812339:

    # Zuri "Deeper! Get it right in there!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:169
translate chinese Z_ES4_rep_fdba097b:

    # Zuri "AHH! AHHH! OHHH! GOD! MMMM!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:171
translate chinese Z_ES4_rep_a9381830:

    # Suri "Fuck her as hard as you can, kid!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:173
translate chinese Z_ES4_rep_dcd7912f:

    # Suri "Fuck her as hard as you can, pal!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:175
translate chinese Z_ES4_rep_a61d8b0f:

    # Suri "I love hearing her scream in pleasure!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:177
translate chinese Z_ES4_rep_f0f66584:

    # MC "(Damn! These twins are kinky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:179
translate chinese Z_ES4_rep_5cff4640:

    # MC "(Damn, these gals are kinky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:183
translate chinese Z_ES4_rep_3b6dd77a:

    # Zuri "AH! AHHH! OOOHHH! FUCK! FUCK!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:186
translate chinese Z_ES4_rep_11f1f6fb:

    # Suri "You should have heard her, back in university, kid. Last time we did this position, she had a cock in her ass, and two guys sucking her tits."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:187
translate chinese Z_ES4_rep_06335757:

    # Suri "They drove my sister INSANE with pleasure, that night!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:189
translate chinese Z_ES4_rep_5d1303f4:

    # Suri "You should have heard her, back in university, pal. Last time we did this position, she had a cock in her ass, and two guys sucking her tits."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:190
translate chinese Z_ES4_rep_0052e911:

    # Suri "They drove Zuri INSANE with pleasure, that night!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:194
translate chinese Z_ES4_rep_a8cbee4a:

    # Zuri "Yes! Yes! Yes! Mmm! Oh God!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:195
translate chinese Z_ES4_rep_4fac0264:

    # Zuri "I’m cumming! I’m cumming!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:197
translate chinese Z_ES4_rep_8d9e2a57:

    # MC "Mmm! Hnnng! (Damn, her pussy is as good as her sister’s! But then again, that’s to be expected!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:199
translate chinese Z_ES4_rep_ff24601b:

    # MC "Mmm! Hnnng! (Damn, her pussy is as good as Suri’s is! But then again, that’s to be expected!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:203
translate chinese Z_ES4_rep_0c20da2f:

    # Zuri "Holy fuck! It’s sooooo goood! Ahhh!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:205
translate chinese Z_ES4_rep_8ff3af41:

    # MC "I’m gonna cum soon!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:209
translate chinese Z_ES4_rep_0e9fe658:

    # Zuri "Cum wherever you want! Ohh fuck!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:213
translate chinese Z_ES4_rep_a709c253:

    # MC "(I might as well enjoy this pussy until the very last second!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:214
translate chinese Z_ES4_rep_5ac2d0d5:

    # Zuri "Ah! Ahh! AHHHH!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:215
translate chinese Z_ES4_rep_5bd8808d:

    # MC "(Let’s fuck her as hard as I can!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:219
translate chinese Z_ES4_rep_c2d61e28:

    # Zuri "OH GOD! I’M CUMMING AGAIN!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:220
translate chinese Z_ES4_rep_246a7bf8:

    # MC "UGH! HNNNG!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:221
translate chinese Z_ES4_rep_18f3c509:

    # MC "(I can feel my cum shooting, deep inside her pussy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:230
translate chinese Z_ES4_rep_8ac54b0a:

    # Zuri "(Holy fuck! He’s filling me up!)"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:231
translate chinese Z_ES4_rep_a0d761f8:

    # Zuri "(God! It’s so hot! Mmm!)"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:232
translate chinese Z_ES4_rep_739881d1:

    # Zuri "OOOHHHHHH.... Yesss....."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:238
translate chinese Z_ES4_rep_227eef91:

    # MC "Here we go, ladies! I’m about to cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:239
translate chinese Z_ES4_rep_14d24d01:

    # MC "Hnnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:240
translate chinese Z_ES4_rep_0e01a1cd:

    # Suri "Make sure you get both of us!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:250
translate chinese Z_ES4_rep_4bf96f58:

    # MC "HNNNNG! Ugh! Uh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:251
translate chinese Z_ES4_rep_e7d9e5a0:

    # Suri "(Ohh! It’s all warm and sticky!)"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:252
translate chinese Z_ES4_rep_e2fdeea5:

    # Zuri "Nice shooting. There’s A LOT there..."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:264
translate chinese Z_ES4_rep_c05fd351:

    # MC "(Huh? Where is everyone?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:265
translate chinese Z_ES4_rep_f05d7954:

    # MC "Zuri? Suri?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:266
translate chinese Z_ES4_rep_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:267
translate chinese Z_ES4_rep_3f0a6fef:

    # MC "(What the hell is going on? Why would they just leave their front door unlocked like that?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:271
translate chinese Z_ES4_rep_7bef0240:

    # Zuri "You deceptive piece of shit!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:272
translate chinese Z_ES4_rep_007dcd03:

    # MC "AHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:273
translate chinese Z_ES4_rep_71de56bc:

    # Zuri "Come here you little fucker!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:280
translate chinese Z_ES4_rep_0a4dee60:

    # MC "OOOF!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:281
translate chinese Z_ES4_rep_00dfef65:

    # Zuri "Did you seriously think you could just lie to me - and get away with it?!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:282
translate chinese Z_ES4_rep_1dd396bc:

    # MC "(Shit! She caught on to me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:286
translate chinese Z_ES4_rep_70af2929:

    # Zuri "I... invested... everything in those... worthless pieces of garbage you told me!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:287
translate chinese Z_ES4_rep_ed121d49:

    # MC "I-I’m sorry, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:288
translate chinese Z_ES4_rep_7b46f04e:

    # Zuri "EVERYTHING!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:289
translate chinese Z_ES4_rep_d895eba9:

    # Zuri "MY WHOLE FUCKING LIFE SAVINGS! MY DEAD FATHER’S INHERITANCE!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:293
translate chinese Z_ES4_rep_8b1fdc0d:

    # Zuri "I lost EVERY cent to my name!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:294
translate chinese Z_ES4_rep_c0e7ed38:

    # Zuri "I remortgaged this freaking house!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:295
translate chinese Z_ES4_rep_a515fc3b:

    # Zuri "All because a little rat decided to give me fake company names..."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:299
translate chinese Z_ES4_rep_d4264c88:

    # Zuri "So, here’s what’s going to happen now."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:300
translate chinese Z_ES4_rep_47595217:

    # Zuri "I’m going to cut you open. Slowly."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:301
translate chinese Z_ES4_rep_e9f74d26:

    # Zuri "I’m going to watch as you slowly bleed to death, in the middle of my fucking living room."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:302
translate chinese Z_ES4_rep_4e6ebbdc:

    # MC "P-Please! D-Don’t!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:306
translate chinese Z_ES4_rep_60da4abc:

    # Zuri "I’ll begin with your belly, and I’ll slice down. All the way to your pathetic little cock."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:307
translate chinese Z_ES4_rep_e2b8b3f3:

    # Zuri "When I’m finished with you, they won’t recognise the body."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:308
translate chinese Z_ES4_rep_5c0c7785:

    # Zuri "Goodbye! You pathetic little shitstain!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:315
translate chinese Z_ES4_rep_6b917c5c:

    # "*CLAAANNG*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:317
translate chinese Z_ES4_rep_d435c852:

    # Zuri "OOOOHHHH!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:318
translate chinese Z_ES4_rep_cded424e:

    # MC "Jesus Christ!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:323
translate chinese Z_ES4_rep_460932f7:

    # MC "Oh fuck... Oh fuck... She’s dead..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:324
translate chinese Z_ES4_rep_f950eb82:

    # Suri "Relax. She’s not dead, pal. I just knocked her out."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:325
translate chinese Z_ES4_rep_1e81afbe:

    # MC "R-Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:329
translate chinese Z_ES4_rep_108c3164:

    # Suri "You better get the heck out of here though. She’s gonna murder you if she sees you again."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:330
translate chinese Z_ES4_rep_5dbccab3:

    # MC "W-Why don’t you want to kill me too?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:331
translate chinese Z_ES4_rep_a3d408aa:

    # Suri "I do. But you’ve already ruined us financially. There’s no sense in either of us going to prison over you."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:333
translate chinese Z_ES4_rep_ce82e0df:

    # Suri "Zuri and I will rebuild. We’ll find some other rich CEO’s son and screw him for personal details."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:334
translate chinese Z_ES4_rep_c47e5d9f:

    # Suri "Now, get the hell out of here, kid. And let me take care of my sister."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:336
translate chinese Z_ES4_rep_bd972056:

    # Suri "Zuri and I will rebuild. We’ll find some other rich CEO and screw him for personal details."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:337
translate chinese Z_ES4_rep_f29973c9:

    # Suri "Now, get the hell out of here, pal. And let me take care of Zuri."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:338
translate chinese Z_ES4_rep_1b856611:

    # MC "Y-Yeah, okay."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:339
translate chinese Z_ES4_rep_f140c54b:

    # Suri "And, [player_name]?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:340
translate chinese Z_ES4_rep_0654b1f3:

    # MC "Yes?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:341
translate chinese Z_ES4_rep_8659b42f:

    # Suri "I’m sure it goes without saying, but don’t you DARE show your face at this house again."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:345
translate chinese Z_ES4_rep_5709f2f1:

    # Suri "Hey.. Zuri.. Wake up!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:346
translate chinese Z_ES4_rep_3748865e:

    # Suri "I’m sorry.."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:347
translate chinese Z_ES4_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:348
translate chinese Z_ES4_rep_28cc6d56:

    # MC "(Why do I feel like an asshole...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:361
translate chinese Zv2_ES4_truth_aftermenu_rep_7d38f75c:

    # Suri "Well, kid? Did you enjoy fucking twins?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:363
translate chinese Zv2_ES4_truth_aftermenu_rep_8f5fd3a5:

    # Suri "Well, pal. Did you enjoy fucking two women at once?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:364
translate chinese Zv2_ES4_truth_aftermenu_rep_68ecf43c:

    # MC "It was amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:365
translate chinese Zv2_ES4_truth_aftermenu_rep_e0484ac0:

    # Zuri "I knew it would be."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:366
translate chinese Zv2_ES4_truth_aftermenu_rep_e09fc3e6:

    # Zuri "Thank you again, for everything. You’ve made us both a shit-ton of money."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:367
translate chinese Zv2_ES4_truth_aftermenu_rep_6c0fca2f:

    # Suri "We’ll be sure to come to you again if we can use your help."
    Suri ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:11
    old "{color=#ff8000}Truth.{/color}"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/Z_ES4_rep.rpy:11
    old "{color=#ff8000}Lie.{/color}"
    new ""

