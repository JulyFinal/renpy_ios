﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:11
translate chinese CeR2_AS3_rep_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:12
translate chinese CeR2_AS3_rep_adb7b8a2:

    # MC "Are you not afraid of being seen in here?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:13
translate chinese CeR2_AS3_rep_dbab40b9:

    # Celia "You weren’t afraid of me being seen when you were blackmailing me. What makes you think I give a flying fuck this time?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:16
translate chinese CeR2_AS3_rep_92af822a:

    # Celia "Now, get your ass in here."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:17
translate chinese CeR2_AS3_rep_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:18
translate chinese CeR2_AS3_rep_eb796d11:

    # MC "(I wonder what she’s planning to do.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:21
translate chinese CeR2_AS3_rep_b3cdd352:

    # Celia "Stop dawdling. If you keep wasting time, someone is going to show up before I get a chance to close this damn door."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:22
translate chinese CeR2_AS3_rep_5df67409:

    # MC "Okay, coming now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:25
translate chinese CeR2_AS3_rep_7a8db939:

    # MC "(She’s not wearing any underwear!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:26
translate chinese CeR2_AS3_rep_6f127cc5:

    # MC "(Is she expecting me to eat her out again - in here?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:27
translate chinese CeR2_AS3_rep_5cb43c8d:

    # MC "(Or maybe she wants to fuck me?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:30
translate chinese CeR2_AS3_rep_3f917b37:

    # MC "Uhh, do you want me to undress?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:31
translate chinese CeR2_AS3_rep_a7976bba:

    # Celia "Lock the door."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:34
translate chinese CeR2_AS3_rep_db4eed68:

    # MC "Oh shit, sorry, I forgot."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:36
translate chinese CeR2_AS3_rep_09d06ab8:

    # "*Click*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:37
translate chinese CeR2_AS3_rep_84ccea21:

    # MC "There we go. What do you want me to do now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:40
translate chinese CeR2_AS3_rep_788132a4:

    # Celia "You made my life a living hell for days upon days, [player_name]. I kinda liked that, you know?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:41
translate chinese CeR2_AS3_rep_16b8fbf1:

    # Celia " I woke up every morning not knowing if I would be forced to suck a cock or ride a dick."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:42
translate chinese CeR2_AS3_rep_4c7e0364:

    # Celia "Heck, for all I know, there might be videos of me stripping, uploaded onto PornHab!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:49
translate chinese CeR2_AS3_rep_d7608c4a:

    # MC "There isn’t any - I never recorded you on webcam!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:50
translate chinese CeR2_AS3_rep_c2c5b161:

    # Celia "Shut up. I don’t believe a single word you say."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:53
translate chinese CeR2_AS3_rep_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:54
translate chinese CeR2_AS3_rep_ece3e180:

    # MC "What do you want from me now? I’ve already apologised."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:57
translate chinese CeR2_AS3_rep_147b254f:

    # Celia "I don’t want an apology. You can’t make things better."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:58
translate chinese CeR2_AS3_rep_cf745f0f:

    # Celia "The only thing I want right now is revenge. Revenge for EVERYTHING that you have done to me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:61
translate chinese CeR2_AS3_rep_03927fb2:

    # MC "What are you going to do? Strangle me in the toilet?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:62
translate chinese CeR2_AS3_rep_352c7205:

    # Celia "Heh, strangling you wouldn’t be enough for me. I want to see you thoroughly and utterly broken."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:65
translate chinese CeR2_AS3_rep_8af6e038:

    # MC "What are you-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:66
translate chinese CeR2_AS3_rep_aeda2160:

    # Celia "Let’s hope the janitor is thorough when he cleans these things!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:67
translate chinese CeR2_AS3_rep_e2d254b0:

    # MC "W-Wait!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:70
translate chinese CeR2_AS3_rep_8ed44592:

    # MC "*BLURP* *GURGLE*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:71
translate chinese CeR2_AS3_rep_a4868fd1:

    # Celia "FUCK! YOU!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:72
translate chinese CeR2_AS3_rep_17f8ff03:

    # Celia "THIS IS FOR TRYING TO RUIN MY LIFE!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:77
translate chinese CeR2_AS3_rep_eb213679:

    # MC "MPFPFFFF!! *BLURP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:78
translate chinese CeR2_AS3_rep_d9fb04bb:

    # MC "(Shit! I can’t breathe!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:80
translate chinese CeR2_AS3_rep_79bc046b:

    # MC "MPPFFF!!!! *GURGLE* (This BDSM roleplay is fucking hard! She’s soo good at this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:81
translate chinese CeR2_AS3_rep_bc422f11:

    # MC "(I keep expecting her to break character, but she never even slips up for a second!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:84
translate chinese CeR2_AS3_rep_1b106f3c:

    # Celia "I hope you can still hear me! Because we’re only getting started!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:85
translate chinese CeR2_AS3_rep_021ac6a2:

    # Celia "You better hold your breath, boy!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:89
translate chinese CeR2_AS3_rep_b5c6797e:

    # "*FLUSH*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:92
translate chinese CeR2_AS3_rep_a9f1f63b:

    # MC "MPPFFF!!!! *GURGLE*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:93
translate chinese CeR2_AS3_rep_a8311a73:

    # Celia "Do you feel the disgust? The humiliation? The degradation?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:94
translate chinese CeR2_AS3_rep_d90f27f3:

    # Celia "This is how I felt, every fucking day!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:97
translate chinese CeR2_AS3_rep_81450acf:

    # Celia "But I suppose I better let you come up for a breath now."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:98
translate chinese CeR2_AS3_rep_60ac03bf:

    # MC "*GASP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:101
translate chinese CeR2_AS3_rep_fc7f9667:

    # MC "*Cough* *Splutter*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:102
translate chinese CeR2_AS3_rep_f0fe7bb4:

    # MC "Y-You’re *Splutter* disgusting... *Cough*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:105
translate chinese CeR2_AS3_rep_1181e55b:

    # Celia "I love it when you get angry. You’re like a little chihuahua - so noisy, yet so powerless."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:106
translate chinese CeR2_AS3_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:107
translate chinese CeR2_AS3_rep_90dd53ea:

    # Celia "We’re wasting time, though. Let’s move onto the main event."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:110
translate chinese CeR2_AS3_rep_ec24a1d2:

    # Celia "C’mere, boy."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:111
translate chinese CeR2_AS3_rep_6296908f:

    # MC "F-Fuck you... *cough*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:114
translate chinese CeR2_AS3_rep_64ed0436:

    # Celia "I said come here!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:115
translate chinese CeR2_AS3_rep_3ef2838a:

    # MC "You almost fucking drowned me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:116
translate chinese CeR2_AS3_rep_986e730f:

    # Celia "Ugh, you’re so melodramatic."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:123
translate chinese CeR2_AS3_rep_90bb3144:

    # Celia "Get over here and lick my pussy. Now!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:124
translate chinese CeR2_AS3_rep_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:125
translate chinese CeR2_AS3_rep_9c5de4f8:

    # Celia "Do you want your face flushed down the toilet again?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:128
translate chinese CeR2_AS3_rep_6ab1f08a:

    # Celia "Mmm... See? That wasn’t so hard."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:129
translate chinese CeR2_AS3_rep_9a3b05e4:

    # Celia "Obeying your mistress makes things so much simpler. Doesn’t it?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:130
translate chinese CeR2_AS3_rep_aef2252b:

    # MC "*Lick* "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:133
translate chinese CeR2_AS3_rep_8552eb18:

    # Celia "Ohh... yeah. Mmm."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:134
translate chinese CeR2_AS3_rep_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:137
translate chinese CeR2_AS3_rep_1de4b9b9:

    # Celia "Mmm! Get your tongue deep in there! Ahh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:138
translate chinese CeR2_AS3_rep_c298f5f7:

    # MC "*Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:139
translate chinese CeR2_AS3_rep_63a21fe8:

    # Celia "Ahh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:142
translate chinese CeR2_AS3_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:143
translate chinese CeR2_AS3_rep_d7831259:

    # Celia "Oh God! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:146
translate chinese CeR2_AS3_rep_280be771:

    # Celia "Fuck..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:147
translate chinese CeR2_AS3_rep_716e494d:

    # Celia "(This is heavenly... I could REALLY get used to having my pussy eaten out whenever I want.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:150
translate chinese CeR2_AS3_rep_873c6969:

    # Celia "*Pant* *Gasp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:151
translate chinese CeR2_AS3_rep_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:154
translate chinese CeR2_AS3_rep_845fb1cb:

    # Celia "(Fuck, I have to pull him in closer! This feels TOO damn good!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:155
translate chinese CeR2_AS3_rep_d8e6e578:

    # MC "*Suck* *Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:156
translate chinese CeR2_AS3_rep_3a85be09:

    # Celia "Ah! AHHH! AYAAAHHHH!!!!! I’m cumming!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:159
translate chinese CeR2_AS3_rep_06ee024b:

    # Celia "H-Holy shit! AHHH! Ohhhh Goddddd!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:160
translate chinese CeR2_AS3_rep_de900249:

    # MC "(How much longer is she expecting me to do this for?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:163
translate chinese CeR2_AS3_rep_c64dd207:

    # Celia "Ah! Ahhh! AHHH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:164
translate chinese CeR2_AS3_rep_e0e380e5:

    # MC "(Is she not even worried about someone hearing us in here?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:165
translate chinese CeR2_AS3_rep_5b70b21e:

    # MC "(She’s completely throwing caution to the wind right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:168
translate chinese CeR2_AS3_rep_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:169
translate chinese CeR2_AS3_rep_4317c7ae:

    # Celia "Why’d you stop?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:170
translate chinese CeR2_AS3_rep_b17002f9:

    # MC "My tongue... I’m exhausted!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:173
translate chinese CeR2_AS3_rep_0a1f79cf:

    # Celia "Tough shit. I was exhausted, every night you made me stay up late and perform for you on camera."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:174
translate chinese CeR2_AS3_rep_d1f996a8:

    # MC "But, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:177
translate chinese CeR2_AS3_rep_13220b99:

    # Celia "I’ll spread my legs. Does that help?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:178
translate chinese CeR2_AS3_rep_69d7718b:

    # MC "Not really..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:179
translate chinese CeR2_AS3_rep_beb99617:

    # Celia "Well, I honestly don’t care. Chop chop!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:182
translate chinese CeR2_AS3_rep_3f7459e1:

    # MC "*Pant* Just, give me a minute to catch my breath."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:183
translate chinese CeR2_AS3_rep_6f8b5faf:

    # Celia "Like the way you gave me breaks when I was sucking your cock?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:184
translate chinese CeR2_AS3_rep_278dad06:

    # Celia "Do you think {b}I{/b} could breathe when you were making me deepthroat you?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:187
translate chinese CeR2_AS3_rep_2ffb9920:

    # MC "P-Point taken..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:188
translate chinese CeR2_AS3_rep_ac908534:

    # Celia "Good boy - you’re finally seeing some sense!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:191
translate chinese CeR2_AS3_rep_83bd14bb_2:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:192
translate chinese CeR2_AS3_rep_e7cc741c:

    # Celia "Mmm... Ohh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:195
translate chinese CeR2_AS3_rep_cfd1749f:

    # Celia "You’ve got a talent for doing this. Ahh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:196
translate chinese CeR2_AS3_rep_73b98d33:

    # MC "*Slurp* *Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:197
translate chinese CeR2_AS3_rep_134e3cde:

    # Celia "Ohh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:200
translate chinese CeR2_AS3_rep_47efa6ca:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:201
translate chinese CeR2_AS3_rep_a963ff5f:

    # Celia "Ahh... Ohh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:204
translate chinese CeR2_AS3_rep_c298f5f7_1:

    # MC "*Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:206
translate chinese CeR2_AS3_rep_bb722cd1:

    # Celia "Mmm, just like that... Focus on my clitoris. Ahh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:208
translate chinese CeR2_AS3_rep_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:210
translate chinese CeR2_AS3_rep_352f0920:

    # Celia "Oh God... *Gasp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:212
translate chinese CeR2_AS3_rep_5930eaa0:

    # Celia "Ahhhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:215
translate chinese CeR2_AS3_rep_ea9ef68c:

    # Celia "Right there! That’s the spot! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:217
translate chinese CeR2_AS3_rep_1dc77284:

    # Celia "Don’t stop, [player_name]! Lick my fucking pussy!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:218
translate chinese CeR2_AS3_rep_98b1236d:

    # Celia "O-Okay! W-Wow, let’s swap positions! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:221
translate chinese CeR2_AS3_rep_cf22bb32:

    # Celia "I want you to eat me out from behind now."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:222
translate chinese CeR2_AS3_rep_46506e91:

    # MC "*Pant* S-Sure..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:223
translate chinese CeR2_AS3_rep_96a62998:

    # Celia "Aww, don’t look so down. You’ll build up stamina doing this. Soon you’ll be able to do it for an hour without breaking a sweat!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:226
translate chinese CeR2_AS3_rep_83bd14bb_3:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:227
translate chinese CeR2_AS3_rep_260f6fc0:

    # MC "(Great... I’m going to spend the rest of my life, doing nothing but eating pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:228
translate chinese CeR2_AS3_rep_929de295:

    # MC "(I suppose there ARE worse ways to go.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:231
translate chinese CeR2_AS3_rep_01c229f7:

    # Celia "Ahhh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:232
translate chinese CeR2_AS3_rep_a1f3e861:

    # Celia "Oh! Yes! MMM!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:235
translate chinese CeR2_AS3_rep_dc9ddee6:

    # Celia "Oh God! Fuck! Ahhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:236
translate chinese CeR2_AS3_rep_47efa6ca_1:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:239
translate chinese CeR2_AS3_rep_4be753dc:

    # Celia "I’m getting close! Mmm! Don’t stop! Ahh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:240
translate chinese CeR2_AS3_rep_7dfbceb2:

    # MC "*SHLURP* *LICK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:241
translate chinese CeR2_AS3_rep_4e21b05f:

    # Celia "AHHHH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:244
translate chinese CeR2_AS3_rep_105d4805:

    # Celia "Oh God! Oh God! Yes!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:246
translate chinese CeR2_AS3_rep_582deac0:

    # MC "*LICK LICK* *SHLURP* *SUCK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:248
translate chinese CeR2_AS3_rep_83bd14bb_4:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:250
translate chinese CeR2_AS3_rep_6a61471f:

    # MC "(Her legs are starting to shake! I think this is the big climax she was wanting!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:251
translate chinese CeR2_AS3_rep_8a8b89bf:

    # Celia "AAAAHHHHHHHH!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:254
translate chinese CeR2_AS3_rep_d5e8907b:

    # MC "*LICK* *SUCK* *SLURP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:256
translate chinese CeR2_AS3_rep_a8fd41e1:

    # Celia "F-Fuck! I’m cummminng! AAAAYAAAAAAHHHHHHHH!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:258
translate chinese CeR2_AS3_rep_6b79174f:

    # MC "*LICK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:259
translate chinese CeR2_AS3_rep_443a7d48:

    # Celia "*PANT* *GASP* OHHHH MY GOOOODDDDDDD!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:262
translate chinese CeR2_AS3_rep_e6cbc9b8:

    # Celia "Well, that was *Pant* very enjoyable."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:263
translate chinese CeR2_AS3_rep_e5cc9be6:

    # Celia "I’ll be expecting you to use that tongue much more often."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:266
translate chinese CeR2_AS3_rep_88e045b7:

    # Celia "Now scram! I have to get changed. It’ll look suspicious if we leave at the same time."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:267
translate chinese CeR2_AS3_rep_ad029612:

    # MC "Won’t it look suspicious if you come out of the men’s toilets, for any reason?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:268
translate chinese CeR2_AS3_rep_2ff3a777:

    # Celia "Get out. Now."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:271
translate chinese CeR2_AS3_rep_09990932:

    # MC "Ugh, fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:276
translate chinese CeR2_AS3_rep_09d06ab8_1:

    # "*Click*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:278
translate chinese CeR2_AS3_rep_e57f9db9:

    # MC "(I can’t keep living like this. I need to find a way out of this predicament.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:280
translate chinese CeR2_AS3_rep_f33fd6b4:

    # MC "(As fun as this is, I think I need to find a way to get myself back in the dominant position in this relationship.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:281
translate chinese CeR2_AS3_rep_72588daf:

    # MC "(But how?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:284
translate chinese CeR2_AS3_rep_8b9aa066:

    # MC "(Hmm, maybe I should speak with Judy? She has been a good help so far.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:285
translate chinese CeR2_AS3_rep_75b6df21:

    # MC "(Even if her advice has been... unorthodox.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:288
translate chinese CeR2_AS3_rep_4d9dfefc:

    # MC "(At this point, an unorthodox solution might be exactly what I need.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:289
translate chinese CeR2_AS3_rep_c52a221a:

    # MC "(I’ll go and see Judy whenever she’s free.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:292
translate chinese CeR2_AS3_rep_e20f9d64:

    # Celia "(Heh, I almost felt bad for him there. He didn’t even put up much of a fight.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:294
translate chinese CeR2_AS3_rep_b1f1fda4:

    # Celia "(That must be his spirit almost broken. He’ll be a perfect sex slave for me soon enough.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS3_rep.rpy:296
translate chinese CeR2_AS3_rep_ef1ce0e6:

    # Celia "(He’s such a good little pussy eater. I’m going to enjoy using him every single day.)"
    Celia ""

