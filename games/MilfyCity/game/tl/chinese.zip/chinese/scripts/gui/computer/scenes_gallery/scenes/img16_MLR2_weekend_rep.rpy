﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:23
translate chinese MLR2_weekend_rep_d11f76c1:

    # Mom "Good evening, Dear. Nice to see you finally made it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:24
translate chinese MLR2_weekend_rep_433e0b68:

    # MC "You started drinking without me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:25
translate chinese MLR2_weekend_rep_5c1e7de9:

    # Mom "Just a little bit. Hehe...! I was too excited, to contain myself any longer."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:28
translate chinese MLR2_weekend_rep_6f45b5a3:

    # Mom "I kept you plenty of wine though. Take a glass and join me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:30
translate chinese MLR2_weekend_rep_bdbe97e5:

    # Mom "You have no idea how happy I am that this is finally happening. I have fantasised about this moment for AGES."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:32
translate chinese MLR2_weekend_rep_5caafd6e:

    # Mom "You have no idea how happy I am that this is finally happening. I have fantasized about this moment for a while!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:33
translate chinese MLR2_weekend_rep_97980eb0:

    # Mom "And now, tonight, you're all mine."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:36
translate chinese MLR2_weekend_rep_bb4c8968:

    # Mom "God... it feels so liberating to have you this close..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:37
translate chinese MLR2_weekend_rep_5787b519:

    # Mom "...to know that no one is going to interrupt us or take you away from me tonight."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:38
translate chinese MLR2_weekend_rep_fe7b3cec:

    # Mom "I love you, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:40
translate chinese MLR2_weekend_rep_d6d9f8bc:

    # MC "I love you too, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:42
translate chinese MLR2_weekend_rep_4ac41469:

    # MC "I love you too, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:46
translate chinese MLR2_weekend_rep_d0a975c8:

    # Mom "Whoops! Haha! Looks like I fell back on the bed."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:47
translate chinese MLR2_weekend_rep_857668cc:

    # Mom "Now, what's that hard thing in your pants? It wouldn't be your cock, would it?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:49
translate chinese MLR2_weekend_rep_efc2fd0d:

    # Mom "Do you have any idea how BAD it would be for a boy's cock to rub against his own mother's pussy?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:51
translate chinese MLR2_weekend_rep_ba7134e6:

    # Mom "Do you have any idea how BAD it would be for my tenant’s cock to rub against his landlady's pussy?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:52
translate chinese MLR2_weekend_rep_e7589cc3:

    # MC "(Damn, I love it when she talks dirty!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:53
translate chinese MLR2_weekend_rep_847b7851:

    # Mom "Hurry up and kiss me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:57
translate chinese MLR2_weekend_rep_ca588a8d:

    # MC "(This is gonna be the best night of my life!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:58
translate chinese MLR2_weekend_rep_e739176a:

    # MC "(I'm gonna lose my virginity to the sexiest damn woman on Earth!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:59
translate chinese MLR2_weekend_rep_495b6ffc:

    # MC "(I can already feel her panties are soaking wet – she clearly can't wait to have my dick shoved, deep inside her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:63
translate chinese MLR2_weekend_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:64
translate chinese MLR2_weekend_rep_c15d4045:

    # Mom "Mmmm...."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:65
translate chinese MLR2_weekend_rep_bcc62e5f:

    # Mom "(I can feel [player_name]'s tongue in my mouth! God, this is so fucking hot!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:69
translate chinese MLR2_weekend_rep_775b5085:

    # Mom "(I don't know why, but the fact this is wrong, is making it even hotter!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:71
translate chinese MLR2_weekend_rep_10c1af4a:

    # MC "Mhm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:72
translate chinese MLR2_weekend_rep_e62d6d17:

    # Mom "Mhmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:73
translate chinese MLR2_weekend_rep_e896e46a:

    # Mom "(I wonder, in what position we'll fuck in first? Perhaps me on top? Or maybe I'll lie back and let him take charge.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:74
translate chinese MLR2_weekend_rep_9f7532a2:

    # Mom "(The thought of his cock plunging into me, over and over, is driving me crazy!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:75
translate chinese MLR2_weekend_rep_eb35463f:

    # MC "(I can taste a little sweet wine from her tounge... It feels weird but.. good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:79
translate chinese MLR2_weekend_rep_008c854f:

    # Mom "Are you ready for tonight?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:81
translate chinese MLR2_weekend_rep_2808bdea:

    # MC "Definitely, Mom. I can't wait."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:83
translate chinese MLR2_weekend_rep_2a93348b:

    # MC "Definitely, Linda. I can't wait."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:84
translate chinese MLR2_weekend_rep_8015028a:

    # Mom "Promise? I don't want to push you into something you're not absolutely comfortable with."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:88
translate chinese MLR2_weekend_rep_3236d6d2:

    # MC "Relax, Mom. I'm with the most stunning woman I've ever met. There is nothing you could say or do right now, that would make me change my mind about tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:89
translate chinese MLR2_weekend_rep_3fe258ec:

    # MC "(Mom picked out some really hot lingerie for tonight!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:91
translate chinese MLR2_weekend_rep_650e1922:

    # MC "Relax, Linda. I'm with the most stunning woman I've ever met. There is nothing you could say or do right now, that would make me change my mind about tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:92
translate chinese MLR2_weekend_rep_ce4323e6:

    # MC "(She picked out some really hot lingerie for tonight!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:93
translate chinese MLR2_weekend_rep_b6010e1c:

    # MC "(The fun part, is going to be stripping her out of it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:97
translate chinese MLR2_weekend_rep_5bc29029:

    # Mom "Well, if you're sure. You're still my boy, at the end of the day. And I wouldn't want to do anything to hurt you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:98
translate chinese MLR2_weekend_rep_65299b3c:

    # MC "You're not going to hurt me. I've never felt so safe and relaxed in my life."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:99
translate chinese MLR2_weekend_rep_27971f2e:

    # Mom "Me too."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:102
translate chinese MLR2_weekend_rep_5173c387:

    # Mom "(Hmm? I wonder how I can move things along. I don't want this to descend into romantic cuddling yet.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:103
translate chinese MLR2_weekend_rep_82b8a7bb:

    # Mom "(Okay, time to take charge. I think I've got a plan for this.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:106
translate chinese MLR2_weekend_rep_0e5b2d35:

    # Mom "Let me slip out of these flimsy clothes – then you can tell me if you like what you see."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:107
translate chinese MLR2_weekend_rep_c108ca6c:

    # MC "I'm already LOVING what I'm seeing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:108
translate chinese MLR2_weekend_rep_262ad363:

    # Mom "Oh yeah? Then perhaps you'd like to explore my body a bit more."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:109
translate chinese MLR2_weekend_rep_2b515de7:

    # MC "Definitely!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:112
translate chinese MLR2_weekend_rep_371fc248:

    # Mom "In that case - let’s play a little game. I'll go first."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:113
translate chinese MLR2_weekend_rep_9cac5712:

    # Mom "Just lie on your back. I’m gonna pour some wine on you and lick it off."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:114
translate chinese MLR2_weekend_rep_41be8a70:

    # MC "Mmm... I’m liking the sound of that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:115
translate chinese MLR2_weekend_rep_2437dfd0:

    # Mom "We'll take it in turns – I'll do three on your body – then you can do three on mine. Sound good?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:116
translate chinese MLR2_weekend_rep_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:120
translate chinese MLR2_weekend_rep_7ac9f207:

    # Mom "In that case, let’s begin here..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:121
translate chinese MLR2_weekend_rep_34a59dd4:

    # MC "Oh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:122
translate chinese MLR2_weekend_rep_59939d87:

    # MC "(Jesus! That's chilly!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:123
translate chinese MLR2_weekend_rep_9a3c2183:

    # Mom "Haha! Sorry, is that a little bit cold, Sweetie?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:127
translate chinese MLR2_weekend_rep_816106c5:

    # Mom "Let me warm it back up for you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:128
translate chinese MLR2_weekend_rep_a70b9d7d:

    # MC "Mmm... Ooohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:129
translate chinese MLR2_weekend_rep_8dfd7588:

    # MC "That's so good..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:133
translate chinese MLR2_weekend_rep_7b729689:

    # Mom "Now, let's do your belly next."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:134
translate chinese MLR2_weekend_rep_0d4cf71d:

    # MC "*Gasp!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:135
translate chinese MLR2_weekend_rep_82f6e36a:

    # Mom "(Hehe. I love the way he squirms!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:139
translate chinese MLR2_weekend_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:140
translate chinese MLR2_weekend_rep_822d5ad4:

    # MC "(She's getting so close to my cock right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:141
translate chinese MLR2_weekend_rep_f5358300:

    # MC "(Please pour the wine there next... PLEASE pour the wine there next!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:144
translate chinese MLR2_weekend_rep_1c48e78b:

    # Mom "Hmm... I've used two of my goes. I wonder where I should pour the final bit of wine?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:145
translate chinese MLR2_weekend_rep_823ff93c:

    # Mom "Have you any ideas?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:146
translate chinese MLR2_weekend_rep_a7993435:

    # MC "I can think of one place, in particular."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:147
translate chinese MLR2_weekend_rep_32ad0591:

    # Mom "So can I."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:151
translate chinese MLR2_weekend_rep_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:152
translate chinese MLR2_weekend_rep_baf453e2:

    # Mom "Such a big thick cock..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:153
translate chinese MLR2_weekend_rep_0ab7dd56:

    # Mom "I can't wait to have you inside me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:156
translate chinese MLR2_weekend_rep_774e83a4:

    # Mom "*Lick Lick*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:157
translate chinese MLR2_weekend_rep_8035612f:

    # MC "Ah! Ahh... Ah...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:158
translate chinese MLR2_weekend_rep_b600741f:

    # Mom "(Sounds like he's REALLY enjoying this!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:161
translate chinese MLR2_weekend_rep_e277af7c:

    # Mom "*Suck Suck!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:162
translate chinese MLR2_weekend_rep_f941cc5d:

    # MC "Oh! Ohhhh Oh ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:163
translate chinese MLR2_weekend_rep_15fcadb7:

    # Mom "*Shluuurrrrp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:166
translate chinese MLR2_weekend_rep_e3e8e728:

    # Mom "Ahem... That's enough of that. I don't want to get you off, TOO quickly."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:167
translate chinese MLR2_weekend_rep_023cd8b7:

    # Mom "Besides - it’s your turn now. Pick three places on my body."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:169
translate chinese MLR2_weekend_rep_5d86b5d0:

    # MC "Okay, Mom. Just lie back for me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:171
translate chinese MLR2_weekend_rep_dec17579:

    # MC "Okay, Linda. Just lie back for me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:174
translate chinese MLR2_weekend_rep_e46c2347:

    # MC "(Hmm... Where to begin?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:252
translate chinese MLR2_weekend_feet_label_rep_36de114b:

    # Mom "Hehe..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:253
translate chinese MLR2_weekend_feet_label_rep_17fe5f16:

    # MC "Sorry, does that tickle?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:254
translate chinese MLR2_weekend_feet_label_rep_d6f8e91d:

    # Mom "J-Just a little bit, as it trickles between my toes!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:255
translate chinese MLR2_weekend_feet_label_rep_b7d9f3e2:

    # MC "Oh dear, we can't have that now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:259
translate chinese MLR2_weekend_feet_label_rep_338bad60:

    # MC "I'll have to clean this mess up with my tongue."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:260
translate chinese MLR2_weekend_feet_label_rep_232320c5:

    # Mom "Ooohh.... Mmm...."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:261
translate chinese MLR2_weekend_feet_label_rep_cec75792:

    # Mom "(God... this is incredible!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:265
translate chinese MLR2_weekend_feet_label_rep_3b81ffa7:

    # MC "*Suck Suck!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:266
translate chinese MLR2_weekend_feet_label_rep_987874ad:

    # Mom "Ah! Ahh.... Ooooohhhh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:267
translate chinese MLR2_weekend_feet_label_rep_ff70b6ea:

    # MC "(She's absolutely loving having her toes sucked!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:280
translate chinese MLR2_weekend_shin_label_rep_b6e159d3:

    # Mom "Ah! Cold..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:281
translate chinese MLR2_weekend_shin_label_rep_7d4cff0a:

    # MC "Hehe... It’s only fair. You did it to me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:282
translate chinese MLR2_weekend_shin_label_rep_2d6861fa:

    # Mom "(My shins? I don't think I've ever been kissed there before.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:286
translate chinese MLR2_weekend_shin_label_rep_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:287
translate chinese MLR2_weekend_shin_label_rep_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:300
translate chinese MLR2_weekend_pussy_label_rep_acd47b91:

    # MC "I think you'll enjoy this spot the most."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:301
translate chinese MLR2_weekend_pussy_label_rep_20a6f65f:

    # Mom "Hmm?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:302
translate chinese MLR2_weekend_pussy_label_rep_39237400:

    # Mom "(Ohh! The wine's on my pussy!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:306
translate chinese MLR2_weekend_pussy_label_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:307
translate chinese MLR2_weekend_pussy_label_rep_32ca6eda:

    # Mom "Mmmm... Yes, Baby... Right there!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:309
translate chinese MLR2_weekend_pussy_label_rep_0f4926ab:

    # MC "(Mom’s so wet I can barely taste the wine!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:311
translate chinese MLR2_weekend_pussy_label_rep_e10697e0:

    # MC "(Linda’s so wet I can barely taste the wine!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:315
translate chinese MLR2_weekend_pussy_label_rep_42a213b6:

    # MC "(Let’s focus on her clitoris for a bit, and see how she enjoys that!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:316
translate chinese MLR2_weekend_pussy_label_rep_19ee5846:

    # Mom "Ooohhh! God... Yes... Mmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:317
translate chinese MLR2_weekend_pussy_label_rep_adf49859:

    # Mom "Don’t stop, [player_name]! Yeeessssss!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:318
translate chinese MLR2_weekend_pussy_label_rep_a599f521:

    # MC "(Hehe. I’ve teased her enough. I don’t want to make her cum, before we get to the main show!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:332
translate chinese MLR2_weekend_belly_label_rep_1b10106a:

    # MC "(Let’s pour some wine on her belly. I’m sure she’ll love, having my hot tongue flick around her navel!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:333
translate chinese MLR2_weekend_belly_label_rep_6cc8521d:

    # Mom "Ah... (I really should have warmed the red wine up a little...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:337
translate chinese MLR2_weekend_belly_label_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:338
translate chinese MLR2_weekend_belly_label_rep_ee9ce0eb:

    # Mom "Hehe... Ah- Hehe..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:339
translate chinese MLR2_weekend_belly_label_rep_4ec6892f:

    # MC "(Haha! It sounds like this tickles her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:340
translate chinese MLR2_weekend_belly_label_rep_4b48c2cc:

    # Mom "Haha! Okay, you can- haha- stop that now!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:354
translate chinese MLR2_weekend_breasts_label_rep_e9807979:

    # MC "(Okay, let’s try pouring some wine on Mom’s breasts. They’re erogenous zones, right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:356
translate chinese MLR2_weekend_breasts_label_rep_6cbb6882:

    # MC "(Okay, let’s try pouring some wine on Linda’s breasts. They’re erogenous zones, right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:357
translate chinese MLR2_weekend_breasts_label_rep_70157bb4:

    # Mom "Oooh...."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:358
translate chinese MLR2_weekend_breasts_label_rep_3fd5f76d:

    # Mom "(I can’t wait to feel his mouth clamped over my nipple!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:362
translate chinese MLR2_weekend_breasts_label_rep_c5890411:

    # Mom "Yes... Oh, yessss...."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:363
translate chinese MLR2_weekend_breasts_label_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:364
translate chinese MLR2_weekend_breasts_label_rep_0c5f06b3:

    # Mom "Suck on it! Suck on my breasts!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:368
translate chinese MLR2_weekend_breasts_label_rep_cd7f6e60:

    # MC "*Suck Suck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:369
translate chinese MLR2_weekend_breasts_label_rep_065df0fd:

    # Mom "Ahhhhh! God! Yes! Hnnnggg!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:383
translate chinese MLR2_weekend_mouth_label_rep_a6b555a7:

    # MC "(It’s not the first place I thought of - but pouring some wine in Mom’s mouth and kissing her could work!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:385
translate chinese MLR2_weekend_mouth_label_rep_ecd22d2d:

    # MC "(It’s not the first place I thought of - but pouring some wine in her mouth and kissing her could work!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:386
translate chinese MLR2_weekend_mouth_label_rep_00090c18:

    # MC "(Let’s see how she likes it...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:390
translate chinese MLR2_weekend_mouth_label_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:391
translate chinese MLR2_weekend_mouth_label_rep_7eaa8ed1:

    # Mom "Hmm?! Mmmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:393
translate chinese MLR2_weekend_mouth_label_rep_e180e001:

    # Mom "(Wow! Having my son kiss me, with the taste of my favourite red wine in my mouth, is incredible.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:395
translate chinese MLR2_weekend_mouth_label_rep_be0dc870:

    # Mom "(Wow! Having [player_name] kiss me, with the taste of my favourite red wine in my mouth, is incredible.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:409
translate chinese MLR2_weekend_end_label_rep_f834b121:

    # Mom "(God dammit... I’m so fucking wet!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:410
translate chinese MLR2_weekend_end_label_rep_cf0bc12c:

    # Mom "(I don’t think I can contain myself any longer. It’s driving me MAD!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:411
translate chinese MLR2_weekend_end_label_rep_22cd9f28:

    # Mom "(I HAVE to fuck him! I have to screw him RIGHT NOW!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:415
translate chinese MLR2_weekend_end_label_rep_7d8dec28:

    # Mom "Okay! The game’s over!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:416
translate chinese MLR2_weekend_end_label_rep_517c8109:

    # MC "Huh? Did I do something wr-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:417
translate chinese MLR2_weekend_end_label_rep_88091e5e:

    # Mom "Get on your back! Just lie down on the bed!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:421
translate chinese MLR2_weekend_end_label_rep_c79ba12d:

    # MC "[Mom_name]! What’s going on?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:422
translate chinese MLR2_weekend_end_label_rep_2ed0fba5:

    # Mom "I need your cock! I need it so fucking much right now!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:423
translate chinese MLR2_weekend_end_label_rep_ed524567:

    # Mom "God, I just want to suck the cum out of you..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:424
translate chinese MLR2_weekend_end_label_rep_52844a0b:

    # MC "How about you lie on top of me and we sixty-nine, then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:428
translate chinese MLR2_weekend_end_label_rep_f8acb940:

    # Mom "Perfect idea! Ahh... Yes..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:429
translate chinese MLR2_weekend_end_label_rep_8008bb1f:

    # MC "*Lick!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:430
translate chinese MLR2_weekend_end_label_rep_bd2ac247:

    # Mom "Go deep with your tongue... Ahh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:431
translate chinese MLR2_weekend_end_label_rep_ea0a7340:

    # Mom "That’s it! Right... ugh... there! I love feeling a, hot, wet, muscle, writhing deep inside me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:435
translate chinese MLR2_weekend_end_label_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:436
translate chinese MLR2_weekend_end_label_rep_a6b75fb2:

    # Mom "*Shlurrrrp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:437
translate chinese MLR2_weekend_end_label_rep_67f5b606:

    # Mom "(I’m gonna suck him dry. [player_name] is about to have his cock sucked like he has NEVER had before!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:439
translate chinese MLR2_weekend_end_label_rep_13ffa4a2:

    # MC "(Mmm... She’s started. This is gonna be fun! I don’t know how long I’ll be able to last, with the scent of Mom’s pussy in my face.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:441
translate chinese MLR2_weekend_end_label_rep_348b8bea:

    # MC "(Mmm, she’s started. This is gonna be fun! I don’t know how long I’ll be able to last with the scent of her pussy in my face.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:444
translate chinese MLR2_weekend_end_label_rep_e277af7c:

    # Mom "*Suck Suck!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:445
translate chinese MLR2_weekend_end_label_rep_1072088e:

    # Mom "Mmm! MMM!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:446
translate chinese MLR2_weekend_end_label_rep_b04ec4be:

    # Mom "(It’s so difficult to concentrate on sucking him off while he’s licking my pussy like that. The pleasure is just so... distracting.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:450
translate chinese MLR2_weekend_end_label_rep_70d2fa8f:

    # Mom "(I guess this means I need to up my game! Time to take his shaft deeper in my mouth!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:451
translate chinese MLR2_weekend_end_label_rep_02b7591c:

    # MC "*Lick Lick!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:452
translate chinese MLR2_weekend_end_label_rep_b8a1863f:

    # MC "Mmm! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:453
translate chinese MLR2_weekend_end_label_rep_c41d8ba6:

    # MC "(Damn, she’s bobbing her head faster! I’ve never seen her this horny before!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:457
translate chinese MLR2_weekend_end_label_rep_d0e81f00:

    # Mom "*GULP!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:459
translate chinese MLR2_weekend_end_label_rep_e3af3dd8:

    # Mom "*Shluuuuuuurrrrp!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:460
translate chinese MLR2_weekend_end_label_rep_4934c7dd:

    # MC "Hnnnnngggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:464
translate chinese MLR2_weekend_end_label_rep_056542bc:

    # MC "(Oh God! She’s deepthroating my cock right now! Fuck! I’m not gonna last much longer!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:465
translate chinese MLR2_weekend_end_label_rep_36b7bde7:

    # MC "(I’ve got to tell her to stop, or I’ll end up cumming before we have sex!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:469
translate chinese MLR2_weekend_end_label_rep_30d058de:

    # MC "Mom! Stop! I’m gonna... ahhhh... cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:471
translate chinese MLR2_weekend_end_label_rep_10bae71e:

    # MC "Linda! Stop! I’m gonna... ahhhh... cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:472
translate chinese MLR2_weekend_end_label_rep_1e04cbc3:

    # Mom "*Suck suck!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:474
translate chinese MLR2_weekend_end_label_rep_21d8cdf1:

    # MC "Mom! Ahhh! We’re supposed to have sex... hnnnng... remember?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:476
translate chinese MLR2_weekend_end_label_rep_59c7cdc3:

    # MC "Linda! Ahhh! We’re supposed to have sex... hnnnng... remember?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:480
translate chinese MLR2_weekend_end_label_rep_bfd92aec:

    # Mom "(Shit... I have to control myself.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:481
translate chinese MLR2_weekend_end_label_rep_4ab80695:

    # Mom "(This happens every time I’m around him - I just can’t restrain myself.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:483
translate chinese MLR2_weekend_end_label_rep_7ecceeae:

    # MC "Mom!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:485
translate chinese MLR2_weekend_end_label_rep_fa3a6335:

    # MC "Linda!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:486
translate chinese MLR2_weekend_end_label_rep_6e9f946b:

    # Mom "(Fuck... Time to stop.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:490
translate chinese MLR2_weekend_end_label_rep_0294fb70:

    # Mom "(Just one last kiss.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:491
translate chinese MLR2_weekend_end_label_rep_26e8a28e:

    # MC "Phew... *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:492
translate chinese MLR2_weekend_end_label_rep_4f3614ee:

    # MC "(Thank God she’s stopping... That was too close.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:496
translate chinese MLR2_weekend_end_label_rep_c0401168:

    # MC "(I was right on the edge of cumming there. Just a couple more licks, and I would have been jizzing, deep down her throat!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:499
translate chinese MLR2_weekend_end_label_rep_33b0a285:

    # MC "Thanks, Mom. That was... really close. Shall we get started on something else.. then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:501
translate chinese MLR2_weekend_end_label_rep_b8704fc9:

    # MC "Thanks, Linda. That was... really close. Shall we get started on something else.. then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:504
translate chinese MLR2_weekend_end_label_rep_1ee01a02:

    # Mom "(Dammit... I don’t want to stop... It’s just so alluring to suck on.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:506
translate chinese MLR2_weekend_end_label_rep_3ed22d27:

    # MC "What the hell is she doing"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:515
translate chinese MLR2_weekend_end_label_rep_658880ff:

    # Mom "*SHLURRRRRP SUCK SUCK SUCK!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:516
translate chinese MLR2_weekend_end_label_rep_0335d87c:

    # MC "Hnnnnnnggggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:517
translate chinese MLR2_weekend_end_label_rep_d01b88b9:

    # MC "(What the hell is she doing?! Why did she start sucking again?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:518
translate chinese MLR2_weekend_end_label_rep_805ff8a5:

    # Mom "*SUCK SUCK!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:520
translate chinese MLR2_weekend_end_label_rep_099a1451:

    # Mom "(MMM! This feels sooo good!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:521
translate chinese MLR2_weekend_end_label_rep_d56c81db:

    # MC "(I can’t hold it back anymore!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:522
translate chinese MLR2_weekend_end_label_rep_e4e3378c:

    # MC "I’m cumming! AHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:531
translate chinese MLR2_weekend_end_label_rep_523cf011:

    # Mom "*Gulp Gulp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:532
translate chinese MLR2_weekend_end_label_rep_a0a660c3:

    # MC "Ohhh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:533
translate chinese MLR2_weekend_end_label_rep_4fca9ee4:

    # MC "(That was so intense... but what am I gonna do now?! There’s no way I’ll get it hard again, to fuck her...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:537
translate chinese MLR2_weekend_end_label_rep_173004a7:

    # Mom "*Gasp* Wow... You REALLY came hard there, didn’t you, [player_name]?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:539
translate chinese MLR2_weekend_end_label_rep_95d4ad7b:

    # MC "*Pant* Y-Yeah, Mom..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:541
translate chinese MLR2_weekend_end_label_rep_87d0e1e7:

    # MC "*Pant* Y-Yeah, Linda..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:542
translate chinese MLR2_weekend_end_label_rep_fdbbf65d:

    # MC "But that’s me spent - we guy’s aren’t like you girls. We can’t just keep going and going. I need some time to recharge my batteries."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:543
translate chinese MLR2_weekend_end_label_rep_96c936a2:

    # Mom "Hehe... I know, Sweetie. Come lie on the bed, beside me. We can cuddle until you’re ready."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:547
translate chinese MLR2_weekend_end_label_rep_4c4d00d1:

    # Mom "So, your father usually takes a full day before he gets hard again."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:549
translate chinese MLR2_weekend_end_label_rep_0c8ad334:

    # Mom "My husband usually takes a full day before he gets hard again."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:550
translate chinese MLR2_weekend_end_label_rep_4af167dd:

    # Mom "How long does it take a strapping young lad like you?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:551
translate chinese MLR2_weekend_end_label_rep_d3328888:

    # MC "Uh... I don’t know. I’ve never really counted."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:552
translate chinese MLR2_weekend_end_label_rep_95da4efb:

    # Mom "Make a guess."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:553
translate chinese MLR2_weekend_end_label_rep_33362dda:

    # MC "Maybe an hour or two?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:557
translate chinese MLR2_weekend_end_label_rep_81f28d07:

    # Mom "Perhaps I could help speed this process along?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:559
translate chinese MLR2_weekend_end_label_rep_20069e9f:

    # MC "Haha! You’re hot, Mom - but I don’t think you’ll be able to beat biology."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:561
translate chinese MLR2_weekend_end_label_rep_7b6d56ad:

    # MC "Haha! You’re hot, Linda - but I don’t think you’ll be able to beat biology."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:562
translate chinese MLR2_weekend_end_label_rep_68f6c57b:

    # Mom "That’s a shame. I was soooo looking forward to having this big boy, deep inside, my tight wet pussy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:566
translate chinese MLR2_weekend_end_label_rep_c4483237:

    # MC "Nice try, Mom. I don’t think dirty talk is gonna cut it though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:568
translate chinese MLR2_weekend_end_label_rep_fda71852:

    # MC "Nice try, Linda. I don’t think dirty talk is gonna cut it though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:569
translate chinese MLR2_weekend_end_label_rep_24cefb26:

    # MC "Just give me an hour and I’ll be ready for round two."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:570
translate chinese MLR2_weekend_end_label_rep_1cb6cf6c:

    # Mom "Aww, that’s a shame. I was kind of hoping, the mere thought of pushing your rock hard cock between my wet vulva, and deep into my pussy, would get you hard."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:571
translate chinese MLR2_weekend_end_label_rep_50e412f0:

    # Mom "How about the thought of me bouncing up and down on your shaft, until you explode into my-"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:575
translate chinese MLR2_weekend_end_label_rep_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:576
translate chinese MLR2_weekend_end_label_rep_ac2756d6:

    # Mom "Well - it looks like that did the trick."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:577
translate chinese MLR2_weekend_end_label_rep_0b7548a0:

    # MC "I guess you were right! I don’t have a condom though-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:581
translate chinese MLR2_weekend_end_label_rep_09e153cf:

    # Mom "Fuck the condom! I’ve waited FAR too long for this moment, for it to be put off any longer."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:582
translate chinese MLR2_weekend_end_label_rep_e3a2039a:

    # MC "I don’t think that’s safe...?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:583
translate chinese MLR2_weekend_end_label_rep_1313f775:

    # Mom "Hurry up and stick it in me!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:584
translate chinese MLR2_weekend_end_label_rep_31a123ac:

    # MC "(I guess it’s alright if I don’t cum inside.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:588
translate chinese MLR2_weekend_end_label_rep_fbcced81:

    # Mom "Oooh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:589
translate chinese MLR2_weekend_end_label_rep_be81b5a8:

    # Mom "(I can feel his cock pressing against me! It’s going in!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:590
translate chinese MLR2_weekend_end_label_rep_5d259084:

    # Mom "(That naughty dream I had for a while, is FINALLY coming true!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:591
translate chinese MLR2_weekend_end_label_rep_995338a3:

    # Mom "(I feel like I’m ready to burst! I’ll probably cum, the second that he thrusts it inside me!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:594
translate chinese MLR2_weekend_end_label_rep_bb45be40:

    # "*CRREEEEEAAAAAAAK*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:598
translate chinese MLR2_weekend_end_label_rep_5e4af2a5:

    # Mom "HUH?!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:599
translate chinese MLR2_weekend_end_label_rep_485fd02e:

    # MC "Huh!?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:600
translate chinese MLR2_weekend_end_label_rep_399bd247:

    # Mom "(FUCK! That’s the front door!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:603
translate chinese MLR2_weekend_end_label_rep_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:609
translate chinese MLR2_weekend_end_label_rep_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:610
translate chinese MLR2_weekend_end_label_rep_5e907272:

    # MC "(What the hell?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:614
translate chinese MLR2_weekend_end_label_rep_99d2008c:

    # Dad "Hi, Honey! I’m home! How are-"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:615
translate chinese MLR2_weekend_end_label_rep_75077c34:

    # Mom "Get out!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:616
translate chinese MLR2_weekend_end_label_rep_5b3de812:

    # Dad "W-What?!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:617
translate chinese MLR2_weekend_end_label_rep_f3a6d9f0:

    # MC "(Oh fuck... please don’t find me. Please don’t find me...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:621
translate chinese MLR2_weekend_end_label_rep_b33537dd:

    # Dad "I’m just coming to bed! The trip got cancelled at short notice!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:622
translate chinese MLR2_weekend_end_label_rep_9fd95741:

    # Mom "Go and sleep on the couch tonight!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:623
translate chinese MLR2_weekend_end_label_rep_0f7012bc:

    # Dad "Wh-Why?!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:627
translate chinese MLR2_weekend_end_label_rep_bcdbed89:

    # Mom "B-Because I said so, you great big... oaf!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:628
translate chinese MLR2_weekend_end_label_rep_b451c737:

    # Dad "Have I... done something?"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:629
translate chinese MLR2_weekend_end_label_rep_9d1465e1:

    # Dad "Can we talk about this?"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:630
translate chinese MLR2_weekend_end_label_rep_a2d334e3:

    # Mom "We’ll talk in the morning."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:634
translate chinese MLR2_weekend_end_label_rep_6e8787fc:

    # Mom "Just get out!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:635
translate chinese MLR2_weekend_end_label_rep_79b54d08:

    # Dad "(Jesus Christ! What have I done?!)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:637
translate chinese MLR2_weekend_end_label_rep_1d2c109e:

    # Dad "(Fuck... did I forget to clear the browsing history on the family PC?)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:639
translate chinese MLR2_weekend_end_label_rep_79a683ee:

    # Dad "(Fuck... did I forget to clear the browsing history on the PC?)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:640
translate chinese MLR2_weekend_end_label_rep_be2ea63c:

    # Dad "(What was the last thing I watched... Something about tentacles maybe?)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:641
translate chinese MLR2_weekend_end_label_rep_873457d1:

    # Dad "(Damn... I’ll have to wait till the morning to find out.)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:645
translate chinese MLR2_weekend_end_label_rep_8926109c:

    # Mom "Okay, he’s gone now, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:646
translate chinese MLR2_weekend_end_label_rep_07bd4a4f:

    # Mom "Quickly sneak back into your bedroom. I’ll speak with you tomorrow morning."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:647
translate chinese MLR2_weekend_end_label_rep_d776c8c1:

    # MC "O-Okay..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:648
translate chinese MLR2_weekend_end_label_rep_429cfffa:

    # MC "(Jesus, my heart’s pounding like a drum right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:649
translate chinese MLR2_weekend_end_label_rep_7aa3cda7:

    # MC "(I was THIS close to getting caught!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:660
translate chinese MLR2_weekend_end_label_rep_3378d200:

    # Mom "Wakey wakey, Sweetie. Rise and shine."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:661
translate chinese MLR2_weekend_end_label_rep_947a5f05:

    # Mom "It’s time to get up, Honey."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:662
translate chinese MLR2_weekend_end_label_rep_0f4e660f:

    # MC "Hmmm...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:666
translate chinese MLR2_weekend_end_label_rep_744334a1:

    # Mom "Come on, [player_name]. If I can drag myself out of bed after ALL that wine I had last night, then so can you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:668
translate chinese MLR2_weekend_end_label_rep_d0fc37ab:

    # MC "Haha... Morning, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:670
translate chinese MLR2_weekend_end_label_rep_a77a2d1d:

    # MC "Haha... Morning, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:671
translate chinese MLR2_weekend_end_label_rep_02d608fc:

    # MC "*Yawn!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:675
translate chinese MLR2_weekend_end_label_rep_16f08775:

    # Mom "I’m sorry about your father, last night. Just... try to put it out of your head."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:677
translate chinese MLR2_weekend_end_label_rep_03301a7c:

    # Mom "I’m sorry about my husband last night. Just... try to put it out of your head."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:678
translate chinese MLR2_weekend_end_label_rep_e55d8936:

    # Mom "He’d promised me- GUARANTEED ME - he would be gone. I don’t know why he came all the way back, rather than just enjoying a night away in a hotel somewhere."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:680
translate chinese MLR2_weekend_end_label_rep_6b06312e:

    # MC "Hey, it’s okay, Mom. I was shitting myself at the time, but I’ve calmed down now. We didn’t get caught."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:682
translate chinese MLR2_weekend_end_label_rep_8a59673f:

    # MC "Hey, it’s okay, Linda. I was shitting myself at the time, but I’ve calmed down now. We didn’t get caught."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:686
translate chinese MLR2_weekend_end_label_rep_1a3fecc1:

    # Mom "I’ll handle this, don’t worry. We’ll have our night together."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:687
translate chinese MLR2_weekend_end_label_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:689
translate chinese MLR2_weekend_end_label_rep_bc1531ae:

    # Mom "Really. As soon as I can get rid of your father for a while, we’ll actually have sex."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:691
translate chinese MLR2_weekend_end_label_rep_21d69104:

    # Mom "Really. As soon as I can get rid of my husband for a while, we’ll actually have sex."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:695
translate chinese MLR2_weekend_end_label_rep_99e35e67:

    # MC "I love you, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:697
translate chinese MLR2_weekend_end_label_rep_e517d6c7:

    # MC "I love you, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:698
translate chinese MLR2_weekend_end_label_rep_488626ce:

    # Mom "I love you too, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/img16_MLR2_weekend_rep.rpy:699
translate chinese MLR2_weekend_end_label_rep_a791f8ee:

    # Mom "*Mwah!*"
    Mom ""

