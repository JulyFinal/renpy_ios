﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:14
translate chinese SR2_NS2_rep_423a0870:

    # MC "Hey, Sara! I’m glad you came."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:15
translate chinese SR2_NS2_rep_8855f4c4:

    # Sara "Yeah... I’m not gonna lie... I’ve been a bit nervous since you told me about the vibrator."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:16
translate chinese SR2_NS2_rep_1be2c7e6:

    # MC "Oh, have you changed your mind?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:17
translate chinese SR2_NS2_rep_50837a62:

    # Sara "I... I’m not sure... Maybe? I'm just imagining that you bought me some MASSIVE, black or purple, thick, scary thing..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:21
translate chinese SR2_NS2_rep_97353aaa:

    # MC "How about this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:22
translate chinese SR2_NS2_rep_658cebd7:

    # Sara "Oh, my God! He’s so cute! And it’s pink! "
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:23
translate chinese SR2_NS2_rep_fb294c47:

    # MC "He?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:24
translate chinese SR2_NS2_rep_cf9b0733:

    # Sara "It’s a ‘he’ now!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:25
translate chinese SR2_NS2_rep_4e0e60a5:

    # MC "Well? How about you try ‘him’ out now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:29
translate chinese SR2_NS2_rep_11086434:

    # Sara "Can I do you first? I need to get myself ‘warmed up’."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:30
translate chinese SR2_NS2_rep_64d70477:

    # Sara "Helping you get off, will DEFINITELY do the trick for me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:31
translate chinese SR2_NS2_rep_ef0cd9d6:

    # MC "Well, if you’re sure!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:35
translate chinese SR2_NS2_rep_fdc92fc5:

    # Sara "Help me get my bra off now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:36
translate chinese SR2_NS2_rep_d9bcce83:

    # MC "(Oh shit... These things are a bloody nightmare to get unclasped!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:37
translate chinese SR2_NS2_rep_ffb6c97f:

    # MC "(Maybe I could just slip it off her shoulders?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:41
translate chinese SR2_NS2_rep_e60db7c2:

    # MC "(Aha! It’s working! I was worried I might have to spend ages, fiddling with that bloody clasp!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:42
translate chinese SR2_NS2_rep_6462b638:

    # Sara "(Why isn’t he unhooking it? Does he not know how to remove a bra?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:43
translate chinese SR2_NS2_rep_b6484a1c:

    # Sara "[player_name]?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:47
translate chinese SR2_NS2_rep_52a14a98:

    # MC "Yeah, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:48
translate chinese SR2_NS2_rep_671e9fb1:

    # Sara "Why are you taking my bra off like that? You CAN unhook a bra, right?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:49
translate chinese SR2_NS2_rep_6f2ba128:

    # MC "(Fuck, she’s onto me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:50
translate chinese SR2_NS2_rep_d11e198c:

    # MC "Y-Yeah! I thought it would be... um... sexier this way!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:55
translate chinese SR2_NS2_rep_26a0df45:

    # Sara "Aww, that’s sweet. Hehe..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:56
translate chinese SR2_NS2_rep_904bc586:

    # Sara "So, you choose first, [player_name]. What would you like me to do?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:57
translate chinese SR2_NS2_rep_87df04cc:

    # Sara "I can use my mouth again to suck you off, or I could do something else, if you have any ideas?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:58
translate chinese SR2_NS2_rep_9881d691:

    # Sara "I’m still not feeling ready to use my pussy yet."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:67
translate chinese SR2_NS2_rep_a07b977c:

    # MC "You give REALLY good blowjobs. Could I maybe get you to give me another one?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:68
translate chinese SR2_NS2_rep_a6f6bcb3:

    # Sara "Sure! Lie back on the bed!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:72
translate chinese SR2_NS2_rep_2dbd26be:

    # Sara "I’m gonna try even harder this time!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:73
translate chinese SR2_NS2_rep_24ffa1d3:

    # MC "(This is gonna be great!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:74
translate chinese SR2_NS2_rep_4b17d542:

    # Sara "I hope you’re ready!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:79
translate chinese SR2_NS2_rep_8623c3b2:

    # Sara "Ooh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:80
translate chinese SR2_NS2_rep_cbc9fb3c:

    # Sara "(Wow! He’s already so hard...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:81
translate chinese SR2_NS2_rep_053f3a58:

    # Sara "(I forgot how thick and large his cock was...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:85
translate chinese SR2_NS2_rep_b1855829:

    # MC "See something you like there, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:86
translate chinese SR2_NS2_rep_8b1f2dfe:

    # Sara "Ah... It’s so... big. And you’re already hard!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:87
translate chinese SR2_NS2_rep_bb080f88:

    # MC "Of course I am! I got to see your tits, after all!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:91
translate chinese SR2_NS2_rep_41a50fb2:

    # Sara "Huh, I guess so."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:92
translate chinese SR2_NS2_rep_da2f9667:

    # Sara "How does it feel when I touch the tip, with my finger, like this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:93
translate chinese SR2_NS2_rep_b95a1bb9:

    # MC "Mmm... It’s really intense and sensitive."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:94
translate chinese SR2_NS2_rep_bc38314a:

    # Sara "In a good way?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:95
translate chinese SR2_NS2_rep_3b3e5e28:

    # MC "Yeah, in a good way."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:96
translate chinese SR2_NS2_rep_2ecdc6fa:

    # Sara "So, it would be REALLY good if I used my tongue to lick the tip?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:97
translate chinese SR2_NS2_rep_b2d271a6:

    # MC "Ooooh, yeah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:101
translate chinese SR2_NS2_rep_fa162b4b:

    # Sara "*Lick*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:102
translate chinese SR2_NS2_rep_bc18cec7:

    # MC "Ah... That’s good, Sara. Just like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:103
translate chinese SR2_NS2_rep_39405adb:

    # MC "(Damn, that feels incredible. She’s dragging her tongue so slowly across my glans.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:107
translate chinese SR2_NS2_rep_41829f32:

    # Sara "(I can feel his cock twitching under my tongue. He must be enjoying this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:108
translate chinese SR2_NS2_rep_f0113c94:

    # Sara "(And it tastes like, some precum is already leaking out.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:109
translate chinese SR2_NS2_rep_b7df96f1:

    # Sara "(I wonder how long I can lick his cock, before he begs me to start sucking on it?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:110
translate chinese SR2_NS2_rep_a6b14193:

    # Sara "*Lick Lick*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:111
translate chinese SR2_NS2_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:115
translate chinese SR2_NS2_rep_7325117e:

    # MC "(Damn, she’s teasing me with that tongue of hers!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:116
translate chinese SR2_NS2_rep_14c0fb23:

    # Sara "*Lick Lick Lick*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:117
translate chinese SR2_NS2_rep_db075c33:

    # MC "Fuck... Mmm! Can you start sucking?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:121
translate chinese SR2_NS2_rep_0db585d9:

    # Sara "(Hehe! Not long, it seems!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:122
translate chinese SR2_NS2_rep_aeae41f2:

    # Sara "*Shlluuurrrrp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:123
translate chinese SR2_NS2_rep_d41cbd9a:

    # MC "Ahh... God..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:124
translate chinese SR2_NS2_rep_151de0f7:

    # MC "(Her mouth is so hot and wet, around my cock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:128
translate chinese SR2_NS2_rep_c4cc7adf:

    # MC "That was amazing, Sara. Can we switch positions though?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:129
translate chinese SR2_NS2_rep_e63b8dda:

    # Sara "Where do you want me to go?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:130
translate chinese SR2_NS2_rep_b6c87807:

    # MC "You just lie, face-down, on the bed. I’ll stand at the end."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:131
translate chinese SR2_NS2_rep_eaecc795:

    # Sara "Okay."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:135
translate chinese SR2_NS2_rep_d870eda2:

    # Sara "Like this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:136
translate chinese SR2_NS2_rep_13b47032:

    # MC "That’s perfect."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:137
translate chinese SR2_NS2_rep_3bf5ed17:

    # Sara "Why did you want to swap around?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:141
translate chinese SR2_NS2_rep_723085c0:

    # MC "From this angle, I can thrust my hips forward into your mouth."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:142
translate chinese SR2_NS2_rep_da6ff1e4:

    # Sara "Okay, if you like this position more... Just don't do it harshly."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:143
translate chinese SR2_NS2_rep_d4a79109:

    # MC "Don't worry, I won't. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:144
translate chinese SR2_NS2_rep_04d7b16c:

    # Sara "Then put him ins-"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:148
translate chinese SR2_NS2_rep_034608ce:

    # Sara "Mppfff!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:150
translate chinese SR2_NS2_rep_500185e9:

    # MC "Ohhh, that’s good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:151
translate chinese SR2_NS2_rep_b09b2211:

    # Sara "(His cock, is so thick and long! There’s no way I’ll be able to take more than half of it in my mouth!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:155
translate chinese SR2_NS2_rep_bf59c8f0:

    # MC "Mmm...Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:156
translate chinese SR2_NS2_rep_817b7bc5:

    # Sara "*Shluurrrrp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:157
translate chinese SR2_NS2_rep_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:161
translate chinese SR2_NS2_rep_c49a1914:

    # Sara "Mppffff!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:162
translate chinese SR2_NS2_rep_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:164
translate chinese SR2_NS2_rep_bd764ef6:

    # MC "(The feeling of her lips wrapped around my cock is unbelievably good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:168
translate chinese SR2_NS2_rep_f760525c:

    # MC "(I can’t stand it any longer! I have to feel it go deeper!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:169
translate chinese SR2_NS2_rep_45ff41b1:

    # MC "(I hope she won’t mind if I put my hands on her head and push my dick, further into her mouth...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:170
translate chinese SR2_NS2_rep_c50ac75f:

    # Sara "Hmm?!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:174
translate chinese SR2_NS2_rep_a4ed4202:

    # Sara "Mmmpfff..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:176
translate chinese SR2_NS2_rep_03c84f36:

    # Sara "(What’s he DOING with his hands on my head?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:177
translate chinese SR2_NS2_rep_69f605a4:

    # Sara "(Surely he’s not going to-)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:181
translate chinese SR2_NS2_rep_da149c55:

    # Sara "MPPFF!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:182
translate chinese SR2_NS2_rep_5062c951:

    # Sara "*SHLURRRRRP!*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:183
translate chinese SR2_NS2_rep_9029b9da:

    # MC "Ahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:184
translate chinese SR2_NS2_rep_af0d2e4a:

    # MC "(I can feel the first couple of inches of my cock, slipping down her wet throat!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:188
translate chinese SR2_NS2_rep_9f837a7b:

    # MC "(Fuck, this is amazing! I have to do that again.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:190
translate chinese SR2_NS2_rep_efde2cd1:

    # Sara "*GAG!*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:191
translate chinese SR2_NS2_rep_9dd98805:

    # Sara "*Suck suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:195
translate chinese SR2_NS2_rep_efde2cd1_1:

    # Sara "*GAG!*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:196
translate chinese SR2_NS2_rep_5062c951_1:

    # Sara "*SHLURRRRRP!*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:198
translate chinese SR2_NS2_rep_b067cce8:

    # MC "(Her throat is so fucking tight! I can feel it grasping at my dick each time her gag reflex kicks in!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:199
translate chinese SR2_NS2_rep_8b68eda4:

    # MC "Hnnng! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:200
translate chinese SR2_NS2_rep_00a9a5c2:

    # Sara "(Wait - is he going to cum inside my mouth again!?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:209
translate chinese SR2_NS2_rep_c422e9da:

    # MC "Hnnng! Oh yeah! Fuck! Ahhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:210
translate chinese SR2_NS2_rep_80e79660:

    # MC "Right there! Yes! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:211
translate chinese SR2_NS2_rep_ee66c4f7:

    # Sara "(There’s so much! I can taste his salty semen, flooding over my tongue!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:215
translate chinese SR2_NS2_rep_8769f689:

    # MC "That was amazing, Sara... *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:216
translate chinese SR2_NS2_rep_98cb2d89:

    # Sara "(Should I swallow it again, like last time?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:217
translate chinese SR2_NS2_rep_f21628b5:

    # Sara "(I guess that would really make him happy.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:221
translate chinese SR2_NS2_rep_0c92c745:

    # MC "Are you okay there, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:222
translate chinese SR2_NS2_rep_b068b0c8:

    # MC "Oh! Do you need me to get you a tissue, to spit it out in?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:223
translate chinese SR2_NS2_rep_51190ce8:

    # Sara "(There’s so much... but it will make him so happy if I can swallow it.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:227
translate chinese SR2_NS2_rep_a022173a:

    # MC "Sara, you don’t have to try and swallow it. Let me get your a tissue and you can-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:228
translate chinese SR2_NS2_rep_152e3a83:

    # Sara "*GULP*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:229
translate chinese SR2_NS2_rep_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:233
translate chinese SR2_NS2_rep_442fb9b2:

    # Sara "Aaaah...."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:234
translate chinese SR2_NS2_rep_16b20f73:

    # Sara "All gone. Hehe..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:235
translate chinese SR2_NS2_rep_670e5753:

    # Sara "Sorry, there was so much that it was really difficult to swallow. You know the way you sometimes take too big a drink and it gets stuck in your mouth?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:236
translate chinese SR2_NS2_rep_a5c4ffdb:

    # MC "Haha, I know. Thanks, Sara. That blowjob was incredible."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:237
translate chinese SR2_NS2_rep_9ca4b36f:

    # Sara "I’m glad you liked it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:243
translate chinese SR2_NS2_rep_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:244
translate chinese SR2_NS2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:245
translate chinese SR2_NS2_rep_002ba9e3:

    # Sara "(I love you so much, [player_name]... You’re the best thing to ever happen to me, in my life.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:256
translate chinese SR2_NS2_rep_cf150844:

    # MC "How about we try a footjob? Did try it before with anyone?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:257
translate chinese SR2_NS2_rep_16ae4295:

    # Sara "A footjob? In porn, women used only their feet right? I didn't know you like that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:258
translate chinese SR2_NS2_rep_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:259
translate chinese SR2_NS2_rep_d8d4cbc0:

    # Sara " I... think I can work it out, but could you maybe give me some pointers to get me started?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:260
translate chinese SR2_NS2_rep_33bf2d96:

    # MC "Sure. Lie face-up, on the bed with your legs spread."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:264
translate chinese SR2_NS2_rep_d870eda2_1:

    # Sara "Like this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:265
translate chinese SR2_NS2_rep_ced3ea5e:

    # MC "That’s perfect, Sara. I’ll show you what to do next."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:266
translate chinese SR2_NS2_rep_12a1fba7:

    # MC "(Her breasts are fucking perfect! Plus, I’ve got a great angle to view them when she’s lying down like this.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:270
translate chinese SR2_NS2_rep_33cb8ad6:

    # MC "Okay, bring your feet up to my cock and try to massage it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:271
translate chinese SR2_NS2_rep_e7a84572:

    # Sara "Okay... Got it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:273
translate chinese SR2_NS2_rep_1f230ba5:

    # MC "Try not to use too much force, or you might hurt me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:274
translate chinese SR2_NS2_rep_d45d466f:

    # Sara "I’ll be careful!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:278
translate chinese SR2_NS2_rep_0e0dd0d6:

    # Sara "How’s this? Am I being gentle enough?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:279
translate chinese SR2_NS2_rep_9987ed5f:

    # MC "Yeah, that’s really good, Sara. You’re doing great."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:280
translate chinese SR2_NS2_rep_a497d6bb:

    # MC "(Her feet are so cute!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:281
translate chinese SR2_NS2_rep_65f49b92:

    # MC "Can you place your feet, either side of my cock and move them back and forth?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:285
translate chinese SR2_NS2_rep_2229efde:

    # Sara "Just like this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:287
translate chinese SR2_NS2_rep_a64d101c:

    # MC "Yeah, like that. Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:288
translate chinese SR2_NS2_rep_90ee3a1b:

    # Sara "How does that feel?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:292
translate chinese SR2_NS2_rep_fdb98d2c:

    # MC "Ahh... It’s... kind of like a handjob, but if you’re really into feet, like I am, then it’s sooo much more erotic."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:293
translate chinese SR2_NS2_rep_648f2c40:

    # Sara "Really? Wow..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:294
translate chinese SR2_NS2_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:295
translate chinese SR2_NS2_rep_4188d866:

    # Sara "Do I need to go faster?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:299
translate chinese SR2_NS2_rep_65149a2a:

    # MC "That’s perfect, just like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:300
translate chinese SR2_NS2_rep_ebfe8a82:

    # Sara "It feels kinda strange, but I’m glad you like it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:301
translate chinese SR2_NS2_rep_ca9c5ce1:

    # Sara "How about if I try something like... this!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:305
translate chinese SR2_NS2_rep_da7a2c09:

    # MC "Ohhh! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:307
translate chinese SR2_NS2_rep_584910da:

    # Sara "Hehe! That sounds like it worked well!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:308
translate chinese SR2_NS2_rep_352e5e46:

    # Sara "(His cock is twitching against the sole of my foot! It must be REALLY sensitive when I do this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:312
translate chinese SR2_NS2_rep_1459637d:

    # MC "Ugh! Ahh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:313
translate chinese SR2_NS2_rep_32c9440d:

    # MC "(Damn, this is making me soooo horny! I wish I could just rip her panties off and fuck her RIGHT NOW!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:317
translate chinese SR2_NS2_rep_39ceb7f6:

    # MC "(I’d just lean forward, grab the elastic waistband, and tear them off.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:318
translate chinese SR2_NS2_rep_baf03df0:

    # MC "(Then, I’d thrust my hips down and plunge my cock into her wet pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:319
translate chinese SR2_NS2_rep_e589f1c5:

    # MC "(She wouldn’t be able to resist the pleasure, once my cock was buried deep inside her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:323
translate chinese SR2_NS2_rep_7e0b55ad:

    # MC "(It looks so inviting... but I have to hold myself back. She said she wasn’t ready for that yet...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:324
translate chinese SR2_NS2_rep_a4e84f9b:

    # Sara "Are you okay, [player_name]? You’ve gone quiet?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:325
translate chinese SR2_NS2_rep_774fc5c4:

    # MC "Y-Yeah, I’m just enjoying how good it feels."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:329
translate chinese SR2_NS2_rep_793716b7:

    # Sara "A-Are you looking at my panties?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:330
translate chinese SR2_NS2_rep_17946bf8:

    # Sara "You really want to fuck me... don’t you?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:331
translate chinese SR2_NS2_rep_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:335
translate chinese SR2_NS2_rep_43bb6aea:

    # Sara "[player_name]? Are you thinking about trying to fuck me?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:336
translate chinese SR2_NS2_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:337
translate chinese SR2_NS2_rep_9c125eb0:

    # MC "(Dammit! I can’t resist much longer. I’m gonna have to cum quickly!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:341
translate chinese SR2_NS2_rep_1207ee4a:

    # Sara "Eek!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:342
translate chinese SR2_NS2_rep_c9b49bc5:

    # MC "Move your feet faster, Sara! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:344
translate chinese SR2_NS2_rep_a919febb:

    # MC "Rub my cock as quickly as you can! Ah! Ooohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:348
translate chinese SR2_NS2_rep_5ce79554:

    # Sara "*Pant* I am! Ah... Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:349
translate chinese SR2_NS2_rep_7e88aaca:

    # MC "Mmm! Yes! Just like that! Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:350
translate chinese SR2_NS2_rep_a2b51f0a:

    # MC "(Dammit, I want to feel my dick inside her body, so badly right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:354
translate chinese SR2_NS2_rep_e48ea915:

    # MC "Yes! Ugh! AHH! Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:355
translate chinese SR2_NS2_rep_8c4668ae:

    # MC "I’m gonna cum soon, Sara!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:356
translate chinese SR2_NS2_rep_2bc94467:

    # Sara "*Pant Pant*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:360
translate chinese SR2_NS2_rep_0ea90eb0:

    # MC "Hnnnggggg! GAHHHHH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:361
translate chinese SR2_NS2_rep_80e3a37a:

    # MC "Ugh! Hnng!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:369
translate chinese SR2_NS2_rep_17e9d1b0:

    # Sara "(Wow! He’s cumming so hard right now!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:373
translate chinese SR2_NS2_rep_d2e5f241:

    # MC "Phew... That was... fucking amazing, Sara..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:374
translate chinese SR2_NS2_rep_bf578e54:

    # Sara "Hehe... You enjoyed it, then?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:375
translate chinese SR2_NS2_rep_2d15ae24:

    # MC "It was incredible..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:376
translate chinese SR2_NS2_rep_8af2c762:

    # MC "You haven’t had an orgasm yet, though. Let me grab the vibrator and we’ll get started on your turn."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:385
translate chinese SR2_NS2_continue_rep_f5c81c18:

    # MC "Thank you so much, Sara. That felt absolutely amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:386
translate chinese SR2_NS2_continue_rep_66f17d2b:

    # Sara "I’m really happy you enjoyed it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:387
translate chinese SR2_NS2_continue_rep_22f5740e:

    # MC "It’s your turn now though. Let's see if I can make you as happy as you made me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:391
translate chinese SR2_NS2_continue_rep_53d2a19e:

    # MC "I’ll just have to slip your panties off, first here."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:392
translate chinese SR2_NS2_continue_rep_5b233742:

    # Sara "O-Okay... *Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:393
translate chinese SR2_NS2_continue_rep_3826250f:

    # MC "(She still sounds a little nervous. Perhaps she’s just shy?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:397
translate chinese SR2_NS2_continue_rep_2c563c91:

    # MC "Here we go..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:398
translate chinese SR2_NS2_continue_rep_7320c8d5:

    # MC "If you’re uncomfortable with this, at all, Sara. Just let me know, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:399
translate chinese SR2_NS2_continue_rep_6bb0cf3e:

    # Sara "I will..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:403
translate chinese SR2_NS2_continue_rep_11517c50:

    # MC "(Her breathing is getting much quicker. I’ll have to be careful not to drag this out for too long. I don’t want her getting shy, and backing out.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:404
translate chinese SR2_NS2_continue_rep_9d67c09a:

    # Sara "(He’s gonna see my pussy again... I wonder what’s it going to feel with that new vibrator up to it?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:405
translate chinese SR2_NS2_continue_rep_6a7e33ce:

    # Sara "(I usually shake and tremble, as he does... I hope he will like to see it.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:409
translate chinese SR2_NS2_continue_rep_6df383f0:

    # Sara "(I hope I don’t moan as loudly as [player_name] does. It would be sooo embarrassing...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:410
translate chinese SR2_NS2_continue_rep_58186086:

    # MC "There we go."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:411
translate chinese SR2_NS2_continue_rep_771611be:

    # MC "Your pussy looks so beautiful, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:415
translate chinese SR2_NS2_continue_rep_73859138:

    # Sara "Ahhh... Don’t stare at it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:416
translate chinese SR2_NS2_continue_rep_36104fe2:

    # MC "Oh c’mon. It’s gorgeous. What are you shy about?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:417
translate chinese SR2_NS2_continue_rep_d1befd92:

    # Sara "It’s embarrassing when you look at it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:421
translate chinese SR2_NS2_continue_rep_d6f57df4:

    # MC "Sara, relax. There’s nothing to be shy about. You’ve got one of the sexiest bodies I’ve ever seen."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:422
translate chinese SR2_NS2_continue_rep_0a5ef609:

    # Sara "P-Promise? You really mean that?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:423
translate chinese SR2_NS2_continue_rep_6fd9d1c6:

    # MC "I do. Now lie back - it’s my turn to make you feel good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:427
translate chinese SR2_NS2_continue_rep_d98e715b:

    # MC "I’m gonna need you to spread your legs a little bit, so I can get the vibrator nice and close."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:428
translate chinese SR2_NS2_continue_rep_54668e28:

    # Sara "O-Oh, sorry. I’ll do that now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:432
translate chinese SR2_NS2_continue_rep_21bdac43:

    # Sara "I-Is that okay?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:433
translate chinese SR2_NS2_continue_rep_6a5147a6:

    # MC "That’s perfect. Just lie back, relax, and enjoy this. Okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:434
translate chinese SR2_NS2_continue_rep_c0f9a610:

    # Sara "O-Okay..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:438
translate chinese SR2_NS2_continue_rep_544e3cec:

    # MC "I’m gonna begin by lightly massaging your vulva. If it is too sensitive, or hurts at all, just let me know, and I’ll stop immediately. Okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:439
translate chinese SR2_NS2_continue_rep_8cedc5d8:

    # Sara "O-Okay, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:440
translate chinese SR2_NS2_continue_rep_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:444
translate chinese SR2_NS2_continue_rep_2b253959:

    # Sara "Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:445
translate chinese SR2_NS2_continue_rep_7ff12af2:

    # Sara "(He can see inside me right now!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:446
translate chinese SR2_NS2_continue_rep_2f1e5600:

    # Sara "(What if he doesn’t like how I look, and he doesn’t want to ‘date’ me anymore....)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:447
translate chinese SR2_NS2_continue_rep_842a0530:

    # MC "You’re beautiful, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:451
translate chinese SR2_NS2_continue_rep_ceb46acb:

    # Sara "Ooohh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:452
translate chinese SR2_NS2_continue_rep_cdf5bf74:

    # MC "I’m just using my fingers to check if you’re wet enough."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:453
translate chinese SR2_NS2_continue_rep_0d962296:

    # Sara "Ahhh.... Mm hmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:457
translate chinese SR2_NS2_continue_rep_05148c33:

    # MC "Okay, that’s perfect. I’ll turn the vibrator on now and start using it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:458
translate chinese SR2_NS2_continue_rep_81bfe500:

    # MC "If you want me to stop, just let me know, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:459
translate chinese SR2_NS2_continue_rep_37044cfb:

    # Sara "I... I will, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:463
translate chinese SR2_NS2_continue_rep_43355176:

    # MC "I love you so much. I’m not going to do anything that will hurt you. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:464
translate chinese SR2_NS2_continue_rep_4d30e8d9:

    # Sara "*Gulp* Thanks.. Sorry I’m so... nervous right now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:465
translate chinese SR2_NS2_continue_rep_8066a71e:

    # MC "You don't need to apologise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:469
translate chinese SR2_NS2_continue_rep_e111cfb1:

    # MC "Here we go. I’ll just push the small button here and..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:471
translate chinese SR2_NS2_continue_rep_424ee770:

    # "*Buzzzzz*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:472
translate chinese SR2_NS2_continue_rep_1207ee4a:

    # Sara "Eek!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:473
translate chinese SR2_NS2_continue_rep_0faba641:

    # MC "It’s supposed to make that noise, don't worry."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:477
translate chinese SR2_NS2_continue_rep_4f37c14f:

    # Sara "Mmm! Ah... Ohh...."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:478
translate chinese SR2_NS2_continue_rep_bf82834c:

    # MC "(Well, it sounds like she’s enjoying it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:479
translate chinese SR2_NS2_continue_rep_6c6f88f6:

    # MC "(I hope the sales assistant was correct, when she told me to purchase the most powerful vibrator they had in store!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:483
translate chinese SR2_NS2_continue_rep_0810f16f:

    # Sara "Oh... OOOHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:484
translate chinese SR2_NS2_continue_rep_8beb7353:

    # Sara "(This feels so... strange! It’s like my clitoris is burning! Ahh...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:485
translate chinese SR2_NS2_continue_rep_60920b31:

    # Sara "Ahh! Ahhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:487
translate chinese SR2_NS2_continue_rep_1a483428:

    # "*BUZZ*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:491
translate chinese SR2_NS2_continue_rep_6661ce43:

    # MC "How is it, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:492
translate chinese SR2_NS2_continue_rep_b9c7b28e:

    # Sara "It’s- ahh... s-sooo intense!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:493
translate chinese SR2_NS2_continue_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:494
translate chinese SR2_NS2_continue_rep_a040be57:

    # Sara "I ahhh... d-don’t knoooohhhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:498
translate chinese SR2_NS2_continue_rep_a1641d4a:

    # Sara "AHHH! AHHH! MMMMM! OOOHHHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:499
translate chinese SR2_NS2_continue_rep_c9daeffd:

    # Sara "S-Stop! OHH! STOP!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:500
translate chinese SR2_NS2_continue_rep_77e28e52:

    # MC "(Uh oh, is something wrong?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:504
translate chinese SR2_NS2_continue_rep_fc30ea4a:

    # MC "Are you alright, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:505
translate chinese SR2_NS2_continue_rep_f01bb54c:

    # Sara "Y-Yeah... *Pant* It was just... so intense... *Gasp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:506
translate chinese SR2_NS2_continue_rep_1b350dae:

    # MC "Did you cum?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:507
translate chinese SR2_NS2_continue_rep_107474bc:

    # Sara "Yes... But that was really powerful... I never used something that strong before."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:508
translate chinese SR2_NS2_continue_rep_d3a14657:

    # MC "Would you like me to continue one more time?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:509
translate chinese SR2_NS2_continue_rep_cde6ff2b:

    # Sara "Could we just cuddle instead?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:513
translate chinese SR2_NS2_continue_rep_d75b0317:

    # MC "Of course we can. Rest your head on my chest here."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:514
translate chinese SR2_NS2_continue_rep_93ab3e0c:

    # Sara "Thanks, [player_name]. I’m not used to something that strong... but that orgasm was really good."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:515
translate chinese SR2_NS2_continue_rep_aad9d50b:

    # MC "You’re perfect, Sara. It’ll just take some time for you to get used to all this."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:519
translate chinese SR2_NS2_continue_rep_b69d9b50:

    # MC "I’ll leave the vibrator with you. You can use it anytime you want."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:520
translate chinese SR2_NS2_continue_rep_57c204a7:

    # MC "Just take things at your own pace, with what you’re comfortable with."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:521
translate chinese SR2_NS2_continue_rep_804b11f8:

    # Sara "Are you sure?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:525
translate chinese SR2_NS2_continue_rep_86bf3460:

    # MC "Of course, Sara. You keep the vibrator."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:527
translate chinese SR2_NS2_continue_rep_d665ef11:

    # Sara "Thank you so much, [player_name]. I’m so lucky to have you as a brother."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:529
translate chinese SR2_NS2_continue_rep_bf823162:

    # Sara "Thank you so much, [player_name]. I’m so lucky to have you in my life."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:530
translate chinese SR2_NS2_continue_rep_6652fdf4:

    # MC "Goodnight, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:532
translate chinese SR2_NS2_continue_rep_f9bf3479:

    # Sara "I love you, [player_name]. I better sneak back to my room before I fall asleep, and Mom catches me in the morning!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:534
translate chinese SR2_NS2_continue_rep_43e83217:

    # Sara "I love you. I better go back to my room. I have something to study in the morning."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:535
translate chinese SR2_NS2_continue_rep_ee9cf9a2:

    # MC "I love you too, Sara. I’ll see you tomorrow."
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:60
    old "Can I get a blowjob, Sara?"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:60
    old "Do you know how to give a footjob, Sara?"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS2_rep.rpy:239
    old "Kiss her"
    new ""

