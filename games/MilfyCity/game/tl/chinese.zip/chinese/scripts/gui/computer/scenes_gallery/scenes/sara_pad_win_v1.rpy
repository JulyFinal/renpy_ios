﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:5
translate chinese sara_pad_win_v1_f0d5a635:

    # Sara "I said flank left! That’s the right flank, you dumbos!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:6
translate chinese sara_pad_win_v1_50a8fab3:

    # MC "(Wow, looks like Sara’s teammates aren’t up to scratch today!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:7
translate chinese sara_pad_win_v1_21d8d926:

    # Sara "Grr! We lost the match because of you guys! I’m off now. Chat later!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:10
translate chinese sara_pad_win_v1_2bdc730f:

    # Sara "Oh! Hey, [player_name]! Didn’t see you standing there. Do you fancy a rematch?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:11
translate chinese sara_pad_win_v1_3f09a547:

    # MC "(I’ve swapped the working controller for the cheap Chinese knock-off version! This should give me the edge I need to beat her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:12
translate chinese sara_pad_win_v1_04d49041:

    # MC "Yeah, I’m ready whenever you are!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:15
translate chinese sara_pad_win_v1_7b300e92:

    # Sara "Sweet! Let me get it set up here."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:16
translate chinese sara_pad_win_v1_5085d648:

    # Sara "Do you want to play Street Brawler VII again? Or something else this time?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:17
translate chinese sara_pad_win_v1_24ad7585:

    # MC "Street Brawler works for me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:18
translate chinese sara_pad_win_v1_5b8cc442:

    # Sara "Coolio!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:22
translate chinese sara_pad_win_v1_c6f291a3:

    # Sara "Hehe - you do know you’re gonna lose again, right?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:23
translate chinese sara_pad_win_v1_7519fdac:

    # MC "Perhaps."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:24
translate chinese sara_pad_win_v1_a7d8903f:

    # Sara "And you know the penalty for losing?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:25
translate chinese sara_pad_win_v1_aad7d578:

    # MC "I lose a piece of clothing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:26
translate chinese sara_pad_win_v1_4bafe4d0:

    # Sara "Yup! Now let’s get started!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:31
translate chinese sara_pad_win_v1_23988fd5:

    # "(Three Minutes Later...)"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:34
translate chinese sara_pad_win_v1_b20a4d5e:

    # Console "FATALITY!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:35
translate chinese sara_pad_win_v1_c85d189a:

    # Sara "Wh-What?! N-No way!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:36
translate chinese sara_pad_win_v1_a7d763b6:

    # MC "That’s one-nil, Sara! Time to lose a piece of clothing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:39
translate chinese sara_pad_win_v1_0b574aa5:

    # Sara "B-But I’m n-not wearing a bra..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:40
translate chinese sara_pad_win_v1_a147add3:

    # MC "Then lose your denim shorts."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:41
translate chinese sara_pad_win_v1_2d05ade3:

    # Sara "I... I’m not w-wearing any... *ahem* either..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:42
translate chinese sara_pad_win_v1_e42b0e1c:

    # MC "You’re not wearing ANY underwear?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:43
translate chinese sara_pad_win_v1_c42736de:

    # Sara "Look away while I take my top off..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:46
translate chinese sara_pad_win_v1_438e3446:

    # MC "Fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:53
translate chinese sara_pad_win_v1_2ae1630e:

    # MC "(Holy shit! She’s so fucking hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:54
translate chinese sara_pad_win_v1_49b832c4:

    # Sara "(I can’t believe this... it’s so embarrassing!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:55
translate chinese sara_pad_win_v1_539ce67b:

    # Sara "(Why didn’t I wear any underwear?! I was sooo consident that I was going to win again!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:56
translate chinese sara_pad_win_v1_dd9f3735:

    # MC "(Hehe - this broken controller is working like a charm! She doesn’t know what the hell is going on!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:62
translate chinese sara_pad_win_v1_2827d6d4:

    # MC "Fine, I won’t look."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:63
translate chinese sara_pad_win_v1_328ccbad:

    # Sara "Thank you..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:64
translate chinese sara_pad_win_v1_32d75f56:

    # MC "Are you done yet?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:65
translate chinese sara_pad_win_v1_614b8908:

    # Sara "Almost..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:71
translate chinese after_choice_sis_nerdy_evening_scene31r_88fd38b5:

    # MC "(Her nipples are pretty stiff! She must be secretly enjoying this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:72
translate chinese after_choice_sis_nerdy_evening_scene31r_5d7a791e:

    # Console "ROUND 2! FIGHT!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:73
translate chinese after_choice_sis_nerdy_evening_scene31r_eaea29be:

    # Sara "I’m gonna beat your ass this time!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:74
translate chinese after_choice_sis_nerdy_evening_scene31r_111fbe93:

    # MC "Oh yeah? You really think so?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:75
translate chinese after_choice_sis_nerdy_evening_scene31r_f71d40d4:

    # Sara "Dammit! I pressed X three times! Why didn’t it work?!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:76
translate chinese after_choice_sis_nerdy_evening_scene31r_a0eb5595:

    # Console "C-C-COMBO BREAKER!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:79
translate chinese after_choice_sis_nerdy_evening_scene31r_b6d8ff64:

    # Console "FATALITY! PLAYER 2 WINS AGAIN!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:80
translate chinese after_choice_sis_nerdy_evening_scene31r_c6ee1b72:

    # Sara "NOOOOOOO!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:81
translate chinese after_choice_sis_nerdy_evening_scene31r_d4e07eca:

    # MC "Yesss!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:82
translate chinese after_choice_sis_nerdy_evening_scene31r_1088fe48:

    # Sara "N-No way! This c-can’t be happening!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:83
translate chinese after_choice_sis_nerdy_evening_scene31r_5e74c6ee:

    # MC "You know the rules, Sara! Time to lose those denim shorts!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:84
translate chinese after_choice_sis_nerdy_evening_scene31r_0c35ce1b:

    # MC "Or... you could just lose your shoes."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:87
translate chinese after_choice_sis_nerdy_evening_scene31r_8bb0bafd:

    # MC "Actually! Let’s make a deal - one more round. Sudden death rules."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:88
translate chinese after_choice_sis_nerdy_evening_scene31r_b51d1f81:

    # Sara "What do you mean?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:89
translate chinese after_choice_sis_nerdy_evening_scene31r_39043f55:

    # MC "If you win, I take off EVERYTHING. If I win though... then you have to strip completely naked for me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:90
translate chinese after_choice_sis_nerdy_evening_scene31r_db6c1ccd:

    # MC "Deal?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:91
translate chinese after_choice_sis_nerdy_evening_scene31r_b909d4fa:

    # Sara "... Deal."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:95
translate chinese after_choice_sis_nerdy_evening_scene31r_9cc3d059:

    # "(Thirty seconds later...)"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:100
translate chinese after_choice_sis_nerdy_evening_scene31r_8a299e11:

    # Sara "AAAAAAHHHHHHH!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:101
translate chinese after_choice_sis_nerdy_evening_scene31r_b6edd993:

    # Sara "(WHAT’S HAPPENING?! Why aren’t I good at video games anymore?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:102
translate chinese after_choice_sis_nerdy_evening_scene31r_98c1dc9e:

    # MC "You lost the deal, Sara. Time to strip off!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:105
translate chinese after_choice_sis_nerdy_evening_scene31r_c9b0822c:

    # Sara "Ugh... Fine. I’ll do it on the bed."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:106
translate chinese after_choice_sis_nerdy_evening_scene31r_7da89808:

    # Sara "N-No photos though!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:107
translate chinese after_choice_sis_nerdy_evening_scene31r_860a84c7:

    # MC "That’s a bit hypocritical of you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:108
translate chinese after_choice_sis_nerdy_evening_scene31r_44eabcf0:

    # Sara "I... I don’t have that picture anymore. I... um... deleted it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:109
translate chinese after_choice_sis_nerdy_evening_scene31r_13ad020f:

    # MC "(She’s lying... She definitely still has that picture of my dick!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:112
translate chinese after_choice_sis_nerdy_evening_scene31r_df7ad3d5:

    # MC "Fine, no photos. But I still want to see your whole body."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:113
translate chinese after_choice_sis_nerdy_evening_scene31r_13fa39d0:

    # Sara "*Gulp* S-Sure."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:114
translate chinese after_choice_sis_nerdy_evening_scene31r_17e2be64:

    # Sara "(I can’t believe I lost... I thought this would just be an easy way to see [player_name]’s cock again.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:115
translate chinese after_choice_sis_nerdy_evening_scene31r_9b8971f0:

    # Sara "(God... what am I going to tell Lily if she asks what happend?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:118
translate chinese after_choice_sis_nerdy_evening_scene31r_99aac29f:

    # MC "(Wow! There’s her pussy! I can see the hood of her clitoris, poking out the top.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:119
translate chinese after_choice_sis_nerdy_evening_scene31r_aa5a04b3:

    # MC "(She wasn’t lying when she said she wasn’t wearing any panties. Was she seriously THAT confident that she was going to win?! Haha!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:120
translate chinese after_choice_sis_nerdy_evening_scene31r_da3ae82c:

    # Sara "W-Well? I-Is this enough?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:123
translate chinese after_choice_sis_nerdy_evening_scene31r_86ccc17a:

    # MC "We did agree, completely naked - but this is a rather sexy view."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:124
translate chinese after_choice_sis_nerdy_evening_scene31r_7d569a3f:

    # Sara "S-Sexy?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:125
translate chinese after_choice_sis_nerdy_evening_scene31r_61bf95b5:

    # MC "I’m just teasing you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:128
translate chinese after_choice_sis_nerdy_evening_scene31r_fba1a468:

    # Sara "W-Wait - You can’t just s-say something like that and walk away..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:129
translate chinese after_choice_sis_nerdy_evening_scene31r_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:130
translate chinese after_choice_sis_nerdy_evening_scene31r_22fdb367:

    # Sara "D... Do... you think I’m pretty?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:133
translate chinese after_choice_sis_nerdy_evening_scene31r_9509f862:

    # MC "Of course you’re pretty. I’d hardly be playing strip challenge games with you if you weren’t!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:134
translate chinese after_choice_sis_nerdy_evening_scene31r_c8382607:

    # Sara "I... I guess..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:135
translate chinese after_choice_sis_nerdy_evening_scene31r_3fb43207:

    # MC "Anyway, I’ll let you get dressed again. See you later, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:136
translate chinese after_choice_sis_nerdy_evening_scene31r_3f5c0f9a:

    # MC "And for the record, you are very pretty."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:137
translate chinese after_choice_sis_nerdy_evening_scene31r_0007fa15:

    # Sara "Th... Thank you..."
    Sara ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:48
    old "Sneak a peek while she is taking her top off."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_win_v1.rpy:48
    old "Be nice and let Sara undress without peeking."
    new ""

