﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:17
translate chinese CR2_AS1_rep_a33a94ea:

    # MC "Sooo, I’ve helped you out quite a bit with your photos."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:18
translate chinese CR2_AS1_rep_ee9f0a03:

    # Caroline "Uh huh, you sure have."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:19
translate chinese CR2_AS1_rep_448dbf1f:

    # MC "Do you remember our deal?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:20
translate chinese CR2_AS1_rep_84e7fa3b:

    # Caroline "Of course I do."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:21
translate chinese CR2_AS1_rep_1ac1b214:

    # MC "Well, I was looking at your outfit, and I thought, it would be REALLY fun to fuck your tits."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:25
translate chinese CR2_AS1_rep_5dc3f488:

    # Caroline "My tits?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:26
translate chinese CR2_AS1_rep_57864ea4:

    # Caroline "I guess they do appear, rather provocative, in this tight top."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:27
translate chinese CR2_AS1_rep_7fc2e9bf:

    # MC "So, can you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:28
translate chinese CR2_AS1_rep_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:33
translate chinese CR2_AS1_rep_ce58a5f3:

    # Caroline "Yeah, why not!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:35
translate chinese CR2_AS1_rep_ce8a7cbd:

    # MC "Awesome! Thanks, sis! You’re the best!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:36
translate chinese CR2_AS1_rep_1334e8d3:

    # Caroline "Maybe don’t call me “sis” when we’re doing stuff like this..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:38
translate chinese CR2_AS1_rep_86adc474:

    # MC "Awesome! Thanks Caroline, you’re the best friend a guy could ask for!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:39
translate chinese CR2_AS1_rep_685835ed:

    # Caroline "Maybe don’t call me “friend” when we’re doing stuff like this..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:41
translate chinese CR2_AS1_rep_d22a98ff:

    # Caroline "Kinda makes things a little awkward, y’know?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:42
translate chinese CR2_AS1_rep_1efb7b48:

    # MC "Heh. My bad."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:43
translate chinese CR2_AS1_rep_8d70f86e:

    # Caroline "Lie back on the couch and take your pants off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:47
translate chinese CR2_AS1_rep_146c315b:

    # Caroline "Oh, you’re already hard!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:48
translate chinese CR2_AS1_rep_52c40edf:

    # Caroline "I guess that shouldn’t really be a surprise though, if experience is anything to go by."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:49
translate chinese CR2_AS1_rep_ee7bd273:

    # MC "How could I not be hard, looking at you in an outfit like that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:53
translate chinese CR2_AS1_rep_c04bfd4c:

    # Caroline "You’re a real charmer. Let’s get your little guy tucked in here."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:54
translate chinese CR2_AS1_rep_f4ae03ff:

    # Caroline "How’s that? Comfortable?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:55
translate chinese CR2_AS1_rep_3784a103:

    # MC "Oh yeah, it feels great!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:59
translate chinese CR2_AS1_rep_bf0c2fb7:

    # Caroline "And.... here we go!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:60
translate chinese CR2_AS1_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:62
translate chinese CR2_AS1_rep_db2173b8:

    # Caroline "You enjoy that? Does it feel good?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:68
translate chinese CR2_AS1_rep_c71e172e:

    # Caroline "Do you like it when your big sister uses her big titties on your big cock?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:69
translate chinese CR2_AS1_rep_03b6f042:

    # MC "(I thought she told me not to call her sister! Women are weird!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:71
translate chinese CR2_AS1_rep_656d23f2:

    # Caroline "Do you like it when your “friend” uses her big titties on your fat cock?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:72
translate chinese CR2_AS1_rep_b2842ffa:

    # MC "(I thought she told me not to call her “friend” anymore! Women are weird!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:73
translate chinese CR2_AS1_rep_d0fa14c9:

    # MC "Yeah, it’s amazing! Ooh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:77
translate chinese CR2_AS1_rep_6f19433a:

    # Caroline "Well? Do you feel like you’re being adequately rewarded for your services?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:78
translate chinese CR2_AS1_rep_079eed2c:

    # MC "This is ugh... so much better than money! Ahh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:79
translate chinese CR2_AS1_rep_d465f805:

    # Caroline "For an eighteen age guy, I'm sure it is!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:83
translate chinese CR2_AS1_rep_bf05fb10:

    # Caroline "Let’s do a few more REALLY deep plunges between my breasts."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:84
translate chinese CR2_AS1_rep_c5384a32:

    # MC "I’d love that, Caroline. Mmm... don’t stop."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:85
translate chinese CR2_AS1_rep_cc1a5a2d:

    # Caroline "Don’t worry, I’m not gonna stop, till you cum."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:89
translate chinese CR2_AS1_rep_8431aa75:

    # MC "Ooh, right there. Your tits are amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:91
translate chinese CR2_AS1_rep_4a0a21f1:

    # Caroline "Are you gonna cum soon?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:92
translate chinese CR2_AS1_rep_e15546d2:

    # MC "Y-Yeah, I am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:96
translate chinese CR2_AS1_rep_187031ae:

    # Caroline "Guess I better angle myself, then - I can’t have you squirting your cum over my merchandise!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:97
translate chinese CR2_AS1_rep_ecb6d641:

    # MC "Why don’t you want me cumming on your tits?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:98
translate chinese CR2_AS1_rep_f2a8d070:

    # Caroline "I’m not talking about my tits! I have to sell this outfit to somebody!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:99
translate chinese CR2_AS1_rep_45d11c98:

    # MC "Ooh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:103
translate chinese CR2_AS1_rep_059b2b2f:

    # MC "Fuck! I’m about to cum! Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:104
translate chinese CR2_AS1_rep_9f9ff80a:

    # Caroline "That’s it. I can feel your cock pulsing between my breasts. Cum for me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:105
translate chinese CR2_AS1_rep_8363be66:

    # Caroline "Cum for your best friend- Cum for me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:106
translate chinese CR2_AS1_rep_4934c7dd:

    # MC "Hnnnnngggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:115
translate chinese CR2_AS1_rep_d7b62e55:

    # MC "Oh Gooooddd! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:116
translate chinese CR2_AS1_rep_0d136177:

    # Caroline "Wow! That’s a LOT of cum! You mustn’t have had much fun in a few days!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:117
translate chinese CR2_AS1_rep_241a88d5:

    # MC "*Phew...* Thank you, Caroline, that was amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:121
translate chinese CR2_AS1_rep_49d5b0b7:

    # Caroline "Don’t think anything of it. Just keep helping me, build my online portfolio, and I’ll keep helping you get off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:122
translate chinese CR2_AS1_rep_dfb15c9d:

    # Caroline "We’ve got a deal, right?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:123
translate chinese CR2_AS1_rep_28d6b1fd:

    # MC "Yeah... *Phew...*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS1_rep.rpy:124
translate chinese CR2_AS1_rep_0868ca75:

    # Caroline "I’ll leave you alone now, to catch your breath."
    Caroline ""

