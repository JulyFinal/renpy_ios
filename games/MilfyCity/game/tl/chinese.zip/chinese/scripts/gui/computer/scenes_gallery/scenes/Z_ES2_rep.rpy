﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:13
translate chinese Z_ES2_rep_bf13bc86:

    # MC "Well, I did exactly what you asked for. I got you the company name."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:14
translate chinese Z_ES2_rep_85f6f72c:

    # Zuri "And you did excellently. We have already begun buying up shares, in order to assume a voting majority within the company."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:15
translate chinese Z_ES2_rep_17d91eb8:

    # Suri "And we couldn’t have done it without your help."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:16
translate chinese Z_ES2_rep_26569d30:

    # MC "Well... What’s the reward you have in mind?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:17
translate chinese Z_ES2_rep_b0b7253e:

    # Zuri "Follow me. "
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:25
translate chinese Z_ES2_rep_23e120ea:

    # Zuri "Suri is all yours tonight, [player_name]. Go ahead and play with her breasts."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:27
translate chinese Z_ES2_rep_68d8b31b:

    # Suri "You can do whatever you want with my tits, [player_name]."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:28
translate chinese Z_ES2_rep_5f5f47a3:

    # MC "(This is gonna be awesome!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:33
translate chinese Z_ES2_rep_d58c6326:

    # Suri "So, what do you think, kid?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:35
translate chinese Z_ES2_rep_2c3f979b:

    # Suri "So, what do you think, pal?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:36
translate chinese Z_ES2_rep_c2a329e4:

    # MC "They’re amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:37
translate chinese Z_ES2_rep_efa951b6:

    # Suri "Hehe... I thought so."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:41
translate chinese Z_ES2_rep_fafeb22f:

    # Suri "You want to play with them, don’t you?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:42
translate chinese Z_ES2_rep_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:43
translate chinese Z_ES2_rep_10b8d1ea:

    # Suri "They’re all yours. And there will be, much much more to come, if you give us more names."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:47
translate chinese Z_ES2_rep_905acadb:

    # Suri "Now, let’s get started with your reward."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:48
translate chinese Z_ES2_rep_e0fd6ce1:

    # Suri "Try to relax - don’t be shy."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:49
translate chinese Z_ES2_rep_cfdf7417:

    # MC "(God! I wish I could fuck both of them at the same time! That would be the hottest thing ever!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:53
translate chinese Z_ES2_rep_1365e2d5:

    # Suri "Ooh, I can feel your hard cock through your jeans. It seems like someone is getting excited by this!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:54
translate chinese Z_ES2_rep_9f82186b:

    # MC "It’s hard not to get excited, when I’ve got a sexy girl like you on my lap."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:55
translate chinese Z_ES2_rep_3e34699b:

    # Suri "Hehe! Okay, so what do you want to do to my titties?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:59
translate chinese Z_ES2_rep_a2382cf5:

    # MC "I can do anything?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:61
translate chinese Z_ES2_rep_b8703291:

    # Suri "Anything you want, kid."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:63
translate chinese Z_ES2_rep_62689eff:

    # Suri "Anything you want, pal."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:64
translate chinese Z_ES2_rep_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:77
translate chinese Zv2_ES2_menu_rep_7621447b:

    # MC "(I think I’ll start by pinching and squeezing her nipples a bit.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:78
translate chinese Zv2_ES2_menu_rep_a60ce5c2:

    # Suri "Mmm, you naughty boy."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:79
translate chinese Zv2_ES2_menu_rep_b1c9d332:

    # Suri "Do you like teasing my nipples like that?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:83
translate chinese Zv2_ES2_menu_rep_0edf117d:

    # Suri "Oooh! That’s good...."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:85
translate chinese Zv2_ES2_menu_rep_25d59f8f:

    # Zuri "My sister LOVES having her nipples played with. She can turn into a real slut if a guy turns her on enough."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:86
translate chinese Zv2_ES2_menu_rep_37efe3c9:

    # Suri "Ignore her, kid. She’s just trying to embarrass me."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:88
translate chinese Zv2_ES2_menu_rep_535b1bef:

    # Zuri "My partner LOVES having her nipples played with. She can turn into a real slut if a guy turns her on enough."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:89
translate chinese Zv2_ES2_menu_rep_76f1aaee:

    # Suri "Ignore her, pal. She’s just trying to embarrass me."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:99
translate chinese Zv2_ES2_menu_rep_b7b33907:

    # MC "(Let’s grope and squeeze Suri’s breasts!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:100
translate chinese Zv2_ES2_menu_rep_b13b9b72:

    # MC "These are really soft, Suri!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:101
translate chinese Zv2_ES2_menu_rep_c5ba390e:

    # Suri "Hehe. I know. Zuri likes to use them as a pillow, some nights."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:102
translate chinese Zv2_ES2_menu_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:106
translate chinese Zv2_ES2_menu_rep_ae2011fc:

    # Zuri "SURI! That’s supposed to be a secret!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:107
translate chinese Zv2_ES2_menu_rep_f3c848b7:

    # Suri "Oh, come on. You’ve done MUCH more to me than simply using my breasts as a pillow."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:108
translate chinese Zv2_ES2_menu_rep_3a470961:

    # Zuri "*Sigh* That’s very true."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:109
translate chinese Zv2_ES2_menu_rep_92951942:

    # MC "(These girls are total nymphos!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:119
translate chinese Zv2_ES2_menu_rep_35fc745c:

    # MC "(Okay, let’s see how she likes it when I suck on her nipples.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:120
translate chinese Zv2_ES2_menu_rep_f33aedd6:

    # Suri "Ooooh! Hehe! That really tickles!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:121
translate chinese Zv2_ES2_menu_rep_f600c631:

    # Zuri "Don’t be afraid to bite a little with your teeth. She’s kinky like that!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:122
translate chinese Zv2_ES2_menu_rep_30bad7ed:

    # Suri "Zuri! Stop it! Hehe!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:126
translate chinese Zv2_ES2_menu_rep_faad3775:

    # Suri "Oooh! Ahhh! Oh, my God! Mmm!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:127
translate chinese Zv2_ES2_menu_rep_c9fc2b71:

    # MC "*Suck suck!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:128
translate chinese Zv2_ES2_menu_rep_5ca78cfc:

    # Suri "Ooohhh...."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:138
translate chinese Zv2_ES2_continue_rep_9631c2b0:

    # Zuri "(The fuck is she doing...?)"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:139
translate chinese Zv2_ES2_continue_rep_85501078:

    # Zuri "Oh, come on, Suri. You’re not seducing him at all!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:140
translate chinese Zv2_ES2_continue_rep_f6050b5b:

    # Suri "I’m trying, Zuri!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:142
translate chinese Zv2_ES2_continue_rep_6701f971:

    # Zuri "Please, you’re acting like a mom with her child! Let me help."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:144
translate chinese Zv2_ES2_continue_rep_443a4ab3:

    # Zuri "Please... Your technique is pathetic! Let me help. "
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:148
translate chinese Zv2_ES2_continue_rep_69cebba7:

    # Suri "Hey! I had this!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:149
translate chinese Zv2_ES2_continue_rep_3c311a4d:

    # Zuri "SURE you did - I’m just here to give you a hand."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:150
translate chinese Zv2_ES2_continue_rep_25372ed4:

    # Suri "Ugh! Fine..."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:154
translate chinese Zv2_ES2_continue_rep_7c262d04:

    # Zuri "I was able to get us the first name. If we work together, I’m sure we can convince [player_name] to give us some more."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:155
translate chinese Zv2_ES2_continue_rep_596e0704:

    # Suri "Ahh... yes!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:159
translate chinese Zv2_ES2_continue_rep_776dae75:

    # Suri "So, what do you say, kid?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:161
translate chinese Zv2_ES2_continue_rep_d4f6ff7e:

    # Suri "So, what do you say, pal?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:162
translate chinese Zv2_ES2_continue_rep_e25f74ae:

    # Suri "Next time you get us a company name, you’ll get to enjoy both of us at the same time. How does that sound?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:163
translate chinese Zv2_ES2_continue_rep_7fb0b22f:

    # MC "Fucking amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:164
translate chinese Zv2_ES2_continue_rep_c9ef3e60:

    # Zuri "I thought so too."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:168
translate chinese Zv2_ES2_continue_rep_b7de8e81:

    # Zuri "I have to promise you - you are in for a night you will NEVER forget."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:169
translate chinese Zv2_ES2_continue_rep_638e5209:

    # Suri "All you have to do is get us that name."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:171
translate chinese Zv2_ES2_continue_rep_c333d7e9:

    # Suri "And then we’ll suck and fuck your brains out, kid."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:173
translate chinese Zv2_ES2_continue_rep_d42084a7:

    # Suri "And then we’ll suck and fuck your brains out, pal."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:177
translate chinese Zv2_ES2_continue_rep_9e753d86:

    # Zuri "Do we have a deal?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:178
translate chinese Zv2_ES2_continue_rep_0600e471:

    # MC "(God... They’re irresistible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:179
translate chinese Zv2_ES2_continue_rep_d400b2f8:

    # MC "Hell yeah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES2_rep.rpy:180
translate chinese Zv2_ES2_continue_rep_ef6f07f6:

    # Zuri "That’s what we like to hear!"
    Zuri ""

