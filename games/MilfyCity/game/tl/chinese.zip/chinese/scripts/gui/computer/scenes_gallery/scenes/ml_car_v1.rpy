﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:8
translate chinese mom_car_v1_65070606:

    # MC "(I think Mom’s changing now. If I’m quick I might be able to sneak a peek!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:10
translate chinese mom_car_v1_ff1f9210:

    # MC "(I think Linda’s changing now. If I’m quick I might be able to sneak a peek!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:12
translate chinese mom_car_v1_c9001286:

    # MC "(Perfect timing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:13
translate chinese mom_car_v1_0bfa772c:

    # MC "(Damn! She’s got an incredible ass. And she looks so sexy in those black high heels.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:16
translate chinese mom_car_v1_510fdae1:

    # MC "(No! She’s walking out of sight!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:17
translate chinese mom_car_v1_6a107e0d:

    # MC "(I’m gonna have to creep in further, or I’ll miss it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:18
translate chinese mom_car_v1_c798eec2:

    # MC "(Wait... Should I go for it? Lately, because of her peculiar behavior, she's starting to seem more sexually attractive to me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:20
translate chinese mom_car_v1_7dc12eea:

    # MC "(Aww - looks like she’s putting her panties back on.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:21
translate chinese mom_car_v1_d488aeb5:

    # MC "(I was hoping I’d catch a glimpse of her pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:24
translate chinese mom_car_v1_5e056924:

    # MC "(This isn’t bad though! I could fap to the mental image of her ass for a week!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:25
translate chinese mom_car_v1_85d4b001:

    # MC "(I probably shouldn’t hang around much longer. She’s almost finished dressing.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:28
translate chinese mom_car_v1_f831dc9e:

    # MC "(She’s so stunningly beautiful though.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:29
translate chinese mom_car_v1_87c16ea5:

    # MC "(Looks like she’s grabbing a dress from her closet.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:32
translate chinese mom_car_v1_8ce5545a:

    # MC "(Okay, that’s her almost finished getting dressed - I better bolt before she notices I’ve been peeping at her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:35
translate chinese mom_car_v1_d2272221:

    # MC "(Actually - instead of leaving, I could take this chance to talk with Mom about getting a job.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:36
translate chinese mom_car_v1_9fc53ae5:

    # MC "Hey, Mom!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:38
translate chinese mom_car_v1_b1455a0a:

    # MC "(Actually - instead of leaving, I could take this chance to talk with Linda about getting a job.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:39
translate chinese mom_car_v1_176421a1:

    # MC "Hey, Linda!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:43
translate chinese mom_car_v1_2d19fceb:

    # Mom "Hi, Sweetie. I didn’t I didn’t see you there. What’s up?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:45
translate chinese mom_car_v1_ab950672:

    # MC "I had been talking with Dad, and he thought it would be a good idea for me to start earning money now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:47
translate chinese mom_car_v1_eb052d4e:

    # MC "I had been talking with Landlord and he thought it would be a good idea for me to start earning money now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:48
translate chinese mom_car_v1_2b735a83:

    # MC "He said you might have some work for me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:51
translate chinese mom_car_v1_ced9bb08:

    # Mom "Hmm... I’m not sure. I can’t think of any work I need done right now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:52
translate chinese mom_car_v1_6e484a1a:

    # MC "How about in your office building?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:53
translate chinese mom_car_v1_1f38ceef:

    # Mom "I’m not sure."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:55
translate chinese mom_car_v1_f14179b1:

    # MC "Please, Mom! I really need the money. I can’t just keep begging Dad for spare change!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:57
translate chinese mom_car_v1_de447367:

    # MC "Please, Linda! I'm really in need of some extra money. I know your husband is a good person, but I shouldn't just keep asking him for pocket change!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:60
translate chinese mom_car_v1_0012b5b8:

    # Mom "Well... Maybe."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:61
translate chinese mom_car_v1_e89b55ee:

    # Mom "There’s a small possibility that I could give you a job."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:62
translate chinese mom_car_v1_d752b8d1:

    # Mom "It comes with a condition though."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:65
translate chinese mom_car_v1_fa4a1823:

    # MC "Awesome! What’s the condition?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:66
translate chinese mom_car_v1_6bf339b2:

    # Mom "I’ll tell you later. In the meantime, just follow me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:67
translate chinese mom_car_v1_c28b2c00:

    # MC "Great!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:74
translate chinese mom_car_v1_1249263a:

    # MC "Where are we going, Mom?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:76
translate chinese mom_car_v1_10a37034:

    # MC "Where are we going, Linda?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:77
translate chinese mom_car_v1_7098a76a:

    # Mom "Just one more turn and then we’ll be there. "
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:78
translate chinese mom_car_v1_a3e90852:

    # Mom "This is one of the car parks, near where I work."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:79
translate chinese mom_car_v1_0526541d:

    # MC "Oh, right."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:82
translate chinese mom_car_v1_ee7a954d:

    # MC "It looks pretty desolate."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:83
translate chinese mom_car_v1_3603b0e6:

    # Mom "Yeah - nobody ever comes into here apart from me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:84
translate chinese mom_car_v1_60388d7d:

    # Mom "(And having no people around, is essential for what I’m about to try next.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:87
translate chinese mom_car_v1_a661f156:

    # MC "So? What’s this condition?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:88
translate chinese mom_car_v1_41790746:

    # Mom "Just wait a minute. I need to plan it first."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:89
translate chinese mom_car_v1_0ea7ba75:

    # Mom "(Okay, you can do this. You’ve rehearsed it in your mind a hundred times!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:93
translate chinese mom_car_v1_35846984:

    # MC "Is everything okay, Mom? You’re looking a little nervous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:95
translate chinese mom_car_v1_c5a90a02:

    # MC "Is everything okay, Linda? You’re looking a little nervous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:96
translate chinese mom_car_v1_c1797313:

    # Mom "I’m fine. Okay, here’s what’s going to happen."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:99
translate chinese mom_car_v1_7eb1a280:

    # Mom "The condition is, that you sit completely still for one full minute. Close your eyes and act like a doll."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:100
translate chinese mom_car_v1_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:101
translate chinese mom_car_v1_b372f2f3:

    # Mom "You aren’t allowed to react. And you aren’t allowed to talk about it later on."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:111
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_36a1542e:

    # MC "Why? I don’t understand why I’d have to do this to get a job."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:112
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_6e9ecb6d:

    # Mom "I’m not asking you to understand - it’s simply the condition I’ve laid out."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:121
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_2cb8b061:

    # MC "What happens if I open my eyes or move?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:123
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_45772fcc:

    # Mom "Then the condition is forfeit, and you won’t get the job."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:124
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_13a21dc9:

    # MC "Alright..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:133
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_29445b45:

    # MC "What if I have questions after the minute is up?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:135
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_0aef79b6:

    # Mom "You’ll just have to contain your curiosity - because if you ask me ANY questions about what happens, you won’t be getting that job."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:137
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_1cf32e45:

    # MC "(Gee... Mom’s pretty serious about this.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:139
translate chinese ml_bedroom_morning_scene5_v1_label2_menu1r_ae172ab9:

    # MC "(Gee... Linda’s pretty serious about this.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:150
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_fd4320d4:

    # MC "Okay - that’s me ready."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:151
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_5940c34c:

    # Mom "The minute starts now. Remember, no talking, moving, or asking questions after."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:154
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_41842b5d:

    # MC "(One... Two... Three...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:155
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_866e5e7d:

    # MC "(She’s just put her hand on my shoulder. Nothing too strange yet...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:156
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_fadcc304:

    # MC "(Seven... Eight... Nine...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:159
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_ed156946:

    # Mom "(God... He’s so handsome. Not like Bob...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:160
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_2f69c360:

    # Mom "(I have to kiss him. This could be my only chance.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:162
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_76fc9c58:

    # Mom "(I hope he doesn’t say anything to his father about this.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:164
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_3417f9d4:

    # Mom "(I hope he doesn’t say anything to Landlord about this.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:167
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_738a41cb:

    # Mom "(Here we go... Now or never!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:168
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_c7f81aa5:

    # MC "(Thirteen... Fourteen... Fifteen...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:169
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_62649637:

    # MC "(What’s she doing?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:172
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_16abe6fa:

    # MC "(OH MY GOD!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:175
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_98631e66:

    # MC "(Mom’s full-on making out with me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:177
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_a0ca595c:

    # MC "(Linda’s full-on making out with me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:178
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_726cb244:

    # MC "(I can feel her tongue in my mouth, and everything!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:181
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_a16aba57:

    # MC "(I... I’ve lost count. Was I on twenty or thirty?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:183
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_0eaa2daa:

    # Mom "(Why did I only say a minute? I could have said two or three...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:184
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_50388008:

    # Mom "(I wish this moment would last forever. It’s like a dream come true, right now.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:188
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_1c3c5565:

    # Mom "(If I think about this when his father fucks tonight, I might even climax, for a change.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:190
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_eb5733bf:

    # Mom "(If I think about this when Bob fucks tonight, I might even climax, for a change.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:191
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_c457ac27:

    # Mom "(I have to contain myself... but right now, I could just rip [player_name]’s clothes off and ride him in the car seat.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:194
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_7a44925c:

    # Mom "(I have to know if he’s hard. I have to know if he’s enjoying this as much as I am...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:195
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_f36f1f05:

    # Mom "(I’ll just move my hand down quickly, then take it away.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:198
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_8ae24b57:

    # Mom "(He’s hard! There’s no question about it.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:199
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_2b7aa98d:

    # Mom "(It also feels like he’s got a pretty sizeable member.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:200
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_0d4f7622:

    # Mom "(If only I could feel it, hard and throbbing, deep inside my pussy!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:201
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_ef6b677c:

    # MC "(Holy shit! Did she just grab my crotch? Is she planning to betray Bob with me? Does she have feelings for me, or is she playing some sort of game?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:205
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_40f28d71:

    # Mom "O-Okay, that’s a minute up now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:206
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_a163313b:

    # Mom "(Wow... That was... something else.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:207
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_73ec652c:

    # MC "C-Can I talk now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:208
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_2768e4fe:

    # Mom "Yes, but you can’t speak about what happened."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:211
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_6d09eecd:

    # MC "Oh... O-Okay... (Fuck! I have so many questions!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:213
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_a8702841:

    # MC "(Why would she do that? I don’t understand it... She’s my mother.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:215
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_15384f02:

    # MC "(Why would she do that? I don't understand it... Is Bob not enough for her? Couldn't she have just asked me?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:216
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_00c2dab9:

    # MC "(I mean... Maybe she has some weird fetish... Or she has a crush on me? N-No! She's married! I should not have such thoughts.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:218
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_2a501319:

    # MC "(If Ms. Celia didn’t want to date me, how could my own mom be interested?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:220
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_f3339e94:

    # MC "(I mean... if Ms. Celia didn't want to date me, how could she even be interested in me? Maybe she made a bet with Liza or something?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:221
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_bc6d6f0a:

    # MC "(Perhaps it's just Celia who feels this way? Other mature women might be interested in me! If I recall correctly, we have an attractive neighbor living close by. Maybe I should consider approaching her as well?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:223
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_5191f149:

    # Mom "Ahem... I work in the building, just round the front of this carpark."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:224
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_551145f9:

    # Mom "If you drop by tomorrow afternoon, I’ll set you up with a job."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:226
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_393174ee:

    # MC "Th-Thanks, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:228
translate chinese ml_bedroom_morning_scene5_v1_label2_menu_after1r_e9aea860:

    # MC "Th-Thanks, Linda."
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:108
    old "Why? I don’t understand."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:108
    old "What if I open my eyes or move? "
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_car_v1.rpy:108
    old "What if I have questions after the minute is up?"
    new ""

