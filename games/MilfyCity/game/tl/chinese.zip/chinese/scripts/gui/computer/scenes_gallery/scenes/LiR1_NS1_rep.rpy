﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:16
translate chinese LiR1_NS1_rep_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:17
translate chinese LiR1_NS1_rep_ce2b79b5:

    # MC "(Looks like it’s my lucky day! I arrived just before they were about to start!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:18
translate chinese LiR1_NS1_rep_563fcc20:

    # MC "(Yazmin is certainly dressed for the occasion. She might have smaller breasts than [Liza_name], but she’s certainly making up for it downstairs tonight!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:22
translate chinese LiR1_NS1_rep_77951ae8:

    # MC "(I wonder what they’re talking about... if I lean in closer, I might be able to hear some of their conversation.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:23
translate chinese LiR1_NS1_rep_3516bf44:

    # Liza "...it’s not the first time you’ve wanted to use that strap-on."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:24
translate chinese LiR1_NS1_rep_62563515:

    # Liza "I’m not saying I want you to take it off... I just... don’t swing that way. Phallic shapes really don't do anything for me."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:28
translate chinese LiR1_NS1_rep_84e542be:

    # Yazmin "Oh c’mon! You must enjoy it - even just a little bit!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:29
translate chinese LiR1_NS1_rep_6babe21d:

    # Yazmin "I’ve heard how loudly you moan, when I fuck you with - this bad boy."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:30
translate chinese LiR1_NS1_rep_0a963ea0:

    # Liza "Yeah, well... it’s not as enjoyable as the times when you use your fingers... or even your tongue."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:34
translate chinese LiR1_NS1_rep_0c5c22c7:

    # Yazmin "That’s alright. I understand. Can we try using it tonight, though? It took me nearly five full minutes to get all these buckles on."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:35
translate chinese LiR1_NS1_rep_6aafd016:

    # Liza "*Sigh* Okay, we can use it tonight. You owe me another romantic dinner though, okay?"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:36
translate chinese LiR1_NS1_rep_35687b2b:

    # Yazmin "We’ll go wherever you want, Liza."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:40
translate chinese LiR1_NS1_rep_3bb14fef:

    # Liza "I assume you want me to do the ‘blowjob fantasy’ for you again."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:41
translate chinese LiR1_NS1_rep_4bde68b3:

    # Yazmin "You know me too well, Honey."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:42
translate chinese LiR1_NS1_rep_c9e20cf7:

    # Liza "*Sigh* I don’t understand what you get out of this. You can’t feel anything when I’m sucking on that pink plastic."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:46
translate chinese LiR1_NS1_rep_13679ab1:

    # Yazmin "There’s more to sex, than the physical pleasure. Simply watching you, suck on this strap-on, is intensely erotic."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:47
translate chinese LiR1_NS1_rep_dbab896a:

    # Liza "Alright, let’s get this over with."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:48
translate chinese LiR1_NS1_rep_4e22a453:

    # Yazmin "Can you at least pretend to enjoy it?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:53
translate chinese LiR1_NS1_rep_acc7ae53:

    # MC "(Huh, it looks like [Liza_name] is a complete lesbian. Yazmin, on the other hand, seems to be much more open to both men AND women.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:54
translate chinese LiR1_NS1_rep_c8c7b6f7:

    # Liza "*Suck Suck*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:55
translate chinese LiR1_NS1_rep_008f8e94:

    # Yazmin "Mmm... that’s more like it."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:59
translate chinese LiR1_NS1_rep_fe44febc:

    # Yazmin "I’ve seen you suck it before - I know you can take it deeper than that."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:60
translate chinese LiR1_NS1_rep_4e627b54:

    # Liza "*Shluuurrrp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:61
translate chinese LiR1_NS1_rep_9109f7e7:

    # MC "(Wow! This is so fucking hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:65
translate chinese LiR1_NS1_rep_ef330fe5:

    # Yazmin "Make sure you take it nice and deep. Get it all soaking wet with your saliva."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:66
translate chinese LiR1_NS1_rep_14c8bfb2:

    # Liza "*Shlllurrrrrp*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:67
translate chinese LiR1_NS1_rep_3220c83a:

    # Yazmin "Do you know what I’m gonna do next? I’m gonna lie you back on the bed and - screw you silly."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:71
translate chinese LiR1_NS1_rep_d01ae1fc:

    # Liza "I don’t know if I’m wet enough yet... It’s just, I don’t get as horny around cocks."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:72
translate chinese LiR1_NS1_rep_d222c6a0:

    # Yazmin "Yeah, I know. That’s what the saliva is for! Now c’mere, and let me kiss you."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:76
translate chinese LiR1_NS1_rep_4230de03:

    # Yazmin "I love you, Honey. You know that?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:77
translate chinese LiR1_NS1_rep_4dd0aba8:

    # Liza "Yeah, I know."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:78
translate chinese LiR1_NS1_rep_58451288:

    # Yazmin "Thanks for putting up with my - silly little fantasies. It’s the perfect ending to a day, for me."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:82
translate chinese LiR1_NS1_rep_6355ec54:

    # Liza "I’m glad I can make you happy like that."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:83
translate chinese LiR1_NS1_rep_32064ff1:

    # Liza "Sorry I’m not super excited about this kinda stuff..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:84
translate chinese LiR1_NS1_rep_5dcd45a7:

    # Yazmin "Shush... It’s okay. You don’t need to apologise. Everyone has their own kinks. I know you like your lace tights."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:88
translate chinese LiR1_NS1_rep_fa769e0d:

    # Liza "*Mwah*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:89
translate chinese LiR1_NS1_rep_9944bb22:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:90
translate chinese LiR1_NS1_rep_c4da81bc:

    # MC "(Damn, I wish I was in Yazmin’s position right now. I would love to explore [Liza_name]’s mouth with my tongue.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:94
translate chinese LiR1_NS1_rep_2585411f:

    # Liza "Mmm!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:95
translate chinese LiR1_NS1_rep_0ac8669d:

    # Liza "(I’m beginning to get wet, now that she’s actually started making out with me!)"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:96
translate chinese LiR1_NS1_rep_5859474d:

    # Yazmin "(Okay, this has gone on long enough... Let’s get the show started!)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:100
translate chinese LiR1_NS1_rep_c23628ee:

    # Liza "Whoa!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:101
translate chinese LiR1_NS1_rep_ddb0ce00:

    # MC "(Haha! Yazmin just pushed her - back onto the bed!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:102
translate chinese LiR1_NS1_rep_874576e4:

    # Yazmin "Sorry. Was I too rough?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:106
translate chinese LiR1_NS1_rep_f0b2ed4c:

    # Liza "I- I’m fine."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:107
translate chinese LiR1_NS1_rep_7b8f59fa:

    # Yazmin "You’re still nervous about being fucked by this strap-on, aren’t you?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:108
translate chinese LiR1_NS1_rep_9371e9bb:

    # Liza "Yeah, a bit."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:112
translate chinese LiR1_NS1_rep_9df6313b:

    # Yazmin "You use dildos and vibrators all the time, by yourself. How is this any different?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:113
translate chinese LiR1_NS1_rep_33336f03:

    # Liza "It’s... how it looks, I guess. The fact that it’s on you and kinda looks like a cock..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:114
translate chinese LiR1_NS1_rep_14992b19:

    # Yazmin "Well, just lie back and try to think of it - as me fucking you with a dildo. Okay?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:118
translate chinese LiR1_NS1_rep_b4219381:

    # Liza "O-Okay... It’s just a dildo..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:119
translate chinese LiR1_NS1_rep_c62febaa:

    # Yazmin "(I’d love to be able to introduce a guy into our house, for a threesome, but Liza is one of the most frigid lesbians I’ve ever met! She freezes up, when she has to eat a banana!)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:120
translate chinese LiR1_NS1_rep_4e0a6cb5:

    # Yazmin "I’m gonna put it in now. Are you ready?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:124
translate chinese LiR1_NS1_rep_aed70dd2:

    # Liza "Oooh..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:125
translate chinese LiR1_NS1_rep_b927d710:

    # Yazmin "How does that feel?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:126
translate chinese LiR1_NS1_rep_38bda5e4:

    # Liza "Mmm... That’s good... You’re brushing against my clitoris there. That feels amazing..."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:130
translate chinese LiR1_NS1_rep_a78d6d9c:

    # Yazmin "Okay, I’m going to start pushing it in now."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:131
translate chinese LiR1_NS1_rep_12752e01:

    # Liza "Ahh... Ah...."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:133
translate chinese LiR1_NS1_rep_3d9bdd60:

    # MC "(It sounds like [Liza_name] is finally beginning to relax and enjoy the sex!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:135
translate chinese LiR1_NS1_rep_64391981:

    # MC "(It sounds like she is finally beginning to relax and enjoy it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:139
translate chinese LiR1_NS1_rep_e01446ba:

    # Yazmin "Fuck... That’s it... "
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:141
translate chinese LiR1_NS1_rep_5a502287:

    # Yazmin "(I love seeing the strap-on buried deep inside my wife’s pussy. The sight of her squirming and creaming herself over my fake plastic cock is just so hot.)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:142
translate chinese LiR1_NS1_rep_f52b2344:

    # Liza "Mmmmm! Uhhh! Ahhh!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:146
translate chinese LiR1_NS1_rep_2ff97048:

    # Liza "Ah! Ah! Ahhh!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:148
translate chinese LiR1_NS1_rep_65bc26e7:

    # MC "(She’s getting louder. It sounds like she might be about to cum soon!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:149
translate chinese LiR1_NS1_rep_68360c9c:

    # Yazmin "That’s it... Take my cock... Take it all, in your slutty pussy..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:153
translate chinese LiR1_NS1_rep_81aa7017:

    # Yazmin "You like it when I fuck you like this, don’t you?"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:154
translate chinese LiR1_NS1_rep_c5fcee1e:

    # Liza "Ah! Ohhh!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:155
translate chinese LiR1_NS1_rep_c73aad8f:

    # Yazmin "You love being pounded hard - over and over!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:156
translate chinese LiR1_NS1_rep_6324ddc1:

    # Liza "Ohhh! AHHHH! I’m gonna cuuummm!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:160
translate chinese LiR1_NS1_rep_b2baffc4:

    # Yazmin "Cum for me! Cum on my fat cock!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:161
translate chinese LiR1_NS1_rep_5cf1df78:

    # Liza "AHHHHHH!!! YEEEEEESSSSSS!!!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:164
translate chinese LiR1_NS1_rep_50b964c1:

    # MC "(Oh my God! [Liza_name]’s whole body is shaking uncontrollably! I don’t think I’ve ever seen a woman cum so hard in my life!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:166
translate chinese LiR1_NS1_rep_84c88719:

    # MC "(Oh my God! Her whole body is shaking uncontrollably! I don’t think I’ve ever seen a woman cum so hard in my life!) "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:170
translate chinese LiR1_NS1_rep_8dfc695b:

    # Liza "AHH! AHHH!!!! HNNNNGGGGG!!!!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:171
translate chinese LiR1_NS1_rep_bc5f3ef8:

    # Liza "Ughhh! Ahhh! Ohhh...."
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:172
translate chinese LiR1_NS1_rep_649d84a1:

    # Yazmin "Wow! That was a BIG one! Good girl!"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:173
translate chinese LiR1_NS1_rep_beb5e12f:

    # Liza "*Pant Pant*"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:177
translate chinese LiR1_NS1_rep_9944bb22_1:

    # Yazmin "Mmm..."
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:178
translate chinese LiR1_NS1_rep_06093a6b:

    # Yazmin "(She says she hates cocks, but she always cums the hardest when she gets fucked by a strap-on. There’s no way I could ever make her do that, with my fingers.)"
    Yazmin ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:179
translate chinese LiR1_NS1_rep_2585411f_1:

    # Liza "Mmm!"
    Liza ""

# game/scripts/gui/computer/scenes_gallery/scenes/LiR1_NS1_rep.rpy:180
translate chinese LiR1_NS1_rep_d110dbc8:

    # MC "(Okay, it looks like they’re finishing, for the night. I should probably slip away now, in case [Liza_name] opens her eyes and spots me leering at them!."
    MC ""

