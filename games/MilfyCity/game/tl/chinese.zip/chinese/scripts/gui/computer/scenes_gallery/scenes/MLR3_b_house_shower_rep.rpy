﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:17
translate chinese MLR3_b_house_shower_rep_5f3a6f6d:

    # Mom "La la la..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:19
translate chinese MLR3_b_house_shower_rep_5598f184:

    # MC "(Damn, she looks so sexy, showering there. I hope I was right, about her wanting me to join her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:20
translate chinese MLR3_b_house_shower_rep_03e3856b:

    # MC "(Well, here goes nothing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:24
translate chinese MLR3_b_house_shower_rep_a4598b09:

    # Mom "La la, oh no no no! Despacito!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:25
translate chinese MLR3_b_house_shower_rep_dc9f543f:

    # Mom "Quiero respirar tu cuello despacito!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:26
translate chinese MLR3_b_house_shower_rep_16ed6a6f:

    # MC "(I’ve no idea what she’s singing, it sounds strangely familiar though...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:30
translate chinese MLR3_b_house_shower_rep_ceb7a833:

    # MC "Hey, [Mom_name]! Sorry to keep you waiting... It took me a couple of minutes to get your hint."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:31
translate chinese MLR3_b_house_shower_rep_b0370c8f:

    # Mom "Seriously? There were, like, seven different hints I dropped."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:32
translate chinese MLR3_b_house_shower_rep_35ec42cb:

    # MC "Really?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:36
translate chinese MLR3_b_house_shower_rep_3db240bd:

    # Mom "Yeah! At least!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:37
translate chinese MLR3_b_house_shower_rep_0779f31a:

    # MC "Why couldn’t you just ask me... instead of dropping obscure suggestions?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:38
translate chinese MLR3_b_house_shower_rep_0e6dd495:

    # Mom "Because that’s not how girls work, Sweetie."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:42
translate chinese MLR3_b_house_shower_rep_210b3cfd:

    # Mom "Now, get over here. I can’t wait to play with you some more!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:43
translate chinese MLR3_b_house_shower_rep_f7795790:

    # MC "Yes, Ma’am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:44
translate chinese MLR3_b_house_shower_rep_826e7290:

    # Mom "I’ve got some good news, and some bad news."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:48
translate chinese MLR3_b_house_shower_rep_8ab16217:

    # MC "Give me the bad news first."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:49
translate chinese MLR3_b_house_shower_rep_0a3e3570:

    # Mom "I’ve already finished washing my body down."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:50
translate chinese MLR3_b_house_shower_rep_a4a81f42:

    # MC "Okay, so what’s the good news?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:54
translate chinese MLR3_b_house_shower_rep_39d6b43b:

    # Mom "I still need to clean ALL of you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:55
translate chinese MLR3_b_house_shower_rep_7ee0a54d:

    # MC "Mmm, I’m liking the sound of this!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:59
translate chinese MLR3_b_house_shower_rep_4cabba2c:

    # Mom "I want you to fuck me in the shower. Right here, right now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:60
translate chinese MLR3_b_house_shower_rep_523c449f:

    # Mom "I want to feel your thick cock, thrusting in and out of me, over and over, non-stop."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:64
translate chinese MLR3_b_house_shower_rep_64011d90:

    # MC "Your boobs are fucking incredible... God, you’re so hot, [Mom_name]!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:65
translate chinese MLR3_b_house_shower_rep_0ad4faa9:

    # Mom "We’ve still got some time, before we both have to go home and return to our real lives. Let’s make the most of these last couple of hours."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:66
translate chinese MLR3_b_house_shower_rep_f0800fdc:

    # Mom "I don’t know how long it will be before we get another chance."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:70
translate chinese MLR3_b_house_shower_rep_bd8d4e6b:

    # MC "You’re right, [Mom_name]. We have to make the most of this."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:71
translate chinese MLR3_b_house_shower_rep_cef72a43:

    # Mom "So, let’s get down to business. Fuck me, up against the wall?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:75
translate chinese MLR3_b_house_shower_rep_1e2d2f6e:

    # MC "Yeah! That sounds great!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:76
translate chinese MLR3_b_house_shower_rep_45778b2e:

    # Mom "Okay, let’s get you hard, first."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:77
translate chinese MLR3_b_house_shower_rep_cf40ad3b:

    # Mom "Thrust, back and forth, between my thighs. They’re all hot, right now, with the warm water flowing over them."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:81
translate chinese MLR3_b_house_shower_rep_642da13a:

    # MC "Mmm, I can feel that... It's so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:83
translate chinese MLR3_b_house_shower_rep_aa79f4ac:

    # Mom "Imagine yourself fucking me, up against the wall, right now - ploughing your thick cock, into my soaking wet cunt."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:84
translate chinese MLR3_b_house_shower_rep_18091983:

    # MC "God... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:88
translate chinese MLR3_b_house_shower_rep_4d2aefe4:

    # Mom "It sounds good, right?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:89
translate chinese MLR3_b_house_shower_rep_237467d5:

    # Mom "I’ve fingered myself to the thought of you fucking me in the shower, for months now. God, the thought of you just taking me from behind, is so hot."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:90
translate chinese MLR3_b_house_shower_rep_cbde6cce:

    # Mom "Sometimes I like to imagine we’re at the swimming pool showers, and I have to hold my breath, to stop myself screaming your name in pleasure."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:94
translate chinese MLR3_b_house_shower_rep_9245a8a8:

    # MC "Fuck, that’s hot..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:95
translate chinese MLR3_b_house_shower_rep_8343ef1b:

    # MC "We HAVE to go to the pool together someday, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:96
translate chinese MLR3_b_house_shower_rep_e0c9ee74:

    # Mom "Oh, trust me, it’s on my agenda."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:100
translate chinese MLR3_b_house_shower_rep_e93321c1:

    # MC "Mmm... Fuck... this is so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:102
translate chinese MLR3_b_house_shower_rep_85ad1274:

    # MC "Does this feel okay for you, [Mom_name]?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:103
translate chinese MLR3_b_house_shower_rep_9466b548:

    # Mom "It’s pretty nice... You’re rubbing up against my clitoris, with each thrust."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:107
translate chinese MLR3_b_house_shower_rep_a27a060c:

    # Mom "Of course, it’ll feel ten times better, when you’re inside me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:108
translate chinese MLR3_b_house_shower_rep_d2294149:

    # MC "I know that, from last night!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:109
translate chinese MLR3_b_house_shower_rep_b5e4c64c:

    # MC "Is it okay if I cum inside you again today?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:113
translate chinese MLR3_b_house_shower_rep_bb754f4f:

    # Mom "Of course! I INSIST on it!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:114
translate chinese MLR3_b_house_shower_rep_983e0335:

    # Mom "Now, enough foreplay. Get your cock over here, and shove it in my pussy. I’m waiting for you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:118
translate chinese MLR3_b_house_shower_rep_a2d8b0a6:

    # MC "Do you want me to get a condom or-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:119
translate chinese MLR3_b_house_shower_rep_5db56483:

    # Mom "No! No condoms - just hurry up and fuck me! I’ve been waiting FAR TOO LONG for this!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:120
translate chinese MLR3_b_house_shower_rep_1d3049e4:

    # MC "Easy! Okay, okay!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:124
translate chinese MLR3_b_house_shower_rep_a7a17729:

    # Mom "Mmm... yes! Right there! Ah..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:125
translate chinese MLR3_b_house_shower_rep_9cfe62c0:

    # MC "([Mom_name] is really loving this! I wonder why she finds my cock so appealing?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:127
translate chinese MLR3_b_house_shower_rep_43fdf247:

    # MC "(Is it the size? Or the shape? Or is it because I’m her son, and she finds it extra hot, because it’s ‘taboo?’"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:129
translate chinese MLR3_b_house_shower_rep_ef006e07:

    # MC "(Is it the size? Or the shape? Or is it because I’m so much younger than her - and she finds it extra hot because it’s a bit ‘taboo?’)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:133
translate chinese MLR3_b_house_shower_rep_97fe9965:

    # Mom "AHH! Fuck! Ohhh! It’s sooo good!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:134
translate chinese MLR3_b_house_shower_rep_257488ab:

    # MC "Ugh! Yeah, you like that, [Mom_name]?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:135
translate chinese MLR3_b_house_shower_rep_a89dbd85:

    # Mom "S-Sooo much!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:139
translate chinese MLR3_b_house_shower_rep_2579be88:

    # Mom "Ohhh! Ahh... Yesssss!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:140
translate chinese MLR3_b_house_shower_rep_9b6b5c93:

    # Mom "D-Deeper! Thrust deeper! Oh God! That’s the spot! AHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:141
translate chinese MLR3_b_house_shower_rep_fba688e9:

    # Mom "(That’s the other benefit of this beach house. With no neighbours, I can be as freaking loud as I want!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:145
translate chinese MLR3_b_house_shower_rep_1cafc134:

    # Mom "Ah! Ahh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:146
translate chinese MLR3_b_house_shower_rep_63d5bcc7:

    # MC "Ugh! Ah! Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:147
translate chinese MLR3_b_house_shower_rep_6c6befc8:

    # MC "(Her pussy is extra slippery today! I don’t know if it’s because she’s really horny, or because of the shower. Either way, it’s amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:151
translate chinese MLR3_b_house_shower_rep_e5cf855a:

    # Mom "Mmm! Holy shit..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:153
translate chinese MLR3_b_house_shower_rep_18630e10:

    # Mom "You’re soooo good with your dick. Ahh! Ahhhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:154
translate chinese MLR3_b_house_shower_rep_c1567567:

    # MC "Ah! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:158
translate chinese MLR3_b_house_shower_rep_cafef048:

    # MC "(I came on this holiday, hoping to finally have sex with [Mom_name]. I NEVER thought I’d get to fuck her, three times, in twenty four hours!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:160
translate chinese MLR3_b_house_shower_rep_73b9d90a:

    # MC "(It’s a dream come true!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:164
translate chinese MLR3_b_house_shower_rep_8ab4afdb:

    # Mom "Oh shit... Oh shit..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:165
translate chinese MLR3_b_house_shower_rep_274d29b3:

    # MC "Are you alright, [Mom_name]?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:166
translate chinese MLR3_b_house_shower_rep_f326ff28:

    # Mom "Faster! HARDER! Ahh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:170
translate chinese MLR3_b_house_shower_rep_28c67e0d:

    # Mom "HOLY SHIT! AHH! AHHHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:172
translate chinese MLR3_b_house_shower_rep_68658833:

    # Mom "I’m cumming! AHHHHHHHH!!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:176
translate chinese MLR3_b_house_shower_rep_c76610f0:

    # Mom "Ayaaaahhhhhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:177
translate chinese MLR3_b_house_shower_rep_aab56aac:

    # MC "Hnng... ugh! Ah! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:178
translate chinese MLR3_b_house_shower_rep_f68e31fe:

    # MC "(I love the way her pussy quivers, each time she cums. It makes sex feel even better!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:182
translate chinese MLR3_b_house_shower_rep_aba14bf1:

    # Mom "Ohhh! OHHHHH!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:183
translate chinese MLR3_b_house_shower_rep_7c2daf4c:

    # MC "Fuck, [Mom_name]... You feel so good! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:184
translate chinese MLR3_b_house_shower_rep_f051c57b:

    # Mom "K-Kiss me!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:188
translate chinese MLR3_b_house_shower_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:189
translate chinese MLR3_b_house_shower_rep_17ad6149:

    # Mom "MMM!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:190
translate chinese MLR3_b_house_shower_rep_cd543b9c:

    # Mom "(My mind’s melting, right now... This is the best sex I’ve EVER had, in my life!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:194
translate chinese MLR3_b_house_shower_rep_01ba785b:

    # MC "HNNNNGGGG!! MMMM!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:195
translate chinese MLR3_b_house_shower_rep_659d2001:

    # Mom "(He’s cumming again! I can feel his cock twitching inside me!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:199
translate chinese MLR3_b_house_shower_rep_32dada07:

    # Mom "(YESSS! Cum inside me! Oh God! Cum inside me!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:200
translate chinese MLR3_b_house_shower_rep_142a51ed:

    # Mom "MMMMMMM!!!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:201
translate chinese MLR3_b_house_shower_rep_6faaed46:

    # MC "Hnnnnngggg! MMMMMMM!!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:210
translate chinese MLR3_b_house_shower_rep_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:211
translate chinese MLR3_b_house_shower_rep_597a0286:

    # Mom "*Gasp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:212
translate chinese MLR3_b_house_shower_rep_db89c926:

    # Mom "W-Wow... That was... good..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:216
translate chinese MLR3_b_house_shower_rep_b3509219:

    # Mom "And the best... part about *pant* shower sex, is that you don’t need *pant* to go wash afterwards."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:217
translate chinese MLR3_b_house_shower_rep_989ec890:

    # MC "Haha *pant* very true!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:218
translate chinese MLR3_b_house_shower_rep_e57e9936:

    # MC "*Phew*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:222
translate chinese MLR3_b_house_shower_rep_b9a6c228:

    # Mom "I’ll just wash up, here. I’ll see you back in the Lounge."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:223
translate chinese MLR3_b_house_shower_rep_10662c85:

    # MC "Okay, [Mom_name]! See you there. Love you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_b_house_shower_rep.rpy:224
translate chinese MLR3_b_house_shower_rep_96948d90:

    # Mom "Love you too, Sweetie!"
    Mom ""

