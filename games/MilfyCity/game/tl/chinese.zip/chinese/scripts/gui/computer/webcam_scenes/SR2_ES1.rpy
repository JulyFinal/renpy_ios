﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:65
translate chinese SR2_ES1_label_a6e098ca:

    # Sara "Heeeeeey, [player_name]! Guess who finally got their webcam working!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:67
translate chinese SR2_ES1_label_d8dfd945:

    # MC "Hi, Sara! Does [Mom_name] know you’re using your webcam?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:68
translate chinese SR2_ES1_label_5fb79f28:

    # Sara "Absolutely not. She doesn’t even know I’m on my laptop. Hehe!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:70
translate chinese SR2_ES1_label_ffe89fb1:

    # MC "Hi, Sara! It’s nice to see you, but you know that you should be studying right now?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:71
translate chinese SR2_ES1_label_9410ef34:

    # Sara "Don't worry. I'm only taking a small break. Just for YOU! Hehe!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:72
translate chinese SR2_ES1_label_55c1cf3e:

    # MC "Haha! You naughty girl!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:76
translate chinese SR2_ES1_label_10cf3e70:

    # Sara "How are things over there, in the land of the free?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:77
translate chinese SR2_ES1_label_95c39602:

    # MC "Eh, not much. I’m just doing a bit of work and then the same old shit at college each day."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:79
translate chinese SR2_ES1_label_e612b03b:

    # Sara "At least you can go wherever you want. Mom’s got me completely grounded right now."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:81
translate chinese SR2_ES1_label_c7c0aea2:

    # Sara "At least you can go wherever you want. I have to study to improve my grades. That sucks and is boring."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:85
translate chinese SR2_ES1_label_27f0d940:

    # MC "Hopefully, our late night chats will help relieve SOME of the boredom you’re facing right now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:86
translate chinese SR2_ES1_label_96759655:

    # Sara "Mmm, I hope so too!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:88
translate chinese SR2_ES1_label_be44d15e:

    # MC "What's everything you have to do before Mom finally ungrounds you?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:90
translate chinese SR2_ES1_label_0cfac363:

    # MC "Do you still have a lot to study?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:96
translate chinese SR2_ES1_label_cb9f2f8a:

    # Sara "Aaarrrghhh...."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:97
translate chinese SR2_ES1_label_f8baa53e:

    # Sara "Do we HAVE to talk about this?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:98
translate chinese SR2_ES1_label_a28030f7:

    # MC "I just want to know how long it is until I can properly hang out with you again!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:102
translate chinese SR2_ES1_label_8a7ac494:

    # Sara "Ugh, she wants me to re-read EVERY book that I’ve studied so far in college this year."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:104
translate chinese SR2_ES1_label_22735cc3:

    # Sara "Ugh, I have to re-read EVERY book that I’ve studied so far in college this year."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:105
translate chinese SR2_ES1_label_4e0ccad8:

    # Sara "And then I have to retake all the tests I didn’t score a B or higher on."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:106
translate chinese SR2_ES1_label_2be36d58:

    # Sara "And FINALLY, I have to score an A on my next two tests."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:110
translate chinese SR2_ES1_label_ec8e85d7:

    # Sara "I mean, just look at this crap! Why do I have to study some dead guy’s poetry?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:111
translate chinese SR2_ES1_label_505a0e43:

    # Sara "He doesn’t even write in normal English! "
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:112
translate chinese SR2_ES1_label_15eec5d9:

    # Sara "‟I dare do all that may become a man. Who dares do more is none.” What the HECK does that even mean?!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:113
translate chinese SR2_ES1_label_43a4e176:

    # MC "Ugh, I remember having to study Shakespeare too. I think it was Romeo and Juliet."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:114
translate chinese SR2_ES1_label_7fce5ae9:

    # Sara "That’s so unfair! You got a super romantic story - I got stuck with Macbeth. It’s just so... boring!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:118
translate chinese SR2_ES1_label_726030ae:

    # Sara "Anyway! I’ll be able to enjoy some late night chats with my favourite brother from now on!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:120
translate chinese SR2_ES1_label_0726dd64:

    # Sara "Anyway! I’ll be able to enjoy some late night chats with my favourite person from now on!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:121
translate chinese SR2_ES1_label_8cac84ae:

    # Sara "So, at least I have something to look forward to at the end of each day!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:123
translate chinese SR2_ES1_label_4a5193ad:

    # MC "Aren’t I your only brother?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:124
translate chinese SR2_ES1_label_ba49496b:

    # Sara "You are - but even if you weren’t, you’d still be my favourite."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:127
translate chinese SR2_ES1_label_7487fea2:

    # MC "Aww, I’m your favourite? Not Lily?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:128
translate chinese SR2_ES1_label_93604322:

    # Sara "Haha, of course it’s you!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:130
translate chinese SR2_ES1_label_b0fd8dbf:

    # MC "(Aww, she really looks up to me!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:134
translate chinese SR2_ES1_label_7c298543:

    # MC "So, what are you wearing tonight?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:135
translate chinese SR2_ES1_label_256b412c:

    # Sara "Ooohh, just my pyjamas. I was going to go to bed, after our call."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:136
translate chinese SR2_ES1_label_8b498b30:

    # MC "Can I see?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:140
translate chinese SR2_ES1_label_378ea222:

    # MC "No bottoms?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:141
translate chinese SR2_ES1_label_eed159de:

    # Sara "It’s too warm for those, right now!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:142
translate chinese SR2_ES1_label_6ada9a7e:

    # MC "Step back and let me get a better look at you."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:146
translate chinese SR2_ES1_label_8e637806:

    # Sara "How’s this?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:147
translate chinese SR2_ES1_label_ad54f978:

    # MC "Perfect! Your legs are so sexy! You know that?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:148
translate chinese SR2_ES1_label_7fe10a82:

    # Sara "Hehe! Thanks!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:152
translate chinese SR2_ES1_label_aa61041d:

    # Sara "Hey! Do you want to see something amazing?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:153
translate chinese SR2_ES1_label_66c0595e:

    # MC "Sure!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:154
translate chinese SR2_ES1_label_50d0017e:

    # Sara "You have to promise not to tell anyone, okay?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:155
translate chinese SR2_ES1_label_319b02cc:

    # MC "Okay, I promise. (I wonder what she’s talking about...)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:159
translate chinese SR2_ES1_label_7b55c7fc:

    # Sara "Boo!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:160
translate chinese SR2_ES1_label_d674ddb0:

    # MC "Mmm! Very nice!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:161
translate chinese SR2_ES1_label_acc436be:

    # Sara "These panties are a little too tight on me - they show off FAR too much of my ass."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:162
translate chinese SR2_ES1_label_0fd23fdb:

    # Sara "I can’t wear them to college on sports days because the other girls would see, when we’re getting changed."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:163
translate chinese SR2_ES1_label_26c84a91:

    # MC "They’re really hot!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:167
translate chinese SR2_ES1_label_6bcb790e:

    # Sara "Haha! I'm so glad you like them, [player_name]!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:182
translate chinese SR2_ES1_menu_2f21cd96:

    # MC "You’ve turned me on now. Could you maybe go a little further and show me your bra?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:183
translate chinese SR2_ES1_menu_37536bae:

    # Sara "My bra?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:184
translate chinese SR2_ES1_menu_0dce4d46:

    # MC "Yeah, just pull your top down a bit and let me see it."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:185
translate chinese SR2_ES1_menu_0dcabdbc:

    # Sara "We’ve got a problem, [player_name]... I can’t do that..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:189
translate chinese SR2_ES1_menu_99bed3a1:

    # Sara "I’m not actually wearing a bra."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:190
translate chinese SR2_ES1_menu_ecb5f498:

    # MC "(Holy shit! Her tits are awesome!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:191
translate chinese SR2_ES1_menu_3dbf3b79:

    # Sara "Sorry, most girls don’t wear a bra to bed."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:195
translate chinese SR2_ES1_menu_244fda36:

    # Sara "I’ll even pull down the other side of my shirt to prove it."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:196
translate chinese SR2_ES1_menu_6e5a374b:

    # MC "Yeah, you should do that!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:198
translate chinese SR2_ES1_menu_7c6ae11f:

    # MC "(There’s nothing better than having your sister flash her tits on camera for you!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:200
translate chinese SR2_ES1_menu_fbf51594:

    # MC "(There’s nothing better than having a girl flash her tits on camera for you!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:204
translate chinese SR2_ES1_menu_c082284d:

    # Sara "See, [player_name]? No bra."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:205
translate chinese SR2_ES1_menu_28fc7b7d:

    # MC "Your boobs are gorgeous, Sara. I’d love to suck on your nipples right now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:206
translate chinese SR2_ES1_menu_6daf432f:

    # MC "Do you think you could lift the camera up a bit so I can get a better view?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:210
translate chinese SR2_ES1_menu_e475b002:

    # Sara "Sure, [player_name]. I’ll do that now."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:211
translate chinese SR2_ES1_menu_007ae070:

    # Sara "I’m really glad you like them. I was a bit worried that they were too small."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:212
translate chinese SR2_ES1_menu_6b729a8a:

    # MC "No, they’re absolutely perfect."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:216
translate chinese SR2_ES1_menu_8e637806:

    # Sara "How’s this?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:217
translate chinese SR2_ES1_menu_bbfb0586:

    # MC "That’s brilliant. God, they’re so perky!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:218
translate chinese SR2_ES1_menu_48e4449c:

    # MC "You’d look so hot in a tiny bikini. Maybe I can get you to wear one to the pool sometime?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:219
translate chinese SR2_ES1_menu_f1b0b4d7:

    # Sara "Hehe... We’ll see. I’m not gonna make any promises though!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:229
translate chinese SR2_ES1_menu_ba4ec444:

    # MC "Damn, you’re so fucking sexy, Sara."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:230
translate chinese SR2_ES1_menu_204c1303:

    # Sara "Hehe... Thanks."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:231
translate chinese SR2_ES1_menu_a040e8c0:

    # MC "Seriously, I’m rocking the biggest boner right now. Do you think you could maybe show me a little more skin?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:232
translate chinese SR2_ES1_menu_fa51aa70:

    # Sara "A little more skin? What are you thinking of?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:233
translate chinese SR2_ES1_menu_e5ec66b7:

    # MC "How about you flash me your panties?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:237
translate chinese SR2_ES1_menu_0464b0e1:

    # Sara "Sure. Two seconds - I just need to adjust my webcam."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:238
translate chinese SR2_ES1_menu_029500f8:

    # MC "Take your time."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:239
translate chinese SR2_ES1_menu_24ffa1d3:

    # MC "(This is gonna be great!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:243
translate chinese SR2_ES1_menu_6eb45787:

    # Sara "Can you see me okay from this angle?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:244
translate chinese SR2_ES1_menu_3517699a:

    # MC "Yeah, that’s perfect, Sara. Go ahead and lift your dress up."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:245
translate chinese SR2_ES1_menu_29616dc3:

    # Sara "(I don’t know why I’m doing this so willingly for him. If it was ANY other guy at my college, I’d be trembling with anxiety right now!)"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:249
translate chinese SR2_ES1_menu_89e02b1c:

    # Sara "There you go, [player_name]. W-What do you think?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:250
translate chinese SR2_ES1_menu_47b75f46:

    # MC "Mmm! Hold your top there for a couple of minutes."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:251
translate chinese SR2_ES1_menu_2cd1e1de:

    # MC "(I can just about make out her cameltoe through the thin pink fabric!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:252
translate chinese SR2_ES1_menu_14788f9a:

    # Sara "D-Do you want to see the back too? "
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:253
translate chinese SR2_ES1_menu_a7ad2962:

    # Sara "(Great... I’m starting to get nervous now.)"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:254
translate chinese SR2_ES1_menu_8dd061b9:

    # MC "Yes please!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:258
translate chinese SR2_ES1_menu_ca020e1a:

    # Sara "There you go."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:259
translate chinese SR2_ES1_menu_26ad73b0:

    # MC "I can’t really see much. Can you lift your shirt up higher?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:260
translate chinese SR2_ES1_menu_414277ae:

    # Sara "Oops, sorry! My bad!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:264
translate chinese SR2_ES1_menu_81e0e768:

    # Sara "How’s that?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:265
translate chinese SR2_ES1_menu_03191713:

    # MC "Much better! I can see everything now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:266
translate chinese SR2_ES1_menu_43417f87:

    # Sara "Hehe..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:267
translate chinese SR2_ES1_menu_022a3a51:

    # MC "(She’s got such a cute little ass!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:271
translate chinese SR2_ES1_menu_251000f9:

    # Sara "Well? Did you enjoy that?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:272
translate chinese SR2_ES1_menu_003d9d05:

    # MC "Mmm, very much so!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:273
translate chinese SR2_ES1_menu_5ec08a09:

    # Sara "In that case, let me give you one final parting gift."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:277
translate chinese SR2_ES1_menu_b676b827:

    # MC "Whoa, you’re gonna make me dizzy if you keep moving the webcam around like that!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:278
translate chinese SR2_ES1_menu_c7c1ecd4:

    # Sara "Almost there!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:282
translate chinese SR2_ES1_menu_901ef35a:

    # Sara "You probably can’t tell - but I’m starting to get really, really wet under these panties."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:283
translate chinese SR2_ES1_menu_451401fc:

    # Sara "Something about showing off my body to you on webcam, is really realy hot."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:284
translate chinese SR2_ES1_menu_8bdf760a:

    # MC "I’m looking forward to seeing you without those panties on."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:285
translate chinese SR2_ES1_menu_30890f68:

    # Sara "Hehe! I'm sure you are!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:299
translate chinese SR2_ES1_continue_6589039f:

    # MC "(She still looks rather downhearted... Probably studying all day is VERY boring...)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:300
translate chinese SR2_ES1_continue_ef053841:

    # MC "(Let's see if I can't take her mind off things...)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:301
translate chinese SR2_ES1_continue_44a44f02:

    # MC "Are you enjoying that vibrator I bought for you?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:305
translate chinese SR2_ES1_continue_ba7c98e3:

    # Sara "Huh? Oh yeah, it's REALLY good."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:306
translate chinese SR2_ES1_continue_3a4f3eb9:

    # MC "Are you using it much?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:307
translate chinese SR2_ES1_continue_8a2e5a48:

    # Sara "Almost every day! Sometimes more than once. I like to imagine that it's your cock pressing up against my pussy, when I do it."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:308
translate chinese SR2_ES1_continue_c65bc554:

    # MC "Do you still have it sitting in your room?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:312
translate chinese SR2_ES1_continue_73abdc00:

    # Sara "Yeah, it's right here. I hide it in my desk drawer."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:313
translate chinese SR2_ES1_continue_ab93ee8a:

    # MC "Could you give me a show of how you use it?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:314
translate chinese SR2_ES1_continue_44753e63:

    # Sara "Wh-What?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:315
translate chinese SR2_ES1_continue_5c5128c6:

    # MC "I'd love to see how you use the vibrator on your body. Can you do that for me?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:319
translate chinese SR2_ES1_continue_9de8115f:

    # Sara "I... I guess so..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:320
translate chinese SR2_ES1_continue_c375aebd:

    # MC "(Woo! This is gonna be great!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:321
translate chinese SR2_ES1_continue_023bb88d:

    # Sara "You have to promise... not to laugh, okay?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:322
translate chinese SR2_ES1_continue_d49b49fe:

    # MC "Why would I laugh?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:323
translate chinese SR2_ES1_continue_5a7d21d8:

    # Sara "I tend to make... a lot of noises when I use it."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:324
translate chinese SR2_ES1_continue_0d70eadd:

    # MC "I’m not gonna laugh, I promise."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:328
translate chinese SR2_ES1_continue_512dacbb:

    # Sara "*Deep breath* Okay..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:329
translate chinese SR2_ES1_continue_36490d55:

    # Sara "I’ll just get my panties off here..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:330
translate chinese SR2_ES1_continue_bdbcfbab:

    # Sara "(I can’t believe I’m doing this on camera...)"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:334
translate chinese SR2_ES1_continue_424ee770:

    # "*Buzzzzz*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:335
translate chinese SR2_ES1_continue_7b2782dc:

    # Sara "Oooh..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:336
translate chinese SR2_ES1_continue_c335064a:

    # MC "(I can hear the vibrator, and it looks like Sara has just found her clitoris!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:337
translate chinese SR2_ES1_continue_3ec176ad:

    # MC "(It’s a shame I can’t see anything though...)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:338
translate chinese SR2_ES1_continue_9d84dce1:

    # MC "Sara, can you bring the webcam closer, so I can see?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:342
translate chinese SR2_ES1_continue_312cf142:

    # Sara "Mmm! Uh huh! S-Sure! Ahh..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:344
translate chinese SR2_ES1_continue_9f797e61:

    # "*Buzzzzzzzz*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:345
translate chinese SR2_ES1_continue_9c22b3ca:

    # Sara "Oh... fuck..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:346
translate chinese SR2_ES1_continue_94d3a8bc:

    # MC "(That girl in the sex shop was right! A strong vibe was the way to go!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:350
translate chinese SR2_ES1_continue_479c4b96:

    # Sara "C-Can you see it?"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:351
translate chinese SR2_ES1_continue_8fd7ff78:

    # MC "Yeah! Your pussy looks amazing!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:352
translate chinese SR2_ES1_continue_15b6aa0b:

    # MC "I could just dive right in there and lick you for hours."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:353
translate chinese SR2_ES1_continue_696ed78a:

    # Sara "Ah! Ah! [player_name]! Oooh!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:354
translate chinese SR2_ES1_continue_eb6dad7a:

    # MC "Press the vibrator up close again. I want to watch you masturbate."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:358
translate chinese SR2_ES1_continue_882ef572:

    # "*Buzzzz*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:359
translate chinese SR2_ES1_continue_102a6230:

    # Sara "Ah... Ah.... Ahhh!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:360
translate chinese SR2_ES1_continue_1558fb84:

    # MC "(It sounds like Sara’s having the time of her life right now!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:364
translate chinese SR2_ES1_continue_299ac1da:

    # Sara "Mmm! Yes! MMM!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:366
translate chinese SR2_ES1_continue_72041f75:

    # "*BUZZZZ*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:367
translate chinese SR2_ES1_continue_8688ec6f:

    # MC "How does it feel, Sara?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:371
translate chinese SR2_ES1_continue_e0c63ae1:

    # Sara "Mmm! It’s soooo ahh.... fucking good!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:372
translate chinese SR2_ES1_continue_e8ff4abf:

    # Sara "Ugh! It’s like a- ahhh - w-warmth deep inside my belly! MMM!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:374
translate chinese SR2_ES1_continue_a1dd42fd:

    # "*BUZZZ*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:375
translate chinese SR2_ES1_continue_4a3a6f63:

    # Sara "God... it’s so fucking intense... Ahhh! AHHH!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:376
translate chinese SR2_ES1_continue_06095e05:

    # MC "I want you to cum for me, Sara."
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:380
translate chinese SR2_ES1_continue_115400ff:

    # Sara "God! Yes! I’m CUMMING! I’M CUMMING!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:381
translate chinese SR2_ES1_continue_2b0a592c:

    # Sara "Hnnnngggg!!! AHHHHHHHHH!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:382
translate chinese SR2_ES1_continue_d462ff86:

    # MC "(Wow! She’s shaking and trembling! I’ve never seen a girl cum so intensely before!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:388
translate chinese SR2_ES1_continue_d9018f3c:

    # "*KNOCK KNOCK*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:390
translate chinese SR2_ES1_continue_a1dd42fd_1:

    # "*BUZZZ*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:391
translate chinese SR2_ES1_continue_ef3c2dea:

    # Sara "F-Fuck!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:395
translate chinese SR2_ES1_continue_69375ca5:

    # Mom "Sara? What’s going on in there?"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:401
translate chinese SR2_ES1_continue_d9a1fc52:

    # MC "(Oh shit!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:402
translate chinese SR2_ES1_continue_90f04c58:

    # MC "Quick! Turn the vibe off and throw it under your bed!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:406
translate chinese SR2_ES1_continue_c9e3cc35:

    # Mom "Sara! I told you to study! You’re wasting your time with those online games again, aren’t you?"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:408
translate chinese SR2_ES1_continue_db9dc452:

    # Sara "N-No, M-Mom!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:410
translate chinese SR2_ES1_continue_8078dd0a:

    # Sara "N-No, L-Linda!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:412
translate chinese SR2_ES1_continue_96a2dea5:

    # Mom "Don’t you lie to me, young lady!"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:416
translate chinese SR2_ES1_continue_90bd3719:

    # Sara "Whoaaaa!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:419
translate chinese SR2_ES1_continue_933aa022:

    # "*THUD*"
    ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:420
translate chinese SR2_ES1_continue_ed711738:

    # Mom "Pull yourself together and-"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:424
translate chinese SR2_ES1_continue_472a1b04:

    # Mom "Why aren’t you wearing any panties?!"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:426
translate chinese SR2_ES1_continue_c0195bfe:

    # Sara "I... uh... Mom!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:428
translate chinese SR2_ES1_continue_3568bad5:

    # Sara "I... uh... Linda!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:429
translate chinese SR2_ES1_continue_06561e71:

    # Mom "Oh my God! Those WERE moans, I heard coming from your room!"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:433
translate chinese SR2_ES1_continue_ce91314c:

    # Mom "Were you watching porn instead of studing?"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:435
translate chinese SR2_ES1_continue_fff4817d:

    # Sara "Mom, I-"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:436
translate chinese SR2_ES1_continue_12fe61e4:

    # Mom "Right. That’s it. No more laptop for you. Turn it off, this instant."
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:438
translate chinese SR2_ES1_continue_f214af8c:

    # Sara "Linda, I-"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:439
translate chinese SR2_ES1_continue_ff4a8421:

    # Mom "Right. That’s it. I’m NOT paying the internet just for my tenants to waste my data on pornography! Instead of studying you’re pleasuring yourself to porn?! I hardly recognize this behaviour in you, Sara!"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:444
translate chinese SR2_ES1_continue_e6eb1f19:

    # Sara "B-But, Mom!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:445
translate chinese SR2_ES1_continue_a846cd15:

    # Mom "Now, Sara! I said, turn off your laptop!"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:447
translate chinese SR2_ES1_continue_f149d3d1:

    # Sara "B-But, Linda! I’m adult and I can do what I want..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:448
translate chinese SR2_ES1_continue_d293f5e9:

    # Mom "I understand that Sara, but you are renting this room in MY house. You’re paying your rent with a tuition grant. If you fail your studies, then you won't get any money."
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:449
translate chinese SR2_ES1_continue_8afb2693:

    # Mom "If I was your mother I would force you to study! Please, turn off your laptop."
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:450
translate chinese SR2_ES1_continue_11b098e8:

    # Sara "*Sniff* O-Okay..."
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:454
translate chinese SR2_ES1_continue_afb6d602:

    # Mom "Hold up - is your webcam on?"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:455
translate chinese SR2_ES1_continue_53d42444:

    # Mom "Have you been doing “the cybersex” with boys?!"
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:456
translate chinese SR2_ES1_continue_ef3de192:

    # MC "(Oh fuck!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:457
translate chinese SR2_ES1_continue_5a695585:

    # Sara "N-No! That red light means its turned off!"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:458
translate chinese SR2_ES1_continue_c0da49ac:

    # Mom "Ahh... Okay, that makes sense."
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:459
translate chinese SR2_ES1_continue_8eea1b83:

    # Sara "*Sniff*"
    Sara ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:461
translate chinese SR2_ES1_continue_2ca4a143:

    # Mom "I swear to God! I will ground you for a year, if your grades in college do not improve, young lady."
    Mom ""

# game/scripts/gui/computer/webcam_scenes/SR2_ES1.rpy:463
translate chinese SR2_ES1_continue_c2f76549:

    # Mom "I swear to God. I will call your parents and tell them to come here to take you back home if your grades don't improve. You won't be able to pay the rent anyway."
    Mom ""

