﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:15
translate chinese CR2_AS2_rep_da78af3c:

    # MC "That was a pretty fun photoshoot!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:16
translate chinese CR2_AS2_rep_d1e6663e:

    # Caroline "Yeah, I enjoyed it too! Even if the costume was a little bit... lewd."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:17
translate chinese CR2_AS2_rep_6dd39715:

    # MC "So, given how sexy you looked, I’m REALLY needing to make use of that deal we made."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:22
translate chinese CR2_AS2_rep_64186dab:

    # Caroline "Oh? And how would you like to use it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:23
translate chinese CR2_AS2_rep_9b468b93:

    # MC "I’m thinking that you could use that amazing ass of yours, to get me off."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:24
translate chinese CR2_AS2_rep_b728a071:

    # MC "What do you say?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:29
translate chinese CR2_AS2_rep_a3f4f059:

    # MC "(Holy shit, those nipple pasties are awesome!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:30
translate chinese CR2_AS2_rep_228863d6:

    # MC "(I’d love her to titfuck me with those on - but I’m feeling like using her ass right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:31
translate chinese CR2_AS2_rep_b9bacb4c:

    # Caroline "You don’t mean... inside, do you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:36
translate chinese CR2_AS2_rep_37611b78:

    # MC "No! Of course not. Just in between your cheeks."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:37
translate chinese CR2_AS2_rep_fd483df2:

    # Caroline "I... uh... I guess that’s okay."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:38
translate chinese CR2_AS2_rep_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:43
translate chinese CR2_AS2_rep_7bbeeb66:

    # Caroline "What do you want me to do?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:44
translate chinese CR2_AS2_rep_7ddaad71:

    # MC "How about, you just lie, face-down on the couch?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:45
translate chinese CR2_AS2_rep_db698752:

    # MC "I can take it from there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:46
translate chinese CR2_AS2_rep_914390c3:

    # Caroline "Okay then."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:50
translate chinese CR2_AS2_rep_1f03f550:

    # Caroline "Just like this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:51
translate chinese CR2_AS2_rep_d6414aa5:

    # MC "That’s absolutely perfect!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:52
translate chinese CR2_AS2_rep_0e501803:

    # Caroline "And you promise, IT won’t go inside?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:53
translate chinese CR2_AS2_rep_caa8a8ef:

    # MC "Your panties will stay on - don’t worry."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:57
translate chinese CR2_AS2_rep_8cc9444c:

    # MC "(Although, to be completely honest, those panties are so tight I can barely see them!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:58
translate chinese CR2_AS2_rep_f066c3b6:

    # MC "(From this angle, she may as well not be wearing any at all!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:59
translate chinese CR2_AS2_rep_d4d6f3eb:

    # Caroline "Give me a heads up before you start."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:63
translate chinese CR2_AS2_rep_afd4f8c2:

    # MC "Okay, sis. I’m just lining my cock up now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:64
translate chinese CR2_AS2_rep_28b64c99:

    # Caroline "Can you please try and not call me “sis” when we’re doing this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:67
translate chinese CR2_AS2_rep_b859c129:

    # MC "I’m just lining my cock up now. You really are the best friend I could have asked for."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:68
translate chinese CR2_AS2_rep_11767f08:

    # Caroline "Can you please try and not call me your “best friend” when we’re doing this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:69
translate chinese CR2_AS2_rep_ff835a9c:

    # Caroline "It makes me a little... uncomfortable."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:73
translate chinese CR2_AS2_rep_095c2ada:

    # MC "Sorry, Caroline. My bad."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:74
translate chinese CR2_AS2_rep_ec346b89:

    # MC "Okay, I’m gonna push my cock between your ass cheeks now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:76
translate chinese CR2_AS2_rep_88bc72e7:

    # Caroline "Mmm hmm, okay."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:80
translate chinese CR2_AS2_rep_3fa5d067:

    # Caroline "Does that feel good for you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:81
translate chinese CR2_AS2_rep_93250345:

    # MC "It’s not too bad."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:82
translate chinese CR2_AS2_rep_9756f096:

    # Caroline "You can... You can bury it deeper if you want."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:86
translate chinese CR2_AS2_rep_9db874f4:

    # MC "Awesome! Thanks, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:87
translate chinese CR2_AS2_rep_5fdda966:

    # MC "(This is gonna feel sooo much better!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:88
translate chinese CR2_AS2_rep_9646d81f:

    # MC "(I can’t believe I have a friend with such a plump ass - it’s gonna feel amazing when they’re wrapped either side of my cock! I suppose we’re closer to “fuckbuddies” than “friends” now though.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:92
translate chinese CR2_AS2_rep_cfe4ed65:

    # MC "Ooohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:94
translate chinese CR2_AS2_rep_cca063eb:

    # Caroline "Better?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:95
translate chinese CR2_AS2_rep_e12107e3:

    # MC "Oh yeah, that’s perfect!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:99
translate chinese CR2_AS2_rep_6e1a318d:

    # Caroline "Perfect? Really?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:100
translate chinese CR2_AS2_rep_244bd905:

    # MC "Yeah, your body is amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:101
translate chinese CR2_AS2_rep_49a2c845:

    # Caroline "(He thinks my body is amazing! Hehe!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:105
translate chinese CR2_AS2_rep_316167fc:

    # MC "Mmm! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:107
translate chinese CR2_AS2_rep_b5e85a62:

    # Caroline "(It really sounds like he’s enjoying this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:108
translate chinese CR2_AS2_rep_0cae6f92:

    # Caroline "(I never imagined a guy could get so much pleasure, without even penetrating something!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:112
translate chinese CR2_AS2_rep_b166885a:

    # MC "Fuck... That’s good..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:113
translate chinese CR2_AS2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:114
translate chinese CR2_AS2_rep_ae6deb8a:

    # MC "(I’m gonna cum in no time at all! Her ass is wrapped perfectly around my cock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:118
translate chinese CR2_AS2_rep_26ab94a3:

    # Caroline "So, where else would you like to fuck me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:119
translate chinese CR2_AS2_rep_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:120
translate chinese CR2_AS2_rep_4a41776d:

    # Caroline "You clearly enjoy fucking my breasts and my ass. What else would you like to do to me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:124
translate chinese CR2_AS2_rep_6a3adaa1:

    # MC "(Is she seriously asking that question right now?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:125
translate chinese CR2_AS2_rep_b5f02673:

    # MC "Ah... I would love to fuck your mouth."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:126
translate chinese CR2_AS2_rep_3df39a75:

    # Caroline "My mouth? Mmm... oh...."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:130
translate chinese CR2_AS2_rep_b67b0cd9:

    # MC "And I’d love to strip these panties off you and rub my cock up against your wet pussy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:132
translate chinese CR2_AS2_rep_f68a7381:

    # Caroline "(Wow, I didn’t know he was THAT into me!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:134
translate chinese CR2_AS2_rep_35fb7853:

    # Caroline "Keep talking..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:138
translate chinese CR2_AS2_rep_e66f3653:

    # MC "Then, after grinding, back and forth, I’d plunge my cock, deep inside you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:139
translate chinese CR2_AS2_rep_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:140
translate chinese CR2_AS2_rep_761804d2:

    # Caroline "(Damn, this dirty talk is starting to make me wet!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:144
translate chinese CR2_AS2_rep_54a94e13:

    # MC "And then I’d thrust, back and forth, in and out of your pussy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:145
translate chinese CR2_AS2_rep_bfa2023f:

    # MC "Each time, making you moan and gasp with pleasure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:146
translate chinese CR2_AS2_rep_dd994c67:

    # Caroline "What next?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:150
translate chinese CR2_AS2_rep_bd19a78a:

    # MC "I... um..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:151
translate chinese CR2_AS2_rep_bff4596e:

    # Caroline "Go on - finish the story."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:152
translate chinese CR2_AS2_rep_7bf0f392:

    # MC "Mmm! I haven’t exactly figured out the ending."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:156
translate chinese CR2_AS2_rep_98cd4aba:

    # Caroline "Well, let me finish it for you. Close your eyes and imagine you’re fucking my pussy right now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:157
translate chinese CR2_AS2_rep_49b5500c:

    # MC "Oh God..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:158
translate chinese CR2_AS2_rep_cf2a7be8:

    # Caroline "Can you feel my, tight wet walls, clamped around your cock?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:162
translate chinese CR2_AS2_rep_b5d4aa6f:

    # Caroline "I want you to thrust deep, and blow your hot seed inside me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:163
translate chinese CR2_AS2_rep_e15032a2:

    # MC "Oh God, I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:164
translate chinese CR2_AS2_rep_2e4826d8:

    # Caroline "Yes... cum deep inside my pussy."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:165
translate chinese CR2_AS2_rep_2a22a45d:

    # Caroline "You’re not wearing a condom. It’s dangerous, but you can’t hold yourself back."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:175
translate chinese CR2_AS2_rep_c36e77d7:

    # MC "HNNNNGGG! AAAHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:176
translate chinese CR2_AS2_rep_b968a1d4:

    # MC "Ugh! Ahh! Ahhh! Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:177
translate chinese CR2_AS2_rep_6144638b:

    # Caroline "Yes! Cum for me! Cum deep in my cunt!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:178
translate chinese CR2_AS2_rep_1209c615:

    # MC "Oh! Ohhh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_AS2_rep.rpy:179
translate chinese CR2_AS2_rep_5cc8951a:

    # Caroline "Wow! You REALLY enjoyed using my ass, didn’t you?"
    Caroline ""

