﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:16
translate chinese CR3_AS8_rep_73c08e0b:

    # MC "Well? Are you happy with the pictures?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:17
translate chinese CR3_AS8_rep_f44a3d19:

    # Caroline "I think I will be! I’m hoping to break into the Japanese market, overseas. It won’t be an easy ride - but if we keep up this targeted advertising, then I stand a solid chance."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:18
translate chinese CR3_AS8_rep_5cd480ec:

    # MC "Good to hear!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:22
translate chinese CR3_AS8_rep_11f74975:

    # Violet "Hey guys, I gotta head on, here. My mom needs me to pick up some groceries, on the way home."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:23
translate chinese CR3_AS8_rep_77dc0cf9:

    # MC "No problem. Catch you later, Violet."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:24
translate chinese CR3_AS8_rep_0e3ded65:

    # Caroline "Thanks for your help today! See you later!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:28
translate chinese CR3_AS8_rep_ded242e0:

    # MC "Well, it’s just you and me now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:29
translate chinese CR3_AS8_rep_6ad95b42:

    # Caroline "Do you have any plans for the evening?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:30
translate chinese CR3_AS8_rep_9df30360:

    # MC "No, I’m free to spend some time here, if you want to relax together."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:34
translate chinese CR3_AS8_rep_5659c62f:

    # Caroline "Yeah, I’d like that. Now that we’ve got some privacy - perhaps we could fool around?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:35
translate chinese CR3_AS8_rep_238acb35:

    # MC "Mmm... that sounds good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:36
translate chinese CR3_AS8_rep_54b969b4:

    # Caroline "Go ahead. You can do whatever you want."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:40
translate chinese CR3_AS8_rep_818b33b4:

    # MC "Is this okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:41
translate chinese CR3_AS8_rep_424e087b:

    # Caroline "You don’t need to worry about seeking my permission, for every action. The deal’s back on - and I know I’m safe with you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:42
translate chinese CR3_AS8_rep_966a2592:

    # MC "(God, her tits are fucking amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:46
translate chinese CR3_AS8_rep_9d6223ec:

    # Caroline "You really like my breasts, don’t you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:47
translate chinese CR3_AS8_rep_de0bbb9d:

    # MC "They stand out, so well in this outfit!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:48
translate chinese CR3_AS8_rep_ab1e6952:

    # Caroline "How about you strip out of that silly costume, and I’ll show you a good time."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:49
translate chinese CR3_AS8_rep_c8c2ddcd:

    # MC "Great - could I request that you keep YOUR outfit on, though? It’s kinda sexy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:53
translate chinese CR3_AS8_rep_40b9ff1e:

    # Caroline "Hehe. Of course I’ll keep mine on for you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:54
translate chinese CR3_AS8_rep_0b5b8b86:

    # Caroline "(Fuck, his cock looks so hot. I can’t wait to play with it!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:55
translate chinese CR3_AS8_rep_0d5e3621:

    # Caroline "Remember - no putting your dick in any of my holes. Aside from that, I’m down for almost anything."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:59
translate chinese CR3_AS8_rep_59230c00:

    # MC "No problem, Caroline. That sounds fair enough."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:60
translate chinese CR3_AS8_rep_b3ffaf3a:

    # Caroline "Close your eyes, for me. I want to show you something."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:61
translate chinese CR3_AS8_rep_7661ad86:

    # MC "Okay, what-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:65
translate chinese CR3_AS8_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:66
translate chinese CR3_AS8_rep_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:67
translate chinese CR3_AS8_rep_edfbfce0:

    # MC "(Oh wow! She’s an incredible kisser!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:71
translate chinese CR3_AS8_rep_91883ce6:

    # Caroline "Mmm... "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:72
translate chinese CR3_AS8_rep_6150324f:

    # Caroline "(He tastes so good... I could make out with him forever.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:76
translate chinese CR3_AS8_rep_fd223820:

    # Caroline "Well? Enjoy that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:77
translate chinese CR3_AS8_rep_87f4843d:

    # MC "Oh yeah... That was something else!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:78
translate chinese CR3_AS8_rep_975d5165:

    # Caroline "I think you’re going to enjoy - what comes next - even more."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:82
translate chinese CR3_AS8_rep_19a79f4d:

    # MC "(Is she going to take her panties off?! I wonder if she’ll let me fuck her today!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:83
translate chinese CR3_AS8_rep_6b9b44d3:

    # Caroline "I hope you’re enjoying the view there. I want you - extra hard - by the time I turn around."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:84
translate chinese CR3_AS8_rep_6e8e7971:

    # MC "I’ve been rock-hard, since I saw you in that white costume!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:88
translate chinese CR3_AS8_rep_5c8826c9:

    # Caroline "What do you think?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:89
translate chinese CR3_AS8_rep_a668695e:

    # MC "Wow... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:90
translate chinese CR3_AS8_rep_fb72c59a:

    # Caroline "There’s not a lot of guys who get to see those parts. You better damn well appreciate the view!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:94
translate chinese CR3_AS8_rep_ba07198d:

    # Caroline "Now, onto the main show..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:95
translate chinese CR3_AS8_rep_84dac483:

    # MC "Careful - are you not worried about it slipping inside you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:96
translate chinese CR3_AS8_rep_63a6fa6e:

    # Caroline "Relax, I’ve got your little guy - gripped firmly - between my thighs. He’s not going anywhere."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:100
translate chinese CR3_AS8_rep_af4fb758:

    # Caroline "Well... maybe ‘little’ wasn’t the right adjective to use."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:101
translate chinese CR3_AS8_rep_56ebbc34:

    # MC "Mmm... That feels good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:105
translate chinese CR3_AS8_rep_b174203a:

    # Caroline "I’m gonna start grinding my hips, up and down. Will you let me know if it feels good?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:106
translate chinese CR3_AS8_rep_b7f88bf1:

    # MC "Yeah, I will. What about you though? You deserve to get some pleasure too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:107
translate chinese CR3_AS8_rep_1b895bbb:

    # Caroline "Don’t you worry - I can feel your shaft, against my pussy. I’ll be enjoying this, as much as you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:111
translate chinese CR3_AS8_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:112
translate chinese CR3_AS8_rep_557970a3:

    # Caroline "My thighs aren’t too tight around your cock, are they?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:113
translate chinese CR3_AS8_rep_f41f597d:

    # MC "Ah... n-no... that’s perfect."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:114
translate chinese CR3_AS8_rep_affe87d5:

    # Caroline "Good! I want you to enjoy this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:118
translate chinese CR3_AS8_rep_12c59643:

    # MC "Mmm... That’s so fucking good, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:119
translate chinese CR3_AS8_rep_c4524380:

    # MC "Where did you learn to use your thighs like that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:120
translate chinese CR3_AS8_rep_b6e09fe6:

    # Caroline "You don’t have a condom on you right now, and I can’t risk letting you into my pussy. This is the safest way to do it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:124
translate chinese CR3_AS8_rep_e65317c6:

    # Caroline "It’s called improvisation! I’ve seen some women do it in porn."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:125
translate chinese CR3_AS8_rep_75e8c457:

    # MC "Huh? That’s pretty clever. Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:126
translate chinese CR3_AS8_rep_2c20909b:

    # Caroline "Yeah, it works most of the time."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:127
translate chinese CR3_AS8_rep_06d3dcba:

    # MC "Why only most of the time?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:131
translate chinese CR3_AS8_rep_bd657f40:

    # Caroline "This position has your cock rub up against my clitoris. I’ve seen a few videos where the woman gets REALLY turned on, and just couldn’t hold herself back any longer."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:132
translate chinese CR3_AS8_rep_e5c707e5:

    # Caroline "Ah... Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:133
translate chinese CR3_AS8_rep_f091866c:

    # Caroline "God... It’s so hot, watching them give in to riding a cock, bareback. They’ve got to be super careful to pull out in time, y’know?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:138
translate chinese CR3_AS8_rep_88deaa12:

    # Caroline "Violet takes birth control, for the exact same reason. Once a guy turns her on, she just needs to fuck him. She’s insatiable like that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:139
translate chinese CR3_AS8_rep_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:141
translate chinese CR3_AS8_rep_d718f328:

    # MC "(I wonder if I could turn on Caroline, that way.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:145
translate chinese CR3_AS8_rep_7b9c2157:

    # Caroline "H-Hey! Wh-What are you doing?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:146
translate chinese CR3_AS8_rep_ae5e4815:

    # MC "It’s not fair that you’re doing all the work! Let me help, by moving my hips a bit!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:147
translate chinese CR3_AS8_rep_d68b1617:

    # Caroline "W-Wait!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:151
translate chinese CR3_AS8_rep_b6f4d8fd:

    # Caroline "Ah! Ah!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:152
translate chinese CR3_AS8_rep_2d9c88ed:

    # MC "(I can feel my shaft digging into her pussy now. I can definitely stimulate her better, from this angle!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:153
translate chinese CR3_AS8_rep_0fbf5c80:

    # MC "(Plus, I can go much faster than she could, when she was on top of me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:157
translate chinese CR3_AS8_rep_25e18b84:

    # Caroline "Ah! Oh, my God! Mmm! Oh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:158
translate chinese CR3_AS8_rep_1685b179:

    # Caroline "[player_name]! Y-You have to - ahhh - s-slow down!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:159
translate chinese CR3_AS8_rep_e92db6e1:

    # MC "Mmm! Ah! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:163
translate chinese CR3_AS8_rep_c462dfd8:

    # Caroline "OOOHHHHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:164
translate chinese CR3_AS8_rep_ebf4b1fc:

    # Caroline "(He’s got the perfect angle on my pussy! It feels so fucking good!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:165
translate chinese CR3_AS8_rep_ee097841:

    # Caroline "(I can’t let him get the better of me like this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:169
translate chinese CR3_AS8_rep_6624b469:

    # Caroline "Ah! AHHH! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:170
translate chinese CR3_AS8_rep_cfc9c2ef:

    # MC "Hnnnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:171
translate chinese CR3_AS8_rep_30453b09:

    # MC "(Damn, she is REALLY wet right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:175
translate chinese CR3_AS8_rep_73c8ef2a:

    # MC "(Let’s change the angle a bit, so my cock is ALMOST poking at her pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:176
translate chinese CR3_AS8_rep_4a7f34b5:

    # Caroline "Oh... Oh... Ohh... Wow..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:177
translate chinese CR3_AS8_rep_f07d1a2c:

    # Caroline "(The feeling of his cock, against my pussy, is making me melt. This is FAR too risky! Why did I ever think, doing this without panties, would be a good idea?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:181
translate chinese CR3_AS8_rep_d3f961f4:

    # MC "(Okay, I’ve got the angle! Now I can press against her pussy, as if I’m about to go inside.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:182
translate chinese CR3_AS8_rep_7da9379f:

    # MC "(I’ll slip past, at the very last second - and tease her. Haha!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:183
translate chinese CR3_AS8_rep_f35a372a:

    # Caroline "Ah! Ah! W-Wait! Don’t go inside!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:187
translate chinese CR3_AS8_rep_21210980:

    # Caroline "Ohhhhhh!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:188
translate chinese CR3_AS8_rep_c91e7456:

    # Caroline "(He is sliding the whole length of his cock against my clitoris! It feels soooo good!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:189
translate chinese CR3_AS8_rep_d762ce3c:

    # MC "(Heh, I’m REALLY making her moan here!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:193
translate chinese CR3_AS8_rep_d0a3ae26:

    # Caroline "Ohhh... Mmm... God..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:194
translate chinese CR3_AS8_rep_5c1f4f24:

    # MC "(She’s absolutely loving this! My cock is completely SOAKED with her juices now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:195
translate chinese CR3_AS8_rep_7aef3915:

    # Caroline "Yeeessss..! Mmmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:202
translate chinese CR3_AS8_rep_11aa80fd:

    # MC "(Fuck! I’m about to cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:203
translate chinese CR3_AS8_rep_12a56071:

    # MC "AH! Ahhh! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:204
translate chinese CR3_AS8_rep_24337985:

    # Caroline "Oh! Oh! AHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:208
translate chinese CR3_AS8_rep_0a8cc347:

    # MC "Yes! HNNNGGGG! Arrghhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:210
translate chinese CR3_AS8_rep_8eafbb0a:

    # Caroline "AHHHHH!!!!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:221
translate chinese CR3_AS8_rep_8114f3fe:

    # MC "*Pant Pant* Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:222
translate chinese CR3_AS8_rep_2ad5f602:

    # MC "Fuck... That was amazing, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:223
translate chinese CR3_AS8_rep_c03a271b:

    # Caroline "(Huh?! He stopped?! I was SOOO close to cumming! Dammit! I want him inside me...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:227
translate chinese CR3_AS8_rep_a7ade34b:

    # Caroline "(Fuck - this has gone too far again. I need to get home and relieve myself, before I find myself doing something I’ll regret.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:228
translate chinese CR3_AS8_rep_46d16608:

    # Caroline "(This ALWAYS happens when I get too horny.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:229
translate chinese CR3_AS8_rep_1cb19228:

    # MC "Caroline? Where are you going?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:233
translate chinese CR3_AS8_rep_30325659:

    # Caroline "I... er... I have to go and do... something urgent. I completely forgot about it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:234
translate chinese CR3_AS8_rep_6a0301ae:

    # Caroline "Feel free to clean yourself up and head back home!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:235
translate chinese CR3_AS8_rep_b2280db1:

    # MC "Um, okay? I’ll see you later."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS8_rep.rpy:236
translate chinese CR3_AS8_rep_eafd6105:

    # Caroline "BYE! (Fuck! I was SOOO close to letting him pound my pussy, there. I need to get a grip on myself!)"
    Caroline ""

