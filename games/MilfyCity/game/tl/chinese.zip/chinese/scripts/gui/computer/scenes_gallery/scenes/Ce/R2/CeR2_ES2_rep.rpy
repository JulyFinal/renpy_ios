﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:11
translate chinese CeR2_ES2_rep_0304391f:

    # MC "(What the fuck?! How did she get in here?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:12
translate chinese CeR2_ES2_rep_1b03da30:

    # MC "C-Celia?! How did- What are you doing here?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:15
translate chinese CeR2_ES2_rep_4982de16:

    # Celia "Oh, hello [player_name]. I was in the neighbourhood, so I thought I would drop by."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:16
translate chinese CeR2_ES2_rep_b91c86a0:

    # MC "How did you get in?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:17
translate chinese CeR2_ES2_rep_1c4b6634:

    # Celia "Linda opened the door for me. A very kind woman, you know. I just explained that I was one of your professors and that I had to talk to you about your progress."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:20
translate chinese CeR2_ES2_rep_2357841e:

    # MC "You really shouldn’t be at my home, you know that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:21
translate chinese CeR2_ES2_rep_5a562b13:

    # Celia "On the contrary, [player_name]. This is EXACTLY where I need to be right now."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:22
translate chinese CeR2_ES2_rep_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:25
translate chinese CeR2_ES2_rep_c9f764de:

    # Celia "You see, I’ve been doing a little bit of my own research. It was taking you so long to find that blackmailer, after all."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:26
translate chinese CeR2_ES2_rep_4e929b1d:

    # Celia "I simply couldn’t wait for someone who was just so slow."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:27
translate chinese CeR2_ES2_rep_a570654c:

    # Celia "And then it occurred to me. All the little bits of evidence came together to form a rather interesting picture."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:28
translate chinese CeR2_ES2_rep_4ab90a2e:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:31
translate chinese CeR2_ES2_rep_285bd1ad:

    # Celia "It was you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:32
translate chinese CeR2_ES2_rep_87f7fa8a:

    # MC "I don’t know-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:33
translate chinese CeR2_ES2_rep_dc924f54:

    # Celia "Don’t bother trying to deny it. I’ve got you dead-to-rights, you piece of shit."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:36
translate chinese CeR2_ES2_rep_1acfa6e0:

    # MC "Celia, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:37
translate chinese CeR2_ES2_rep_3781ba2e:

    # Celia "Shut up. Don’t talk over me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:38
translate chinese CeR2_ES2_rep_5fcc8bf6:

    # MC "You’ve come to the wrong conclusion!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:42
translate chinese CeR2_ES2_rep_5e1414c3:

    # Celia "Oh, have I?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:44
translate chinese CeR2_ES2_rep_09d06ab8:

    # "*Click*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:46
translate chinese CeR2_ES2_rep_4be37e2b:

    # MC "(Oh fuck...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:48
translate chinese CeR2_ES2_rep_6443cfbe:

    # MC "(Well, well! She’s turned the tables on me! I wonder what she has has planned for me...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:51
translate chinese CeR2_ES2_rep_3e287af0:

    # MC "I, uh... How did that get there?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:52
translate chinese CeR2_ES2_rep_da7e6f3d:

    # Celia "It was you. From the very beginning, it was you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:53
translate chinese CeR2_ES2_rep_ad825399:

    # Celia "YOU were the one who has been making me strip for you on webcam!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:56
translate chinese CeR2_ES2_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:58
translate chinese CeR2_ES2_rep_10175f56:

    # MC "(I’m fucked.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:60
translate chinese CeR2_ES2_rep_e104137f:

    # MC "(I wonder if she’s going to be as harsh on me as I was on her?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:61
translate chinese CeR2_ES2_rep_2547122d:

    # Celia "You don’t have to say anything. I can already tell by that pathetic expression on your goddamn face."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:64
translate chinese CeR2_ES2_rep_e52b8c43:

    # MC "Sorry, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:65
translate chinese CeR2_ES2_rep_9396175f:

    # MC "*Hack*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:66
translate chinese CeR2_ES2_rep_4157835b:

    # Celia "Now, you and I are going to have a little chat."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:75
translate chinese CeR2_ES2_rep_933aa022:

    # "*THUD*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:76
translate chinese CeR2_ES2_rep_324142f5:

    # MC "[Mom_name] is home! She’ll hear you if you-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:77
translate chinese CeR2_ES2_rep_2e22908e:

    # Celia "I said, shut up."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:80
translate chinese CeR2_ES2_rep_4ab90a2e_1:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:81
translate chinese CeR2_ES2_rep_64ecefe6:

    # MC "P-Please, Celia, I- I did it, but I’m sorry. I didn’t mean to-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:83
translate chinese CeR2_ES2_rep_0036fa1c:

    # Celia "God... You were like a lion when you were blackmailing me. So strong, so confident... Now you’re like a little worm. A pathetic little worm."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:85
translate chinese CeR2_ES2_rep_ac810a0b:

    # Celia "God... You were like a lion when you were in charge. So strong, so confident... Now you're like a little worm. A pathetic little worm."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:88
translate chinese CeR2_ES2_rep_5ef00a43:

    # Celia "You. Disgust. Me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:89
translate chinese CeR2_ES2_rep_4c4c5a9c:

    # MC "S-Sorry! I understand if you hate me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:90
translate chinese CeR2_ES2_rep_3c3c7de9:

    # Celia "I don’t hate you, [player_name]. I fucking loathe you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:91
translate chinese CeR2_ES2_rep_6e5b630a:

    # Celia "With every fibre of my being, every cell in my body, every thought going through my brain. I loathe you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:94
translate chinese CeR2_ES2_rep_049fbefc:

    # MC "*COUGH*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:95
translate chinese CeR2_ES2_rep_93523775:

    # MC "P-Please..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:96
translate chinese CeR2_ES2_rep_5ab512f7:

    # Celia "I wish I could just end you right now for what you did to me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:99
translate chinese CeR2_ES2_rep_4639c4a2:

    # Celia "I hate you for all those times you made me suck and fuck your disgusting cock."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:101
translate chinese CeR2_ES2_rep_356b1ea7:

    # Celia "I hate you for that time you came inside me!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:103
translate chinese CeR2_ES2_rep_79e0ad5c:

    # Celia "I hate you for that time you came inside me! (Though it was kinda hot...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:104
translate chinese CeR2_ES2_rep_fc7f9667:

    # MC "*Cough* *Splutter*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:106
translate chinese CeR2_ES2_rep_086ec0de:

    # MC "(I can’t... breathe...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:108
translate chinese CeR2_ES2_rep_4587b6b4:

    # MC "(She never gives up on this fantasy, does she?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:115
translate chinese CeR2_ES2_rep_a792ebb9:

    # "*BANG*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:116
translate chinese CeR2_ES2_rep_60ac03bf:

    # MC "*GASP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:117
translate chinese CeR2_ES2_rep_ae2a7da3:

    # Celia "But, killing you really isn’t an option on the table. Is it?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:120
translate chinese CeR2_ES2_rep_354275f0:

    # Celia "You see, [player_name], I have much more ambitious plans for your future than putting you in a coffin."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:121
translate chinese CeR2_ES2_rep_4ef02b8f:

    # MC "*Gasp* *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:122
translate chinese CeR2_ES2_rep_9a340d1c:

    # Celia "You’re going to make a wonderful pet."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:125
translate chinese CeR2_ES2_rep_4dde94b1:

    # MC "*Gasp* P-Pet?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:126
translate chinese CeR2_ES2_rep_6eac88b7:

    # Celia "My own personal sex slave."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:127
translate chinese CeR2_ES2_rep_04bf345a:

    # Celia "Any time I want my pussy licked, or maybe my feet rubbed, you’ll be there."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:130
translate chinese CeR2_ES2_rep_c6e9d745:

    # Celia "And each time you ask, I expect to hear nothing come out of your mouth except, ‘Yes, Ma’am.’"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:131
translate chinese CeR2_ES2_rep_3ee09135:

    # Celia "Do I make myself clear?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:132
translate chinese CeR2_ES2_rep_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:133
translate chinese CeR2_ES2_rep_4d37fee2:

    # Celia "I said, do I make myself clear?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:134
translate chinese CeR2_ES2_rep_3ff32172:

    # MC "Y-Yes, Ma’am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:137
translate chinese CeR2_ES2_rep_51b34031:

    # Celia "Heh, you’re a quick learner."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:138
translate chinese CeR2_ES2_rep_68cf88af:

    # Celia "But you’ve also been a very bad boy. And bad boys deserve punishment."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:139
translate chinese CeR2_ES2_rep_19570c32:

    # MC "What?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:142
translate chinese CeR2_ES2_rep_1acfa6e0_1:

    # MC "Celia, I-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:143
translate chinese CeR2_ES2_rep_5a49c95b:

    # Celia "Silence!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:148
translate chinese CeR2_ES2_rep_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:149
translate chinese CeR2_ES2_rep_c9682c6a:

    # MC "Ouch!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:152
translate chinese CeR2_ES2_rep_8a799876:

    # Celia "That was for everything you made me do on webcam."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:153
translate chinese CeR2_ES2_rep_76251dd0:

    # Celia "You humiliated me. And now I’m going to do the same to you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:156
translate chinese CeR2_ES2_rep_90ba0fe6:

    # MC "Please, don-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:157
translate chinese CeR2_ES2_rep_2ba205af:

    # Celia "Shut it!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:162
translate chinese CeR2_ES2_rep_4875f5be_1:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:163
translate chinese CeR2_ES2_rep_b737498c:

    # MC "Ow!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:166
translate chinese CeR2_ES2_rep_192f4160:

    # Celia "THAT one was for all the times you made me use that DISGUSTING glory hole!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:167
translate chinese CeR2_ES2_rep_c12cbcc6:

    # MC "S-Sorry! I’m sorry!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:168
translate chinese CeR2_ES2_rep_6db40063:

    # Celia "Sorry isn’t going to butter my toast this time."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:171
translate chinese CeR2_ES2_rep_b925fe7c:

    # Celia "No amount of apologising, no quantity of grovelling, no whiny little whimpering, will get you out of this."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:172
translate chinese CeR2_ES2_rep_d05588f4:

    # Celia "I will never forgive you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:173
translate chinese CeR2_ES2_rep_c206a534:

    # Celia "As long as I have breath in my lungs and blood in my veins, I will make every day of your life a living hell."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:176
translate chinese CeR2_ES2_rep_e37d5cab:

    # Celia "I know you never paid much attention in Literature class, but may I suggest you read ‘No Exit’ by Sartre?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:177
translate chinese CeR2_ES2_rep_1f2aa214:

    # Celia "I don’t want to spoil the ending, but the hell I’m offering will pale in comparison to that. There will be no respite. The door to the exit will never open."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:178
translate chinese CeR2_ES2_rep_4b54fba3:

    # MC "Celia, please... Don’t do this! I can-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:185
translate chinese CeR2_ES2_rep_3c726d8a:

    # "*WHACK*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:186
translate chinese CeR2_ES2_rep_46b8c40e:

    # MC "UGGGGHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:189
translate chinese CeR2_ES2_rep_643fde9d:

    # MC "(Holy fuck... She’s really strong!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:190
translate chinese CeR2_ES2_rep_28e25343:

    # Celia "I bet you weren’t expecting to be hit that hard. A lot of men who try to fuck with me get that nasty surprise."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:191
translate chinese CeR2_ES2_rep_e096d8e5:

    # Celia "The last guy who groped my ass in a nightclub almost had his arm broken."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:194
translate chinese CeR2_ES2_rep_d7ae0149:

    # Celia "I’ve always been into my martial arts. My mother encouraged it from a young age. "
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:195
translate chinese CeR2_ES2_rep_a39de9f5:

    # Celia "It was the best thing she ever did for me - God rest her soul."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:196
translate chinese CeR2_ES2_rep_42a16ff7:

    # MC "*Cough* *Gasp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:199
translate chinese CeR2_ES2_rep_946ce4b3:

    # Celia "Stop acting so hurt. I just winded you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:200
translate chinese CeR2_ES2_rep_cecbadf8:

    # MC "Y-You’re... psychotic..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:202
translate chinese CeR2_ES2_rep_c29bf7d1:

    # Celia "Says the guy who blackmailed a girl, simply for turning him down. I’ve handled creeps like you all my life."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:204
translate chinese CeR2_ES2_rep_2f27883d:

    # Celia "Says the guy who blackmailed a girl, simply for turning him down. I’ve handled creeps like you all my life. (It amazes me he’s still into this roleplay... He’s much better than Gustav.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:207
translate chinese CeR2_ES2_rep_528631e9:

    # MC "Grr..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:209
translate chinese CeR2_ES2_rep_1a2b8eaa:

    # MC "(Fuck, how can I get out of this one?! Think, [player_name], think!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:211
translate chinese CeR2_ES2_rep_faa48481:

    # MC "(I’ll keep up my acting for the meantime and let her take control for a while. It seems like she’s enjoying the role reversal!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:214
translate chinese CeR2_ES2_rep_0ab77317:

    # Celia "So, while you were watching me on webcam, what were you doing?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:215
translate chinese CeR2_ES2_rep_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:216
translate chinese CeR2_ES2_rep_d6db9bcc:

    # Celia "I bet you were wanking yourself off."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:219
translate chinese CeR2_ES2_rep_977f69ee:

    # Celia "Rubbing your cock up and down while looking at my body."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:220
translate chinese CeR2_ES2_rep_08cbe4e8:

    # Celia "Haha! You couldn’t get close to a real woman without trickery and deception."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:223
translate chinese CeR2_ES2_rep_c0f06cf9:

    # MC "Ow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:226
translate chinese CeR2_ES2_rep_f862b3f8:

    # MC "(God... my stomach fucking hurts!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:228
translate chinese CeR2_ES2_rep_c44f697e:

    # MC "(God... Even though she was acting, Celia still gives a pretty strong blow!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:231
translate chinese CeR2_ES2_rep_825c33d6:

    # Celia "So, were you jerking yourself off while you looked at me?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:232
translate chinese CeR2_ES2_rep_ec9b8cdc:

    # MC "...yes."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:233
translate chinese CeR2_ES2_rep_db0ebc97:

    # Celia "I knew it."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:236
translate chinese CeR2_ES2_rep_94c4b44b:

    # Celia "It’s hardly fair that you got to have all the pleasure while you were blackmailing me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:237
translate chinese CeR2_ES2_rep_2f6536da:

    # Celia "I feel like I’m owed quite a lot."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:240
translate chinese CeR2_ES2_rep_08d98d9a:

    # Celia "And today is as good a day as any, for you to begin repaying your debt."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:241
translate chinese CeR2_ES2_rep_bff7bf80:

    # MC "W-What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:244
translate chinese CeR2_ES2_rep_3b826559:

    # Celia "We’ll begin with you eating me out."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:245
translate chinese CeR2_ES2_rep_95e59f81:

    # MC "What?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:246
translate chinese CeR2_ES2_rep_ce4e53ad:

    # Celia "Was I not clear? You’re going to be licking my pussy, and paying extra attention to my clitoris, until I tell you to stop."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:249
translate chinese CeR2_ES2_rep_752b8953:

    # Celia "I don’t care how tired your tongue gets, I don’t care if there are other people home right now who could potentially walk in on us."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:250
translate chinese CeR2_ES2_rep_b8530a52:

    # MC "B-But-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:251
translate chinese CeR2_ES2_rep_577d3caa:

    # Celia "And you better do a good job. I’m sure Linda wouldn’t be too impressed with how you’ve been spending your free time blackmailing a professor."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:254
translate chinese CeR2_ES2_rep_67529b49:

    # Celia "Mmm, I’m really looking forward to this."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:255
translate chinese CeR2_ES2_rep_0816032b:

    # Celia "My husband has a peculiar quirk when it comes to giving head. It’s been far too long since someone actually went down on me."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:258
translate chinese CeR2_ES2_rep_a1cffbf2:

    # Celia "So, without further ado, let’s get to it."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:259
translate chinese CeR2_ES2_rep_4ab90a2e_2:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:262
translate chinese CeR2_ES2_rep_3ec3fd8c:

    # Celia "Come over here, [player_name]."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:263
translate chinese CeR2_ES2_rep_d3f0f9f1:

    # MC "Just *pant* let me catch my breath."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:265
translate chinese CeR2_ES2_rep_974d786f:

    # MC "(There has to be a way out of this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:267
translate chinese CeR2_ES2_rep_68815b6f:

    # MC "(Well, I did have her suck my dick, so I guess this is a fair request!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:270
translate chinese CeR2_ES2_rep_78a32027:

    # Celia "Oh, come on! I didn’t knee you THAT hard!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:271
translate chinese CeR2_ES2_rep_2e76e4ef:

    # Celia "I’m not going to wait for you much longer. And I’m sure Linda is going to wonder why you’re spending so long with your professor in your bedroom."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:275
translate chinese CeR2_ES2_rep_8d48463a:

    # MC "(Fuck it. I really don’t have a choice right now. I’m going to have to lick her pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:277
translate chinese CeR2_ES2_rep_4c20469e:

    # MC "(Looks like I’m going to be eating her pussy tonight!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:278
translate chinese CeR2_ES2_rep_d52d2998:

    # Celia "Look, I’ll even sit down to make it easier for you."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:282
translate chinese CeR2_ES2_rep_db1d494a:

    # MC "(Gah, I’m not going down without a fight!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:284
translate chinese CeR2_ES2_rep_c992d2c4:

    # MC "(Hmm, I wonder if Celia would prefer me to pretend to put up a fight?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:285
translate chinese CeR2_ES2_rep_88d1dc54:

    # MC "No way!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:286
translate chinese CeR2_ES2_rep_eed1522d:

    # Celia "Hmm?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:287
translate chinese CeR2_ES2_rep_5a02c586:

    # MC "I said, no way! I’m not putting my face down there!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:290
translate chinese CeR2_ES2_rep_ee444594:

    # Celia "How very foolish, [player_name]."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:291
translate chinese CeR2_ES2_rep_6489e55e:

    # Celia "I thought you’d already realised this, but I will spell it out for you if I have to."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:294
translate chinese CeR2_ES2_rep_4f0be952:

    # Celia "Defy me, and you’re dead meat."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:295
translate chinese CeR2_ES2_rep_130100c3:

    # Celia "That’s honestly all there is to it. I will do everything in my power to ruin your life, just like you did mine."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:296
translate chinese CeR2_ES2_rep_89d3fd6a:

    # Celia "If you think being my sex slave is the worst thing I could do to you, then you’re horribly mistaken."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:299
translate chinese CeR2_ES2_rep_de6094a2:

    # Celia "That girl who comes to college with you. Sara’s her name, right?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:300
translate chinese CeR2_ES2_rep_be34f01a:

    # Celia "I think she lives here as well."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:301
translate chinese CeR2_ES2_rep_c2b3e230:

    # Celia "It would be a shame if I was to dig up some dirt on her too. Maybe get her involved in this."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:302
translate chinese CeR2_ES2_rep_081a1137:

    # MC "No, don’t!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:305
translate chinese CeR2_ES2_rep_84453efb:

    # Celia "How do you think she’d enjoy licking my pussy every day?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:306
translate chinese CeR2_ES2_rep_29ec1c5b:

    # Celia "Or having me shove a big fat dildo into her tiny little virgin a-"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:307
translate chinese CeR2_ES2_rep_4836700e:

    # MC "Fine! I’ll do what you say - just leave Sara out of it!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:308
translate chinese CeR2_ES2_rep_3fcd3b03:

    # Celia "Good. Now stop wasting time, and get over here."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:311
translate chinese CeR2_ES2_rep_6eb95063:

    # Celia "That’s it... a bit closer."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:312
translate chinese CeR2_ES2_rep_7b44faa2:

    # Celia "(Hehe, I’m going to make the most of this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:313
translate chinese CeR2_ES2_rep_8db12095:

    # Celia "Start licking, boy."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:316
translate chinese CeR2_ES2_rep_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:317
translate chinese CeR2_ES2_rep_0fad326d:

    # Celia "Ohh... Solid technique. Continue."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:320
translate chinese CeR2_ES2_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:321
translate chinese CeR2_ES2_rep_8381282f:

    # MC "(God... This is so humiliating!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:322
translate chinese CeR2_ES2_rep_0a884fb0:

    # Celia "Ah... Yes..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:325
translate chinese CeR2_ES2_rep_f232b05d:

    # Celia "Ohh... Fuck... "
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:326
translate chinese CeR2_ES2_rep_387b72ea:

    # MC "*Lick* *Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:327
translate chinese CeR2_ES2_rep_00138d64:

    # Celia "Mmm, that’s good."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:330
translate chinese CeR2_ES2_rep_bd005120:

    # Celia "Oh, fuck... Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:331
translate chinese CeR2_ES2_rep_0b416c88:

    # Celia "*Pant* Whoa... Keep it up, boy."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:332
translate chinese CeR2_ES2_rep_73b98d33:

    # MC "*Slurp* *Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:335
translate chinese CeR2_ES2_rep_df483778:

    # Celia "Let’s speed things up a bit, now. Put that tongue to work!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:336
translate chinese CeR2_ES2_rep_d27930a6:

    # Celia "Unless, of course, you’d prefer me to bring Sara in here?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:337
translate chinese CeR2_ES2_rep_79380613:

    # MC "*LICK LICK LICK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:340
translate chinese CeR2_ES2_rep_397c84b3:

    # Celia "Haha! Ohh! I suspected ah... that would motivate you! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:342
translate chinese CeR2_ES2_rep_83357c3a:

    # Celia "Ohh! Fuck! Oh, yes!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:344
translate chinese CeR2_ES2_rep_99fb61cf:

    # MC "(Dammit! Why can’t she leave Sara out of this?! It has nothing to do with her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:346
translate chinese CeR2_ES2_rep_70cd97e9:

    # MC "(I know I fucked her through a toilet glory hole, but threatening to bring Sara into this is a dirty move! Even for her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:349
translate chinese CeR2_ES2_rep_e4536814:

    # MC "*LICK* *SLURP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:352
translate chinese CeR2_ES2_rep_1e576280:

    # Celia "Ahhh... Oh my God! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:355
translate chinese CeR2_ES2_rep_387b72ea_1:

    # MC "*Lick* *Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:357
translate chinese CeR2_ES2_rep_35485c82:

    # Celia "Ahh... I seem to have caught myself quite a prize! You’re not bad at eating pussy."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:358
translate chinese CeR2_ES2_rep_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:359
translate chinese CeR2_ES2_rep_134e3cde:

    # Celia "Ohh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:362
translate chinese CeR2_ES2_rep_7d0416d3:

    # Celia "Let’s bring your face in Mmm... even closer, shall we?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:363
translate chinese CeR2_ES2_rep_4b8d6185:

    # MC "Mppff!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:364
translate chinese CeR2_ES2_rep_a79ff2a8:

    # Celia "Ohhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:367
translate chinese CeR2_ES2_rep_f9ea5a90:

    # Celia "Mmm! Ahh, that’s it! Focus on my fucking clit! Ahh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:368
translate chinese CeR2_ES2_rep_7f879ec5:

    # MC "*SLURP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:369
translate chinese CeR2_ES2_rep_84016673:

    # Celia "(I’m getting so close to cumming!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:372
translate chinese CeR2_ES2_rep_65a58ca1:

    # Celia "Mmm! That’s it! Don’t stop! Ohh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:373
translate chinese CeR2_ES2_rep_47efa6ca:

    # MC "*LICK LICK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:374
translate chinese CeR2_ES2_rep_5c07f1b5:

    # Celia "Ah! AHH! AHHH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:377
translate chinese CeR2_ES2_rep_f6171b55:

    # Celia "Oh God! Yes! YES! AHHH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:378
translate chinese CeR2_ES2_rep_e12cbfe6:

    # MC "(Damn it! I’m not going to make this arrogant bitch cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:381
translate chinese CeR2_ES2_rep_7c5be389:

    # Celia "Don’t ah... stop! I’m soooohhhh close!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:382
translate chinese CeR2_ES2_rep_f050ce10_1:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:385
translate chinese CeR2_ES2_rep_00830872:

    # Celia "Huh? Dammit! I was so close!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:386
translate chinese CeR2_ES2_rep_f0f133f4:

    # MC "I’m not licking your stupid cunt anymore."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:389
translate chinese CeR2_ES2_rep_5885c297:

    # Celia "Well, is that so?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:390
translate chinese CeR2_ES2_rep_36086fbc:

    # Celia "Let me show you what happens to disobedient pets."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:397
translate chinese CeR2_ES2_rep_933aa022_1:

    # "*THUD*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:398
translate chinese CeR2_ES2_rep_e22b7fed:

    # MC "Ooofff!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:399
translate chinese CeR2_ES2_rep_8b7d0959:

    # MC "H-Hey! I’m sorry! Don’t hit me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:402
translate chinese CeR2_ES2_rep_654c6943:

    # Celia "You’re gonna get what’s coming to you, [player_name]! Wanna play BDSM with ME!?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:403
translate chinese CeR2_ES2_rep_a761ca53:

    # MC "N-No, let go of me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:406
translate chinese CeR2_ES2_rep_ba29a567:

    # Celia "I imagine this will leave quite a mark. I wonder how we’ll explain it to the Dean?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:407
translate chinese CeR2_ES2_rep_67c6ab31:

    # Celia "Perhaps you walked into the door by accident? That sounds like a good excuse."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:408
translate chinese CeR2_ES2_rep_cea225ce:

    # MC "N-No!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:411
translate chinese CeR2_ES2_rep_5ac48b80:

    # MC "P-Please! I’ll do anything! I’ll eat your pussy again!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:412
translate chinese CeR2_ES2_rep_8bb3cbf3:

    # MC "Just don’t punch me! (Fuck... I'm on the losing side today... I have no words...Judy was right from the beginning that she’s too experienced in that kind of thing.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:413
translate chinese CeR2_ES2_rep_328502cf:

    # MC "I’ll eat your ass if you want me to!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:419
translate chinese CeR2_ES2_rep_933aa022_2:

    # "*THUD*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:420
translate chinese CeR2_ES2_rep_77a612f3:

    # MC "AHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:421
translate chinese CeR2_ES2_rep_6c89c160:

    # MC "*Gasp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:424
translate chinese CeR2_ES2_rep_0e62c223:

    # Celia "I don’t want to bruise that pretty little face of yours. It looks far too good between my thighs."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:425
translate chinese CeR2_ES2_rep_34c6a48b:

    # MC "*Pant* *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:426
translate chinese CeR2_ES2_rep_4f599552:

    # Celia "I hope you learned a very valuable lesson today. Pets don’t disobey their masters. Okay?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:429
translate chinese CeR2_ES2_rep_8077b1c0:

    # Celia "I said, okay?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:430
translate chinese CeR2_ES2_rep_a6fbf3fc:

    # MC "Y-Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:431
translate chinese CeR2_ES2_rep_47000ecf:

    # Celia "Yes, what?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:434
translate chinese CeR2_ES2_rep_cc76e025:

    # MC "Y-Yes, Ma’am!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:435
translate chinese CeR2_ES2_rep_4ab90a2e_3:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:436
translate chinese CeR2_ES2_rep_82214382:

    # Celia "Good. It’ll serve you well to not forget it again. Now, close your eyes."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:439
translate chinese CeR2_ES2_rep_388bb296:

    # MC "*Whimper*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:440
translate chinese CeR2_ES2_rep_39410c06:

    # Celia "Ahh... Punching your face would have been such a waste."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:443
translate chinese CeR2_ES2_rep_3c427cbd:

    # Celia "*Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:444
translate chinese CeR2_ES2_rep_36793349:

    # MC "(She’s teasing me now. What the fuck does she want?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:447
translate chinese CeR2_ES2_rep_3c427cbd_1:

    # Celia "*Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:448
translate chinese CeR2_ES2_rep_ba14338e:

    # Celia "(I think I’m going to enjoy having [player_name] as my personal toy.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:451
translate chinese CeR2_ES2_rep_6fa67b2e:

    # Celia "I have to leave now. Someone will be wondering why I've been in here for such a long time."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:452
translate chinese CeR2_ES2_rep_4ab90a2e_4:

    # MC "*Gulp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:453
translate chinese CeR2_ES2_rep_ce43f2eb:

    # Celia "Now, where did I leave my skirt and panties."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:456
translate chinese CeR2_ES2_rep_34df74e5:

    # Celia "I’ll see you later, [player_name]."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:457
translate chinese CeR2_ES2_rep_4638c6c4:

    # Celia "Don’t forget, you’re mine forever. Anywhere, any place, and any time I ask."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:458
translate chinese CeR2_ES2_rep_2d204a49_3:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:459
translate chinese CeR2_ES2_rep_f7795790:

    # MC "Yes, Ma’am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:462
translate chinese CeR2_ES2_rep_ce699557:

    # Linda "Oh! How did it go with, [player_name]?"
    Linda ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:463
translate chinese CeR2_ES2_rep_33598ecc:

    # Celia "I might have to come over a couple more times. He needs some extra tuition."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:464
translate chinese CeR2_ES2_rep_47709908:

    # Linda "I’m sorry to hear that. Hopefully it won’t be too taxing for you."
    Linda ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:465
translate chinese CeR2_ES2_rep_708cf638:

    # Celia "I don’t mind, it’s my job. Thank you for letting me into your home today. You’ve really got a lovely place."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:466
translate chinese CeR2_ES2_rep_0f5847f6:

    # Linda "You’re very kind, Professor Celia. I’ll show you to the front door."
    Linda ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:469
translate chinese CeR2_ES2_rep_56e95c7d:

    # MC "God. Dammit."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:471
translate chinese CeR2_ES2_rep_6af3b5a3:

    # MC "(I am completely and utterly fucked.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:472
translate chinese CeR2_ES2_rep_d8e101e6:

    # MC "(She’s got me by the balls right now. I NEED to come up with a plan to escape from this. But how?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:474
translate chinese CeR2_ES2_rep_da46d111:

    # MC "(I can’t believe she actually came to my home! That said... I DID go to hers...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:475
translate chinese CeR2_ES2_rep_096f68b0:

    # MC "(I wasn’t expecting her to become the dominant one. I wonder if Judy can give me any advice on how to regain some superiority here?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:481
translate chinese CeR2_ES2_rep_3c726d8a_1:

    # "*WHACK*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:482
translate chinese CeR2_ES2_rep_e82436e1:

    # MC "ARRRGGGHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:483
translate chinese CeR2_ES2_rep_87c0a1d9:

    # MC "FUCK! SHIT!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:488
translate chinese CeR2_ES2_rep_b4b0d056:

    # "*WHAM*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:491
translate chinese CeR2_ES2_rep_9c509c21:

    # MC "Ouch..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:492
translate chinese CeR2_ES2_rep_884065f9:

    # MC "(How the fuck did Celia punch the floor without batting an eyelid?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_ES2_rep.rpy:493
translate chinese CeR2_ES2_rep_098763cf:

    # MC "(That bitch is strong.)"
    MC ""

