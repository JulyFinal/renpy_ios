﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:17
translate chinese CR3_AS9_rep_84f6c20a:

    # Violet "Well, that went better than I thought it would! That ugly pink dressing gown ain’t half as bad when it’s got violet lying on top of it!"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:18
translate chinese CR3_AS9_rep_e7180605:

    # Violet "Anyway, I gotta dash, guys - everyone is waiting for me at the party."
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:19
translate chinese CR3_AS9_rep_501bd510:

    # Violet "See ya later!"
    Violet ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:24
translate chinese CR3_AS9_rep_b24118d3:

    # MC "Well... That’s her gone now. Finally, there’s some privacy, for just you and me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:25
translate chinese CR3_AS9_rep_1ac8660b:

    # Caroline "Mmm, there definitely is."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:26
translate chinese CR3_AS9_rep_24c072d7:

    # MC "And didn’t you mention something about us fooling around after she left?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:31
translate chinese CR3_AS9_rep_87ff72ba:

    # Caroline "Did I really say that? I don’t remember."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:32
translate chinese CR3_AS9_rep_301472fc:

    # MC "Oh yeah, I’ll quote you. You said, ‘As soon as Violet leaves, I’m gonna rip my panties off and bounce up and down on your thick co-’"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:33
translate chinese CR3_AS9_rep_7efc61cb:

    # Caroline "Oh, HA HA! Very funny..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:37
translate chinese CR3_AS9_rep_8a22fa87:

    # MC "Let’s take this silly thing off. I want to see your eyes."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:38
translate chinese CR3_AS9_rep_f0f01808:

    # MC "Your eyes are gorgeous - you know that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:39
translate chinese CR3_AS9_rep_991bee90:

    # Caroline "They’re nothing special."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:40
translate chinese CR3_AS9_rep_b96d8675:

    # MC "Well, they’re special to me. You may as well call them a maze - because I’m getting lost in them."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:41
translate chinese CR3_AS9_rep_04bb087e:

    # Caroline "Hehe, where’d you find that line? The internet?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:42
translate chinese CR3_AS9_rep_0938400b:

    # MC "No - deep within my heart."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:46
translate chinese CR3_AS9_rep_5313da11:

    # Caroline "God, you’re so corny. Just stop talking, and kiss me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:47
translate chinese CR3_AS9_rep_f40a3bed:

    # MC "(I love being able to make her smile like that. I think, deep down, she really enjoys those cheesy lines.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:51
translate chinese CR3_AS9_rep_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:52
translate chinese CR3_AS9_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:53
translate chinese CR3_AS9_rep_70965f52:

    # MC "(If it wasn’t for this godforsaken dressing gown, everything would be perfect right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:57
translate chinese CR3_AS9_rep_724e8c24:

    # MC "(Ah well, I’ll just try to put it out of my head and enjoy the moment.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:58
translate chinese CR3_AS9_rep_5015ce69:

    # Caroline "Mmm! (God, he tastes so good... Why is he so irresistible?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:62
translate chinese CR3_AS9_rep_60987446:

    # Caroline "(Every single time I kiss him like this, my mind just goes blank. It’s hard to put it into words, even in my own mind. But it feels like all my cares and problems are simply melting away into nothingness.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:63
translate chinese CR3_AS9_rep_d4f607ad:

    # Caroline "(It feels a bit like how I imagine absolute safety to feel.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:67
translate chinese CR3_AS9_rep_8aa300b4:

    # Caroline "(It’s like a log cabin with a blazing hearth, in the middle of a blizzard - or the basement during a hurricane. There’s something serene and secure to his kisses.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:68
translate chinese CR3_AS9_rep_1f9bb450:

    # MC "(Almost as if, all the problems are ‘out there’, far away where - they can’t hurt you.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:72
translate chinese CR3_AS9_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:73
translate chinese CR3_AS9_rep_0566c072:

    # Caroline "(No financial stress. No tax returns. No abusive ex-boyfriend.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:74
translate chinese CR3_AS9_rep_43d1480a:

    # Caroline "(Just [player_name].)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:75
translate chinese CR3_AS9_rep_5f0c5a10:

    # Caroline "([player_name] and his succulent lips.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:79
translate chinese CR3_AS9_rep_d65408c3:

    # Caroline "Wow..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:80
translate chinese CR3_AS9_rep_baab58ba:

    # MC "You enjoyed that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:81
translate chinese CR3_AS9_rep_2b656ab2:

    # Caroline "Kissing you is amazing, and I could do it forever. HOWEVER! I did promise you that we would fool around."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:85
translate chinese CR3_AS9_rep_314698f9:

    # Caroline "So, what’s it gonna be for you? Handjob or footjob?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:86
translate chinese CR3_AS9_rep_f4534e9e:

    # MC "Hmm, it’s a tough choice."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:92
translate chinese CR3_AS9_rep_5673f0d6:

    # MC "Okay, I’ve decided. I want you to give me a handjob."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:93
translate chinese CR3_AS9_rep_1e8ece20:

    # Caroline "Great! Let’s get started."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:96
translate chinese CR3_AS9_rep_bc9f9f17:

    # Caroline "Um... before I wank you off, can you do one thing for me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:97
translate chinese CR3_AS9_rep_b0d91b5e:

    # MC "Certainly. What is it?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:98
translate chinese CR3_AS9_rep_8f9a2032:

    # Caroline "Can you strip out of that disgusting pink abomination?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:99
translate chinese CR3_AS9_rep_50955101:

    # MC "Haha! Sure!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:100
translate chinese CR3_AS9_rep_917e6922:

    # Caroline "Come and stand in front of me, when you’re done - but face away from me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:104
translate chinese CR3_AS9_rep_e50b0aca:

    # MC "Do you mean like this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:105
translate chinese CR3_AS9_rep_3de31fe2:

    # Caroline "Yeah, that’s great. We’re gonna vary things up a bit tonight. Gotta keep these handjobs fresh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:106
translate chinese CR3_AS9_rep_1cfe8475:

    # Caroline "(God... he’s so huge! Just look at the size of his cock, compared to my fingers!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:110
translate chinese CR3_AS9_rep_95efe868:

    # Caroline "(What would that feel like inside me? Would it even fit properly in my pussy, without hurting me?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:111
translate chinese CR3_AS9_rep_d2e70306:

    # Caroline "(My ex wasn’t that thick. [player_name] is so much better!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:112
translate chinese CR3_AS9_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:116
translate chinese CR3_AS9_rep_dea714cb:

    # MC "Oohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:117
translate chinese CR3_AS9_rep_ade9a61b:

    # MC "(Her hands are so soft. It feels great when she strokes my cock like this.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:118
translate chinese CR3_AS9_rep_3f160688:

    # Caroline "(It sounds like he’s really enjoying this! I wonder what else I can do to spice things up.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:122
translate chinese CR3_AS9_rep_cb2ca102:

    # Caroline "(He’s still getting harder! I didn’t know guys were like this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:124
translate chinese CR3_AS9_rep_aea4f24c:

    # Caroline "(I mean, how much bigger can his cock swell?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:125
translate chinese CR3_AS9_rep_05d1b90c_1:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:130
translate chinese CR3_AS9_rep_cb58d288:

    # Caroline "You’re really enjoying this, aren’t you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:131
translate chinese CR3_AS9_rep_86e7e604:

    # MC "Ah... yes..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:132
translate chinese CR3_AS9_rep_f2403500:

    # Caroline "You love it when I wrap my fingers around your fat dick and stroke it up and down, don’t you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:136
translate chinese CR3_AS9_rep_2b7252bb:

    # MC "Ah... It’s so good..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:138
translate chinese CR3_AS9_rep_f921e2be:

    # Caroline "Oh yeah, just look at you, getting SOOOO hard because your sister is touching your dick. We’re not even dating and you’re so erect right now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:140
translate chinese CR3_AS9_rep_daa97a17:

    # Caroline "Oh yeah, just look at you, getting SOOOOO hard when I'm touching your dick. We're not even dating and you're so erect right now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:141
translate chinese CR3_AS9_rep_9577d6d9:

    # MC "(God, I love it when she talks dirty.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:145
translate chinese CR3_AS9_rep_5ac00b08:

    # Caroline "Would you get this hard for any other girl? Or is it the thrill of knowing how BAD it is that your older sister is the one wanking you off?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:147
translate chinese CR3_AS9_rep_a146b6f4:

    # Caroline "Would you get this hard for any other girl? Or is it the thrill of knowing how BAD it is that your best friend is the one wanking you off?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:148
translate chinese CR3_AS9_rep_4b630759:

    # MC "Oh... Ah... Hnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:149
translate chinese CR3_AS9_rep_b7bafb97:

    # Caroline "Mmm... this is SO naughty!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:154
translate chinese CR3_AS9_rep_f63924f5:

    # Caroline "What would [Linda_name] say if I told her you were getting wanked off by me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:156
translate chinese CR3_AS9_rep_f326587b:

    # Caroline "Hmm? She’d probably be furious."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:157
translate chinese CR3_AS9_rep_4f2631b0:

    # Caroline "Or maybe just shocked that you are perverted enough to get off to the thought of your older sister rubbing your cock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:159
translate chinese CR3_AS9_rep_fb5adebb:

    # Caroline "Hmm... I don't know how Linda would react to her tenants mingling. It's not something I've ever thought about."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:160
translate chinese CR3_AS9_rep_b2d388d1:

    # Caroline "Or maybe just shocked that you are perverted enough to get off to the thought of your best friend rubbing your cock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:164
translate chinese CR3_AS9_rep_cb1c0d6b:

    # Caroline "(Damn... I’ve turned myself on, with all that dirty talk... That wasn’t part of the plan!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:165
translate chinese CR3_AS9_rep_5e693abd:

    # Caroline "(Goddamnit... I’ve SOAKED these panties!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:166
translate chinese CR3_AS9_rep_6ae97228:

    # MC "Huh? Why’d you stop? Is something wrong?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:167
translate chinese CR3_AS9_rep_eba4708c:

    # Caroline "Um... could you... turn around?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:171
translate chinese CR3_AS9_rep_54c797f2:

    # Caroline "(I get to watch his dick now, while I wank him off. This will be so much more fun!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:172
translate chinese CR3_AS9_rep_365afdc9:

    # MC "Like this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:173
translate chinese CR3_AS9_rep_5a9d211f:

    # Caroline "Y-Yeah, just like that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:177
translate chinese CR3_AS9_rep_90418a0a:

    # Caroline "(Fuck... I can’t think straight, right now. I just want to rip my clothes off and screw him silly!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:178
translate chinese CR3_AS9_rep_90d97c60:

    # Caroline "(I need to hold it together! I can’t let myself give into my lust!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:179
translate chinese CR3_AS9_rep_f689fc9f:

    # MC "You stopped again, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:183
translate chinese CR3_AS9_rep_bfe58101:

    # Caroline "Umm... Sorry, I got distracted."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:184
translate chinese CR3_AS9_rep_411dadf5:

    # MC "Something on your mind?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:185
translate chinese CR3_AS9_rep_c9221558:

    # Caroline "No! Just... just enjoy your handjob."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:189
translate chinese CR3_AS9_rep_4c277dce:

    # Caroline "(Fuck... I can feel it throbbing beneath my fingers. It feels so exciting!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:190
translate chinese CR3_AS9_rep_d527904e:

    # Caroline "(If only I could feel that, throbbing deep inside my cunt...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:191
translate chinese CR3_AS9_rep_b0dcb567:

    # MC "Ah... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:195
translate chinese CR3_AS9_rep_868bc360:

    # Caroline "(Fuck, I can’t resist it anymore! I have to touch myself!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:196
translate chinese CR3_AS9_rep_e5c707e5:

    # Caroline "Ah... Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:197
translate chinese CR3_AS9_rep_fe54fda8:

    # MC "Ah... Ugh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:201
translate chinese CR3_AS9_rep_378562f0:

    # MC "(Oh shit! She’s masturbating too! She must have excited herself a bit too much!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:202
translate chinese CR3_AS9_rep_165f0f1f:

    # Caroline "Oh... Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:203
translate chinese CR3_AS9_rep_2dd122d1:

    # MC "(I guess it could be my turn to try talking dirty.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:207
translate chinese CR3_AS9_rep_71be6951:

    # MC "You’re imagining it inside you right now, aren’t you? Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:208
translate chinese CR3_AS9_rep_ea84f9ed:

    # Caroline "N-No... Oh... Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:209
translate chinese CR3_AS9_rep_0a89df49:

    # MC "Maybe just my fingers, then? Plunging in and out of your wet pussy. Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:213
translate chinese CR3_AS9_rep_f53f3b4d:

    # Caroline "Oh God... fuck... Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:214
translate chinese CR3_AS9_rep_f905e2fb:

    # MC "Hnng... (Damn, I’m gonna blow my load soon!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:215
translate chinese CR3_AS9_rep_d4eafa77:

    # Caroline "Ah! Ah! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:219
translate chinese CR3_AS9_rep_aafe303b:

    # MC "Hnnnnnggg! I’m gonna cum! AHHHHH!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:220
translate chinese CR3_AS9_rep_443d6580:

    # Caroline "(Holy fuck... he sounds so manly when he cums... God, I’m so turned on right now.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:221
translate chinese CR3_AS9_rep_65af195b:

    # Caroline "Ahh! AHHH! Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:225
translate chinese CR3_AS9_rep_f2634aca:

    # Caroline "Cum for me! Cum for your big sister!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:227
translate chinese CR3_AS9_rep_540b93b8:

    # Caroline "Cum for me! I want to hear you cum!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:228
translate chinese CR3_AS9_rep_5894548f:

    # MC "HNNNG!!! AHHHHHH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:239
translate chinese CR3_AS9_rep_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:240
translate chinese CR3_AS9_rep_0fd97cfc:

    # Caroline "(Wow... So much cum! He must have been saving that up for days!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:241
translate chinese CR3_AS9_rep_e699dd7b:

    # Caroline "(I don’t recall ever seeing someone in porn, shooting this much cum!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:248
translate chinese CR3_AS9_rep_77991bab:

    # MC "Let’s go for a footjob today."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:249
translate chinese CR3_AS9_rep_8cc179fc:

    # Caroline "Okay! I’ll just slip my shoes off here, and then we’ll be ready to go."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:253
translate chinese CR3_AS9_rep_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:254
translate chinese CR3_AS9_rep_2afa6563:

    # Caroline "(It’s nice to take those things off. High heels look great - but they can really kill your ankles!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:255
translate chinese CR3_AS9_rep_f9502a81:

    # Caroline "Would you like me to slip my tights off too? Or shall I just rub your cock with these stockings on?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:256
translate chinese CR3_AS9_rep_4c77ee64:

    # MC "Keep the stockings on!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:260
translate chinese CR3_AS9_rep_3686debe:

    # Caroline "Okay, [player_name]. Your wish is my command."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:261
translate chinese CR3_AS9_rep_681eff83:

    # MC "Mmm, oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:262
translate chinese CR3_AS9_rep_2242e00f:

    # Caroline "Y’know, I don’t know anyone else with a foot fetish, besides you..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:266
translate chinese CR3_AS9_rep_5e9e4dec:

    # Caroline "I guess it's a good thing, because I'm starting to love it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:268
translate chinese CR3_AS9_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:269
translate chinese CR3_AS9_rep_5edcb13c:

    # Caroline "I’m not gonna lie - I still remember the first time you asked me. I was shocked! It wasn’t something that I considered part of a normal sexual relationship."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:273
translate chinese CR3_AS9_rep_bfe53aee:

    # Caroline "I’d always viewed it as kinda like BDSM, y’know? Something that you hear about online and in TV shows, but nobody ever really does it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:274
translate chinese CR3_AS9_rep_d8e99da4:

    # MC "Uh huh... Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:275
translate chinese CR3_AS9_rep_8da73a24:

    # Caroline "I guess my opinion of it changed, the more we did it. I’m growing... used to it now. I mean, it really isn’t THAT kinky, is it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:279
translate chinese CR3_AS9_rep_af5fbd9d:

    # Caroline "Certainly not in the grand scheme of things."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:280
translate chinese CR3_AS9_rep_baf6e51e:

    # Caroline "It’s just like giving a handjob - except you’re using your feet instead. How long have you been interested in feet, [player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:281
translate chinese CR3_AS9_rep_72d37621:

    # MC "Ah... I... umm... don’t know... oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:285
translate chinese CR3_AS9_rep_62ef7d2c:

    # Caroline "Hmm, can you even remember a time when you didn’t want a sexy girl to rub, her pretty little feet, all over your shaft?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:286
translate chinese CR3_AS9_rep_0fcf0880:

    # MC "Mmm! N-No..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:287
translate chinese CR3_AS9_rep_7e6a944a:

    # Caroline "Oh, so you’ve always liked them, then?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:291
translate chinese CR3_AS9_rep_31738bab:

    # Caroline "I’m making this up as I go along, and unfortunately I don’t have a cock of my own - but I imagine that doing this should feel REALLY good, right?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:292
translate chinese CR3_AS9_rep_b2d5fa12:

    # MC "Oh yeah, that’s great, Caroline. Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:293
translate chinese CR3_AS9_rep_36ca71b5:

    # Caroline "Hehe, I’m glad you’re enjoying this. It’s kinda therapeutic, in a strange way."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:297
translate chinese CR3_AS9_rep_979cc4ac:

    # Caroline "I love the way you squirm when I wrap my toes around the tip of your cock, just like this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:298
translate chinese CR3_AS9_rep_8972f772:

    # Caroline "It’s just so sexy to know that I’ve got such control over your body, with something as simple as my feet."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:299
translate chinese CR3_AS9_rep_c7d4d769:

    # Caroline "Perhaps that’s what turns you on about this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:303
translate chinese CR3_AS9_rep_05e23b28:

    # MC "Ooohhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:304
translate chinese CR3_AS9_rep_b06caed9:

    # Caroline "Oh yeah, that’s the spot I need to work, isn’t it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:305
translate chinese CR3_AS9_rep_aec01713:

    # Caroline "I suppose the velvety texture of my stockings, only makes things better."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:309
translate chinese CR3_AS9_rep_6b782471:

    # Caroline "I wonder which you prefer - the soft, warm touch of my naked soles...."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:310
translate chinese CR3_AS9_rep_0bdb3351:

    # Caroline "...or the feeling of these silky tights?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:311
translate chinese CR3_AS9_rep_1b31110a:

    # Caroline "Be a good boy and lie down for me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:315
translate chinese CR3_AS9_rep_56b80909:

    # Caroline "Yes, perfect."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:316
translate chinese CR3_AS9_rep_2394cb90:

    # Caroline "I hope you’re enjoying the view, [player_name] - because I’m loving mine."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:317
translate chinese CR3_AS9_rep_da13ff2a:

    # MC "(She seems to be getting more and more into footjobs, the more we do them!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:321
translate chinese CR3_AS9_rep_c1170cce_1:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:322
translate chinese CR3_AS9_rep_eb661620:

    # Caroline "Let’s see if I can make you cum, using only my feet."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:325
translate chinese CR3_AS9_rep_3073637e:

    # Caroline "Do you always get this hard thinking about women’s feet? Or is there a special allure to knowing that they belong to your big sister?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:327
translate chinese CR3_AS9_rep_05035a27:

    # Caroline "Do you always get this hard thinking about women’s feet? Or is there a special allure about your best friend using her feet?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:332
translate chinese CR3_AS9_rep_1bdda0f6:

    # MC "Ah... (I don’t think she wants me to reply. She’s probably just enjoying monologuing while she teases me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:333
translate chinese CR3_AS9_rep_08ed5050:

    # Caroline "Whenever you’re about to cum, you’re gonna have to tell me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:334
translate chinese CR3_AS9_rep_f373faf3:

    # Caroline "I know you REALLY want to shoot your cum all over my feet - but this outfit is expensive, and I don’t want white stains on it the first time I’m wearing it!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:339
translate chinese CR3_AS9_rep_b6927d8b:

    # MC "Hnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:340
translate chinese CR3_AS9_rep_6bf68204:

    # Caroline "So be a good boy and tell me when you’re about to cum, okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:341
translate chinese CR3_AS9_rep_8dc25ff2:

    # MC "Ah... Y-Yeah, I will... Hnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:345
translate chinese CR3_AS9_rep_9526e5ef:

    # Caroline "(God, this is so much fun! Why did I never try this sooner?! So many wasted years!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:346
translate chinese CR3_AS9_rep_f83ce374:

    # Caroline "(At least I’ve got a willing participant now, who can help me make up for lost time!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:347
translate chinese CR3_AS9_rep_2a51d5f8:

    # MC "Ah! Ah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:351
translate chinese CR3_AS9_rep_9e04eeea:

    # Caroline "(Well, there’s no reason why I shouldn’t enjoy myself too. I’m soaked right now - and why should [player_name] have all the fun?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:352
translate chinese CR3_AS9_rep_4bb41bc9:

    # Caroline "Ah... Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:353
translate chinese CR3_AS9_rep_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:357
translate chinese CR3_AS9_rep_5f076627:

    # MC "(Oh wow! She’s actually masturbating in front of me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:358
translate chinese CR3_AS9_rep_61900e35:

    # Caroline "Ah... yes... You love that, don’t you? Ohh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:359
translate chinese CR3_AS9_rep_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:363
translate chinese CR3_AS9_rep_b8cb9c46:

    # Caroline "You’re getting very loud there, [player_name]. You’re about to cum, aren’t you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:364
translate chinese CR3_AS9_rep_a9ff199c:

    # MC "Y-Yeah! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:366
translate chinese CR3_AS9_rep_204dd0e4:

    # Caroline "Cum for me. Cum for your big sister, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:368
translate chinese CR3_AS9_rep_bd9badea:

    # Caroline "Cum for me. I want you to cum for me, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:371
translate chinese CR3_AS9_rep_e5ff163c:

    # MC "Ahh! AHHH!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:373
translate chinese CR3_AS9_rep_eff45f29:

    # Caroline "Oh! Ohh! Yes! Ah!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:374
translate chinese CR3_AS9_rep_5002e198:

    # MC "Hnnnnnggg! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:384
translate chinese CR3_AS9_rep_2f7b3b4b_1:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:385
translate chinese CR3_AS9_rep_5e616733:

    # Caroline "Hehe. You enjoyed that, didn’t you? You’re such a little slut for feet."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:386
translate chinese CR3_AS9_rep_875c686a:

    # Caroline "I’ll keep that in mind if I ever need to get you off quickly."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:393
translate chinese CR3_AS9_O4_con3_rep_c31b3304:

    # Caroline "Well, we’ve had our fun... I better get changed now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:394
translate chinese CR3_AS9_O4_con3_rep_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:396
translate chinese CR3_AS9_O4_con3_rep_e9d978b2:

    # Caroline "I’ve got A LOT to do... business stuff, laundry..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:400
translate chinese CR3_AS9_O4_con3_rep_ee869cc9:

    # MC "Hey! I’m not letting you run off on me again. It’s not fair that I’m the one who has all the fun."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:401
translate chinese CR3_AS9_O4_con3_rep_2ca77eb7:

    # Caroline "R-Really! I’m fine, you don’t need to worry about me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:405
translate chinese CR3_AS9_O4_con3_rep_56ca49bb:

    # MC "Oh c’mon, we made a deal! Not a one-sided arrangement, where you’re the one who does ALL the pleasuring!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:406
translate chinese CR3_AS9_O4_con3_rep_1f5fea1a:

    # Caroline "H-Hey! What are you doing?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:410
translate chinese CR3_AS9_O4_con3_rep_5c634e95:

    # MC "I’m gonna give you some pleasure too!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:411
translate chinese CR3_AS9_O4_con3_rep_9a468bdd:

    # Caroline "W-Wait-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:412
translate chinese CR3_AS9_O4_con3_rep_11eb55f1:

    # MC "Take a seat!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:418
translate chinese CR3_AS9_O4_con3_rep_1dc26ac5:

    # Caroline "Oof!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:419
translate chinese CR3_AS9_O4_con3_rep_dd5ad2b9:

    # Caroline "R-Really! I’m fine! You don’t need to worry. I can take care of myself and-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:420
translate chinese CR3_AS9_O4_con3_rep_de01fb31:

    # MC "You won’t need to take care of yourself. I’ll be here to help relieve you, instead."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:424
translate chinese CR3_AS9_O4_con3_rep_aa9024b1:

    # MC "I mean, you’re not seriously going to turn down a real man and then run off for a dildo? I mean, I’ve HEARD you masturbating every night. I KNOW how horny you get."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:425
translate chinese CR3_AS9_O4_con3_rep_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:426
translate chinese CR3_AS9_O4_con3_rep_ec15a765:

    # Caroline "Wh-What are you gonna do?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:427
translate chinese CR3_AS9_O4_con3_rep_134bd598:

    # MC "I’m gonna strip your panties off, and then lick your pussy until you’ve cum."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:431
translate chinese CR3_AS9_O4_con3_rep_f28dd19e:

    # Caroline "Ah... O-Okay... but this is a ONE TIME thing. Got it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:432
translate chinese CR3_AS9_O4_con3_rep_f6e4b451:

    # MC "Uh huh."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:433
translate chinese CR3_AS9_O4_con3_rep_af8abdbf:

    # Caroline "I’m serious, [player_name]. This isn’t a permanent alteration to our deal!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:437
translate chinese CR3_AS9_O4_con3_rep_49e6a328:

    # MC "Just relax and try to enjoy this. You’re worrying far too much."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:438
translate chinese CR3_AS9_O4_con3_rep_ba1e2f34:

    # Caroline "I don’t even know if I’ll be able to cum if you’re doing that. No one’s ever gone down on-."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:439
translate chinese CR3_AS9_O4_con3_rep_d7774dfe:

    # MC "Trust me. You’ll cum."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:443
translate chinese CR3_AS9_O4_con3_rep_a90970e7:

    # Caroline "(Well, he’s confident. I’ll give him that!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:444
translate chinese CR3_AS9_O4_con3_rep_1449f8d6:

    # MC "(Okay, let’s give Caroline the best pussy eating she’s ever had!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:445
translate chinese CR3_AS9_O4_con3_rep_2faaf8ad:

    # MC "(I’ll have her shaking and squealing my name, by the time I’m done with her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:449
translate chinese CR3_AS9_O4_con3_rep_b7c518c4:

    # MC "Just move your ankles a little bit more so I can get these off."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:450
translate chinese CR3_AS9_O4_con3_rep_9ccb25ef:

    # Caroline "Is that okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:451
translate chinese CR3_AS9_O4_con3_rep_1c0a41d6:

    # MC "Good. okay, here we go!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:455
translate chinese CR3_AS9_O4_con3_rep_6e22eaf1_1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:456
translate chinese CR3_AS9_O4_con3_rep_53baca74:

    # MC "You sound nervous. Just try to relax."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:457
translate chinese CR3_AS9_O4_con3_rep_64d0457c:

    # Caroline "Okay... I’ll try..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:458
translate chinese CR3_AS9_O4_con3_rep_9fd3bf3c:

    # MC "And... I’m gonna need you to spread your legs too. Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:459
translate chinese CR3_AS9_O4_con3_rep_565deb4e:

    # Caroline "Oops... Sorry..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:463
translate chinese CR3_AS9_O4_con3_rep_cf74c3a7:

    # MC "(Alright, here we go. Let’s see what I can do.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:465
translate chinese CR3_AS9_O4_con3_rep_7020cf25:

    # MC "(I should start, by focusing on her clit - she’s already wet and sensitive. I can kick things off by lapping my tongue across that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:469
translate chinese CR3_AS9_O4_con3_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:470
translate chinese CR3_AS9_O4_con3_rep_638f29e8:

    # Caroline "Mmmm! Ahmmmmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:471
translate chinese CR3_AS9_O4_con3_rep_89f5b465:

    # MC "(It sounds like she’s stifling her moans! I must be licking the right places!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:475
translate chinese CR3_AS9_O4_con3_rep_347ad41f:

    # Caroline "(Oh, my God! It feels incredible!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:476
translate chinese CR3_AS9_O4_con3_rep_5acb7402:

    # Caroline "(How does he know where to touch?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:477
translate chinese CR3_AS9_O4_con3_rep_e1c28c43:

    # Caroline "(His tongue is so hot and flexible... God... It’s like my dildo on steroids!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:482
translate chinese CR3_AS9_O4_con3_rep_e743d242:

    # MC "*Lick Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:483
translate chinese CR3_AS9_O4_con3_rep_8b510b17:

    # Caroline "Ahh! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:484
translate chinese CR3_AS9_O4_con3_rep_02c7e5cf:

    # MC "(Her legs are quivering like crazy, right now! I think she’s about to cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:488
translate chinese CR3_AS9_O4_con3_rep_83bd14bb_1:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:489
translate chinese CR3_AS9_O4_con3_rep_126ee468:

    # Caroline "Ohhhh! MMMM!! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:493
translate chinese CR3_AS9_O4_con3_rep_c298f5f7:

    # MC "*Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:494
translate chinese CR3_AS9_O4_con3_rep_ccdb4109:

    # Caroline "(How the heck is he SOOO good at this?! He’s barely been going for thirty seconds, and I’m already melting!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:495
translate chinese CR3_AS9_O4_con3_rep_4b2980e0:

    # Caroline "(Shit! I think I’m gonna cum!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:499
translate chinese CR3_AS9_O4_con3_rep_1060eba7:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:500
translate chinese CR3_AS9_O4_con3_rep_3b66b146:

    # Caroline "AHHHHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:501
translate chinese CR3_AS9_O4_con3_rep_e8f0723e:

    # Caroline "(Oh God! He’s sucking on my clitoris! It’s so fucking good! I’m gonna cum!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:505
translate chinese CR3_AS9_O4_con3_rep_fa663386:

    # Caroline "Hnnnnnnggg! UGH! AAAAHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:506
translate chinese CR3_AS9_O4_con3_rep_12d659e0:

    # MC "(Yup! That’s her cumming! I guess she never expected me to be THIS good with my mouth!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:507
translate chinese CR3_AS9_O4_con3_rep_94f648cd:

    # MC "(Given how well I performed, I won’t be surprised if Caroline WANTS to permanently alter our deal to include cunnilingus!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:511
translate chinese CR3_AS9_O4_con3_rep_d8d38d0d:

    # Caroline "*Pant* Wow..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:512
translate chinese CR3_AS9_O4_con3_rep_7bedc530:

    # MC "Heh, I’m glad you enjoyed that. I’ll let you get changed now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:513
translate chinese CR3_AS9_O4_con3_rep_42fab5a1:

    # Caroline "Huh? What makes you think we’re finished?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:518
translate chinese CR3_AS9_O4_con3_rep_c42ad36b:

    # MC "Oof!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:519
translate chinese CR3_AS9_O4_con3_rep_c556cf9d:

    # MC "(Jesus! What’s gotten into her?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:520
translate chinese CR3_AS9_O4_con3_rep_18a3281b:

    # MC "What are you doing, Caroline?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:524
translate chinese CR3_AS9_O4_con3_rep_2589a47b:

    # Caroline "I haven’t had my pussy licked in my life before - I’m not letting you get away with just one session!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:525
translate chinese CR3_AS9_O4_con3_rep_1611e239:

    # MC "You want to go again?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:526
translate chinese CR3_AS9_O4_con3_rep_4cd0b892:

    # Caroline "Unlike men, women are capable of having multiple orgasms before we tire out."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:530
translate chinese CR3_AS9_O4_con3_rep_2044d277:

    # Caroline "I hope you’ve still got some energy left in that tongue of yours!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:531
translate chinese CR3_AS9_O4_con3_rep_ca47bd6b:

    # MC "(Holy shit, she’s serious! I’ve never seen her this horny before!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:535
translate chinese CR3_AS9_O4_con3_rep_5ff58e26:

    # Caroline "Mmm... That’s it..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:536
translate chinese CR3_AS9_O4_con3_rep_4742d564:

    # Caroline "Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:537
translate chinese CR3_AS9_O4_con3_rep_83bd14bb_2:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:541
translate chinese CR3_AS9_O4_con3_rep_63ffde6d:

    # Caroline "God... Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:542
translate chinese CR3_AS9_O4_con3_rep_3b13ab3e:

    # Caroline "Bury your tongue deep inside me! Fuck! Move it everywhere... Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:543
translate chinese CR3_AS9_O4_con3_rep_99bff545:

    # MC "(I knew she’d enjoy me eating her pussy out - but I never realised it would feel THIS good for her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:547
translate chinese CR3_AS9_O4_con3_rep_c298f5f7_1:

    # MC "*Shlurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:548
translate chinese CR3_AS9_O4_con3_rep_7e31b53f:

    # Caroline "Oooohhh! Yesssss! Mmm! Fuck!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:549
translate chinese CR3_AS9_O4_con3_rep_b302c924:

    # MC "(She tastes delicious! I could lick and suck at her pussy all day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:553
translate chinese CR3_AS9_O4_con3_rep_8d9183bd:

    # Caroline "Ah! Oh yes! Don’t stop!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:554
translate chinese CR3_AS9_O4_con3_rep_d8e039ca:

    # MC "*SUCK* *SHLURP*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:555
translate chinese CR3_AS9_O4_con3_rep_5db89485:

    # Caroline "Deeper! Faster! MMM!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:559
translate chinese CR3_AS9_O4_con3_rep_284535ac:

    # Caroline "Yessss.... Lick my fucking pussy! Suck on my little clitty! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:560
translate chinese CR3_AS9_O4_con3_rep_1060eba7_1:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:561
translate chinese CR3_AS9_O4_con3_rep_e72fe17d:

    # Caroline "(God... why didn’t I think to put this in the original deal?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:565
translate chinese CR3_AS9_O4_con3_rep_8980eb2f:

    # Caroline "(I could have saved a FORTUNE in batteries for my vibrator!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:566
translate chinese CR3_AS9_O4_con3_rep_97d49009:

    # Caroline "Hnnng...."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:567
translate chinese CR3_AS9_O4_con3_rep_d2b3b753:

    # Caroline "(Okay, here we go - time for orgasm number two!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:571
translate chinese CR3_AS9_O4_con3_rep_c964e84a:

    # Caroline "AHH! AHHH! AHHHHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:573
translate chinese CR3_AS9_O4_con3_rep_d6f82fc5:

    # Caroline "(Thank God we’re not at home - I couldn’t scream like this in the house, without Mom or Sara hearing me!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:574
translate chinese CR3_AS9_O4_con3_rep_851a5c86:

    # Caroline "(Actually, come to think of it, it’s probably a good thing that I DIDN’T include this in the deal! There’s no way I’d be able to resist him doing this, and I’d probably just end up accidentally ruining it, by attracting our family’s attention to our little deal.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:576
translate chinese CR3_AS9_O4_con3_rep_2bcf7df6:

    # Caroline "(Thank God we’re not at home - I couldn’t scream like this in the house, without Linda or Sara hearing me!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:577
translate chinese CR3_AS9_O4_con3_rep_63b5b351:

    # Caroline "(Actually, come to think of it, it’s probably a good thing that I DIDN’T include this in the deal! There’s no way I’d be able to resist him doing this, and I’d probably just end up accidentally ruining it, by attracting our roommates attention to our little deal.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:581
translate chinese CR3_AS9_O4_con3_rep_50470947:

    # MC "(Wow! Her juices are flowing all over my face, right now! She’s rocking back and forth like crazy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:582
translate chinese CR3_AS9_O4_con3_rep_4f8262fc:

    # Caroline "Hnnnnnggg! AAAAAHHHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:583
translate chinese CR3_AS9_O4_con3_rep_dda296d9:

    # Caroline "C-CUMMMMIINNNNNGGG!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:587
translate chinese CR3_AS9_O4_con3_rep_9fc85780:

    # Caroline "*Pant* *Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:588
translate chinese CR3_AS9_O4_con3_rep_f123d99f:

    # Caroline "H-H-Holy... Shit... Wow..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:589
translate chinese CR3_AS9_O4_con3_rep_88b845cc:

    # MC "(She’s still trembling, after she came! I guess things got a WHOLE lot more sensitive the second time around!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:593
translate chinese CR3_AS9_O4_con3_rep_28aebe7a:

    # MC "Hehe, so - what was that you were saying about me not being able to make you cum?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:594
translate chinese CR3_AS9_O4_con3_rep_f2dbb8cb:

    # Caroline "*Ahem*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:595
translate chinese CR3_AS9_O4_con3_rep_54592fda:

    # MC "I think I counted... twice?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:600
translate chinese CR3_AS9_O4_con3_rep_bdcbc50b:

    # Caroline "Shut up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:601
translate chinese CR3_AS9_O4_con3_rep_38a163ad:

    # MC "So, when’s my tongue’s next appointment with your delicious cunt?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:602
translate chinese CR3_AS9_O4_con3_rep_c97d3306:

    # Caroline "One time thing. Remember?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:603
translate chinese CR3_AS9_O4_con3_rep_125e9da4:

    # MC "*Sigh* Fine. I’m sure you’ll change your mind though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_AS9_rep.rpy:604
translate chinese CR3_AS9_O4_con3_rep_402b8fc9:

    # Caroline "We’ll see."
    Caroline ""

