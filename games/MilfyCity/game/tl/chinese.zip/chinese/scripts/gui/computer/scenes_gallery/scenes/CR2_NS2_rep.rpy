﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:13
translate chinese CR2_NS2_rep_221a045c:

    # MC "Hey, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:15
translate chinese CR2_NS2_rep_3e3b7c9d:

    # Caroline "Shush... Try to keep your voice down. We may be outside, but the rest of the family are sleeping."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:17
translate chinese CR2_NS2_rep_6a91d4c3:

    # Caroline "Shush, try to keep your voice down. We may be outside, but the walls on the house aren’t very soundproof."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:18
translate chinese CR2_NS2_rep_597a36a1:

    # MC "No problem. I’ll try to be quiet."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:25
translate chinese CR2_NS2_rep_d048df1d:

    # MC "What was it you wanted to talk about, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:26
translate chinese CR2_NS2_rep_ebb5183a:

    # Caroline "I needed to have a serious conversation with you. I couldn’t do it inside with everyone else around. There’s no privacy there."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:27
translate chinese CR2_NS2_rep_3cae0e2b:

    # MC "Why not talk at your shop?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:28
translate chinese CR2_NS2_rep_37f2422c:

    # Caroline "The location didn't feel... right. Come and sit with me on the bench for a while."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:31
translate chinese CR2_NS2_rep_ffebf50d:

    # MC "(A serious conversation? I hope everything’s okay.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:32
translate chinese CR2_NS2_rep_ac91d429:

    # MC "(I wonder if this has to do with her shop being robbed - She did seem very stressed after that whole event.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:33
translate chinese CR2_NS2_rep_31bba18d:

    # MC "(Is there even anything else she would want to have a serious conversation about?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:37
translate chinese CR2_NS2_rep_4c1d5061:

    # Caroline "Don’t look so worried. Nothing seriously bad has happened."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:38
translate chinese CR2_NS2_rep_9d83e666:

    # MC "Oh, thank God."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:39
translate chinese CR2_NS2_rep_74cf66f0:

    # MC "You made me scared there!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:44
translate chinese CR2_NS2_rep_941a1b28:

    # Caroline "Haha! I’m sorry, [player_name]. It’s a serious topic, but you don’t need to worry."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:45
translate chinese CR2_NS2_rep_cc865f41:

    # Caroline "Grab a seat beside me here."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:49
translate chinese CR2_NS2_rep_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:50
translate chinese CR2_NS2_rep_c044f47b:

    # MC "(She’s being very quiet now. Perhaps, I should start the conversation?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:51
translate chinese CR2_NS2_rep_b666b37d:

    # MC "So, what was it you wanted to talk about?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:55
translate chinese CR2_NS2_rep_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:56
translate chinese CR2_NS2_rep_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:57
translate chinese CR2_NS2_rep_f39a9ee2:

    # MC "(Shit, I’m feeling sick to my stomach. I think I know what it is now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:58
translate chinese CR2_NS2_rep_f631960e:

    # MC "(She wants to end the deal we made!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:59
translate chinese CR2_NS2_rep_7c8e57e4:

    # MC "Caroline? Is this about the deal we made?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:60
translate chinese CR2_NS2_rep_125b4795:

    # Caroline "Yeah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:61
translate chinese CR2_NS2_rep_0e7da4e3:

    # MC "(I knew it! It’s over...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:65
translate chinese CR2_NS2_rep_9094216f:

    # MC "*Gulp* Y-You want to end it, don’t you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:66
translate chinese CR2_NS2_rep_b3c189a8:

    # Caroline "What?! NO! No.. "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:70
translate chinese CR2_NS2_rep_4b627b08:

    # Caroline "Of course, if you don’t want to.."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:71
translate chinese CR2_NS2_rep_c11bedbc:

    # MC "I don't want to!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:72
translate chinese CR2_NS2_rep_95d38edd:

    # MC "(Oh, thank God!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:73
translate chinese CR2_NS2_rep_e88a24f7:

    # MC "Phew... I was getting worried again, there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:74
translate chinese CR2_NS2_rep_2e4d596c:

    # Caroline "Haha! Try to relax. I’m not here to end anything."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:78
translate chinese CR2_NS2_rep_f2b42f2c:

    # Caroline "I actually wanted to talk to you about, everything you’ve done for me lately."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:79
translate chinese CR2_NS2_rep_cb7e737c:

    # MC "You don’t have to thank me for that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:80
translate chinese CR2_NS2_rep_b722317e:

    # Caroline "No, I really do. I wouldn’t be where I am right now, if you hadn’t lent me that money."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:84
translate chinese CR2_NS2_rep_e1a82317:

    # Caroline "Or helped me take those pictures."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:85
translate chinese CR2_NS2_rep_6dfc7975:

    # Caroline "Or supported me when my shop got robbed."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:86
translate chinese CR2_NS2_rep_ccf5292a:

    # Caroline "Or... just been there to talk to when things have been bad. You’ve been an incredible friend, [player_name]. I mean that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:87
translate chinese CR2_NS2_rep_254e84e6:

    # MC "It’s nothing. Honestly. I would have done the same thing for Sara or Bob, or ANY of you if you had gotten yourselves into trouble."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:92
translate chinese CR2_NS2_rep_ee12a1e2:

    # Caroline "Don’t keep saying it’s nothing, you idiot!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:93
translate chinese CR2_NS2_rep_d79af546:

    # Caroline "You’re the only person in my life right now who’s actually supported me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:95
translate chinese CR2_NS2_rep_c0b7bf46:

    # Caroline "Mom and Dad never helped me when my business went under. That was ALL you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:97
translate chinese CR2_NS2_rep_9c8fa0b8:

    # Caroline "Linda and Bob never helped me when my business went under. That was ALL you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:98
translate chinese CR2_NS2_rep_9350ddcf:

    # Caroline "None of my friends ever helped me. None of them came over when I was feeling down. It was you who visited me. It was you who listened to me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:99
translate chinese CR2_NS2_rep_e3ff1e8c:

    # Caroline "All the help I ever got came from YOU, [player_name]. Do you understand that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:100
translate chinese CR2_NS2_rep_2eb0a227:

    # MC "I... I guess so."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:105
translate chinese CR2_NS2_rep_1c59a434:

    # Caroline "(Mwah!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:106
translate chinese CR2_NS2_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:107
translate chinese CR2_NS2_rep_590f7250:

    # MC "(Wow! That came out of nowhere!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:111
translate chinese CR2_NS2_rep_15ef5f7f:

    # Caroline "(This is so wrong... It must be the night air and the full moon making me feel all romantic.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:113
translate chinese CR2_NS2_rep_36685a1b:

    # Caroline "(I can’t actually be feeling something for [player_name]. He’s my brother, for Christ’s sake!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:115
translate chinese CR2_NS2_rep_ffccb3dd:

    # Caroline "(I can’t actually be feeling something for [player_name]. He’s my best friend, for Christ’s sake!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:116
translate chinese CR2_NS2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:120
translate chinese CR2_NS2_rep_4cdcdb31:

    # Caroline "Don’t take me wrong, [player_name].. It’s only a reward for your help... Nothing more."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:121
translate chinese CR2_NS2_rep_bcddd383:

    # MC "C-Caroline, I..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:122
translate chinese CR2_NS2_rep_6c867398:

    # Caroline "Shush... Just... let me ask one thing."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:123
translate chinese CR2_NS2_rep_a6248fa0:

    # MC "A-Anything..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:127
translate chinese CR2_NS2_rep_bf256737:

    # Caroline "This money you gave me, all the time you spend helping me out, the way you’re always there when I need you..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:128
translate chinese CR2_NS2_rep_e7670ae9:

    # Caroline "Are you doing those things, for sexual favours as part of our deal?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:129
translate chinese CR2_NS2_rep_318b2124:

    # Caroline "Or do you feel something more?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:139
translate chinese CR2_NS2_rep_c54f0d74:

    # MC "I... I think I’m falling in love with you, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:140
translate chinese CR2_NS2_rep_1e99462b:

    # Caroline "R-Really?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:141
translate chinese CR2_NS2_rep_6f022fee:

    # MC "Yeah, I think I am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:145
translate chinese CR2_NS2_rep_567d3770:

    # Caroline "Thank you for telling me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:146
translate chinese CR2_NS2_rep_78b60b82:

    # Caroline "I... "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:148
translate chinese CR2_NS2_rep_197a5d48:

    # Caroline "I don’t feel the same way. I mean, I do love you - but just as a brother."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:150
translate chinese CR2_NS2_rep_dec0fedd:

    # Caroline "I don’t feel the same way. I mean, I do love you - but just as a friend."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:151
translate chinese CR2_NS2_rep_30034a6e:

    # MC "Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:155
translate chinese CR2_NS2_rep_491c6177:

    # Caroline "Please don’t be sad!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:156
translate chinese CR2_NS2_rep_a730ef67:

    # MC "It’s okay. I still get to spend, almost every day with you. The deal we have is good enough for me right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:157
translate chinese CR2_NS2_rep_606d84d9:

    # Caroline "Are you sure?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:158
translate chinese CR2_NS2_rep_aacf3a13:

    # MC "If anything changes, we can talk about this again in the future, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:159
translate chinese CR2_NS2_rep_b6b2795f:

    # Caroline "Okay."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:170
translate chinese CR2_NS2_rep_33f4bba9:

    # MC "I’m not gonna lie to you - I’ve been doing them as part of our deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:171
translate chinese CR2_NS2_rep_ff300569:

    # MC "I help you out, and in exchange you help me get off."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:172
translate chinese CR2_NS2_rep_4982a2d5:

    # Caroline "Haha! WOW! I knew that guys were only interested in sex, but you’re the first one who’s actually been honest about it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:176
translate chinese CR2_NS2_rep_39e36245:

    # MC "I’m sorry-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:177
translate chinese CR2_NS2_rep_9f040670:

    # Caroline "No, don’t be sorry. I know exactly where I stand with you. That’s a good thing."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:178
translate chinese CR2_NS2_rep_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:179
translate chinese CR2_NS2_rep_3e1dde68:

    # Caroline "Absolutely, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:186
translate chinese CR2_NS2_q1_rep_b97f88ee:

    # MC "I’m doing these things because you’re my sister. Anything else is a bonus."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:188
translate chinese CR2_NS2_q1_rep_09c4a175:

    # MC "I’m doing these things because you’re my closest friend. Anything else is a bonus."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:189
translate chinese CR2_NS2_q1_rep_e7eeb3f2:

    # MC "And that includes the deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:190
translate chinese CR2_NS2_q1_rep_f4d91aed:

    # Caroline "Really?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:191
translate chinese CR2_NS2_q1_rep_0f057ca2:

    # MC "Really."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:193
translate chinese CR2_NS2_q1_rep_e4aae5e2:

    # Caroline "I’m kinda relieved to hear that. Honestly, I only love you as a brother, and if things started to get romantic I’d be feeling a little weird."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:195
translate chinese CR2_NS2_q1_rep_90308f83:

    # Caroline "I’m kinda relieved to hear that. Honestly, I only love you as a friend, and if things started to get romantic I’d be feeling a little weird."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:196
translate chinese CR2_NS2_q1_rep_64ed9edd:

    # MC "Well, you don’t need to worry about that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:202
translate chinese CR2_NS2_continue1_rep_eb85e7ca:

    # Caroline "C’mon. Follow me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:203
translate chinese CR2_NS2_continue1_rep_6b3b257e:

    # MC "Where are we going?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:204
translate chinese CR2_NS2_continue1_rep_766eb396:

    # Caroline "Back to my bedroom for some fun."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:208
translate chinese CR2_NS2_continue1_rep_ad071b82:

    # MC "But you said Mom and Dad were asleep!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:210
translate chinese CR2_NS2_continue1_rep_5c65c110:

    # MC "But you said we couldn’t risk waking anyone"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:211
translate chinese CR2_NS2_continue1_rep_25868964:

    # Caroline "Aww... are you a chicken?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:212
translate chinese CR2_NS2_continue1_rep_ae27fe6c:

    # MC "Hey! I’m not a chicken!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:213
translate chinese CR2_NS2_continue1_rep_42c30069:

    # Caroline "Then, c’mon with me to my room."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:223
translate chinese CR2_NS2_continue1_rep_a3c0e856:

    # "*Crreeeeaaaak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:225
translate chinese CR2_NS2_continue1_rep_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:227
translate chinese CR2_NS2_continue1_rep_1487cf27:

    # MC "Fuck ME, Caroline? You REALLY need to oil those hinges!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:231
translate chinese CR2_NS2_continue1_rep_9ff8e6f9:

    # Caroline "I’ve never needed to sneak guys into my bedroom before."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:232
translate chinese CR2_NS2_continue1_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:233
translate chinese CR2_NS2_continue1_rep_02389bfc:

    # Caroline "Why do you look so surprised?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:237
translate chinese CR2_NS2_continue1_rep_81794494:

    # MC "I figured you would have brought boys over before."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:239
translate chinese CR2_NS2_continue1_rep_84bafd73:

    # Caroline "With a nosy brother like you, and an even nosier sister like Sara? It wasn’t worth the risk!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:241
translate chinese CR2_NS2_continue1_rep_87214fb6:

    # Caroline "With a nosy perv like you, and an even nosier girl like Sara? It wasn’t worth the risk!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:242
translate chinese CR2_NS2_continue1_rep_7f877a5c:

    # MC "Haha! I guess you’re right."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:243
translate chinese CR2_NS2_continue1_rep_f4b99476:

    # Caroline "I just went over to their places to fuck."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:247
translate chinese CR2_NS2_continue1_rep_9486afa3:

    # MC "So, what exactly are we doing tonight?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:248
translate chinese CR2_NS2_continue1_rep_371b016b:

    # Caroline "Don’t get your hopes up - we won’t be having sex."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:249
translate chinese CR2_NS2_continue1_rep_ba7d4202:

    # Caroline "I haven’t quite decided how far I’m willing to go - but we’ll both find out soon enough."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:253
translate chinese CR2_NS2_continue1_rep_2252b98e:

    # MC "(Her body looks so sexy! I wonder what I’ll get to do with her tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:254
translate chinese CR2_NS2_continue1_rep_d8e2a843:

    # Caroline "Y’know, it’s probably a good thing that I don’t have a boyfriend right now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:255
translate chinese CR2_NS2_continue1_rep_f186edb2:

    # Caroline "It would make our deal a WHOLE lot more awkward."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:259
translate chinese CR2_NS2_continue1_rep_8482dff1:

    # Caroline "And I don’t think I’d find a boyfriend who would treat me as well as you’ve done."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:260
translate chinese CR2_NS2_continue1_rep_06984008:

    # Caroline "You helped grow my business - and then, when I got robbed - you saved it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:261
translate chinese CR2_NS2_continue1_rep_ee6741c4:

    # MC "Caroline, you don’t need to keep thanking me for that. There’s more to you than just your business."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:265
translate chinese CR2_NS2_continue1_rep_26a7ecfc:

    # Caroline "I know. I know. It’s my first real stab at independence though. I want to make it work."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:266
translate chinese CR2_NS2_continue1_rep_b14df790:

    # MC "Yeah, I get that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:267
translate chinese CR2_NS2_continue1_rep_7ad94102:

    # Caroline "Okay, I think I’m ready."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:271
translate chinese CR2_NS2_continue1_rep_ac3c368e:

    # Caroline "How about you rub your cock between my thighs and up against my panties?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:272
translate chinese CR2_NS2_continue1_rep_9879a67c:

    # MC "Sounds good to me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:273
translate chinese CR2_NS2_continue1_rep_ed0bb618:

    # Caroline "Cool. So, do you want to do it, back or front?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:280
translate chinese CR2_NS2_continue1_rep_d1daec90:

    # MC "Let’s do it with you facing back."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:281
translate chinese CR2_NS2_continue1_rep_a058a72b:

    # Caroline "Mmm... Sounds good to me. Strip off and lie on your back, on the bed."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:285
translate chinese CR2_NS2_continue1_rep_a644d9bd:

    # Caroline "Well? How’s this? Are you comfortable?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:286
translate chinese CR2_NS2_continue1_rep_a0513c1b:

    # MC "Yeah, this is good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:287
translate chinese CR2_NS2_continue1_rep_a2d324eb:

    # Caroline "Great! I’ll start moving my hips now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:289
translate chinese CR2_NS2_continue1_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:293
translate chinese CR2_NS2_continue1_rep_d0e062b5:

    # MC "Mmm... Your mound is so warm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:294
translate chinese CR2_NS2_continue1_rep_1441356d:

    # Caroline "It feels good for you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:295
translate chinese CR2_NS2_continue1_rep_53080cb7:

    # MC "Ah... so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:299
translate chinese CR2_NS2_continue1_rep_dea714cb:

    # MC "Oohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:300
translate chinese CR2_NS2_continue1_rep_d3ec6e19:

    # Caroline "(I can feel his hard cock, rubbing up and down against my pussy, through my panties!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:301
translate chinese CR2_NS2_continue1_rep_8ca9f7e6:

    # Caroline "(This is more pleasurable for me, than I expected it to be!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:305
translate chinese CR2_NS2_continue1_rep_9273793e:

    # MC "Ah! Yes! That’s amazing, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:307
translate chinese CR2_NS2_continue1_rep_1018bf50:

    # Caroline "Oh... Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:308
translate chinese CR2_NS2_continue1_rep_a869ccfa:

    # Caroline "(I should try and keep my voice down. I don’t want him to think, I’m enjoying this too much...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:312
translate chinese CR2_NS2_continue1_rep_c973bdf7:

    # MC "(I’ll try thrusting MY hips as well!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:313
translate chinese CR2_NS2_continue1_rep_3242ccc8:

    # Caroline "MMM! Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:314
translate chinese CR2_NS2_continue1_rep_4134f2ff:

    # Caroline "(His cock is brushing against my clitoris!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:318
translate chinese CR2_NS2_continue1_rep_f8b6a085:

    # Caroline "(And now his hands are groping my ass!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:319
translate chinese CR2_NS2_continue1_rep_3db37453:

    # Caroline "(If he keeps this up, I’m probably going to cum!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:320
translate chinese CR2_NS2_continue1_rep_a6e7097f:

    # MC "(Her ass is so soft! I could squeeze it all day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:324
translate chinese CR2_NS2_continue1_rep_5364dcd3:

    # Caroline "How- ahh... are you holding out there, [player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:326
translate chinese CR2_NS2_continue1_rep_8c378270:

    # MC "(Fuck, this feels amazing.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:331
translate chinese CR2_NS2_continue1_rep_68aa9d81:

    # MC "I’m good. Your ass feels amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:333
translate chinese CR2_NS2_continue1_rep_10d192d0:

    # MC "I’d love to fuck it, for real, someday."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:334
translate chinese CR2_NS2_continue1_rep_2457e4c6:

    # Caroline "Oohh... M-Maybe you will."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:338
translate chinese CR2_NS2_continue1_rep_340a9ffc:

    # Caroline "(I can’t believe I just said that!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:339
translate chinese CR2_NS2_continue1_rep_de745719:

    # Caroline "(I’ll just put it down to, how damned horny I am right now.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:341
translate chinese CR2_NS2_continue1_rep_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:345
translate chinese CR2_NS2_continue1_rep_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:346
translate chinese CR2_NS2_continue1_rep_dea714cb_1:

    # MC "Oohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:347
translate chinese CR2_NS2_continue1_rep_32053a88:

    # Caroline "Ahh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:351
translate chinese CR2_NS2_continue1_rep_aff82f76:

    # Caroline "(I’ll have to be careful though - I can’t let myself get this horny, EVERY TIME that [player_name] and I do stuff.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:352
translate chinese CR2_NS2_continue1_rep_2a2690cb:

    # Caroline "(If he keeps this up, I might not be able to resist, and end up letting him fuck me someday!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:358
translate chinese CR2_NS2_continue1_rep_676061a6:

    # MC "Let’s do it when you’re facing front."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:359
translate chinese CR2_NS2_continue1_rep_93e24c48:

    # Caroline "Okay, take off your clothes and lie back on the bed."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:361
translate chinese CR2_NS2_continue1_rep_05d1b90c_1:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:363
translate chinese CR2_NS2_continue1_rep_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:364
translate chinese CR2_NS2_continue1_rep_e0deb0b1:

    # Caroline "Enjoying the view?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:365
translate chinese CR2_NS2_continue1_rep_4f86f9c9:

    # MC "It’s incredible..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:369
translate chinese CR2_NS2_continue1_rep_5cb36182:

    # Caroline "How about when I close my thighs?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:370
translate chinese CR2_NS2_continue1_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:371
translate chinese CR2_NS2_continue1_rep_b2035065:

    # Caroline "Does that feel good?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:375
translate chinese CR2_NS2_continue1_rep_aa5075db:

    # MC "So good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:377
translate chinese CR2_NS2_continue1_rep_a270de4d:

    # Caroline "(I love the sensation of his cock, grinding against my panties.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:378
translate chinese CR2_NS2_continue1_rep_a070b5e6:

    # Caroline "(It’s brushing, perfectly against my clitoris!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:383
translate chinese CR2_NS2_continue1_rep_dea714cb_2:

    # MC "Oohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:384
translate chinese CR2_NS2_continue1_rep_00ce89b1:

    # Caroline "Ahh... Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:385
translate chinese CR2_NS2_continue1_rep_d3eed0f6:

    # MC "It sounds like you’re enjoying this too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:389
translate chinese CR2_NS2_continue1_rep_9b791865:

    # Caroline "I’m... ah... just breathing..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:390
translate chinese CR2_NS2_continue1_rep_29ad8611:

    # MC "(Hey! She’s going further than we’ve ever gone before! Is she really horny? Or has she just not noticed?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:391
translate chinese CR2_NS2_continue1_rep_0ab0cfbf:

    # MC "Sure, if that’s what you say, beautiful."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:395
translate chinese CR2_NS2_continue1_rep_ada95666:

    # Caroline "(Oh God, his cock feels so good! It’s making me so horny right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:396
translate chinese CR2_NS2_continue1_rep_56311d3d:

    # Caroline "(This is dangerous... If I got REALLY HORNY someday, I might let him inside me...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:397
translate chinese CR2_NS2_continue1_rep_e30e38fe:

    # Caroline "(Damn, that would be so wrong...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:401
translate chinese CR2_NS2_continue1_rep_22547e88:

    # Caroline "Oohhh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:402
translate chinese CR2_NS2_continue1_rep_3c3de20d:

    # Caroline "(This is so wrong, but it feels SOOO good!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:403
translate chinese CR2_NS2_continue1_rep_7289a7c9:

    # MC "(She’s getting faster with each passing minute!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:407
translate chinese CR2_NS2_continue1_rep_3ef7f70a:

    # MC "Ugh! I’m gonna cum soon!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:408
translate chinese CR2_NS2_continue1_rep_5b4cbcee:

    # MC "Your thighs are fucking incredible!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:410
translate chinese CR2_NS2_continue1_rep_57f6e928:

    # Caroline "Ah! Ah! Ahh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:414
translate chinese CR2_NS2_continue1_rep_a06e605a:

    # Caroline "(He’s going to be cumming, soooo close to my pussy!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:415
translate chinese CR2_NS2_continue1_rep_099e4d25:

    # Caroline "(Holy shit... my heart is racing right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:416
translate chinese CR2_NS2_continue1_rep_c16f94db:

    # Caroline "Ahh... Ohhh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:420
translate chinese CR2_NS2_continue1_rep_c37b2862:

    # MC "(I’ll get a much better orgasm if I take control of the situation.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:421
translate chinese CR2_NS2_continue1_rep_6fd97b0b:

    # MC "(I hope Caroline doesn’t mind if I pull myself on top, to change things up!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:422
translate chinese CR2_NS2_continue1_rep_d1282c39:

    # Caroline "Mmm! Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:426
translate chinese CR2_NS2_continue1_rep_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:427
translate chinese CR2_NS2_continue1_rep_03e3856b:

    # MC "(Well, here goes nothing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:435
translate chinese CR2_NS2_continue2_rep_0a1540a1:

    # Caroline "Whoa!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:436
translate chinese CR2_NS2_continue2_rep_03fa1f6c:

    # MC "You gotta stay quiet, Caroline. Remember?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:438
translate chinese CR2_NS2_continue2_rep_b1d55cf7:

    # MC "Don’t want to wake Mom and Dad up!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:440
translate chinese CR2_NS2_continue2_rep_e9fd3449:

    # MC "Don’t want to wake Linda and Bob up!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:444
translate chinese CR2_NS2_continue2_rep_6142a4b3:

    # Caroline "Mmmm.... Ohh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:445
translate chinese CR2_NS2_continue2_rep_caf6d30b:

    # MC "(This is much better!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:446
translate chinese CR2_NS2_continue2_rep_f9aa5be3:

    # MC "(And by the look on Caroline’s face, she’s LOVING the feeling of it too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:450
translate chinese CR2_NS2_continue2_rep_855f8c0f:

    # Caroline "Ah! Ah! Ah!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:452
translate chinese CR2_NS2_continue2_rep_b91d6f84:

    # Caroline "(God! He’s gonna make me cum!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:453
translate chinese CR2_NS2_continue2_rep_43c09e34:

    # MC "Fuck, this is good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:456
translate chinese CR2_NS2_continue2_rep_af9e17e7:

    # Caroline "Ooohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:457
translate chinese CR2_NS2_continue2_rep_7d1af4ca:

    # Caroline "(I can feel my pussy burning up! I’m gonna cum soon!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:458
translate chinese CR2_NS2_continue2_rep_9c4077ce:

    # MC "I’m not gonna last much longer! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:462
translate chinese CR2_NS2_continue2_rep_12ccaf2b:

    # Caroline "Thrust faster! Ah! "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:463
translate chinese CR2_NS2_continue2_rep_89740de8:

    # MC "Are you - ugh - sure?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:465
translate chinese CR2_NS2_continue2_rep_f4076293:

    # Caroline "Ah! Yes! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:469
translate chinese CR2_NS2_continue2_rep_fb38cb2b:

    # Caroline "Mmm! Fuck... It’s so good..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:470
translate chinese CR2_NS2_continue2_rep_4742d564:

    # Caroline "Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:471
translate chinese CR2_NS2_continue2_rep_052a321f:

    # MC "Hnnng! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:475
translate chinese CR2_NS2_continue2_rep_f2f14668:

    # Caroline "W-Wait! Oh God!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:476
translate chinese CR2_NS2_continue2_rep_06d3feba:

    # Caroline "Careful! You’ll get it on my-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:477
translate chinese CR2_NS2_continue2_rep_929dcba5:

    # MC "HNNNG!!! AAHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:486
translate chinese CR2_NS2_continue2_rep_b3e1d76e:

    # Caroline "...face."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:487
translate chinese CR2_NS2_continue2_rep_d28054d4:

    # MC "Oh shit! Sorry."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:488
translate chinese CR2_NS2_continue2_rep_9d583176:

    # Caroline "Don’t worry about it..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:492
translate chinese CR2_NS2_continue2_rep_37a55502:

    # Caroline "Go on back to your room. I need to clean up, here."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:493
translate chinese CR2_NS2_continue2_rep_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:494
translate chinese CR2_NS2_continue2_rep_3917a44c:

    # Caroline "Yeah. I’ll see you tomorrow."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:498
translate chinese CR2_NS2_continue2_rep_5fc0330d:

    # Caroline "(Damn... the scent of his cum, there is making me VERY horny!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:499
translate chinese CR2_NS2_continue2_rep_f00ffa28:

    # Caroline "(It doesn't help that he came before I did, either.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:500
translate chinese CR2_NS2_continue2_rep_fda0a1b3:

    # Caroline "(Time to get my special toy out...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:504
translate chinese CR2_NS2_continue2_rep_e74416b5:

    # Caroline "Hmm... Where did I leave it, after last time?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:505
translate chinese CR2_NS2_continue2_rep_e12ad616:

    # Caroline "I could have sworn I had it under my pillow..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:506
translate chinese CR2_NS2_continue2_rep_6e4cf65a:

    # Caroline "Unless..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:510
translate chinese CR2_NS2_continue2_rep_f7a35142:

    # Caroline "(I had to hide it under my bed, in case Mom decided to clean my room.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:512
translate chinese CR2_NS2_continue2_rep_c43995fa:

    # Caroline "(I had to hide it under my bed, in case Linda decided to clean my room.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:513
translate chinese CR2_NS2_continue2_rep_085069b4:

    # Caroline "(It would have been embarrassing if she’d found it.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:514
translate chinese CR2_NS2_continue2_rep_659d0423:

    # Caroline "(Oh, come on... Where have you gone?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:519
translate chinese CR2_NS2_continue2_rep_73f7c19a:

    # Caroline "Aha! There you are!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:520
translate chinese CR2_NS2_continue2_rep_6fcc635a:

    # Caroline "(How on Earth did you get THAT far under the bed?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:521
translate chinese CR2_NS2_continue2_rep_2ec15ad2:

    # Caroline "(It must have rolled, after I threw it under, last time.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:522
translate chinese CR2_NS2_continue2_rep_f5786bd2:

    # Caroline "(I just need to wash it quickly, then it’ll be ready to use.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:526
translate chinese CR2_NS2_continue2_rep_2e1fca8d:

    # Caroline "(Okay, that’s it washed... Now, it's time to have some fun.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:527
translate chinese CR2_NS2_continue2_rep_c1e442ff:

    # Caroline "(It’s been faaaar too long since I’ve had, a good long session with you.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:528
translate chinese CR2_NS2_continue2_rep_a746cd11:

    # Caroline "(I think I’ll put you in my pussy tonight.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:533
translate chinese CR2_NS2_continue2_rep_1187d248:

    # Caroline "Oooh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:534
translate chinese CR2_NS2_continue2_rep_3799c9f3:

    # Caroline "Yes... Right there..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:536
translate chinese CR2_NS2_continue2_rep_8cc07a4e:

    # Caroline "Mmm! That’s it..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:540
translate chinese CR2_NS2_continue2_rep_70c08ec4:

    # Caroline "Yes... Take off your pants and thrust your cock inside me..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:542
translate chinese CR2_NS2_continue2_rep_72a290d0:

    # Caroline "Mmm... That’s sooooo goood! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:543
translate chinese CR2_NS2_continue2_rep_c645ec88:

    # Caroline "OH! OHHH, [player_name]! Fuck me harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:548
translate chinese CR2_NS2_continue2_rep_faf25b4b:

    # Caroline "W-what!? Eh!? What did I JUST SAY!?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:549
translate chinese CR2_NS2_continue2_rep_356132ef:

    # Caroline "(Am I seriously getting off, to the thought of [player_name] fucking me?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:551
translate chinese CR2_NS2_continue2_rep_c0f06898:

    # Caroline "Caroline: (That’s sick and wrong... He’s brother! What am I thinking?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:552
translate chinese CR2_NS2_continue2_rep_d731634e:

    # Caroline "(What’s wrong with me!?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:554
translate chinese CR2_NS2_continue2_rep_2f45c9bc:

    # Caroline "(That’s sick and wrong... He’s my best friend! What am I thinking?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:555
translate chinese CR2_NS2_continue2_rep_921c0ffb:

    # Caroline "(This is... weird... and wrong!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:561
translate chinese CR2_NS2_continue2_rep_d22c87d1:

    # Caroline "(Dammit! This stupid deal is affecting me!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:562
translate chinese CR2_NS2_continue2_rep_107bfc8b:

    # Caroline "(I CAN’T like [player_name] THAT way! This was only supposed to be fun!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:563
translate chinese CR2_NS2_continue2_rep_921c0ffb_1:

    # Caroline "(This is... weird... and wrong!)"
    Caroline ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:135
    old "I... think I’m falling in love with you, Caroline."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:135
    old "I’m doing them because your're my sister. Anything else is a bonus."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:135
    old "I’m doing them because your're my friend. Anything else is a bonus."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:135
    old "I’m not gonna lie to you - I’ve been doing them as part of our deal."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:276
    old "Let’s do it with you facing back."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/CR2_NS2_rep.rpy:276
    old "Let’s do it with you facing front."
    new ""

