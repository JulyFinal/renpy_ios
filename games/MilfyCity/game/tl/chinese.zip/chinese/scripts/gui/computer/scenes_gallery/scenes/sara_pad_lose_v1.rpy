﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:9
translate chinese sara_pad_lose_v1_827550fa:

    # MC "Hey Sara, you still busy with your league game?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:10
translate chinese sara_pad_lose_v1_22a7fa4d:

    # Sara "Give me two seconds... this match is almost over."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:11
translate chinese sara_pad_lose_v1_b418f6f9:

    # Sara "Aaaaand I’m done!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:14
translate chinese sara_pad_lose_v1_6b0e2eaf:

    # Sara "Say, do you fancy gaming together? I can boot up the XSwitch4!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:15
translate chinese sara_pad_lose_v1_d8aeb7cc:

    # MC "Great! What game do you want to play?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:16
translate chinese sara_pad_lose_v1_0576259e:

    # Sara "Let me have a look and see what multiplayer games I have."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:19
translate chinese sara_pad_lose_v1_1fc03e58:

    # Sara "Hmm... Medal of Duty? Call of Honour?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:20
translate chinese sara_pad_lose_v1_ab426d4d:

    # Sara "Oh! I have Street Brawler VII!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:21
translate chinese sara_pad_lose_v1_fbcb1d27:

    # MC "Anything works for me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:22
translate chinese sara_pad_lose_v1_b6060e98:

    # Sara "Let’s do Street Brawler VII then. One vs one deathmatch!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:23
translate chinese sara_pad_lose_v1_0b369ff9:

    # MC "Sounds fun!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:26
translate chinese sara_pad_lose_v1_70d0a843:

    # Sara "Okay, there’s your controller. You’ve played before, right?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:27
translate chinese sara_pad_lose_v1_2e3c7a80:

    # MC "Thanks. Yeah, and I’m pretty damn good at it - so you better watch your back!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:28
translate chinese sara_pad_lose_v1_eda302b6:

    # Sara "Well, since you’re that confident, how about we change up the rules a bit?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:29
translate chinese sara_pad_lose_v1_3ec55d34:

    # MC "What are you thinking? Betting some money?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:32
translate chinese sara_pad_lose_v1_cce2ff7a:

    # Sara "The loser has to.... take off... a piece of clothing, each time they die."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:33
translate chinese sara_pad_lose_v1_ee6b7632:

    # Sara "(This is my revenge for trying to steal my panties!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:34
translate chinese sara_pad_lose_v1_608842ae:

    # MC "(Wait? WHAT?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:35
translate chinese sara_pad_lose_v1_df0f7dbd:

    # MC "S-Sorry, I didn’t hear you right, there. What did you say?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:36
translate chinese sara_pad_lose_v1_c6cef2b8:

    # Sara "Each time your character dies in-game, you have to lose a piece of clothing. Deal?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:39
translate chinese sara_pad_lose_v1_6191a341:

    # MC "(Holy shit! I must be dreaming! This can’t actually be happening!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:40
translate chinese sara_pad_lose_v1_8dd28609:

    # MC "Hell yeah, that’s a deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:41
translate chinese sara_pad_lose_v1_f2b7c94f:

    # MC "You do realise that this means you’re about to be stripped naked? When it comes to the Street Brawler series - I’m a freakin’ pro."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:44
translate chinese sara_pad_lose_v1_81738234:

    # Sara "Uh huh, I’m sure you are."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:45
translate chinese sara_pad_lose_v1_59504933:

    # Sara "Take a good look right now - because this is the closest you’re gonna get to seeing my tits today."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:46
translate chinese sara_pad_lose_v1_9c22175e:

    # MC "(Damn, I can’t wait to see her boobs today. There’s no way I’m losing to a girl! I’ve been playing the Street Brawler series since I was in kindergarden!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:49
translate chinese sara_pad_lose_v1_87f4eb3d:

    # Console "READY! SET! FIGHT!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:50
translate chinese sara_pad_lose_v1_1ca5d425:

    # MC "(Damn! She’s quick!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:51
translate chinese sara_pad_lose_v1_8d592c60:

    # Sara "What’s the matter, [player_name]? You’re looking a bit stressed!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:52
translate chinese sara_pad_lose_v1_4164c8e0:

    # Sara "Hehe... Why haven’t you hit me yet?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:53
translate chinese sara_pad_lose_v1_e2af5310:

    # MC "Because you aren’t giving me a chance to-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:54
translate chinese sara_pad_lose_v1_e1593d27:

    # Console "Player 2 has been defeated!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:55
translate chinese sara_pad_lose_v1_12b382be:

    # MC "Dammit!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:58
translate chinese sara_pad_lose_v1_57e51f5d:

    # "(Fifteen Minutes Later...)"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:63
translate chinese sara_pad_lose_v1_3a362944:

    # Sara "Hehe! Are you sure you want to go for one more round? You’ve only got your boxers left!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:65
translate chinese sara_pad_lose_v1_f19fc50d:

    # MC "It isn’t over yet! I was just going easy on you because you’re my sister."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:67
translate chinese sara_pad_lose_v1_83ffbad8:

    # MC "It isn’t over yet! I was just going easy on you because we’re friends!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:68
translate chinese sara_pad_lose_v1_d145ac12:

    # Sara "Suuuuure!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:71
translate chinese sara_pad_lose_v1_0360c9bf:

    # "(Five Minutes Later...)"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:74
translate chinese sara_pad_lose_v1_e1593d27_1:

    # Console "Player 2 has been defeated!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:75
translate chinese sara_pad_lose_v1_a236be8f:

    # Console "Player 1 has broken a new killstreak record!"
    Console ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:76
translate chinese sara_pad_lose_v1_0ec0d862:

    # Sara "Woohoo!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:79
translate chinese sara_pad_lose_v1_27b50ef5:

    # Sara "Don’t worry, [player_name]. You don’t have to take your underwear off too."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:80
translate chinese sara_pad_lose_v1_fbfa7781:

    # Sara "I think you’ve already been humiliated enough! Hehe!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:81
translate chinese sara_pad_lose_v1_4b616edc:

    # MC "Fair is fair - we agreed to the rules before we started."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:82
translate chinese sara_pad_lose_v1_84962fa8:

    # Sara "Wait - you're not seriously going to-"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:88
translate chinese sara_pad_lose_v1_d2461f9e:

    # Sara "Oh, my God! You’re hard!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:89
translate chinese sara_pad_lose_v1_946ff154:

    # Sara "Wh-Why is it so hard?!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:90
translate chinese sara_pad_lose_v1_2d3893c5:

    # MC "(Maybe because I want to, fuck you silly?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:91
translate chinese sara_pad_lose_v1_f8d7ba9d:

    # MC "It’s because you’re looking at it right now. Cocks tend to get hard when they’re given attention."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:94
translate chinese sara_pad_lose_v1_0b87f0f1:

    # MC "Right - what happens now then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:95
translate chinese sara_pad_lose_v1_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:96
translate chinese sara_pad_lose_v1_16d8373f:

    # MC "Is it one more round to decide the winner? Or have you won, since I’m naked?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:99
translate chinese sara_pad_lose_v1_340cdc9f:

    # MC "(She’s not listening to me anymore... She’s just staring at my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:100
translate chinese sara_pad_lose_v1_336d31cf:

    # MC "(I wonder if it is the first time she’s ever seen one. She seems to be extremely interested in it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:101
translate chinese sara_pad_lose_v1_ef449047:

    # Sara "(Wow... It’s so big and hard... I don’t know why, but I really want to touch it.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:104
translate chinese sara_pad_lose_v1_f5db47cb:

    # MC "So... uhh... I’m gonna go and get dressed now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:106
translate chinese sara_pad_lose_v1_1ad65c6a:

    # MC "Last thing I want is, Mom or Dad, walking in on us right now!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:108
translate chinese sara_pad_lose_v1_0b8a0655:

    # MC "Last thing I want is Linda or Bob walking in on us right now!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:110
translate chinese sara_pad_lose_v1_09d06ab8:

    # "*Click*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:111
translate chinese sara_pad_lose_v1_ba7f5115:

    # "(A flash of light fills the room)"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:117
translate chinese sara_pad_lose_v1_c108ecce:

    # Sara "(Got it! I couldn’t let this just be a memory!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:118
translate chinese sara_pad_lose_v1_08b0b6b0:

    # MC "What the hell, Sara! Did you just take a picture of my dick?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:119
translate chinese sara_pad_lose_v1_cc17959a:

    # Sara "N-No?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:120
translate chinese sara_pad_lose_v1_93e93001:

    # MC "Yes you did! I can see you taking a photo right now! Delete it!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:124
translate chinese sara_pad_lose_v1_d72f993c:

    # Sara "You’re gonna have to catch me first! Hehe!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:125
translate chinese sara_pad_lose_v1_b3d1ccc2:

    # MC "Come back here!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:126
translate chinese sara_pad_lose_v1_bb781fb4:

    # MC "Seriously, Sara! Give me your phone!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:128
translate chinese sara_pad_lose_v1_51453c5a:

    # Sara "I-If you don’t stop chasing me, I’ll call Mom!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:130
translate chinese sara_pad_lose_v1_2efb84c9:

    # Sara "I-If you don’t stop chasing me, I’ll call Linda!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:132
translate chinese sara_pad_lose_v1_a3af909b:

    # MC "Gotcha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:133
translate chinese sara_pad_lose_v1_537b1751:

    # Sara "[player_name], stop! Seriously!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:134
translate chinese sara_pad_lose_v1_1eb039b8:

    # MC "Delete that picture from your phone!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:135
translate chinese sara_pad_lose_v1_24fc059b:

    # Sara "I’m not talking about this with you!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:136
translate chinese sara_pad_lose_v1_b16ad2d1:

    # MC "Well, maybe I’ll just have to-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:137
translate chinese sara_pad_lose_v1_f7786052:

    # Sara "Umm... [player_name]?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:140
translate chinese sara_pad_lose_v1_74d5de99:

    # MC "(Oh shit! My cock pressed right up against her bare belly. It feels so warm against the tip of my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:141
translate chinese sara_pad_lose_v1_5fd7abfe:

    # Sara "(Oh, my God! My [player_name]’s cock is touching me!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:142
translate chinese sara_pad_lose_v1_a1cff58b:

    # MC "I- I- I’m sorry... I’ll go now!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:145
translate chinese sara_pad_lose_v1_047a29ad:

    # MC "(Crap, that got weird, REALLY fast.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:146
translate chinese sara_pad_lose_v1_6afb1e15:

    # MC "(I hope she’s not too angry at me for pushing my cock against her. I didn’t mean to!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:147
translate chinese sara_pad_lose_v1_95f748cf:

    # Sara "(That was intense... I have to check this picture out again when he leaves!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:150
translate chinese sara_pad_lose_v1_aded0c65:

    # Sara "(Wow... It’s sooo big!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_pad_lose_v1.rpy:151
translate chinese sara_pad_lose_v1_80a46c68:

    # Sara "(I have to show Lily! She won’t believe this!)"
    Sara ""

