﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:18
translate chinese Z_ES3_rep_8ea7df0f:

    # Zuri "Welcome back, [player_name]."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:20
translate chinese Z_ES3_rep_846a0e33:

    # Suri "It’s good to see you again, kid."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:22
translate chinese Z_ES3_rep_d3f07b92:

    # Suri "It’s good to see you again, pal."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:23
translate chinese Z_ES3_rep_0bb677d8:

    # MC "I’m glad to see you too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:24
translate chinese Z_ES3_rep_21c74d28:

    # Zuri "Thanks again for your help with the company name. We’ll both make sure you are adequately rewarded."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:25
translate chinese Z_ES3_rep_9d94c452:

    # Suri "How about we head into the back room and get this party started?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:33
translate chinese Z_ES3_rep_fc4e5adb:

    # Suri "So, what were you thinking?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:34
translate chinese Z_ES3_rep_ff53ccdf:

    # Zuri "We could give you a footjob."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:35
translate chinese Z_ES3_rep_f31899b8:

    # Suri "Or we could lick your cock until you cum."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:41
translate chinese Z_ES3_rep_09eea99a:

    # MC "I’d love to see the two of you lick my cock."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:45
translate chinese Z_ES3_rep_6ba5d9ee:

    # Suri "Is that so, kid?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:47
translate chinese Z_ES3_rep_e4ce1190:

    # Suri "Is that so, pal?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:48
translate chinese Z_ES3_rep_61f28a82:

    # Zuri "I imagine you must enjoy the sight of two pretty girls, on their knees before you."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:49
translate chinese Z_ES3_rep_a3105d90:

    # Zuri "Let’s get these jeans undone."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:53
translate chinese Z_ES3_rep_14b45453:

    # MC "(This is gonna be awesome! Double blowjobs are incredible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:54
translate chinese Z_ES3_rep_bcbc0ce4:

    # Zuri "Now, we’re only going to lick you today. But if you get us more names, we can certainly think about giving you a proper sucking. Deal?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:55
translate chinese Z_ES3_rep_8ce16276:

    # MC "Yeah, deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:58
translate chinese Z_ES3_rep_f01ea8fc:

    # Zuri "Wow! It’s pretty big, Suri!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:60
translate chinese Z_ES3_rep_a78a58d6:

    # Suri "This kid surprises me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:61
translate chinese Z_ES3_rep_f1501b47:

    # MC "(God, why am I just letting them do this? They’re seducing me into ruining Dad’s company!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:63
translate chinese Z_ES3_rep_484cf88f:

    # Suri "This guy surprises me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:64
translate chinese Z_ES3_rep_35777e6d:

    # MC "(God, why am I just letting them do this? They’re seducing me into ruining Bob’s company!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:67
translate chinese Z_ES3_rep_e03c586b:

    # MC "(I have to make a stand and say “No more”.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:68
translate chinese Z_ES3_rep_716220ff:

    # Zuri "It’s sooo thick too!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:69
translate chinese Z_ES3_rep_c79d1eca:

    # Suri "That would feel REALLY good inside me!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:73
translate chinese Z_ES3_rep_320f6fbe:

    # MC "Oooh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:74
translate chinese Z_ES3_rep_703977fc:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:75
translate chinese Z_ES3_rep_619d9b75:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:79
translate chinese Z_ES3_rep_7a9a6a9c:

    # MC "(On the other hand, maybe Dad’s company isn’t worth a blowjob THIS good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:81
translate chinese Z_ES3_rep_60b13944:

    # MC "(On the other hand, maybe Bob’s company isn’t worth a blowjob THIS good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:82
translate chinese Z_ES3_rep_703977fc_1:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:83
translate chinese Z_ES3_rep_7d757fa8:

    # MC "(They’re teasing every inch of my dick! I’ll be cumming in no time!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:87
translate chinese Z_ES3_rep_029f09cf:

    # Zuri "*Lick! Slurp!*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:88
translate chinese Z_ES3_rep_061b6594:

    # MC "Ahh... Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:89
translate chinese Z_ES3_rep_e3dde0db:

    # Suri "*Lick! Lick!*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:93
translate chinese Z_ES3_rep_92e767ac:

    # MC "(God, her eyes are stunning!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:95
translate chinese Z_ES3_rep_fc220e33:

    # MC "(The way she looks at me while she licks my cock, is heart-melting!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:99
translate chinese Z_ES3_rep_ce40556e:

    # Suri "*Suck! Shlurp! Suck!*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:100
translate chinese Z_ES3_rep_9e77a3f1:

    # Zuri "*Suck Suck!*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:101
translate chinese Z_ES3_rep_31314dae:

    # MC "Ooohhh God! Mmmmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:105
translate chinese Z_ES3_rep_8921cf63:

    # MC "Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:107
translate chinese Z_ES3_rep_408b41bc:

    # Zuri "*Shluuuurrrrp!*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:108
translate chinese Z_ES3_rep_848628b1:

    # Suri "*SUCK SUCK!*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:112
translate chinese Z_ES3_rep_14d24d01:

    # MC "Hnnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:113
translate chinese Z_ES3_rep_77225479:

    # MC "I’m gonna cum! It’s too intense! AHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:115
translate chinese Z_ES3_rep_546f9a94:

    # Suri "*SHLURP! SUCK SUCK!*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:120
translate chinese Z_ES3_rep_cbfecc66:

    # MC "I’m cumming! Hnnnnggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:121
translate chinese Z_ES3_rep_703977fc_2:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:122
translate chinese Z_ES3_rep_619d9b75_1:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:131
translate chinese Z_ES3_rep_43a06055:

    # MC "AYAAAAAHHHHH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:132
translate chinese Z_ES3_rep_49b5500c:

    # MC "Oh God..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:133
translate chinese Z_ES3_rep_7fd86971:

    # Suri "Mmm... Salty!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:137
translate chinese Z_ES3_rep_c48a9090:

    # Zuri "You’ve seen what we can do now. How about you get us that third name?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:138
translate chinese Z_ES3_rep_1830a4fb:

    # Suri "Yeah, if you do that we’ll take your WHOLE cock in our mouths. Sound good?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:139
translate chinese Z_ES3_rep_faa6f0f7:

    # MC "Absolutely! You girls are incredible!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:147
translate chinese Z_ES3_rep_c96d59b1:

    # MC "I’ll go for the footjob."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:148
translate chinese Z_ES3_rep_9c193590:

    # Zuri "Mmm... Good choice. Go ahead and take your trousers off, then lie back on the bed."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:152
translate chinese Z_ES3_rep_3cbb8f41:

    # Suri "His cock is so big, Zuri! Hehe!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:153
translate chinese Z_ES3_rep_04dddf1e:

    # Zuri "It REALLY is! I hope he’s going to enjoy us rubbing our feet ALL over it."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:155
translate chinese Z_ES3_rep_7b181785:

    # MC "(Twins rubbing their feet over my cock? It’s my lucky day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:157
translate chinese Z_ES3_rep_34b3541c:

    # MC "(Two girls rubbing their feet over my cock? It’s my lucky day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:162
translate chinese Z_ES3_rep_e3a07d04:

    # Suri "And here we go. Hehe! I can feel it twitching beneath my toes!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:164
translate chinese Z_ES3_rep_482a2537:

    # Suri "I think he’s enjoying this!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:165
translate chinese Z_ES3_rep_ec1c995b:

    # MC "Mmm! Oh yeah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:170
translate chinese Z_ES3_rep_605760d3:

    # Zuri "There’s going to be MANY more things we can do for you. "
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:171
translate chinese Z_ES3_rep_c84a8a0f:

    # Suri "We can give you sooo much pleasure."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:172
translate chinese Z_ES3_rep_4ed66755:

    # Zuri "And the only thing you have to do, is lie back and enjoy it."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:176
translate chinese Z_ES3_rep_73049590:

    # MC "Mmm! Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:178
translate chinese Z_ES3_rep_862ead3e:

    # MC "(This feels so fucking good...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:179
translate chinese Z_ES3_rep_b57afe7c:

    # Suri "Maybe we’ll even let you fuck our pussies someday."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:183
translate chinese Z_ES3_rep_25db98a6:

    # Zuri "And the only thing you need to do - to keep earning these rewards - is get us those names."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:184
translate chinese Z_ES3_rep_d4a1a6dc:

    # Zuri "Simple, right?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:185
translate chinese Z_ES3_rep_80e3caf3:

    # MC "Ah... uh huh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:189
translate chinese Z_ES3_rep_90fab4dc:

    # Suri "What’s wrong, kid? Would you like us to go faster?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:191
translate chinese Z_ES3_rep_0f2a9d67:

    # Suri "What’s wrong, pal? Would you like us to go faster?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:193
translate chinese Z_ES3_rep_76f21560:

    # MC "God yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:194
translate chinese Z_ES3_rep_fdcbcfd4:

    # Zuri "Let’s speed things up, Suri."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:198
translate chinese Z_ES3_rep_2b3f583a:

    # MC "Ooh! God... That’s amazing..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:200
translate chinese Z_ES3_rep_6bd7cea4:

    # MC "(I shouldn’t be doing this to Dad’s company... but they’re so fucking sexy...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:202
translate chinese Z_ES3_rep_36c414ff:

    # MC "(I shouldn’t be doing this to Bob’s company... but they’re so fucking sexy...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:203
translate chinese Z_ES3_rep_b46540b1:

    # MC "(My cock is so hard right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:207
translate chinese Z_ES3_rep_f4473d30:

    # MC "AH! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:209
translate chinese Z_ES3_rep_67a30b90:

    # Suri "Sounds like this kid isn’t gonna last much longer!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:211
translate chinese Z_ES3_rep_866080cb:

    # Suri "Sounds like this guy isn’t gonna last much longer!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:212
translate chinese Z_ES3_rep_8bd4b9c5:

    # Zuri "Aww, what a shame."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:216
translate chinese Z_ES3_rep_e50d7037:

    # Suri "Are you gonna cum, kid?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:218
translate chinese Z_ES3_rep_542994e9:

    # Suri "Are you gonna cum, pal?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:219
translate chinese Z_ES3_rep_8d81c052:

    # Zuri "Yeah, are you gonna cum all over our feet?"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:220
translate chinese Z_ES3_rep_7e167dcc:

    # MC "Mmmm! Ahhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:224
translate chinese Z_ES3_rep_39da96e9:

    # MC "Fuck! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:225
translate chinese Z_ES3_rep_a22443d9:

    # MC "Hnnnnnngggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:226
translate chinese Z_ES3_rep_d27690de:

    # Suri "That’s it, cum for me! Cum for me now!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:230
translate chinese Z_ES3_rep_0bd7c4d4:

    # Suri "Squirt your cum all over my toes!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:231
translate chinese Z_ES3_rep_cb559623:

    # MC "AHH! AHHHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:241
translate chinese Z_ES3_rep_c469efae:

    # MC "Oooh.... *Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:243
translate chinese Z_ES3_rep_8e9728d9:

    # Zuri "Wow! That’s A LOT of cum, kid."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:244
translate chinese Z_ES3_rep_61940e2e:

    # Suri "We can do this again, kid. All you have to do is get us more names. Okay?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:246
translate chinese Z_ES3_rep_c83fee11:

    # Zuri "Wow! That’s A LOT of cum, pal."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:247
translate chinese Z_ES3_rep_b0cb966f:

    # Suri "We can do this again, pal. All you have to do is get us more names. Okay?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:248
translate chinese Z_ES3_rep_98da0aa8:

    # MC "*Pant* Y-Yeah, okay..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:257
translate chinese Z_ES3_rep_8ea7df0f_1:

    # Zuri "Welcome back, [player_name]."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:258
translate chinese Z_ES3_rep_94769793:

    # Zuri "Thanks again for your help! Let’s go to our - room of pleasure."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:266
translate chinese Z_ES3_rep_2ceb05d6:

    # Zuri "You’ve done another excellent job for us."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:268
translate chinese Z_ES3_rep_ee0f969d:

    # Suri "Yeah, you really came through, kid. You’re gonna make us super rich!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:270
translate chinese Z_ES3_rep_96a274eb:

    # Suri "Yeah, you really came through, pal. You’re gonna make us super rich!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:271
translate chinese Z_ES3_rep_4e1fad0f:

    # MC "I get another reward now, right?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:272
translate chinese Z_ES3_rep_c22e842c:

    # Suri "Hehe... You do. I believe we promised you a blowjob."
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:277
translate chinese Z_ES3_rep_a5dfc68c:

    # Suri "Mmm, I can’t wait to suck on his cock. It looked sooo delicious, last time we did it!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:278
translate chinese Z_ES3_rep_662924ae:

    # Zuri "Well? What are we waiting for? Let’s get these pants off him."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:279
translate chinese Z_ES3_rep_24ffa1d3:

    # MC "(This is gonna be great!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:283
translate chinese Z_ES3_rep_e1e75030:

    # Suri "So, which of us gets to suck it first?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:284
translate chinese Z_ES3_rep_0520c2f1:

    # MC "I’m not fussy!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:285
translate chinese Z_ES3_rep_8d735901:

    # Zuri "Be my guest, Suri!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:289
translate chinese Z_ES3_rep_85aa98a0:

    # Zuri "If you enjoy us doing this, then just wait till you see what we have in store for you, for the grand finale!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:290
translate chinese Z_ES3_rep_58168956:

    # Suri "Yeah, we’ll blow your cock today, but next time - we’ll blow your mind!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:294
translate chinese Z_ES3_rep_7f56b20a:

    # Suri "Are you always this hard, kid?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:296
translate chinese Z_ES3_rep_e460abf1:

    # Suri "Are you always this hard, pal?"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:297
translate chinese Z_ES3_rep_dfa3538d:

    # Suri "I don't think I've ever seen you without a massive erection!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:298
translate chinese Z_ES3_rep_c18a7f20:

    # MC "It’s hard not to have one, when I’m near someone as beautiful as you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:302
translate chinese Z_ES3_rep_703977fc_3:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:303
translate chinese Z_ES3_rep_619d9b75_2:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:304
translate chinese Z_ES3_rep_f2e8de7c:

    # MC "Mmm... That’s good. RIght there..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:308
translate chinese Z_ES3_rep_fe9e5f00:

    # Suri "*Suuuuck*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:309
translate chinese Z_ES3_rep_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:310
translate chinese Z_ES3_rep_826cf9ed:

    # MC "(I can feel Suri’s mouth, wrapped around the tip of my cock. It’s so hot and wet!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:314
translate chinese Z_ES3_rep_8aebcbb8:

    # MC "God... Mmmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:316
translate chinese Z_ES3_rep_619d9b75_3:

    # Zuri "*Lick Lick*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:318
translate chinese Z_ES3_rep_dd163d14:

    # Suri "*Shluuurrrp*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:322
translate chinese Z_ES3_rep_975cd7e9:

    # MC "(This is too much! Their tongues are so good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:323
translate chinese Z_ES3_rep_f9b52d56:

    # MC "(Who knew, corporate espionage could feel so right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:324
translate chinese Z_ES3_rep_6e28ed50:

    # Zuri "Mmmm..."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:325
translate chinese Z_ES3_rep_703977fc_4:

    # Suri "*Lick Lick*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:329
translate chinese Z_ES3_rep_e5cdb1e6:

    # Zuri "*Suck Suck*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:332
translate chinese Z_ES3_rep_ea2be631:

    # MC "(Damn, Zuri is just as good at sucking cock, as her twin sister is!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:334
translate chinese Z_ES3_rep_3a5fe5b2:

    # MC "(Damn, Zuri is just as good at sucking cock as Suri!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:335
translate chinese Z_ES3_rep_df1e2b98:

    # MC "(The two of them together, are fucking incredible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:339
translate chinese Z_ES3_rep_0ba9371f:

    # Zuri "*GULP*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:340
translate chinese Z_ES3_rep_634d50a1:

    # MC "Fuck! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:341
translate chinese Z_ES3_rep_259ca6cf:

    # MC "(I can feel Zuri’s tight throat around my glans!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:345
translate chinese Z_ES3_rep_9da31cb4:

    # MC "(If she keeps this up, I’m gonna cum! It’s too intense!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:346
translate chinese Z_ES3_rep_a8a8b750:

    # MC "Hnnng! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:347
translate chinese Z_ES3_rep_a267a93e:

    # Zuri "*Shluuuuuurrrrp*"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:351
translate chinese Z_ES3_rep_58b6bc32:

    # Suri "MMPPFFF!!!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:352
translate chinese Z_ES3_rep_cc37b6d2:

    # Zuri "Oops! Sorry, Suri!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:353
translate chinese Z_ES3_rep_1aa0401f:

    # MC "Ahhh! Huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:357
translate chinese Z_ES3_rep_d7996665:

    # Zuri "Sorry, it looks like my sister’s head has... accidentally fallen on your cock."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:359
translate chinese Z_ES3_rep_4453a5b4:

    # Zuri "Sorry, it looks like Suri’s head has accidentally fallen on your cock."
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:360
translate chinese Z_ES3_rep_1b5ee3e8:

    # Suri "Mmmpfff! *SHLURRRRP*"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:361
translate chinese Z_ES3_rep_be8fb162:

    # MC "Oh! Ahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:365
translate chinese Z_ES3_rep_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:366
translate chinese Z_ES3_rep_e519e8a9:

    # Zuri "Drink it ALL up, Suri!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:367
translate chinese Z_ES3_rep_6ad09894:

    # Suri "*SHLURRRP!* COUGH!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:368
translate chinese Z_ES3_rep_13deecc1:

    # MC "HNNNNNGGG!!! UGH! YES!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:376
translate chinese Z_ES3_rep_4d81992e:

    # MC "(I can feel my cock twitching in her mouth! She’s drinking me dry!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:380
translate chinese Z_ES3_rep_9ca5634d:

    # MC "Wow... That was amazing..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:381
translate chinese Z_ES3_rep_c7377f31:

    # Suri "Zuri! You naughty bitch!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:382
translate chinese Z_ES3_rep_42702283:

    # Zuri "Hehe! I couldn’t resist!"
    Zuri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:383
translate chinese Z_ES3_rep_de249513:

    # Suri "I’m gonna have to spank you later on tonight, for that!"
    Suri ""

# game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:384
translate chinese Z_ES3_rep_51240ede:

    # Zuri "Feel free to go now, [player_name]."
    Zuri ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:14
    old "{color=#ff8000}Lick and Footjob.{/color}"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/Z_ES3_rep.rpy:14
    old "{color=#ff8000}Blowjob.{/color}"
    new ""

