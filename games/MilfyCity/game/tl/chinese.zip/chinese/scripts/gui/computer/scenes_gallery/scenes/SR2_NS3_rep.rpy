﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:13
translate chinese SR2_NS3_rep_28fadb05:

    # Sara "Hi, [player_name]. I was beginning to think you’d forgotten about me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:14
translate chinese SR2_NS3_rep_c697914f:

    # MC "Of course not! I couldn’t wait for tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:15
translate chinese SR2_NS3_rep_793b268c:

    # Sara "I hope you’re not scared of heights, by the way. We ARE going to be climbing ALL the way up onto the garage roof."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:19
translate chinese SR2_NS3_rep_8d8a0955:

    # MC "Pfft! That’s nothing! I’ll be able to help you up, there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:20
translate chinese SR2_NS3_rep_6801ac54:

    # Sara "Aww, you’re sweet. Let’s get going! We’re missing the stars!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:22
translate chinese SR2_NS3_rep_41a51c9b:

    # MC "Just be careful not to be too loud - we don’t want to wake Mom and Dad."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:24
translate chinese SR2_NS3_rep_9ab2e52b:

    # MC "Just be careful not to be too loud - we don’t want to wake everyone up."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:28
translate chinese SR2_NS3_rep_2b1fdfe1:

    # Sara "Oops! Sorry, I’ll try to keep my voice down. I’m just so excited."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:29
translate chinese SR2_NS3_rep_cfebd804:

    # MC "That’s fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:30
translate chinese SR2_NS3_rep_48605822:

    # MC "(There’s a nice floral scent in the air - is she wearing a new perfume?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:34
translate chinese SR2_NS3_rep_138332f3:

    # Sara "*Sigh*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:35
translate chinese SR2_NS3_rep_64685318:

    # MC "(That was a big sigh. How could she turn from excited to exasperation so quickly?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:36
translate chinese SR2_NS3_rep_fd14fda2:

    # MC "Is something wrong, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:37
translate chinese SR2_NS3_rep_ceaa8dc3:

    # Sara "It’s nothing... I was just kind of hoping that you’d kiss me as soon as we met."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:38
translate chinese SR2_NS3_rep_c70969d1:

    # MC "I could kiss you now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:42
translate chinese SR2_NS3_rep_613665b5:

    # Sara "I’d REALLY like that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:43
translate chinese SR2_NS3_rep_df3c2a35:

    # Sara "Every time you kiss me it feels like there are butterflies in my stomach. It’s like all the weight of life’s problems just float away."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:45
translate chinese SR2_NS3_rep_f4e21001:

    # Sara "I love you, [player_name]. Much more than any sis really should..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:47
translate chinese SR2_NS3_rep_b416e79c:

    # Sara "I love you, [player_name]. Much more than anyone probably should love another person."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:51
translate chinese SR2_NS3_rep_932f985a:

    # Sara "I hope you feel as strongly for me as I do for you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:52
translate chinese SR2_NS3_rep_70c2d8c4:

    # MC "(Her green eyes rival the stars in their beauty tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:53
translate chinese SR2_NS3_rep_9869fa2c:

    # MC "I do, Sara. I love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:57
translate chinese SR2_NS3_rep_c90f6004:

    # Sara "Hehe... Sorry about the frumpy jumper. I guessed it was going to be cold."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:58
translate chinese SR2_NS3_rep_ceb91264:

    # MC "I think it looks good on you. Just answer me one question."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:59
translate chinese SR2_NS3_rep_bb5ae6c5:

    # Sara "Yes?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:63
translate chinese SR2_NS3_rep_4989233b:

    # MC "You thought it was going to be cold?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:64
translate chinese SR2_NS3_rep_4bf2cda1:

    # Sara "Yeah, I did."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:68
translate chinese SR2_NS3_rep_4ab31891:

    # MC "And yet, you decided not to wear any leggings?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:69
translate chinese SR2_NS3_rep_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:70
translate chinese SR2_NS3_rep_e4eb887e:

    # MC "You should know by now, how turned on I get by your body. Especially your slender legs."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:74
translate chinese SR2_NS3_rep_3356ecab:

    # Sara "I love you so much. Hurry up and kiss me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:76
translate chinese SR2_NS3_rep_560f3cf2:

    # MC "(Sara needed a date like this. It offers her some respite from being grounded.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:77
translate chinese SR2_NS3_rep_802482ab:

    # MC "(I hope that Mom finally changes her mind and lets up on her soon.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:79
translate chinese SR2_NS3_rep_b1d76bed:

    # MC "(Sara needed a date like this. It offers her some relief and fun from all that stress coming from studying very hard.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:80
translate chinese SR2_NS3_rep_5e2e9eb8:

    # MC "(I hope I’m not disturbing her study too much. I want her to have a lot of time for me again very soon.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:84
translate chinese SR2_NS3_rep_0c330e25:

    # MC "Mmmm...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:85
translate chinese SR2_NS3_rep_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:88
translate chinese SR2_NS3_rep_09eb4c67:

    # MC "(I hope none of the family wake up and look out their windows right now... It’d give Dad a heart attack!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:90
translate chinese SR2_NS3_rep_77fdf1ab:

    # MC "(I hope nobody wakes up and looks out their windows right now... It’d give Bob a heart attack since he probably doesn't expect to see his tenants kissing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:95
translate chinese SR2_NS3_rep_db8a1ec0:

    # Sara "Mmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:96
translate chinese SR2_NS3_rep_baaffcad:

    # Sara "(I go weak, each time he kisses me like this. It’s like all the energy just leaves my body...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:97
translate chinese SR2_NS3_rep_e2a7a388:

    # Sara "(I’ll have to break it soon, or we’ll get distracted and miss the best part of the night sky!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:101
translate chinese SR2_NS3_rep_35b1163a:

    # Sara "*Pant* W-Wow..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:102
translate chinese SR2_NS3_rep_ab3a7c79:

    # Sara "(That was sensational...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:106
translate chinese SR2_NS3_rep_79e0ca0b:

    # Sara "Just like that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:107
translate chinese SR2_NS3_rep_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:108
translate chinese SR2_NS3_rep_39f6d984:

    # Sara "That’s EXACTLY how I want to be kissed when we meet. It’s just perfect."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:109
translate chinese SR2_NS3_rep_bcdc8dda:

    # MC "I’ll try and remember to do that more often for you, then."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:117
translate chinese SR2_NS3_rep_e48de3a8:

    # Sara "C’mon! Hurry up, [player_name]! We don’t have forever!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:118
translate chinese SR2_NS3_rep_09ee9127:

    # MC "Yeah, I’m coming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:119
translate chinese SR2_NS3_rep_d3278f17:

    # Sara "I don’t think I’ll be able to get up onto the roof without your help. Can you give me a boost?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:123
translate chinese SR2_NS3_rep_f4fbb764:

    # MC "Sure, no problem. How’s this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:124
translate chinese SR2_NS3_rep_39b9fc8e:

    # Sara "I’m almost there! Just a little bit more!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:125
translate chinese SR2_NS3_rep_e0795e85:

    # Sara "Make sure you don’t drop me!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:129
translate chinese SR2_NS3_rep_531cef67:

    # MC "Don’t worry, I won’t drop you, Sara. There’s nothing at all that could possibly distract me right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:130
translate chinese SR2_NS3_rep_d9070ebf:

    # Sara "You’re looking at my panties, aren’t you?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:131
translate chinese SR2_NS3_rep_dce9cdcb:

    # MC "...maybe."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:135
translate chinese SR2_NS3_rep_62ab56d8:

    # Sara "Pervert!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:136
translate chinese SR2_NS3_rep_830367dd:

    # MC "I can’t help it! It’s just the angle you were at!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:140
translate chinese SR2_NS3_rep_92a3ba01:

    # Sara "Uh huh, I’m sure!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:141
translate chinese SR2_NS3_rep_9015dfe3:

    # Sara "You can find your own way up!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:142
translate chinese SR2_NS3_rep_d8332194:

    # MC "Wait - aren’t you going to give me a hand?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:146
translate chinese SR2_NS3_rep_4d517552:

    # MC "Hello?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:147
translate chinese SR2_NS3_rep_c8b18188:

    # MC "Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:148
translate chinese SR2_NS3_rep_929d9ee1:

    # MC "*Sigh...*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:152
translate chinese SR2_NS3_rep_75f04e4d:

    # MC "Hnnngg! C’mon! Almost there!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:153
translate chinese SR2_NS3_rep_c4d40ba2:

    # MC "(Just a couple more inches...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:157
translate chinese SR2_NS3_rep_98e2a470:

    # MC "*Phew!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:158
translate chinese SR2_NS3_rep_2b84bb2b:

    # MC "I finally made it, Sara!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:159
translate chinese SR2_NS3_rep_c8b18188_1:

    # MC "Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:164
translate chinese SR2_NS3_rep_dc5ab8aa:

    # MC "Sara, are you okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:165
translate chinese SR2_NS3_rep_d7f5df3c:

    # Sara "They’re all so beautiful. Look at them, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:166
translate chinese SR2_NS3_rep_f4ba1aa0:

    # Sara "Sit down beside me."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:170
translate chinese SR2_NS3_rep_cf37c3e3:

    # MC "Wow, we got clear skies tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:171
translate chinese SR2_NS3_rep_964c81eb:

    # Sara "There’s so many... you couldn’t even begin to count them..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:175
translate chinese SR2_NS3_rep_cc6cfc8a:

    # Sara "I’d love to go exploring them someday. Just travelling from star to star."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:176
translate chinese SR2_NS3_rep_6cc2a6e8:

    # Sara "It would be so wonderful..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:177
translate chinese SR2_NS3_rep_963d57fe:

    # Sara "Just look at the colours: Purples and greens and yellows..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:181
translate chinese SR2_NS3_rep_d0cb0c34:

    # Sara "The greatest imagination in the world couldn’t come up with something as perfect as this."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:182
translate chinese SR2_NS3_rep_db2bcfc8:

    # Sara "It’s... infinite."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:183
translate chinese SR2_NS3_rep_a0d3e15f:

    # Sara "We’re like ants in a sandbox, staring out into a garden we could never fully explore."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:187
translate chinese SR2_NS3_rep_7fe18a4e:

    # MC "There’s billions of those stars. And yet, the one place I’d choose to be is exactly where I am right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:188
translate chinese SR2_NS3_rep_05380ad5:

    # MC "Right here on this roof, beside you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:189
translate chinese SR2_NS3_rep_80d1d31e:

    # Sara "Really?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:193
translate chinese SR2_NS3_rep_69915823:

    # MC "Really, Sara. That’s the truth."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:194
translate chinese SR2_NS3_rep_f04d906a:

    # Sara "I’m sorry I’m not ready yet."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:195
translate chinese SR2_NS3_rep_32617e96:

    # MC "Ready for what?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:199
translate chinese SR2_NS3_rep_aaf0e409:

    # Sara "For sex... I want to be 100 percent sure that you are the one... It’s important for me. Just please don't take it as something bad or that I am not trust you..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:200
translate chinese SR2_NS3_rep_4c00f3db:

    # Sara "I know you want it - and if I can’t give you it then some other girl will."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:201
translate chinese SR2_NS3_rep_de7fabb3:

    # MC "It’s not like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:202
translate chinese SR2_NS3_rep_685f6300:

    # Sara "Please... I’ve seen how other girls in college look at you. Even after you made a fool of yourself in front of professor Celia, they still think you’re hot."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:203
translate chinese SR2_NS3_rep_421de18e:

    # MC "(Ugh, I wish she didn’t bring up that incident with Ms. Celia. I’m STILL cringing when I think about it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:204
translate chinese SR2_NS3_rep_2423feda:

    # Sara "I want to go further with you tonight. Could... we try anal?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:205
translate chinese SR2_NS3_rep_7b02e252:

    # MC "Are you sure? We don’t have to-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:206
translate chinese SR2_NS3_rep_a526799b:

    # Sara "I want to. I’m not ready to use my pussy yet, but I think... maybe I can do anal. I won’t know if I don’t try."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:210
translate chinese SR2_NS3_rep_1eebefd9:

    # MC "I don’t want to hurt you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:211
translate chinese SR2_NS3_rep_ce297bcc:

    # Sara "Y-You won’t hurt me... and I want it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:212
translate chinese SR2_NS3_rep_f5a15549:

    # MC "You don’t know that for sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:213
translate chinese SR2_NS3_rep_27df4561:

    # Sara "*Gulp* P-Please don’t try to talk me out of it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:217
translate chinese SR2_NS3_rep_1c5ec41c:

    # MC "Will you at least promise me that you’ll tell me to stop if it starts to hurt?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:218
translate chinese SR2_NS3_rep_117d3c2b:

    # Sara "... I promise."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:219
translate chinese SR2_NS3_rep_615eedc7:

    # MC "Okay."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:223
translate chinese SR2_NS3_rep_bc5ffff4:

    # MC "At least let me finger you for a bit first, to turn you on."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:224
translate chinese SR2_NS3_rep_b43e7a00:

    # Sara "I... Ahh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:225
translate chinese SR2_NS3_rep_1717532b:

    # MC "(Her pussy is so warm right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:229
translate chinese SR2_NS3_rep_3c7e487d:

    # Sara "W-Wait... Can we just... get straight to it?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:230
translate chinese SR2_NS3_rep_24d16f3f:

    # MC "Why? Is something wrong?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:234
translate chinese SR2_NS3_rep_e7dde135:

    # Sara "If we do foreplay, then I might... chicken out."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:235
translate chinese SR2_NS3_rep_94a7d704:

    # MC "If you're sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:236
translate chinese SR2_NS3_rep_4d3a1d77:

    # Sara "Y-Yeah, I think this is for the best."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:240
translate chinese SR2_NS3_rep_9092d6db:

    # MC "Do you want to take off your panties now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:241
translate chinese SR2_NS3_rep_a73e9591:

    # MC "Why do you look so shocked?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:242
translate chinese SR2_NS3_rep_92e16a5c:

    # Sara "I... You were just so forward about it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:243
translate chinese SR2_NS3_rep_c381649f:

    # MC "How am I going to fuck you if you’ve still got them on? Haha"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:247
translate chinese SR2_NS3_rep_e13dd671:

    # Sara "Fine, I’m taking them off now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:248
translate chinese SR2_NS3_rep_d140435d:

    # Sara "(God, I hope nobody sees us up here. I wonder if [player_name] has even thought about the risks of doing this.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:249
translate chinese SR2_NS3_rep_2f717c9d:

    # Sara "Umm... [player_name], do you think anyone will be able to see us up here?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:250
translate chinese SR2_NS3_rep_4708fe05:

    # MC "Nah, absolutely not. It’s too dark - plus we’re not near a main street. Do you know anyone who walks around looking at the roofs of houses?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:254
translate chinese SR2_NS3_rep_4d4b93ef:

    # Sara "*Gulp* If you say so."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:255
translate chinese SR2_NS3_rep_22c0fb02:

    # MC "It’ll be fine. As long as we’re quiet we shouldn’t get caught."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:257
translate chinese SR2_NS3_rep_ba7378dd:

    # MC "Plus, the rest of our family should have been asleep for A LONG time by now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:259
translate chinese SR2_NS3_rep_2efbea9f:

    # MC "Plus, the rest of the house should be deep asleep by now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:260
translate chinese SR2_NS3_rep_171a57d0:

    # MC "(Damn, it’s a shame I can’t use her pussy tonight. My cock would fit so snuggly in that tight little hole.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:264
translate chinese SR2_NS3_rep_6b86ceef:

    # Sara "O-Okay, I think I’m ready. How do you want me to do this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:265
translate chinese SR2_NS3_rep_8ab5e8a4:

    # MC "How about you lean forward over the tip of the roof? I’ll stand behind you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:266
translate chinese SR2_NS3_rep_1fd0a650:

    # Sara "Is it safe?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:267
translate chinese SR2_NS3_rep_3e56c1a0:

    # MC "It’ll be fine - it’s only a few feet. We’ll hardly hurt ourselves if we fall."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:271
translate chinese SR2_NS3_rep_546e8965:

    # Sara "Is this okay? Do you need me to angle my ass up more?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:272
translate chinese SR2_NS3_rep_734da78e:

    # MC "That’s perfect, Sara. Just stay like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:273
translate chinese SR2_NS3_rep_4e737e70:

    # MC "(What a view! This is either going to be the most unusual place I will ever have sex with a woman, in my life... Or the most unusual story of how a guy ended up in hospital!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:277
translate chinese SR2_NS3_rep_4126017d:

    # Sara "This is gonna feel weird, isn’t it?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:278
translate chinese SR2_NS3_rep_71491a3d:

    # MC "I... don’t know, Sara. Sorry, I’ve never had a dick in my ass before."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:279
translate chinese SR2_NS3_rep_c76a1a84:

    # Sara "Just... go slow, okay?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:284
translate chinese SR2_NS3_rep_3c8b4fb6:

    # MC "Try to relax, Sara. I’ll take things very slowly. And if you want me to stop, for any reason, just say."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:285
translate chinese SR2_NS3_rep_800c1314:

    # MC "I don’t want to cause you any pain. For all I know, it might take us two or three attempts, before I can even get it all the way in."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:286
translate chinese SR2_NS3_rep_2130b29d:

    # MC "We’ll just take things as they come, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:290
translate chinese SR2_NS3_rep_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:291
translate chinese SR2_NS3_rep_879bbc29:

    # Sara "*Deep breath*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:292
translate chinese SR2_NS3_rep_11d17b9c:

    # Sara "(I just have to keep breathing and focus on keeping my voice down.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:293
translate chinese SR2_NS3_rep_3e4164c6:

    # Sara "(I can feel his glans pushing up against my asshole... This is it!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:297
translate chinese SR2_NS3_rep_3697d17d:

    # Sara "Mmmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:298
translate chinese SR2_NS3_rep_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:300
translate chinese SR2_NS3_rep_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:301
translate chinese SR2_NS3_rep_828c5f30:

    # Sara "(Goddamn! His cock is fucking huge!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:305
translate chinese SR2_NS3_rep_6ea1674c:

    # Sara "Ahhh.... Ugh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:306
translate chinese SR2_NS3_rep_d8d815a3:

    # Sara "(Why didn’t I think to start with something small first? Like a finger or two?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:307
translate chinese SR2_NS3_rep_586ab9ce:

    # MC "(Oooh! This is great! She’s so tight that I can barely get it in!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:311
translate chinese SR2_NS3_rep_9c31ca3c:

    # MC "Ahh... Yes... Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:312
translate chinese SR2_NS3_rep_5b72e012:

    # Sara "Ow..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:313
translate chinese SR2_NS3_rep_93e77b2e:

    # MC "Fuck, this is good..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:317
translate chinese SR2_NS3_rep_d0e370a2:

    # Sara "Ah... Ah... Oww... Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:318
translate chinese SR2_NS3_rep_01d05623:

    # MC "(I didn’t manage to push my cock very far in. I’ll pull out and try again.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:319
translate chinese SR2_NS3_rep_dc992cb7:

    # MC "How are you holding up there, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:320
translate chinese SR2_NS3_rep_01116398:

    # Sara "Fine! Ugh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:324
translate chinese SR2_NS3_rep_aad9bb41:

    # MC "I’m going to try thrusting it in again. I’ll go slowly."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:325
translate chinese SR2_NS3_rep_d884e337:

    # Sara "(Fuck! He’s so damn thick! I don’t know if I can handle this much longer!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:329
translate chinese SR2_NS3_rep_b318b000:

    # MC "Ooohhh yeah... That’s the spot!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:331
translate chinese SR2_NS3_rep_0fe3c5b3:

    # Sara "AHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:333
translate chinese SR2_NS3_rep_627c53aa:

    # MC "(Damn! She’s being REALLY loud right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:337
translate chinese SR2_NS3_rep_5ce64851:

    # Sara "(SHIT!! FUCK!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:339
translate chinese SR2_NS3_rep_965b0f1e:

    # Sara "(Damn! This hurts so much! I should NEVER have agreed to this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:341
translate chinese SR2_NS3_rep_a03df080:

    # Sara "(Damn! This feels weird! I feel pleasure and something ELSE at the same time!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:342
translate chinese SR2_NS3_rep_0800b6c9:

    # Sara "(Why didn’t I just let him fuck my pussy?! God DAMN!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:347
translate chinese SR2_NS3_rep_8c32044e:

    # Sara "Fuck! It hurts! Pull it out! Pull it out!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:349
translate chinese SR2_NS3_rep_92ebb7a2:

    # Sara "Ah! Fuck! It feels weird. Maybe pull it out or try a little slower."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:350
translate chinese SR2_NS3_rep_a010f877:

    # MC "Really? I’m not even halfway in yet!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:352
translate chinese SR2_NS3_rep_431f60e7:

    # Sara "It’s sooooo sore!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:354
translate chinese SR2_NS3_rep_a524605a:

    # Sara "It’s sooooo dry!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:355
translate chinese SR2_NS3_rep_671d92fa:

    # MC "(Damn, I’m not that far from cumming. I could VERY quickly thrust a few more times and cum in her ass...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:361
translate chinese SR2_NS3_rep_eff95422:

    # MC "(A few more thrusts won’t hurt her. I’ll quickly cum and then we’ll be done with it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:362
translate chinese SR2_NS3_rep_41085739:

    # Sara "Are you pulling out, [player_name]?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:366
translate chinese SR2_NS3_rep_1d486d0b:

    # MC "Mmm! Ahh! Ahh! Hnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:367
translate chinese SR2_NS3_rep_e21f8708:

    # Sara "AHHH! AHHH!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:368
translate chinese SR2_NS3_rep_fad6ffd3:

    # Sara "FUCK! OUCH! OWIE! TAKE IT OUT!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:370
translate chinese SR2_NS3_rep_4aed8b6c:

    # MC "Mmm! Ahh! Just a few more thrusts okay!?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:371
translate chinese SR2_NS3_rep_430e1aef:

    # Sara "O-Okay! Only a few! Ahh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:372
translate chinese SR2_NS3_rep_83911e09:

    # Sara "FUCK! AH! HARDER!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:373
translate chinese SR2_NS3_rep_94fa733a:

    # Sara "[player_name]!!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:377
translate chinese SR2_NS3_rep_bafed9f0:

    # MC "HNNNNGGG! UGH! YES!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:379
translate chinese SR2_NS3_rep_b26e402c:

    # MC "(Fuck! This feels good! Her ass is so tight, it's milking my cock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:381
translate chinese SR2_NS3_rep_5aa5de31:

    # Sara "AHH! AHH OWWW!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:390
translate chinese SR2_NS3_rep_db1fd57c:

    # MC "Phew..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:391
translate chinese SR2_NS3_rep_00c1f838:

    # Sara "Oww.... Ouch..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:393
translate chinese SR2_NS3_rep_1f7ba49c:

    # Sara "Why’d you do that, [player_name]? It REALLY hurt!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:395
translate chinese SR2_NS3_rep_1ad2a84b:

    # Sara "That was the weirdest feeling I ever had... Ah..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:396
translate chinese SR2_NS3_rep_e8ba1c43:

    # MC "Sorry Sara, I was just so close to cumming."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:398
translate chinese SR2_NS3_rep_d61dce3e:

    # Sara "Hmmpph... Just don’t do it again!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:400
translate chinese SR2_NS3_rep_eefba7ff:

    # Sara "Hmmppph... Just let’s prepare better the next time!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:406
translate chinese SR2_NS3_rep_28c134ca:

    # MC "(I better pull it out, I don’t want to hurt Sara by accident.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:407
translate chinese SR2_NS3_rep_949585e6:

    # MC "It’s okay, Sara, I’m pulling out now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:408
translate chinese SR2_NS3_rep_18acdf28:

    # Sara "Oww... Th-Thanks, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:412
translate chinese SR2_NS3_rep_98b1e218:

    # MC "There we go, that’s it out."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:413
translate chinese SR2_NS3_rep_9d4155ae:

    # Sara "I’m sorry you didn’t get to cum."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:414
translate chinese SR2_NS3_rep_22594833:

    # MC "It’s okay, Sara. I wasn’t going to have any fun if you were in pain."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:421
translate chinese SR2_NS3_continue_rep_a949f462:

    # Sara "That was really, really sore..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:423
translate chinese SR2_NS3_continue_rep_635dc3fb:

    # Sara "That was really, really dry..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:424
translate chinese SR2_NS3_continue_rep_466368d7:

    # MC "I’ll tell you what, how about I go out and I buy us some lube instead?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:425
translate chinese SR2_NS3_continue_rep_5c2af5d8:

    # Sara "Lube?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:426
translate chinese SR2_NS3_continue_rep_e546ae95:

    # MC "Yeah, it’s a slippery stuff. I can get one from the sex shop."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:431
translate chinese SR2_NS3_continue_rep_285c9893:

    # Sara "What do I do with it?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:433
translate chinese SR2_NS3_continue_rep_e107c624:

    # Sara "That’s a good idea... And how will you plan to use it?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:434
translate chinese SR2_NS3_continue_rep_d020f891:

    # MC "I’ll put it in your ass and around my cock. It should help it slide in easier."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:436
translate chinese SR2_NS3_continue_rep_e571876b:

    # Sara "Will it... make it less sore?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:437
translate chinese SR2_NS3_continue_rep_d0392d47:

    # MC "It should. If we’re lucky it MIGHT even make it feel good for you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:440
translate chinese SR2_NS3_continue_rep_69ebfdef:

    # Sara "No way! I don’t think I could EVER enjoy what we just did! Haha!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:442
translate chinese SR2_NS3_continue_rep_e8cf4d0a:

    # Sara "Will it... make it less dry?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:443
translate chinese SR2_NS3_continue_rep_869d7e9c:

    # Sara "Sounds great, we should have used it today..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:444
translate chinese SR2_NS3_continue_rep_ff89060b:

    # MC "We should have. If we're lucky it MIGHT even make it feel really good for you too!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:448
translate chinese SR2_NS3_continue_rep_7892d5fc:

    # Sara "Hmm! Maybe! We’ll have to try it out.. Haha! "
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:449
translate chinese SR2_NS3_continue_rep_6b854c1a:

    # MC "That’s okay, we don’t have to do it again."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:450
translate chinese SR2_NS3_continue_rep_8a365d6d:

    # Sara "But I WANT to do it for you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:451
translate chinese SR2_NS3_continue_rep_75e0f11b:

    # MC "Sara, you don’t have to offer anal if it’s going to hur-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:455
translate chinese SR2_NS3_continue_rep_33c3150f:

    # Sara "Mwah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:456
translate chinese SR2_NS3_continue_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:457
translate chinese SR2_NS3_continue_rep_65a61302:

    # MC "(Sara doesn't need to put herself through trials like this to make me happy. She should know by now that I’m already happy with her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:461
translate chinese SR2_NS3_continue_rep_cfc51d7c:

    # Sara "Thank you, [player_name]. You’ve made this one of the most magical nights of my life."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:462
translate chinese SR2_NS3_continue_rep_9d37a09f:

    # Sara "Can we just agree to forget that the last bit on the roof happened?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:463
translate chinese SR2_NS3_continue_rep_ecb3f264:

    # MC "Haha, sure... Staring at the stars was my favourite part anyway."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:464
translate chinese SR2_NS3_continue_rep_696935f8:

    # Sara "Hehe, mine too."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:466
translate chinese SR2_NS3_continue_rep_e55aa971:

    # MC "C’mon, we better sneak back inside before Mom or Dad notice us missing. I’ll help you down from the roof."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:468
translate chinese SR2_NS3_continue_rep_d463a3dc:

    # MC "C’mon, we better go back to the house. I’ll help you down from the roof."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:469
translate chinese SR2_NS3_continue_rep_9349f99b:

    # Sara "Thanks, [player_name]."
    Sara ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:357
    old "A few more thrusts won’t hurt her. Right?"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/SR2_NS3_rep.rpy:357
    old "I better finish up. I don’t want to hurt her by mistake."
    new ""

