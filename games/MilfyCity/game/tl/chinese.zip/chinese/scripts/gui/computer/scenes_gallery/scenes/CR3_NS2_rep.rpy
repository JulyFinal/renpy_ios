﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:16
translate chinese CR3_NS2_rep_a1e2a683:

    # Caroline "Ah... Ah! Ah! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:17
translate chinese CR3_NS2_rep_3ee080d3:

    # MC "Huh? (What’s that noise? Is someone screaming?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:18
translate chinese CR3_NS2_rep_51f124d8:

    # MC "(It sounds like it’s coming from Caroline’s bedroom.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:22
translate chinese CR3_NS2_rep_e8de81dc:

    # Caroline "Ohhh! Ahh! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:25
translate chinese CR3_NS2_rep_00f55b11:

    # MC "(I should probably check this out. If I’m lucky, I might catch my older sister masturbating!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:27
translate chinese CR3_NS2_rep_9c767198:

    # MC "(I should probably check this out. If I’m lucky, I might catch her masturbating!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:29
translate chinese CR3_NS2_rep_49d27a50:

    # MC "(Here we go... Hopefully her bedroom door isn’t too creaky.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:33
translate chinese CR3_NS2_rep_cb80268c:

    # Caroline "Ah! Mmm! Oh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:34
translate chinese CR3_NS2_rep_1482605d:

    # MC "(Oh yeah! Perfect timing! Just like I thought. She’s masturbating, when she thinks everyone is asleep!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:35
translate chinese CR3_NS2_rep_a4d72713:

    # MC "(I’m surprised she hasn’t woken anybody with her screaming!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:39
translate chinese CR3_NS2_rep_b34abcca:

    # MC "(I wonder what she’s fantasising about? Whatever it is, she’s far too deeply engrossed in it, to notice ME at the door.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:40
translate chinese CR3_NS2_rep_4708bf0c:

    # Caroline "Mmm... fuck... Oh... God..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:42
translate chinese CR3_NS2_rep_5cd0cd74:

    # "*Buzzz*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:47
translate chinese CR3_NS2_rep_770cbd84:

    # MC "(It sounds like she’s got a vibrating dildo too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:48
translate chinese CR3_NS2_rep_1a028add:

    # MC "(No wonder she’s moaning, so loudly!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:49
translate chinese CR3_NS2_rep_a063c075:

    # Caroline "Ah! AHHHHH!!!! Fuck... Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:53
translate chinese CR3_NS2_rep_cbcbe64f:

    # "*Buzz Buzz*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:55
translate chinese CR3_NS2_rep_d97b521e:

    # Caroline "Mmm... (The rain was pouring down outside and we were completely lost... My uniform had been soaked through to my skin.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:56
translate chinese CR3_NS2_rep_6b7c1dbd:

    # Caroline "([player_name] and I were lucky to find that abandoned little cottage in the woods. We built a small fire, but there was no way either of us could sit - in our sodden clothes. We had to strip them off...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:61
translate chinese CR3_NS2_rep_cbcbe64f_1:

    # "*Buzz Buzz*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:63
translate chinese CR3_NS2_rep_e5c707e5:

    # Caroline "Ah... Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:64
translate chinese CR3_NS2_rep_1ba7d532:

    # Caroline "(We were sitting at opposite sides of the small log cabin - basking in the glow of the fire.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:66
translate chinese CR3_NS2_rep_90571755:

    # Caroline "(But I keep catching my brother, stealing glances at my naked body...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:68
translate chinese CR3_NS2_rep_cd26fc38:

    # Caroline "(But I keep catching my best friend stealing glances at my naked body...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:72
translate chinese CR3_NS2_rep_b29d6d90:

    # Caroline "Ugh, dammit..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:74
translate chinese CR3_NS2_rep_4947ee58:

    # Caroline "(Why does my brother keep popping into my fantasies?! I have to change the character again. Okay, it’s Joey from college. Focus on Joey.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:76
translate chinese CR3_NS2_rep_f183913d:

    # Caroline "(Why does he keep popping into my fantasies?! I have to change the character again. Okay, it’s Joey from college. Focus on Joey.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:77
translate chinese CR3_NS2_rep_3853869e:

    # Caroline "(Dammit, I need to turn up the speed too.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:81
translate chinese CR3_NS2_rep_cfb94cc1:

    # "*BUZZ BUZZ BUZZ*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:83
translate chinese CR3_NS2_rep_d91a6261:

    # Caroline "Ohhhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:84
translate chinese CR3_NS2_rep_9f6cd423:

    # Caroline "(Joey keeps stealing glances at my naked body, and I can’t help but notice his cock getting harder. God... it’s so fucking long.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:85
translate chinese CR3_NS2_rep_20c5cad2:

    # Caroline "(He tells me, we need to conserve our heat, and that we should spoon to keep warm. I’m too naive to resist him, and scurry over into his arms.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:90
translate chinese CR3_NS2_rep_ee70ad83:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:92
translate chinese CR3_NS2_rep_bcc78d31:

    # Caroline "(The next thing I know, he has his arms wrapped around my body. His hands are groping my breasts, teasing my nipples, Fuck... His cock is pressing up against my vulva...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:93
translate chinese CR3_NS2_rep_b256155c:

    # Caroline "Oh God... Yes..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:97
translate chinese CR3_NS2_rep_a103f2cd:

    # Caroline "(I try to object, but he’s far too quick. [player_name]’s dick starts to slip inside me. Inch by inch, my brother penetrates me, forcing his thick meat, deep into my soaking wet pussy.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:99
translate chinese CR3_NS2_rep_2340ecb4:

    # Caroline "(I try to object, but he’s far too quick. [player_name]’s dick starts to slip inside me. Inch by inch, my best friend penetrates me, forcing his thick meat, deep into my soaking wet pussy.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:100
translate chinese CR3_NS2_rep_fe27090c:

    # Caroline "Ah! Ah! C-C-Cummmmiinng! Ahhhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:104
translate chinese CR3_NS2_rep_cbcbe64f_2:

    # "*Buzz Buzz*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:106
translate chinese CR3_NS2_rep_7ed91ba6:

    # Caroline "(He begins to fuck me faster and faster. His cock, thrusting in and out of my - tight little hole.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:108
translate chinese CR3_NS2_rep_bbcc0233:

    # Caroline "(Oh God... And then he cums so hard. My brother thrusts his hips, in deep, filling me up with his thick, potent, hot cum! I feel it spray into my pussy, filling me up!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:110
translate chinese CR3_NS2_rep_74a6ca34:

    # Caroline "(Oh God... and then he cums so hard. [player_name] thrusts his hips in deep, filling me up with his thick, potent, hot cum! I feel it spray into my pussy, filling me up!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:111
translate chinese CR3_NS2_rep_d81cc489:

    # Caroline "AHHHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:115
translate chinese CR3_NS2_rep_5724a059:

    # Caroline "Dammit..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:117
translate chinese CR3_NS2_rep_76a25c6d:

    # Caroline "(Why the HELL did I start thinking about my brother AGAIN?! It’s SUPPOSED to be Joey!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:119
translate chinese CR3_NS2_rep_4a07aa33:

    # Caroline "(Why the HELL did I start thinking about HIM AGAIN?! It’s SUPPOSED to be Joey!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:120
translate chinese CR3_NS2_rep_c784b923:

    # Caroline "(Okay, let’s change everything. New position, new people, new fantasy. I can do this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:124
translate chinese CR3_NS2_rep_9e8cfa09:

    # Caroline "(I’m lying down on a beautiful sunny beach, The waves are lapping against the golden sand as I close my eyes, There’s nobody else - as far as the eye can see, so I’m wearing the skimpiest bikini I own.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:126
translate chinese CR3_NS2_rep_b8a7b676:

    # Caroline "(Suddenly, I hear footsteps behind me... It’s Simon, an athletic, six foot tall blond guy, who looks NOTHING like my brother.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:128
translate chinese CR3_NS2_rep_52fe27b3:

    # Caroline "(Suddenly, I hear footsteps behind me... it’s Simon, an athletic six foot tall blond guy who looks NOTHING like my best friend.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:129
translate chinese CR3_NS2_rep_a99ed675:

    # Caroline "(He pounces on me without even asking, locking his lips with my own and kissing me so passionately.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:134
translate chinese CR3_NS2_rep_cbcbe64f_3:

    # "*Buzz Buzz*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:136
translate chinese CR3_NS2_rep_60827ef3:

    # MC "(Wow! What a show!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:137
translate chinese CR3_NS2_rep_aeaaf2bf:

    # Caroline "(Simon slips his fingers under my - tiny bikini top. I feel his warm fingertips pinch and tease - my sensitive nipples - and I can’t bring myself to resist him.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:138
translate chinese CR3_NS2_rep_fbf9a561:

    # Caroline "(His other hand slips down, across my belly and towards my bikini bottoms...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:142
translate chinese CR3_NS2_rep_99be15b9:

    # Caroline "Ohh... Fuck... Yes..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:143
translate chinese CR3_NS2_rep_21683907:

    # Caroline "(Suddenly, his fingers are inside me, pushing, deep into my pussy, and reaching for my g-spot. I buck them up and down, relishing - every last second.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:144
translate chinese CR3_NS2_rep_8cec9e6b:

    # Caroline "(Before I realise it - [player_name] has removed his fingers, and has taken his cock out. He is pressing it, up against my bikini bottoms, poking into my pussy, through them.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:148
translate chinese CR3_NS2_rep_0d4b0af8:

    # Caroline "Oh, my God... Ohh... Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:150
translate chinese CR3_NS2_rep_8a892ac9:

    # Caroline "(My brother is pushing his cock, deeper into my panties. The fabric is pushing itself, into my pussy. If he doesn’t stop, they’ll tear, and his cock will thrust - so fucking deep inside me.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:151
translate chinese CR3_NS2_rep_5f0704d5:

    # Caroline "(Dammit! I’m back to thinking about my brother again! But I’m soooo fucking close to cumming...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:153
translate chinese CR3_NS2_rep_d93b8491:

    # Caroline "([player_name] is pushing his cock deeper into my panties. The fabric is pushing itself into my pussy. If he doesn’t stop, they’ll tear, and his cock will thrust so fucking deep inside me.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:154
translate chinese CR3_NS2_rep_144cb4a3:

    # Caroline "(Dammit! I’m back to thinking about HIM again! But I’m soooo fucking close to cumming...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:160
translate chinese CR3_NS2_rep_0c0a8f1d:

    # Caroline "(Ugh! Fine! I’ll think about [player_name] - one last time. But I really need to control my fantasies, from now on!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:161
translate chinese CR3_NS2_rep_814af415:

    # Caroline "Ah! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:164
translate chinese CR3_NS2_rep_ee70ad83_1:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:169
translate chinese CR3_NS2_rep_285666a1:

    # Caroline "(With one final thrust, my brother plunges his cock, hard against my panties. They tear to shreds, as his cock forces its way through them, and into my sensitive hole.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:171
translate chinese CR3_NS2_rep_03b6f864:

    # Caroline "(With one final thrust, my best friend plunges his cock hard against my panties. They tear to shreds, as his cock forces its way through them, and into my sensitive hole.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:173
translate chinese CR3_NS2_rep_adfb4193:

    # Caroline "(I wrap my legs around his waist, and scream in pleasure. The sound of the waves, crash up against the shore, as he pummels my pussy, with his massive erection.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:174
translate chinese CR3_NS2_rep_15a92a50:

    # Caroline "Yes! Yes! *Gasp* Oh! Fuck!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:178
translate chinese CR3_NS2_rep_ee70ad83_2:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:180
translate chinese CR3_NS2_rep_1b4d7211:

    # Caroline "(My whole body begins to twitch and shake, as he stirs up my pussy.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:181
translate chinese CR3_NS2_rep_2ffc0182:

    # Caroline "AHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:185
translate chinese CR3_NS2_rep_7859ef5d:

    # MC "(Holy shit! She is absolutely LOVING this! I don’t think I’ve ever seen Caroline - this horny - before!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:186
translate chinese CR3_NS2_rep_c068850c:

    # Caroline "Ah! MMM! Oh fuck!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:190
translate chinese CR3_NS2_rep_03d3d79a:

    # Caroline "(And then I feel him thrust in - really deep! He grunts loudly, as his balls begin to clench. And then, he shoots his cum, deep inside me. I tremble and shake, under him, powerless to stop him, as he fills me up.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:192
translate chinese CR3_NS2_rep_ee70ad83_3:

    # "*BUZZ BUZZ*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:193
translate chinese CR3_NS2_rep_17baf6ef:

    # Caroline "AAAHHHHHHH!! HNNNGGGGG!! OOHHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:197
translate chinese CR3_NS2_rep_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:198
translate chinese CR3_NS2_rep_a2fdd223:

    # MC "(Wow, she looks exhausted!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:199
translate chinese CR3_NS2_rep_d146db5c:

    # MC "(I’d love to know what she was thinking about, while she was - getting herself off.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:203
translate chinese CR3_NS2_rep_c958eee7:

    # Caroline "(Holy fuck... That was intense...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:204
translate chinese CR3_NS2_rep_38f93f03:

    # Caroline "(Okay, I better put my dildo away, before I accidentally fall asleep - with it lying out.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:206
translate chinese CR3_NS2_rep_32bc12b0:

    # Caroline "(I don’t want Mom or Dad walking in on me, in the morning - like this.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:208
translate chinese CR3_NS2_rep_bbe9d55d:

    # Caroline "(I don’t want anyone walking in on me in the morning like this.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:212
translate chinese CR3_NS2_rep_5db0876b:

    # Caroline "(Okay, let’s hide it under here again. That’ll keep it safe.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:213
translate chinese CR3_NS2_rep_6e1a2632:

    # Caroline "(Right, I better get back to bed now. I’m up early again, tomorrow morning.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:217
translate chinese CR3_NS2_rep_1d3c02c6:

    # MC "(Huh, so she hides her dildo under her bed. That’s good to know!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:219
translate chinese CR3_NS2_rep_b48cfb6c:

    # MC "(I suppose it keeps it safe, when Mom cleans the room, or Sara goes looking for makeup to nick off her older sister.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_NS2_rep.rpy:221
translate chinese CR3_NS2_rep_0701c5be:

    # MC "(I suppose it keeps it safe when Linda cleans the room, or Sara goes hunting for makeup to “borrow”!)"
    MC ""

