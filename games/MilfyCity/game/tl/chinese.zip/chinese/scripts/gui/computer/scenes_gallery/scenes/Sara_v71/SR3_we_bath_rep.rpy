﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:13
translate chinese SR3_we_bath_rep_91368a27:

    # MC "(The mall’s grand opening is going to attract a big crowd. There’s definitely going to be a few people from our college there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:14
translate chinese SR3_we_bath_rep_d352e2a4:

    # MC "(I wonder how they’ll react to seeing Sara and me on a date?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:16
translate chinese SR3_we_bath_rep_4b2b63e0:

    # MC "(At the end of the day, the thing that matters the most is that she is happy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:17
translate chinese SR3_we_bath_rep_67b9e0b4:

    # MC "(God, she was so nervous when she was trying to ask me out. I’ll do my best to make today as special as I can for her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:18
translate chinese SR3_we_bath_rep_69bcab67:

    # MC "(Okay, time to run myself a bath and get washed.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:20
translate chinese SR3_we_bath_rep_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:21
translate chinese SR3_we_bath_rep_361d8973:

    # MC "(There’s no better way to wake up on the weekend, than a relaxing hot bath.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:23
translate chinese SR3_we_bath_rep_c5b8c611:

    # Sara "(Oh wow! I’ve been grounded for so long, I forgot how hot [player_name] looks when he’s naked.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:24
translate chinese SR3_we_bath_rep_e48b7e87:

    # Sara "(When was the last time I saw him like this? It must have been when we were both up on the roof trying anal.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:26
translate chinese SR3_we_bath_rep_33b0aca0:

    # Sara "(God... His cock is massive.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:27
translate chinese SR3_we_bath_rep_073805ea:

    # Sara "(I still can’t believe he agreed to go on a date with me. I really want to do something for him, to show how grateful I am.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:30
translate chinese SR3_we_bath_rep_9f952e04:

    # Sara "Hey, mind if I join you?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:31
translate chinese SR3_we_bath_rep_6a128959:

    # MC "Oh, hey Sara. Sure, c’mon in!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:34
translate chinese SR3_we_bath_rep_3439b248:

    # MC "Just be careful. [Mom_name] or [Dad_name] didn’t see you come in here, did they?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:36
translate chinese SR3_we_bath_rep_69c0310a:

    # MC "No one's at home? Can we be loud?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:37
translate chinese SR3_we_bath_rep_1200f56d:

    # Sara "Relax, [Mom_name] just went out to the shops, and [Dad_name] probably went to the office for overtime."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:39
translate chinese SR3_we_bath_rep_f4d7e3a8:

    # MC "*Phew* That’s a relief. I’m a little too old now to plausibly be sharing a bath with you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:41
translate chinese SR3_we_bath_rep_d9150041:

    # MC "*Phew* That’s a relief."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:43
translate chinese SR3_we_bath_rep_2f3e44f7:

    # Sara "Hehe! Stop worrying, we’ll be fine. The only other person in the home is Caroline, and I think she’s just moping around in her room right now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:44
translate chinese SR3_we_bath_rep_55db7ccf:

    # MC "Okay, that’s good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:45
translate chinese SR3_we_bath_rep_360809c8:

    # MC "(Sara looks so fucking sexy, wearing nothing but those tight little denim shorts.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:47
translate chinese SR3_we_bath_rep_c449d7f8:

    # MC "Y’know, if you’re planning on joining me in here, you’re gonna have to lose those shorts."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:48
translate chinese SR3_we_bath_rep_abb9a0e1:

    # Sara "Oh, you mean these?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:50
translate chinese SR3_we_bath_rep_31d4926a:

    # Sara "Enjoying the view, [player_name]?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:51
translate chinese SR3_we_bath_rep_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:53
translate chinese SR3_we_bath_rep_07e47dd9:

    # MC "(Damn, her teenage ass is stunning!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:55
translate chinese SR3_we_bath_rep_001248e3:

    # MC "(Damn, her tight ass is stunning!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:57
translate chinese SR3_we_bath_rep_d19cd756:

    # Sara "I’ll join you in a second, [player_name]. I just have to grab my shampoo and a spare towel."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:58
translate chinese SR3_we_bath_rep_b8b14f5a:

    # MC "Uh huh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:60
translate chinese SR3_we_bath_rep_5eb044d6:

    # MC "(I can’t just wait in the bath! That ass is just begging to be pounded right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:61
translate chinese SR3_we_bath_rep_ca68bf8c:

    # MC "(God, I’d love to just bend her over the sink, bury my shaft in her pussy and fuck her until her tight little hole cums around my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:62
translate chinese SR3_we_bath_rep_8c483c03:

    # Sara "Did you see where I left my-"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:64
translate chinese SR3_we_bath_rep_efe8aed1:

    # Sara "Mmpff!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:65
translate chinese SR3_we_bath_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:67
translate chinese SR3_we_bath_rep_9b96cfe0:

    # Sara "W-What happened to us bathing together? Hehe."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:68
translate chinese SR3_we_bath_rep_8d46c167:

    # MC "You were tempting me. I couldn’t resist."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:69
translate chinese SR3_we_bath_rep_6839f872:

    # Sara "So you thought you’d just surprise me with a passionate kiss?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:70
translate chinese SR3_we_bath_rep_f2dbdc9a:

    # MC "Did it work?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:72
translate chinese SR3_we_bath_rep_76be4c21:

    # Sara "Yeah... I liked it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:74
translate chinese SR3_we_bath_rep_d4f7fcbc:

    # MC "I missed you when you were grounded, you know that, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:76
translate chinese SR3_we_bath_rep_884382f4:

    # MC "I missed you when you were at room reading books all day, you know that, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:77
translate chinese SR3_we_bath_rep_37fe985f:

    # Sara "I missed seeing you too, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:79
translate chinese SR3_we_bath_rep_27b4aec6:

    # Sara "Oh wow, I can feel your big guy between my thighs. You REALLY did miss me, huh?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:80
translate chinese SR3_we_bath_rep_2910d3e5:

    # MC "Hmm? Oh, he isn’t even that big yet. Give him a moment."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:82
translate chinese SR3_we_bath_rep_1aa768d3:

    # Sara "Oh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:83
translate chinese SR3_we_bath_rep_e9a6d98d:

    # MC "Haha! See what I mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:84
translate chinese SR3_we_bath_rep_f391bdf1:

    # Sara "Y-Yeah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:85
translate chinese SR3_we_bath_rep_7c68ae52:

    # MC "Do you fancy doing something naughty together before our date?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:87
translate chinese SR3_we_bath_rep_a8457368:

    # MC "How does it feel when I slide my dick back and forth across your pussy like that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:88
translate chinese SR3_we_bath_rep_093e89f6:

    # Sara "Ah... It’s... It’s really nice..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:89
translate chinese SR3_we_bath_rep_15973e11:

    # MC "I could just slip it inside right now. How about even just the tip?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:91
translate chinese SR3_we_bath_rep_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:92
translate chinese SR3_we_bath_rep_1523d466:

    # MC "C’mon, you know you want it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:93
translate chinese SR3_we_bath_rep_7889b06a:

    # Sara "I do... but..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:94
translate chinese SR3_we_bath_rep_5d0a696a:

    # Sara "(I can feel his cock brushing up against my vulva... If he really wanted to, he could plunge it into my pussy and pop my cherry right now.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:95
translate chinese SR3_we_bath_rep_98ac3c45:

    # Sara "(I’m not ready for that yet. I don’t want my first time to be a quickie in a bathroom.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:97
translate chinese SR3_we_bath_rep_a7f09b1f:

    # Sara "W-Wait, I’m not ready for sex. I don’t want my first time to be in the bathroom."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:98
translate chinese SR3_we_bath_rep_57cd70fe:

    # MC "Heh, I understand that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:103
translate chinese SR3_we_bath_rep_def0a97b:

    # MC "How about you get down on your knees and suck my cock instead?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:105
translate chinese SR3_we_bath_rep_29292df8:

    # Sara "Yeah! I can do that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:106
translate chinese SR3_we_bath_rep_a10b7f35:

    # Sara "(That’s a relief. I was worried he was going to want sex really badly right now.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:107
translate chinese SR3_we_bath_rep_55171825:

    # MC "You look so sexy, Sara. God, your freckles are just adorable."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:108
translate chinese SR3_we_bath_rep_835ebd28:

    # Sara "Hehe, thanks."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:110
translate chinese SR3_we_bath_rep_ff1b9a4a_1:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:111
translate chinese SR3_we_bath_rep_a123aa35:

    # MC "You okay there?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:112
translate chinese SR3_we_bath_rep_ad23083a:

    # Sara "I... uh... kinda forgot how big your guy was up close."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:113
translate chinese SR3_we_bath_rep_8d7f4393:

    # MC "Haha, don’t worry. We can do this another time if you want."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:115
translate chinese SR3_we_bath_rep_d3437b0f:

    # Sara "No way! Do you not think I’m up to the challenge?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:116
translate chinese SR3_we_bath_rep_6e3035ee:

    # MC "Mmm... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:117
translate chinese SR3_we_bath_rep_0d84dc08:

    # MC "(Her palm feels so warm wrapped around my shaft.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:118
translate chinese SR3_we_bath_rep_3eb577c0:

    # MC "Go ahead, but don’t push yourself if you don’t want to."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:120
translate chinese SR3_we_bath_rep_2307048b:

    # Sara "I’ve been practicing, you know?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:121
translate chinese SR3_we_bath_rep_f5f9d61d:

    # MC "Practicing giving head?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:122
translate chinese SR3_we_bath_rep_15562df7:

    # Sara "I’d been asking [Mom_name] for cucumbers and bananas to eat while I studied. Remember when I first started giving you blowjobs I could barely fit an inch in my mouth?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:124
translate chinese SR3_we_bath_rep_6dc2d41b:

    # MC "Yeah, I remember. It was adorable though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:126
translate chinese SR3_we_bath_rep_8f963817:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe! The best part was, [Mom_name] never suspected a thing."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:128
translate chinese SR3_we_bath_rep_a3e27abe:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:129
translate chinese SR3_we_bath_rep_664028f3:

    # MC "Okay then, Sara. Let’s see what you’ve got."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:131
translate chinese SR3_we_bath_rep_995d9e27:

    # Sara "(Okay Sara, deep breaths... You can do this. It’s just like a banana...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:132
translate chinese SR3_we_bath_rep_1b0c0dea:

    # Sara "(You’ve practiced for this. You've read porn magazines and watched a lot of porn videos!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:133
translate chinese SR3_we_bath_rep_bdd8cf62:

    # MC "Mmm... God that’s good... Keep stroking my cock like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:135
translate chinese SR3_we_bath_rep_1d81783e:

    # Sara "Are you enjoying this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:137
translate chinese SR3_we_bath_rep_b1e68492:

    # MC "Mmm... Oh yeah, it’s so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:138
translate chinese SR3_we_bath_rep_73b9b423:

    # Sara "Well, it’s about to get a whole lot better."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:140
translate chinese SR3_we_bath_rep_acbf6f41:

    # Sara "You’re so big and hard, [player_name]. I can feel it pulsing against my fingers."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:142
translate chinese SR3_we_bath_rep_e3ade2cb:

    # MC "That just means I’m super excited."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:144
translate chinese SR3_we_bath_rep_09d8181c:

    # MC "Alright, let’s see what you’ve taught yourself."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:145
translate chinese SR3_we_bath_rep_64d8a6c2:

    # Sara "I’m about to blow your mind, [player_name]. Just close your eyes, relax, and enjoy the sensation of my mouth wrapped around your cock."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:147
translate chinese SR3_we_bath_rep_676817a4:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:149
translate chinese SR3_we_bath_rep_5800eb5b:

    # MC "Ohhh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:150
translate chinese SR3_we_bath_rep_a9389210:

    # Sara "Haha! I’m glad you like it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:152
translate chinese SR3_we_bath_rep_0111514d:

    # Sara "(Remember what you read on Judy’s Blog: the glans is the most sensitive part of the guy’s cock. If I focus my efforts on the tip of his dick, I’ll make him cum so much harder!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:153
translate chinese SR3_we_bath_rep_9c363fd7:

    # Sara "*Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:154
translate chinese SR3_we_bath_rep_327a84b0:

    # MC "Ahh... just like that... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:156
translate chinese SR3_we_bath_rep_40486528:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:157
translate chinese SR3_we_bath_rep_4e6b387c:

    # MC "Mmm! Ugh... I missed your little mouth so fucking much, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:158
translate chinese SR3_we_bath_rep_5ba0a8c7:

    # MC "(Her tongue is so wet and warm against my cock. Sara’s blowjobs are fuckin' incredible.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:160
translate chinese SR3_we_bath_rep_4a4fc314:

    # Sara "*Mwah* *Lick*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:161
translate chinese SR3_we_bath_rep_d17a2701:

    # MC "Hnnng... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:162
translate chinese SR3_we_bath_rep_315fcdd8:

    # MC "(She’s so cute, down there on her knees sucking my dick.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:164
translate chinese SR3_we_bath_rep_6e3198d2:

    # Sara "(What was the next piece of advice that blog gave... Oh yeah! Move your head back and forth, allowing your lips to glide over the head of the penis.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:166
translate chinese SR3_we_bath_rep_fb284e00:

    # Sara "*Shlurp* *Suck* *Shluuuurrrp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:168
translate chinese SR3_we_bath_rep_63b87947:

    # MC "Ahhh... You definitely ARE getting better. Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:170
translate chinese SR3_we_bath_rep_30554186:

    # MC "(Sara’s breasts were never the biggest, but they look so perky and perfect. Her skin looks phenomenal when the sunlight caresses it like that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:171
translate chinese SR3_we_bath_rep_9c363fd7_1:

    # Sara "*Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:172
translate chinese SR3_we_bath_rep_ab7362ea:

    # MC "God, you’re fucking amazing, Sara... Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:174
translate chinese SR3_we_bath_rep_259cb936:

    # MC "Mmm, please don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:176
translate chinese SR3_we_bath_rep_40486528_1:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:177
translate chinese SR3_we_bath_rep_090c1266:

    # Sara "(His dick is starting to throb in my mouth. He must be REALLY enjoying this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:179
translate chinese SR3_we_bath_rep_79a290ea:

    # MC "This is brilliant, Sara, but do you think you can try going a bit deeper?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:181
translate chinese SR3_we_bath_rep_00db2170:

    # Sara "Mmm hmm! *Shlurp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:183
translate chinese SR3_we_bath_rep_77ffa74b:

    # Sara "*Glompfff*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:184
translate chinese SR3_we_bath_rep_cf38225b:

    # MC "Mmm... That’s right. Just like that, Sara. Ugh! Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:185
translate chinese SR3_we_bath_rep_e4bf86f3:

    # Sara "(What did Judy write next? Create a vacuum by sucking your cheeks in? I think that was it.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:187
translate chinese SR3_we_bath_rep_196e8da8:

    # Sara "*Suuuuuccck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:188
translate chinese SR3_we_bath_rep_8b2f405a:

    # MC "Oooohhh fuuucck... Oh Sara, that’s so fucking good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:189
translate chinese SR3_we_bath_rep_3e93c595:

    # MC "(I’m lucky [Mom_name] and [Dad_name] aren’t home. There’s no way I’ll be able to keep my voice down for the whole blowjob!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:191
translate chinese SR3_we_bath_rep_f59a84ed:

    # Sara "*Suck* *Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:192
translate chinese SR3_we_bath_rep_0808dcbb:

    # MC "Oh! Oh fuck! Arrrghhh! Ugh! Yes! Yes Sara, don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:193
translate chinese SR3_we_bath_rep_957abfd8:

    # Sara "*Shlurp* *Slluurrrp* *SUCK*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:195
translate chinese SR3_we_bath_rep_216e4bf0:

    # MC "I... *Hnnnhhh* I... I’m gonna..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:197
translate chinese SR3_we_bath_rep_cf07efe5:

    # Sara "(What was I supposed to do after sucking my cheeks in? I can’t remember now. I think I’m supposed to start ‘deepthroating’ now, aren’t I?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:199
translate chinese SR3_we_bath_rep_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:201
translate chinese SR3_we_bath_rep_7f790225:

    # Sara "(Yeah, I’ll try taking his dick deeper into my mouth. I mean, he seems to be enjoying whatever I’m doing right now!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:202
translate chinese SR3_we_bath_rep_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:203
translate chinese SR3_we_bath_rep_b38e805b:

    # MC "Fuuuck! Hnnnnggg!! Ugghhh! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:205
translate chinese SR3_we_bath_rep_c50ac75f:

    # Sara "Hmm?!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:213
translate chinese SR3_we_bath_rep_ff51b3ec:

    # Sara "Mmpplllfff! *Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:214
translate chinese SR3_we_bath_rep_c33108ff:

    # MC "Ughhhh! Ohhh God, that’s amazing..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:215
translate chinese SR3_we_bath_rep_834c250f:

    # Sara "(H-Holy shit! I was NOT expecting him to cum yet! I got WAY too distracted thinking about what to do next!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:217
translate chinese SR3_we_bath_rep_6d184773:

    # Sara "(I think I accidentally swallowed the first bit of cum he shot in my mouth, but there’s more and more coming!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:218
translate chinese SR3_we_bath_rep_a8eb67c1:

    # Sara "(Oh shit, there’s waaaayyy too much!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:219
translate chinese SR3_we_bath_rep_3cd76510:

    # MC "Ohh... Fuck... That was amazing, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:221
translate chinese SR3_we_bath_rep_af10e58b:

    # MC "Jesus, you look so fucking hot right now. Do you think you can do me a favour, Sara? Can you swallow it for me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:222
translate chinese SR3_we_bath_rep_301b6e6e:

    # Sara "Mmm hmm."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:223
translate chinese SR3_we_bath_rep_18bd41c0:

    # Sara "*Gulp* *Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:224
translate chinese SR3_we_bath_rep_d2006bfe:

    # MC "Open wide, let me see."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:226
translate chinese SR3_we_bath_rep_e18805dc:

    # Sara "Ahh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:227
translate chinese SR3_we_bath_rep_e1b2b7a0:

    # MC "Fuck, you’re amazing. Thanks for letting me cum inside. It was amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:229
translate chinese SR3_we_bath_rep_2c6079e3:

    # Sara "*Cough* N-No problem. Sorry I never got the chance to go deeper. I was about to try taking you down my throat, and then you suddenly came."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:230
translate chinese SR3_we_bath_rep_d83a6f94:

    # MC "Haha, don’t worry about it. Your mouth felt fucking amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:233
translate chinese SR3_we_bath_rep_55fd1381:

    # Sara "Thanks. Now, I seriously need to have a bath too. I’m all sweaty after that!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:235
translate chinese SR3_we_bath_rep_63d42553:

    # Sara "I’ll get washed and dressed here. Head on over to the new shopping mall. I’ll meet you there when I’m ready."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:236
translate chinese SR3_we_bath_rep_6e10d321:

    # MC "Sounds good to me! Where exactly do you want to meet?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:237
translate chinese SR3_we_bath_rep_107c5be9:

    # Sara "Just in the main foyer will be fine."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:238
translate chinese SR3_we_bath_rep_82a1676a:

    # MC "Great. I’ll see you there, Sara. I’m really looking forward to our date."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:239
translate chinese SR3_we_bath_rep_b6afb773:

    # Sara "Me too. I’m so excited!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:240
translate chinese SR3_we_bath_rep_36bae83a:

    # Sara "Apologies for not going deeper. We will try again in the future."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:247
translate chinese SR3_we_bath_rep_91368a27_1:

    # MC "(The mall’s grand opening is going to attract a big crowd. There’s definitely going to be a few people from our college there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:248
translate chinese SR3_we_bath_rep_05f56a48:

    # MC "(It’s a good thing I told her to keep the date on the down low. It’s not worth risking the attention we could generate as a couple. Some other girl I’m dating could see us!) "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:250
translate chinese SR3_we_bath_rep_e95e95be:

    # MC "(At the end of the day, the thing that matters the most is that we’re both safe.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:251
translate chinese SR3_we_bath_rep_5e37870f:

    # MC "(God, she was so nervous when she was trying to ask me out. It might not be a formal date, but I’ll do my best to make today as special as I can for her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:252
translate chinese SR3_we_bath_rep_69bcab67_1:

    # MC "(Okay, time to run myself a bath and get washed.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:254
translate chinese SR3_we_bath_rep_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:255
translate chinese SR3_we_bath_rep_361d8973_1:

    # MC "(There’s no better way to wake up on the weekend, than a relaxing hot bath.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:257
translate chinese SR3_we_bath_rep_8ec422c9:

    # Sara "(I still can’t believe he didn’t want to be seen dating me in public...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:258
translate chinese SR3_we_bath_rep_5367f059:

    # Sara "(Is there someone else he has his eyes on? Or am I just being paranoid? Maybe I’m just not good enough for him?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:260
translate chinese SR3_we_bath_rep_1649c203:

    # Sara "(What do I have to do to make him proud enough for him to call me his girlfriend in front of other people?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:261
translate chinese SR3_we_bath_rep_10480b82:

    # Sara "(Maybe I should be more sexual? I’ve given him a couple of blowjobs and some anal - but maybe it isn’t enough for a horny guy like him.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:266
translate chinese SR3_we_bath_rep_9f952e04_1:

    # Sara "Hey, mind if I join you?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:267
translate chinese SR3_we_bath_rep_6a128959_1:

    # MC "Oh, hey Sara. Sure, c’mon in!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:270
translate chinese SR3_we_bath_rep_3439b248_1:

    # MC "Just be careful. [Mom_name] or [Dad_name] didn’t see you come in here, did they?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:272
translate chinese SR3_we_bath_rep_69c0310a_1:

    # MC "No one's at home? Can we be loud?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:273
translate chinese SR3_we_bath_rep_1200f56d_1:

    # Sara "Relax, [Mom_name] just went out to the shops, and [Dad_name] probably went to the office for overtime."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:275
translate chinese SR3_we_bath_rep_f4d7e3a8_1:

    # MC "*Phew* That’s a relief. I’m a little too old now to plausibly be sharing a bath with you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:277
translate chinese SR3_we_bath_rep_0960be1f:

    # MC "*Phew* That’s a relief. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:279
translate chinese SR3_we_bath_rep_2f3e44f7_1:

    # Sara "Hehe! Stop worrying, we’ll be fine. The only other person in the home is Caroline, and I think she’s just moping around in her room right now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:280
translate chinese SR3_we_bath_rep_55db7ccf_1:

    # MC "Okay, that’s good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:281
translate chinese SR3_we_bath_rep_360809c8_1:

    # MC "(Sara looks so fucking sexy, wearing nothing but those tight little denim shorts.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:283
translate chinese SR3_we_bath_rep_c449d7f8_1:

    # MC "Y’know, if you’re planning on joining me in here, you’re gonna have to lose those shorts."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:284
translate chinese SR3_we_bath_rep_abb9a0e1_1:

    # Sara "Oh, you mean these?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:286
translate chinese SR3_we_bath_rep_ef8a3e29:

    # Sara "Enjoying the view?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:287
translate chinese SR3_we_bath_rep_b39ef889_1:

    # MC "*Whistle*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:289
translate chinese SR3_we_bath_rep_07e47dd9_1:

    # MC "(Damn, her teenage ass is stunning!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:291
translate chinese SR3_we_bath_rep_d1a3895e:

    # MC "(Damn, her ass is stunning!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:293
translate chinese SR3_we_bath_rep_d19cd756_1:

    # Sara "I’ll join you in a second, [player_name]. I just have to grab my shampoo and a spare towel."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:294
translate chinese SR3_we_bath_rep_b8b14f5a_1:

    # MC "Uh huh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:296
translate chinese SR3_we_bath_rep_5eb044d6_1:

    # MC "(I can’t just wait in the bath! That ass is just begging to be pounded right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:297
translate chinese SR3_we_bath_rep_ca68bf8c_1:

    # MC "(God, I’d love to just bend her over the sink, bury my shaft in her pussy and fuck her until her tight little hole cums around my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:298
translate chinese SR3_we_bath_rep_8c483c03_1:

    # Sara "Did you see where I left my-"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:300
translate chinese SR3_we_bath_rep_efe8aed1_1:

    # Sara "Mmpff!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:301
translate chinese SR3_we_bath_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:303
translate chinese SR3_we_bath_rep_9b96cfe0_1:

    # Sara "W-What happened to us bathing together? Hehe."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:304
translate chinese SR3_we_bath_rep_8d46c167_1:

    # MC "You were tempting me. I couldn’t resist."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:305
translate chinese SR3_we_bath_rep_6839f872_1:

    # Sara "So you thought you’d just surprise me with a passionate kiss?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:306
translate chinese SR3_we_bath_rep_f2dbdc9a_1:

    # MC "Did it work?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:308
translate chinese SR3_we_bath_rep_76be4c21_1:

    # Sara "Yeah... I liked it."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:310
translate chinese SR3_we_bath_rep_d4f7fcbc_1:

    # MC "I missed you when you were grounded, you know that, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:312
translate chinese SR3_we_bath_rep_884382f4_1:

    # MC "I missed you when you were at room reading books all day, you know that, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:313
translate chinese SR3_we_bath_rep_37fe985f_1:

    # Sara "I missed seeing you too, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:315
translate chinese SR3_we_bath_rep_27b4aec6_1:

    # Sara "Oh wow, I can feel your big guy between my thighs. You REALLY did miss me, huh?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:316
translate chinese SR3_we_bath_rep_2910d3e5_1:

    # MC "Hmm? Oh, he isn’t even that big yet. Give him a moment."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:318
translate chinese SR3_we_bath_rep_1aa768d3_1:

    # Sara "Oh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:319
translate chinese SR3_we_bath_rep_e9a6d98d_1:

    # MC "Haha! See what I mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:320
translate chinese SR3_we_bath_rep_f391bdf1_1:

    # Sara "Y-Yeah!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:321
translate chinese SR3_we_bath_rep_7c68ae52_1:

    # MC "Do you fancy doing something naughty together before our date?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:323
translate chinese SR3_we_bath_rep_a8457368_1:

    # MC "How does it feel when I slide my dick back and forth across your pussy like that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:324
translate chinese SR3_we_bath_rep_093e89f6_1:

    # Sara "Ah... It’s... It’s really nice..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:325
translate chinese SR3_we_bath_rep_15973e11_1:

    # MC "I could just slip it inside right now. How about even just the tip?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:327
translate chinese SR3_we_bath_rep_ff1b9a4a_2:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:328
translate chinese SR3_we_bath_rep_1523d466_1:

    # MC "C’mon, you know you want it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:329
translate chinese SR3_we_bath_rep_7889b06a_1:

    # Sara "I do... but..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:330
translate chinese SR3_we_bath_rep_5d0a696a_1:

    # Sara "(I can feel his cock brushing up against my vulva... If he really wanted to, he could plunge it into my pussy and pop my cherry right now.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:331
translate chinese SR3_we_bath_rep_98ac3c45_1:

    # Sara "(I’m not ready for that yet. I don’t want my first time to be a quickie in a bathroom.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:333
translate chinese SR3_we_bath_rep_a7f09b1f_1:

    # Sara "W-Wait, I’m not ready for sex. I don’t want my first time to be in the bathroom."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:334
translate chinese SR3_we_bath_rep_57cd70fe_1:

    # MC "Heh, I understand that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:339
translate chinese SR3_we_bath_rep_def0a97b_1:

    # MC "How about you get down on your knees and suck my cock instead?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:341
translate chinese SR3_we_bath_rep_29292df8_1:

    # Sara "Yeah! I can do that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:342
translate chinese SR3_we_bath_rep_5039cdf2:

    # Sara "(I think it’s pretty clear he wants to fuck me. Maybe that’s why he’s holding off on making us official? Does he worry that I’m never going to let him do me?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:343
translate chinese SR3_we_bath_rep_55171825_1:

    # MC "You look so sexy, Sara. God, your freckles are just adorable."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:344
translate chinese SR3_we_bath_rep_5f188ab5:

    # Sara "Hehe, thanks.."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:346
translate chinese SR3_we_bath_rep_ff1b9a4a_3:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:347
translate chinese SR3_we_bath_rep_a123aa35_1:

    # MC "You okay there?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:348
translate chinese SR3_we_bath_rep_ad23083a_1:

    # Sara "I... uh... kinda forgot how big your guy was up close."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:349
translate chinese SR3_we_bath_rep_8d7f4393_1:

    # MC "Haha, don’t worry. We can do this another time if you want."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:351
translate chinese SR3_we_bath_rep_d3437b0f_1:

    # Sara "No way! Do you not think I’m up to the challenge?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:352
translate chinese SR3_we_bath_rep_6e3035ee_1:

    # MC "Mmm... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:353
translate chinese SR3_we_bath_rep_0d84dc08_1:

    # MC "(Her palm feels so warm wrapped around my shaft.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:354
translate chinese SR3_we_bath_rep_3eb577c0_1:

    # MC "Go ahead, but don’t push yourself if you don’t want to."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:356
translate chinese SR3_we_bath_rep_2307048b_1:

    # Sara "I’ve been practicing, you know?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:357
translate chinese SR3_we_bath_rep_f5f9d61d_1:

    # MC "Practicing giving head?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:358
translate chinese SR3_we_bath_rep_15562df7_1:

    # Sara "I’d been asking [Mom_name] for cucumbers and bananas to eat while I studied. Remember when I first started giving you blowjobs I could barely fit an inch in my mouth?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:360
translate chinese SR3_we_bath_rep_6dc2d41b_1:

    # MC "Yeah, I remember. It was adorable though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:362
translate chinese SR3_we_bath_rep_8f963817_1:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe! The best part was, [Mom_name] never suspected a thing."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:364
translate chinese SR3_we_bath_rep_a3e27abe_1:

    # Sara "Well, I can do SOOO much more now. At least, on a banana. Hehe!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:365
translate chinese SR3_we_bath_rep_664028f3_1:

    # MC "Okay then, Sara. Let’s see what you’ve got."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:367
translate chinese SR3_we_bath_rep_995d9e27_1:

    # Sara "(Okay Sara, deep breaths... You can do this. It’s just like a banana...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:369
translate chinese SR3_we_bath_rep_1b0c0dea_1:

    # Sara "(You’ve practiced for this. You've read porn magazines and watched a lot of porn videos!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:370
translate chinese SR3_we_bath_rep_bdd8cf62_1:

    # MC "Mmm... God that’s good... Keep stroking my cock like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:372
translate chinese SR3_we_bath_rep_1d81783e_1:

    # Sara "Are you enjoying this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:374
translate chinese SR3_we_bath_rep_b1e68492_1:

    # MC "Mmm... Oh yeah, it’s so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:375
translate chinese SR3_we_bath_rep_73b9b423_1:

    # Sara "Well, it’s about to get a whole lot better."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:377
translate chinese SR3_we_bath_rep_acbf6f41_1:

    # Sara "You’re so big and hard, [player_name]. I can feel it pulsing against my fingers."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:379
translate chinese SR3_we_bath_rep_e3ade2cb_1:

    # MC "That just means I’m super excited."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:381
translate chinese SR3_we_bath_rep_09d8181c_1:

    # MC "Alright, let’s see what you’ve taught yourself."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:382
translate chinese SR3_we_bath_rep_df4e3519:

    # Sara "I’m about to blow your mind. Just close your eyes, relax, and enjoy the sensation of my mouth wrapped around your cock."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:384
translate chinese SR3_we_bath_rep_676817a4_1:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:386
translate chinese SR3_we_bath_rep_5800eb5b_1:

    # MC "Ohhh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:387
translate chinese SR3_we_bath_rep_a9389210_1:

    # Sara "Haha! I’m glad you like it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:389
translate chinese SR3_we_bath_rep_0111514d_1:

    # Sara "(Remember what you read on Judy’s Blog: the glans is the most sensitive part of the guy’s cock. If I focus my efforts on the tip of his dick, I’ll make him cum so much harder!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:390
translate chinese SR3_we_bath_rep_9c363fd7_2:

    # Sara "*Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:391
translate chinese SR3_we_bath_rep_327a84b0_1:

    # MC "Ahh... just like that... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:393
translate chinese SR3_we_bath_rep_40486528_2:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:394
translate chinese SR3_we_bath_rep_4e6b387c_1:

    # MC "Mmm! Ugh... I missed your little mouth so fucking much, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:395
translate chinese SR3_we_bath_rep_5ba0a8c7_1:

    # MC "(Her tongue is so wet and warm against my cock. Sara’s blowjobs are fuckin' incredible.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:397
translate chinese SR3_we_bath_rep_4a4fc314_1:

    # Sara "*Mwah* *Lick*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:398
translate chinese SR3_we_bath_rep_d17a2701_1:

    # MC "Hnnng... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:399
translate chinese SR3_we_bath_rep_315fcdd8_1:

    # MC "(She’s so cute, down there on her knees sucking my dick.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:401
translate chinese SR3_we_bath_rep_6e3198d2_1:

    # Sara "(What was the next piece of advice that blog gave... Oh yeah! Move your head back and forth, allowing your lips to glide over the head of the penis.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:403
translate chinese SR3_we_bath_rep_fb284e00_1:

    # Sara "*Shlurp* *Suck* *Shluuuurrrp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:405
translate chinese SR3_we_bath_rep_63b87947_1:

    # MC "Ahhh... You definitely ARE getting better. Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:407
translate chinese SR3_we_bath_rep_30554186_1:

    # MC "(Sara’s breasts were never the biggest, but they look so perky and perfect. Her skin looks phenomenal when the sunlight caresses it like that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:408
translate chinese SR3_we_bath_rep_9c363fd7_3:

    # Sara "*Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:409
translate chinese SR3_we_bath_rep_ab7362ea_1:

    # MC "God, you’re fucking amazing, Sara... Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:411
translate chinese SR3_we_bath_rep_259cb936_1:

    # MC "Mmm, please don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:413
translate chinese SR3_we_bath_rep_40486528_3:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:414
translate chinese SR3_we_bath_rep_090c1266_1:

    # Sara "(His dick is starting to throb in my mouth. He must be REALLY enjoying this!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:416
translate chinese SR3_we_bath_rep_79a290ea_1:

    # MC "This is brilliant, Sara, but do you think you can try going a bit deeper?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:418
translate chinese SR3_we_bath_rep_00db2170_1:

    # Sara "Mmm hmm! *Shlurp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:420
translate chinese SR3_we_bath_rep_77ffa74b_1:

    # Sara "*Glompfff*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:421
translate chinese SR3_we_bath_rep_cf38225b_1:

    # MC "Mmm... That’s right. Just like that, Sara. Ugh! Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:422
translate chinese SR3_we_bath_rep_e4bf86f3_1:

    # Sara "(What did Judy write next? Create a vacuum by sucking your cheeks in? I think that was it.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:424
translate chinese SR3_we_bath_rep_196e8da8_1:

    # Sara "*Suuuuuccck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:425
translate chinese SR3_we_bath_rep_8b2f405a_1:

    # MC "Oooohhh fuuucck... Oh Sara, that’s so fucking good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:427
translate chinese SR3_we_bath_rep_cb45b6d9:

    # MC "(I’m lucky [Mom_name] and [Dad_name] aren’t home, there’s no way I’ll be able to keep my voice down for the whole blowjob!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:429
translate chinese SR3_we_bath_rep_0c0910c9:

    # MC "(I’m lucky nobody isn’t home! There’s no way I’ll be able to keep my voice down for the whole blowjob!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:431
translate chinese SR3_we_bath_rep_f59a84ed_1:

    # Sara "*Suck* *Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:432
translate chinese SR3_we_bath_rep_0808dcbb_1:

    # MC "Oh! Oh fuck! Arrrghhh! Ugh! Yes! Yes Sara, don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:433
translate chinese SR3_we_bath_rep_957abfd8_1:

    # Sara "*Shlurp* *Slluurrrp* *SUCK*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:435
translate chinese SR3_we_bath_rep_216e4bf0_1:

    # MC "I... *Hnnnhhh* I... I’m gonna..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:437
translate chinese SR3_we_bath_rep_cf07efe5_1:

    # Sara "(What was I supposed to do after sucking my cheeks in? I can’t remember now. I think I’m supposed to start ‘deepthroating’ now, aren’t I?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:439
translate chinese SR3_we_bath_rep_bd1c6d83_2:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:441
translate chinese SR3_we_bath_rep_33044a28:

    # Sara "(Yeah, I’ll try taking his dick deeper into my mouth. I mean, he seems to be enjoying whatever I’m doing right now! I’m gonna do it! I’m gonna prove to him I’m the best girl he could possibly have!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:442
translate chinese SR3_we_bath_rep_bd1c6d83_3:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:443
translate chinese SR3_we_bath_rep_b38e805b_1:

    # MC "Fuuuck! Hnnnnggg!! Ugghhh! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:445
translate chinese SR3_we_bath_rep_c50ac75f_1:

    # Sara "Hmm?!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:453
translate chinese SR3_we_bath_rep_ff51b3ec_1:

    # Sara "Mmpplllfff! *Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:454
translate chinese SR3_we_bath_rep_c33108ff_1:

    # MC "Ughhhh! Ohhh God, that’s amazing..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:455
translate chinese SR3_we_bath_rep_834c250f_1:

    # Sara "(H-Holy shit! I was NOT expecting him to cum yet! I got WAY too distracted thinking about what to do next!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:457
translate chinese SR3_we_bath_rep_6d184773_1:

    # Sara "(I think I accidentally swallowed the first bit of cum he shot in my mouth, but there’s more and more coming!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:458
translate chinese SR3_we_bath_rep_a8eb67c1_1:

    # Sara "(Oh shit, there’s waaaayyy too much!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:459
translate chinese SR3_we_bath_rep_3cd76510_1:

    # MC "Ohh... Fuck... That was amazing, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:461
translate chinese SR3_we_bath_rep_af10e58b_1:

    # MC "Jesus, you look so fucking hot right now. Do you think you can do me a favour, Sara? Can you swallow it for me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:462
translate chinese SR3_we_bath_rep_301b6e6e_1:

    # Sara "Mmm hmm."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:463
translate chinese SR3_we_bath_rep_18bd41c0_1:

    # Sara "*Gulp* *Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:464
translate chinese SR3_we_bath_rep_d2006bfe_1:

    # MC "Open wide, let me see."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:466
translate chinese SR3_we_bath_rep_e18805dc_1:

    # Sara "Ahh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:467
translate chinese SR3_we_bath_rep_e1b2b7a0_1:

    # MC "Fuck, you’re amazing. Thanks for letting me cum inside. It was amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:469
translate chinese SR3_we_bath_rep_2c6079e3_1:

    # Sara "*Cough* N-No problem. Sorry I never got the chance to go deeper. I was about to try taking you down my throat, and then you suddenly came."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:470
translate chinese SR3_we_bath_rep_d83a6f94_1:

    # MC "Haha, don’t worry about it. Your mouth felt fucking amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:475
translate chinese SR3_we_bath_rep_55fd1381_1:

    # Sara "Thanks. Now, I seriously need to have a bath too. I’m all sweaty after that!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:477
translate chinese SR3_we_bath_rep_63d42553_1:

    # Sara "I’ll get washed and dressed here. Head on over to the new shopping mall. I’ll meet you there when I’m ready."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:478
translate chinese SR3_we_bath_rep_6e10d321_1:

    # MC "Sounds good to me! Where exactly do you want to meet?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:479
translate chinese SR3_we_bath_rep_107c5be9_1:

    # Sara "Just in the main foyer will be fine."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:480
translate chinese SR3_we_bath_rep_c622b0d2:

    # MC "Great. I’ll see you there, Sara. I’m really looking forward to our day out."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:481
translate chinese SR3_we_bath_rep_b6afb773_1:

    # Sara "Me too. I’m so excited!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:483
translate chinese SR3_we_bath_rep_d81f8842:

    # MC "Just remember, don’t run up and kiss me or anything. We don’t want to look too romantic when we go out, okay? We’re supposed to be keeping this on the down low. You don’t want your whole class bullying you for dating your brother, do you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:485
translate chinese SR3_we_bath_rep_12a18112:

    # MC "Just remember, don’t run up and kiss me or anything. We don’t want to look too romantic when we go out, okay? We’re supposed to be keeping this on the down low. You don’t want your whole gossiping about your new relationship, do you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_bath_rep.rpy:486
translate chinese SR3_we_bath_rep_6af4b9f5:

    # Sara "*Sigh* Okay, [player_name]."
    Sara ""

