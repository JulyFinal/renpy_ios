﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:9
translate chinese ml_room_fj_v1_5d98fe58:

    # MC "Hey, Mom. I’m here to talk to you about... the thing from yesterday."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:11
translate chinese ml_room_fj_v1_50713cad:

    # MC "Hey, Linda. I'm here to talk to you about... the thing that happened between us the last time..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:12
translate chinese ml_room_fj_v1_5e7a2c2c:

    # Mom "*Gulp* Y-Yes?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:13
translate chinese ml_room_fj_v1_05d58f7e:

    # MC "Is now a good time for you? Or do you want me to come back later?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:14
translate chinese ml_room_fj_v1_ab8e121e:

    # Mom "I... I’m going to work soon, but I have a few minutes."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:20
translate chinese ml_room_fj_v1_ee8efdf8:

    # MC "Mom, I... I love you too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:21
translate chinese ml_room_fj_v1_40cd20d3:

    # MC "And not just in the way a son normally loves his Mom. I mean, I really love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:23
translate chinese ml_room_fj_v1_66b99089:

    # MC "Linda, I... I love you too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:24
translate chinese ml_room_fj_v1_ef97be22:

    # MC "I understand that you're much more experienced than I am, and you have a husband, but I genuinely love you. Since the day I moved here and became your tenant, I've noticed how much you've cared about me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:29
translate chinese ml_room_fj_v1_b5315db6:

    # MC "After, all you said the last time, and the way you've acted around me... I think..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:30
translate chinese ml_room_fj_v1_bf944fd1:

    # MC "I think I want the same thing that you do."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:35
translate chinese ml_room_fj_v1_69c8b3f6:

    # MC "Mom... You really should have told me sooner."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:37
translate chinese ml_room_fj_v1_b6cd3ca5:

    # MC "Linda... You really should have told me sooner."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:38
translate chinese ml_room_fj_v1_bdf782c7:

    # MC "You said that you’ve always felt this way. If I’d known, then I would have been able to understand, why you were acting the way you were."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:39
translate chinese ml_room_fj_v1_76fc7e11:

    # MC "Everything would have made sense."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:45
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_8dc8bc4e:

    # MC "Anyway, I should go now. But... I really do love you, Mom. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:46
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_6a93b26f:

    # MC "And I might be interested in... doing some of the... um.... stuff... that..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:48
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_9b18281b:

    # MC "Anyway, I should go now. Bob could be here any time soon. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:49
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_7fbd81bf:

    # MC "And I might be interested in... doing some stuff... with you... regardless that you have a husband... um..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:50
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_fd215a4e:

    # MC "Sorry, I’m getting all nervous and stumbling over my words. I should just go."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:53
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_dc99bc46:

    # Mom "Don’t go! Please!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:54
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:55
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_be8d4764:

    # Mom "S-Sorry, I didn’t mean to frighten you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:57
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_4201f689:

    # Mom "I was... just, so sure that you were going to tell me, that you only loved me like a mother."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:58
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_f2d1ccb3:

    # Mom "I was scared that I might have pushed you away, with those silly games I made you play."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:60
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_1690e764:

    # Mom "I was... just so certain that you were going to tell me that you only loved me like a very caring landlady. Besides, I'm older than you and I have a husband."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:61
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_a2ec5f9b:

    # Mom "I was afraid of that, and I thought you might also prefer younger women. That's why I wanted to engage in those silly games with you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:62
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_392831e4:

    # Mom "I know everything’s moving quite fast... but if you want, we could be intimate together, in our underwear. How does that sound?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:63
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_aa6573dc:

    # MC "*Gulp* R-Really? Right now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:64
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_49dfee50:

    # Mom "Sit down on the sofa at the end of my bed."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:69
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_a253b8eb:

    # Mom "I want you to see this."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:70
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_fb7b98e2:

    # Mom "I want you to look at my body and enjoy watching it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:72
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_c48a05af:

    # Mom "This is just for you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:74
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_a245ca6d:

    # Mom "This is just for you. Bob shouldn’t come here soon."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:77
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:78
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_886030e9:

    # Mom "(I hope he likes my body... I know I’m not THAT young anymore...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:80
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_3bcccc8b:

    # MC "Wow... You’re stunning, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:82
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_e729dde0:

    # MC "Wow... You’re stunning, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:85
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_d88d9d4b:

    # Mom "You really think so?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:86
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_6c0fe967:

    # MC "Yeah - your body is incredible! And that lingerie you’re wearing, fits you perfectly!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:87
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_f6b7be7a:

    # Mom "I’m glad you like it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:90
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_3def29be:

    # Mom "How about you strip off now too?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:91
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_e841d04b:

    # Mom "I’ve shown you what I’ve got - it’s only fair that you show me yours."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:92
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_ed5b4f21:

    # MC "Okay, hang on..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:95
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_2b2d1b6a:

    # MC "Well? Is it as good as you imagined?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:96
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_0c1b14bb:

    # Mom "Mmm... Almost. The part I spent, most time fantasising about, is still covered up right now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:99
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_b91cebc5:

    # Mom "It’s going to feels so good, to finally kiss you without feeling like a creep."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:100
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_8ef78f54:

    # MC "You did have me wondering what was going on, for a few days there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:101
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_e27a46bd:

    # Mom "Hehe... I’m sorry. I just couldn’t resist you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:104
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:105
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_c977372b:

    # Mom "(How can something so wrong, feel so right?)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:107
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_7210687d:

    # Mom "(It’s like... my dreams are finally beginning to come true.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:108
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_301a9559:

    # Mom "(Whenever I kiss [player_name], there’s butterflies in my tummy... I’ve never felt this way, when I’ve kissed anyone else, in my life.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:111
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_54e1f274:

    # Mom "Lie down on the bed. Just like that."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:112
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_545ec595:

    # Mom "(I can see how hard he already is... but I have to feel it with my own hand.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:115
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_13d4ced8:

    # Mom "Do you mind if I... touch you with my hand?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:116
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_76b251f4:

    # MC "S-Sure... I don’t mind."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:119
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_e00edddb:

    # Mom "(Wow... He’s huge...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:120
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_9cb4c089:

    # Mom "(If only he wasn’t wearing these boxer shorts...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:121
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_24219d84:

    # Mom "(I’d love to take his cock in my mouth right now, and suck on it until he came.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:125
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_f13cb6dc:

    # MC "Ahh... M-Mom..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:127
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_2aec94d1:

    # MC "Ahh... L-Linda..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:128
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_802bcddc:

    # MC "(She’s being so gentle with her tongue...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:131
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_f375d839:

    # MC "Ah! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:132
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_3e8d2ee8:

    # Mom "(It sounds like his nipples are especially sensitive.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:133
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_4985a879:

    # Mom "(He’s clearly enjoying me flicking my tongue over them.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:137
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_dedafdec:

    # MC "(I’m so hard right now... I can’t believe, Mom was this attracted to me for so long.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:139
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_de3b11ea:

    # MC "(I’m so hard right now... I can’t believe, Linda was this attracted to me for so long.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:140
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_5213554d:

    # MC "(I wonder if this was one of the fantasies she had, about me and her?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:144
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_cd78d7a2:

    # MC "Ooh... Oh, Mom!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:146
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_46e0c493:

    # MC "Ooh... Oh, Linda!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:147
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_d624ed52:

    # Mom "Do you like it when I kiss your neck like this?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:148
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_a1206890:

    # MC "Yes..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:151
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_753c01e0:

    # Mom "You can do whatever you want now. I’ve had my fun - it’s time for you to have some too."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:152
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:153
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_22a0cfd0:

    # Mom "I’ll lie back, on the bed. The rest is up to you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:160
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_c8e867dc:

    # MC "You’ve got beautiful feet."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:161
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_d01a4ad5:

    # Mom "Hehe... Thanks. Have you got a bit of a foot fetish, then?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:162
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_87d764a2:

    # MC "W-What?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:165
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_f7a807e6:

    # Mom "Relax - I’m just teasing you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:166
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_fa5cfed3:

    # Mom "Mmm... It’s nice when you massage them like that."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:167
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_2c78f826:

    # MC "You like that? I’ll do the soles too, then."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:170
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_c1c1d3d9:

    # Mom "Ahh... Your father never does ANYTHING like this, for me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:171
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_24719c88:

    # Mom "God... your fingers are amazing."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:177
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_c8e867dc_1:

    # MC "You’ve got beautiful feet."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:178
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_d01a4ad5_1:

    # Mom "Hehe... Thanks. Have you got a bit of a foot fetish, then?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:179
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_87d764a2_1:

    # MC "W-What?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:182
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_f7a807e6_1:

    # Mom "Relax - I’m just teasing you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:183
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_fa5cfed3_1:

    # Mom "Mmm... It’s nice when you massage them like that."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:184
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_2c78f826_1:

    # MC "You like that? I’ll do the soles too, then."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:187
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_e85d0f78:

    # Mom "Ahh... Landlord never does ANYTHING like this, for me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:188
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch1r_24719c88_1:

    # Mom "God... your fingers are amazing."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:198
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_ff17e220:

    # MC "Can you spread your legs a little more, Mom?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:200
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_a18f2681:

    # MC "Can you spread your legs a little more, Linda?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:201
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_3c3139d5:

    # Mom "Of course. Like this?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:202
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_75715e4e:

    # MC "Perfect."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:205
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_95583728:

    # Mom "Ooh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:206
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_4c1e9741:

    # Mom "(His fingers are so close to my pussy... I wish he’d go a little bit closer, and just slip them inside me.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:207
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_60097e86:

    # MC "Your skin’s so soft."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:210
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_771c4edc:

    # Mom "The trick is, an exfoliating scrub and moisturiser, twice a day."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:211
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_c99e9ed8:

    # MC "Are you okay if I touch your breasts?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:212
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_f57c338c:

    # Mom "Please, go ahead."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:215
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:216
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_6cbd7aea:

    # Mom "You can give them a squeeze, if you want."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:217
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_de892c19:

    # Mom "Just don’t be too rough, okay?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:220
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:221
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_83068f48:

    # MC "(This is freaking awesome!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:222
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_3ad38725:

    # MC "(I hope I get to play with them, without the bra, soon!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:225
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_ffa2753c:

    # Mom "If we weren’t wearing our underwear, I would just pull you inside me, right now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:226
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_dac3f703:

    # Mom "Mmm... I’d love to feel your cock, thrusting, deep into my wet pussy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:229
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_838b5fd1:

    # Mom "I can already feel your hard cock, pressing against my black panties."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:230
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_28d866db:

    # Mom "Sadly, I have to go. If I spend, another minute in bed, I’ll be late for work."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:231
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_775c12a5:

    # Mom "I’ll see you tonight, Sweetie."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:233
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_99e35e67:

    # MC "I love you, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:235
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_e517d6c7:

    # MC "I love you, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:236
translate chinese ml_bedroom_morning_scene6_v1_label_after_ch21r_2b4de539:

    # Mom "I love you too."
    Mom ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:17
    old "I love you too."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:17
    old "I think I want the... same thing."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:17
    old "You should have told me sooner."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:156
    old "Give Mom a foot massage to begin."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:156
    old "Give Linda a foot massage to begin."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:156
    old "Start with Mom’s hips, and work up her body"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/ml_room_fj_v1.rpy:156
    old "Start with Linda’s Hips, and work up her body"
    new ""

