﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:7
translate chinese Ci_S1_rep_903a2cfd:

    # MC "Here you go! It’s a deal!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:8
translate chinese Ci_S1_rep_421d1c35:

    # Cindy "Ka-ching, baby!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:9
translate chinese Ci_S1_rep_64d79c7d:

    # MC "I’m expecting the best damn blowjob of my life, right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:12
translate chinese Ci_S1_rep_c9c3acb1:

    # Cindy "Well, I hope I can live up to your expectations, baby."
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:13
translate chinese Ci_S1_rep_0d2b812f:

    # Cindy "Want me to lose my top?"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:14
translate chinese Ci_S1_rep_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:24
translate chinese Ci_S1_rep_676c0b15:

    # MC "Oh wow, you’re REALLY toned!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:25
translate chinese Ci_S1_rep_1dba80d7:

    # Cindy "I’d give credit to my workout regime... but it’s probably just my insanely high metabolism - on account of all the cocaine I take..."
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:26
translate chinese Ci_S1_rep_a3a9cdae:

    # MC "(Yikes...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:29
translate chinese Ci_S1_rep_bd38a975:

    # Cindy "You’ve got a really big dick, baby!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:30
translate chinese Ci_S1_rep_55af7f9b:

    # Cindy "I can’t wait to make you squirm, as I suck your balls dry!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:33
translate chinese Ci_S1_rep_bad30dfe:

    # Cindy "Mmm... *Suck Suck*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:34
translate chinese Ci_S1_rep_7c6bc164:

    # MC "Oh God... Yes... Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:35
translate chinese Ci_S1_rep_129f1775:

    # MC "(It feels so good when she’s sucking my balls like that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:38
translate chinese Ci_S1_rep_326725ce:

    # Cindy "*Suuuuccck*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:40
translate chinese Ci_S1_rep_6e408f5a:

    # MC "Ahhh... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:43
translate chinese Ci_S1_rep_c5763b10:

    # MC "(Mmm, she’s really good at this! I’m starting to feel a little less stung, on dropping a grand for this...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:44
translate chinese Ci_S1_rep_21e9ec0c:

    # Cindy "*Shluurrrrp*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:47
translate chinese Ci_S1_rep_92808095:

    # MC "Oh yeah... Just like that, Cindy. Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:48
translate chinese Ci_S1_rep_69c87f55:

    # Cindy "*Suck Suck*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:49
translate chinese Ci_S1_rep_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:52
translate chinese Ci_S1_rep_bd4bfda4:

    # Cindy "Hehe, you’re really hard, baby!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:53
translate chinese Ci_S1_rep_a30f1362:

    # Cindy "Let’s get your cock in my mouth now. I want to feel your shaft slipping down my throat."
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:56
translate chinese Ci_S1_rep_82c227b8:

    # Cindy "*Suck*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:58
translate chinese Ci_S1_rep_e33637c2:

    # MC "Mmm! Holy fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:60
translate chinese Ci_S1_rep_026f2ea1:

    # MC "(Her mouth is so warm and wet!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:63
translate chinese Ci_S1_rep_9995a02b:

    # MC "(I’ve paid so much, I think I have a right to a little more than just some head bobbing.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:65
translate chinese Ci_S1_rep_a2d3e897:

    # Cindy "Nmmpff?!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:66
translate chinese Ci_S1_rep_1706e5f1:

    # MC "I hope you’ve done deepthroat before, Cindy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:69
translate chinese Ci_S1_rep_f6718cd2:

    # Cindy "*SHLUURRRRP* *GAG*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:70
translate chinese Ci_S1_rep_9cef31ad:

    # MC "Ohhh fuuuuck! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:71
translate chinese Ci_S1_rep_1e73f88a:

    # Cindy "*SPLUTTER*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:74
translate chinese Ci_S1_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:75
translate chinese Ci_S1_rep_fa58f707:

    # Cindy "*GAG* *SUUUCCCK*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:77
translate chinese Ci_S1_rep_2bcacb07:

    # MC "Ahhh... Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:80
translate chinese Ci_S1_rep_cc34414f:

    # MC "Okay, time to actually begin!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:81
translate chinese Ci_S1_rep_974f7560:

    # Cindy "(Wait - he hadn’t started yet?!)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:82
translate chinese Ci_S1_rep_1d317a43:

    # MC "I’m gonna facefuck you, so hard!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:85
translate chinese Ci_S1_rep_103bca38:

    # Cindy "Hmmpff?!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:86
translate chinese Ci_S1_rep_b7649f44:

    # MC "Hnnnnggg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:87
translate chinese Ci_S1_rep_6cea4327:

    # Cindy "(Uh oh.)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:90
translate chinese Ci_S1_rep_ec68725e:

    # Cindy "*SHLUUURRRRRP*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:91
translate chinese Ci_S1_rep_5157a423:

    # MC "HNNNNGGGG! Oh YES!!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:92
translate chinese Ci_S1_rep_fed2e88f:

    # MC "Holy fuck! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:95
translate chinese Ci_S1_rep_0b6a6942:

    # Cindy "*SHLURP SUCK SHLURP*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:96
translate chinese Ci_S1_rep_717987c5:

    # MC "Mmm! Yes! Suck my cock, you fucking slut! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:97
translate chinese Ci_S1_rep_ebbe6c06:

    # Cindy "*SUCK SUCK*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:100
translate chinese Ci_S1_rep_637a6192:

    # Cindy "(Oh God, his cock is slipping right down my throat! I can barely breathe!)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:101
translate chinese Ci_S1_rep_c73ec10e:

    # MC "I’m gonna fill up your slutty little mouth with my cum - and you’re going to swallow it all!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:102
translate chinese Ci_S1_rep_cdc75d04:

    # Cindy "*SHLURP*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:105
translate chinese Ci_S1_rep_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:106
translate chinese Ci_S1_rep_8db6b355:

    # Cindy "*GASP*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:107
translate chinese Ci_S1_rep_54c5f9cf:

    # Cindy "(He’s so domineering, the way he’s grabbing my head.)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:110
translate chinese Ci_S1_rep_3bfbafa5:

    # MC "(God, I’m not going to last much longer!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:111
translate chinese Ci_S1_rep_c2c82934:

    # MC "Ugh! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:114
translate chinese Ci_S1_rep_e15d26db:

    # Cindy "NNMPPFFFF! MMMMMMMPPF!!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:115
translate chinese Ci_S1_rep_61af625a:

    # Cindy "*GAG* *SPLUTTER*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:117
translate chinese Ci_S1_rep_759223fe:

    # MC "Mmm! Choke on it! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:120
translate chinese Ci_S1_rep_c732af31:

    # MC "Hnnnnng! Ahh! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:121
translate chinese Ci_S1_rep_a52b082a:

    # MC "(Her throat is so tight! I can feel it wrapped around my glans right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:122
translate chinese Ci_S1_rep_ba224ba7:

    # MC "(There’s vibrations, every time she moans!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:125
translate chinese Ci_S1_rep_756524ec:

    # MC "Oh yeah! I’m cumming! HHNNNNNGGG!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:126
translate chinese Ci_S1_rep_aa9f13da:

    # MC "Gahhhh!!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:127
translate chinese Ci_S1_rep_208fc000:

    # Cindy "HMPPPFF!! Mmmm!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:128
translate chinese Ci_S1_rep_ebbe6c06_1:

    # Cindy "*SUCK SUCK*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:138
translate chinese Ci_S1_rep_1a7e7c33:

    # MC "Ahhh! OH YEAH! FUCK! MMMMM!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:139
translate chinese Ci_S1_rep_48ce9c91:

    # Cindy "*GAG* *SHLLUUURRRP*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:140
translate chinese Ci_S1_rep_657044e2:

    # Cindy "(Oh wow! There’s so much of his cum, flooding into my mouth!)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:143
translate chinese Ci_S1_rep_c1b672a1:

    # Cindy "*Cough Cough*"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:144
translate chinese Ci_S1_rep_2c95ef21:

    # MC "*Pant* That was *pant* amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:145
translate chinese Ci_S1_rep_e4d2734e:

    # Cindy "*Cough* For you maybe! You asshole. You didn’t have to be so rough!"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:146
translate chinese Ci_S1_rep_878e8762:

    # MC "*Sigh* Sorry. I’ll head on now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:149
translate chinese Ci_S1_rep_2509ecae:

    # Cindy "(Wow... that was so intense!)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:150
translate chinese Ci_S1_rep_ecab11c9:

    # Cindy "(I just wish he had grabbed my pigtails.)"
    Cindy ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ci/Ci_S1_rep.rpy:151
translate chinese Ci_S1_rep_c13950e7:

    # Cindy "(I’m already gushing like a fountain down there! If he was any rougher, I would have probably let him pound my ass!)"
    Cindy ""

