﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:15
translate chinese MLR2_ES3_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:16
translate chinese MLR2_ES3_rep_33986a1c:

    # MC "Now, as I think about it.. I should wear something better.."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:17
translate chinese MLR2_ES3_rep_869e6bf2:

    # MC "Yeah. I should quickly go change!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:26
translate chinese MLR2_ES3_rep_fbe44d5a:

    # MC "(Okay? Date night with Mom. What should I wear?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:28
translate chinese MLR2_ES3_rep_cc25ffad:

    # MC "(Okay? Date night with Linda. What should I wear?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:29
translate chinese MLR2_ES3_rep_53d77bdf:

    # MC "(I don’t want to look TOO formal.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:30
translate chinese MLR2_ES3_rep_5b4d1e6d:

    # MC "(But I have to dress up, smarter than usual.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:35
translate chinese MLR2_ES3_rep_bec58e7e:

    # MC "(Yeah, this is looking good.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:36
translate chinese MLR2_ES3_rep_cc756812:

    # MC "(It’s only dinner anyway.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:38
translate chinese MLR2_ES3_rep_2c24535f:

    # MC "(Okay - time to meet Mom in the garage.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:40
translate chinese MLR2_ES3_rep_6bce348f:

    # MC "(Okay - time to meet Linda in the garage.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:49
translate chinese MLR2_ES3_rep_467ce4c5:

    # MC "(I’ve been waiting in the garage for ten minutes now. I wonder if Mom has forgotten about our date.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:51
translate chinese MLR2_ES3_rep_aaddeca4:

    # MC "(I’ve been waiting in the garage for ten minutes now. I wonder if Linda has forgotten about our date.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:52
translate chinese MLR2_ES3_rep_57cad0c9:

    # MC "(Then again, she’s a woman - and they can take FOREVER, getting ready to go out.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:53
translate chinese MLR2_ES3_rep_b555ad05:

    # MC "(I’ll give her another five minutes before I search for her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:57
translate chinese MLR2_ES3_rep_eb2e3391:

    # Mom "Hi, Sweetie. Sorry to keep you waiting!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:58
translate chinese MLR2_ES3_rep_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:59
translate chinese MLR2_ES3_rep_1ec0bcd7:

    # Mom "What do you think? Like my dress?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:60
translate chinese MLR2_ES3_rep_a06d8140:

    # MC "Hell yeah! It’s amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:65
translate chinese MLR2_ES3_rep_172c9f84:

    # Mom "I haven’t worn this little number, in almost ten years. I just never felt sexy enough to wear it while I was with your father."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:67
translate chinese MLR2_ES3_rep_d4572ec8:

    # Mom "I haven’t worn this little number, in almost ten years. I just never felt sexy enough to wear it while I was with Bob."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:68
translate chinese MLR2_ES3_rep_de28d6fb:

    # Mom "What do you think? Is it too short to go out in?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:69
translate chinese MLR2_ES3_rep_b126cfad:

    # MC "Maybe a little bit."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:70
translate chinese MLR2_ES3_rep_84f75a15:

    # Mom "Good. That’s what I was aiming for."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:74
translate chinese MLR2_ES3_rep_bfbd07f5:

    # MC "You ARE looking great tonight, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:76
translate chinese MLR2_ES3_rep_c5bf9fac:

    # MC "You ARE looking great tonight, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:77
translate chinese MLR2_ES3_rep_23954c99:

    # Mom "Thanks! I actually had to climb into the attic to find this dress. It was packed away."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:81
translate chinese MLR2_ES3_rep_40f9011c:

    # Mom "Now, hop in the car. I’ll drive us to the restaurant."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:82
translate chinese MLR2_ES3_rep_b10b1135:

    # Mom "We’re already a little bit late!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:83
translate chinese MLR2_ES3_rep_84b168f7:

    # MC "Okay, let’s go!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:92
translate chinese MLR2_ES3_rep_e9948b3e:

    # MC "(I wonder if I’ll get to fuck Mom tonight?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:94
translate chinese MLR2_ES3_rep_6d8d3ad2:

    # MC "(I wonder if I’ll get to fuck Linda tonight?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:95
translate chinese MLR2_ES3_rep_f8e6172c:

    # MC "(That’s what happens after a guy and girl come back from a date, right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:96
translate chinese MLR2_ES3_rep_ee1a2cab:

    # MC "(I should probably try and bring her back to my bedroom, after we get home.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:97
translate chinese MLR2_ES3_rep_936b3a03:

    # MC "(God, I’m getting so nervous. Is this even a date? Should I have brought her some flowers?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:101
translate chinese MLR2_ES3_rep_ba95dc2a:

    # Mom "You okay there, Sweetie? You’ve been awfully quiet."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:102
translate chinese MLR2_ES3_rep_0b95aa28:

    # MC "Y-Yeah, I’m fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:103
translate chinese MLR2_ES3_rep_09354e90:

    # Mom "Are you sure? You can tell me anything at all."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:107
translate chinese MLR2_ES3_rep_c3f6b0eb:

    # MC "Well... I was kind of nervous about tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:108
translate chinese MLR2_ES3_rep_98a08918:

    # MC "I didn’t bring you any flowers or chocolates - and to be honest, I’m not even sure if this is a date or not. Or maybe just-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:109
translate chinese MLR2_ES3_rep_63599895:

    # Mom "[player_name], just relax and don’t think too much about it, okay?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:110
translate chinese MLR2_ES3_rep_a4ab5b20:

    # MC "But...-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:113
translate chinese MLR2_ES3_rep_1b5a710a:

    # Mom "-Haha! You’re adorable. Just focus on enjoying yourself tonight, okay?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:115
translate chinese MLR2_ES3_rep_c9298cb6:

    # MC "Alright. Thanks, Mom. Sorry I was so nervous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:117
translate chinese MLR2_ES3_rep_c3852580:

    # MC "Alright. Thanks, Linda. Sorry I was so nervous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:118
translate chinese MLR2_ES3_rep_cbf41a5d:

    # Mom "It’s alright, Sweetie. Just let me lead the way."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:127
translate chinese MLR2_ES3_rep_30e9c214:

    # Mom "Here we go - you’ll absolutely LOVE the food."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:128
translate chinese MLR2_ES3_rep_75ed9a5a:

    # MC "Uhh... Where are we sitting? It looks like they’re really busy tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:129
translate chinese MLR2_ES3_rep_1f74e095:

    # Mom "How about you go and find us an empty table?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:133
translate chinese MLR2_ES3_rep_8d422881:

    # Mom "I’ll pop off to the ladies’ room, and join you in a couple of minutes."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:135
translate chinese MLR2_ES3_rep_20d20b0d:

    # MC "No problem, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:137
translate chinese MLR2_ES3_rep_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:169
translate chinese resteurant_table_label_rep_4e9ddd63:

    # Mom "Good find! This is a nice little booth."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:170
translate chinese resteurant_table_label_rep_cd3e3ffb:

    # MC "(That dress is so short, I can see her panties!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:172
translate chinese resteurant_table_label_rep_55cfdb74:

    # MC "Thanks, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:174
translate chinese resteurant_table_label_rep_c0a111cf:

    # MC "Thanks, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:178
translate chinese resteurant_table_label_rep_1b708302:

    # Mom "How about you choose the dish tonight?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:179
translate chinese resteurant_table_label_rep_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:180
translate chinese resteurant_table_label_rep_187a5fcd:

    # Mom "Everything is really great here. You can’t go wrong, I promise."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:181
translate chinese resteurant_table_label_rep_ec32c7a9:

    # MC "Are there any foods you don’t like?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:182
translate chinese resteurant_table_label_rep_51585735:

    # Mom "Red onion and anchovies. I’ll eat anything else."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:252
translate chinese MLR2_ES3_continue_label_rep_f1bcfff0:

    # Mom "So, while we’re waiting for our meal to come, I’ve got a question I really wanted to know."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:253
translate chinese MLR2_ES3_continue_label_rep_2d25befd:

    # MC "Uh huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:254
translate chinese MLR2_ES3_continue_label_rep_d8299759:

    # Mom "I was wondering. Are you still looking for a girlfriend? Maybe one at your age?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:263
translate chinese MLR2_ES3_continue_label_rep_59334f39:

    # MC "Not right now. I’m still the laughing stock of the college, because of that Celia incident."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:264
translate chinese MLR2_ES3_continue_label_rep_000874ba:

    # Mom "Ahh, of course. Well, that’s perfectly understandable."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:268
translate chinese MLR2_ES3_continue_label_rep_5c148e4a:

    # Mom "Just return to dating in your own time, whenever you feel comfortable."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:269
translate chinese MLR2_ES3_continue_label_rep_4b53bcfe:

    # Mom "And, as always, I’m always here if you need me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:271
translate chinese MLR2_ES3_continue_label_rep_5727cbc0:

    # MC "Thanks, Mom. You’re the best."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:273
translate chinese MLR2_ES3_continue_label_rep_e2f9424e:

    # MC "Thanks, Linda. You’re the best."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:279
translate chinese MLR2_ES3_continue_label_rep_67459acc:

    # MC "Yeah, Mom. I'm still searching... (How can I name that secret relationship with you...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:281
translate chinese MLR2_ES3_continue_label_rep_3669e25f:

    # MC "Yeah, Linda. I'm still searching... (How can I name that secret relationship with you...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:282
translate chinese MLR2_ES3_continue_label_rep_80c242d7:

    # Mom "Oh? Are you suggesting that both of us are still searching as well?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:286
translate chinese MLR2_ES3_continue_label_rep_efefda80:

    # Mom "Is there... someone specific you have in mind? (I believe my other half is very close right now.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:287
translate chinese MLR2_ES3_continue_label_rep_c1bf35e6:

    # MC "A few hot girls, here and there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:288
translate chinese MLR2_ES3_continue_label_rep_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:289
translate chinese MLR2_ES3_continue_label_rep_14820c87:

    # Mom "I don’t think it’s a good idea for you to rush into a relationship again, so soon after what happened last time with your professor."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:290
translate chinese MLR2_ES3_continue_label_rep_c27c6cee:

    # MC "Umm... I’ll keep that in mind."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:296
translate chinese MLR2_ES3_continue_label_rep_55867cd3:

    # MC "I’m not sure, right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:298
translate chinese MLR2_ES3_continue_label_rep_1e37f87e:

    # Mom "That’s okay. You know - both your sisters are single. Maybe you could pick up one of them!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:299
translate chinese MLR2_ES3_continue_label_rep_2d4e7d96:

    # MC "MOM!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:301
translate chinese MLR2_ES3_continue_label_rep_bccaf564:

    # Mom "That’s okay. You know, both your friends are single. Maybe you could pick up one of them!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:302
translate chinese MLR2_ES3_continue_label_rep_c8dc7952:

    # MC "LINDA!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:307
translate chinese MLR2_ES3_continue_label_rep_b54f571a:

    # Mom "Hahaha! I’m just teasing! I know you’re close with Sara and Caroline."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:308
translate chinese MLR2_ES3_continue_label_rep_5b65e14e:

    # MC "Heh... I guess so."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:319
translate chinese after_menu_MLR2_ES3_continue_label_rep_4b573baf:

    # Mom "Mmm... Roasted salmon with sweet potato. Good choice."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:320
translate chinese after_menu_MLR2_ES3_continue_label_rep_31111016:

    # Mom "I always loved how they both melt in your mouth, when slow-cooked."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:324
translate chinese after_menu_MLR2_ES3_continue_label_rep_fa813b43:

    # Mom "Well, let’s dig in, shall we?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:325
translate chinese after_menu_MLR2_ES3_continue_label_rep_232ccba0:

    # MC "Sounds good to me! Want any salt or pepper?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:326
translate chinese after_menu_MLR2_ES3_continue_label_rep_8690c1db:

    # Mom "Just a little pepper, please. Too much salt, and you’ll ruin the salmon."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:331
translate chinese after_menu_MLR2_ES3_continue_label_rep_126a82cf:

    # Mom "Tomato and pesto linguine. Very nice."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:332
translate chinese after_menu_MLR2_ES3_continue_label_rep_488669a6:

    # Mom "I can’t remember the last time I had a proper pasta dish - it must have been three years ago, when I last visited Italy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:333
translate chinese after_menu_MLR2_ES3_continue_label_rep_f7579f8f:

    # MC "Was the food good, over there?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:334
translate chinese after_menu_MLR2_ES3_continue_label_rep_f473fdc1:

    # Mom "It was incredible! Completely out of this world!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:338
translate chinese after_menu_MLR2_ES3_continue_label_rep_0930f8e2:

    # MC "What about Dad? Did he enjoy the food in Italy?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:340
translate chinese after_menu_MLR2_ES3_continue_label_rep_a2754554:

    # MC "What about Bob, did he enjoy the food in Italy?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:341
translate chinese after_menu_MLR2_ES3_continue_label_rep_fa044d30:

    # Mom "Mmm... Absolutely not. He didn’t even come with me. I went by myself - ended up having dinner with a lovely young Italian lady named Viviana."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:342
translate chinese after_menu_MLR2_ES3_continue_label_rep_a90cc1e4:

    # Mom "Last time I heard from her, I think she was looking to immigrate here for work."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:347
translate chinese after_menu_MLR2_ES3_continue_label_rep_82ad2484:

    # Mom "Hmm... Sausages and potatoes..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:348
translate chinese after_menu_MLR2_ES3_continue_label_rep_b6271b65:

    # Mom "You sure know how to treat a girl!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:349
translate chinese after_menu_MLR2_ES3_continue_label_rep_301a078d:

    # MC "(Uh oh... Maybe I should have picked something more... upmarket.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:353
translate chinese after_menu_MLR2_ES3_continue_label_rep_fd9c95cd:

    # Mom "At least it tastes pretty good."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:354
translate chinese after_menu_MLR2_ES3_continue_label_rep_d9d24266:

    # MC "(Phew!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:356
translate chinese after_menu_MLR2_ES3_continue_label_rep_c04cddf9:

    # MC "(I think I’m off the hook, at least. I should definitely consider a fancier dish, if I ever take Mom out for dinner again!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:358
translate chinese after_menu_MLR2_ES3_continue_label_rep_495162e9:

    # MC "(I think I’m off the hook, at least. I should definitely consider a fancier dish, if I ever take Linda out for dinner again!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:363
translate chinese after_menu_MLR2_ES3_continue_label_rep_f4338f8d:

    # Mom "I must admit. I’ve never actually tried seafood salad before."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:364
translate chinese after_menu_MLR2_ES3_continue_label_rep_93e789c7:

    # Mom "My loathing of anchovies has made me somewhat anxious when it comes to trying new seafoods."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:365
translate chinese after_menu_MLR2_ES3_continue_label_rep_fa6c0517:

    # MC "Give it a go - you’ll probably like it!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:366
translate chinese after_menu_MLR2_ES3_continue_label_rep_c55f82e0:

    # MC "If it turns out you don’t we can just order another dish - I’ll pay."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:370
translate chinese after_menu_MLR2_ES3_continue_label_rep_74a63f00:

    # Mom "Hmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:371
translate chinese after_menu_MLR2_ES3_continue_label_rep_1c934c68:

    # MC "Not a fan?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:372
translate chinese after_menu_MLR2_ES3_continue_label_rep_e9240966:

    # Mom "It’s... just alright. A nice pasta would have probably gone down better."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:373
translate chinese after_menu_MLR2_ES3_continue_label_rep_ae475621:

    # MC "Ahh, I’ll remember that for future."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:374
translate chinese after_menu_MLR2_ES3_continue_label_rep_e28dcb74:

    # Mom "Don’t worry - it’s nice to be pushed out of my comfort zone every now and then."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:379
translate chinese after_menu_MLR2_ES3_continue_label_rep_f84d6ae1:

    # Mom "Thank you for joining me tonight, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:381
translate chinese after_menu_MLR2_ES3_continue_label_rep_7a5d07c8:

    # MC "You don't’ need to thank me, Mom. I’m having a great time!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:383
translate chinese after_menu_MLR2_ES3_continue_label_rep_77a7da3d:

    # MC "You don't need to thank me, Linda. I’m having a great time!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:384
translate chinese after_menu_MLR2_ES3_continue_label_rep_3acaa154:

    # Mom "How about a wine, then? Red or white?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:385
translate chinese after_menu_MLR2_ES3_continue_label_rep_ba75e92d:

    # MC "Uhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:386
translate chinese after_menu_MLR2_ES3_continue_label_rep_2dafe954:

    # Mom "You’re clearly not a wine connoisseur. We’ll go for a red."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:391
translate chinese after_menu_MLR2_ES3_continue_label_rep_92b17e42:

    # Mom "Well? What do you think?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:392
translate chinese after_menu_MLR2_ES3_continue_label_rep_a7a55e9c:

    # MC "It’s... uh... fruity?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:393
translate chinese after_menu_MLR2_ES3_continue_label_rep_5d02c4b9:

    # Mom "Someone more experienced would probably describe this as: floral, with strong undertones of red grape, garnished with a crisp afterbite."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:394
translate chinese after_menu_MLR2_ES3_continue_label_rep_66dc0fbb:

    # Mom "But, yes, I suppose “fruity” works too."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:398
translate chinese after_menu_MLR2_ES3_continue_label_rep_260ac126:

    # MC "Sorry, it’s my first time ever drinking such an expensive wine, so I’m not very experienced with the terminologies."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:399
translate chinese after_menu_MLR2_ES3_continue_label_rep_db2c98a4:

    # Mom "Relax - it’s cute."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:401
translate chinese after_menu_MLR2_ES3_continue_label_rep_d50fe088:

    # MC "Uh... Mom? Is that you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:403
translate chinese after_menu_MLR2_ES3_continue_label_rep_69553a8b:

    # MC "Uh... Linda? Is that you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:404
translate chinese after_menu_MLR2_ES3_continue_label_rep_d6ea4baa:

    # Mom "What do you mean?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:408
translate chinese after_menu_MLR2_ES3_continue_label_rep_1b8a891b:

    # MC "(I KNEW it was her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:409
translate chinese after_menu_MLR2_ES3_continue_label_rep_2de7e191:

    # MC "Your foot... it’s on my..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:410
translate chinese after_menu_MLR2_ES3_continue_label_rep_edbfacd6:

    # Mom "On your what, Dear?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:414
translate chinese after_menu_MLR2_ES3_continue_label_rep_55a2215d:

    # MC "We’re in public, Mom..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:416
translate chinese after_menu_MLR2_ES3_continue_label_rep_bc341ea8:

    # MC "We’re in public..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:417
translate chinese after_menu_MLR2_ES3_continue_label_rep_1d56bf81:

    # MC "There’s shit-loads of people! This place is packed out tonight!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:418
translate chinese after_menu_MLR2_ES3_continue_label_rep_840c6aa3:

    # Mom "Hmm, we better not get caught then. That would be rather embarrassing for you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:422
translate chinese after_menu_MLR2_ES3_continue_label_rep_a87bed8b:

    # MC "Oh, my God - you’re not seriously going to go through with this, right?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:423
translate chinese after_menu_MLR2_ES3_continue_label_rep_75d0b430:

    # Mom "Mmm... I most certainly am, Dear."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:424
translate chinese after_menu_MLR2_ES3_continue_label_rep_280a0f69:

    # MC "(Fuck! Should I try to stop her?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:448
translate chinese MLR2_ES3_footjob_label_rep_bb475a85:

    # MC "(I guess it wouldn’t hurt to let her continue. We just have to be very careful.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:453
translate chinese MLR2_ES3_footjob_label_rep_d0e2f324:

    # "*Zzzzzziiiiiipppp*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:458
translate chinese MLR2_ES3_footjob_label_rep_b8bc3254:

    # MC "(She just undid my zipper with her toes and pulled my boxer shorts down!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:460
translate chinese MLR2_ES3_footjob_label_rep_298206f3:

    # MC "Mom-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:462
translate chinese MLR2_ES3_footjob_label_rep_0690d7b1:

    # MC "Linda-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:463
translate chinese MLR2_ES3_footjob_label_rep_9fb54e62:

    # Mom "Shush. The trick is, to avoid reacting. You don’t want to alert any other diners, as to what is going on."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:467
translate chinese MLR2_ES3_footjob_label_rep_2d969cca:

    # Mom "Besides - Don’t tell me that you’re not enjoying this?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:468
translate chinese MLR2_ES3_footjob_label_rep_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:469
translate chinese MLR2_ES3_footjob_label_rep_9ffd99fa:

    # Mom "I thought so."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:470
translate chinese MLR2_ES3_footjob_label_rep_88c2c0ee:

    # Mom "Now, let me slip my other shoe off, so I can get both feet working on your cock."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:474
translate chinese MLR2_ES3_footjob_label_rep_fe94855f:

    # MC "Oooh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:477
translate chinese MLR2_ES3_footjob_label_rep_01b60380:

    # Mom "Sounds like my big boy’s enjoying having Mommy’s feet, rubbing over his thick hard cock."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:479
translate chinese MLR2_ES3_footjob_label_rep_d2e7a803:

    # Mom "Sounds like you’re enjoying having my bare feet rubbing over his thick, hard cock."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:480
translate chinese MLR2_ES3_footjob_label_rep_18585998:

    # MC "(Fuck, this feels so good...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:484
translate chinese MLR2_ES3_footjob_label_rep_62c12589:

    # Mom "What’s wrong? You’re looking a little flustered, Sweetie."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:485
translate chinese MLR2_ES3_footjob_label_rep_5cbc71e0:

    # Mom "Did you drink too much wine?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:486
translate chinese MLR2_ES3_footjob_label_rep_397260c1:

    # MC "S-Stop teasing me! Someone could ahh... see us!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:490
translate chinese MLR2_ES3_footjob_label_rep_4a4e7c24:

    # Mom "You worry too much. You need to learn to relax and enjoy the simple things in life..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:492
translate chinese MLR2_ES3_footjob_label_rep_b92ffb49:

    # Mom "...like your mother massaging your cock with her feet, in the middle of a public restaurant."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:494
translate chinese MLR2_ES3_footjob_label_rep_4187f12c:

    # Mom "...like your landlady massaging your cock with her feet, in the middle of a public restaurant."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:495
translate chinese MLR2_ES3_footjob_label_rep_ed1a6441:

    # MC "Ah... Oohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:496
translate chinese MLR2_ES3_footjob_label_rep_daeb6b1f:

    # MC "(She’s got a twisted definition of “simple things in life.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:500
translate chinese MLR2_ES3_footjob_label_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:501
translate chinese MLR2_ES3_footjob_label_rep_5c82260a:

    # MC "(She’s getting faster!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:502
translate chinese MLR2_ES3_footjob_label_rep_3054de58:

    # Mom "You’re acting rather strange - is everything okay, Sweetie?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:506
translate chinese MLR2_ES3_footjob_label_rep_afa56578:

    # MC "Shit! Someone LITERALLY just walked right by us!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:507
translate chinese MLR2_ES3_footjob_label_rep_9df4234e:

    # MC "If they spot us, they might call the police! We're in a public place!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:508
translate chinese MLR2_ES3_footjob_label_rep_32b6856e:

    # Mom "Well, you better hurry up and cum, then. Because this isn’t ending until you do."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:512
translate chinese MLR2_ES3_footjob_label_rep_7467115c:

    # MC "Ahhh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:515
translate chinese MLR2_ES3_footjob_label_rep_c9ee389e:

    # Mom "Oh, is my big boy close?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:516
translate chinese MLR2_ES3_footjob_label_rep_75db9c3e:

    # Mom "Cum for me. Cum all over your mommy’s feet."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:518
translate chinese MLR2_ES3_footjob_label_rep_d0011020:

    # Mom "Oh, are you close?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:519
translate chinese MLR2_ES3_footjob_label_rep_20cf9b78:

    # Mom "Cum for me. Cum all over my feet."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:520
translate chinese MLR2_ES3_footjob_label_rep_29adf468:

    # MC "(Dammit, I have to try and suppress my moaning, in public.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:529
translate chinese MLR2_ES3_footjob_label_rep_90a08020:

    # MC "Hnnnggg.... Ah..... Ugh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:531
translate chinese MLR2_ES3_footjob_label_rep_2cdac345:

    # Mom "That’s it! Good boy!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:533
translate chinese MLR2_ES3_footjob_label_rep_4ce033b6:

    # Mom "That’s it. Mmm... Good..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:534
translate chinese MLR2_ES3_footjob_label_rep_1396af60:

    # MC "Fuck... Ah.... Ohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:538
translate chinese MLR2_ES3_footjob_label_rep_ebadc1bb:

    # Mom "Wow - so much cum! You must have been REALLY horny!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:539
translate chinese MLR2_ES3_footjob_label_rep_a7847152:

    # MC "Q-Quiet. Here, take my napkin. Clean your feet quickly, before someone sees!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:540
translate chinese MLR2_ES3_footjob_label_rep_1d546320:

    # MC "(I think that has to be the most dangerous sex I’ve EVER had.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:541
translate chinese MLR2_ES3_footjob_label_rep_88505f38:

    # Mom "Finish off your wine, if you want. Then we can head home."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:542
translate chinese MLR2_ES3_footjob_label_rep_10d1e5fd:

    # MC "You’ve barely touched YOUR wine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:543
translate chinese MLR2_ES3_footjob_label_rep_800566a8:

    # Mom "That’s because I’m driving - Safety first, Dear."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:551
translate chinese MLR2_ES3_blowjob_label_rep_ab8e0172:

    # MC "Mom, you’ve got to stop! We’re in public!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:553
translate chinese MLR2_ES3_blowjob_label_rep_04b8a65e:

    # MC "Linda, you’ve got to stop! We’re in public!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:554
translate chinese MLR2_ES3_blowjob_label_rep_07eb54ca:

    # Mom "Aww... Why?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:555
translate chinese MLR2_ES3_blowjob_label_rep_1e8a931d:

    # MC "If a waiter catches us right now, we’ll both be screwed!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:556
translate chinese MLR2_ES3_blowjob_label_rep_a9151642:

    # Mom "*Sigh* If you insist."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:557
translate chinese MLR2_ES3_blowjob_label_rep_55952d17:

    # MC "Thank you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:558
translate chinese MLR2_ES3_blowjob_label_rep_459ccb13:

    # Mom "At the very least, can I come over and give you a hug?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:559
translate chinese MLR2_ES3_blowjob_label_rep_6cd5d7d5:

    # MC "Sure, that’s perfectly fine."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:563
translate chinese MLR2_ES3_blowjob_label_rep_d84286d4:

    # Mom "See? This is nice."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:564
translate chinese MLR2_ES3_blowjob_label_rep_e463807b:

    # MC "Yeah, it is."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:566
translate chinese MLR2_ES3_blowjob_label_rep_66cbb36a:

    # MC "Thanks for bringing me out tonight, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:568
translate chinese MLR2_ES3_blowjob_label_rep_b3bfa574:

    # MC "Thanks for bringing me out tonight, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:572
translate chinese MLR2_ES3_blowjob_label_rep_79d71771:

    # Mom "Well, I’d say the pleasure is all mine. But you seem to be enjoying yourself too."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:573
translate chinese MLR2_ES3_blowjob_label_rep_9a2cf3b7:

    # Mom "Do you like looking at my breasts?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:574
translate chinese MLR2_ES3_blowjob_label_rep_38244daa:

    # MC "What- I wasn’t-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:575
translate chinese MLR2_ES3_blowjob_label_rep_88a16011:

    # Mom "Of course you are!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:581
translate chinese MLR2_ES3_blowjob_label_rep_7a63b9f8:

    # Mom "I mean, what other reason could you POSSIBLY have, for being THIS hard?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:583
translate chinese MLR2_ES3_blowjob_label_rep_cc9d5ceb:

    # MC "Mom! Public!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:585
translate chinese MLR2_ES3_blowjob_label_rep_bbfac1a8:

    # MC "Linda! Public!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:586
translate chinese MLR2_ES3_blowjob_label_rep_63b32175:

    # MC "You can’t just start giving me a handjob in a place like this!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:587
translate chinese MLR2_ES3_blowjob_label_rep_bbf930e7:

    # Mom "Haha! Who said anything about a handjob?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:591
translate chinese MLR2_ES3_blowjob_label_rep_e24f02c2:

    # Mom "*Shlurrrrp!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:592
translate chinese MLR2_ES3_blowjob_label_rep_8d36417d:

    # MC "Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:593
translate chinese MLR2_ES3_blowjob_label_rep_a1146007:

    # Waiter "Is everything alright, Sir?"
    Waiter ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:594
translate chinese MLR2_ES3_blowjob_label_rep_5273b3e7:

    # MC "Y-Yeah, she just -ah- dropped her contact lens!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:598
translate chinese MLR2_ES3_blowjob_label_rep_04340fd0:

    # Waiter "No problem. If you need anything else, give me a shout."
    Waiter ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:599
translate chinese MLR2_ES3_blowjob_label_rep_54ac9d55:

    # Mom "*SUCK! SUCK!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:601
translate chinese MLR2_ES3_blowjob_label_rep_9c9667c1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:605
translate chinese MLR2_ES3_blowjob_label_rep_f7afa1b7:

    # MC "(I can’t believe she’s doing this right now! What the hell has gotten into her?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:606
translate chinese MLR2_ES3_blowjob_label_rep_7b68aa61:

    # Mom "*Shlurrrp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:608
translate chinese MLR2_ES3_blowjob_label_rep_69fc58b8:

    # MC "Ohh... fuck! She's speeded up!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:609
translate chinese MLR2_ES3_blowjob_label_rep_fac134a4:

    # Mom "(I just can’t hold myself back, around him! I need him to cum in my mouth!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:613
translate chinese MLR2_ES3_blowjob_label_rep_312847cd:

    # MC "Mmm...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:615
translate chinese MLR2_ES3_blowjob_label_rep_0d2cef16:

    # MC "(Damn! This feels so good! Mom gives phenomenal blowjobs!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:617
translate chinese MLR2_ES3_blowjob_label_rep_26c479c8:

    # MC "(Damn! This feels so good! Linda gives phenomenal blowjobs!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:618
translate chinese MLR2_ES3_blowjob_label_rep_c984db8c:

    # MC "(There’s so many people around though - I’m lucky we haven’t been spotted yet!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:622
translate chinese MLR2_ES3_blowjob_label_rep_05621810:

    # Mom "*SUCK SUCK SUCK*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:624
translate chinese MLR2_ES3_blowjob_label_rep_d1eeb2c7:

    # MC "Ohhh... Ohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:625
translate chinese MLR2_ES3_blowjob_label_rep_2b87d913:

    # Mom "(I can’t wait for [player_name] to spew his hot cum in my wet mouth!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:629
translate chinese MLR2_ES3_blowjob_label_rep_f9f3e033:

    # MC "Ahh... I’m gonna cum soon, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:631
translate chinese MLR2_ES3_blowjob_label_rep_8a3d4a63:

    # MC "Ahh... I’m gonna cum soon, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:632
translate chinese MLR2_ES3_blowjob_label_rep_65f7466a:

    # Mom "*Lick! Shlurp!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:634
translate chinese MLR2_ES3_blowjob_label_rep_89296ee4:

    # MC "God..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:638
translate chinese MLR2_ES3_blowjob_label_rep_e678d521:

    # MC "*Pant! Pant!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:639
translate chinese MLR2_ES3_blowjob_label_rep_643276e2:

    # Mom "(His cock’s beginning to throb between my lips! Time for the grand finale!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:640
translate chinese MLR2_ES3_blowjob_label_rep_6e4121b3:

    # MC "(Any seconds now! Yes!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:644
translate chinese MLR2_ES3_blowjob_label_rep_a560a239:

    # MC "Huh? (Why did she take it out of her mouth?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:645
translate chinese MLR2_ES3_blowjob_label_rep_d45d17bc:

    # Mom "Aaah..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:647
translate chinese MLR2_ES3_blowjob_label_rep_5243850e:

    # MC "M-Mom? Why did you stop? Is everything-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:649
translate chinese MLR2_ES3_blowjob_label_rep_30a93c63:

    # MC "L-Linda? Why did you stop? Is everything-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:653
translate chinese MLR2_ES3_blowjob_label_rep_5e84f7bf:

    # Mom "*SHLLURRRRRRRRRPPP!!!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:654
translate chinese MLR2_ES3_blowjob_label_rep_273777b7:

    # MC "OH God! Ahhh! Ahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:655
translate chinese MLR2_ES3_blowjob_label_rep_ed3a9079:

    # MC "Fuck! I’m cumming... Shit! Hnnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:663
translate chinese MLR2_ES3_blowjob_label_rep_d1ca9a37:

    # Mom "*Gulp! Gulp!*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:664
translate chinese MLR2_ES3_blowjob_label_rep_e2f4c749:

    # MC "(Holy fuck! She’s swallowing it all as I spray it into her mouth!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:668
translate chinese MLR2_ES3_blowjob_label_rep_38c0e9dc:

    # MC "Holy shit... Phew..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:669
translate chinese MLR2_ES3_blowjob_label_rep_7c206a9d:

    # MC "That was fucking incredible!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:670
translate chinese MLR2_ES3_blowjob_label_rep_332e204b:

    # Mom "I’m glad you enjoyed it, Sweetie."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:671
translate chinese MLR2_ES3_blowjob_label_rep_12124d8f:

    # MC "Were you not afraid of getting caught?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:672
translate chinese MLR2_ES3_blowjob_label_rep_88a34243:

    # Mom "Honestly - that just makes it even hotter for me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:684
translate chinese MLR2_ES3_end_label_rep_a15179e5:

    # MC "Thanks again for taking me out for dinner. I had a really good time, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:686
translate chinese MLR2_ES3_end_label_rep_234aa1c5:

    # MC "Thanks again for taking me out for dinner. I had a really good time, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:687
translate chinese MLR2_ES3_end_label_rep_a1736ca2:

    # Mom "Me too, Sweetie. I can’t wait to do it again."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:688
translate chinese MLR2_ES3_end_label_rep_38c00572:

    # MC "So, are we going home now or-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:692
translate chinese MLR2_ES3_end_label_rep_aea6b299:

    # MC "Mom, what’s wrong? Are you alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:694
translate chinese MLR2_ES3_end_label_rep_949c4c70:

    # MC "Linda, what’s wrong? Are you alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:695
translate chinese MLR2_ES3_end_label_rep_eeecef80:

    # Mom "I- I’m fine..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:696
translate chinese MLR2_ES3_end_label_rep_9a872aa9:

    # MC "You suddenly looked sad there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:700
translate chinese MLR2_ES3_end_label_rep_be79ab75:

    # MC "W-Was it something I said?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:701
translate chinese MLR2_ES3_end_label_rep_00d55ada:

    # Mom "No."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:702
translate chinese MLR2_ES3_end_label_rep_29a28e16:

    # MC "Did- Is this about me not bringing flowers or chocolates? I swear to God, I didn't know if this was supposed to be a date or not."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:707
translate chinese MLR2_ES3_end_label_rep_922d3921:

    # Mom "It’s not that."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:709
translate chinese MLR2_ES3_end_label_rep_af310fc2:

    # Mom "Your father is at home right now. The date ends as soon as we get home."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:711
translate chinese MLR2_ES3_end_label_rep_0ddb7420:

    # Mom "My husband is at home right now. The date ends as soon as we get home."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:712
translate chinese MLR2_ES3_end_label_rep_9deb2831:

    # MC "(So it WAS a date!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:713
translate chinese MLR2_ES3_end_label_rep_e4454a55:

    # MC "Hey, that’s okay."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:717
translate chinese MLR2_ES3_end_label_rep_7bb1ad78:

    # MC "We’ll have loads more dates together, in the future."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:719
translate chinese MLR2_ES3_end_label_rep_c8b77e93:

    # MC "And we can hang out together when Dad goes on his business trips. Okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:721
translate chinese MLR2_ES3_end_label_rep_42874bc4:

    # MC "And we can hang out together when Bob goes on his business trips. Okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:723
translate chinese MLR2_ES3_end_label_rep_3463417b:

    # Mom "*Sniff* Promise?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:725
translate chinese MLR2_ES3_end_label_rep_0e92612e:

    # MC "I promise, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:727
translate chinese MLR2_ES3_end_label_rep_2f3a36e0:

    # MC "I promise, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:733
translate chinese MLR2_ES3_end_label_rep_8a22ce72:

    # Mom "Thank you so much, [player_name]. I couldn’t have asked for a kinder boy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:734
translate chinese MLR2_ES3_end_label_rep_585b20f0:

    # Mom "Let’s get home before your father starts to wonder where we both are."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:735
translate chinese MLR2_ES3_end_label_rep_861d35e0:

    # MC "Okay, Mom. Love you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:737
translate chinese MLR2_ES3_end_label_rep_c4b77b95:

    # Mom "Thank you so much, [player_name]. You’re so kind."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:738
translate chinese MLR2_ES3_end_label_rep_4a6133ff:

    # Mom "Let’s get home before Bob starts to wonder where we both are."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:739
translate chinese MLR2_ES3_end_label_rep_f169098f:

    # MC "Okay, Linda. Love you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:740
translate chinese MLR2_ES3_end_label_rep_c6f945cd:

    # Mom "Love you too, Sweetie."
    Mom ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:259
    old "No, I’m still trying to get over that embarrassment with Celia."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:259
    old "Yeah, I’m still searching."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:259
    old "I’m not sure."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:428
    old "Try to stop Mom from rubbing her feet on your cock."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:428
    old "Try to stop Linda from rubbing her feet on your cock."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:428
    old "Let Mom give you a footjob under the table."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR2_ES3_rep.rpy:428
    old "Let Linda give you a footjob under the table."
    new ""

