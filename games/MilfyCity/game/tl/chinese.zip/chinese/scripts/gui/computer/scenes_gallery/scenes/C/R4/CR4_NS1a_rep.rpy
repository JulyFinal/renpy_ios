﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:12
translate chinese CR4_NS1a_rep_f869a591:

    # MC "Caroline? Where are yo-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:13
translate chinese CR4_NS1a_rep_3af94053:

    # MC "Wow!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:14
translate chinese CR4_NS1a_rep_eedcb3d7:

    # MC "(Holy shit! She looks incredible in that swimsuit! I normally prefer bikinis, but that one-piece really makes her breasts stand out!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:18
translate chinese CR4_NS1a_rep_e4ca7ec0:

    # Caroline "Surprise! Haha! What do you think? Like it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:19
translate chinese CR4_NS1a_rep_892f5f13:

    # MC "You look amazing in that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:20
translate chinese CR4_NS1a_rep_644627e8:

    # Caroline "Thanks. I’ve had it in my cupboard for a few years now. I’ve never really gotten a chance to wear it anywhere."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:21
translate chinese CR4_NS1a_rep_cb7c9c0d:

    # Caroline "It is a LITTLE bit too lewd for the swimming pool, after all. Haha!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:22
translate chinese CR4_NS1a_rep_d1ac6f39:

    # MC "Ahaha, true."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:26
translate chinese CR4_NS1a_rep_9f906d4b:

    # Caroline "Now, how about you strip down to your trunks. We’re going swimming!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:27
translate chinese CR4_NS1a_rep_45799c83:

    # MC "In the lake?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:28
translate chinese CR4_NS1a_rep_91778c47:

    # Caroline "Why not? It’s a warm night."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:32
translate chinese CR4_NS1a_rep_2fb32a9e:

    # MC "Uh, sure. Why not?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:33
translate chinese CR4_NS1a_rep_14d8d878:

    # Caroline "Great, I’ll catch you in there!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:34
translate chinese CR4_NS1a_rep_18572fd2:

    # MC "(I would never have guessed this was the surprise she was talking about!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:38
translate chinese CR4_NS1a_rep_891ed115:

    # MC "(She just dove straight in! I can’t keep her waiting any longer - time to strip out of these clothes.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:39
translate chinese CR4_NS1a_rep_6d66197d:

    # MC "Wait for me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:44
translate chinese CR4_NS1a_rep_7fda7291:

    # "*SPLASH**"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:45
translate chinese CR4_NS1a_rep_7b1843dc:

    # MC "(That tight swimsuit really shows off the best angle of her ass!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:46
translate chinese CR4_NS1a_rep_9264f6cd:

    # MC "(Her feet look incredible too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:50
translate chinese CR4_NS1a_rep_5d0c1bcd:

    # MC "(I hope Caroline’s right about the water being warm!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:51
translate chinese CR4_NS1a_rep_4c6ceec6:

    # MC "(I wouldn’t like to get a cold shock from diving blindly into this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:55
translate chinese CR4_NS1a_rep_1005c2c5:

    # Caroline "Ahh... Hurry up and get in here. The water’s lovely!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:56
translate chinese CR4_NS1a_rep_0ed64fa4:

    # Caroline "What are you waiting for? You’re not scared of a little water, are you? Haha!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:57
translate chinese CR4_NS1a_rep_afc28ee3:

    # MC "Of course not! I’m not Sara! Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:61
translate chinese CR4_NS1a_rep_1144b4ed:

    # Caroline "Hehe! Well, when you’re done admiring the view, come and join me. And when I say “view”, I mean me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:62
translate chinese CR4_NS1a_rep_038afe11:

    # MC "I wasn’t - umm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:63
translate chinese CR4_NS1a_rep_99355bd7:

    # Caroline "It’s okay, look all you want. I dressed this way, for YOU tonight. Enjoy it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:67
translate chinese CR4_NS1a_rep_39124583:

    # MC "You are beautiful, Caroline, you know that? You take my breath away every single time I see you. It doesn’t matter whether you’re in a sexy swimsuit, or your hot cosplay outfits, or... even just your regular clothes."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:68
translate chinese CR4_NS1a_rep_804903a4:

    # MC "You rock whatever outfit you wear, and you are stunningly gorgeous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:69
translate chinese CR4_NS1a_rep_a723c211:

    # Caroline "Aww, thank you, [player_name]. You’re so sweet."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:70
translate chinese CR4_NS1a_rep_2b630d0d:

    # Caroline "Now, how about you stop stalling, and join me? I’m not going to bite you! Unless you ask me to. Hehe!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:75
translate chinese CR4_NS1a_rep_6ccbac6e:

    # "*Splash*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:76
translate chinese CR4_NS1a_rep_d486f4c9:

    # Caroline "Haha! That was the LEAST elegant dive I’ve ever seen!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:80
translate chinese CR4_NS1a_rep_34ea6d79:

    # MC "You’ve clearly practiced more than me. Do you come down to this place to swim often?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:81
translate chinese CR4_NS1a_rep_13218543:

    # Caroline "Umm... Once or twice per year, when the stars align. I need good weather, a clear schedule, and a warm night. So it’s not as often as I’d like to be here."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:82
translate chinese CR4_NS1a_rep_b9272d36:

    # MC "What do you do?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:83
translate chinese CR4_NS1a_rep_ad19a370:

    # Caroline "Honestly, I’ll just swim a couple of laps - then I like to lie back and float. When there’s no clouds, you can see right up into the stars. There was one night, three years ago, when the power went out. Do you remember?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:84
translate chinese CR4_NS1a_rep_df5384da:

    # MC "Sort of."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:85
translate chinese CR4_NS1a_rep_abb05762:

    # Caroline "You went into Sara’s room to keep her company. I snuck out of the house and came down to the lake. The whole city had lost its power. There was no light pollution."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:86
translate chinese CR4_NS1a_rep_eff24a2b:

    # Caroline "The sky wasn’t black that night. If you stared hard enough you could see a rainbow of nebula between the starry diamonds. It was a once-in-a-lifetime experience."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:90
translate chinese CR4_NS1a_rep_a8fde49d:

    # Caroline "...and then the city’s power came back on and all I could see was a crescent moon and a handful of the strongest stars."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:91
translate chinese CR4_NS1a_rep_00f397f0:

    # MC "That sounds heavenly. I’d like to see that with you someday."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:92
translate chinese CR4_NS1a_rep_57e4b0e1:

    # Caroline "We’d probably have to borrow [Linda_name]’s car and drive outside the city limits though. Unless you want to wait for the miniscule chance of us seeing another blackout."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:93
translate chinese CR4_NS1a_rep_8e9c4586:

    # MC "Maybe that’s something we could do? Do you mind if I slip your top down?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:94
translate chinese CR4_NS1a_rep_5b02a939:

    # Caroline "Haha, of course not, [player_name]. You can do whatever you want to me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:98
translate chinese CR4_NS1a_rep_903faf79:

    # MC "*Whistle* Beautiful as always, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:99
translate chinese CR4_NS1a_rep_bf1cd9c8:

    # MC "(Her nipples are already stiff! Either she finds the water colder than she would care to admit, or she is already turned on!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:100
translate chinese CR4_NS1a_rep_b3371eaf:

    # MC "(I’m gonna start kissing my way down the back of her neck.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:104
translate chinese CR4_NS1a_rep_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:105
translate chinese CR4_NS1a_rep_4d3e8258:

    # Caroline "Mmm... Oh fuck... Right there."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:106
translate chinese CR4_NS1a_rep_1c0586b2:

    # Caroline "(God, I love the way he holds my breasts.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:110
translate chinese CR4_NS1a_rep_f050ce10_1:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:111
translate chinese CR4_NS1a_rep_bca896ee:

    # Caroline "Mmm! Ah... Ohh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:112
translate chinese CR4_NS1a_rep_2c2ccb86:

    # MC "(Her moaning is getting louder - she’s really enjoying this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:116
translate chinese CR4_NS1a_rep_83bd14bb:

    # MC "*Lick Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:117
translate chinese CR4_NS1a_rep_063d9ac3:

    # Caroline "Ah... Yes... Mmm! Play with my nipples! Ohh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:118
translate chinese CR4_NS1a_rep_72b604d0:

    # Caroline "(I’m getting so horny and wet right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:122
translate chinese CR4_NS1a_rep_3b58c51b:

    # MC "What can I do for you? Anything at all! I owe you big time for those amazing blowjobs you gave me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:123
translate chinese CR4_NS1a_rep_a9c20ce1:

    # Caroline "Anything?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:124
translate chinese CR4_NS1a_rep_bbd91dd1:

    # MC "I’ll suck your boobs, lick your pussy. Just name it. I want to make you feel as good as you made me feel."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:128
translate chinese CR4_NS1a_rep_a3ea908d:

    # Caroline "(I think... tonight might be the night to finally do it.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:129
translate chinese CR4_NS1a_rep_61fcaada:

    # Caroline "Hmm... Well, there is one thing."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:130
translate chinese CR4_NS1a_rep_5f172b26:

    # MC "Yeah, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:131
translate chinese CR4_NS1a_rep_cc15df20:

    # Caroline "I... Can you look away when I ask? Sorry, I can’t say it when you’re looking straight at me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:135
translate chinese CR4_NS1a_rep_0607b189:

    # MC "Haha, okay. What did you want to ask?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:136
translate chinese CR4_NS1a_rep_ca7f19e4:

    # Caroline "Can you... fuck- I want to have my first time with you tonight."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:137
translate chinese CR4_NS1a_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:141
translate chinese CR4_NS1a_rep_7a803880:

    # Caroline "Y-Yeah, I think I’m ready."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:142
translate chinese CR4_NS1a_rep_227b2517:

    # MC "Right here in the lake?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:143
translate chinese CR4_NS1a_rep_0cc20184:

    # Caroline "No... Over there on the riverbank. That’s where I lay when the power cut out. I love that spot."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:147
translate chinese CR4_NS1a_rep_d182bf2e:

    # Caroline "Whoa! You don’t have to carry me over there. I can swim by myself, you know!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:148
translate chinese CR4_NS1a_rep_62d30eec:

    # MC "But do you like me carrying you like this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:149
translate chinese CR4_NS1a_rep_dfafef7c:

    # Caroline "...yeah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:153
translate chinese CR4_NS1a_rep_06ccc228:

    # MC "Is this the spot?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:154
translate chinese CR4_NS1a_rep_cff1b41d:

    # Caroline "Yes, just right of the oak tree."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:155
translate chinese CR4_NS1a_rep_83e16f39:

    # MC "You’re not cold, are you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:159
translate chinese CR4_NS1a_rep_47820d97:

    # Caroline "Try and relax. I’m fine. I promise."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:160
translate chinese CR4_NS1a_rep_00ac0da5:

    # MC "Okay, I just didn’t want you catching a flu or-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:164
translate chinese CR4_NS1a_rep_c75cdf38:

    # Caroline "Hush... You’re worrying too much."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:165
translate chinese CR4_NS1a_rep_ee20bde4:

    # Caroline "Go ahead and set me down here. I’ll get myself ready for you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:166
translate chinese CR4_NS1a_rep_8c704b78:

    # Caroline "(My heart is racing right now - I guess tonight's the night.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:170
translate chinese CR4_NS1a_rep_4d31d835:

    # Caroline "Well, this is it, [player_name]. *Gulp* I’m all yours."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:171
translate chinese CR4_NS1a_rep_49ba2601:

    # MC "Are you okay, Caroline? You sound a little bit nervous."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:172
translate chinese CR4_NS1a_rep_eca4355f:

    # Caroline "I’ll be fine. I’m not sure if it’s nerves or maybe just excitement. What I do know for sure, is that I definitely want this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:176
translate chinese CR4_NS1a_rep_b8dc1140:

    # Caroline "I can see you’re already hard. Come on over and fuck me on the bank."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:177
translate chinese CR4_NS1a_rep_4709766e:

    # Caroline "I can’t wait to feel your thick cock inside me. "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:178
translate chinese CR4_NS1a_rep_f6bfe6f1:

    # Caroline "(I’ve been imagining [player_name]’s cock when I’ve been using my dildo, for FAR too long now.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:182
translate chinese CR4_NS1a_rep_f46fa3c8:

    # MC "I’m going to go slow when I start. I don’t want to hurt you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:183
translate chinese CR4_NS1a_rep_e741f1b6:

    # Caroline "Thank you, [player_name]. But don’t worry - you’re not going to hurt me. I promise."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:184
translate chinese CR4_NS1a_rep_30034a6e:

    # MC "Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:188
translate chinese CR4_NS1a_rep_ae37533a:

    # MC "(It already feels so good! Her vulva is so warm and wet!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:190
translate chinese CR4_NS1a_rep_67c2bad7:

    # MC "(I’ll have to try and not blow my load too quickly. I want to make our first time last as long as possible.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:194
translate chinese CR4_NS1a_rep_d52e6084:

    # Caroline "Ahh... yes! Put your cock inside me, [player_name]! I want to feel you fill me up!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:195
translate chinese CR4_NS1a_rep_afaa2e63:

    # MC "Ohh... Fuck... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:196
translate chinese CR4_NS1a_rep_84c0945f:

    # MC "(I can’t believe it - after waiting so long, it’s finally going to happen. I’m going to get to fuck her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:200
translate chinese CR4_NS1a_rep_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:201
translate chinese CR4_NS1a_rep_278d5957:

    # MC "I love you too, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:202
translate chinese CR4_NS1a_rep_69fa2a22:

    # MC "Ready?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:203
translate chinese CR4_NS1a_rep_8d19b83a:

    # Caroline "Uh huh."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:207
translate chinese CR4_NS1a_rep_84e09ab8:

    # Caroline "Ah!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:208
translate chinese CR4_NS1a_rep_4d7e8441:

    # MC "Ohh... Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:209
translate chinese CR4_NS1a_rep_376ad084:

    # MC "(The feeling of her pussy wrapped around my glans is amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:213
translate chinese CR4_NS1a_rep_a1be6637:

    # MC "Are you alright, ah... Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:214
translate chinese CR4_NS1a_rep_12dc1d57:

    # Caroline "Uh huh! Y-Yeah! Fuck me, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:215
translate chinese CR4_NS1a_rep_573aeacd:

    # Caroline "I want to feel you go ohh... balls-deep inside my tight little pussy!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:219
translate chinese CR4_NS1a_rep_281ddf39:

    # MC "Alright, as long as you’re sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:220
translate chinese CR4_NS1a_rep_91ba1b61:

    # Caroline "Mmm! I’m sure! Put it inside me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:221
translate chinese CR4_NS1a_rep_81e28f81:

    # MC "(Here goes nothing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:225
translate chinese CR4_NS1a_rep_3e40661b:

    # Caroline "OHHH GODDDD! YES!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:227
translate chinese CR4_NS1a_rep_ab7674e9:

    # MC "Hnnng! Ugh! Oh shit! That’s so good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:228
translate chinese CR4_NS1a_rep_a6b09409:

    # Caroline "Ah! Your cock is so ahh... thick!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:232
translate chinese CR4_NS1a_rep_16c70088:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:233
translate chinese CR4_NS1a_rep_576bc79f:

    # Caroline "No! Mmm! It feels really good right now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:234
translate chinese CR4_NS1a_rep_42057a49:

    # MC "Are you okay if I keep thrusting?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:235
translate chinese CR4_NS1a_rep_ec5a3228:

    # Caroline "Yes, please - and don’t stop!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:239
translate chinese CR4_NS1a_rep_dcb3a52e:

    # MC "Uh! Ah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:240
translate chinese CR4_NS1a_rep_31666053:

    # Caroline "Ohh! Mmm! Yes! Just like that!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:241
translate chinese CR4_NS1a_rep_c33c03dd:

    # MC "Ugh! Your pussy is so hot!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:245
translate chinese CR4_NS1a_rep_fd6ddc55:

    # Caroline "Ah! AHH! Fuck me! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:246
translate chinese CR4_NS1a_rep_361028b4:

    # Caroline "Fuck me harder, [player_name]! I’m going to cum!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:247
translate chinese CR4_NS1a_rep_c0e23921:

    # Caroline "AHHH! AHHHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:251
translate chinese CR4_NS1a_rep_edce70ef:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:252
translate chinese CR4_NS1a_rep_b5dd395e:

    # Caroline "(I’m cumming! Holy shit! I can’t control my body, right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:253
translate chinese CR4_NS1a_rep_374f76bb:

    # MC "(Her whole body is shaking like crazy, right now! I never realised she would climax, this quickly, from me fucking her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:257
translate chinese CR4_NS1a_rep_0796017b:

    # Caroline "MPPFFFFF!!!! MMMMMM!! AAAAHHMMMMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:259
translate chinese CR4_NS1a_rep_fda3b9ca:

    # MC "(She must have REALLY been looking forward to this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:260
translate chinese CR4_NS1a_rep_2cfeb5e3:

    # MC "(Her pussy is clamping down around my shaft! I’m not going to be able to last very long if she keeps cumming as intensely as this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:264
translate chinese CR4_NS1a_rep_c2b543cd:

    # Caroline "Mmm mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:265
translate chinese CR4_NS1a_rep_c599aac5:

    # Caroline "(Wow... It’s finally passing. That orgasm was amazing!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:266
translate chinese CR4_NS1a_rep_8448b3ac:

    # Caroline "(I hope he doesn’t stop though - if he keeps fucking me like this I might be able to cum multiple times!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:270
translate chinese CR4_NS1a_rep_a161433d:

    # MC "Hnnnng! Ugh! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:271
translate chinese CR4_NS1a_rep_4fe392f8:

    # Caroline "(Yes! Keep pounding me like that!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:272
translate chinese CR4_NS1a_rep_4ee65a4e:

    # Caroline "(His fat cock is making my entire body shake, each time he thrusts it inside me!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:276
translate chinese CR4_NS1a_rep_4f5e7e04:

    # Caroline "MMMMM!!! AHMMMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:278
translate chinese CR4_NS1a_rep_253b8129:

    # MC "(I can feel her fingers digging into the back of my head. She is really enjoying this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:279
translate chinese CR4_NS1a_rep_160a1c6b:

    # MC "(It must feel so intense for her, right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:283
translate chinese CR4_NS1a_rep_4c14c112:

    # MC "Mmm! Aaahmmmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:285
translate chinese CR4_NS1a_rep_f6a31822:

    # Caroline "Faster, [player_name]!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:287
translate chinese CR4_NS1a_rep_edce70ef_1:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:289
translate chinese CR4_NS1a_rep_75d8cda3:

    # Caroline "(This feels so good! I’d really like to change up positions a bit too, though.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:291
translate chinese CR4_NS1a_rep_4f5e7e04_1:

    # Caroline "MMMMM!!! AHMMMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:294
translate chinese CR4_NS1a_rep_1195c13d:

    # Caroline "This ahh... feels so good! Do you want to try ohh... doing it from behind?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:295
translate chinese CR4_NS1a_rep_e40ae654:

    # MC "Sure, why not?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:296
translate chinese CR4_NS1a_rep_b93dccf9:

    # Caroline "Okay, let me just swivel round."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:300
translate chinese CR4_NS1a_rep_7ad805ae:

    # MC "How do you want me to do it?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:301
translate chinese CR4_NS1a_rep_795da874:

    # Caroline "As fast and as hard as you possibly can. I love it when you go really rough."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:302
translate chinese CR4_NS1a_rep_9839e13a:

    # MC "I’ll try pounding you as hard as I can, then."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:306
translate chinese CR4_NS1a_rep_89e26a3c:

    # Caroline "Thanks. I’m looking forward to it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:307
translate chinese CR4_NS1a_rep_4f6893c9:

    # MC "(I wonder if she will let me cum inside her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:308
translate chinese CR4_NS1a_rep_993e287c:

    # MC "Can I finish inside you, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:312
translate chinese CR4_NS1a_rep_e8ce10ea:

    # Caroline "Umm... I’m not on any birth control right now... It’s probably not a great idea."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:313
translate chinese CR4_NS1a_rep_3c01d8a7:

    # MC "Ahh, that’s okay."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:314
translate chinese CR4_NS1a_rep_2ed5cc7f:

    # Caroline "Sorry..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:318
translate chinese CR4_NS1a_rep_8e8af02a:

    # Caroline "Oh! And make sure you screw the right hole!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:319
translate chinese CR4_NS1a_rep_63b28f7d:

    # Caroline "I might be horny right now, but I’m NOT in the mood for surprise anal!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:320
translate chinese CR4_NS1a_rep_45523c04:

    # MC "Haha, don’t worry - I wouldn’t do that to you, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:324
translate chinese CR4_NS1a_rep_599b6842:

    # Caroline "Thanks, [player_name]. I MIGHT let you fuck my ass in the future, but for tonight let’s keep it to the pussy."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:325
translate chinese CR4_NS1a_rep_f219acb6:

    # MC "No problem. I’ll make sure to fuck your pussy very roughly."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:329
translate chinese CR4_NS1a_rep_3264540b:

    # MC "(Her asscheeks are so soft! I could squeeze and play with these all day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:330
translate chinese CR4_NS1a_rep_98c29d17:

    # Caroline " Are you having fun there?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:331
translate chinese CR4_NS1a_rep_0d502e3a:

    # MC "Haha, sorry, I got distracted."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:335
translate chinese CR4_NS1a_rep_33a529dc:

    # MC "(Damn, it looks really sexy when I tug her swimsuit up, tight like that!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:336
translate chinese CR4_NS1a_rep_47c5ba7f:

    # Caroline "Pull it to the side and shove your cock inside me! I’m so fucking horny!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:340
translate chinese CR4_NS1a_rep_a64d02ae:

    # Caroline "Yes! Hurry up and fuck me, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:341
translate chinese CR4_NS1a_rep_b9d87c35:

    # MC "(Okay! Here we go!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:345
translate chinese CR4_NS1a_rep_7ccdfa6f:

    # "*RRRIIIIP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:346
translate chinese CR4_NS1a_rep_f57d5b3c:

    # MC "(Oh shit, I just ripped it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:347
translate chinese CR4_NS1a_rep_97920477:

    # Caroline "Mmm, that was really hot! I like it when you tear my clothes off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:351
translate chinese CR4_NS1a_rep_6632cc61:

    # MC "(Phew! I thought I was going to get in shit for ruining her bathing suit!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:352
translate chinese CR4_NS1a_rep_08614751:

    # Caroline "It feels so aggressive and domineering when you strip me naked. I really love that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:353
translate chinese CR4_NS1a_rep_8bed9a81:

    # MC "Well, in that case, I’ll make sure to pound you extra hard. Spread your legs a bit wider, and I’ll start."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:357
translate chinese CR4_NS1a_rep_145da06c:

    # Caroline "How’s this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:358
translate chinese CR4_NS1a_rep_ffeaaac5:

    # MC "Just a little bit wider, I want to make sure I can plough every single inch of my cock into your pussy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:359
translate chinese CR4_NS1a_rep_db9d1731:

    # Caroline "Mmm, I’m looking forward to this!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:363
translate chinese CR4_NS1a_rep_7b0ec0e9:

    # MC "That’s perfect. I hope you’re ready - because I’m about to destroy your pussy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:364
translate chinese CR4_NS1a_rep_5dc0efae:

    # Caroline "Ooh, yes please!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:368
translate chinese CR4_NS1a_rep_ba26d38c:

    # MC "(I wonder if she would mind me cumming inside her if she gets caught up in the heat of the moment?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:369
translate chinese CR4_NS1a_rep_ea3670f5:

    # MC "(Maybe she’ll get too horny to resist?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:370
translate chinese CR4_NS1a_rep_540e7da5:

    # MC "(I mean, there’s always the risk of pregnancy. But it feels SOOO much better, just shooting a hot load of baby batter deep into her unprotected cunt.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:374
translate chinese CR4_NS1a_rep_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:375
translate chinese CR4_NS1a_rep_47b594c5:

    # Caroline "(I can feel his dick at the entrance to my pussy!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:376
translate chinese CR4_NS1a_rep_60768891:

    # Caroline "(Oh God, my heart’s racing with excitement, right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:380
translate chinese CR4_NS1a_rep_d24bf861:

    # MC "Oh God! Mmm! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:381
translate chinese CR4_NS1a_rep_d2ee7ab9:

    # Caroline "Ohh... Right there!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:382
translate chinese CR4_NS1a_rep_1d8d436b:

    # Caroline "(His bare cock is slipping into my pussy! Damn, I REALLY should have brought condoms with me...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:386
translate chinese CR4_NS1a_rep_ce854b83:

    # MC "Ahh... Fuck, your pussy feels so good, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:387
translate chinese CR4_NS1a_rep_02737bc5:

    # Caroline "Mmm! Uh huh! Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:388
translate chinese CR4_NS1a_rep_717e8ec9:

    # Caroline "Fuck me really hard! Ah!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:392
translate chinese CR4_NS1a_rep_a614c71e:

    # MC "Oh, I will. By the time I’m finished, your legs will be too weak to stand."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:393
translate chinese CR4_NS1a_rep_2a1b0b54:

    # Caroline "Ahh... Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:397
translate chinese CR4_NS1a_rep_15db8ec9:

    # MC "Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:398
translate chinese CR4_NS1a_rep_ea05542d:

    # Caroline "AHHH! OH FUCK! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:399
translate chinese CR4_NS1a_rep_fee15f0d:

    # Caroline "J-Just like that! Ugh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:403
translate chinese CR4_NS1a_rep_87d837d4:

    # Caroline "I love it when you fuck ahh.. me rough and ohhh... hard like this! MMMM!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:404
translate chinese CR4_NS1a_rep_1932d5af:

    # MC "Arrgh! You’re so fucking tight!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:405
translate chinese CR4_NS1a_rep_c7572ea3:

    # Caroline "Ah! AHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:408
translate chinese CR4_NS1a_rep_2155bffb:

    # Caroline "Harder! Fuck me harder! Ohhhhh!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:409
translate chinese CR4_NS1a_rep_148d1d95:

    # MC "(Thankfully we’re far away from the house! Caroline is really loud right now! I’d hate [Linda_name] or [Bob_name] to hear us doing this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:410
translate chinese CR4_NS1a_rep_489d5bdc:

    # MC "(Okay, it’s time to wreck her pussy, like I promised!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:414
translate chinese CR4_NS1a_rep_11f53c8a:

    # Caroline "AYAAAAHHHHHHH!!! Holy ahhhh... shit! OHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:416
translate chinese CR4_NS1a_rep_887c96aa:

    # Caroline "Talk dirty to me! OHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:418
translate chinese CR4_NS1a_rep_e59b5844:

    # MC "Mmmm! Ahh! Ugh! Take my cock, you fucking slut!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:422
translate chinese CR4_NS1a_rep_f232f539:

    # MC "Fuck! I’m gonna cum soon! UGh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:423
translate chinese CR4_NS1a_rep_bb5a2d93:

    # MC "Hnng... Can I do it inside you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:424
translate chinese CR4_NS1a_rep_51fbeb05:

    # Caroline "I ahhh... ohhh! I don’t know... MMM!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:428
translate chinese CR4_NS1a_rep_ec4cb8fe:

    # MC "Hnnng! I’m about to cum! Inside or out?! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:430
translate chinese CR4_NS1a_rep_9a1d6a7e:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:432
translate chinese CR4_NS1a_rep_5709fc1e:

    # Caroline "(Shit! It’s too risky! I have to say outside - but it feels sooo fucking good right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:434
translate chinese CR4_NS1a_rep_9d78e7b8:

    # MC "Caroline?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:436
translate chinese CR4_NS1a_rep_2e150c2d:

    # MC "(She’s too lost in pleasure to make a decision - I’ll have to do it for her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:438
translate chinese CR4_NS1a_rep_c7572ea3_1:

    # Caroline "Ah! AHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:442
translate chinese CR4_NS1a_rep_d6b5136f:

    # MC "Fuck it! I’m cumming inside you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:446
translate chinese CR4_NS1a_rep_00016007:

    # Caroline "Oh God!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:447
translate chinese CR4_NS1a_rep_5700a7a8:

    # MC "Hnnnngggg!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:448
translate chinese CR4_NS1a_rep_be9334a4:

    # Caroline "AHHH! FILL ME UP, [player_name]! OHHH, FUCK!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:458
translate chinese CR4_NS1a_rep_ec4c3180:

    # Caroline "(I can feel his hot cum, blasting up against my cervix! Holy shit! This is incredible!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:465
translate chinese CR4_NS1a_rep_ea965d7a:

    # MC "(Fuck it! Cumming inside is too risky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:466
translate chinese CR4_NS1a_rep_a8839386:

    # MC "Hnnng! Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:476
translate chinese CR4_NS1a_rep_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:477
translate chinese CR4_NS1a_rep_e75a8159:

    # Caroline "(Thank God he pulled out... I don’t think I could have resisted otherwise...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:478
translate chinese CR4_NS1a_rep_772d1c92:

    # Caroline "(There’s probably still a tiny risk of me getting pregnant, but it’s much smaller than having him stuff me full of his semen.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:479
translate chinese CR4_NS1a_rep_5971d331:

    # MC "Ugh! Yes! Ahhh.... *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:487
translate chinese CR4_NS1_lake_con2_rep_4e1ebe13:

    # Caroline "That was... *Pant* amazing..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:488
translate chinese CR4_NS1_lake_con2_rep_677a9149:

    # MC "Y-Yeah, we *Pant* did good... Phew... I’m exhausted."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:489
translate chinese CR4_NS1_lake_con2_rep_64217f5c:

    # Caroline "Heh, me too..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:493
translate chinese CR4_NS1_lake_con2_rep_3e5f61ba:

    # MC "Sorry about damaging your swimsuit, Caroline. I’ll buy you a new one tomorrow."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:494
translate chinese CR4_NS1_lake_con2_rep_2f0848d9:

    # Caroline "Hehe, relax. It’s fine. I enjoyed it - it was... spontaneous."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:495
translate chinese CR4_NS1_lake_con2_rep_6c86f23f:

    # Caroline "Besides, it’s not like I’m going to have to run half-naked, back to our house. I’ve got a spare change of clothes behind the tree."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:499
translate chinese CR4_NS1_lake_con2_rep_ffc5cc31:

    # MC "Ahh, that’s good to hear. Although, seeing you try and sneak your way back to your bedroom with no clothes on, would be pretty fucking hot."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:500
translate chinese CR4_NS1_lake_con2_rep_d38057b9:

    # Caroline "You’ve got a REALLY dirty mind, you know that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:501
translate chinese CR4_NS1_lake_con2_rep_ad086509:

    # MC "Heh, I guess I do."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:502
translate chinese CR4_NS1_lake_con2_rep_1a58f0a7:

    # Caroline "[player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:503
translate chinese CR4_NS1_lake_con2_rep_dd7df583:

    # MC "Yeah?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:504
translate chinese CR4_NS1_lake_con2_rep_e92bbe60:

    # Caroline "I’m really glad we finally did this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:505
translate chinese CR4_NS1_lake_con2_rep_671e1b78:

    # MC "Me too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:506
translate chinese CR4_NS1_lake_con2_rep_439fa5f1:

    # Caroline "Remind me to show you a few tricks next time. I’ve got a few things I want to teach you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:507
translate chinese CR4_NS1_lake_con2_rep_b09a3568:

    # MC "Mmm, I’m looking forward to it. We should probably head back now, though. Before anyone notices us missing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:508
translate chinese CR4_NS1_lake_con2_rep_5ea4f63a:

    # Caroline "Good call. I’ll get dressed again now."
    Caroline ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:439
    old "Go balls-deep and fill Caroline with your potent, hot semen."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS1a_rep.rpy:439
    old "Pull out and blow your load over Caroline’s ass."
    new ""

