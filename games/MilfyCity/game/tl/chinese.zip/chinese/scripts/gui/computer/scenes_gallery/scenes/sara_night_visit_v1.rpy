﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:10
translate chinese sara_night_visit_v1_abd287a1:

    # Sara "..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:11
translate chinese sara_night_visit_v1_9ff988d7:

    # Sara "(I wonder if he’s definitely asleep.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:12
translate chinese sara_night_visit_v1_b9e173d1:

    # Sara "[player_name]? Are you awake?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:13
translate chinese sara_night_visit_v1_2d204a49:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:16
translate chinese sara_night_visit_v1_8a0e30e9:

    # Sara "(Okay, you can do this, Sara. Be brave!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:17
translate chinese sara_night_visit_v1_f4e84a75:

    # Sara "(You have to get this picture of his cock, for Lily.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:18
translate chinese sara_night_visit_v1_dcd9cf27:

    # Sara "(Then you can prove that you’re cool, and not just a nerdy virgin!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:21
translate chinese sara_night_visit_v1_e0bbdb0b:

    # Sara "(Hey, this is easier than I thought it would be! He’s only in his boxer shorts!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:22
translate chinese sara_night_visit_v1_04dca295:

    # Sara "(I just need to strip these off him, then start moving his cock until it gets, all stiff and hard...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:23
translate chinese sara_night_visit_v1_fd55ac23:

    # Sara "(...like that time in my bedroom, when he pressed it up against my belly.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:26
translate chinese sara_night_visit_v1_77fb772d:

    # Sara "(Wow... It always takes my breath away, each time I see it!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:27
translate chinese sara_night_visit_v1_b45590d9:

    # Sara "(It feels like there’s a hundred tiny butterflies in my belly right now!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:28
translate chinese sara_night_visit_v1_3f5aa6a2:

    # Sara "(I don’t think I even need to move his cock at all... it’s already quite stiff!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:31
translate chinese sara_night_visit_v1_254234d1:

    # Sara "(I’ll just take a quick picture of it, then sneak out of his bedroom.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:32
translate chinese sara_night_visit_v1_e20c911a:

    # Sara "([player_name] won’t even know I was in here! Haha! Prefect!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:33
translate chinese sara_night_visit_v1_85b8a1e4:

    # Sara "(On the other hand... maybe I could touch his cock, just a little bit...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:36
translate chinese sara_night_visit_v1_d9d5f159:

    # Sara "(Yeah, I should rub it a bit - just to get a better picture, of course.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:37
translate chinese sara_night_visit_v1_e317ff00:

    # Sara "(Wow... it’s getting so much bigger and harder!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:38
translate chinese sara_night_visit_v1_15a1eb0e:

    # Sara "(I wonder how long I should do this for?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:44
translate chinese sara_night_visit_v1_2bcec930:

    # MC "Boo!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:45
translate chinese sara_night_visit_v1_689da9c4:

    # Sara "EEEKKK!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:46
translate chinese sara_night_visit_v1_c409b2fa:

    # Sara "(AHHH! He woke up!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:49
translate chinese sara_night_visit_v1_350dc75b:

    # Sara "I- I- *Sniff* I’m s-so sorry!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:50
translate chinese sara_night_visit_v1_075b7b0d:

    # MC "What were you doing?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:51
translate chinese sara_night_visit_v1_f4559248:

    # Sara "I was... I was... *sob* t-trying to take a... picture..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:52
translate chinese sara_night_visit_v1_19249ffd:

    # MC "Don’t you already have one on your phone?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:55
translate chinese sara_night_visit_v1_91330c36:

    # Sara "I... wanted another..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:56
translate chinese sara_night_visit_v1_f4d4e06e:

    # Sara "Please forgive me. I’m sooo sorry! *Sob*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:58
translate chinese sara_night_visit_v1_39f8e28f:

    # Sara "I’ll- I’ll do anything! Just don’t tell Dad!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:61
translate chinese sara_night_visit_v1_02015110:

    # MC "Hey - relax. I won’t tell Dad."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:63
translate chinese sara_night_visit_v1_0dcea48b:

    # Sara "I’ll- I’ll do anything! Just don’t tell Landlord!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:66
translate chinese sara_night_visit_v1_f537fd6d:

    # MC "Hey - relax. I won’t tell Landlord."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:67
translate chinese sara_night_visit_v1_87bd0b39:

    # Sara "Th-Thank you. *Sniff* I’ll do anything for you."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:68
translate chinese sara_night_visit_v1_8dbf01a8:

    # Sara "O-Or to you!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:71
translate chinese sara_night_visit_v1_971d0c08:

    # MC "Come on into bed and sleep beside me tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:72
translate chinese sara_night_visit_v1_984d1307:

    # Sara "Th...that’s all?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:73
translate chinese sara_night_visit_v1_2de90f31:

    # MC "Yeah, climb in beside me. It’s warm under the covers."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:76
translate chinese sara_night_visit_v1_d01d807c:

    # Sara "Th...thank you... I’m so sorry. *Sniff*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:77
translate chinese sara_night_visit_v1_204e07d7:

    # MC "Hey - it’s alright. Dry your eyes. Try to breathe."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:78
translate chinese sara_night_visit_v1_39d6aa09:

    # MC "If you were THAT desperate for a picture of my junk, you could have just asked."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:81
translate chinese sara_night_visit_v1_8abc9110:

    # Sara "Hehe... You always make me laugh so easily..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:82
translate chinese sara_night_visit_v1_76a23dad:

    # MC "That’s better. Let’s get rid of those tears."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:83
translate chinese sara_night_visit_v1_fe6106c0:

    # MC "I’ll shuffle over here, so there’s room for you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:86
translate chinese sara_night_visit_v1_81a3db98:

    # Sara "Thanks, [player_name]..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:87
translate chinese sara_night_visit_v1_c4dc94fb:

    # MC "You still look a little stressed. Is everything alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:88
translate chinese sara_night_visit_v1_42e6c5dc:

    # Sara "Actually... I wanted to ask you something..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:93
translate chinese sara_night_visit_v1_a889ea1b:

    # Sara "D...Do you... like me?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:94
translate chinese sara_night_visit_v1_f4964229:

    # Sara "B-Because after everything that happened - with the videogames, Lily, you.. and me..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:95
translate chinese sara_night_visit_v1_8abe0961:

    # Sara "Y-you said.. I’m nice.. s-sexy..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:96
translate chinese sara_night_visit_v1_59ccb7d7:

    # Sara "I... I just need to know..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:101
translate chinese sara_night_visit_v1_4e7f78b1:

    # Sara "(Please say yes...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:102
translate chinese sara_night_visit_v1_1693b99d:

    # MC "Yes, Sara. I really like you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:104
translate chinese sara_night_visit_v1_f615a575:

    # MC "Honestly, I thought it would have been pretty obvious."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:105
translate chinese sara_night_visit_v1_78d374f4:

    # Sara "(Oh, my God!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:110
translate chinese sara_night_visit_v1_554dca11:

    # Sara "I- I- I can’t believe I just asked you that. G-Go back to sleep."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:111
translate chinese sara_night_visit_v1_fe9284ca:

    # Sara "Forget what I just said!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:113
translate chinese sara_night_visit_v1_58732214:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?! And he’s your brother!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:115
translate chinese sara_night_visit_v1_82c1da2a:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:116
translate chinese sara_night_visit_v1_928adda7:

    # MC "(Huh?! Women are strange...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:125
translate chinese sara_night_visit_v1_dc741cc8:

    # Sara "Because I think I like you... more than a brother..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:127
translate chinese sara_night_visit_v1_fdec6962:

    # Sara "Because I think I like you... more than a friend..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:128
translate chinese sara_night_visit_v1_2d204a49_1:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:129
translate chinese sara_night_visit_v1_4e7f78b1_1:

    # Sara "(Please say yes...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:130
translate chinese sara_night_visit_v1_2d204a49_2:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:131
translate chinese sara_night_visit_v1_54152fe9:

    # Sara "(Please, [player_name]... say anything...)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:132
translate chinese sara_night_visit_v1_2d204a49_3:

    # MC "..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:136
translate chinese sara_night_visit_v1_13ca058f:

    # Sara "N-Nevermind! I- Forget I asked you about it!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:138
translate chinese sara_night_visit_v1_58732214_1:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?! And he’s your brother!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:140
translate chinese sara_night_visit_v1_82c1da2a_1:

    # Sara "(Stupid, Sara! How could he ever love a nerdy virgin like you?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:141
translate chinese sara_night_visit_v1_e7bf0527:

    # Sara "(You shouldn’t have put him in that position! You could ruin your relationship with him!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:142
translate chinese sara_night_visit_v1_71418457:

    # MC "Are you okay, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:143
translate chinese sara_night_visit_v1_e6b63ba6:

    # Sara "J-Just go to sleep, you b-big dumbo!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:151
translate chinese after_mc_sara_night_scene1_v1_choice1r_01d1f46d:

    # MC "*YAWN!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:152
translate chinese after_mc_sara_night_scene1_v1_choice1r_037ecab5:

    # MC "(Looks like Sara left during the night. I wonder when she snuck out. I’ll probably see her around college today anyway.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:153
translate chinese after_mc_sara_night_scene1_v1_choice1r_813b79bf:

    # MC "(I’ve never seen her that emotional before.)"
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:98
    old "Yes, Sara. I really like you."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/sara_night_visit_v1.rpy:98
    old "Stay silent."
    new ""

