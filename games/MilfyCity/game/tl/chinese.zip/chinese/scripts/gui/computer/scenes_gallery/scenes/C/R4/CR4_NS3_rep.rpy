﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:8
translate chinese CR4_NS3_rep_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:9
translate chinese CR4_NS3_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:10
translate chinese CR4_NS3_rep_b6e665ab:

    # Caroline "*Whispered* Take your time and think about it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:13
translate chinese CR4_NS3_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:15
translate chinese CR4_NS3_rep_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:18
translate chinese CR4_NS3_rep_f4ba85cf:

    # MC "Let’s try doggy style tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:19
translate chinese CR4_NS3_rep_c80575a5:

    # Caroline "Okay, let me get up on the bed."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:22
translate chinese CR4_NS3_rep_215a7ac4:

    # Caroline "How’s that? Is my ass high enough?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:23
translate chinese CR4_NS3_rep_cff20e98:

    # MC "Perfect height. I’ll be able to fuck you, no problem."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:26
translate chinese CR4_NS3_rep_ebdadda1:

    # Caroline "So, which hole do you want to fuck tonight? My pussy? Or my ass?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:27
translate chinese CR4_NS3_rep_0d8931f6:

    # MC "Will we need lube for your ass?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:28
translate chinese CR4_NS3_rep_524fdbfa:

    # Caroline "I’m way ahead of you there - I’ve already applied some. So you should be able to slip your cock right in."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:31
translate chinese CR4_NS3_rep_9f9a5550:

    # MC "It’s a tough decision... but I think I’m gonna fuck your..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:36
translate chinese CR4_NS3_rep_db64895a:

    # MC "...pussy tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:37
translate chinese CR4_NS3_rep_0cd9a67c:

    # Caroline "Mmm, I like the sound of that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:40
translate chinese CR4_NS3_rep_0acd861d:

    # Caroline "Ahh... Fuck... Put it in, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:41
translate chinese CR4_NS3_rep_4cb54052:

    # MC "Mmm, I am... Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:44
translate chinese CR4_NS3_rep_357446ea:

    # Caroline "Oh God... Mmm! You’re so thick!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:45
translate chinese CR4_NS3_rep_dcb94e5a:

    # MC "Ah... I’m gonna fuck you so hard now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:48
translate chinese CR4_NS3_rep_efe990dd:

    # Caroline "Mmm! Yes, please! Fuck me hard, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:49
translate chinese CR4_NS3_rep_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:50
translate chinese CR4_NS3_rep_8b3d3c7c:

    # Caroline "Oh! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:53
translate chinese CR4_NS3_rep_916b78c3:

    # Caroline "Ahh! Yes! YES! Ohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:54
translate chinese CR4_NS3_rep_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:55
translate chinese CR4_NS3_rep_26c4aed2:

    # Caroline "Harder! Harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:58
translate chinese CR4_NS3_rep_2341697f:

    # MC "How’s that, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:59
translate chinese CR4_NS3_rep_bb9e6e25:

    # Caroline "Mmm! Yes! It’s so good, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:61
translate chinese CR4_NS3_rep_8260bd1f:

    # MC "Ahh... Hnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:64
translate chinese CR4_NS3_rep_afb590ba:

    # Caroline "Ah! Harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:65
translate chinese CR4_NS3_rep_a504ab55:

    # MC "I can’t go any harder!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:66
translate chinese CR4_NS3_rep_5117ca27:

    # Caroline "Then just ahh... spank me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:69
translate chinese CR4_NS3_rep_f82c4b5b:

    # MC "Ugh! A-Are you sure?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:70
translate chinese CR4_NS3_rep_006b864a:

    # Caroline "YES! Spank me hard, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:73
translate chinese CR4_NS3_rep_cf2e2c2d:

    # MC "(I hope she’s sure about what she’s asking me to do right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:74
translate chinese CR4_NS3_rep_baf18882:

    # Caroline "Ahh ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:75
translate chinese CR4_NS3_rep_d5d521f6:

    # MC "*Gulp* (Here goes nothing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:79
translate chinese CR4_NS3_rep_4875f5be:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:80
translate chinese CR4_NS3_rep_9a1d6a7e:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:81
translate chinese CR4_NS3_rep_3225a933:

    # MC "Sorr-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:82
translate chinese CR4_NS3_rep_439aba68:

    # Caroline "AGAIN! More!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:85
translate chinese CR4_NS3_rep_4875f5be_1:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:88
translate chinese CR4_NS3_rep_078482b1:

    # Caroline "MMMM! Yesss.... Spank me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:89
translate chinese CR4_NS3_rep_c601269a:

    # Caroline "I’m been such a bad girl, spank me harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:90
translate chinese CR4_NS3_rep_9e0f3e29:

    # MC "(Huh, I never guessed Caroline would have been into this kind of thing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:94
translate chinese CR4_NS3_rep_4875f5be_2:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:95
translate chinese CR4_NS3_rep_1aa93675:

    # Caroline "Eek!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:98
translate chinese CR4_NS3_rep_4875f5be_3:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:99
translate chinese CR4_NS3_rep_5a30efe2:

    # Caroline "Ohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:102
translate chinese CR4_NS3_rep_4875f5be_4:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:104
translate chinese CR4_NS3_rep_53701a34:

    # Caroline "Ahhhh! Fuck! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:107
translate chinese CR4_NS3_rep_7ed4fb4e:

    # Caroline "Don’t *gasp* stop fucking *gasp* me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:110
translate chinese CR4_NS3_rep_4875f5be_5:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:111
translate chinese CR4_NS3_rep_ca43676c:

    # Caroline "AHHH! I’m cumming! AYAAAHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:115
translate chinese CR4_NS3_rep_4875f5be_6:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:116
translate chinese CR4_NS3_rep_299bbbdf:

    # Caroline "AHHH! YES! I’m cummmmmmiiinnng!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:117
translate chinese CR4_NS3_rep_2d9840d5_1:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:120
translate chinese CR4_NS3_rep_2313ccf5:

    # Caroline "P-Pull my hair too!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:121
translate chinese CR4_NS3_rep_3f1e201e:

    # MC "Are you-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:122
translate chinese CR4_NS3_rep_5dc9ba3e:

    # Caroline "Please! Just do it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:125
translate chinese CR4_NS3_rep_2422b2e2:

    # Caroline "AHHH! OHHH FUCK! YES!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:126
translate chinese CR4_NS3_rep_3dcb7635:

    # MC "(Holy shit, I never knew she was into rough sex like this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:128
translate chinese CR4_NS3_rep_814af415:

    # Caroline "Ah! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:131
translate chinese CR4_NS3_rep_686d4459:

    # MC "Hnnnggg! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:132
translate chinese CR4_NS3_rep_2bf6842c:

    # MC "Take my cock, you stupid slut!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:133
translate chinese CR4_NS3_rep_f2b8c2c4:

    # Caroline "Oh fuck! Yes! Talk dirty to me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:136
translate chinese CR4_NS3_rep_1d63bea3:

    # MC "UGH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:137
translate chinese CR4_NS3_rep_9a1d6a7e_1:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:139
translate chinese CR4_NS3_rep_9ca36bd4:

    # MC "I’m going to destroy your pussy right now!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:142
translate chinese CR4_NS3_rep_19feb73f:

    # Caroline "Ohhh! Oh, my God! *GASP* Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:144
translate chinese CR4_NS3_rep_a8cfe4a7:

    # Caroline "Destroy my slutty little pussy! YES! Ahhhhhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:145
translate chinese CR4_NS3_rep_6f91780c:

    # Caroline "I’m cummmmmiiing! I’m cumming again! AHHH"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:148
translate chinese CR4_NS3_rep_c6d907b8:

    # MC "Hnnnggg... I’m cumming too! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:149
translate chinese CR4_NS3_rep_9a3f195b:

    # Caroline "Yes! Cum inside me, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:152
translate chinese CR4_NS3_rep_5cbd1a10:

    # Caroline "AHHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:154
translate chinese CR4_NS3_rep_2b40314c:

    # MC "Faster! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:156
translate chinese CR4_NS3_rep_9a1d6a7e_2:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:161
translate chinese CR4_NS3_rep_936e314d:

    # MC "I’m cumming inside you, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:162
translate chinese CR4_NS3_rep_7d521558:

    # MC "I’m gonna fill you up!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:163
translate chinese CR4_NS3_rep_eac920c9:

    # Caroline "AAAYAAAHHHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:166
translate chinese CR4_NS3_rep_c8e7efd3:

    # MC "Hnnnnnnggg! Ugh! Ahhh! Ohhh fuck! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:178
translate chinese CR4_NS3_rep_13477376:

    # Caroline "*Pant* Oh W-wow... That was... fucking amazing. *Gasp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:180
translate chinese CR4_NS3_rep_b32b827c:

    # MC "Sorry, Caroline. I hope I didn’t go too hard, there with the slapping and hair pulling."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:182
translate chinese CR4_NS3_rep_474f8af3:

    # Caroline "N-No... it was *pant* perfect... You’re the best brother, I could ever ask for..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:184
translate chinese CR4_NS3_rep_0c71be68:

    # Caroline "N-No... it was *pant* perfect... You’re the best boyfriend, I could ever ask for..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:195
translate chinese CR4_NS3_rep_c43827f1:

    # MC "Hnnngg... I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:196
translate chinese CR4_NS3_rep_9acc449d:

    # MC "(I better play it safe, and pull out. No sense in cumming inside her without a condom on!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:197
translate chinese CR4_NS3_rep_44d86a11:

    # Caroline "Ah ahhh! Ohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:200
translate chinese CR4_NS3_rep_e343e5af:

    # MC "Hnnnggg! Ugh! Ahh"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:210
translate chinese CR4_NS3_rep_e6ca5d23:

    # Caroline "Ohh... *Pant* *Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:212
translate chinese CR4_NS3_rep_28212750:

    # MC "Fuck... That was incredible."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:213
translate chinese CR4_NS3_rep_d2a8a825:

    # Caroline "Y-Yeah, that was *pant* fucking amazing... You were great!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:220
translate chinese CR4_NS3_rep_579aa9bf:

    # MC "...tight little asshole tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:221
translate chinese CR4_NS3_rep_b2e394c3:

    # Caroline "A-Are you sure?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:224
translate chinese CR4_NS3_rep_743afdcc:

    # MC "It’ll be fine. I’ll go slow at first."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:225
translate chinese CR4_NS3_rep_dce15a12:

    # Caroline "*Gulp* O-Okay..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:226
translate chinese CR4_NS3_rep_d0eb59b9:

    # MC "Mmm... Oh fuck...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:229
translate chinese CR4_NS3_rep_f4ca41e8:

    # Caroline "Holy shit! Ahh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:230
translate chinese CR4_NS3_rep_16c70088:

    # MC "I’m not hurting you, am I?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:231
translate chinese CR4_NS3_rep_4fda47a1:

    # Caroline "N-No, you’re just really ohh... thick!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:234
translate chinese CR4_NS3_rep_93e81e75:

    # MC "Damn, your asshole is really fucking tight, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:235
translate chinese CR4_NS3_rep_03a171e7:

    # Caroline "Ahh... I’ll take that as a compliment, I guess! Haha!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:236
translate chinese CR4_NS3_rep_890d50aa:

    # MC "Ugh! Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:237
translate chinese CR4_NS3_rep_8b3d3c7c_1:

    # Caroline "Oh! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:240
translate chinese CR4_NS3_rep_fa176c3c:

    # Caroline "Ahh! Yes! Mmm! Fuck me..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:241
translate chinese CR4_NS3_rep_06f44a62:

    # MC "(It sounds like she’s enjoying anal more now! I just had to get her over the initial shock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:242
translate chinese CR4_NS3_rep_2d9840d5_2:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:243
translate chinese CR4_NS3_rep_26c4aed2_1:

    # Caroline "Harder! Harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:246
translate chinese CR4_NS3_rep_2341697f_1:

    # MC "How’s that, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:248
translate chinese CR4_NS3_rep_783ddcd8:

    # Caroline "Mmm! Yes! Don’t stop!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:249
translate chinese CR4_NS3_rep_d5478f05:

    # Caroline "Oh fuck! It’s so good, [player_name]! Keep pounding my ass with your massive cock!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:250
translate chinese CR4_NS3_rep_8260bd1f_1:

    # MC "Ahh... Hnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:253
translate chinese CR4_NS3_rep_724937b8:

    # Caroline "Faster, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:254
translate chinese CR4_NS3_rep_4d210704:

    # MC "I can’t go any faster!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:255
translate chinese CR4_NS3_rep_038eab02:

    # Caroline "Then just ahh... spank me while you fuck my ass!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:258
translate chinese CR4_NS3_rep_f82c4b5b_1:

    # MC "Ugh! A-Are you sure?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:259
translate chinese CR4_NS3_rep_006b864a_1:

    # Caroline "YES! Spank me hard, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:260
translate chinese CR4_NS3_rep_e5644f3a:

    # Caroline "Spank me so hard, you feel the vibrations while you’re fucking my butt!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:263
translate chinese CR4_NS3_rep_cf2e2c2d_1:

    # MC "(I hope she’s sure about what she’s asking me to do right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:264
translate chinese CR4_NS3_rep_baf18882_1:

    # Caroline "Ahh ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:265
translate chinese CR4_NS3_rep_d5d521f6_1:

    # MC "*Gulp* (Here goes nothing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:270
translate chinese CR4_NS3_rep_4875f5be_7:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:271
translate chinese CR4_NS3_rep_9a1d6a7e_3:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:272
translate chinese CR4_NS3_rep_3225a933_1:

    # MC "Sorr-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:273
translate chinese CR4_NS3_rep_72509c8a:

    # Caroline "AGAIN! More! HARDER!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:276
translate chinese CR4_NS3_rep_4875f5be_8:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:279
translate chinese CR4_NS3_rep_078482b1_1:

    # Caroline "MMMM! Yesss.... Spank me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:280
translate chinese CR4_NS3_rep_f9550138:

    # Caroline "I’m a naughty little slut! Punish me! Spank me harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:281
translate chinese CR4_NS3_rep_9e0f3e29_1:

    # MC "(Huh, I never guessed Caroline would have been into this kind of thing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:285
translate chinese CR4_NS3_rep_4875f5be_9:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:286
translate chinese CR4_NS3_rep_1aa93675_1:

    # Caroline "Eek!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:289
translate chinese CR4_NS3_rep_4875f5be_10:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:290
translate chinese CR4_NS3_rep_5a30efe2_1:

    # Caroline "Ohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:293
translate chinese CR4_NS3_rep_4875f5be_11:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:295
translate chinese CR4_NS3_rep_53701a34_1:

    # Caroline "Ahhhh! Fuck! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:298
translate chinese CR4_NS3_rep_6c4e0b2a:

    # Caroline "Don’t *gasp* stop fucking *gasp* my *GASP* ass!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:301
translate chinese CR4_NS3_rep_4875f5be_12:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:302
translate chinese CR4_NS3_rep_ca43676c_1:

    # Caroline "AHHH! I’m cumming! AYAAAHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:306
translate chinese CR4_NS3_rep_4875f5be_13:

    # "*SLAP*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:307
translate chinese CR4_NS3_rep_299bbbdf_1:

    # Caroline "AHHH! YES! I’m cummmmmmiiinnng!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:308
translate chinese CR4_NS3_rep_2d9840d5_3:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:311
translate chinese CR4_NS3_rep_2313ccf5_1:

    # Caroline "P-Pull my hair too!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:312
translate chinese CR4_NS3_rep_3f1e201e_1:

    # MC "Are you-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:313
translate chinese CR4_NS3_rep_5dc9ba3e_1:

    # Caroline "Please! Just do it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:316
translate chinese CR4_NS3_rep_2422b2e2_1:

    # Caroline "AHHH! OHHH FUCK! YES!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:317
translate chinese CR4_NS3_rep_3dcb7635_1:

    # MC "(Holy shit, I never knew she was into rough sex like this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:319
translate chinese CR4_NS3_rep_814af415_1:

    # Caroline "Ah! AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:322
translate chinese CR4_NS3_rep_686d4459_1:

    # MC "Hnnnggg! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:323
translate chinese CR4_NS3_rep_2bf6842c_1:

    # MC "Take my cock, you stupid slut!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:324
translate chinese CR4_NS3_rep_f2b8c2c4_1:

    # Caroline "Oh fuck! Yes! Talk dirty to me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:327
translate chinese CR4_NS3_rep_1d63bea3_1:

    # MC "UGH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:328
translate chinese CR4_NS3_rep_9a1d6a7e_4:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:330
translate chinese CR4_NS3_rep_2759f0b8:

    # MC "I’m going to destroy this tight asshole of yours. I’m gonna fuck you so hard and pump all my cum, deep inside you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:333
translate chinese CR4_NS3_rep_19feb73f_1:

    # Caroline "Ohhh! Oh, my God! *GASP* Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:335
translate chinese CR4_NS3_rep_80012427:

    # Caroline "Fuck my ass! Fuck my silly! YES! Ahhhhhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:336
translate chinese CR4_NS3_rep_68140395:

    # Caroline "I’m cummmmmiiing! I’m cumming again! AHHH "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:339
translate chinese CR4_NS3_rep_c6d907b8_1:

    # MC "Hnnnggg... I’m cumming too! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:340
translate chinese CR4_NS3_rep_19509a20:

    # Caroline "Yes! Cum inside me, [player_name]! Fill my ass!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:343
translate chinese CR4_NS3_rep_5cbd1a10_1:

    # Caroline "AHHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:345
translate chinese CR4_NS3_rep_2b40314c_1:

    # MC "Faster! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:347
translate chinese CR4_NS3_rep_9a1d6a7e_5:

    # Caroline "AHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:352
translate chinese CR4_NS3_rep_936e314d_1:

    # MC "I’m cumming inside you, Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:353
translate chinese CR4_NS3_rep_7d521558_1:

    # MC "I’m gonna fill you up!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:356
translate chinese CR4_NS3_rep_eac920c9_1:

    # Caroline "AAAYAAAHHHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:357
translate chinese CR4_NS3_rep_3cf5d2cd:

    # Caroline "FUCKING FILL ME UP! OHHH! YESSS!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:360
translate chinese CR4_NS3_rep_c8e7efd3_1:

    # MC "Hnnnnnnggg! Ugh! Ahhh! Ohhh fuck! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:370
translate chinese CR4_NS3_rep_13477376_1:

    # Caroline "*Pant* Oh W-wow... That was... fucking amazing. *Gasp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:373
translate chinese CR4_NS3_rep_30da628e:

    # MC "How’s your ass, after all that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:374
translate chinese CR4_NS3_rep_020a3934:

    # Caroline "*Pant* A little bit sensitive... but it was *Pant* really fucking intense... I loved it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:385
translate chinese CR4_NS3_rep_c43827f1_1:

    # MC "Hnnngg... I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:386
translate chinese CR4_NS3_rep_44d86a11_1:

    # Caroline "Ah ahhh! Ohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:390
translate chinese CR4_NS3_rep_e343e5af_1:

    # MC "Hnnnggg! Ugh! Ahh"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:400
translate chinese CR4_NS3_rep_e6ca5d23_1:

    # Caroline "Ohh... *Pant* *Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:401
translate chinese CR4_NS3_rep_28212750_1:

    # MC "Fuck... That was incredible."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:403
translate chinese CR4_NS3_rep_d2a8a825_1:

    # Caroline "Y-Yeah, that was *pant* fucking amazing... You were great!"
    Caroline ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:33
    old "Pussy"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:33
    old "Ass"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:158
    old "Blow your load inside her."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:158
    old "Pull out and cum on her back."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3_rep.rpy:349
    old "Blow your load deep inside her bowels."
    new ""

