﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:7
translate chinese ml_work_hj_v1_db7178b5:

    # Mom "Say - would you fancy sitting on the couch with me for a while?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:8
translate chinese ml_work_hj_v1_690b7417:

    # MC "Sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:11
translate chinese ml_work_hj_v1_32803f1c:

    # MC "(She just sat down on my knee! I didn’t expect that!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:12
translate chinese ml_work_hj_v1_da697af7:

    # Mom "You’ve got beautiful eyes, [player_name]. You know that?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:14
translate chinese ml_work_hj_v1_d3a1fb2c:

    # MC "Gee... Thanks, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:16
translate chinese ml_work_hj_v1_be7a833b:

    # MC "Gee... Thanks, Linda."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:17
translate chinese ml_work_hj_v1_209d2f53:

    # Mom "You really do. I could gaze into them for hours."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:20
translate chinese ml_work_hj_v1_cd6c2ad2:

    # MC "(Gulp!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:21
translate chinese ml_work_hj_v1_1a8acdca:

    # Mom "You look a little nervous."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:22
translate chinese ml_work_hj_v1_21c3ae9e:

    # Mom "You shouldn’t be. I promise, you’re in very safe hands right now."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:23
translate chinese ml_work_hj_v1_28b9dbae:

    # Mom "Try relaxing. Put your hand on my thigh."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:28
translate chinese ml_work_hj_v1_1200e789:

    # Mom "That’s it. See?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:29
translate chinese ml_work_hj_v1_f77bfdbf:

    # Mom "I can hear your heart pounding from here."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:30
translate chinese ml_work_hj_v1_9c05bbe6:

    # Mom "Just try to breathe, and close your eyes."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:31
translate chinese ml_work_hj_v1_16e681a5:

    # Mom "I promise you’ll enjoy this."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:34
translate chinese ml_work_hj_v1_6bdc411f:

    # MC "(Oh, my God... It's really happening. She's not worried about my reaction anymore!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:35
translate chinese ml_work_hj_v1_60e3ab04:

    # MC "(How far is she going to take this, today? Just a kiss?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:38
translate chinese ml_work_hj_v1_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:40
translate chinese ml_work_hj_v1_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:42
translate chinese ml_work_hj_v1_027778ee:

    # MC "(Wow! She’s an amazing kisser!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:45
translate chinese ml_work_hj_v1_7d823958:

    # Mom "(God... This is even better than I dreamt it would be.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:46
translate chinese ml_work_hj_v1_dce8e9d6:

    # Mom "(I wish I could just freeze this moment, and stay right here forever.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:48
translate chinese ml_work_hj_v1_cc3052f1:

    # MC "(Mom must be getting nervous too - I can hear her heart beating, even louder than mine!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:50
translate chinese ml_work_hj_v1_25aa3944:

    # MC "(Linda must be getting nervous too - I can hear her heart beating, even louder than mine!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:53
translate chinese ml_work_hj_v1_6b055a44:

    # Mom "Lie down on the couch beside me. I want to do something for you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:54
translate chinese ml_work_hj_v1_a26b746f:

    # MC "D-Do something? Like what?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:56
translate chinese ml_work_hj_v1_c778e5bf:

    # Mom "Hush... Just you lie back and relax. Mommy will take care of everything."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:58
translate chinese ml_work_hj_v1_cbd6e3e7:

    # Mom "Hush... Just you lie back and relax. Linda will take care of everything."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:61
translate chinese ml_work_hj_v1_b9cdcbf0:

    # MC "Ooohh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:62
translate chinese ml_work_hj_v1_916e8450:

    # MC "(Holy shit... I can feel her fingers, wrapping around my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:63
translate chinese ml_work_hj_v1_c02f54a5:

    # MC "(She’s massaging it now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:67
translate chinese ml_work_hj_v1_19cd253d:

    # MC "M-Mom! Y-You-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:69
translate chinese ml_work_hj_v1_368ef663:

    # MC "L-Linda. Y-You-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:70
translate chinese ml_work_hj_v1_0786b850:

    # Mom "Shush... I see you’ve got a hard problem, down here."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:72
translate chinese ml_work_hj_v1_4c5cb1d5:

    # Mom "Let Mother help you sort it out."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:74
translate chinese ml_work_hj_v1_2166ad4b:

    # Mom "Let friend help you sort it out."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:77
translate chinese ml_work_hj_v1_a6a61779:

    # Mom "(Mmm... It’s so big!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:78
translate chinese ml_work_hj_v1_5bba6f95:

    # Mom "(I’d love to feel this monster inside me. Filling up my pussy!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:79
translate chinese ml_work_hj_v1_2133155c:

    # Mom "(God, I’m getting wet at the mere thought of it!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:82
translate chinese ml_work_hj_v1_d79de929:

    # Mom "Does it feel good when I circle my fingers around, this little bit at the top?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:83
translate chinese ml_work_hj_v1_86e7e604:

    # MC "Ah... yes..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:84
translate chinese ml_work_hj_v1_69bd06ca:

    # Mom "I’ll tell you why it’s so sensitive."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:87
translate chinese ml_work_hj_v1_12a585b5:

    # Mom "It’s called the frenulum - and it’s a sensitive little cluster of nerves."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:89
translate chinese ml_work_hj_v1_03e4e3d7:

    # Mom "A secret trick of mine, back in school, was to rapidly flick my tongue back and forth across it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:91
translate chinese ml_work_hj_v1_263f4e22:

    # Mom "A secret trick of mine, back in the college, was to rapidly flick my tongue back and forth across it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:92
translate chinese ml_work_hj_v1_24fb8e8f:

    # Mom "No guy could last thirty seconds, when getting one of MY blowjobs."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:95
translate chinese ml_work_hj_v1_4d82224b:

    # Mom "But enough foreplay - let’s get down to business."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:96
translate chinese ml_work_hj_v1_16df264f:

    # MC "Ah! Ahh... Oohhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:98
translate chinese ml_work_hj_v1_7c55b7b3:

    # Mom "Mmm... sounds like my boy’s enjoying this."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:100
translate chinese ml_work_hj_v1_554dcc6e:

    # Mom "Mmm... sounds like my toyboy is enjoying it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:103
translate chinese ml_work_hj_v1_c4560fd2:

    # MC "Oooh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:106
translate chinese ml_work_hj_v1_fb442bfb:

    # MC "(Oh, my God! I never imagined, Mom would be this kinky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:108
translate chinese ml_work_hj_v1_76eb0966:

    # MC "(Oh, my God! I never imagined, Linda would be this kinky!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:109
translate chinese ml_work_hj_v1_82c8a240:

    # Mom "(Haha! I felt him shudder as I licked him. He’ll be cumming for me, in no time.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:112
translate chinese ml_work_hj_v1_c5a2b9b4:

    # Mom "Up and down..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:113
translate chinese ml_work_hj_v1_06858200:

    # Mom "Up... and down."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:114
translate chinese ml_work_hj_v1_89bebdd0:

    # Mom "I hope you’re enjoying this as much as I am."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:117
translate chinese ml_work_hj_v1_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:119
translate chinese ml_work_hj_v1_90eac278:

    # Mom "Are you close?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:120
translate chinese ml_work_hj_v1_b36f4d3c:

    # Mom "I want you to cum for me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:123
translate chinese ml_work_hj_v1_d40031e0:

    # MC "Mmm! MMMMM!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:124
translate chinese ml_work_hj_v1_1a042b58:

    # MC "(Fuck! I’m gonna cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:126
translate chinese ml_work_hj_v1_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:127
translate chinese ml_work_hj_v1_31ea9460:

    # Mom "(I can feel his cock, twitching and throbbing in my hand. My boy’s about to blow his load!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:131
translate chinese ml_work_hj_v1_f2b708c3:

    # Mom "That’s it! Cum for Mommy! Good boy!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:133
translate chinese ml_work_hj_v1_2a66def9:

    # Mom "That’s it! Cum for me! Good boy!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:134
translate chinese ml_work_hj_v1_985618ca:

    # MC "Ahh! Ooooh! Ahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:142
translate chinese ml_work_hj_v1_d9e63502:

    # Mom "Wow... That’s a lot of cum! You’re lucky you had me around, to relieve you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:145
translate chinese ml_work_hj_v1_d921489c:

    # Mom "Is that you all finished? Or should I keep going?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:146
translate chinese ml_work_hj_v1_fddfcb19:

    # MC "N-No, I’m... I’m done..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:147
translate chinese ml_work_hj_v1_9613af35:

    # Mom "So, how was it? Did you enjoy it?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:151
translate chinese ml_work_hj_v1_509fb13a:

    # MC "It was amazing, Mom! Thank you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:153
translate chinese ml_work_hj_v1_12889189:

    # MC "It was amazing, Linda! Thank you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:154
translate chinese ml_work_hj_v1_4ccf0242:

    # Mom "I’m very happy to hear that."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:155
translate chinese ml_work_hj_v1_165471c6:

    # Mom "You make SUCH a cute face when you cum!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:157
translate chinese ml_work_hj_v1_2d4e7d96:

    # MC "MOM!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:158
translate chinese ml_work_hj_v1_43e822d8:

    # Mom "Haha! I better get back to work. I’ll see you, later this evening."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:159
translate chinese ml_work_hj_v1_f3ce303b:

    # MC "See ya, Mom. Thanks again."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:161
translate chinese ml_work_hj_v1_fa3a6335:

    # MC "Linda!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:162
translate chinese ml_work_hj_v1_43e822d8_1:

    # Mom "Haha! I better get back to work. I’ll see you, later this evening."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/ml_work_hj_v1.rpy:163
translate chinese ml_work_hj_v1_78797b54:

    # MC "See ya, Linda. Thanks again."
    MC ""

