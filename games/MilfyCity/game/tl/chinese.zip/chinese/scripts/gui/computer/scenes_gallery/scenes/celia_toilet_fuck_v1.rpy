﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:9
translate chinese celia_toilet_fuck_v1_6725fff9:

    # Celia "I’m giving you a choice today. You can either... fuck me in the ass, or... I can suck your cock."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:10
translate chinese celia_toilet_fuck_v1_5879610b:

    # MC "Wh-What? Really?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:11
translate chinese celia_toilet_fuck_v1_86a25b14:

    # Celia "(Sigh. This is the lowest point of my career in teaching.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:12
translate chinese celia_toilet_fuck_v1_0c9d102c:

    # Celia "Really."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:18
translate chinese celia_toilet_fuck_v1_f75a24fb:

    # Celia "Fine. But this is the one and only time this will ever happen."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:19
translate chinese celia_toilet_fuck_v1_2da4174e:

    # MC "You’re acting really strange..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:20
translate chinese celia_toilet_fuck_v1_cfd2e220:

    # Celia "Just... stop talking."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:23
translate chinese celia_toilet_fuck_v1_3c534b81:

    # Celia "(I can feel his cock through his jeans. He’s already hard!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:24
translate chinese celia_toilet_fuck_v1_bf505998:

    # Celia "(Okay, I just need to pull them down a little bit, and take this slowly.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:25
translate chinese celia_toilet_fuck_v1_ce2625ae:

    # Celia "([player_name] won’t last too long. He’ll probably cum, as soon as I lick the tip!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:28
translate chinese celia_toilet_fuck_v1_4b5ba5ff:

    # Celia "Oh wow... (He’s bigger than my husband!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:29
translate chinese celia_toilet_fuck_v1_e64c5579:

    # MC "Is everything alright, Ms. Celia?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:30
translate chinese celia_toilet_fuck_v1_aa281f0e:

    # Celia "Y-Yeah..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:33
translate chinese celia_toilet_fuck_v1_08cca380:

    # Celia "*Lick* *Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:35
translate chinese celia_toilet_fuck_v1_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:36
translate chinese celia_toilet_fuck_v1_e52264fa:

    # MC "Oh God... That’s good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:39
translate chinese celia_toilet_fuck_v1_3d8cb8e2:

    # Celia "(The scent of his cock, is making me so wet.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:40
translate chinese celia_toilet_fuck_v1_5a369e5a:

    # Celia "*Lick Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:43
translate chinese celia_toilet_fuck_v1_f676f2b1:

    # MC "(She’s about to start sucking! This is going to be incredible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:44
translate chinese celia_toilet_fuck_v1_c5f3f0af:

    # Celia "(I hope he cums quickly. The longer I spend in here, the more chance I have of getting caught!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:47
translate chinese celia_toilet_fuck_v1_eb0a0c57:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:48
translate chinese celia_toilet_fuck_v1_74231630:

    # MC "Ahh... Damn... You’re not too bad at this, Ms. Celia."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:49
translate chinese celia_toilet_fuck_v1_261f8e37:

    # Celia "(Not too bad?! My husband thinks my blowjobs are amazing! What an ungrateful little bastard! I’ll show him just how good I really am!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:50
translate chinese celia_toilet_fuck_v1_e9c0b13e:

    # Celia "(This little twerp won’t last two minutes, against MY mouth!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:53
translate chinese celia_toilet_fuck_v1_eb0a0c57_1:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:55
translate chinese celia_toilet_fuck_v1_f4cef10d:

    # MC "(Hehe... I can’t believe she’s this receptive to being blackmailed!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:57
translate chinese celia_toilet_fuck_v1_fc303bd9:

    # MC "(Heh, I can’t believe she’s enjoying pretending to be blackmailed this much!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:58
translate chinese celia_toilet_fuck_v1_71b75169:

    # MC "(I honestly thought she would have put up more resistance!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:61
translate chinese celia_toilet_fuck_v1_4bef739e:

    # Celia "(Time to take him, deep in my mouth. There’s no way he’ll be able to resist cumming, once I start this!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:63
translate chinese celia_toilet_fuck_v1_850574f3:

    # Celia "(Then I can finally get back to class and forget about this horrible ordeal!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:65
translate chinese celia_toilet_fuck_v1_36196a6d:

    # Celia "(I’ll have to finish quickly so I can get back to teaching my class!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:69
translate chinese celia_toilet_fuck_v1_bf9da234:

    # MC "(This blowjob is amazing - I’ll definitely have to blackmail her again, so I can try her ass too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:71
translate chinese celia_toilet_fuck_v1_b1e1e995:

    # MC "(This blowjob is amazing! I’ll definitely have to organise this again so I can try her ass out as well!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:72
translate chinese celia_toilet_fuck_v1_9a554c15:

    # MC "Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:75
translate chinese celia_toilet_fuck_v1_633e3f5f:

    # Celia "*SHLURP*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:76
translate chinese celia_toilet_fuck_v1_8d56a97e:

    # Celia "*GAG*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:77
translate chinese celia_toilet_fuck_v1_f6b307f9:

    # MC "Ooooh! That’s really good, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:80
translate chinese celia_toilet_fuck_v1_afd7e90c:

    # Celia "*Suck* *Suck* *Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:81
translate chinese celia_toilet_fuck_v1_ecc0c788:

    # Celia "*Shluuuurrrp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:82
translate chinese celia_toilet_fuck_v1_4777f6ae:

    # MC "Ahhh! Mmm! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:85
translate chinese celia_toilet_fuck_v1_018a01bc:

    # Celia "*Suck* *Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:86
translate chinese celia_toilet_fuck_v1_8d56a97e_1:

    # Celia "*GAG*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:87
translate chinese celia_toilet_fuck_v1_23589306:

    # MC "Ahh! I’m so close! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:88
translate chinese celia_toilet_fuck_v1_27373d41:

    # Celia "(Heh... I knew he wouldn't last too long, against MY oral technique.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:91
translate chinese celia_toilet_fuck_v1_eded1683:

    # MC "(Should I pull out and cum on her face, or let her keep sucking, and cum in her mouth?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:97
translate chinese celia_toilet_fuck_v1_15ef2060:

    # MC "Oh God! Yes! Yes! Ahhhhhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:98
translate chinese celia_toilet_fuck_v1_2492f430:

    # Celia "*Suck* *Shlurrrrp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:99
translate chinese celia_toilet_fuck_v1_20a9a906:

    # Celia "Mpppfff!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:100
translate chinese celia_toilet_fuck_v1_85e04a84:

    # Celia "(He’s flooding my mouth with his hot cum!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:110
translate chinese celia_toilet_fuck_v1_50684223:

    # Celia "Ahh...."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:111
translate chinese celia_toilet_fuck_v1_024646bf:

    # MC "Crap! Do you want a tissue?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:112
translate chinese celia_toilet_fuck_v1_5df155d5:

    # Celia "(It’s best if I don’t leave any evidence behind.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:114
translate chinese celia_toilet_fuck_v1_c373a0b5:

    # Celia "*Gulp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:115
translate chinese celia_toilet_fuck_v1_21c833ee:

    # MC "(Holy shit! She swallowed my cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:119
translate chinese celia_toilet_fuck_v1_c7f93601:

    # MC "I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:120
translate chinese celia_toilet_fuck_v1_c0a14f63:

    # Celia "Wait- Eww!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:130
translate chinese celia_toilet_fuck_v1_82f1b8e0:

    # MC "Hnng! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:131
translate chinese celia_toilet_fuck_v1_1e301636:

    # Celia "Oh yuck! Pass me some toilet paper!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:136
translate chinese celia_toilet_fuck_v1_66686892:

    # Celia "Hmm... I’d a feeling you’d choose that one."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:137
translate chinese celia_toilet_fuck_v1_3a182f7b:

    # Celia "Come on over to the door. You have to promise to be quiet though - I think there’s some other students around right now."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:138
translate chinese celia_toilet_fuck_v1_8e7ff021:

    # MC "Don’t worry, Ms. Celia. I’ll be quiet."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:141
translate chinese celia_toilet_fuck_v1_e721187f:

    # MC "(Alright! Time to hike up this slut’s skirt!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:142
translate chinese celia_toilet_fuck_v1_bfe81a0b:

    # MC "(I’m gonna fuck her ass so hard, that she’ll be moaning in pleasure!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:145
translate chinese celia_toilet_fuck_v1_41c14574:

    # MC "(Oh wow! No panties!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:146
translate chinese celia_toilet_fuck_v1_539ff4fa:

    # MC "You’re not wearing any underwear, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:147
translate chinese celia_toilet_fuck_v1_1cb10d7c:

    # Celia "I don’t need a running commentary. Just hurry up and get on with it."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:150
translate chinese celia_toilet_fuck_v1_104170a4:

    # MC "As you wish."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:151
translate chinese celia_toilet_fuck_v1_94bc6794:

    # Celia "And make sure you put it in the right hole. I’m not on any birth control right now, so my pussy is out of the question."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:152
translate chinese celia_toilet_fuck_v1_891b345d:

    # MC "Yeah, I’ll make sure to only fuck your ass."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:155
translate chinese celia_toilet_fuck_v1_25021d2f:

    # Celia "(I usually only do anal once or twice per year. Usually for my husband’s birthday...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:157
translate chinese celia_toilet_fuck_v1_7a8f8a41:

    # Celia "(But until I find out who this blackmailer is, there’s isn’t much I can do.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:159
translate chinese celia_toilet_fuck_v1_50d71191:

    # Celia "(It’s much hotter in this fantasy than when my husband asks for it. Something about pretending to be “made” to have my ass fucked just gets me sooo wet!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:160
translate chinese celia_toilet_fuck_v1_d65505ed:

    # Celia "(I’m just glad he stated anal, instead of my pussy!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:163
translate chinese celia_toilet_fuck_v1_50684223_1:

    # Celia "Ahh...."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:167
translate chinese celia_toilet_fuck_v1_3999960c:

    # Celia "(I can feel the tip of his glans, pressing against my back door.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:168
translate chinese celia_toilet_fuck_v1_e1c62eb3:

    # Celia "(He’s got a really thick cock... This could be difficult for me to take.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:172
translate chinese celia_toilet_fuck_v1_b4d63389:

    # Celia "Ooh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:173
translate chinese celia_toilet_fuck_v1_bee93f0d:

    # MC "(Awesome! Ms. Celia’s asshole is sooo damn tight! This is amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:176
translate chinese celia_toilet_fuck_v1_8b0b2112:

    # MC "(Time to start thrusting!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:180
translate chinese celia_toilet_fuck_v1_d958a561:

    # Celia "Ah... Ah.... Ooh...Mmffff...."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:181
translate chinese celia_toilet_fuck_v1_f607e344:

    # MC "You have to be quiet, Ms. Celia. Remember? You said there were other students about!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:182
translate chinese celia_toilet_fuck_v1_ff0c8a5f:

    # Celia "I- Ah! I know! I’m t-trying! Ah!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:186
translate chinese celia_toilet_fuck_v1_b9b8e06d:

    # "*Creeeaaak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:187
translate chinese celia_toilet_fuck_v1_a1e7eb1e:

    # Celia "(Oh God! That was the bathroom door! Someone else is in here!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:188
translate chinese celia_toilet_fuck_v1_711ab4ad:

    # MC "(Hehe! Time to start thrusting really fast! Let’s see if Ms. Celia can keep it together!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:190
translate chinese celia_toilet_fuck_v1_f28bdbff:

    # Celia "(I’ve got to keep biting my lip! I can’t moan right now, or I’ll get caught!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:191
translate chinese celia_toilet_fuck_v1_505cc7bb:

    # Celia "Ah... (He’s fucking me so fast! It feels so good!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:194
translate chinese celia_toilet_fuck_v1_94a9194a:

    # Celia "(His thick shaft is filling up my asshole! I can’t take much more of this!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:195
translate chinese celia_toilet_fuck_v1_f4645f28:

    # Celia "(Hurry up and leave the bathroom, you stupid student! I need to moan!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:196
translate chinese celia_toilet_fuck_v1_b8a35c82:

    # MC "(God! I’m about to cum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:197
translate chinese celia_toilet_fuck_v1_0f756bc9:

    # MC "Hnng...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:198
translate chinese celia_toilet_fuck_v1_44c8a382:

    # Celia "(Oh no! I can feel his cock twitching and his hot cum pouring inside me! I’m gonna cum!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:202
translate chinese celia_toilet_fuck_v1_14bfe98c:

    # "*Creeeak* *Thud*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:203
translate chinese celia_toilet_fuck_v1_bf5da75a:

    # MC "(Phew... looks like the student just left!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:204
translate chinese celia_toilet_fuck_v1_df3ea219:

    # Celia "Ahhh! Oooohhhhhhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:205
translate chinese celia_toilet_fuck_v1_287a5e92:

    # MC "(Ms. Celia is shaking and trembling! Did I just make her cum?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:206
translate chinese celia_toilet_fuck_v1_8c7cf98e:

    # MC "Are you okay there?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:207
translate chinese celia_toilet_fuck_v1_1c84524e:

    # Celia "Y-Yeah... *Pant*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:210
translate chinese celia_toilet_fuck_v1_015cdbbc:

    # Celia "I... have to get back to *Pant* class."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:211
translate chinese celia_toilet_fuck_v1_dd1c4a31:

    # Celia "(That was too fucking close... I never imagined he would make me cum like that!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:219
translate chinese celia_toilet_cabin_day_scene4__blowjob_v1_label1_9938d1d5:

    # MC "That was AWESOME, Ms. Celia! Thank you so much!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:220
translate chinese celia_toilet_cabin_day_scene4__blowjob_v1_label1_40e2d029:

    # Celia "Yeah, sure. Whatever..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:222
translate chinese celia_toilet_cabin_day_scene4__blowjob_v1_label1_8db57b16:

    # Celia "(I need to hurry up and figure out who is blackmailing me, before this goes any further.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:224
translate chinese celia_toilet_cabin_day_scene4__blowjob_v1_label1_d5e39911:

    # Celia "(How much further should I let this fantasy go? I do have a husband after all...)"
    Celia ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:14
    old "I want you to suck my cock, Ms. Celia!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:14
    old "I want to fuck your ass, Ms. Celia."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:93
    old "Let her keep sucking, and cum in her mouth."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/celia_toilet_fuck_v1.rpy:93
    old "Pull out and cum on her face!"
    new ""

