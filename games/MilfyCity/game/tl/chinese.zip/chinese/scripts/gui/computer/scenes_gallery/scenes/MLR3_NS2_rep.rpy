﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:17
translate chinese MLR3_NS2_rep_acdce1cd:

    # MC "Zzz..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:18
translate chinese MLR3_NS2_rep_9588797f:

    # MC "*Snore*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:22
translate chinese MLR3_NS2_rep_79e038e5:

    # MC "Zzz...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:24
translate chinese MLR3_NS2_rep_48c1e588:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:29
translate chinese MLR3_NS2_rep_14803739:

    # Mom "(Why are these damn floorboards so creaky? It was difficult enough creeping in here, without waking Sara or Caroline!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:30
translate chinese MLR3_NS2_rep_1dd27504:

    # MC "Zzz... *Snore*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:34
translate chinese MLR3_NS2_rep_bea3b2c4:

    # Mom "(God... I’m so damn horny... I hope he doesn't mind me waking him up, like this.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:35
translate chinese MLR3_NS2_rep_fb624e63:

    # Mom "(Okay... here goes nothing.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:39
translate chinese MLR3_NS2_rep_489200bc:

    # Mom "(My heart’s racing right now. Why do I feel so worried?! It’s not like we haven’t done this before.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:40
translate chinese MLR3_NS2_rep_9588797f_1:

    # MC "*Snore*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:44
translate chinese MLR3_NS2_rep_0506030e:

    # Mom "(I guess I’ll wake him up with a gentle kiss.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:45
translate chinese MLR3_NS2_rep_a6f6858c:

    # Mom "(It’s how I’d like to be woken up, after all.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:49
translate chinese MLR3_NS2_rep_89024f27:

    # Mom "*Whispered* You’re so handsome, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:51
translate chinese MLR3_NS2_rep_7809c36d:

    # Mom "*Whispered* I can’t believe I have such a beautiful son."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:53
translate chinese MLR3_NS2_rep_aee10932:

    # Mom "*Whispered* I can’t believe I have such a beautiful guy in my life."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:57
translate chinese MLR3_NS2_rep_08a6cfb7:

    # Mom "*Whispered* I love you, [player_name]. I really do."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:58
translate chinese MLR3_NS2_rep_3aff1f32:

    # Mom "*Whispered* You have no idea how much happier you have made me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:62
translate chinese MLR3_NS2_rep_6e6d3ea6:

    # Mom "*Mwah*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:63
translate chinese MLR3_NS2_rep_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:64
translate chinese MLR3_NS2_rep_302a3f87:

    # Mom "(His lips are so soft...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:68
translate chinese MLR3_NS2_rep_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:69
translate chinese MLR3_NS2_rep_acdce1cd_1:

    # MC "Zzz..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:73
translate chinese MLR3_NS2_rep_10c2f82b:

    # MC "(Ugh... I’m having another one of those erotic dreams...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:74
translate chinese MLR3_NS2_rep_f8404175:

    # MC "(Wait... Why is my mouth so warm?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:78
translate chinese MLR3_NS2_rep_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:79
translate chinese MLR3_NS2_rep_2ffa53de:

    # MC "(Is someone's tongue in my mouth?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:83
translate chinese MLR3_NS2_rep_abd39c81:

    # MC "Hmm?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:85
translate chinese MLR3_NS2_rep_56911e09:

    # MC "(Holy shit! [Mom_name]?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:86
translate chinese MLR3_NS2_rep_1fd97556:

    # Mom "(Ahh! He finally woke up!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:90
translate chinese MLR3_NS2_rep_5acc15c8:

    # Mom "I thought you’d never wake up. You must have been in a pretty deep sleep."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:91
translate chinese MLR3_NS2_rep_6da8e0df:

    # MC "Uh huh... Sorry, I wasn’t expecting you tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:93
translate chinese MLR3_NS2_rep_497e5cc8:

    # Mom "Listen, your father is still at work... and I want to do it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:95
translate chinese MLR3_NS2_rep_0e513183:

    # Mom "Listen, Bob is still at work... and I want to do it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:96
translate chinese MLR3_NS2_rep_5085aa09:

    # MC "You mean, like have sex, right now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:103
translate chinese MLR3_NS2_rep_29cc2c58:

    # Mom "Yes! Now let’s get these clothes and blankets off you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:104
translate chinese MLR3_NS2_rep_958343b4:

    # MC "Whoa!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:105
translate chinese MLR3_NS2_rep_e122d104:

    # Mom "There we go!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:109
translate chinese MLR3_NS2_rep_bcccaac2:

    # Mom "We won’t be needing THESE things either!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:110
translate chinese MLR3_NS2_rep_28a42246:

    # MC "(Holy shit! This is actually happening again! I didn’t realise [Dad_name] would be away for so long!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:111
translate chinese MLR3_NS2_rep_ceafef25:

    # Mom "Well? What are you waiting for? I’m all ready for you.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:115
translate chinese MLR3_NS2_rep_a977313a:

    # MC "Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:116
translate chinese MLR3_NS2_rep_28c4f346:

    # Mom "You like what you see?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:117
translate chinese MLR3_NS2_rep_9d2b34eb:

    # MC "Y-Yeah! It’s great! You’re great!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:121
translate chinese MLR3_NS2_rep_fcf10a01:

    # Mom "I just couldn’t hold myself back any longer. I get so horny, all the time, and I haven’t been able to stop thinking about fucking your cock, since that beach getaway we had together."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:122
translate chinese MLR3_NS2_rep_cbb22d44:

    # Mom "Please... just fuck me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:123
translate chinese MLR3_NS2_rep_e51f2269:

    # MC "I haven’t got a condom..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:127
translate chinese MLR3_NS2_rep_b48f688b:

    # Mom "Relax - it’ll be fine. We’re wasting time! Just hurry up and stick your cock inside me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:128
translate chinese MLR3_NS2_rep_c47346e8:

    # MC "Alright, as long as you’re sure it’s safe."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:129
translate chinese MLR3_NS2_rep_cb155f30:

    # Mom "I’m at a safe time of the month. You can cum inside - don't worry about it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:133
translate chinese MLR3_NS2_rep_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:135
translate chinese MLR3_NS2_rep_e30a9802:

    # Mom "Mmm... yes... Just like that..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:136
translate chinese MLR3_NS2_rep_9f9cdb91:

    # MC "(Her pussy is so wet right now, her vulva feels like a pair of lips, sucking on my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:140
translate chinese MLR3_NS2_rep_98dfc4dc:

    # MC "Mmm! Yes! Ugh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:141
translate chinese MLR3_NS2_rep_3a45e9c4:

    # Mom "Oh... wow... "
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:142
translate chinese MLR3_NS2_rep_ed81bfa1:

    # Mom "(My mind’s melting, right now... this feels sooooo good!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:146
translate chinese MLR3_NS2_rep_aa1d59ab:

    # Mom "D-Deeper! Push it ALL THE WAY in!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:147
translate chinese MLR3_NS2_rep_df0c049f:

    # Mom "I want to feel your cock, all the way inside me, right up to my cervix!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:148
translate chinese MLR3_NS2_rep_73de22f3:

    # Mom "AHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:152
translate chinese MLR3_NS2_rep_4bb9ba19:

    # MC "(Fuck... this feels so good! I really missed this, after we left the beach house.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:153
translate chinese MLR3_NS2_rep_4d8c589a:

    # Mom "Mmm! Oh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:157
translate chinese MLR3_NS2_rep_b01d1396:

    # MC "Spread your legs a little more, [Mom_name]. I just need to get a better angle."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:159
translate chinese MLR3_NS2_rep_9845568a:

    # Mom "Uh huh! Whatever you want! Ah!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:161
translate chinese MLR3_NS2_rep_bfcc03a9:

    # MC "There we go. Perfect. I can fuck you properly now!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:165
translate chinese MLR3_NS2_rep_4a314bce:

    # MC "Ugh! Hnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:167
translate chinese MLR3_NS2_rep_0cf139fb:

    # Mom "Ohh! Ahh! Yes!! YES! Oh my God! Yes!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:169
translate chinese MLR3_NS2_rep_ffabef4d:

    # Mom "Holy fuck!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:173
translate chinese MLR3_NS2_rep_22488aa0:

    # Mom "(This is the best sex I have ever had, in my life! I wonder why?)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:174
translate chinese MLR3_NS2_rep_3a0397a6:

    # Mom "(Is it to do with the girth or length of his cock?)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:175
translate chinese MLR3_NS2_rep_93eb55a0:

    # Mom "(Maybe it’s got to do with the angle he’s screwing me at?)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:179
translate chinese MLR3_NS2_rep_c0d1e1a1:

    # Mom "(Perhaps it’s just, the knowledge that I’m being fucked by my own son.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:181
translate chinese MLR3_NS2_rep_abc48810:

    # Mom "(Perhaps it’s just the knowledge that I’m being fucked by a guy so much younger than I am.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:182
translate chinese MLR3_NS2_rep_375e4e4b:

    # Mom "(Judy once told me that the brain is the most intense sexual organ... perhaps its true.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:183
translate chinese MLR3_NS2_rep_0d7c9e06:

    # Mom "Ah! Ahh! AHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:187
translate chinese MLR3_NS2_rep_e0520807:

    # Mom "YEEEEESSSSS!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:188
translate chinese MLR3_NS2_rep_ffdb0bfc:

    # MC "Ugh! Uh! Ahh! Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:189
translate chinese MLR3_NS2_rep_88cb71c5:

    # Mom "Suck on my tits! Quick!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:193
translate chinese MLR3_NS2_rep_cd7f6e60:

    # MC "*Suck Suck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:194
translate chinese MLR3_NS2_rep_fbb0fa01:

    # Mom "Mmm! Just like that! Ugh! Ahh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:195
translate chinese MLR3_NS2_rep_13f50765:

    # Mom "Y-You can bite them a bit, if you want! J-Just don’t be too oohhhh hard!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:199
translate chinese MLR3_NS2_rep_1060eba7:

    # MC "*SUCK SUCK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:200
translate chinese MLR3_NS2_rep_7045618c:

    # Mom "AH! YES! OHHH FUCK! I’M GONNA CUM! I’M CUMMING! AHHHHHHH!!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:201
translate chinese MLR3_NS2_rep_4399b9a7:

    # MC "(That’s one orgasm for [Mom_name] so far!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:205
translate chinese MLR3_NS2_rep_b0b5b190:

    # Mom "*Pant Pant*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:206
translate chinese MLR3_NS2_rep_8fa7af89:

    # Mom "W-Wow... That was good."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:207
translate chinese MLR3_NS2_rep_c13231b6:

    # MC "Heh, I’m glad you’re enjoying this as much as I am."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:211
translate chinese MLR3_NS2_rep_e0dcdc6c:

    # MC "I think I’m gonna cum pretty soon too, though!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:212
translate chinese MLR3_NS2_rep_d189d5c2:

    # Mom "Aww, really? We were just getting started!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:213
translate chinese MLR3_NS2_rep_79d51762:

    # MC "I know, but your pussy just feels so fucking good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:217
translate chinese MLR3_NS2_rep_c69bf8f7:

    # Mom "Slow down, a bit. Take a couple of slow deep thrusts."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:218
translate chinese MLR3_NS2_rep_074175ea:

    # Mom "I’m rarely going to get the chance to properly fuck you, so when we do get our opportunities, we’re gonna make the most of them."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:219
translate chinese MLR3_NS2_rep_fdfd450f:

    # MC "Okay, [Mom_name]. No problem. Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:223
translate chinese MLR3_NS2_rep_819799f8:

    # Mom "I’m serious. If you cum right now, I’ll... ground you for a week!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:225
translate chinese MLR3_NS2_rep_0303181b:

    # Mom "Good luck explaining the reasoning behind that one, to your sisters! Haha!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:227
translate chinese MLR3_NS2_rep_cb07a7b6:

    # Mom "I’m serious. If you cum right now, I’ll... raise the rent for all of you - starting next week! "
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:229
translate chinese MLR3_NS2_rep_d3f02e30:

    # Mom "Good luck explaining the reasoning behind that one to Sara and Caroline! Haha!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:232
translate chinese MLR3_NS2_rep_fd9199dd:

    # MC "Haha, that’s just cruel, [Mom_name]!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:236
translate chinese MLR3_NS2_rep_2f52473c:

    # Mom "Ohh... fuck... Mmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:238
translate chinese MLR3_NS2_rep_e2241d62:

    # Mom "That’s the spot, Baby! Right there!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:239
translate chinese MLR3_NS2_rep_caabc932:

    # MC "Hnng... Fuck, I’m so close to cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:244
translate chinese MLR3_NS2_rep_a18dfd5d:

    # MC "(It gets tighter and hotter, the deeper I go! It would feel amazing to just, blow my load, deep inside her, right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:245
translate chinese MLR3_NS2_rep_f3289f18:

    # Mom "Ah! Ahhhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:246
translate chinese MLR3_NS2_rep_02d18261:

    # MC "Ah! Fuck! Mmm! Hnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:250
translate chinese MLR3_NS2_rep_71d575cb:

    # Mom "You sound like you’re about to cum! Pull out and we’ll switch up positions."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:251
translate chinese MLR3_NS2_rep_7338053c:

    # Mom "It’ll give you a chance to regain some stamina, before round two."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:252
translate chinese MLR3_NS2_rep_befc87ba:

    # MC "Sure. What position are you thinking? Doggy style?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:256
translate chinese MLR3_NS2_rep_b08230c6:

    # Mom "Nah, nothing that basic. Let’s try it sideways."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:257
translate chinese MLR3_NS2_rep_00f7a73e:

    # MC "Ohh, this looks interesting."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:258
translate chinese MLR3_NS2_rep_18c39297:

    # Mom "Climb behind me and fuck me from behind."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:262
translate chinese MLR3_NS2_rep_2cfc15b1:

    # Mom "Just... make sure you aim your cock at the right hole."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:263
translate chinese MLR3_NS2_rep_14d41da1:

    # Mom "I’m down for anal, but only when I can prepare for it, with lube!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:264
translate chinese MLR3_NS2_rep_4e7b79f6:

    # MC "Haha! No problem, [Mom_name]. I’ll be careful I get the right hole."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:268
translate chinese MLR3_NS2_rep_b105e7ab:

    # Mom "You’re DANGEROUSLY close to the wrong one, right now!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:269
translate chinese MLR3_NS2_rep_f0a44a86:

    # MC "I know, I know! Don’t worry about it - I’ve got a hold of my dick."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:270
translate chinese MLR3_NS2_rep_304654f7:

    # Mom "You better!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:274
translate chinese MLR3_NS2_rep_a3da8621:

    # Mom "Ah!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:275
translate chinese MLR3_NS2_rep_ac780dec:

    # MC "See? What did I tell you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:279
translate chinese MLR3_NS2_rep_473a9c18:

    # MC "Slipped in like a glove. See?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:281
translate chinese MLR3_NS2_rep_463e5c7c:

    # Mom "Mmm! Uh huh! Yeah!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:282
translate chinese MLR3_NS2_rep_82bb72a1:

    # Mom "(This angle is perfect - he’s thrusting into my g-spot now!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:286
translate chinese MLR3_NS2_rep_9d564a0a:

    # Mom "Ohh... Yes... right there!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:287
translate chinese MLR3_NS2_rep_a117f745:

    # MC "Ugh... Fuck... I love you, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:288
translate chinese MLR3_NS2_rep_488626ce:

    # Mom "I love you too, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:292
translate chinese MLR3_NS2_rep_f0aac57c:

    # Mom "OHHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:294
translate chinese MLR3_NS2_rep_dadc208c:

    # Mom "(God! He’s going so deep inside me! This feels soooo good!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:300
translate chinese MLR3_NS2_rep_7cd21a98:

    # Mom "Ah! Ahh... Mmm! Ohhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:302
translate chinese MLR3_NS2_rep_996783ae:

    # Mom "Don’t stop, [player_name]! Don’t stop fucking your mommy! You’re making me feel sooo good!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:304
translate chinese MLR3_NS2_rep_d5eb38eb:

    # Mom "Don’t stop, [player_name]! Don’t stop fucking me! You’re making me feel sooo good!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:308
translate chinese MLR3_NS2_rep_b0dbea4a:

    # MC "Ugh! Ah... Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:309
translate chinese MLR3_NS2_rep_70d4cd36:

    # Mom "Yes! Oh! Yes! Right there! That’s the spot!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:314
translate chinese MLR3_NS2_rep_2bef2142:

    # Mom "Kiss me! I want to feel your lips, while you fuck me!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:315
translate chinese MLR3_NS2_rep_c453b06c:

    # MC "(She’s really getting into this! I’ve never seen her so excited before!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:319
translate chinese MLR3_NS2_rep_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:320
translate chinese MLR3_NS2_rep_7f0c53e5:

    # MC "*Mwah*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:321
translate chinese MLR3_NS2_rep_9318227b:

    # Mom "MMMM!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:325
translate chinese MLR3_NS2_rep_1df066a7:

    # Mom "(Oh God! He’s going, so deep inside me! This feels sooooo good!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:328
translate chinese MLR3_NS2_rep_0bb9d7e8:

    # MC "([Mom_name]’s pussy is quivering around my cock! She’s about to cum again!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:330
translate chinese MLR3_NS2_rep_1a6efd55:

    # MC "(Her pussy is quivering around my cock! She’s about to cum again!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:331
translate chinese MLR3_NS2_rep_601cd872:

    # Mom "MMM! MMMMMM!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:335
translate chinese MLR3_NS2_rep_66c9ea5e:

    # Mom "D-Don’t stop! Keep going! AHHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:336
translate chinese MLR3_NS2_rep_31e941ef:

    # MC "Ugh! Hnnng! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:340
translate chinese MLR3_NS2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:341
translate chinese MLR3_NS2_rep_b1141087:

    # Mom "Mmm! MMMMM!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:345
translate chinese MLR3_NS2_rep_6ecbbbc0:

    # MC "I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:346
translate chinese MLR3_NS2_rep_3c73ccd7:

    # Mom "Do it inside me! Cum in my pussy!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:347
translate chinese MLR3_NS2_rep_09681933:

    # Mom "I want to feel your hot cum, filling me up!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:351
translate chinese MLR3_NS2_rep_1f5671ab:

    # MC "Hnnnngggg! AHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:352
translate chinese MLR3_NS2_rep_e9ca704e:

    # Mom "Ahhh! I’m CUMMING AGAIN! AYYAAAHHHHHH!!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:353
translate chinese MLR3_NS2_rep_f4a0e1d2:

    # MC "([Mom_name]’s pussy is convulsing around my cock - she’ll milk me dry, if I don’t pull out!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:357
translate chinese MLR3_NS2_rep_e0aa9078:

    # MC "I’m pulling out!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:366
translate chinese MLR3_NS2_rep_ae3538c8:

    # MC "(It’s too risky to cum inside her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:367
translate chinese MLR3_NS2_rep_dc0e0b32:

    # Mom "Aww, okay..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:368
translate chinese MLR3_NS2_rep_a96656a6:

    # MC "Hnnng! Ugh! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:374
translate chinese MLR3_NS2_rep_18fc3329:

    # MC "Yes! Hnng! FUCK! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:376
translate chinese MLR3_NS2_rep_4ab63885:

    # Mom "Ohh God... Mmm... it feels sooo hot!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:385
translate chinese MLR3_NS2_rep_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:386
translate chinese MLR3_NS2_rep_57dc26bf:

    # Mom "Wow... That was... fucking amazing..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:395
translate chinese MLR3_NS2_con2_rep_c609d275:

    # MC "That was incredible - thank you so much, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:396
translate chinese MLR3_NS2_con2_rep_fa3be7f9:

    # Mom "I hope you enjoyed it as much as I did! Wow, I’m still trembling a little. Can you feel my hands shaking?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:397
translate chinese MLR3_NS2_con2_rep_01661cdf:

    # MC "Haha, yeah, I can!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:401
translate chinese MLR3_NS2_con2_rep_56688a68:

    # Mom "So... What do you say, ready for round two?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:402
translate chinese MLR3_NS2_con2_rep_02a45c2b:

    # MC "Round two?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:403
translate chinese MLR3_NS2_con2_rep_d479dffe:

    # MC "There’s NO way I’ll be able to get hard again, anytime soon, after that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:407
translate chinese MLR3_NS2_con2_rep_de30b54c:

    # Mom "Oh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:408
translate chinese MLR3_NS2_con2_rep_86ab5048:

    # MC "Sorry, [Mom_name]. Guys just don’t work like that... we can’t keep cumming multiple times, like you women can."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:412
translate chinese MLR3_NS2_con2_rep_6b14744f:

    # Mom "That sounds like a challenge to me!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:413
translate chinese MLR3_NS2_con2_rep_3fdfd822:

    # MC "W-Wait! It wasn’t a challenge, I was being serious!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:417
translate chinese MLR3_NS2_con2_rep_834e97b2:

    # Mom "First things first: we need to get you hard again!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:418
translate chinese MLR3_NS2_con2_rep_0329d9f5:

    # MC "Listen, [Mom_name], this isn’t going to work - I can’t just make it go-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:419
translate chinese MLR3_NS2_con2_rep_d678375c:

    # Mom "Take a look at my breasts... Do you not want me to rub them, all over your fat cock?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:423
translate chinese MLR3_NS2_con2_rep_5d0a5d86:

    # MC "Oh yeah... They’re amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:424
translate chinese MLR3_NS2_con2_rep_7f00473a:

    # Mom "Imagine them, rubbing all up and down your body, massaging every single inch of it."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:428
translate chinese MLR3_NS2_con2_rep_f9405048:

    # Mom "Aha! There we go!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:429
translate chinese MLR3_NS2_con2_rep_52149836:

    # MC "Huh?! What?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:430
translate chinese MLR3_NS2_con2_rep_8111c436:

    # Mom "Told you I’d get you hard! I’m gonna suck you off now. You gave me two orgams - it’s only fair that I return the favour!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:434
translate chinese MLR3_NS2_con2_rep_651ce7e2:

    # MC "You don’t have to, [Mom_name]. I don’t want you stressing yourself out, about me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:435
translate chinese MLR3_NS2_con2_rep_021b2565:

    # Mom "I’m not stressing myself out."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:436
translate chinese MLR3_NS2_con2_rep_bd2667ce:

    # Mom "I’m just, finally indulging a fantasy, I’ve kept repressed for years."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:440
translate chinese MLR3_NS2_con2_rep_877a50c2:

    # Mom "I don’t know if you have any cum left in your balls, after that, but if you do, I’m gonna suck it ALL out."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:441
translate chinese MLR3_NS2_con2_rep_a298f833:

    # MC "(That sounds so goddamn sexy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:445
translate chinese MLR3_NS2_con2_rep_8c20f667:

    # Mom "*Lick*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:446
translate chinese MLR3_NS2_con2_rep_8130653d:

    # MC "Ahh... Oh...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:450
translate chinese MLR3_NS2_con2_rep_ea1a54f8:

    # Mom "(Hehe, I can feel his cock quivering, as I lick his glans. It must be extra sensitive, since he has cum already!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:451
translate chinese MLR3_NS2_con2_rep_2dccbc5a:

    # Mom "*Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:452
translate chinese MLR3_NS2_con2_rep_75a723b3:

    # MC "Mmm... You’re amazing at that, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:456
translate chinese MLR3_NS2_con2_rep_3008810b:

    # MC "Fuck... Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:457
translate chinese MLR3_NS2_con2_rep_4ed10276:

    # Mom "*Suck *Shlurp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:461
translate chinese MLR3_NS2_con2_rep_f1e73f4a:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:462
translate chinese MLR3_NS2_con2_rep_003e4dfe:

    # MC "Ah! Ah! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:466
translate chinese MLR3_NS2_con2_rep_28baa1c9:

    # Mom "Mmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:467
translate chinese MLR3_NS2_con2_rep_b3044b58:

    # Mom "(His cock is so delicious! I could suck, on this bad boy, for hours!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:468
translate chinese MLR3_NS2_con2_rep_9cf2a5a7:

    # Mom "(Sadly, I don’t think he’d be able to last, that long though!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:472
translate chinese MLR3_NS2_con2_rep_f1a81d87:

    # MC "Mmm, don’t stop, [Mom_name]! Oh God... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:473
translate chinese MLR3_NS2_con2_rep_4a26fb17:

    # MC "I never thought I’d... ahh.. get hard again, so quickly."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:474
translate chinese MLR3_NS2_con2_rep_9c9667c1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:478
translate chinese MLR3_NS2_con2_rep_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:479
translate chinese MLR3_NS2_con2_rep_f5b3b18b:

    # MC "Ohhh! Yes! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:483
translate chinese MLR3_NS2_con2_rep_3a4abcf6:

    # Mom "*Shlurp Shlurp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:484
translate chinese MLR3_NS2_con2_rep_d6da0ff5:

    # MC "I’m gonna cum again soon. Just keep doing th-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:486
translate chinese MLR3_NS2_con2_rep_48c1e588:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:490
translate chinese MLR3_NS2_con2_rep_5c1879d0:

    # MC "(Shit! Was that footsteps in the hallway?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:492
translate chinese MLR3_NS2_con2_rep_48c1e588_1:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:493
translate chinese MLR3_NS2_con2_rep_f1e73f4a_1:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:497
translate chinese MLR3_NS2_con2_rep_f525097c:

    # MC "(It might just be Sara, going to the bathroom...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:498
translate chinese MLR3_NS2_con2_rep_85d89482:

    # MC "(Maybe I should pull a blanket up, over [Mom_name], to hide her?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:500
translate chinese MLR3_NS2_con2_rep_0ecd9b8f:

    # MC "(On the other hand, I don’t want to kill the mood for her. She was so excited to have sex with me tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:507
translate chinese MLR3_NS2_con2_rep_18f1c0a4:

    # Dad "Huh? (What are those weird noises coming from [player_name]’s room.)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:508
translate chinese MLR3_NS2_con2_rep_06fc1a8a:

    # Dad "(I should probably check on him, to make sure he’s alright.)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:512
translate chinese MLR3_NS2_con2_rep_9491107f:

    # MC "(Fuck it... Better safe, than sorry!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:513
translate chinese MLR3_NS2_con2_rep_81a02b63:

    # MC "(This blanket should do fine - if Sara walks in, I’ll just come up with some lame excuse. If I’m lucky, they won’t even notice [Mom_name]’s body under the covers!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:517
translate chinese MLR3_NS2_con2_rep_10367c21:

    # Dad "Hey there, champ. What are you doin-"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:518
translate chinese MLR3_NS2_con2_rep_02c34e99:

    # MC "(Oh FUCK! How did [Dad_name] get home?!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:519
translate chinese MLR3_NS2_con2_rep_40564029:

    # Mom "(HOLY SHIT! FUCK! When did he get back?!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:523
translate chinese MLR3_NS2_con2_rep_fd3a675e:

    # MC "I... uh... um..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:524
translate chinese MLR3_NS2_con2_rep_f972e0c1:

    # Mom "(Shit! SHIT! SHIT!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:525
translate chinese MLR3_NS2_con2_rep_522b1248:

    # MC "I can... explain! I was..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:529
translate chinese MLR3_NS2_con2_rep_b406ae2d:

    # Dad "[player_name]! Oh, my God!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:531
translate chinese MLR3_NS2_con2_rep_7b04313c:

    # MC "D-Dad! I can explain! It’s NOT what you think it is!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:533
translate chinese MLR3_NS2_con2_rep_b34df5fd:

    # MC "B-Bob! I can explain! It’s NOT what you think it is!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:536
translate chinese MLR3_NS2_con2_rep_fccc86ca:

    # MC "I was just... and then she came in and..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:537
translate chinese MLR3_NS2_con2_rep_1bd21e26:

    # MC "...um, I was... er... (Fuck! I’m just rambling like an idiot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:541
translate chinese MLR3_NS2_con2_rep_ba06d3fb:

    # Dad "Why didn’t you tell me you got yourself a girlfriend?!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:542
translate chinese MLR3_NS2_con2_rep_42096cee:

    # Dad "Nice job, champ! I can’t wait to meet the lucky lady, tomorrow morning."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:544
translate chinese MLR3_NS2_con2_rep_807a7e16:

    # Dad "You’ve done your Dad proud."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:546
translate chinese MLR3_NS2_con2_rep_6ce60519:

    # Dad "You’ve done me proud."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:549
translate chinese MLR3_NS2_con2_rep_7cce963f:

    # MC "Y-Yeah! You’re gonna... love her..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:550
translate chinese MLR3_NS2_con2_rep_ef64b017:

    # Dad "I’ll leave, you two lovebirds, in peace. Goodnight, folks."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:554
translate chinese MLR3_NS2_con2_rep_9e1132f6:

    # MC "Jesus fucking Christ..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:555
translate chinese MLR3_NS2_con2_rep_183745d4:

    # MC "Kill me now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:556
translate chinese MLR3_NS2_con2_rep_454e892a:

    # Mom "*Whispered* Is he gone?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:557
translate chinese MLR3_NS2_con2_rep_10d26591:

    # MC "Yeah... he’s gone."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:561
translate chinese MLR3_NS2_con2_rep_9443de6a:

    # Dad "My, my, my! I never imagined he’d get lucky, so fast."
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:562
translate chinese MLR3_NS2_con2_rep_b1c28e1f:

    # Dad "(In fact... it was taking so long, for him to get a girl, I was eighty percent sure he was a gay!)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:563
translate chinese MLR3_NS2_con2_rep_d1540cf7:

    # Dad "I was SO close to bringing home that gay fellow Tim in accounting to meet [player_name]. Good thing I didn’t jump the gun!)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:564
translate chinese MLR3_NS2_con2_rep_e2747dd0:

    # Dad "(Good for him, good for him. Right, I’ll grab myself a drink and then hit the hay. Maybe I’ll get lucky with my wife tonight!)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:568
translate chinese MLR3_NS2_con2_rep_8cc39c12:

    # MC "Are you okay, [Mom_name]?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:569
translate chinese MLR3_NS2_con2_rep_50c782c6:

    # Mom "That was... too fucking close."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:570
translate chinese MLR3_NS2_con2_rep_72cfebce:

    # MC "I know! It was insane! I can’t believe we got away with that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:571
translate chinese MLR3_NS2_con2_rep_df8b49e4:

    # Mom "Good idea, with the blanket - that was some quick thinking!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:575
translate chinese MLR3_NS2_con2_rep_b21b771c:

    # Mom "I better get dressed and get back to my room, before your father notices I’m missing, and puts two and two together."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:577
translate chinese MLR3_NS2_con2_rep_55c73d6b:

    # Mom "I better get dressed and get back to my room, before Bob notices I’m missing, and puts two and two together."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:578
translate chinese MLR3_NS2_con2_rep_bc8e5fb5:

    # MC "Yeah, hurry on back. We’ll see each other another night, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:579
translate chinese MLR3_NS2_con2_rep_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:580
translate chinese MLR3_NS2_con2_rep_2b4de539:

    # Mom "I love you too."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:593
translate chinese MLR3_NS2_con2_rep_18f1c0a4_1:

    # Dad "Huh? (What are those weird noises coming from [player_name]’s room.)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:594
translate chinese MLR3_NS2_con2_rep_06fc1a8a_1:

    # Dad "(I should probably check on him, to make sure he’s alright.)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:595
translate chinese MLR3_NS2_con2_rep_ac1ec820:

    # MC "([Mom_name] was so excited to come over tonight. There’s no sense in spoiling the mood, by hiding her under a blanket!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:599
translate chinese MLR3_NS2_con2_rep_f1e73f4a_2:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:603
translate chinese MLR3_NS2_con2_rep_9c9667c1_1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:604
translate chinese MLR3_NS2_con2_rep_11b7c251:

    # Dad "What in tarnation...?"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:608
translate chinese MLR3_NS2_con2_rep_ffc50cea:

    # MC "D-DAD!?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:610
translate chinese MLR3_NS2_con2_rep_489f8b19:

    # MC "B-BOB!?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:611
translate chinese MLR3_NS2_con2_rep_575b2027:

    # MC "I- uh?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:612
translate chinese MLR3_NS2_con2_rep_d7ca8077:

    # Mom "*Suck Su-*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:613
translate chinese MLR3_NS2_con2_rep_f5f5b274:

    # Mom "(Oh fuck...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:617
translate chinese MLR3_NS2_con2_rep_a27978d8:

    # Dad "WH-WHAT THE HECK IS GOING ON?!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:619
translate chinese MLR3_NS2_con2_rep_456695a5:

    # Dad "JESUS H. CHRIST, LINDA! You’re in bed with your SON!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:621
translate chinese MLR3_NS2_con2_rep_4d1eb204:

    # Dad "JESUS H. CHRIST, LINDA! You're in bed with [player_name]!?"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:625
translate chinese MLR3_NS2_con2_rep_1cea5c24:

    # Mom "N-No! W-Wait! I can explain-"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:626
translate chinese MLR3_NS2_con2_rep_f6434f5d:

    # Dad "Y-You were sucking him off?!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:627
translate chinese MLR3_NS2_con2_rep_f7d15627:

    # Dad "Wait a minute... this is all starting to make sense!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:631
translate chinese MLR3_NS2_con2_rep_31f95e60:

    # Mom "BOB! Wait!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:632
translate chinese MLR3_NS2_con2_rep_f7026917:

    # MC "Oh shit... FUCK!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:633
translate chinese MLR3_NS2_con2_rep_30dbe208:

    # Mom "No! NOOO!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:638
translate chinese MLR3_NS2_con2_rep_8ce1484d:

    # "*SLAM*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:639
translate chinese MLR3_NS2_con2_rep_4d47783e:

    # MC "(I am so fucked... He’s gonna murder me now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:643
translate chinese MLR3_NS2_con2_rep_e5ba378f:

    # Mom "BOB! Come back! Don’t go!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:644
translate chinese MLR3_NS2_con2_rep_07690258:

    # MC "Holy shit... My life is ruined..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:648
translate chinese MLR3_NS2_con2_rep_d78da6eb:

    # Mom "BOB! BOB!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:649
translate chinese MLR3_NS2_con2_rep_e59aab48:

    # Mom "Please! Don’t leave! I can- I can explain everything! I’ll do anything!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:653
translate chinese MLR3_NS2_con2_rep_8965d4d9:

    # MC "(Crap, I might have just lost my relationships with [Mom_name] and [Dad_name] in the same night...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:654
translate chinese MLR3_NS2_con2_rep_8e2e085c:

    # MC "(I can’t see either of them wanting to speak to me ever again after this.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:655
translate chinese MLR3_NS2_con2_rep_e9128916:

    # MC "Tomorrow is gonna be a tough day..."
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:355
    old "Pull out and play it safe!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:355
    old "What’s the harm?! Plunge your cock in deep and blow your load inside her!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:502
    old "Pull a blanket up over [Mom_name]. Better safe than sorry!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR3_NS2_rep.rpy:502
    old "Don’t bother with the blanket - there’s no sense in killing the mood for [Mom_name]."
    new ""

