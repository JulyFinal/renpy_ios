﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:8
translate chinese celia_vibrator_classroom_v1_3422556a:

    # Celia "Quiet, class! We’re continuing with advanced calculus today. Please open your textbooks to page 276."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:10
translate chinese celia_vibrator_classroom_v1_07d4b189:

    # Celia "(I can’t believe, that pervert made me wear this vibrator today.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:11
translate chinese celia_vibrator_classroom_v1_fe004f5a:

    # Celia "(It was bad enough that he forbade me from wearing panties!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:13
translate chinese celia_vibrator_classroom_v1_e46f5d63:

    # Celia "(I can’t believe that little pervert made me wear this vibrator today... God, he’s so creative! I’m soaked with anticipation right now!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:14
translate chinese celia_vibrator_classroom_v1_4fba6358:

    # Celia "(And he was also clever enough to forbid me from wearing my panties... Mmm...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:17
translate chinese celia_vibrator_classroom_v1_94af9d83:

    # MC "(Hehe! This is gonna be great. I’ll let her lecture for a couple of minutes, before I begin.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:18
translate chinese celia_vibrator_classroom_v1_4fb12f0d:

    # MC "(It’s gonna be interesting, watching this bitch try to maintain her composure while I vibrate this inside her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:19
translate chinese celia_vibrator_classroom_v1_9ef5954a:

    # Celia "Now, in order to achieve accurate outcomes in mathematics, one must ensure that they follow the instructions presented in their textbooks."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:22
translate chinese celia_vibrator_classroom_v1_3dc4dc31:

    # MC "(Yawn!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:23
translate chinese celia_vibrator_classroom_v1_f15bd146:

    # MC "(This is getting boring! Time to liven things up!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:24
translate chinese celia_vibrator_classroom_v1_709a313d:

    # MC "(Let’s turn the setting to low...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:28
translate chinese celia_vibrator_classroom_v1_63c216bf:

    # Celia "So, let's take a look at example one."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:29
translate chinese celia_vibrator_classroom_v1_1aa46538:

    # Celia "Here we have a scalene triangle with unknown angles and only two side lengths."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:30
translate chinese celia_vibrator_classroom_v1_16ed2d4b:

    # Celia "If I write this up on the board-"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:37
translate chinese celia_vibrator_classroom_v1_c884251a:

    # Celia "(Oh God... it’s starting...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:38
translate chinese celia_vibrator_classroom_v1_b6b518b1:

    # Celia "(I can feel it vibrating, deep inside me!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:44
translate chinese celia_vibrator_classroom_v1_001bee8a:

    # Brunette_Girl "What were you saying, Ms. Celia?"
    Brunette_Girl ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:47
translate chinese celia_vibrator_classroom_v1_8b8780d0:

    # Celia "I... um... need you to go to chaaahpter twelve. Work your way through the prooohhhblem questions."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:48
translate chinese celia_vibrator_classroom_v1_0ce1e4b4:

    # Ginger_Guy "Are you okay?"
    Ginger_Guy ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:49
translate chinese celia_vibrator_classroom_v1_f8a4f816:

    # Celia "Y-Yeah. Jus a bit of a headache."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:52
translate chinese celia_vibrator_classroom_v1_ea5ce627:

    # Celia "(Shit... This bastard’s gonna make me cum, in front of the whole class, if he keeps this up!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:53
translate chinese celia_vibrator_classroom_v1_6499696c:

    # Celia "Just focus on the techniques I’ve laaaid out, on the board."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:56
translate chinese celia_vibrator_classroom_v1_beeeb9fa:

    # MC "(Hehe... Time to turn it up to medium!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:66
translate chinese celia_vibrator_classroom_v1_018b2376:

    # Celia "(Holy... shit...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:67
translate chinese celia_vibrator_classroom_v1_1c35ddeb:

    # Celia "*Pant!* *Gasp!*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:68
translate chinese celia_vibrator_classroom_v1_59288e5e:

    # MC "(Heh... While the class are busy working, I can see that she’s struggling not to climax!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:76
translate chinese celia_vibrator_classroom_v1_6765d3c2:

    # Celia "*Whispered* Oh, my God..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:77
translate chinese celia_vibrator_classroom_v1_89c52eb6:

    # Blonde_Girl "Is everything okay, Ms. Celia?"
    Blonde_Girl ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:78
translate chinese celia_vibrator_classroom_v1_9a5dd8d0:

    # Celia "Mmm hmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:79
translate chinese celia_vibrator_classroom_v1_9a4e8adb:

    # Blonde_Girl "Do you need me to get the college nurse?"
    Blonde_Girl ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:80
translate chinese celia_vibrator_classroom_v1_1b2cbf9a:

    # Celia "Noooh! I-I’m fine. J-Just fooohhhcus on your work."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:81
translate chinese celia_vibrator_classroom_v1_7ebcf3bc:

    # Celia "(Fuck! I’m so close to cumming!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:84
translate chinese celia_vibrator_classroom_v1_f9b04c91:

    # MC "(Time for the grand finale!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:85
translate chinese celia_vibrator_classroom_v1_ea53de2a:

    # MC "(Let’s make this arrogant bitch cum. Up! High power!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:93
translate chinese celia_vibrator_classroom_v1_18651f33:

    # Celia "(Oh God! Oh Fuck! Fuck! I’m cumming!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:94
translate chinese celia_vibrator_classroom_v1_cfe48dd0:

    # Celia "Ah... Ah.... Oh....."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:97
translate chinese celia_vibrator_classroom_v1_8d4bcd12:

    # Celia "Mmmmmm!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:98
translate chinese celia_vibrator_classroom_v1_107c337c:

    # MC "(Heh! She’s clamping her hand over her mouth, to try and hold back her moans!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:99
translate chinese celia_vibrator_classroom_v1_9f4eec4e:

    # MC "(She’s cumming! She’s actually cumming, in front of her whole class! I can see her whole body shaking!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:102
translate chinese celia_vibrator_classroom_v1_dc17c881:

    # MC "(Okay, time to turn it off now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:107
translate chinese celia_vibrator_classroom_v1_873c6969:

    # Celia "*Pant* *Gasp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:109
translate chinese celia_vibrator_classroom_v1_ccbfe593:

    # Celia "(The bastard blackmailing me, MUST be somewhere in this class. He clearly wants to watch me suffer. And the only way he could do that, is if he was in this classroom right now.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:110
translate chinese celia_vibrator_classroom_v1_9b1cc92b:

    # Celia "(Hmm? That narrows down the list of potential people it could be.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:112
translate chinese celia_vibrator_classroom_v1_0da41e88:

    # MC "(If I keep looking innocent and bored, she won’t catch on that it’s me doing it to her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:113
translate chinese celia_vibrator_classroom_v1_626017fb:

    # MC "(Good luck, Celia. You’ll never catch your blackmailer!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:115
translate chinese celia_vibrator_classroom_v1_8d450e6e:

    # Celia "(Oh, that was a dirty move, [player_name]! You must love humiliating me as much as I love being humiliated!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:116
translate chinese celia_vibrator_classroom_v1_f9c29da4:

    # Celia "(Alright, if that’s the way you want to play, then I’ll see if I can get my own back on you!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:119
translate chinese celia_vibrator_classroom_v1_0903aa76:

    # MC "(I’ll keep looking innocent and distracted. I don’t want my fellow students noticing what Celia and I have going on!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/celia_vibrator_classroom_v1.rpy:120
translate chinese celia_vibrator_classroom_v1_06428539:

    # MC "(Good luck, Celia. Now it’s your turn!)"
    MC ""

