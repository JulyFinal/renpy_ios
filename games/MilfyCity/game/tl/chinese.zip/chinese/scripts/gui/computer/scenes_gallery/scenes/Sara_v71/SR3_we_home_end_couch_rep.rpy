﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:9
translate chinese SR3_we_home_end_couch_rep_9b2438e1:

    # Sara "Is here okay?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:10
translate chinese SR3_we_home_end_couch_rep_9c4732ce:

    # MC "That’s perfect, Sara. Just sit back there, relax, and let me do the work."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:12
translate chinese SR3_we_home_end_couch_rep_c855ddda:

    # MC "That dress is really cute, by the way. Where did you get it from?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:14
translate chinese SR3_we_home_end_couch_rep_e57e130e:

    # Sara "I ordered it online. I knew [Mom_name] would kill me if she saw me going out dressed like this. Haha, she’d probably try and ground me again."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:16
translate chinese SR3_we_home_end_couch_rep_aa116b8b:

    # Sara "I ordered it online. I know you would like it... but I was a little shy wearing it knowing that others will look at me with desire..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:17
translate chinese SR3_we_home_end_couch_rep_624bc30f:

    # MC "(Her feet are so small and adorable.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:19
translate chinese SR3_we_home_end_couch_rep_7dc4f1d0:

    # Sara "What are you doing, [player_name]?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:20
translate chinese SR3_we_home_end_couch_rep_ccebd06c:

    # MC "Just admiring every last inch of your body. I didn’t think you could get much sexier than you were in the ice cream parlour, but... wow! You’re blowing my mind again right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:22
translate chinese SR3_we_home_end_couch_rep_37505ed3:

    # MC "Are you still feeling nervous about sex?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:23
translate chinese SR3_we_home_end_couch_rep_729f908a:

    # Sara "Y-Yeah, just a bit. My heart’s kinda racing right now."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:24
translate chinese SR3_we_home_end_couch_rep_1ffa3f7e:

    # MC "That’s okay, we’ll get your body warmed up, so my cock will just slide in, nice and easy."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:26
translate chinese SR3_we_home_end_couch_rep_2490b741:

    # Sara "O-Okay, thanks [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:27
translate chinese SR3_we_home_end_couch_rep_8d974fbc:

    # MC "Just sit back, relax, and let me take care of your body. You’re in expert hands right now, I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:29
translate chinese SR3_we_home_end_couch_rep_9203a0c1:

    # Sara "Really? Expert hands? You’ve done this a lot?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:30
translate chinese SR3_we_home_end_couch_rep_d1a8f266:

    # MC "Haha, that’s not what I meant! I just mean that I’m going to take good care of you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:31
translate chinese SR3_we_home_end_couch_rep_9a8ef999:

    # MC "(Sara seems to be very jealous at the thought of me being with someone else. I’ll have to choose my words carefully.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:33
translate chinese SR3_we_home_end_couch_rep_bbdfd9f8:

    # MC "Now, let’s peel this dress back and see what I’ve been missing out on all day!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:34
translate chinese SR3_we_home_end_couch_rep_ff1b9a4a:

    # Sara "*Gulp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:35
translate chinese SR3_we_home_end_couch_rep_a9222631:

    # Sara "(I can’t believe it wasn’t that long ago that we were stripping each other while playing video games in my room. Look how far we’ve come since then.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:37
translate chinese SR3_we_home_end_couch_rep_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:38
translate chinese SR3_we_home_end_couch_rep_175750d0:

    # MC "I never get tired of seeing your boobs, Sara. They look as amazing as they did the first time I laid eyes on them."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:39
translate chinese SR3_we_home_end_couch_rep_a0688371:

    # Sara "Hehe... You’re just saying that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:41
translate chinese SR3_we_home_end_couch_rep_7b375101:

    # MC "I’m serious, Sara. Your breasts are beautiful."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:42
translate chinese SR3_we_home_end_couch_rep_35bf580f:

    # Sara "Are they better than Lily’s...?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:43
translate chinese SR3_we_home_end_couch_rep_3eeb5c9b:

    # MC "Of course! You need to stop comparing yourself to other women, Sara. You are beautiful just the way that you are."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:45
translate chinese SR3_we_home_end_couch_rep_30176200:

    # MC "Now, get Lily out of your head and just focus on the sensation of my fingertips teasing your sensitive nipples."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:46
translate chinese SR3_we_home_end_couch_rep_16d178f1:

    # Sara "O-Okay, [player_name]..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:48
translate chinese SR3_we_home_end_couch_rep_bab0a73c:

    # Sara "Oooohh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:49
translate chinese SR3_we_home_end_couch_rep_ba2754b7:

    # MC "I’m not pinching too hard, am I?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:50
translate chinese SR3_we_home_end_couch_rep_25aebcdc:

    # Sara "No... that’s... perfect. Mmm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:52
translate chinese SR3_we_home_end_couch_rep_60847d7e:

    # Sara "Ohhh! God... your fingers are warm..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:53
translate chinese SR3_we_home_end_couch_rep_375ce866:

    # Sara "Push a little more... ah! Yes, just like that! My chest feels all... tingly!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:55
translate chinese SR3_we_home_end_couch_rep_a79a00c2:

    # MC "(Let’s try gently tugging on her nipples and see if she likes that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:57
translate chinese SR3_we_home_end_couch_rep_fcf4e1b1:

    # Sara "Ahh! Ooooohhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:58
translate chinese SR3_we_home_end_couch_rep_5b6e50d9:

    # MC "(Look like I’m onto a winner! She’s clenching her fists in excitement!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:60
translate chinese SR3_we_home_end_couch_rep_6011c574:

    # Sara "*Pant* [player_name], where did you *gasp* learn to use your fingers like this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:61
translate chinese SR3_we_home_end_couch_rep_bcd96de2:

    # MC "Honestly? You’d be amazed at how much stuff you can learn from watching porn."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:62
translate chinese SR3_we_home_end_couch_rep_e530da28:

    # Sara "Ohhh wow..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:64
translate chinese SR3_we_home_end_couch_rep_8b776c6a:

    # MC "Do you want me to speed up or go harder?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:66
translate chinese SR3_we_home_end_couch_rep_e2d4988a:

    # Sara "J-Just keep it *pant* like that... Wow..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:67
translate chinese SR3_we_home_end_couch_rep_c876f818:

    # Sara "(I can feel my panties starting to get wet. It looks like whatever [player_name] was doing is working.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:69
translate chinese SR3_we_home_end_couch_rep_47d236bc:

    # MC "Okay, let’s escalate things a bit."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:70
translate chinese SR3_we_home_end_couch_rep_b51d1f81:

    # Sara "What do you mean?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:71
translate chinese SR3_we_home_end_couch_rep_9e0bfcef:

    # MC "If you’re getting this excited from having your nipples rubbed, then I can only imagine how much you’re going to enjoy..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:73
translate chinese SR3_we_home_end_couch_rep_b83cfe69:

    # MC "...having them sucked."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:74
translate chinese SR3_we_home_end_couch_rep_da40e8b6:

    # Sara "*Gasp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:75
translate chinese SR3_we_home_end_couch_rep_4c894c7f:

    # Sara "[player_name], I-"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:77
translate chinese SR3_we_home_end_couch_rep_f050ce10:

    # MC "*Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:78
translate chinese SR3_we_home_end_couch_rep_16cb829e:

    # Sara "Mmmm! Ohhh fuuuck! That feels sooo goood!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:79
translate chinese SR3_we_home_end_couch_rep_d1c07ef5:

    # Sara "Just like *pant* that! Keep flicking your tongue like that."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:81
translate chinese SR3_we_home_end_couch_rep_0a778461:

    # Sara "Oh my God... Mmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:82
translate chinese SR3_we_home_end_couch_rep_192ec1e8:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:83
translate chinese SR3_we_home_end_couch_rep_b80e1a13:

    # Sara "(God, my chest feels so weird right now. There’s so much pleasure rushing through my body I can barely focus.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:85
translate chinese SR3_we_home_end_couch_rep_a022ce36:

    # Sara "Ah... Ahh..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:86
translate chinese SR3_we_home_end_couch_rep_71269125:

    # MC "(Let’s speed things up a bit.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:87
translate chinese SR3_we_home_end_couch_rep_9c269129:

    # MC "*Lick* *Lick* *Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:89
translate chinese SR3_we_home_end_couch_rep_0fb1ae41:

    # Sara "Mmm! God..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:90
translate chinese SR3_we_home_end_couch_rep_f0799478:

    # Sara "Ah! Yes... Yes, [player_name], right there... Ahh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:92
translate chinese SR3_we_home_end_couch_rep_ee76253e:

    # Sara "Ooohh... Fuuuccck..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:93
translate chinese SR3_we_home_end_couch_rep_192ec1e8_1:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:95
translate chinese SR3_we_home_end_couch_rep_0769b740:

    # Sara "W-Wow... *Pant* This is... amazing, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:96
translate chinese SR3_we_home_end_couch_rep_47b6bd16:

    # MC "(Sara’s getting more and more excited. I wonder if I should increase the intensity of things even further?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:98
translate chinese SR3_we_home_end_couch_rep_192ec1e8_2:

    # MC "*Lick* *Lick*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:99
translate chinese SR3_we_home_end_couch_rep_e1d61a6d:

    # Sara "Mmm! Y-Yes, [player_name]! Lick my tits! Ah... Just like that!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:100
translate chinese SR3_we_home_end_couch_rep_70316717:

    # MC "(I wonder how Sara will react to me sucking on them.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:102
translate chinese SR3_we_home_end_couch_rep_496b593d:

    # MC "*Suck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:103
translate chinese SR3_we_home_end_couch_rep_910b7c78:

    # Sara "*GASP*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:104
translate chinese SR3_we_home_end_couch_rep_26bc4036:

    # MC "*Suuuck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:105
translate chinese SR3_we_home_end_couch_rep_d31f1bcc:

    # Sara "Wh-What are... Oooohhh! That’s soooo good!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:107
translate chinese SR3_we_home_end_couch_rep_48dcb775:

    # Sara "Mmm! My panties are soaking, [player_name]!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:108
translate chinese SR3_we_home_end_couch_rep_496b593d_1:

    # MC "*Suck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:109
translate chinese SR3_we_home_end_couch_rep_9431feb9:

    # Sara "*Gasp* Ooohh, yes! Mmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:111
translate chinese SR3_we_home_end_couch_rep_261adc9f:

    # Sara "Fuck, yes! Just like that! I want to feel you inside me, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:112
translate chinese SR3_we_home_end_couch_rep_617daf30:

    # MC "(She’s getting really horny now! It’s probably a good time for me to make my move on her pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:114
translate chinese SR3_we_home_end_couch_rep_f69dcaa4:

    # Sara "Hnnngg... Mmm... Wow... You’re the *pant* best!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:115
translate chinese SR3_we_home_end_couch_rep_496b593d_2:

    # MC "*Suck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:116
translate chinese SR3_we_home_end_couch_rep_ea907d5a:

    # Sara "(His lips feel so warm wrapped around my nipple like that.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:118
translate chinese SR3_we_home_end_couch_rep_6cd26bea:

    # Sara "Ooohh! Yes... suck on it! Ah! *Gasp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:119
translate chinese SR3_we_home_end_couch_rep_eba00c86:

    # MC "*SUCK*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:120
translate chinese SR3_we_home_end_couch_rep_6b3422a0:

    # Sara "Aaahh! I’m gonna cum! AAAHHHH!!!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:121
translate chinese SR3_we_home_end_couch_rep_0a12db9f:

    # Sara "Yeeeesssss! *Pant* Aaaaahhh!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:123
translate chinese SR3_we_home_end_couch_rep_6d64492e:

    # Sara "*Pant* *Pant*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:124
translate chinese SR3_we_home_end_couch_rep_000481ca:

    # MC "I’m gonna guess you’re ready for sex now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:125
translate chinese SR3_we_home_end_couch_rep_1aa1b18e:

    # Sara "Uh huh *pant* Wh-What made you *pant* think that? Haha..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:127
translate chinese SR3_we_home_end_couch_rep_4ef4b60c:

    # Sara "A-Are you sure I’m going to be wet enough?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:128
translate chinese SR3_we_home_end_couch_rep_ee015863:

    # MC "Well, you just came, so you’re going to be about as wet as you can possibly get."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:130
translate chinese SR3_we_home_end_couch_rep_73549b6d:

    # Sara "And it won’t hurt?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:132
translate chinese SR3_we_home_end_couch_rep_2cde5186:

    # Sara "I guess so... It's will be that weird feeling again only at the beginning? Am I right?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:133
translate chinese SR3_we_home_end_couch_rep_fe31887f:

    # MC "It will. But not much, and not for very long. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:135
translate chinese SR3_we_home_end_couch_rep_73f244c1:

    # Sara "*Sigh* Okay... I think I’m ready, [player_name]. Let’s do this."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:136
translate chinese SR3_we_home_end_couch_rep_ea376940:

    # MC "You’re going to be fine, Sara, I promise. Think about it, tens of millions of people are constantly going out and hooking up with each other every day via apps."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:138
translate chinese SR3_we_home_end_couch_rep_284958d7:

    # MC "People wouldn’t be doing that if sex was a really painful unpleasant experience, would they?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:140
translate chinese SR3_we_home_end_couch_rep_2c6917be:

    # MC "People wouldn't be doing that if sex wasn't an extremely pleasant experience, would they?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_couch_rep.rpy:141
translate chinese SR3_we_home_end_couch_rep_893fcbf5:

    # Sara "Y-Yeah, that makes sense. You’re right. I’m overthinking things. Okay, let’s do this."
    Sara ""

