﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:7
translate chinese CR4_NS3a_rep_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:8
translate chinese CR4_NS3a_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:9
translate chinese CR4_NS3a_rep_b6e665ab:

    # Caroline "*Whispered* Take your time and think about it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:12
translate chinese CR4_NS3a_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:14
translate chinese CR4_NS3a_rep_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:18
translate chinese CR4_NS3a_rep_bafd573f:

    # MC "How about we try cowgirl tonight?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:19
translate chinese CR4_NS3a_rep_ac209ad4:

    # Caroline "What about reverse cowgirl?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:20
translate chinese CR4_NS3a_rep_3ed720c0:

    # MC " Which one is that again?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:23
translate chinese CR4_NS3a_rep_2a77b0fb:

    # Caroline "Let me show you!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:24
translate chinese CR4_NS3a_rep_902a850c:

    # MC "Oh nice!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:25
translate chinese CR4_NS3a_rep_104a2133:

    # Caroline "Go ahead and slip your cock inside me. Pussy or ass. Your choice."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:31
translate chinese CR4_NS3a_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:32
translate chinese CR4_NS3a_rep_86d81d1e:

    # Caroline "Oh fuck, that’s the spot! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:33
translate chinese CR4_NS3a_rep_a05a09a3:

    # Caroline "Ah, go ahead and fuck me, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:36
translate chinese CR4_NS3a_rep_665d1551:

    # Caroline "Ah! Yes! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:37
translate chinese CR4_NS3a_rep_aec7d681:

    # Caroline "How does that feel for you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:40
translate chinese CR4_NS3a_rep_165b4b63:

    # MC "Mmm! It’s so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:41
translate chinese CR4_NS3a_rep_48746a35:

    # Caroline "Do you want me to start moving my hips?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:42
translate chinese CR4_NS3a_rep_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:45
translate chinese CR4_NS3a_rep_1d6b72c9:

    # Caroline "Ah! Ahh! Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:46
translate chinese CR4_NS3a_rep_3cbbd539:

    # MC "Mmmm! Fuck! That’s good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:47
translate chinese CR4_NS3a_rep_29a77369:

    # Caroline "Oh, my God! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:50
translate chinese CR4_NS3a_rep_cebc36da:

    # MC "Ride my cock, Caroline! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:52
translate chinese CR4_NS3a_rep_89dacc01:

    # Caroline "Ah! Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:54
translate chinese CR4_NS3a_rep_f0c13720:

    # MC "Mmmm! Faster!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:56
translate chinese CR4_NS3a_rep_cb044fb7:

    # Caroline "Ooohhh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:57
translate chinese CR4_NS3a_rep_8e74e1fc:

    # Caroline "(Holy fuck, his cock went so deep inside me... I’m so wet right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:58
translate chinese CR4_NS3a_rep_b7dd77bc:

    # MC "Don’t stop! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:61
translate chinese CR4_NS3a_rep_0b1188e0:

    # MC "Ah...Ohhhh... Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:62
translate chinese CR4_NS3a_rep_5ce9e729:

    # Caroline "Would you *gasp* like me to go faster?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:63
translate chinese CR4_NS3a_rep_8dd7f9fa:

    # MC "Yes, please!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:66
translate chinese CR4_NS3a_rep_4f067e1e:

    # MC "Oh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:67
translate chinese CR4_NS3a_rep_fcb49e6b:

    # Caroline "Hnnng... MMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:70
translate chinese CR4_NS3a_rep_f81e6c91:

    # Caroline "Your cock is so damn thick! Ugh! Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:71
translate chinese CR4_NS3a_rep_8a96add5:

    # MC "Keep riding me, Caroline! Ah! I love it!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:72
translate chinese CR4_NS3a_rep_9a2d713f:

    # MC "Mmm! Hnnngg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:75
translate chinese CR4_NS3a_rep_2fbf5885:

    # Caroline "I hope you’re Ahh... not going to cum on me yet!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:77
translate chinese CR4_NS3a_rep_73eb2535:

    # Caroline "I’m not finished ohh... riding you! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:79
translate chinese CR4_NS3a_rep_ea51c392:

    # MC "Faster! Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:81
translate chinese CR4_NS3a_rep_ff9b5571:

    # MC "Ah...Ohhhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:83
translate chinese CR4_NS3a_rep_361fb6a7:

    # MC "Faster! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:85
translate chinese CR4_NS3a_rep_a96a7af9:

    # Caroline "Ahhhh! AYAYAAAAHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:86
translate chinese CR4_NS3a_rep_01076d68:

    # MC "(Fuck, that was loud! I hope nobody else in the house heard us!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:87
translate chinese CR4_NS3a_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:90
translate chinese CR4_NS3a_rep_b810e8f1:

    # Caroline "Shit ah... sorry, I was too loud there, wasn’t I?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:91
translate chinese CR4_NS3a_rep_04438941:

    # MC "Just a little bit, haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:92
translate chinese CR4_NS3a_rep_83c24480:

    # Caroline "I’ll try and dial it down a notch. Let’s do regular cowgirl now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:95
translate chinese CR4_NS3a_rep_59da1b43:

    # Caroline "Mmm, you look so hot right there. I can’t wait to plant myself down on your fat cock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:96
translate chinese CR4_NS3a_rep_5f0b7527:

    # Caroline "I’m going to make you squirm beneath me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:99
translate chinese CR4_NS3a_rep_81279dbf:

    # Caroline "Hehe, you’re going to love the next few minutes."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:100
translate chinese CR4_NS3a_rep_a9e1ff9e:

    # MC "Oh, I’m sure I will."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:101
translate chinese CR4_NS3a_rep_0d6fdd07:

    # Caroline "God, you’re so handsome."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:104
translate chinese CR4_NS3a_rep_5580b6c9:

    # Caroline "Ah... Okay... Here we go!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:105
translate chinese CR4_NS3a_rep_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:106
translate chinese CR4_NS3a_rep_abb50074:

    # MC "(I can feel her vulva, wrapped around the tip of my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:109
translate chinese CR4_NS3a_rep_92e5645f:

    # MC "OOOHHH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:110
translate chinese CR4_NS3a_rep_edce70ef:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:111
translate chinese CR4_NS3a_rep_febea908:

    # Caroline "Ah... T-Try to keep your voice down, hehe!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:114
translate chinese CR4_NS3a_rep_b8c783cc:

    # Caroline "I... ah... oh... don’t want anyone interrupting mmm... us now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:115
translate chinese CR4_NS3a_rep_bfe279c7:

    # MC "Uh huh, sure, Caroline! Ahh.... Your pussy feels so fucking good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:118
translate chinese CR4_NS3a_rep_ca073a0c:

    # MC "Ugh! Just like that, Caroline! Keep bouncing on my cock!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:119
translate chinese CR4_NS3a_rep_a77dbc2d:

    # Caroline "Ah! Ahh! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:122
translate chinese CR4_NS3a_rep_c8023017:

    # MC "Ooohh! Fuck, I’m getting close!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:123
translate chinese CR4_NS3a_rep_7028a503:

    # Caroline "Mmm! Where do you want to cum, [player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:129
translate chinese CR4_NS3a_rep_971f5355:

    # MC "Don’t stop bouncing, Caroline! I want to cum inside you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:130
translate chinese CR4_NS3a_rep_9c10fa5b:

    # Caroline "Uh huh! Cum inside me! Fill me up, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:131
translate chinese CR4_NS3a_rep_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:134
translate chinese CR4_NS3a_rep_12fff763:

    # Caroline "Ayaaahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:135
translate chinese CR4_NS3a_rep_b204a169:

    # MC "Hnnnngg!!! UGH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:137
translate chinese CR4_NS3a_rep_9ccb3f7a:

    # Caroline "Cum inside your sister’s slutty pussy! Do it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:139
translate chinese CR4_NS3a_rep_6af7ba75:

    # Caroline "Cum inside your girlfriend’s slutty pussy! Do it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:140
translate chinese CR4_NS3a_rep_043fe09a:

    # MC "AAHAHHHHH! OHHHH!! FUCK!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:150
translate chinese CR4_NS3a_rep_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:151
translate chinese CR4_NS3a_rep_212ccf36:

    # Caroline "Hehe, did you enjoy that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:152
translate chinese CR4_NS3a_rep_a9cfe6fe:

    # MC "*Gasp* Y-Yeah, that was amazing, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:164
translate chinese CR4_NS3a_rep_15e43593:

    # MC "Get on your knees. I’ll cum over your face."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:165
translate chinese CR4_NS3a_rep_186fb669:

    # Caroline "Okay, two seconds."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:168
translate chinese CR4_NS3a_rep_dba9ac4c:

    # Caroline "Ready!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:169
translate chinese CR4_NS3a_rep_87aa9cff:

    # MC "Ugh! Ahh... Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:179
translate chinese CR4_NS3a_rep_16f751f8:

    # MC "Hnnnnggg! UGH! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:180
translate chinese CR4_NS3a_rep_907508e7:

    # Caroline "Oh wow! Almost got me in the eye, there! Hehe!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:181
translate chinese CR4_NS3a_rep_82ebae89:

    # MC "Oh... *Phew* That was amazing, Caroline. Thank you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:191
translate chinese CR4_NS3a_rep_6827cf7d:

    # MC "Mmm... I’ll fuck your ass tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:193
translate chinese CR4_NS3a_rep_b9c3643d:

    # Caroline "Oh fuck, that’s so tight!! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:194
translate chinese CR4_NS3a_rep_64db08d1:

    # Caroline "Just be slow ah... at first."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:197
translate chinese CR4_NS3a_rep_a6a0f037:

    # Caroline "Ohh... *Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:198
translate chinese CR4_NS3a_rep_aec7d681_1:

    # Caroline "How does that feel for you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:201
translate chinese CR4_NS3a_rep_a15ecf96:

    # MC "Mmm! It’s so good, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:202
translate chinese CR4_NS3a_rep_5ad88110:

    # Caroline "Do you want me to stop moving my hips?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:203
translate chinese CR4_NS3a_rep_5da849b6_1:

    # MC "Yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:206
translate chinese CR4_NS3a_rep_1d6b72c9_1:

    # Caroline "Ah! Ahh! Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:207
translate chinese CR4_NS3a_rep_3cbbd539_1:

    # MC "Mmmm! Fuck! That’s good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:208
translate chinese CR4_NS3a_rep_29a77369_1:

    # Caroline "Oh, my God! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:211
translate chinese CR4_NS3a_rep_cebc36da_1:

    # MC "Ride my cock, Caroline! Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:212
translate chinese CR4_NS3a_rep_89dacc01_1:

    # Caroline "Ah! Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:215
translate chinese CR4_NS3a_rep_cb044fb7_1:

    # Caroline "Ooohhh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:216
translate chinese CR4_NS3a_rep_dd8f6abd:

    # Caroline "(Holy fuck, his cock went so deep inside my ass... That feels... strangely pleasurable.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:217
translate chinese CR4_NS3a_rep_d594c161:

    # MC "Don’t stop! Hnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:220
translate chinese CR4_NS3a_rep_0b1188e0_1:

    # MC "Ah...Ohhhh... Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:221
translate chinese CR4_NS3a_rep_5ce9e729_1:

    # Caroline "Would you *gasp* like me to go faster?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:222
translate chinese CR4_NS3a_rep_8dd7f9fa_1:

    # MC "Yes, please!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:225
translate chinese CR4_NS3a_rep_4f067e1e_1:

    # MC "Oh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:226
translate chinese CR4_NS3a_rep_fcb49e6b_1:

    # Caroline "Hnnng... MMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:229
translate chinese CR4_NS3a_rep_f81e6c91_1:

    # Caroline "Your cock is so damn thick! Ugh! Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:230
translate chinese CR4_NS3a_rep_c407976a:

    # MC "Hnng! And your ass is soooo fucking tight, right now! Don’t stop riding me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:231
translate chinese CR4_NS3a_rep_9a2d713f_1:

    # MC "Mmm! Hnnngg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:234
translate chinese CR4_NS3a_rep_2fbf5885_1:

    # Caroline "I hope you’re Ahh... not going to cum on me yet!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:236
translate chinese CR4_NS3a_rep_73eb2535_1:

    # Caroline "I’m not finished ohh... riding you! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:238
translate chinese CR4_NS3a_rep_ea51c392_1:

    # MC "Faster! Caroline!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:240
translate chinese CR4_NS3a_rep_ff9b5571_1:

    # MC "Ah...Ohhhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:242
translate chinese CR4_NS3a_rep_361fb6a7_1:

    # MC "Faster! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:244
translate chinese CR4_NS3a_rep_a96a7af9_1:

    # Caroline "Ahhhh! AYAYAAAAHHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:245
translate chinese CR4_NS3a_rep_01076d68_1:

    # MC "(Fuck, that was loud! I hope nobody else in the house heard us!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:246
translate chinese CR4_NS3a_rep_43b8826f_2:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:249
translate chinese CR4_NS3a_rep_b810e8f1_1:

    # Caroline "Shit ah... sorry, I was too loud there, wasn’t I?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:250
translate chinese CR4_NS3a_rep_04438941_1:

    # MC "Just a little bit, haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:251
translate chinese CR4_NS3a_rep_83c24480_1:

    # Caroline "I’ll try and dial it down a notch. Let’s do regular cowgirl now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:254
translate chinese CR4_NS3a_rep_59da1b43_1:

    # Caroline "Mmm, you look so hot right there. I can’t wait to plant myself down on your fat cock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:255
translate chinese CR4_NS3a_rep_5f0b7527_1:

    # Caroline "I’m going to make you squirm beneath me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:258
translate chinese CR4_NS3a_rep_81279dbf_1:

    # Caroline "Hehe, you’re going to love the next few minutes."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:259
translate chinese CR4_NS3a_rep_a9e1ff9e_1:

    # MC "Oh, I’m sure I will."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:260
translate chinese CR4_NS3a_rep_0d6fdd07_1:

    # Caroline "God, you’re so handsome."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:263
translate chinese CR4_NS3a_rep_5580b6c9_1:

    # Caroline "Ah... Okay... Here we go!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:264
translate chinese CR4_NS3a_rep_ac6d5d68_1:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:265
translate chinese CR4_NS3a_rep_3ebd709b:

    # MC "(Her asshole is so damn tight! I don’t think I can last much longer! She’ll milk me dry!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:268
translate chinese CR4_NS3a_rep_92e5645f_1:

    # MC "OOOHHH!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:269
translate chinese CR4_NS3a_rep_edce70ef_1:

    # Caroline "MMMMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:270
translate chinese CR4_NS3a_rep_febea908_1:

    # Caroline "Ah... T-Try to keep your voice down, hehe!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:273
translate chinese CR4_NS3a_rep_69fc131e:

    # Caroline "I... ah... oh... don’t want anyone interrupting - mmm - us now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:274
translate chinese CR4_NS3a_rep_7cf5d8d8:

    # MC "Uh huh, sure! Ahh.... Your ass feels so good. I’m not hurting you, am I?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:275
translate chinese CR4_NS3a_rep_af8e4fbc:

    # Caroline "Ah, n-no. This is alright!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:278
translate chinese CR4_NS3a_rep_ca073a0c_1:

    # MC "Ugh! Just like that, Caroline! Keep bouncing on my cock!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:279
translate chinese CR4_NS3a_rep_a77dbc2d_1:

    # Caroline "Ah! Ahh! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:282
translate chinese CR4_NS3a_rep_c8023017_1:

    # MC "Ooohh! Fuck, I’m getting close!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:283
translate chinese CR4_NS3a_rep_0bfe3f7d:

    # Caroline "Mmm! Where do you want to cum, [player_name]"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:289
translate chinese CR4_NS3a_rep_da811175:

    # MC "Don’t stop bouncing, Caroline! I want to cum inside your ass!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:290
translate chinese CR4_NS3a_rep_9c10fa5b_1:

    # Caroline "Uh huh! Cum inside me! Fill me up, [player_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:291
translate chinese CR4_NS3a_rep_d174ea9d_1:

    # MC "Hnnng..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:294
translate chinese CR4_NS3a_rep_12fff763_1:

    # Caroline "Ayaaahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:295
translate chinese CR4_NS3a_rep_b204a169_1:

    # MC "Hnnnngg!!! UGH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:297
translate chinese CR4_NS3a_rep_063f678f:

    # Caroline "Cum inside your sister’s slutty ass! Do it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:299
translate chinese CR4_NS3a_rep_448da1bf:

    # Caroline "Cum inside your girlfriend’s slutty ass! Do it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:300
translate chinese CR4_NS3a_rep_043fe09a_1:

    # MC "AAHAHHHHH! OHHHH!! FUCK!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:310
translate chinese CR4_NS3a_rep_2f7b3b4b_1:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:311
translate chinese CR4_NS3a_rep_212ccf36_1:

    # Caroline "Hehe, did you enjoy that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:312
translate chinese CR4_NS3a_rep_a9cfe6fe_1:

    # MC "*Gasp* Y-Yeah, that was amazing, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:324
translate chinese CR4_NS3a_rep_15e43593_1:

    # MC "Get on your knees. I’ll cum over your face."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:325
translate chinese CR4_NS3a_rep_186fb669_1:

    # Caroline "Okay, two seconds."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:328
translate chinese CR4_NS3a_rep_dba9ac4c_1:

    # Caroline "Ready!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:329
translate chinese CR4_NS3a_rep_87aa9cff_1:

    # MC "Ugh! Ahh... Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:340
translate chinese CR4_NS3a_rep_16f751f8_1:

    # MC "Hnnnnggg! UGH! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:341
translate chinese CR4_NS3a_rep_907508e7_1:

    # Caroline "Oh wow! Almost got me in the eye, there! Hehe!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:342
translate chinese CR4_NS3a_rep_82ebae89_1:

    # MC "Oh... *Phew* That was amazing, Caroline. Thank you."
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:125
    old "Don’t stop bouncing! I want to cum inside you!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:125
    old "Get on your knees. I’ll cum on your face."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_NS3a_rep.rpy:285
    old "Don’t stop bouncing! I want to cum inside your ass!"
    new ""

