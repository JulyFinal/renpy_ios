﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:18
translate chinese MLR3_AS3_rep_746f9efb:

    # MC "(Huh? What’s [Mom_name] doing in my room? She almost never comes in here when I’m not around.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:19
translate chinese MLR3_AS3_rep_2f83c104:

    # MC "(She must have something really important bothering her. Come to think of it, she’s looking a little anxious there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:20
translate chinese MLR3_AS3_rep_f75128cf:

    # MC "(Shit! I wonder if I’ve done something wrong in the past few days, to upset her?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:24
translate chinese MLR3_AS3_rep_1b7efb81:

    # Mom "Hi, [player_name]. We need to talk."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:25
translate chinese MLR3_AS3_rep_dee53d11:

    # MC "(Fuck... This could be worse than I expected. I wonder what the hell is going on?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:26
translate chinese MLR3_AS3_rep_88176837:

    # MC "Y-Yeah, no problem, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:30
translate chinese MLR3_AS3_rep_0fd9d703:

    # Mom "Sit down beside me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:32
translate chinese MLR3_AS3_rep_274d29b3:

    # MC "Are you alright, [Mom_name]?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:34
translate chinese MLR3_AS3_rep_f312a74f:

    # MC "Are you alright?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:35
translate chinese MLR3_AS3_rep_4dd97e3a:

    # Mom "I think so... maybe. Sorry, that’s why I had to do this in your room. I needed to guarantee that we had some privacy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:39
translate chinese MLR3_AS3_rep_7f01a04c:

    # Mom "Listen, [player_name]... You know that I really care about you. Don’t you?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:40
translate chinese MLR3_AS3_rep_bc3cad83:

    # MC "Yeah, of course I know that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:42
translate chinese MLR3_AS3_rep_391eaaab:

    # Mom "I know we’ve done a lot of stuff together. Especially late at night, when your father is asleep."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:44
translate chinese MLR3_AS3_rep_af6ad3fd:

    # Mom "I know we’ve done a lot of stuff together. Especially late at night when my husband is asleep."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:48
translate chinese MLR3_AS3_rep_56875714:

    # Mom "I just wanted to say... sorry."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:49
translate chinese MLR3_AS3_rep_65d0e1e7:

    # MC "Sorry? What for, [Mom_name]? You’ve done nothing wrong."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:50
translate chinese MLR3_AS3_rep_cebe88b7:

    # Mom "You probably feel like I’m just using you for sex."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:52
translate chinese MLR3_AS3_rep_0a8fe2a0:

    # Mom "We don’t get to go on dates that often, and the only time we get to spend together is wasted on quickies, with the threat of your father walking in on us."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:54
translate chinese MLR3_AS3_rep_726ef69c:

    # Mom "We don’t get to go on dates that often, and the only time we get to spend together is wasted on quickies, with the threat of my husband walking in on us."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:58
translate chinese MLR3_AS3_rep_a5e55a1b:

    # Mom "I get so turned on when I’m around you. I just want to screw you silly, each time I get close to you..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:59
translate chinese MLR3_AS3_rep_9a4a02e0:

    # Mom "...but we never get to go on romantic dates or anything, because of the nature of our relationship."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:60
translate chinese MLR3_AS3_rep_2570a8c7:

    # MC "[Mom_name]! We went to that restaurant together, remember?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:64
translate chinese MLR3_AS3_rep_eea7e310:

    # Mom "Yeah, and where else?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:65
translate chinese MLR3_AS3_rep_03dc33ca:

    # MC "Umm... The beach house?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:66
translate chinese MLR3_AS3_rep_8c095b98:

    # Mom "Two dates, [player_name]. I’ve made you cum, more times than we’ve gone out somewhere together - romantically."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:67
translate chinese MLR3_AS3_rep_619bfe0a:

    # Mom "I’ve come to the realisation, that I’m using you like a sex toy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:71
translate chinese MLR3_AS3_rep_d727638a:

    # MC "What?! No, you’re not, [Mom_name]!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:72
translate chinese MLR3_AS3_rep_366460bd:

    # Mom "I am. I need to start treating you like an actual other half in a relationship. That means giving you time, that isn’t just about us having sex."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:73
translate chinese MLR3_AS3_rep_2d28ee0e:

    # Mom "I don’t want to leave you feeling like I’m using you... because, if you feel that way, I know you’ll end up leaving me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:80
translate chinese MLR3_AS3_rep_33a0b673:

    # MC "[Mom_name]! I don’t feel that way and I’d NEVER do that! I love you more than you know."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:81
translate chinese MLR3_AS3_rep_35741d97:

    # Mom "Really?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:82
translate chinese MLR3_AS3_rep_b0038d87:

    # MC "I swear on my life! I don't believe you're taking advantage of me. Certainly, I'd love to spend more quality time together, but I understand that it's challenging at the moment, with [Dad_name] in the picture."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:86
translate chinese MLR3_AS3_rep_e16171ce:

    # Mom "Thank you, Sweetie. I appreciate you understanding."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:87
translate chinese MLR3_AS3_rep_08a11b48:

    # Mom "I promise you, someday I’m gonna make this right. I’m gonna find a way to spend more time together."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:88
translate chinese MLR3_AS3_rep_f9174ba2:

    # MC "Don’t put pressure on yourself, [Mom_name]. We’ll work through this. All you need to know, right now, is that I don’t feel used."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:92
translate chinese MLR3_AS3_rep_adb89e33:

    # Mom "You’re so understanding and mature. I’m lucky that I snapped you up before you started dating someone."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:93
translate chinese MLR3_AS3_rep_f2db8f27:

    # Mom "You’re a real catch, you know that?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:94
translate chinese MLR3_AS3_rep_8a9fe064:

    # MC "Aww, thanks, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:98
translate chinese MLR3_AS3_rep_77de2022:

    # Mom "Anyway, now that I’m no longer worried about you leaving me, let’s move on to something else."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:99
translate chinese MLR3_AS3_rep_926ded6c:

    # Mom "How’s college going? I don’t feel like I’ve asked you that in quite a while."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:100
translate chinese MLR3_AS3_rep_99b17fe6:

    # MC "Eh, not too bad. You can take a look at my current projects, over on my desk."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:104
translate chinese MLR3_AS3_rep_c18ebfad:

    # Mom "Over here?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:105
translate chinese MLR3_AS3_rep_a68a3737:

    # MC "Yeah, you see those two red folders to the right? That’s what I’m working on right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:106
translate chinese MLR3_AS3_rep_1f701f76:

    # Mom "Yuck... this takes me back to my days in University."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:109
translate chinese MLR3_AS3_rep_46a68f33:

    # Mom "I used to hate revising. During the exam period my mom would ALWAYS yap at me: “Why aren’t you studying?! Why can’t you be more like Liza?!”"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:110
translate chinese MLR3_AS3_rep_48c1555d:

    # Mom "Liza worked her ass off, locked herself away in her bedroom, and did nothing but work."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:111
translate chinese MLR3_AS3_rep_700cc5a4:

    # Mom "Meanwhile, I procrastinated and delayed..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:115
translate chinese MLR3_AS3_rep_6144db2f:

    # Mom "At the end of the day, Liza got the better grades - but I got the better job. Grades aren’t everything, [player_name]."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:116
translate chinese MLR3_AS3_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:117
translate chinese MLR3_AS3_rep_a816c3c8:

    # Mom "Sure, they’re important, but there are lots of other things that can affect your chances of success in life."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:121
translate chinese MLR3_AS3_rep_473ca45e:

    # Mom "Confidence, maturity, emotional intelligence, and empathy - to name a few."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:122
translate chinese MLR3_AS3_rep_9c503f94:

    # Mom "And you’ve got an abundance of all of those. You’ll do just fine."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:123
translate chinese MLR3_AS3_rep_56a74cb8:

    # Mom "How are your grades, by the way?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:127
translate chinese MLR3_AS3_rep_f4b5d4d5:

    # MC "Not too bad. I’m slightly above average."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:128
translate chinese MLR3_AS3_rep_dee96b05:

    # Mom "That’s fine by me."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:129
translate chinese MLR3_AS3_rep_5b5b78d4:

    # MC "(Hmm... Let’s see if I can spice things up here. Should I grab her ass or her breasts?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:137
translate chinese MLR3_AS3_rep_249202f0:

    # MC "(Hehe, I bet she never saw this one coming!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:138
translate chinese MLR3_AS3_rep_be53a089:

    # Mom "Oh my!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:139
translate chinese MLR3_AS3_rep_f64b33af:

    # MC "Sorry, [Mom_name], I couldn’t resist!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:143
translate chinese MLR3_AS3_rep_0d360fbf:

    # Mom "You couldn’t resist grabbing my ass? Well, at least you understand how I feel about you, now. I can’t resist toying with you, every time we meet."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:144
translate chinese MLR3_AS3_rep_922c6816:

    # Mom "You’ve got a good firm grip there... Now you’ve gone and turned me on again!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:151
translate chinese MLR3_AS3_rep_ab4aa3da:

    # MC "([Mom_name]’s breasts are amazing! There’s nothing better than groping a huge pair of tits like this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:152
translate chinese MLR3_AS3_rep_62f55e35:

    # Mom "Ohh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:156
translate chinese MLR3_AS3_rep_39d4a412:

    # Mom "My my... someone is horny!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:157
translate chinese MLR3_AS3_rep_f810502e:

    # MC "Sorry, [Mom_name]. I couldn’t hold myself back. Your tits are awesome!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:162
translate chinese MLR3_AS3_con2_rep_9343346c:

    # Mom "Well, if you’re horny, that’s a problem - and Mommy is going to have to do something about that!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:164
translate chinese MLR3_AS3_con2_rep_684c5ad3:

    # Mom "Well, if you’re horny, that’s a problem - I have to do something about that!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:165
translate chinese MLR3_AS3_con2_rep_bacf2c20:

    # MC "Mmm... what are you suggesting?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:166
translate chinese MLR3_AS3_con2_rep_63edf347:

    # Mom "I’m thinking that you deserve a good sloppy blowjob."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:170
translate chinese MLR3_AS3_con2_rep_231ce836:

    # MC "Mmm, I like the sound of that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:172
translate chinese MLR3_AS3_con2_rep_00938f05:

    # Mom "I think your father is out right now, so we have a little bit of privacy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:174
translate chinese MLR3_AS3_con2_rep_b43e0c2c:

    # Mom "I think Bob is out right now, so we have a little bit of privacy."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:175
translate chinese MLR3_AS3_con2_rep_a03abdff:

    # MC "That’s a relief."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:177
translate chinese MLR3_AS3_con2_rep_1f633602:

    # Mom "Go ahead and pull your pants down. Just lie back and relax. Let Mommy take care of all the work."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:179
translate chinese MLR3_AS3_con2_rep_87ba7b94:

    # Mom "Go ahead and pull your pants down. Just lie back and relax. Let me take care of all the work."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:183
translate chinese MLR3_AS3_con2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:184
translate chinese MLR3_AS3_con2_rep_5db0f1ae:

    # Mom "I shouldn’t be surprised that you’re already hard. You’ve got such a nice cock, you know that?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:185
translate chinese MLR3_AS3_con2_rep_7cc461cf:

    # Mom "It’s so long and thick."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:190
translate chinese MLR3_AS3_con2_rep_78521e0d:

    # Mom "(God, I miss the feeling of this, plunging into my pussy.)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:191
translate chinese MLR3_AS3_con2_rep_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:194
translate chinese MLR3_AS3_con2_rep_a5868d30:

    # Mom "*Shlurp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:195
translate chinese MLR3_AS3_con2_rep_f1e73f4a:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:197
translate chinese MLR3_AS3_con2_rep_d4492164:

    # MC "Ugh... fuck, this is good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:198
translate chinese MLR3_AS3_con2_rep_539bc65f:

    # Mom "*SUCK SUCK*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:203
translate chinese MLR3_AS3_con2_rep_3a0f3c6b:

    # MC "(I love it when she uses her hand and mouth at the same time.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:204
translate chinese MLR3_AS3_con2_rep_6b1860aa:

    # MC "Ah... Yes, just like that, [Mom_name]. Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:205
translate chinese MLR3_AS3_con2_rep_e369d768:

    # MC "Ugh! Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:209
translate chinese MLR3_AS3_con2_rep_b5ea5d19:

    # Mom "*Shluuuurrrrrp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:211
translate chinese MLR3_AS3_con2_rep_509c6612:

    # MC " Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:212
translate chinese MLR3_AS3_con2_rep_98db7d51:

    # MC "(She’s rolling her tongue around the tip. Fuck... this is indescribable.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:216
translate chinese MLR3_AS3_con2_rep_585db196:

    # Mom "Do you want me to try deepthroating you?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:217
translate chinese MLR3_AS3_con2_rep_ba4991a2:

    # MC "Oh yeah, that sounds great!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:218
translate chinese MLR3_AS3_con2_rep_322324ad:

    # Mom "Okay, here we go. I might gag a bit, but don’t worry about that - just relax and enjoy this."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:222
translate chinese MLR3_AS3_con2_rep_2fd0aebf:

    # MC "Okay, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:223
translate chinese MLR3_AS3_con2_rep_82fa6ad1:

    # MC "(Damn, I wish she would just pull her pants off right now and ride me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:227
translate chinese MLR3_AS3_con2_rep_f1e73f4a_1:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:228
translate chinese MLR3_AS3_con2_rep_943f6908:

    # MC "Ah... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:229
translate chinese MLR3_AS3_con2_rep_c240ab14:

    # MC "(Fuck me, this is heavenly.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:233
translate chinese MLR3_AS3_con2_rep_f21b6d9e:

    # Mom "*SHLURRRP*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:234
translate chinese MLR3_AS3_con2_rep_5fd9db6d:

    # Mom "*GAG* *COUGH*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:235
translate chinese MLR3_AS3_con2_rep_2c65e1ff:

    # MC "Hnnng! Ugh! Oh yes! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:239
translate chinese MLR3_AS3_con2_rep_f1e73f4a_2:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:241
translate chinese MLR3_AS3_con2_rep_e06a5f61:

    # MC "Ah... Yes, [Mom_name]! Just like that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:243
translate chinese MLR3_AS3_con2_rep_fedf03e5:

    # MC "Ah... Yes! Just like that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:244
translate chinese MLR3_AS3_con2_rep_c1d3b7fe:

    # MC "I want you to go deeper! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:248
translate chinese MLR3_AS3_con2_rep_b5886106:

    # MC "Ah... Yes... just like that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:250
translate chinese MLR3_AS3_con2_rep_539bc65f_1:

    # Mom "*SUCK SUCK*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:251
translate chinese MLR3_AS3_con2_rep_666ad2b6:

    # MC "Mmm! Yes! Yes, [Mom_name]!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:255
translate chinese MLR3_AS3_con2_rep_01d26843:

    # Mom "*GAG!* *SPLUTTER*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:257
translate chinese MLR3_AS3_con2_rep_cfcb85df:

    # MC "Hnnng! Ohhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:258
translate chinese MLR3_AS3_con2_rep_61836a3a:

    # MC "(I can feel my dick, slipping down her tight throat! This is fucking incredible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:262
translate chinese MLR3_AS3_con2_rep_60b35f42:

    # MC "Fuck... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:263
translate chinese MLR3_AS3_con2_rep_161c4629:

    # MC "(This is so hot - I just wish [Mom_name] wasn’t wearing so many clothes.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:264
translate chinese MLR3_AS3_con2_rep_ceb4c203:

    # MC "(I wonder if she’d mind me stripping some off her? Probably not!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:268
translate chinese MLR3_AS3_con2_rep_3fc030ac:

    # MC "(Let’s go for her trousers - it’ll be easier to take those off without interrupting her blowjob.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:269
translate chinese MLR3_AS3_con2_rep_77276512:

    # MC "(If I go for her shirt then she’s gonna have to stop while I pull it over her head.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:270
translate chinese MLR3_AS3_con2_rep_f1e73f4a_3:

    # Mom "*Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:274
translate chinese MLR3_AS3_con2_rep_3ab8f52a:

    # MC "(Goddamn, she’s good with her lips.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:275
translate chinese MLR3_AS3_con2_rep_1e1e3d97:

    # Mom "*Shluuurrrp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:276
translate chinese MLR3_AS3_con2_rep_9c9667c1:

    # MC "Ohh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:280
translate chinese MLR3_AS3_con2_rep_f61ca0f8:

    # Mom "*Suck Suck* Hmm?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:281
translate chinese MLR3_AS3_con2_rep_839a9fa5:

    # Mom "(Looks like he wants to play with my ass, while I suck him off! Nothing wrong with that!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:282
translate chinese MLR3_AS3_con2_rep_cecbe5cc:

    # MC "Mmm, you’re not wearing any panties, [Mom_name]!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:286
translate chinese MLR3_AS3_con2_rep_cf921134:

    # MC "Fuck, your ass is great."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:287
translate chinese MLR3_AS3_con2_rep_539bc65f_2:

    # Mom "*SUCK SUCK*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:288
translate chinese MLR3_AS3_con2_rep_8c9ffff6:

    # MC "Ahh... Ugh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:292
translate chinese MLR3_AS3_con2_rep_307c97e1:

    # MC "I’d love to plunge my cock, deep into you right now. Just throw you down on the bed, or up against the wall, and take you from behind."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:293
translate chinese MLR3_AS3_con2_rep_fbcbf21e:

    # MC "Ah... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:294
translate chinese MLR3_AS3_con2_rep_c80169ce:

    # Mom "(You have NO IDEA how much I want that too!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:298
translate chinese MLR3_AS3_con2_rep_597a0286:

    # Mom "*Gasp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:299
translate chinese MLR3_AS3_con2_rep_15545bb3:

    # Mom "Are you close to cumming?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:300
translate chinese MLR3_AS3_con2_rep_9946f970:

    # MC "Yeah, not far off it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:301
translate chinese MLR3_AS3_con2_rep_2c6b50d8:

    # Mom "Okay, I want you to cum in my mouth. I want to taste your, hot virile cum, on my tongue."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:305
translate chinese MLR3_AS3_con2_rep_913c8148:

    # Mom "*Suck Suck Suck*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:306
translate chinese MLR3_AS3_con2_rep_316167fc:

    # MC "Mmm! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:307
translate chinese MLR3_AS3_con2_rep_d68c043e:

    # MC "(She’s sped up now! I’m not gonna last long, if she keeps up this pace!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:312
translate chinese MLR3_AS3_con2_rep_b136258c:

    # Mom "*GAG* *SHLUUURRRRP*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:313
translate chinese MLR3_AS3_con2_rep_485274a8:

    # MC "OHHH! FUCK! Yessss!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:314
translate chinese MLR3_AS3_con2_rep_f617a09e:

    # MC "I’m cumming, [Mom_name]! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:318
translate chinese MLR3_AS3_con2_rep_33352a1e:

    # MC "Hnnnnggg! Ugh! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:326
translate chinese MLR3_AS3_con2_rep_d0fd4ec9:

    # MC "(Fuck, it feels so good, blowing my load in her mouth. It reminds me of how amazing it felt, to cum in her tight pussy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:327
translate chinese MLR3_AS3_con2_rep_1b634a21:

    # Mom "Mmm! (It tastes so good...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:328
translate chinese MLR3_AS3_con2_rep_e90bae89:

    # Mom "*Gulp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:333
translate chinese MLR3_AS3_con2_rep_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:334
translate chinese MLR3_AS3_con2_rep_b1098dea:

    # MC "Fuck...That was amazing. Thanks, [Mom_name]."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:335
translate chinese MLR3_AS3_con2_rep_e90bae89_1:

    # Mom "*Gulp*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:343
translate chinese MLR3_AS3_con2_rep_48c1e588:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:344
translate chinese MLR3_AS3_con2_rep_c8e27c2a:

    # MC "Footsteps?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:346
translate chinese MLR3_AS3_con2_rep_2fc8014a:

    # Mom "Shit! Your dad isn’t supposed to be home yet - pull your pants up!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:348
translate chinese MLR3_AS3_con2_rep_d9a54d47:

    # Mom "Shit! My husband isn’t supposed to be home yet - pull your pants up!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:351
translate chinese MLR3_AS3_con2_rep_7d8e4bdb:

    # MC "(Fuck fuck fuck!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:352
translate chinese MLR3_AS3_con2_rep_c771ee54:

    # Mom "(Shit! Fucking shit!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:357
translate chinese MLR3_AS3_con2_rep_48c1e588_1:

    # "*Creak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:359
translate chinese MLR3_AS3_con2_rep_a890ede8:

    # Caroline "Hey, [player_name]! I’ve run out of white paper. Can I steal some of yours?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:360
translate chinese MLR3_AS3_con2_rep_b00bfb03:

    # MC "Y-Yeah, s-sure!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:361
translate chinese MLR3_AS3_con2_rep_1bfa031c:

    # Caroline "Is everything okay? You seem nervous."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:365
translate chinese MLR3_AS3_con2_rep_8aa2644a:

    # MC "Uh... Y-Yeah, the paper is over there, on my desk."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:366
translate chinese MLR3_AS3_con2_rep_528440d7:

    # Caroline "No problem. Hi, [Mom_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:367
translate chinese MLR3_AS3_con2_rep_aa9cbd72:

    # Mom "Mmm hmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:371
translate chinese MLR3_AS3_con2_rep_d62cf188:

    # Mom "(Shit, I’ve still got some of [player_name]’s cum in my mouth!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:372
translate chinese MLR3_AS3_con2_rep_8ebc5003:

    # Mom "(Please, please, please, don’t notice...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:373
translate chinese MLR3_AS3_con2_rep_9d75ed85:

    # Caroline "Anyway, sorry for interrupting you two. I won’t be a minute!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:377
translate chinese MLR3_AS3_con2_rep_8c81a365:

    # Caroline "Do you mind if I steal a pen as well? I think mine’s about to run dry on me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:378
translate chinese MLR3_AS3_con2_rep_385cbf91:

    # MC "Yeah, go ahead."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:379
translate chinese MLR3_AS3_con2_rep_3eeaf32f:

    # MC "(Thank God we both got our pants back on in time. We came THIS CLOSE, to blowing the gig!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:383
translate chinese MLR3_AS3_con2_rep_b67eda21:

    # Mom "I’m gonna go and prepare dinner. I’ll see you both later on."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:384
translate chinese MLR3_AS3_con2_rep_be7fb864:

    # Caroline "Bye, [Mom_name]!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:385
translate chinese MLR3_AS3_con2_rep_903560e8:

    # MC "S-See ya, later!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:386
translate chinese MLR3_AS3_con2_rep_82886f8d:

    # MC "(Phew... That was FAR too close!)"
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:131
    old "Grab [Mom_name]’s ass."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/MLR3_AS3_rep.rpy:131
    old "Grab [Mom_name]’s breasts."
    new ""

