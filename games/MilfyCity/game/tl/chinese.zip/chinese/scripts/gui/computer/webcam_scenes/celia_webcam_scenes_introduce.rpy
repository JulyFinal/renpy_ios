﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:47
translate chinese celia_webcam_scenes_5976b66e:

    # MC "(Oh God... she’s online! My heart is racing!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:64
translate chinese celia_webcam_evening_scene1_v1_label_09660990:

    # MC "(Okay, I better make sure my webcam is covered up.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:75
translate chinese celia_webcam_evening_scene1_v1_label2_7b361398:

    # Celia "Hello?! Is this thing on?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:77
translate chinese celia_webcam_evening_scene1_v1_label2_c20cf8fd:

    # MC "(I better try using a deeper voice than usual.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:79
translate chinese celia_webcam_evening_scene1_v1_label2_8e799bed:

    # MC "(Wow! She’s REALLY playing her part! I should probably keep up my acting as well!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:80
translate chinese celia_webcam_evening_scene1_v1_label2_21a94f3d:

    # MC "I see you got my letter, Ms. Celia."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:81
translate chinese celia_webcam_evening_scene1_v1_label2_6904b98e:

    # Celia "I don’t know who the HELL you think you are, but when I find you, I will beat the crap out of you!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:84
translate chinese celia_webcam_evening_scene1_v1_label2_0d47171a:

    # Celia "And where the hell are you?! Turn your webcam on, you coward!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:85
translate chinese celia_webcam_evening_scene1_v1_label2_bb2541c4:

    # Celia "If you’re going to threaten me, then at least show me your face, while you do it!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:86
translate chinese celia_webcam_evening_scene1_v1_label2_7626d4db:

    # MC "I won’t be doing that, Ms. Celia."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:87
translate chinese celia_webcam_evening_scene1_v1_label2_efbbdf73:

    # Celia "Fine! Then I’m going."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:90
translate chinese celia_webcam_evening_scene1_v1_label2_14d2e5e5:

    # MC "You can walk away - but if you do, I will publish the picture of you selling grades, on social media."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:91
translate chinese celia_webcam_evening_scene1_v1_label2_3e0eaf0a:

    # Celia "(Nice... Is [player_name] better than I thought?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:92
translate chinese celia_webcam_evening_scene1_v1_label2_1bc6d1b9:

    # MC "And I won't stop there. I’ll make sure the Dean gets a copy, as well as the police."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:93
translate chinese celia_webcam_evening_scene1_v1_label2_aec4ac58:

    # MC "You’re a corrupt woman, Ms. Celia. And now you will have to pay the price."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:97
translate chinese celia_webcam_evening_scene1_v1_label2_2403ad8d:

    # Celia "God dammit... What do you want from me?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:99
translate chinese celia_webcam_evening_scene1_v1_label2_ff3e18f0:

    # Celia "God dammit... What do you want from me? (Mmm... I’m so fucking wet with anticipation right now. I wonder what [player_name] is going to make me do?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:100
translate chinese celia_webcam_evening_scene1_v1_label2_dfb47ad4:

    # MC "Not too much. I only have a couple of demands."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:101
translate chinese celia_webcam_evening_scene1_v1_label2_452dbd79:

    # MC "Firstly, I want to chat with you every evening. Let’s make this a regular thing."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:102
translate chinese celia_webcam_evening_scene1_v1_label2_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:104
translate chinese celia_webcam_evening_scene1_v1_label2_91af9da5:

    # Celia "Ugh! Fine! (It’s not like I have a choice..)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:106
translate chinese celia_webcam_evening_scene1_v1_label2_f3fee161:

    # Celia "Ugh! Fine! (My panties are soaked right now!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:107
translate chinese celia_webcam_evening_scene1_v1_label2_ab29547b:

    # Celia "And your second demand?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:108
translate chinese celia_webcam_evening_scene1_v1_label2_0ba108b6:

    # MC "I want you to strip down to your underwear. Lose the grey dress."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:112
translate chinese celia_webcam_evening_scene1_v1_label2_6b38993c:

    # Celia "WHAT?! I swear to God, I will find out who you are, you fucking pervert!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:114
translate chinese celia_webcam_evening_scene1_v1_label2_b914bfd8:

    # Celia "WHAT?! YOU FUCKING PERVERT!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:115
translate chinese celia_webcam_evening_scene1_v1_label2_10d19f96:

    # MC "That’s hardly the proper way to talk to the guy, who holds enough evidence to get you fired from your job."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:116
translate chinese celia_webcam_evening_scene1_v1_label2_318a6694:

    # MC "Now, how about you take that dress off, before I get in touch with the Dean?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:117
translate chinese celia_webcam_evening_scene1_v1_label2_868633fe_1:

    # Celia "..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:120
translate chinese celia_webcam_evening_scene1_v1_label2_c2f9eed1:

    # MC "Mmm... Nice ass, Ms. Celia."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:121
translate chinese celia_webcam_evening_scene1_v1_label2_fb72e137:

    # Celia "Fuck you..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:122
translate chinese celia_webcam_evening_scene1_v1_label2_626d6236:

    # MC "(Damn, Ms. Celia has a REALLY nice ass! Maybe I’ll get to fuck it someday?)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:125
translate chinese celia_webcam_evening_scene1_v1_label2_c6e8044e:

    # MC "(Mmm! And nice tits too! I can’t wait to see her without her bra on.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:126
translate chinese celia_webcam_evening_scene1_v1_label2_df412237:

    # MC "(I should probably wait until later on though - I should follow Judy’s advice, and take things in gradual steps.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:129
translate chinese celia_webcam_evening_scene1_v1_label2_891251ee:

    # Celia "Well? That’s my dress off. What do you want now, you pervert?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:130
translate chinese celia_webcam_evening_scene1_v1_label2_20186a82:

    # MC "That’s enough for tonight. I just wanted you to know who holds the power here."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:131
translate chinese celia_webcam_evening_scene1_v1_label2_70efb96d:

    # MC "We’re going to chat again, tomorrow night. I’d like to see you in your underwear, when we begin chatting."
    MC ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:133
translate chinese celia_webcam_evening_scene1_v1_label2_b3eb96a5:

    # Celia "(Fuck... I need to figure out who this creep is, or I’m in serious shit.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:135
translate chinese celia_webcam_evening_scene1_v1_label2_16509e76:

    # Celia "(God, this is so exciting! I wonder what he’s going to make me do next...) "
    Celia ""

# game/scripts/gui/computer/webcam_scenes/celia_webcam_scenes_introduce.rpy:136
translate chinese celia_webcam_evening_scene1_v1_label2_0b03457c:

    # MC "See you tomorrow, beautiful."
    MC ""

