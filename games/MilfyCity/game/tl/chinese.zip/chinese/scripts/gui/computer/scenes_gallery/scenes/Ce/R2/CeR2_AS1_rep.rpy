﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:12
translate chinese CeR2_AS1_rep_06d7f1f5:

    # MC "(There it is in all it’s glory. Excuse the pun.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:13
translate chinese CeR2_AS1_rep_adef43ae:

    # MC "(In a few minutes time I’m going to have that arrogant bitch, on her knees with her lips wrapped tightly around my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:14
translate chinese CeR2_AS1_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:16
translate chinese CeR2_AS1_rep_b9b23b8d:

    # MC "Mwahahaha..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:18
translate chinese CeR2_AS1_rep_7d03ea45:

    # MC "(I knew revenge would be fun, but I never realised it could be THIS sweet.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:20
translate chinese CeR2_AS1_rep_bf772099:

    # MC "(Heh, I knew this fantasy would be fun, but I never realised it would be THIS hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:22
translate chinese CeR2_AS1_rep_bb6ed167:

    # MC "(Now, I better get myself prepared for when Ms. Celia arrives.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:23
translate chinese CeR2_AS1_rep_eb13f056:

    # MC "(I’ll slip my pants down while I wait for her.) "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:26
translate chinese CeR2_AS1_rep_b9b8e06d:

    # "*Creeeaaak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:27
translate chinese CeR2_AS1_rep_5afe872f:

    # MC "(That’s the toilet door opening! She must have finally arrived!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:28
translate chinese CeR2_AS1_rep_c5ae3ffd:

    # MC "(I can hear some footsteps crossing the floor. Hopefully they belong to her.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:30
translate chinese CeR2_AS1_rep_6f050731:

    # "*Clunk*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:31
translate chinese CeR2_AS1_rep_76d3af95:

    # MC "(And the cubicle door to my right just closed!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:33
translate chinese CeR2_AS1_rep_f3fde3ae:

    # Celia "(Ugh... fuck me.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:34
translate chinese CeR2_AS1_rep_4aac19e5:

    # Celia "(Why are men’s toilets always so fucking gross?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:35
translate chinese CeR2_AS1_rep_509e8344:

    # Celia "(I suppose I should say something to let him know that I’ve arrived.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:36
translate chinese CeR2_AS1_rep_9d498901:

    # Celia "*Ahem* I’m here."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:38
translate chinese CeR2_AS1_rep_a79a9289:

    # MC "(And that’s my cue!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:40
translate chinese CeR2_AS1_rep_9db02654:

    # MC "(This will teach you to humiliate me like that in public, Ms. Celia!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:42
translate chinese CeR2_AS1_rep_69a30b9d:

    # MC "(Let's assess your teaching skills in other subjects with this! Hehe! Ms. Celia!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:44
translate chinese CeR2_AS1_rep_7f1ea0e7:

    # Celia "Ugh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:46
translate chinese CeR2_AS1_rep_3c656ae6:

    # Celia "(A tiny part of me was hoping that the blackmailer was only joking.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:47
translate chinese CeR2_AS1_rep_179a28e8:

    # Celia "(I guess I knew deep down that he was telling the truth though. I’m going to have to suck some random stranger’s cock.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:49
translate chinese CeR2_AS1_rep_53bdf525:

    # Celia "(Ugh, I’ve nerver used a glory hole before... It feels so... degrading... in a hot way.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:50
translate chinese CeR2_AS1_rep_976d9939:

    # Celia "(God, my panties are soaking wet right now. I can't believe I'm actually going to use a glory hole!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:52
translate chinese CeR2_AS1_rep_4dfdfd95:

    # MC "(I’m not feeling anything yet...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:53
translate chinese CeR2_AS1_rep_4cdacd6d:

    # MC "(Maybe I didn’t think this through. What’s to stop her hurting me? Come to think of it, I’m actually in quite a vulnerable position right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:54
translate chinese CeR2_AS1_rep_ea8fc136:

    # MC "(I’ll just stay still and see how this plays out...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:57
translate chinese CeR2_AS1_rep_36172914:

    # Celia "(I won’t be able to see this fucker’s face when I’m blowing him, so God knows when he’ll decide to cum.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:59
translate chinese CeR2_AS1_rep_a6342365:

    # Celia "(I won’t be able to see [player_name]'s face when I’m blowing him, so God knows when he’ll decide to cum.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:60
translate chinese CeR2_AS1_rep_dad777c4:

    # Celia "(I’ll take my dress off. The last thing I need is an unexplainable white stain down the front of me.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:62
translate chinese CeR2_AS1_rep_92203d40:

    # Celia "(Alright... Here we go.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:63
translate chinese CeR2_AS1_rep_934cba7b:

    # MC "(I can hear her moving! She must be about to start sucking my dick!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:66
translate chinese CeR2_AS1_rep_1b0a0325:

    # Celia "(I wonder who you REALLY are...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:67
translate chinese CeR2_AS1_rep_8ecba5c5:

    # Celia "(This is one of the blackmailer’s friends. This means that he has told at LEAST one other person that I’m being blackmailed.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:68
translate chinese CeR2_AS1_rep_028ed44c:

    # Celia "(Someone simply HAS to start bragging or boasting at some point.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:70
translate chinese CeR2_AS1_rep_d9dee901:

    # Celia "(And when they do, I’ll catch them.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:71
translate chinese CeR2_AS1_rep_fa3ed065:

    # Celia "(I’ll catch every single one of the bastards who did this to me.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:72
translate chinese CeR2_AS1_rep_49436736:

    # Celia "Hmm... (Now that I think about it, I’ve got quite a long list of students that I altered grades for. I should cross reference their names. Maybe one of them is the blackmailer?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:74
translate chinese CeR2_AS1_rep_9cbfec71:

    # Celia "(Until that day though, I’ve got to bite my tongue and bide my time.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:76
translate chinese CeR2_AS1_rep_7f808eec:

    # Celia "(How much farther can this fantasy possibly go?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:77
translate chinese CeR2_AS1_rep_0ef66af6:

    # Celia "(I mean, it doesn’t get more degrading than being fucked in a mens’ toilets.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:78
translate chinese CeR2_AS1_rep_b6efad21:

    # Celia "(Oh... Imagine if someone saw me coming in here. Word would spread really fast on campus. My reputation would be ruined. Mmm... That’s so fucking hot.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:80
translate chinese CeR2_AS1_rep_789f3aeb:

    # Celia "(I wonder if I should roleplay catching him in order to shake things up a bit?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:81
translate chinese CeR2_AS1_rep_4ea5ea13:

    # Celia "(I could certainly have A LOT of fun turning the tables.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:82
translate chinese CeR2_AS1_rep_c71e0987:

    # Celia "Mmm... (Now that I think about it, I’ve got quite a long list of students that I altered grades for. I probably had something like this coming for a LONG time!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:84
translate chinese CeR2_AS1_rep_62afe204:

    # Celia "(For the meantime, I’ll bite my tongue and keep playing the submissive one in this fantasy.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:86
translate chinese CeR2_AS1_rep_fb613c3b:

    # Celia "(You’ll make it through this, Celia. You have always made it, in the end.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:87
translate chinese CeR2_AS1_rep_84299fb4:

    # Celia "(Remember Harvard, Celia. Remember how those elitist pricks treated you, for coming from a poor family. They weren’t laughing when you made the Dean’s list!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:89
translate chinese CeR2_AS1_rep_2fadd999:

    # Celia "(You’re going to suck this cock and act like the helpless victim.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:90
translate chinese CeR2_AS1_rep_8db4e524:

    # Celia "(Then, whenever your time comes, you’re going to strike! You’re going to turn the tables on this shitlord!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:96
translate chinese CeR2_AS1_rep_3c427cbd:

    # Celia "*Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:97
translate chinese CeR2_AS1_rep_f4864c18:

    # MC "Mmm... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:99
translate chinese CeR2_AS1_rep_e80e20e1:

    # MC "(Shit, I better try to keep my moaning to a minimum. I don’t want to risk Celia recognising my voice.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:101
translate chinese CeR2_AS1_rep_45f62667:

    # MC "(I’ll try changing my voice as well to make it easier for Celia to pretend it isn’t me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:103
translate chinese CeR2_AS1_rep_5a369e5a:

    # Celia "*Lick Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:104
translate chinese CeR2_AS1_rep_dd87aefc:

    # MC "Mmmpfff... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:105
translate chinese CeR2_AS1_rep_c5e91253:

    # MC "(Fuck, this feels so good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:107
translate chinese CeR2_AS1_rep_43a28118:

    # Celia "(I better make sure I give a good blowjob here. I don’t want this asshole going back and saying I didn’t give good head.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:109
translate chinese CeR2_AS1_rep_3c427cbd_1:

    # Celia "*Lick*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:111
translate chinese CeR2_AS1_rep_df3bb48a:

    # MC "Ohh... Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:113
translate chinese CeR2_AS1_rep_b9258bea:

    # MC "(Her tongue feels so good flicking up and down the side of my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:114
translate chinese CeR2_AS1_rep_1db042ee:

    # Celia "*Slurp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:116
translate chinese CeR2_AS1_rep_5f7bf351:

    # MC "(Oh shit... This is so good... I wish I’d thought to make Celia do this earlier!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:117
translate chinese CeR2_AS1_rep_5596ab4a:

    # Celia "*Shluurrrp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:119
translate chinese CeR2_AS1_rep_7ac91f92:

    # Celia "Mmppfff!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:121
translate chinese CeR2_AS1_rep_f58cfda9:

    # Celia "*Suuucccck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:122
translate chinese CeR2_AS1_rep_5c4e3662:

    # MC "Ah.... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:124
translate chinese CeR2_AS1_rep_36b68398:

    # MC "(Holy shit... Her mouth feels incredible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:125
translate chinese CeR2_AS1_rep_05ac408d:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:126
translate chinese CeR2_AS1_rep_22adba9e:

    # MC "Hnngg..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:127
translate chinese CeR2_AS1_rep_00ddd76c:

    # MC "(Damn, it’s a struggle not to moan!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:129
translate chinese CeR2_AS1_rep_faa250ca:

    # MC "(I really want to beg her to move her head more quickly, but I can’t or I’ll give myself away.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:132
translate chinese CeR2_AS1_rep_bdc41643:

    # MC "(Even though she’s the one being blackmailed, for the next few minutes I’m at HER mercy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:134
translate chinese CeR2_AS1_rep_3588d32d:

    # MC "(Even though she's the one that is pretending, for the next few minutes I'm at HER mercy!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:136
translate chinese CeR2_AS1_rep_56278310:

    # Celia "*Shlurp* *Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:138
translate chinese CeR2_AS1_rep_59cea1f3:

    # Celia "(I’m giving this all I can! The sooner I get this bastard to cum, the sooner I can move on with my day!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:139
translate chinese CeR2_AS1_rep_2e2198b4:

    # Celia "(I guess I’ll just have to suck extra hard. Let’s see if that gets a reaction out of him!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:141
translate chinese CeR2_AS1_rep_a5f02c73:

    # Celia "*SUUUUCCCCK*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:142
translate chinese CeR2_AS1_rep_3be1ed6f:

    # MC "HMMMMMMM!!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:143
translate chinese CeR2_AS1_rep_e57b66ab:

    # MC "(Dammit! I’m having to clench my teeth to try and suppress my moaning.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:144
translate chinese CeR2_AS1_rep_66b1b3ea:

    # MC "(Her mouth is like a fucking vacuum!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:146
translate chinese CeR2_AS1_rep_05ac408d_1:

    # Celia "*Shlurp*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:147
translate chinese CeR2_AS1_rep_eb0a0c57:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:148
translate chinese CeR2_AS1_rep_ad2904ff:

    # MC "Mmm.... Hnnnnggg...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:150
translate chinese CeR2_AS1_rep_5e0d9587:

    # MC "(My heart’s pounding right now. She has a real talent for sucking cock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:151
translate chinese CeR2_AS1_rep_0854c568:

    # MC "(I’ll definitely be making her do this again in the future!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:153
translate chinese CeR2_AS1_rep_66f0bdd8:

    # Celia "(Grr... come on, you bastard! Blow your load already!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:154
translate chinese CeR2_AS1_rep_cf87f08c:

    # Celia "(I can’t spend all day here, or my class will wonder where the fuck I’ve wandered off to!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:156
translate chinese CeR2_AS1_rep_f00cc479:

    # Celia "(I didn’t want to have to do this... but drastic times call for drastic measures.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:157
translate chinese CeR2_AS1_rep_3aaf811a:

    # MC "(Huh? She’s stopped? What’s she doing?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:159
translate chinese CeR2_AS1_rep_075eda35:

    # Celia "(Take a deep breath, Celia. You can do this!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:160
translate chinese CeR2_AS1_rep_8c6a19af:

    # Celia "(Let’s deepthroat this little bastard until he cums. Once he squirts, you’ll be able to nail him!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:163
translate chinese CeR2_AS1_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:165
translate chinese CeR2_AS1_rep_b4cee80e:

    # MC "(Ahh, there she is. I wonder why she stopped for a minute, there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:166
translate chinese CeR2_AS1_rep_a68b0d2d:

    # MC "(Maybe she was just-)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:168
translate chinese CeR2_AS1_rep_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:170
translate chinese CeR2_AS1_rep_e1dc771e:

    # Celia "*SHLUUURRRRP*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:171
translate chinese CeR2_AS1_rep_0b609764:

    # MC "(HOLY FUCK! God, she’s deepthroating me! Her throat is so damn tight around my cock!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:172
translate chinese CeR2_AS1_rep_8d56a97e:

    # Celia "*GAG*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:175
translate chinese CeR2_AS1_rep_4b84470a:

    # Celia "(I KNEW that would work!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:177
translate chinese CeR2_AS1_rep_2ed81abd:

    # Celia "*SUCK SHLURP* "
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:179
translate chinese CeR2_AS1_rep_8d56a97e_1:

    # Celia "*GAG*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:181
translate chinese CeR2_AS1_rep_9c65680e:

    # MC "(Oh fuck! OH FUCK!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:182
translate chinese CeR2_AS1_rep_3e63c42a:

    # MC "HNNNNGGG!! UGH!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:183
translate chinese CeR2_AS1_rep_e5f9c628:

    # MC "(I’m cumming! Oh fuck! I’m gonna cum down this bitch’s throat!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:193
translate chinese CeR2_AS1_rep_c06dafe1:

    # Celia "*GULP*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:194
translate chinese CeR2_AS1_rep_6f2e2082:

    # Celia "HMMPFFF?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:195
translate chinese CeR2_AS1_rep_5323338a:

    # Celia "(NO! He wasn’t supposed to cum that quickly!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:196
translate chinese CeR2_AS1_rep_c367bdba:

    # Celia "(Fuck! I swallowed it as it hit the back of my throat. It was a fucking reflex!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:198
translate chinese CeR2_AS1_rep_34bbb127:

    # Celia "*Cough*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:199
translate chinese CeR2_AS1_rep_01efb74b:

    # Celia "Y-You better not to lie to your boss about the quality of this blowjob, fucker..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:200
translate chinese CeR2_AS1_rep_9a645688:

    # Celia "I’m serious!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:202
translate chinese CeR2_AS1_rep_30c636fb:

    # Celia "(Okay, I’ll linger outside the toilets and wait for this little shitstain to come out. Then I’ll catch the bastard red-handed!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:204
translate chinese CeR2_AS1_rep_df8a2f08:

    # Celia "(Okay, I’ll linger outside the toilets and wait for [player_name] to come out. Then I can confront him and turn the tables on our little fantasy!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:206
translate chinese CeR2_AS1_rep_72c25f75:

    # MC "(Heh heh, I’ll just wait here. Celia has a class that she has to teach.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:207
translate chinese CeR2_AS1_rep_ab1e1660:

    # MC "(She can’t afford to sit outside the mens’ toilets and wait for me forever.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:208
translate chinese CeR2_AS1_rep_e2b572ba:

    # MC "(Time is on my side!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:212
translate chinese CeR2_AS1_rep_6f050731_1:

    # "*Clunk*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:214
translate chinese CeR2_AS1_rep_c6ac72d7:

    # MC "(There goes the cubicle door... followed by her footsteps. And, she is out of here!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:215
translate chinese CeR2_AS1_rep_bc075b0e:

    # MC "(Now, time to sit back on my phone and chillax.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:217
translate chinese CeR2_AS1_rep_7c3d5855:

    # Celia "Grr... (C’mon! Where the fuck are you?!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:218
translate chinese CeR2_AS1_rep_de88b28e:

    # Celia "(You can’t hide in there forever, you little shit!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS1_rep.rpy:219
translate chinese CeR2_AS1_rep_c924388b:

    # Celia "(Fuck it, it’s been twenty minutes... I can’t hang around here forever, or I’ll lose my job.)"
    Celia ""

