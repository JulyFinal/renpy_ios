﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:10
translate chinese SR3_we_home_end_bed_rep_71e0ae56:

    # MC "How about we head over to the bed? I’ll sit down and you can suck my cock."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:12
translate chinese SR3_we_home_end_bed_rep_4b63d6eb:

    # Sara "Will that get me wet enough so it won’t hurt when you try to put it in?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:14
translate chinese SR3_we_home_end_bed_rep_e63ab8f4:

    # Sara "I hope that will get me wet enough..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:16
translate chinese SR3_we_home_end_bed_rep_2885c239:

    # MC "Well, that depends. Does it turn you on when you give head?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:17
translate chinese SR3_we_home_end_bed_rep_1832501e:

    # Sara "Umm... Yeah, it kinda does. Actually a lot as I think of that now..."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:18
translate chinese SR3_we_home_end_bed_rep_ce96497f:

    # MC "Well, that’s your answer right there! It’ll get me hard and get you wet!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:20
translate chinese SR3_we_home_end_bed_rep_066d590f:

    # Sara "Alright. How do you want to do this?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:21
translate chinese SR3_we_home_end_bed_rep_5228c5f8:

    # MC "C’mon over here and take my jeans off."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:23
translate chinese SR3_we_home_end_bed_rep_9b3b29c6:

    # MC "Mmm, love the view, Sara!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:24
translate chinese SR3_we_home_end_bed_rep_92548314:

    # Sara "Hehe, I knew you were going to like this dress, but I didn’t realise just how much!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:25
translate chinese SR3_we_home_end_bed_rep_62d0f7d0:

    # MC "What can I say? You’ve got great taste in fashion."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:27
translate chinese SR3_we_home_end_bed_rep_0f1b1b44:

    # Sara "I’m going to suck your cock so fucking hard, you won’t be able to stand."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:28
translate chinese SR3_we_home_end_bed_rep_2feb8789:

    # MC "Mmm, as hot as that sounds, just remember - I still need to fuck you too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:29
translate chinese SR3_we_home_end_bed_rep_976897b5:

    # MC "Men aren’t as lucky as women are. We only get to cum once before we need to recharge. We can’t just go again and again like you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:30
translate chinese SR3_we_home_end_bed_rep_39bfa45a:

    # Sara "Hehe, I’ll make sure to stop before you cum, then. Let me know when you’re getting close."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:32
translate chinese SR3_we_home_end_bed_rep_b503a57b:

    # Sara "Hey there, big guy!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:33
translate chinese SR3_we_home_end_bed_rep_676817a4:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:34
translate chinese SR3_we_home_end_bed_rep_d9303071:

    # MC "(Haha, she is still adorable. How the hell did I get so lucky?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:36
translate chinese SR3_we_home_end_bed_rep_4a9b6eba:

    # Sara "(He got so hard so quickly! I wonder if he’s excited to finally fuck my pussy.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:38
translate chinese SR3_we_home_end_bed_rep_f5a69fd0:

    # Sara "(Does it feel the same as when he puts his dick in my mouth? Maybe it feels better?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:40
translate chinese SR3_we_home_end_bed_rep_2a113386:

    # Sara "(I hope my pussy will feel much better for [player_name], than my mouth.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:42
translate chinese SR3_we_home_end_bed_rep_676817a4_1:

    # Sara "*Mwah*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:43
translate chinese SR3_we_home_end_bed_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:44
translate chinese SR3_we_home_end_bed_rep_0ec26d7c:

    # MC "Alright, ready whenever you are, Sara. Show me the best you can do."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:46
translate chinese SR3_we_home_end_bed_rep_f2b0b304:

    # Sara "*Glompf*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:48
translate chinese SR3_we_home_end_bed_rep_fa95d150:

    # MC "Oh, fuck! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:49
translate chinese SR3_we_home_end_bed_rep_10aaf249:

    # Sara "(Heh, he didn’t expect me to go that quickly!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:51
translate chinese SR3_we_home_end_bed_rep_bd1c6d83:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:52
translate chinese SR3_we_home_end_bed_rep_af3ea908:

    # MC "Ahh... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:54
translate chinese SR3_we_home_end_bed_rep_e40f8f67:

    # MC "(I can feel her teenage mouth wrapped tightly around my shaft. Her tongue is swirling over the tip of my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:56
translate chinese SR3_we_home_end_bed_rep_fef692a7:

    # MC "(I can feel her mouth wrapped tightly around my shaft. Her tongue is swirling over the tip of my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:58
translate chinese SR3_we_home_end_bed_rep_79ab639d:

    # MC "Ohh... Don’t stop, Sara!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:60
translate chinese SR3_we_home_end_bed_rep_5d0d3abe:

    # Sara "*Suck* *Shlurp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:61
translate chinese SR3_we_home_end_bed_rep_51a2aeea:

    # MC "Ah... Ahh... Ohhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:63
translate chinese SR3_we_home_end_bed_rep_1833ce98:

    # MC "Oh yeah, suck my fucking cock. Mmm! I want to feel it slide down your tight little throat."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:64
translate chinese SR3_we_home_end_bed_rep_3cad6a41:

    # Sara "*Shlurp* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:65
translate chinese SR3_we_home_end_bed_rep_9ce87233:

    # Sara "(Having his cock in my mouth is getting me horny. My panties are starting to get wet.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:67
translate chinese SR3_we_home_end_bed_rep_9bcc8fed:

    # MC "Ughhh... Ohhh! Yes... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:68
translate chinese SR3_we_home_end_bed_rep_40486528:

    # Sara "*Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:69
translate chinese SR3_we_home_end_bed_rep_434825c8:

    # MC "You’re so good at giving head, Sara. Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:71
translate chinese SR3_we_home_end_bed_rep_e4e2dd97:

    # MC "Ahh... yes... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:72
translate chinese SR3_we_home_end_bed_rep_85c5686a:

    # Sara "*Shlurp* *Suck* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:73
translate chinese SR3_we_home_end_bed_rep_aeed7fae:

    # MC "(It’s so tempting to just blow my load deep in her mouth right now. It would be so easy to just wrap my hands around her head, hold it in place, and fuck her face until I emptied my balls into her throat.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:75
translate chinese SR3_we_home_end_bed_rep_31eae5ab:

    # MC "(I have to hold on though. If I cum in her mouth then I just waste an opportunity to finally fuck Sara’s tight virgin pussy.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:76
translate chinese SR3_we_home_end_bed_rep_dacd8cbe:

    # MC "Ugh.. .Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:78
translate chinese SR3_we_home_end_bed_rep_91b3f327:

    # MC "Oh fuck, Sara. Yes! Keep sucking... Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:80
translate chinese SR3_we_home_end_bed_rep_3c4b2635:

    # Sara "*Suck* *Gag* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:82
translate chinese SR3_we_home_end_bed_rep_b14f1a32:

    # MC "Do you *ugh* think you can go deeper, Sara?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:83
translate chinese SR3_we_home_end_bed_rep_22bec121:

    # Sara "Mmm hmm!"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:84
translate chinese SR3_we_home_end_bed_rep_1cb75114:

    # Sara "*Shlurrrp*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:86
translate chinese SR3_we_home_end_bed_rep_7958a750:

    # Sara "(He wants me to take his cock deeper? I could try deepthroating it for him now and see if he likes that.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:87
translate chinese SR3_we_home_end_bed_rep_3cad6a41_1:

    # Sara "*Shlurp* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:88
translate chinese SR3_we_home_end_bed_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:90
translate chinese SR3_we_home_end_bed_rep_f7697cac:

    # MC "Holy fuck... Your mouth is just *pant* perfect, Sara."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:91
translate chinese SR3_we_home_end_bed_rep_bd1c6d83_1:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:92
translate chinese SR3_we_home_end_bed_rep_c6756ff7:

    # Sara "(Okay, here goes nothing! Let’s see how deep I can take this dick!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:94
translate chinese SR3_we_home_end_bed_rep_79a8f4dd:

    # Sara "*Glompff*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:95
translate chinese SR3_we_home_end_bed_rep_968b03a2:

    # MC "Hnnnggg... Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:96
translate chinese SR3_we_home_end_bed_rep_84ae1537:

    # MC "(I can feel her tight throat clinging to the tip of my dick. Holy shit that’s good.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:98
translate chinese SR3_we_home_end_bed_rep_e9a0152a:

    # Sara "*Gag* *Splutter* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:100
translate chinese SR3_we_home_end_bed_rep_5c537c33:

    # Sara "(Crap! This is MUCH more difficult than it was when I was practicing on bananas! How the heck do girls do this in porn without choking?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:102
translate chinese SR3_we_home_end_bed_rep_68cf8852:

    # Sara "(Crap! This is MUCH more difficult than I thought! How the heck do girls do this in porn without choking?!)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:103
translate chinese SR3_we_home_end_bed_rep_1ce2f5f9:

    # MC "(Jesus, it’s taking every fibre of my being to not blow my load down her throat right now! Focus, [player_name], if you hold on you get to pound her pussy instead - and that’s gonna feel SO much better than this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:105
translate chinese SR3_we_home_end_bed_rep_c5f4060a:

    # MC "Ahh... Ohhh... Shit... Mmmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:106
translate chinese SR3_we_home_end_bed_rep_4e319494:

    # Sara "*Shlurp* *Gag*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:107
translate chinese SR3_we_home_end_bed_rep_d453f449:

    # Sara "(I wonder if he’s getting close to cumming. Maybe I should start slowing down now?)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:109
translate chinese SR3_we_home_end_bed_rep_a63399fa:

    # MC "Oh my God! Sara, you’re amazing! Hnnnggg! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:111
translate chinese SR3_we_home_end_bed_rep_094cb53f:

    # MC "(She’s managed to take almost five inches in her mouth there! She’s really improving at this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:112
translate chinese SR3_we_home_end_bed_rep_3c4b2635_1:

    # Sara "*Suck* *Gag* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:114
translate chinese SR3_we_home_end_bed_rep_5f0cfde5:

    # MC "Mmm! Yes, Sara! God... I’m getting close. Oh fuck...If you keep doing that I’m gonna cum."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:115
translate chinese SR3_we_home_end_bed_rep_f2266814:

    # Sara "*Suck* *Shluuuurrrrp* *GAG* *SPLUTTER* *Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:116
translate chinese SR3_we_home_end_bed_rep_dda714c7:

    # MC "(Every time she gags I feel her little throat tightening around my cock. It’s like she’s trying to milk me dry right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:118
translate chinese SR3_we_home_end_bed_rep_f85cdf89:

    # MC "Ahh.. Ahh! S-Sara, I’m about to cum! Fuck, fuck! I’m on the edge!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:119
translate chinese SR3_we_home_end_bed_rep_bd1c6d83_2:

    # Sara "*Suck Suck*"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:120
translate chinese SR3_we_home_end_bed_rep_ce963264:

    # Sara "(Oops! I got carried away, there and forgot to slow down.)"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:122
translate chinese SR3_we_home_end_bed_rep_1af53fed:

    # MC "*Pant* Phew... that was close! Haha, you had me right on the verge of cumming."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:123
translate chinese SR3_we_home_end_bed_rep_dbe7cd32:

    # Sara "Sorry, [player_name]. I got lost in the moment there."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:124
translate chinese SR3_we_home_end_bed_rep_ef03104f:

    # MC "So, I take it you’re horny, then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:125
translate chinese SR3_we_home_end_bed_rep_4bf009b3:

    # Sara "Well.. my panties are soaked... very soaked, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:127
translate chinese SR3_we_home_end_bed_rep_5a0eae64:

    # MC "Are you ready to try sex now, then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:129
translate chinese SR3_we_home_end_bed_rep_8e732692:

    # Sara "I... I guess so. I’m still a little scared. Anal with you wasn’t... It wasn't pleasant at all, the first time we did it. It really hurt."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:130
translate chinese SR3_we_home_end_bed_rep_8e49167f:

    # Sara "I’m kinda terrified that this is going to be like that again, or maybe even worse."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:132
translate chinese SR3_we_home_end_bed_rep_b3307a02:

    # Sara "I... I guess so. I'm still a little nervous, but I trust you, [player_name]."
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:133
translate chinese SR3_we_home_end_bed_rep_d97da364:

    # Sara "I'm wet and ready for your big boy... Just promise to stop when I ask you, okay?"
    Sara ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:134
translate chinese SR3_we_home_end_bed_rep_41f59c61:

    # MC "Listen, Sara. I promise. We’ll take it slow and if you find yourself not enjoying it, we can just stop, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Sara_v71/SR3_we_home_end_bed_rep.rpy:135
translate chinese SR3_we_home_end_bed_rep_1fa73e39:

    # Sara "Alright."
    Sara ""

