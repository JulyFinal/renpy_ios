﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:7
translate chinese CR4_We_rep_22a1c58f:

    # Caroline "Ta da! What do you think?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:8
translate chinese CR4_We_rep_c9661363:

    # MC "Wow! This hotel is incredible!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:10
translate chinese CR4_We_rep_37e402df:

    # Caroline "It’s five stars. The last time I was here was a few years ago, with [Mom_name]. Wecame here together on a girly night out."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:12
translate chinese CR4_We_rep_539ed27b:

    # Caroline "It’s five stars. The last time I was here was a few years ago with my friend. We went together on a girly night out."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:15
translate chinese CR4_We_rep_b6301bf1:

    # Caroline "I have a feeling I’m going to enjoy tonight MUCH more than last time though."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:16
translate chinese CR4_We_rep_8a935e75:

    # MC "I’m sure you will."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:17
translate chinese CR4_We_rep_302d14a3:

    # MC "Look! They’ve even left us a bowl of fresh berries!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:20
translate chinese CR4_We_rep_6b6d1de9:

    # MC "What do you want to do first?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:21
translate chinese CR4_We_rep_8ccafa5e:

    # Caroline "How about we sit down and have a little drink together?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:22
translate chinese CR4_We_rep_c098eb92:

    # MC "Sounds good to me! Want me to call down to the hotel bar and grab us some wine?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:25
translate chinese CR4_We_rep_ef152305:

    # Caroline "Don’t worry, I came prepared."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:26
translate chinese CR4_We_rep_5cd7689e:

    # MC "Cool, that’s fine then. HOLY SHIT! This bathroom is massive!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:27
translate chinese CR4_We_rep_309ce8f4:

    # Caroline "Hehe, you’re so easily distracted!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:30
translate chinese CR4_We_rep_aeee8af4:

    # Caroline "C’mon, we can try the bath out later on. "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:31
translate chinese CR4_We_rep_38330a88:

    # MC "Haha, no problem. Sorry, this is all just so exciting! I’ve never been in a hotel as amazing as this before!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:34
translate chinese CR4_We_rep_bc00cb15:

    # Caroline "Let’s head over to the couch over there."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:35
translate chinese CR4_We_rep_0c226a54:

    # MC "Sure, no problem!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:38
translate chinese CR4_We_rep_29675113:

    # MC "(Wow! Her dress is so short, I can almost see her asscheeks!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:39
translate chinese CR4_We_rep_b3925d2c:

    # MC "(I can’t wait to tear it off her and spread those later on.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:42
translate chinese CR4_We_rep_f5b7abc6:

    # Caroline "Enjoying the view, [player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:43
translate chinese CR4_We_rep_191878a7:

    # MC "Haha, how’d you know I was looking?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:44
translate chinese CR4_We_rep_2d1ecb19:

    # Caroline "[Mom_name] caught me leaving the house earlier. She was shocked by how short my dress was, so I had to tell her I’m going out on a date."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:45
translate chinese CR4_We_rep_672761e2:

    # Caroline "If [Mom_name] noticed my short skirt, then you’re DEFINITELY going to notice!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:48
translate chinese CR4_We_rep_f5f9d512:

    # MC "Does [Mom_name] know you’re dating me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:49
translate chinese CR4_We_rep_eb2882d7:

    # Caroline "I told her it was just some guy - and that I’d introduce her to us when I felt ready."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:50
translate chinese CR4_We_rep_da6bab00:

    # MC "I wonder how she’ll take it. It won’t make things awkward, right?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:53
translate chinese CR4_We_rep_b3f7ec70:

    # Caroline "Let’s try not to think about any of that tonight. I just want to have a fun time with you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:54
translate chinese CR4_We_rep_1a3929c2:

    # Caroline "Say, can you go into my bag? I have a bottle of vodka in there that I’ve been saving for a special occasion."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:57
translate chinese CR4_We_rep_707f4789:

    # MC "No problem. I’ll get it now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:58
translate chinese CR4_We_rep_71da1e06:

    # Caroline "Thanks, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:59
translate chinese CR4_We_rep_7ef9ada0:

    # MC "You look really amazing tonight, Caroline. You know that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:62
translate chinese CR4_We_rep_307f53f0:

    # Caroline "Hehe, thank you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:63
translate chinese CR4_We_rep_d52884d6:

    # Caroline "Now, you’ll have all night to leer at my body. Can we get something to drink? I’m parched after that meal."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:70
translate chinese CR4_We_rep_9cb00310:

    # MC "(Okay, this looks like her bag. How the hell do I get into this thing?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:71
translate chinese CR4_We_rep_0ac57e37:

    # MC "(Ahh, there’s the clasp!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:74
translate chinese CR4_We_rep_4ec23f9d:

    # MC "Milfy City Vodka? Cute name. Is it a local brand?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:75
translate chinese CR4_We_rep_8bc86cb4:

    # Caroline "Yeah, it’s a small producer from just outside the city limits. I got it a couple of years ago."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:76
translate chinese CR4_We_rep_c6414783:

    # Caroline "I swore I wouldn’t open it until I had someone that I knew I wanted to share it with."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:77
translate chinese CR4_We_rep_22ccd6b9:

    # Caroline "Now that you’re my boyfriend, I think... I think it’s the right time to open it up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:85
translate chinese CR4_We_rep_73b358d3:

    # MC "Are you sure?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:86
translate chinese CR4_We_rep_4a0cfece:

    # Caroline "I’m more than certain, [player_name]. I really am. You’re the one I want to spend my life with."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:87
translate chinese CR4_We_rep_52bf71e3:

    # Caroline "You don’t raise your voice or shout at me. You’ve never hit me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:90
translate chinese CR4_We_rep_b138e4dc:

    # MC "That’s not exactly a high bar..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:91
translate chinese CR4_We_rep_a0c68c5e:

    # Caroline "All I want is to feel safe in a relationship with someone, who I know cares about me. You’ve already given me that, [player_name]. I’m sorry I was pushing you away at the beginning."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:92
translate chinese CR4_We_rep_0d7e5ce3:

    # MC "It’s okay. I understand now. "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:95
translate chinese CR4_We_rep_ace5df19:

    # MC "When I was... When I visited Charles to try and get your necklace back, he said some things."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:96
translate chinese CR4_We_rep_6ecec50f:

    # Caroline "Oh yeah? Like what?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:97
translate chinese CR4_We_rep_5a8bc10d:

    # MC "He mentioned how you used to have to buy foundation to cover the bruises he gave you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:100
translate chinese CR4_We_rep_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:101
translate chinese CR4_We_rep_e5ce135d:

    # MC "I mean, I knew he was a first class asshole. But I never realised JUST how much of a scumbag he really was."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:102
translate chinese CR4_We_rep_7b823929:

    # MC "[Mom_name] and Sara never knew, did they?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:103
translate chinese CR4_We_rep_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:106
translate chinese CR4_We_rep_8edb8451:

    # MC "I’ll pour us some drinks."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:107
translate chinese CR4_We_rep_ee627fcd:

    # Caroline "I got... good at hiding it from everyone. You, [Dad_name], Sara..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:108
translate chinese CR4_We_rep_815a6f2c:

    # Caroline "I felt like what was happening was my fault. Because I wasn’t good enough for him."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:111
translate chinese CR4_We_rep_9074c722:

    # MC "It’s alright. We should have been paying more attention. You weren’t yourself back then."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:112
translate chinese CR4_We_rep_18a50a60:

    # Caroline "I know... Walking away from him was one of the hardest things I ever did. He stalked me for months after that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:115
translate chinese CR4_We_rep_a6c1a72a:

    # MC "Do you want to hear a story that will cheer you up?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:116
translate chinese CR4_We_rep_3061091e:

    # Caroline "Shoot."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:117
translate chinese CR4_We_rep_acba1008:

    # MC "When I went over to visit him, his place was a complete dump. He had a single room with a mattress on the floor, empty beer bottles everywhere, and some shitty television that looked like it belonged in the eighties."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:118
translate chinese CR4_We_rep_aeffa0bc:

    # MC "And while he’s living in squalor, you’re living it up in a five star hotel. It’s as you said during dinner - you beat the bastard, and you did it without anyone’s help."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:119
translate chinese CR4_We_rep_082672f1:

    # MC "Now you run your own hugely successful business, you’ve gotten your confidence back, and you’ve got a new partner who really, really loves you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:122
translate chinese CR4_We_rep_7ac5e0c1:

    # MC "So here’s to your continued success!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:123
translate chinese CR4_We_rep_09aeb9fc:

    # Caroline "Thanks, [player_name]. I’ll drink to that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:126
translate chinese CR4_We_rep_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:127
translate chinese CR4_We_rep_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:128
translate chinese CR4_We_rep_c9b5e2eb:

    # MC "*Cough* That’s strong stuff!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:131
translate chinese CR4_We_rep_38232d0f:

    # Caroline "I wish it could have been us, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:132
translate chinese CR4_We_rep_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:133
translate chinese CR4_We_rep_b4af6450:

    # Caroline "I mean, you and me. I wish I’d never met Charles."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:136
translate chinese CR4_We_rep_7b26b862:

    # MC "You can’t change the past, Caroline. It isn’t worth wasting your time imagining what could have been."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:137
translate chinese CR4_We_rep_4cc5358a:

    # MC "Heck, if you hadn’t dated Charles then you may never have learnt how strong you actually are. You might not have launched your own business!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:138
translate chinese CR4_We_rep_0a2e032c:

    # MC "And if you hadn’t done that, we’d not be romantically involved."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:139
translate chinese CR4_We_rep_89342902:

    # Caroline "I guess you’re right."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:142
translate chinese CR4_We_rep_a4f55ba3_1:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:143
translate chinese CR4_We_rep_f00403c4:

    # MC "Thanks again for organising this night, Caroline. I really love it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:146
translate chinese CR4_We_rep_4416246b:

    # Caroline "Thanks for talking me through all this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:147
translate chinese CR4_We_rep_16b5d566:

    # Caroline "I’ve never really opened up much to anyone. It’s nice to have someone I can talk to and trust. Someone who isn’t going to belittle me or mock me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:150
translate chinese CR4_We_rep_dfb5d643:

    # Caroline "You’re perfect."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:151
translate chinese CR4_We_rep_35346dd6:

    # MC "That necklace really suits you, you know that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:152
translate chinese CR4_We_rep_292cc5b0:

    # Caroline "You think so?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:155
translate chinese CR4_We_rep_c6529bd8:

    # Caroline "For a sixty year old piece of jewelry, it’s aged pretty damn well."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:156
translate chinese CR4_We_rep_cbab8be2:

    # MC "I’m just glad it’s back where it belongs."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:157
translate chinese CR4_We_rep_fdc673a1:

    # Caroline "I still need to properly thank you for that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:160
translate chinese CR4_We_rep_c9b20f0a:

    # MC "Mmm, and how do you plan to do that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:161
translate chinese CR4_We_rep_2478291c:

    # Caroline "Why don’t you set down your drink, and I’ll show you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:162
translate chinese CR4_We_rep_90c52b84:

    # MC "Okay!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:169
translate chinese CR4_We_rep_7585dd65:

    # Caroline "I’m going to rock your world tonight, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:170
translate chinese CR4_We_rep_971e5c5c:

    # MC "Mmm, I’m looking forward to that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:171
translate chinese CR4_We_rep_858ab27a:

    # Caroline "I’ve got a few little tricks I’ve been yearning to try out with you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:174
translate chinese CR4_We_rep_c53a58bc:

    # MC "Oh yeah? And what tricks would those be?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:175
translate chinese CR4_We_rep_39d96062:

    # Caroline "We’ll have to get you out of these restrictive clothes first. Hehe!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:178
translate chinese CR4_We_rep_5d52f7a3:

    # Caroline "How many times do you think you can go in one night?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:179
translate chinese CR4_We_rep_1a641e20:

    # MC "I don’t know. Maybe three?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:180
translate chinese CR4_We_rep_d8245487:

    # Caroline "Mmm, let’s see if we can hit three, then. We’re going to need to make you cum before we have sex though."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:181
translate chinese CR4_We_rep_5a08631f:

    # MC "Why?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:182
translate chinese CR4_We_rep_7a357d0e:

    # Caroline "I want you lasting longer for the main event!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:183
translate chinese CR4_We_rep_eb56053d:

    # MC "Sweet! Sounds good to me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:186
translate chinese CR4_We_rep_f314a52b:

    # Caroline "But first, we’re going to have to get you all nice and hard."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:187
translate chinese CR4_We_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:188
translate chinese CR4_We_rep_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:191
translate chinese CR4_We_rep_2338451b:

    # MC "I love you, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:192
translate chinese CR4_We_rep_88520fcd:

    # Caroline "I love you too, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:195
translate chinese CR4_We_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:196
translate chinese CR4_We_rep_05d1b90c_1:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:197
translate chinese CR4_We_rep_806cf2ac:

    # MC "(Her lips are so soft.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:200
translate chinese CR4_We_rep_cd115f60:

    # Caroline "(He’s beginning to get hard now. I wonder what he’ll want to do first.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:201
translate chinese CR4_We_rep_a9fd3cf0:

    # Caroline "(Maybe I should warm him up with a boobjob? Perhaps he’d prefer me to just suck his cock?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:204
translate chinese CR4_We_rep_a1bb61b2:

    # Caroline "Oh my! You’ve gotten hard REALLY quickly!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:205
translate chinese CR4_We_rep_2a341311:

    # MC "Mmm, keep moving your hand like that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:208
translate chinese CR4_We_rep_1c62dcfa:

    # Caroline "Like this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:209
translate chinese CR4_We_rep_8392b3d7:

    # MC "Uh huh... Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:210
translate chinese CR4_We_rep_609185f6:

    # Caroline "Do you like it when I rub your shaft like this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:211
translate chinese CR4_We_rep_2048b593:

    # MC "Yes, mmm! Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:214
translate chinese CR4_We_rep_2f3df3d8:

    # Caroline "Why settle for just a handjob though, when you could have SO MUCH more?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:215
translate chinese CR4_We_rep_ca2052c1:

    # MC "I’m listening... and watching."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:216
translate chinese CR4_We_rep_673d143f:

    # Caroline "Hehe, make sure you don’t blink."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:219
translate chinese CR4_We_rep_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:220
translate chinese CR4_We_rep_f909746c:

    # Caroline "As I was saying: why settle for a handjob, when you could have these babies wrapped around your cock?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:221
translate chinese CR4_We_rep_e5f70504:

    # MC "Very tempting. How about you lose the rest of that dress while I think about it?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:224
translate chinese CR4_We_rep_c4328cfe:

    # Caroline "Alternatively, I could take that thick cock of yours into my mouth and suck on it until you are trembling in orgasm."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:225
translate chinese CR4_We_rep_b01a8c3f:

    # MC "That is ALSO very tempting! You’re giving me a really difficult choice right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:228
translate chinese CR4_We_rep_dcb5c5fc:

    # Caroline "Well, perhaps THIS can help you make up your mind."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:229
translate chinese CR4_We_rep_37125ea0:

    # Caroline "I know I’m hot, but try not to drool."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:232
translate chinese CR4_We_rep_b39ef889_1:

    # MC "*Whistle*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:233
translate chinese CR4_We_rep_3b7e182b:

    # MC "You look fucking incredible right now!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:236
translate chinese CR4_We_rep_cb6a5f24:

    # Caroline "Well? What’s it going to be, [player_name]? "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:237
translate chinese CR4_We_rep_5011ac5b:

    # Caroline "Do you want my breasts massaging your dick until you blow your load over them?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:238
translate chinese CR4_We_rep_b1710161:

    # Caroline "Or would you like another one of my, unbeatable, blowjobs?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:244
translate chinese CR4_We_rep_dad5eb3a:

    # MC "Let’s go for a blowjob."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:245
translate chinese CR4_We_rep_77514df9:

    # Caroline "Mmm, good choice. Lie back - and I’ll take care of everything."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:248
translate chinese CR4_We_rep_dce35bfb:

    # MC "(Her eyes are so damn sexy...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:249
translate chinese CR4_We_rep_9ad499dc:

    # Caroline "You’re really going to enjoy this. I hope you’ve got a big load of cum saved up for me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:250
translate chinese CR4_We_rep_fb218847:

    # MC "There might be - there’s only one way you’re gonna find out though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:253
translate chinese CR4_We_rep_f3c7eee7:

    # Caroline "Hehe, I was thinking about doing something a little bit different tonight."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:254
translate chinese CR4_We_rep_699b732e:

    # Caroline "Normally, when a girl gives a guy a blowjob she uses her hands. Just like this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:255
translate chinese CR4_We_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:258
translate chinese CR4_We_rep_8f5f90aa:

    # Caroline "I was thinking that tonight, I would try and get you off with just my mouth."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:259
translate chinese CR4_We_rep_71958523:

    # MC "Sounds fun! Do you think you’re up to it though?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:260
translate chinese CR4_We_rep_50554145:

    # Caroline "Oh please... If anyone isn’t going to be “up to it”, it’ll be you. I’ll have you creaming in my mouth in no time at all."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:261
translate chinese CR4_We_rep_fbea9c52:

    # MC "It sounds to me like someone is waaaay too confident!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:262
translate chinese CR4_We_rep_1bc66e6b:

    # Caroline "Oh yeah? I bet you won’t last three minutes."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:263
translate chinese CR4_We_rep_6a3ff038:

    # MC "You’re on!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:264
translate chinese CR4_We_rep_e9f92542:

    # Caroline "Let me just wet it with my tongue. Feel free to start counting when I let go."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:265
translate chinese CR4_We_rep_ca64c9f7:

    # Caroline "That is... if you even CAN focus on counting."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:268
translate chinese CR4_We_rep_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:270
translate chinese CR4_We_rep_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:273
translate chinese CR4_We_rep_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:275
translate chinese CR4_We_rep_47800f0b:

    # MC "Mmm... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:276
translate chinese CR4_We_rep_7d191740_1:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:279
translate chinese CR4_We_rep_ac6d5d68:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:280
translate chinese CR4_We_rep_44e61699:

    # Caroline "(Okay, that’s [player_name] nice and hard now! Three minutes starts now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:281
translate chinese CR4_We_rep_a95f976c:

    # MC "(Dammit, the tip is so sensitive!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:284
translate chinese CR4_We_rep_41842b5d:

    # MC "(One... Two... Three...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:285
translate chinese CR4_We_rep_43b8826f_2:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:286
translate chinese CR4_We_rep_a22cbf0a:

    # MC "(Damn, it feels so good when she licks at my balls like that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:289
translate chinese CR4_We_rep_10b4b18f:

    # MC "(Seven... eight...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:290
translate chinese CR4_We_rep_e2c07e81_1:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:291
translate chinese CR4_We_rep_c39bd83c:

    # MC "Ohhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:294
translate chinese CR4_We_rep_45982ded:

    # Caroline "*Suck Shlurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:295
translate chinese CR4_We_rep_18f876ac:

    # MC "Mmm! Oh fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:296
translate chinese CR4_We_rep_b5848e66:

    # MC "(Was I on fifteen? Shit, I can’t even keep track.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:299
translate chinese CR4_We_rep_05d1b90c_2:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:300
translate chinese CR4_We_rep_a88acabb:

    # Caroline "*Shluurrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:301
translate chinese CR4_We_rep_b52e91a4:

    # MC "God... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:304
translate chinese CR4_We_rep_7357f4f3:

    # Caroline "I make that twenty seconds so far. Didn’t lose count, did you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:305
translate chinese CR4_We_rep_a42508c7:

    # MC "No, not at all. Haha, that sounds about right."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:306
translate chinese CR4_We_rep_e7fae07d:

    # Caroline "Ready for the main event, then? As I promised: absolutely no hands."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:309
translate chinese CR4_We_rep_a88acabb_1:

    # Caroline "*Shluurrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:310
translate chinese CR4_We_rep_c7e44b87:

    # MC "Ohhhh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:311
translate chinese CR4_We_rep_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:314
translate chinese CR4_We_rep_6e22eaf1:

    # Caroline "*Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:315
translate chinese CR4_We_rep_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:317
translate chinese CR4_We_rep_e441b104:

    # MC "(I can feel her tongue swirling around my glans - she’s so damn good at this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:320
translate chinese CR4_We_rep_444a25d5:

    # Caroline "*Mpppf!* *GAG*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:322
translate chinese CR4_We_rep_17827721:

    # MC "Ohhh! Fuck, yes! Just like that! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:324
translate chinese CR4_We_rep_6ca75877:

    # Caroline "(One minute down, two to go. Time to up my game!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:327
translate chinese CR4_We_rep_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:328
translate chinese CR4_We_rep_c7efe113:

    # Caroline "([player_name] has started breathing pretty heavily now! I’ve got him on the ropes!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:329
translate chinese CR4_We_rep_cdf43328:

    # Caroline "(He’ll be shooting his hot cum into my mouth, any second now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:332
translate chinese CR4_We_rep_05d1b90c_3:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:333
translate chinese CR4_We_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:334
translate chinese CR4_We_rep_2660f2a6:

    # MC "(When she moans like that, I can feel intense little vibrations travelling down my shaft! She must be doing that on purpose!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:337
translate chinese CR4_We_rep_23da9308_1:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:339
translate chinese CR4_We_rep_22b13036:

    # MC "Mmm! Yes... Oh fuck, you’re so good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:340
translate chinese CR4_We_rep_0dbec2e3:

    # Caroline "*Shluuurrrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:343
translate chinese CR4_We_rep_8272aedb:

    # Caroline "(Let’s see if he enjoys me rubbing his glans against the side of my cheek.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:345
translate chinese CR4_We_rep_76c9d1f1:

    # MC "Ohhh... Keep going! That’s so good!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:347
translate chinese CR4_We_rep_922ea5d9:

    # Caroline "*Suck Suuuuucccck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:349
translate chinese CR4_We_rep_5b528ba6:

    # MC "Hnnng...."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:351
translate chinese CR4_We_rep_0dbec2e3_1:

    # Caroline "*Shluuurrrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:353
translate chinese CR4_We_rep_31f8a2b9:

    # MC "(Shit! There’s no way I’m gonna last three minutes! I’m already edging!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:354
translate chinese CR4_We_rep_8e1baa4d:

    # MC "(I should just grab her head and fuck her mouth!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:357
translate chinese CR4_We_rep_bc4628d7:

    # Caroline "Hmm?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:358
translate chinese CR4_We_rep_111c5b8c:

    # MC "Ugh! Don’t stop! Keep sucking my cock!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:359
translate chinese CR4_We_rep_d06119ca:

    # MC "Ahhh fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:363
translate chinese CR4_We_rep_7d31255b:

    # Caroline "*SUCK SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:364
translate chinese CR4_We_rep_65c2b70e:

    # MC "Ahhhhhh! Shit, I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:365
translate chinese CR4_We_rep_535409ab:

    # Caroline "(Hehe, I knew he wouldn’t last long when I put my mouth to work!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:366
translate chinese CR4_We_rep_1bf35705:

    # MC "Ugh! Hnnnnnggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:376
translate chinese CR4_We_rep_7c6277ae:

    # Caroline "MPFPFF!!! *GAG*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:377
translate chinese CR4_We_rep_fb364c13:

    # Caroline "(Oh wow! There really was A LOT of cum! It’s filling up my mouth!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:380
translate chinese CR4_We_rep_95176477:

    # Caroline "*Gulp Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:381
translate chinese CR4_We_rep_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:382
translate chinese CR4_We_rep_88907b62:

    # Caroline "*Suck* *Gulp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:383
translate chinese CR4_We_rep_19fe42b1:

    # MC "W-Wow... That was... *pant* ...fucking amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:386
translate chinese CR4_We_rep_1b603d17:

    # MC "How long did I last?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:387
translate chinese CR4_We_rep_91e3bed9:

    # Caroline "I sort of lost count too, but I think it was around the two and a half minute mark."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:388
translate chinese CR4_We_rep_fd7ef196:

    # MC "Aww, seriously?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:389
translate chinese CR4_We_rep_c3fb8944:

    # Caroline "Don’t worry, that’s what this pre-sex climax was for. It means you’ll last longer when I finally get to ride you tonight!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:394
translate chinese CR4_We_rep_8f8b31d9:

    # MC "I’d like to fuck your tits first, tonight."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:395
translate chinese CR4_We_rep_11d9f617:

    # Caroline "Sounds fun! I think you’re REALLY going to enjoy this!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:398
translate chinese CR4_We_rep_962f1ffc:

    # Caroline "How does that feel? Are you comfy?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:399
translate chinese CR4_We_rep_7eeaaa96:

    # MC "Oh yeah, that’s great..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:400
translate chinese CR4_We_rep_30d0803c:

    # MC "(Her breasts are so warm, wrapped around my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:403
translate chinese CR4_We_rep_65357032:

    # Caroline "Hehe, you have such a cute expression on your face. You look like you’re really enjoying it when I bounce up and down like this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:404
translate chinese CR4_We_rep_86a2cbdb:

    # MC "It feels so great, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:407
translate chinese CR4_We_rep_6f64e512:

    # MC "Mmm! Just like that..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:409
translate chinese CR4_We_rep_971023ac:

    # Caroline "Do you want me to speed up?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:410
translate chinese CR4_We_rep_d9a2d6ea:

    # MC "No, it’s perfect - just like that. Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:413
translate chinese CR4_We_rep_f7b3ab67:

    # Caroline "Do you like it when I squeeze them really tight, around your cock like that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:414
translate chinese CR4_We_rep_d595c335:

    # MC "Ohh... That’s so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:415
translate chinese CR4_We_rep_94e44052:

    # Caroline "(I love watching him squirm in pleasure, as I tease him with my breasts!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:418
translate chinese CR4_We_rep_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:419
translate chinese CR4_We_rep_3eaf82ea:

    # Caroline "(His cock is pulsing between my boobs - I can feel him quivering each time I massage his dick with them.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:420
translate chinese CR4_We_rep_5c3e2e39:

    # Caroline "I’m going to speed things up a notch now, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:423
translate chinese CR4_We_rep_2dfade31:

    # MC "Uh, yes please!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:425
translate chinese CR4_We_rep_ac6d5d68_1:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:428
translate chinese CR4_We_rep_b987e77d_2:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:429
translate chinese CR4_We_rep_41ac5776:

    # MC "(Holy fuck, this feels incredible. I love how good she is with her breasts!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:430
translate chinese CR4_We_rep_fadde8b8:

    # Caroline "Would you like to hold my tits while you fuck them?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:433
translate chinese CR4_We_rep_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:434
translate chinese CR4_We_rep_508b0e7a:

    # Caroline "You can squeeze harder than that if you want. Don’t worry, you’re not going to hurt me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:436
translate chinese CR4_We_rep_ee272317:

    # MC "Hnng... No, this is perfect... ahh.."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:439
translate chinese CR4_We_rep_ac6d5d68_2:

    # MC "Ohh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:441
translate chinese CR4_We_rep_b0d0a416:

    # MC "I think I’m gonna blow my load soon!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:443
translate chinese CR4_We_rep_3b2848e7:

    # Caroline "I want you to cum over my tits, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:446
translate chinese CR4_We_rep_2ffee189:

    # Caroline "I want to feel your hot sticky seed, coat my boobs."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:447
translate chinese CR4_We_rep_d27440e5:

    # Caroline "Can you do that for me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:448
translate chinese CR4_We_rep_70b8de63:

    # MC "Y-Yes, hnnnng... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:451
translate chinese CR4_We_rep_af2d5043:

    # Caroline "That’s it, cum for me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:452
translate chinese CR4_We_rep_5dc5861b:

    # MC "Ahhhhh! Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:455
translate chinese CR4_We_rep_57e4d2fd:

    # MC "I’m cumming! Hnnnnggg! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:457
translate chinese CR4_We_rep_70b8de63_1:

    # MC "Y-Yes, hnnnng... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:459
translate chinese CR4_We_rep_edde419f:

    # MC "Ohhh! Fuck! Aaarrrghhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:469
translate chinese CR4_We_rep_3ef74e14:

    # Caroline "Oh wow! That’s A LOT of cum!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:470
translate chinese CR4_We_rep_65723723:

    # MC "*Pant Pant* Thanks, Caroline... That was... *Pant* incredible..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:471
translate chinese CR4_We_rep_d9c70231:

    # Caroline "Well, now that we’ve got that out of the way, you should last MUCH longer during the main event!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:472
translate chinese CR4_We_rep_39585864:

    # Caroline "At least, I hope you will - I plan to fuck you A LOT tonight."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:478
translate chinese CR4_love_hotel_lab3_rep_e7fcb8d1:

    # Caroline "How about you and me take a bath together before we head to bed?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:479
translate chinese CR4_love_hotel_lab3_rep_05875b4b:

    # MC "Sure! Sounds good to me. Want me to go run the hot water?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:482
translate chinese CR4_love_hotel_lab3_rep_a64c2743:

    # Caroline "That would be lovely. I’ll just freshen up, here. And I’ll join you in a couple of minutes. Okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:483
translate chinese CR4_love_hotel_lab3_rep_12ff6969:

    # MC "Perfect. See you soon."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:489
translate chinese CR4_love_hotel_lab3_rep_fc60bfed:

    # MC "(Alright, that’s the bath filled up. The water’s nice and hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:490
translate chinese CR4_love_hotel_lab3_rep_ad1f0a27:

    # MC "(I guess I’ll just hop straight in while I wait for Caroline.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:493
translate chinese CR4_love_hotel_lab3_rep_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:494
translate chinese CR4_love_hotel_lab3_rep_bc72340e:

    # MC "(Oh, that’s good...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:497
translate chinese CR4_love_hotel_lab3_rep_f2e95454:

    # MC "(It feels so much larger than the bath we have back home.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:498
translate chinese CR4_love_hotel_lab3_rep_1d9c86eb:

    # MC "(Whenever I move out and get a home of my own, I’d love to get one of those large, square jacuzzi baths. The ones with the water jets.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:499
translate chinese CR4_love_hotel_lab3_rep_289c1903:

    # MC "(That’d be the life...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:502
translate chinese CR4_love_hotel_lab3_rep_7269e167:

    # MC "(Ohh, it looks like Caroline is preparing drinks for the two of us.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:503
translate chinese CR4_love_hotel_lab3_rep_fad6009c:

    # MC "Need a hand, there?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:504
translate chinese CR4_love_hotel_lab3_rep_94423e20:

    # Caroline "I got it! Just give me a minute!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:507
translate chinese CR4_love_hotel_lab3_rep_1d8856cd:

    # MC "(Damn, her ass is so fucking hot. I hope I get a chance to plunge my cock in it tonight.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:508
translate chinese CR4_love_hotel_lab3_rep_6b9fe8bc:

    # Caroline "Do you take ice in your brandy?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:509
translate chinese CR4_love_hotel_lab3_rep_0106dff0:

    # MC "Does anyone?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:510
translate chinese CR4_love_hotel_lab3_rep_6206b643:

    # Caroline "Hehe, I’ve no idea. I’ve never drank it before."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:511
translate chinese CR4_love_hotel_lab3_rep_3e622bbc:

    # MC "Let’s skip the ice then. Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:514
translate chinese CR4_love_hotel_lab3_rep_d44499e7:

    # MC "Where’d you get brandy, by the way?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:515
translate chinese CR4_love_hotel_lab3_rep_9bcffe64:

    # Caroline "Compliments of booking a room with this hotel. It’s a nice place to stay!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:516
translate chinese CR4_love_hotel_lab3_rep_2796e830:

    # MC "It really is!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:519
translate chinese CR4_love_hotel_lab3_rep_e5103960:

    # MC "That’s A LOT of brandy... Are you sure you’re supposed to fill the glass up that much?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:520
translate chinese CR4_love_hotel_lab3_rep_ae1cb100:

    # Caroline "I mean, it’s just like a strong wine, isn’t it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:521
translate chinese CR4_love_hotel_lab3_rep_8cfc5135:

    # MC "I think so?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:524
translate chinese CR4_love_hotel_lab3_rep_ec589135:

    # Caroline "It’ll be fine. Alcohol is alcohol - however they decide to dress it up!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:525
translate chinese CR4_love_hotel_lab3_rep_85a029a3:

    # MC "Fair enough."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:526
translate chinese CR4_love_hotel_lab3_rep_f1b01d7b:

    # Caroline "How’s the water?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:529
translate chinese CR4_love_hotel_lab3_rep_d83b2d1b:

    # MC "Absolutely perfect. You’ll love it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:530
translate chinese CR4_love_hotel_lab3_rep_b82801b5:

    # Caroline "Mmm, you’re right. That’s really warm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:531
translate chinese CR4_love_hotel_lab3_rep_9a83b325:

    # Caroline "Shift your legs a bit, and I’ll squeeze in too."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:534
translate chinese CR4_love_hotel_lab3_rep_56421aec:

    # Caroline "Ohh... That’s nice."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:535
translate chinese CR4_love_hotel_lab3_rep_5c2e271b:

    # MC "Thanks for pouring me the drink. I wasn’t expecting that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:536
translate chinese CR4_love_hotel_lab3_rep_1516391e:

    # Caroline "Come on, it’s hardly a romantic bath without a drink to relax with."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:539
translate chinese CR4_love_hotel_lab3_rep_97628a4e:

    # MC "Shall we make a toast?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:540
translate chinese CR4_love_hotel_lab3_rep_fb8bf7be:

    # Caroline "What would you like to toast to?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:541
translate chinese CR4_love_hotel_lab3_rep_d21e4ff9:

    # MC "To us, to one of the best nights of a long and happy relationship."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:542
translate chinese CR4_love_hotel_lab3_rep_f3e24eaf:

    # Caroline "Hehe, I’ll drink to that."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:545
translate chinese CR4_love_hotel_lab3_rep_ca7a725b:

    # MC "*Slurp*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:546
translate chinese CR4_love_hotel_lab3_rep_ecd5a79e:

    # MC "(Holy shit, this stuff is strong! Maybe topping these glasses to the brim was the wrong decision.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:547
translate chinese CR4_love_hotel_lab3_rep_17e8a8ec:

    # MC "(It’s kinda got a peppery, caramel taste.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:550
translate chinese CR4_love_hotel_lab3_rep_ed8ea072:

    # MC "(Fuck... she looks so hot right now. Her breasts are amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:551
translate chinese CR4_love_hotel_lab3_rep_14477400:

    # MC "(I love the way I can just about make out her pussy through the water.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:554
translate chinese CR4_love_hotel_lab3_rep_0e159e4e:

    # Caroline "I know where you’re looking."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:555
translate chinese CR4_love_hotel_lab3_rep_4cda7266:

    # MC "Haha, caught me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:556
translate chinese CR4_love_hotel_lab3_rep_a56d0540:

    # Caroline "Please. It wasn’t hard to notice. Your eyes were walking their way all over my body."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:557
translate chinese CR4_love_hotel_lab3_rep_29cbdce9:

    # MC "Can you blame me?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:558
translate chinese CR4_love_hotel_lab3_rep_3ecb8197:

    # Caroline "Hehe, not at all."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:561
translate chinese CR4_love_hotel_lab3_rep_5524ad2e:

    # Caroline "Umm... During that toast. You said a “long and happy relationship”."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:562
translate chinese CR4_love_hotel_lab3_rep_6930eada:

    # MC "Yeah, I did."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:563
translate chinese CR4_love_hotel_lab3_rep_b76b8cd6:

    # Caroline "How long do you think we’ll be together?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:564
translate chinese CR4_love_hotel_lab3_rep_b0655be0:

    # MC "As many years as my heart can give you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:567
translate chinese CR4_love_hotel_lab3_rep_6baa51a3:

    # Caroline "You’ve always been good with your words, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:568
translate chinese CR4_love_hotel_lab3_rep_1fc7b593:

    # Caroline "When you say that, do you mea-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:569
translate chinese CR4_love_hotel_lab3_rep_a61b0707:

    # MC "I mean, forever. I’m in this until the final words of the final chapter of this book we’re writing together."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:572
translate chinese CR4_love_hotel_lab3_rep_29c1674b:

    # MC "I love you, Caroline. We get one shot at life on Earth, and I want to spend the rest of mine with you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:573
translate chinese CR4_love_hotel_lab3_rep_88520fcd:

    # Caroline "I love you too, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:574
translate chinese CR4_love_hotel_lab3_rep_fec9f6f6:

    # Caroline "*Hic*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:577
translate chinese CR4_love_hotel_lab3_rep_d99f61be:

    # Caroline "Hehe, sorry. Way to ruin a moment, Caroline! It’s just the drink talking."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:578
translate chinese CR4_love_hotel_lab3_rep_21a5af4d:

    # MC "Haha, don’t worry about it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:581
translate chinese CR4_love_hotel_lab3_rep_c8d9040b:

    # Caroline "Say, this kind of conversation is best kept for bed. How about we spice things up a bit before they get too heavy?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:582
translate chinese CR4_love_hotel_lab3_rep_8ab2029c:

    # MC "Sure. What are you thinking of?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:583
translate chinese CR4_love_hotel_lab3_rep_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:589
translate chinese CR4_love_hotel_lab3_rep_2685510a:

    # Caroline "I want to watch you play with yourself for me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:590
translate chinese CR4_love_hotel_lab3_rep_eed88a2a:

    # MC "Really?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:591
translate chinese CR4_love_hotel_lab3_rep_ee35a1e3:

    # Caroline "Yeah. Just reach under the water and-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:592
translate chinese CR4_love_hotel_lab3_rep_a40a40f4:

    # Caroline "Mmm, exactly like that..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:593
translate chinese CR4_love_hotel_lab3_rep_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:596
translate chinese CR4_love_hotel_lab3_rep_385f4818:

    # MC "Mmm, are you enjoying watching me rub my cock, like this?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:597
translate chinese CR4_love_hotel_lab3_rep_94f1337f:

    # Caroline "Oh yeah, I think I’m going to have to join you... Let me just get my drink out of the way. *Hic*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:598
translate chinese CR4_love_hotel_lab3_rep_b101197d:

    # Caroline "Hehe, sorry!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:601
translate chinese CR4_love_hotel_lab3_rep_31590db7:

    # Caroline "Okay... Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:602
translate chinese CR4_love_hotel_lab3_rep_3c807e07:

    # Caroline "I love your chest... I love watching the muscles on your body. Ahh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:603
translate chinese CR4_love_hotel_lab3_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:606
translate chinese CR4_love_hotel_lab3_rep_0840a2ad:

    # Caroline "I get so wet every time I see you naked. I get so excited when you are looking at my body."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:607
translate chinese CR4_love_hotel_lab3_rep_28ef7884:

    # Caroline "Every time you took photographs of me in my cosplay outfits, you’d ALWAYS leave my panties soaking wet. Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:608
translate chinese CR4_love_hotel_lab3_rep_f81f0d8e:

    # MC "Thank you for letting me, helping you with your business was some of the best fun I’ve ever had."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:614
translate chinese CR4_love_hotel_lab3_rep_b95ca4e5:

    # MC "C’mon, let’s get out of the bath and head to bed."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:615
translate chinese CR4_love_hotel_lab3_rep_f38a57e1:

    # Caroline "Mmm, alright. I’ll grab some towels for us."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:618
translate chinese CR4_love_hotel_lab3_rep_c4493be7:

    # Caroline "Thanks for the bath, [player_name]. I’ll catch you in bed when you finish drying yourself off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:619
translate chinese CR4_love_hotel_lab3_rep_271197a5:

    # MC "Two minutes and I’ll be there!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:626
translate chinese CR4_love_hotel_lab3_rep_13e1a392:

    # MC "Would you be able to help me finish off, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:627
translate chinese CR4_love_hotel_lab3_rep_223c7336:

    # Caroline "Hehe, sure. Would you like me to use my mouth?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:628
translate chinese CR4_love_hotel_lab3_rep_102b1dc6:

    # MC "Can you try your feet, for a change?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:631
translate chinese CR4_love_hotel_lab3_rep_1e88bd99:

    # Caroline "My feet?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:632
translate chinese CR4_love_hotel_lab3_rep_6db5f32d:

    # MC "Yeah, if that’s okay with you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:633
translate chinese CR4_love_hotel_lab3_rep_1fb2a615:

    # Caroline "Not a problem. I hope you’ll enjoy this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:636
translate chinese CR4_love_hotel_lab3_rep_ca1450fe:

    # Caroline "I’m going to massage all of your cock with my feet. You’ll be quivering with pleasure, in no time at all."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:637
translate chinese CR4_love_hotel_lab3_rep_eb64e296:

    # MC "That’s a bold claim to make."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:640
translate chinese CR4_love_hotel_lab3_rep_3a840e25:

    # Caroline "Do you not believe I can do it?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:641
translate chinese CR4_love_hotel_lab3_rep_5f979920:

    # MC "I’ll wait and see."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:642
translate chinese CR4_love_hotel_lab3_rep_0724151f:

    # Caroline "Hehe, let’s see how this plays out."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:645
translate chinese CR4_love_hotel_lab3_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:646
translate chinese CR4_love_hotel_lab3_rep_624a3e08:

    # Caroline "Enjoying that?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:647
translate chinese CR4_love_hotel_lab3_rep_465f8ac0:

    # MC "Ohh... That’s good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:650
translate chinese CR4_love_hotel_lab3_rep_a5f4daba:

    # Caroline "I’ll keep stroking my feet up and down your long, hard cock."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:651
translate chinese CR4_love_hotel_lab3_rep_9fd5033c:

    # MC "Mmm, just like that. Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:653
translate chinese CR4_love_hotel_lab3_rep_147dc962:

    # Caroline "(I love how stiff his cock feels under the soles of my feet.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:656
translate chinese CR4_love_hotel_lab3_rep_c477e361:

    # Caroline "Do you enjoy it when I rub the tip of your cock with my toes?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:658
translate chinese CR4_love_hotel_lab3_rep_2f6fda2f:

    # MC "Ohh... It’s amazing. Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:659
translate chinese CR4_love_hotel_lab3_rep_d0398e22:

    # Caroline "That’s it. Keep moaning for me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:662
translate chinese CR4_love_hotel_lab3_rep_cb0801cd:

    # MC "Ahhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:663
translate chinese CR4_love_hotel_lab3_rep_2528567a:

    # Caroline "(It seems he’s very sensitive when I do THIS around the tip! Perhaps I should focus more on that area.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:666
translate chinese CR4_love_hotel_lab3_rep_ecceb611:

    # Caroline "(I don’t know why, but I feel so... powerful when I do this to [player_name].)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:667
translate chinese CR4_love_hotel_lab3_rep_398bec32:

    # Caroline "(It’s not like giving a blowjob or handjob. They feel unusually submissive compared to using my feet.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:670
translate chinese CR4_love_hotel_lab3_rep_b976556f:

    # MC "Oh God, don’t stop! Mmm! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:671
translate chinese CR4_love_hotel_lab3_rep_e232cb64:

    # Caroline "Are you going to cum? I want you to cum for me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:672
translate chinese CR4_love_hotel_lab3_rep_d1616c2c:

    # MC "Ahhh... fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:675
translate chinese CR4_love_hotel_lab3_rep_73250c5b:

    # Caroline "I want you to ejaculate all over my feet."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:676
translate chinese CR4_love_hotel_lab3_rep_c55fd56d:

    # MC "Fuck! Mmm! Ahh"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:679
translate chinese CR4_love_hotel_lab3_rep_82587c48:

    # Caroline "That’s it, let me milk your hard cock with my soles."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:680
translate chinese CR4_love_hotel_lab3_rep_6a83268a:

    # MC "Ahh - I’m cumnming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:681
translate chinese CR4_love_hotel_lab3_rep_0d8b9876:

    # Caroline "Cum for me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:684
translate chinese CR4_love_hotel_lab3_rep_68376c81:

    # MC "Hnnnnggg! Aaahhhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:685
translate chinese CR4_love_hotel_lab3_rep_1417f8f5:

    # Caroline "Yes! That’s it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:686
translate chinese CR4_love_hotel_lab3_rep_804dfb9f:

    # MC "Ugh! Arrrghhh!!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:696
translate chinese CR4_love_hotel_lab3_rep_2f7b3b4b:

    # MC "*Pant Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:697
translate chinese CR4_love_hotel_lab3_rep_290821a8:

    # Caroline "Wow... that’s a lot of cum! It’s a good thing we’re in the bath! Haha!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:698
translate chinese CR4_love_hotel_lab3_rep_4ef60181:

    # Caroline "I’ll wash myself up and then meet you in the bedroom? Okay? You better have enough juice in you for another round."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:699
translate chinese CR4_love_hotel_lab3_rep_dfdcd904:

    # MC "Y-Yeah *pant* Sure, I’ll see you *pant* there..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:707
translate chinese CR4_love_hotel_rep4_af4e7a38:

    # MC "Caroline? Where are you?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:708
translate chinese CR4_love_hotel_rep4_d10e9b0f:

    # Caroline "Just wait on the bed - I’ll be ready in a second!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:711
translate chinese CR4_love_hotel_rep4_ad6dfa1e:

    # MC "(I wonder what she’s doing now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:712
translate chinese CR4_love_hotel_rep4_14fc9381:

    # Caroline "I got one final surprise for tonight that I wanted to share with you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:713
translate chinese CR4_love_hotel_rep4_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:720
translate chinese CR4_love_hotel_rep4_7fdece30:

    # Caroline "Ta-da! What do you think?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:721
translate chinese CR4_love_hotel_rep4_aee4159e:

    # MC "W-Wow! I think you look amazing!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:722
translate chinese CR4_love_hotel_rep4_786586ce:

    # Caroline "The woman in the lingerie shop recommended it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:725
translate chinese CR4_love_hotel_rep4_725b0cda:

    # Caroline "She might have actually been a lesbian... She was very insistent on helping me try it on..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:726
translate chinese CR4_love_hotel_rep4_4b27b5fb:

    # Caroline "Anyway! I’m glad you like it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:727
translate chinese CR4_love_hotel_rep4_9a5a119f:

    # MC "Your boobs look great in that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:730
translate chinese CR4_love_hotel_rep4_a1ff1429:

    # Caroline "You really think so? How about I come a bit closer, so you can properly check them out."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:731
translate chinese CR4_love_hotel_rep4_0ce0527b:

    # MC "Mmm, I’d like that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:732
translate chinese CR4_love_hotel_rep4_3e05366e:

    # MC "You get hotter every time I see you, Caroline. You know that?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:735
translate chinese CR4_love_hotel_rep4_a5e4a726:

    # Caroline "Really? I was kinda worrying you’d get bored with me someday."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:736
translate chinese CR4_love_hotel_rep4_151273ae:

    # MC "Never, Caroline. You’re the best thing I have in my life, right now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:737
translate chinese CR4_love_hotel_rep4_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:740
translate chinese CR4_love_hotel_rep4_278d5957:

    # MC "I love you too, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:741
translate chinese CR4_love_hotel_rep4_1c5324c1:

    # Caroline "How about we warm up with a blowjob?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:742
translate chinese CR4_love_hotel_rep4_29e82a89:

    # MC "Wow, it really is my lucky night, isn’t it?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:745
translate chinese CR4_love_hotel_rep4_7879d84f:

    # MC "Do you not want me going down on you, for a change? Or-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:746
translate chinese CR4_love_hotel_rep4_6b061beb:

    # Caroline "Relax, I LOVE sucking your cock. And now I have a place I can do it without worrying about Linda or Sara walking in!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:747
translate chinese CR4_love_hotel_rep4_13245e10:

    # MC "Well, if you’re sure."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:750
translate chinese CR4_love_hotel_rep4_9fe39070:

    # Caroline "Of course I am, dummy! Now, just lie back and relax."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:752
translate chinese CR4_love_hotel_rep4_6e79f5ad:

    # Caroline "Let take your sister care of your big problem. Okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:754
translate chinese CR4_love_hotel_rep4_58302159:

    # Caroline "Let your girlfriend take care of your big problem. Okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:755
translate chinese CR4_love_hotel_rep4_90c52b84:

    # MC "Okay!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:758
translate chinese CR4_love_hotel_rep4_d0722184:

    # Caroline "I’m going to suck your fat cock until I’ve drained your balls, of every last drop."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:759
translate chinese CR4_love_hotel_rep4_e6ecb71d:

    # MC "Oh wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:762
translate chinese CR4_love_hotel_rep4_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:763
translate chinese CR4_love_hotel_rep4_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:766
translate chinese CR4_love_hotel_rep4_b0fe80b8:

    # MC "(This is going to be awesome! I can’t wait to fuck Caroline, all night long!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:768
translate chinese CR4_love_hotel_rep4_beb7ec2d:

    # MC "(I wish this night could just last forever, or even loop on repeat. That would be Heaven on Earth.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:771
translate chinese CR4_love_hotel_rep4_3b1121c2:

    # Caroline "I’m going to slip out of this nightgown now - but you just lie exactly where you are."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:772
translate chinese CR4_love_hotel_rep4_7c3ed074:

    # Caroline "I’ll be getting back to you very, very soon."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:775
translate chinese CR4_love_hotel_rep4_40a45763:

    # MC "*Whistle* You look stunning."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:776
translate chinese CR4_love_hotel_rep4_a7d0b09b:

    # Caroline "Hehe, I know."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:777
translate chinese CR4_love_hotel_rep4_252915d1:

    # Caroline "I love that bulge you’ve got going on in your pants. It’s a really hot look for you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:780
translate chinese CR4_love_hotel_rep4_7967eeca:

    # Caroline "However, they’re getting in the way. I’m going to need to take them off."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:781
translate chinese CR4_love_hotel_rep4_30e3323e:

    # MC "Be my guest."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:784
translate chinese CR4_love_hotel_rep4_19fa8835:

    # Caroline "(Wow, he’s so massive! I’m so excited to feel him inside my pussy again tonight.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:785
translate chinese CR4_love_hotel_rep4_914d5b6b:

    # Caroline "(Our first time at the lake was unbelievable. I hadn’t felt that much pleasure, in my life, before.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:788
translate chinese CR4_love_hotel_rep4_ab958b19:

    # Caroline "Hello, [player_name] Junior, you’re about to get licked and sucked so, so hard..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:789
translate chinese CR4_love_hotel_rep4_ac581b5f:

    # MC "(My heart is racing with excitement right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:792
translate chinese CR4_love_hotel_rep4_6ee340ee:

    # Caroline "Get ready, I’m about to blow, so much more than just your mind."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:793
translate chinese CR4_love_hotel_rep4_35cf4e87:

    # MC "Mmm, I can’t wait."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:796
translate chinese CR4_love_hotel_rep4_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:797
translate chinese CR4_love_hotel_rep4_6305452a:

    # MC "Ohhh, fuck... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:798
translate chinese CR4_love_hotel_rep4_6047c7f5:

    # MC "(Holy shit, that feels so good.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:801
translate chinese CR4_love_hotel_rep4_8a0481c2:

    # MC "(It’s so hot watching her make eye contact with me as she licks my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:802
translate chinese CR4_love_hotel_rep4_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:803
translate chinese CR4_love_hotel_rep4_f7fbce5f:

    # MC "Mmm... Ah... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:806
translate chinese CR4_love_hotel_rep4_eec57016:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:807
translate chinese CR4_love_hotel_rep4_e016b0dc:

    # MC "Yes... Mmm... Just like that, Caroline. Ahh.."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:808
translate chinese CR4_love_hotel_rep4_23da9308:

    # Caroline "*Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:811
translate chinese CR4_love_hotel_rep4_b180c7f9:

    # Caroline "*Shluuuurrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:812
translate chinese CR4_love_hotel_rep4_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:813
translate chinese CR4_love_hotel_rep4_535c9877:

    # MC "(Her mouth is so hot and wet, right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:816
translate chinese CR4_love_hotel_rep4_7f304be3:

    # Caroline "*SHLURP SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:817
translate chinese CR4_love_hotel_rep4_12d482e6:

    # Caroline "Mmm! Mmm... "
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:818
translate chinese CR4_love_hotel_rep4_027813fb:

    # MC "Ohhh... Ahhh! "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:821
translate chinese CR4_love_hotel_rep4_7ba0b6ae:

    # Caroline "*Slurp Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:822
translate chinese CR4_love_hotel_rep4_7ce1ac67:

    # Caroline "*Suck Suck Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:823
translate chinese CR4_love_hotel_rep4_2a3dd532:

    # MC "Hnnng... Mmmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:826
translate chinese CR4_love_hotel_rep4_6f0268c3:

    # Caroline "Mppf! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:827
translate chinese CR4_love_hotel_rep4_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:828
translate chinese CR4_love_hotel_rep4_2619ef3a:

    # MC "Ahh... shit... I’m gonna cum soon!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:831
translate chinese CR4_love_hotel_rep4_e0d1bc4f:

    # Caroline "*Suck* *Slurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:832
translate chinese CR4_love_hotel_rep4_9bbc457e:

    # Caroline "(I should probably stop now, and make sure he has at least SOME cum left!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:833
translate chinese CR4_love_hotel_rep4_b54a2991:

    # Caroline "(I would like to get a nice warm creampie at the end of this, after all!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:836
translate chinese CR4_love_hotel_rep4_63d417a6:

    # MC "Fuck... *Pant* That was amazing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:837
translate chinese CR4_love_hotel_rep4_7d4370a0:

    # Caroline "I’m glad you enjoyed it. How about we stop the blowjob now - and make sure you still have enough mojo for the main event?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:838
translate chinese CR4_love_hotel_rep4_1b0cbe21:

    # MC "Y-Yeah, *pant* I think that’s a good call."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:841
translate chinese CR4_love_hotel_rep4_b382b618:

    # Caroline "So, how would you like to do this? Any preference?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:842
translate chinese CR4_love_hotel_rep4_3780552d:

    # MC "I’m not fussy. Any way at all, works for me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:843
translate chinese CR4_love_hotel_rep4_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:846
translate chinese CR4_love_hotel_rep4_c3e092c5:

    # Caroline "How about I kneel down, at the end of the bed?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:847
translate chinese CR4_love_hotel_rep4_fa71544b:

    # Caroline "Then you can fuck me doggy-style from behind."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:848
translate chinese CR4_love_hotel_rep4_b087a138:

    # MC "Yeah, that sounds good to me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:851
translate chinese CR4_love_hotel_rep4_0321f2b1:

    # Caroline "Okay, ready when you are."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:852
translate chinese CR4_love_hotel_rep4_04f6b647:

    # Caroline "Don’t worry about being gentle - I’m already soaking wet. I’ve been waiting for this since dinner!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:855
translate chinese CR4_love_hotel_rep4_36e90c73:

    # MC "Okay, but if it hurts at all, please let me know. I want you to enjoy this too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:856
translate chinese CR4_love_hotel_rep4_34fc4d0e:

    # Caroline "Relax, I’ll be fine. Okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:857
translate chinese CR4_love_hotel_rep4_51fa7e2c:

    # MC "Alright. (This is going to be amazing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:860
translate chinese CR4_love_hotel_rep4_da1816a3:

    # Caroline "Are you enjoying the view?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:861
translate chinese CR4_love_hotel_rep4_19d68c11:

    # MC "Haha, of course."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:862
translate chinese CR4_love_hotel_rep4_cda397d5:

    # Caroline "Hurry up, I want to feel you inside me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:865
translate chinese CR4_love_hotel_rep4_26e3e5cd:

    # MC "I’m coming, Caroline. Just give me a minute."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:866
translate chinese CR4_love_hotel_rep4_8c4fef2d:

    # Caroline "(I’m so fucking horny right now. I feel like I could cum, the second he penetrates my pussy!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:869
translate chinese CR4_love_hotel_rep4_8f3948c3:

    # Caroline "C’mon, [player_name]. Don’t keep a girl waiting!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:870
translate chinese CR4_love_hotel_rep4_95421889:

    # MC "Easy. It’s going in now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:871
translate chinese CR4_love_hotel_rep4_609432c2_1:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:874
translate chinese CR4_love_hotel_rep4_b256155c:

    # Caroline "Oh God... Yes..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:876
translate chinese CR4_love_hotel_rep4_e1e12506:

    # MC "(She wasn’t lying when she said she was wet! Her pussy is drenched with her juices, right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:877
translate chinese CR4_love_hotel_rep4_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:880
translate chinese CR4_love_hotel_rep4_c747894d:

    # Caroline "Oh, my God! YES! AHHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:881
translate chinese CR4_love_hotel_rep4_66397836:

    # MC "Mmm! Fuck... That’s good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:882
translate chinese CR4_love_hotel_rep4_abe2a2c0:

    # Caroline "(His cock is so thick! It feels so good inside my pussy!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:885
translate chinese CR4_love_hotel_rep4_38a39d31:

    # Caroline "Yes, [player_name]! Fill me up! Ahh! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:887
translate chinese CR4_love_hotel_rep4_f6e3d64d:

    # Caroline "Go deeper! I want to feel ALL of you inside me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:889
translate chinese CR4_love_hotel_rep4_3246853b:

    # MC "Hnng... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:892
translate chinese CR4_love_hotel_rep4_3a48011f:

    # Caroline "Ayaaaahhhh!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:893
translate chinese CR4_love_hotel_rep4_5e0df602:

    # MC "Hnnngg... Ohhh... Fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:894
translate chinese CR4_love_hotel_rep4_292d2eaf:

    # MC "(Her pussy is so damn tight! It feels like she’s massaging my cock with it!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:897
translate chinese CR4_love_hotel_rep4_72e16008:

    # Caroline "Oh! Oh, [player_name], I love you!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:898
translate chinese CR4_love_hotel_rep4_642e1fc4:

    # Caroline "Oh fuck! It’s so fucking good! Stir up my pussy with your big fucking cock!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:899
translate chinese CR4_love_hotel_rep4_44b6ee70:

    # MC "Ahh... Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:902
translate chinese CR4_love_hotel_rep4_6869f612:

    # Caroline "Yes, [player_name]! Harder! Harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:903
translate chinese CR4_love_hotel_rep4_4742d564:

    # Caroline "Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:904
translate chinese CR4_love_hotel_rep4_2ff1f26d:

    # MC "Oh! God! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:907
translate chinese CR4_love_hotel_rep4_7f491a35:

    # MC "Your pussy is awesome! It feels so good plunging, my dick deep into you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:908
translate chinese CR4_love_hotel_rep4_38b5500f:

    # Caroline "Mmm! Don’t stop!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:909
translate chinese CR4_love_hotel_rep4_b987e77d_1:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:912
translate chinese CR4_love_hotel_rep4_0f11c0f3:

    # Caroline "OHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:913
translate chinese CR4_love_hotel_rep4_d4184b43:

    # MC "Aaaaaahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:916
translate chinese CR4_love_hotel_rep4_5efb9106:

    # Caroline "*Pant Pant* W-Wow! *Gasp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:917
translate chinese CR4_love_hotel_rep4_d1a9119c:

    # MC "(I think I’ve sent her pleasure receptors into overdrive! She can barely speak right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:920
translate chinese CR4_love_hotel_rep4_fd1f1aa6:

    # Caroline "[player_name]... *Pant* S-Soooo g-good! Ahh! AHH! *GASP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:921
translate chinese CR4_love_hotel_rep4_e36235e9:

    # MC "(I can feel her pussy walls clamping down around my cock. She must have already climaxed a couple of times!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:923
translate chinese CR4_love_hotel_rep4_12780878:

    # Caroline "AHHHH! I’M CUMMING AGAIN!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:926
translate chinese CR4_love_hotel_rep4_34967343:

    # Caroline "*PANT* P-POUND MY SLUTTY LITTLE PUSSY!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:927
translate chinese CR4_love_hotel_rep4_12597dbe:

    # Caroline "MMM! YES! YES! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:928
translate chinese CR4_love_hotel_rep4_9db20aa4:

    # MC "(I hope this hotel room has thick walls!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:931
translate chinese CR4_love_hotel_rep4_b8d97736:

    # Caroline "Ah! Ahhh! Ayyaaahhhh!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:932
translate chinese CR4_love_hotel_rep4_295f8c08:

    # Caroline "I love your cock! Yes! Mmmm! Harder! *Gasp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:933
translate chinese CR4_love_hotel_rep4_69ed3f41:

    # MC "Oh fuck... Hnnngg.... Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:936
translate chinese CR4_love_hotel_rep4_7d40403f:

    # Caroline "Ah... Ah.... Ohhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:937
translate chinese CR4_love_hotel_rep4_cbf9492d:

    # Caroline "Ohh... It’s so fucking good..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:938
translate chinese CR4_love_hotel_rep4_ccb6a6ff:

    # MC "Ahhh... I love you!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:941
translate chinese CR4_love_hotel_rep4_93d4c5ad:

    # MC "Ugh! Mmm! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:942
translate chinese CR4_love_hotel_rep4_6e6c4da2:

    # Caroline "Oh! OHHH! YESSSS!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:945
translate chinese CR4_love_hotel_rep4_092a1a65:

    # Caroline "D-Do you want to *pant* swap positions?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:946
translate chinese CR4_love_hotel_rep4_52143cf5:

    # MC "Ugh, sure! What were you thinking?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:947
translate chinese CR4_love_hotel_rep4_c5036271:

    # Caroline "Let’s try... this!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:950
translate chinese CR4_love_hotel_rep4_25ca52b1:

    # MC "Oh wow! Yoga classes really paid off, huh?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:951
translate chinese CR4_love_hotel_rep4_58bf4fec:

    # Caroline "Hehe, they sure did!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:952
translate chinese CR4_love_hotel_rep4_2668a438:

    # MC "I’ve never seen anyone spread their legs that wide before!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:955
translate chinese CR4_love_hotel_rep4_23c78ec4:

    # Caroline "Pound me really hard, [player_name]. I want to feel you slam my pussy and make me cum!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:956
translate chinese CR4_love_hotel_rep4_ce52ed49:

    # MC "(Damn, she’s got a really nice asshole. I wish I could fuck that too, right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:957
translate chinese CR4_love_hotel_rep4_723ce289:

    # MC "(I should probably stick to her cunt, for the time being.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:960
translate chinese CR4_love_hotel_rep4_5093672b:

    # MC "I’ll go as hard as I can, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:961
translate chinese CR4_love_hotel_rep4_7e6eada2:

    # Caroline "(This is going to feel so good!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:964
translate chinese CR4_love_hotel_rep4_b39e109b:

    # Caroline "Ohhh! Push it deep inside me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:965
translate chinese CR4_love_hotel_rep4_b987e77d_2:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:968
translate chinese CR4_love_hotel_rep4_ec19fa09:

    # Caroline "MMMM!!! Just like that! Ohhh God..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:969
translate chinese CR4_love_hotel_rep4_068d636f:

    # Caroline "(I can feel his hard dick, pushing up against my g-spot!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:972
translate chinese CR4_love_hotel_rep4_020644d5:

    # Caroline "Ah! Ahh! Yes! Fuck me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:973
translate chinese CR4_love_hotel_rep4_347505e7:

    # MC "Ahh... Ohhh... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:974
translate chinese CR4_love_hotel_rep4_310034b3:

    # MC "(Her pussy feels even tighter, with her legs spread like that, it’s like her vagina is sucking on my dick, every time I try to pull out!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:977
translate chinese CR4_love_hotel_rep4_21db2b22:

    # Caroline "Oooohhhh yeeeaaahhh! Harder, [player_name]! Fuck me harder!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:978
translate chinese CR4_love_hotel_rep4_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:979
translate chinese CR4_love_hotel_rep4_163f6ab5:

    # MC "(Her legs are trembling now! She’s clearly loving this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:982
translate chinese CR4_love_hotel_rep4_6546f7c5:

    # Caroline "AAAAAAHHHHHHH!!!! I’m cumming! I’m fucking cumming!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:983
translate chinese CR4_love_hotel_rep4_9246f825:

    # Caroline "(Holy shit! I can barely hold my legs apart! My entire body is trembling with an orgasm!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:984
translate chinese CR4_love_hotel_rep4_c7b67557:

    # MC "(I’m going to cum too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:991
translate chinese CR4_love_hotel_rep4_26b28d94:

    # MC "Hnnng! I’m cumming!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:992
translate chinese CR4_love_hotel_rep4_a1bd9fcd:

    # Caroline "Oh yes! Fill me up! Fill me up! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:994
translate chinese CR4_love_hotel_rep4_0ded8d58:

    # MC "UGHHH! AHHHH!!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1002
translate chinese CR4_love_hotel_rep4_6288f048:

    # Caroline "(I can feel his hot cum, flooding inside me!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1009
translate chinese CR4_love_hotel_rep4_2d9840d5:

    # MC "Ugh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1010
translate chinese CR4_love_hotel_rep4_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1011
translate chinese CR4_love_hotel_rep4_e6dfb30c:

    # MC "Hnnnnggg! Gahhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1019
translate chinese CR4_love_hotel_rep4_44e75a12:

    # Caroline "(Aww, I wish he’d cum inside me. Oh well, there'll be other opportunities tonight.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1024
translate chinese CR4_love_hotel_lab6_rep_9ce99a84:

    # MC "*Pant* That was... really good work..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1025
translate chinese CR4_love_hotel_lab6_rep_56a039be:

    # Caroline "You weren’t half bad yourself! That was REALLY good sex..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1026
translate chinese CR4_love_hotel_lab6_rep_86303a2b:

    # Caroline "Like, seriously mind blowing!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1029
translate chinese CR4_love_hotel_lab6_rep_6bd922e5:

    # MC "Haha, you were shaking and trembling so much, I thought there was an earthquake, for a second."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1030
translate chinese CR4_love_hotel_lab6_rep_91bf12bd:

    # Caroline "Haha! Says the guy who was moaning so loudly, the entire hotel could hear him!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1031
translate chinese CR4_love_hotel_lab6_rep_2317ba68:

    # MC "You’re not seriously trying to blame that on me. Did you hear how loud you were?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1032
translate chinese CR4_love_hotel_lab6_rep_54bb9c9e:

    # Caroline "Haha! I couldn’t hear myself, over your grunting!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1035
translate chinese CR4_love_hotel_lab6_rep_95289020:

    # Caroline "Say, do you think I’ll be able to get another round later on?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1036
translate chinese CR4_love_hotel_lab6_rep_8c04384d:

    # MC "Sure, I don’t see why not."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1039
translate chinese CR4_love_hotel_lab6_rep_ddc8d31a:

    # Caroline "How long until he is hard again?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1040
translate chinese CR4_love_hotel_lab6_rep_c72bbb3d:

    # MC "Maybe an hour? Two at most?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1041
translate chinese CR4_love_hotel_lab6_rep_7d343c75:

    # Caroline "Hmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1044
translate chinese CR4_love_hotel_lab6_rep_f63378c3:

    # Caroline "What if I offered you the chance to fuck ANY hole you wanted, of my body? Would that encourage your guy to get stiff again sooner?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1045
translate chinese CR4_love_hotel_lab6_rep_6b9f9273:

    # MC "Any hole? Even anal?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1046
translate chinese CR4_love_hotel_lab6_rep_afb9e7af:

    # Caroline "If that’s what you want."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1049
translate chinese CR4_love_hotel_lab6_rep_514ace2f:

    # MC "Hmm, I think that sounds like a VERY tempting offer."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1050
translate chinese CR4_love_hotel_lab6_rep_66f65d60:

    # Caroline "In fact, I’ll go one step further."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1051
translate chinese CR4_love_hotel_lab6_rep_eafb33ae:

    # MC "Oh yeah?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1054
translate chinese CR4_love_hotel_lab6_rep_568b06cb:

    # Caroline "Not only can you fuck whatever hole you want - but you can creampie it too."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1055
translate chinese CR4_love_hotel_lab6_rep_da14d9e8:

    # MC "Now, that is enticing."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1056
translate chinese CR4_love_hotel_lab6_rep_856341a0:

    # Caroline "No condoms. Just raw, unprotected fucking."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1057
translate chinese CR4_love_hotel_lab6_rep_74c504ff:

    # MC "Let me just refresh with a drink, and then we’ll get back to it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1060
translate chinese CR4_love_hotel_lab6_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1061
translate chinese CR4_love_hotel_lab6_rep_b0e9580c:

    # Caroline "*Glug Glug*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1062
translate chinese CR4_love_hotel_lab6_rep_87c46138:

    # MC "*Glug*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1065
translate chinese CR4_love_hotel_lab6_rep_4c536e71:

    # MC "He’s probably going to need at least another twenty minutes, to get hard."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1066
translate chinese CR4_love_hotel_lab6_rep_ddb2f738:

    # MC "Do you want to cuddle or nap for a little bit, while we wait?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1067
translate chinese CR4_love_hotel_lab6_rep_a4f55ba3:

    # Caroline "*Glug*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1070
translate chinese CR4_love_hotel_lab6_rep_f30134d3:

    # Caroline "Does the thought of plunging your naked cock, into my soaking wet pussy, not get you hard?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1071
translate chinese CR4_love_hotel_lab6_rep_4eeda26a:

    # Caroline "If it doesn’t, then perhaps the thought of ejaculating, balls-deep, inside me might."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1072
translate chinese CR4_love_hotel_lab6_rep_7e868121:

    # Caroline "Think about yourself grabbing my ass as you bury your shaft, as deep as it will go. Imagine the sensation of my pussy, milking your cock, of every last drop of your cum."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1075
translate chinese CR4_love_hotel_lab6_rep_770ffb5f:

    # Caroline "Well... that did the trick!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1076
translate chinese CR4_love_hotel_lab6_rep_bec2ab11:

    # MC "It certainly did. Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1077
translate chinese CR4_love_hotel_lab6_rep_0a889f8e:

    # MC "Shall we get things started, then?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1078
translate chinese CR4_love_hotel_lab6_rep_54aa39fc:

    # Caroline "Let me just make sure he STAYS hard first."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1081
translate chinese CR4_love_hotel_lab6_rep_e2c07e81:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1082
translate chinese CR4_love_hotel_lab6_rep_3b109c95:

    # MC "Mmm, fuck... You’re so good at that, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1085
translate chinese CR4_love_hotel_lab6_rep_f6d34698:

    # Caroline "Mmm... *Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1086
translate chinese CR4_love_hotel_lab6_rep_38b20d2e:

    # MC "Oh... Fuck... Wow..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1089
translate chinese CR4_love_hotel_lab6_rep_57cac9a1:

    # Caroline "*Shlurp* *Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1090
translate chinese CR4_love_hotel_lab6_rep_2c780c23:

    # MC "AH! Ahh... God..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1091
translate chinese CR4_love_hotel_lab6_rep_b93b7455:

    # MC "(My cock is so sensitive right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1095
translate chinese CR4_love_hotel_lab6_rep_8507d6be:

    # MC "You’re amazing mmm... at that, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1096
translate chinese CR4_love_hotel_lab6_rep_e2c07e81_1:

    # Caroline "*Lick Lick*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1097
translate chinese CR4_love_hotel_lab6_rep_77b9344f:

    # MC "Oh fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1100
translate chinese CR4_love_hotel_lab6_rep_7808d7e8:

    # Caroline "*SHLURP* *SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1101
translate chinese CR4_love_hotel_lab6_rep_c9c76242:

    # MC "Ahh... Yes! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1104
translate chinese CR4_love_hotel_lab6_rep_e0cee18c:

    # Caroline "*Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1105
translate chinese CR4_love_hotel_lab6_rep_13186e8e:

    # MC "Ohhhh! Ahhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1106
translate chinese CR4_love_hotel_lab6_rep_62fc944c:

    # Caroline "Hehe, okay, I think that’s you guaranteed to be hard for a LONG time!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1109
translate chinese CR4_love_hotel_lab6_rep_122033ca:

    # Caroline "Now, how does this angle work for you?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1110
translate chinese CR4_love_hotel_lab6_rep_2ef37352:

    # MC "Looks hot to me, Caroline. I’m ready whenever you are."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1111
translate chinese CR4_love_hotel_lab6_rep_f1bc3444:

    # Caroline "Great!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1114
translate chinese CR4_love_hotel_lab6_rep_ce5b7f11:

    # Caroline "Are you enjoying tonight so far?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1115
translate chinese CR4_love_hotel_lab6_rep_3a112969:

    # MC "Of course I am! This is, like, the best night I have ever had in my whole life!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1116
translate chinese CR4_love_hotel_lab6_rep_f4d91aed:

    # Caroline "Really?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1117
translate chinese CR4_love_hotel_lab6_rep_5da849b6:

    # MC "Yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1120
translate chinese CR4_love_hotel_lab6_rep_c206d120:

    # Caroline "I’m glad you’re enjoying it that much."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1121
translate chinese CR4_love_hotel_lab6_rep_57766d33:

    # Caroline "It’s the best night I’ve ever had too. You have really made me feel so special today, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1122
translate chinese CR4_love_hotel_lab6_rep_2338451b:

    # MC "I love you, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1125
translate chinese CR4_love_hotel_lab6_rep_7da9fa5c:

    # Caroline "I love you too. Now, would you rather fuck me pussy or my ass tonight?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1126
translate chinese CR4_love_hotel_lab6_rep_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1131
translate chinese CR4_love_hotel_lab6_rep_1f46f43e:

    # MC "I just can’t get enough of your pussy, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1132
translate chinese CR4_love_hotel_lab6_rep_1c33864a:

    # Caroline "Hehe, I’m glad you’re enjoying it. It’s all yours."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1135
translate chinese CR4_love_hotel_lab6_rep_94d044b6:

    # Caroline "Mmm... Ohhh fuck..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1136
translate chinese CR4_love_hotel_lab6_rep_f5c09c75:

    # MC "Ahh... It’s so good."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1137
translate chinese CR4_love_hotel_lab6_rep_45f1580b:

    # Caroline "Ohh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1140
translate chinese CR4_love_hotel_lab6_rep_5a5d6077:

    # Caroline "Just like that, [player_name]... Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1141
translate chinese CR4_love_hotel_lab6_rep_09680cc5:

    # MC "Fuck... I don’t know if I’ll last very long, Caroline. I’ve already cum far too many times today!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1142
translate chinese CR4_love_hotel_lab6_rep_1ee665ae:

    # Caroline "Hehe, don’t worry. I’ve enjoyed it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1145
translate chinese CR4_love_hotel_lab6_rep_efd0c315:

    # Caroline "Just fuck me as fast and as hard as you can. Okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1146
translate chinese CR4_love_hotel_lab6_rep_71d7d606:

    # MC "No problem."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1149
translate chinese CR4_love_hotel_lab6_rep_9a554c15:

    # MC "Ohh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1150
translate chinese CR4_love_hotel_lab6_rep_3ca93e03:

    # Caroline "AHHH!! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1153
translate chinese CR4_love_hotel_lab6_rep_58f1820e:

    # Caroline "Oh, my God, you’re so thick! Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1154
translate chinese CR4_love_hotel_lab6_rep_738da62d:

    # Caroline "Wow, you're mmm... stretching my pussy, to the limit! *Gasp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1157
translate chinese CR4_love_hotel_lab6_rep_2b033dd4:

    # Caroline "Oh yes, yes, yes! Holy shit, yes! MMM! FUCK! Ahhhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1158
translate chinese CR4_love_hotel_lab6_rep_cc78f9a1:

    # MC "Ugh! Hnnngg! Aaaahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1159
translate chinese CR4_love_hotel_lab6_rep_6eecb1c1:

    # Caroline "Harder! Harder! *GASP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1162
translate chinese CR4_love_hotel_lab6_rep_158ef57e:

    # MC "Ugh! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1163
translate chinese CR4_love_hotel_lab6_rep_f5b6b7c9:

    # Caroline "I’m cumming! I’m cumming! AAYAAAAHHHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1166
translate chinese CR4_love_hotel_lab6_rep_9674362e:

    # MC "Mmm! Oh God, yes! Hnnng!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1167
translate chinese CR4_love_hotel_lab6_rep_b2ed607b:

    # Caroline "AHHH! AHHH!!! *GASP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1170
translate chinese CR4_love_hotel_lab6_rep_fd359ebe:

    # Caroline "Don’t stop! *PANT* D-DON’T STOP! MMM!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1171
translate chinese CR4_love_hotel_lab6_rep_093716d2:

    # MC "Hnnnggg... I’m gonna cum soon!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1174
translate chinese CR4_love_hotel_lab6_rep_5996c27f:

    # MC "(Where should I finish this time? In Caroline’s pussy or on her ass?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1179
translate chinese CR4_love_hotel_lab6_rep_375ba8ef:

    # MC "(Fuck it, I’ll cum inside her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1180
translate chinese CR4_love_hotel_lab6_rep_ad1b6c11:

    # MC "I’m cumming! Hnngg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1181
translate chinese CR4_love_hotel_lab6_rep_b29d9ef6:

    # Caroline "Ah yes! Cum inside me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1184
translate chinese CR4_love_hotel_lab6_rep_dd889bbe:

    # MC "Hnnnngggg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1185
translate chinese CR4_love_hotel_lab6_rep_c17dcd08:

    # Caroline "Ahh! Fuck me really *Gasp* fast at the end!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1186
translate chinese CR4_love_hotel_lab6_rep_6737f8ad:

    # Caroline "AAAYAAAAAHHHHH!!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1189
translate chinese CR4_love_hotel_lab6_rep_a5cc5cab:

    # MC "Oh! Oh fuck! Yes! Hnng! Mmm!! Ahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1190
translate chinese CR4_love_hotel_lab6_rep_e9ac151a:

    # Caroline "Ahh! AHHHH!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1193
translate chinese CR4_love_hotel_lab6_rep_7345a86b:

    # Caroline "Oh fuck!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1195
translate chinese CR4_love_hotel_lab6_rep_cdfe4848:

    # Caroline "(I’ve never climaxed this hard in my life, before!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1198
translate chinese CR4_love_hotel_lab6_rep_08fe4cb2:

    # MC "Hnnnnnggg! UGH! Ahhhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1208
translate chinese CR4_love_hotel_lab6_rep_5525b914:

    # Caroline "Ohhh... wow... *Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1209
translate chinese CR4_love_hotel_lab6_rep_079d60d2:

    # MC "(I think that’s the last time I’m going to cum tonight. I’ve got nothing left...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1210
translate chinese CR4_love_hotel_lab6_rep_4bb87903:

    # MC "*Pant* Ohh... Caroline..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1213
translate chinese CR4_love_hotel_lab6_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1214
translate chinese CR4_love_hotel_lab6_rep_3601acdc:

    # Caroline "*Pant Pant*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1215
translate chinese CR4_love_hotel_lab6_rep_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1216
translate chinese CR4_love_hotel_lab6_rep_1be968eb:

    # Caroline "I love you too..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1219
translate chinese CR4_love_hotel_lab6_rep_282bbec6:

    # Caroline "*Gasp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1220
translate chinese CR4_love_hotel_lab6_rep_b5ccd5c8:

    # MC "How does it feel?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1221
translate chinese CR4_love_hotel_lab6_rep_4813a6d9:

    # Caroline "Really... warm. I love how it feels when it blasts, up against my cervix. It’s so hot."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1227
translate chinese CR4_love_hotel_lab6_rep_06eb979e:

    # MC "I’m going to pull out and cum over your ass."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1229
translate chinese CR4_love_hotel_lab6_rep_29d7b69b:

    # Caroline "Uh huh! Ahh... Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1240
translate chinese CR4_love_hotel_lab6_rep_461793f8:

    # MC "Ugh! Ahhh... *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1241
translate chinese CR4_love_hotel_lab6_rep_e8ba4d44:

    # MC "HNNNNGGGG!!! Ohhh!! Fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1242
translate chinese CR4_love_hotel_lab6_rep_2e44c4f7:

    # Caroline "Ohh... That was incredible, [player_name]. Thank you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1247
translate chinese CR4_love_hotel_lab6_rep_ec479efd:

    # MC "I’m going to fuck you in the ass."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1248
translate chinese CR4_love_hotel_lab6_rep_45408895:

    # Caroline "Okay, we probably won’t need lube. Your cock should be wet enough, with my juices."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1249
translate chinese CR4_love_hotel_lab6_rep_309e581a:

    # Caroline "Just go slow at first, until you get it in!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1252
translate chinese CR4_love_hotel_lab6_rep_f686530a:

    # Caroline "OHHH!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1253
translate chinese CR4_love_hotel_lab6_rep_49d68aa4:

    # MC "Sorry, did that hurt?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1254
translate chinese CR4_love_hotel_lab6_rep_3ff6c8a3:

    # Caroline "N-Not really. Ah... Just a bit surprising."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1257
translate chinese CR4_love_hotel_lab6_rep_76737861:

    # MC "That’s the tip in your ass. I’m going to thrust the rest in now."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1258
translate chinese CR4_love_hotel_lab6_rep_3d0d6699:

    # Caroline "*Gulp* O-Okay."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1259
translate chinese CR4_love_hotel_lab6_rep_266a4790:

    # Caroline "(Please don’t hurt too much...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1262
translate chinese CR4_love_hotel_lab6_rep_1d05a90b:

    # MC "Mmm... Ahhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1263
translate chinese CR4_love_hotel_lab6_rep_268403d9:

    # Caroline "Ohh... Ah...."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1264
translate chinese CR4_love_hotel_lab6_rep_2ded5ed6:

    # Caroline "(Deep breaths, you can do this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1267
translate chinese CR4_love_hotel_lab6_rep_74cf8956:

    # Caroline "Ahh.. Ohh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1268
translate chinese CR4_love_hotel_lab6_rep_390d8745:

    # MC "(It sounds like she’s starting to moan in pleasure now! This must be feeling pretty good for her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1269
translate chinese CR4_love_hotel_lab6_rep_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1272
translate chinese CR4_love_hotel_lab6_rep_e44f01c4:

    # Caroline "Oh fuck... Ah... Shit..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1273
translate chinese CR4_love_hotel_lab6_rep_6d52e8b8:

    # MC "Are you okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1274
translate chinese CR4_love_hotel_lab6_rep_c4517cea:

    # Caroline "Y-Yeah, it’s just really intense."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1277
translate chinese CR4_love_hotel_lab6_rep_1e7ec8f4:

    # Caroline "OHHH! Mmm! Ahh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1278
translate chinese CR4_love_hotel_lab6_rep_dc52c2f7:

    # Caroline "(Wow, this feels amazing. I’m so damn wet right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1279
translate chinese CR4_love_hotel_lab6_rep_0ed0ee2d:

    # MC "God, your ass is soooo tight! It feels amazing to fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1282
translate chinese CR4_love_hotel_lab6_rep_2144771f:

    # MC "Ah! Ahhh! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1283
translate chinese CR4_love_hotel_lab6_rep_98d47bed:

    # Caroline "*Gasp* Oh! Oh, [player_name]! Ahh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1284
translate chinese CR4_love_hotel_lab6_rep_4f5d4b33:

    # MC "Ugh! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1287
translate chinese CR4_love_hotel_lab6_rep_75374d79:

    # Caroline "Mmm! Cum inside my ass!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1288
translate chinese CR4_love_hotel_lab6_rep_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1290
translate chinese CR4_love_hotel_lab6_rep_8290b60b:

    # Caroline "Fill your sister’s ass with cum! AHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1292
translate chinese CR4_love_hotel_lab6_rep_84bf1e2c:

    # Caroline "Fill your girlfriend’s ass with cum! AHHHH!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1295
translate chinese CR4_love_hotel_lab6_rep_617b11f7:

    # MC "Aaayaaahhhh! HNNNNGGG!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1305
translate chinese CR4_love_hotel_lab6_rep_b2c9e4a1:

    # Caroline "It’s so hot! Oh God! Yes!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1306
translate chinese CR4_love_hotel_lab6_rep_bae9df66:

    # MC "Ughhhh... Ahhh.... *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1307
translate chinese CR4_love_hotel_lab6_rep_5fae972b:

    # MC "W-Wow, that was the best... Thank you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1315
translate chinese CR4_love_hotel_lab7_rep_f2c82357:

    # Caroline "That was... absolutely phenomenal..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1316
translate chinese CR4_love_hotel_lab7_rep_ccbdca25:

    # Caroline "I’d been imagining what this day might be like, for a long time now."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1317
translate chinese CR4_love_hotel_lab7_rep_45d8a747:

    # Caroline "It had always been amazing when I dreamt about it, as I slept."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1320
translate chinese CR4_love_hotel_lab7_rep_7a2b51f3:

    # Caroline "But I always knew, deep down, that reality wouldn’t live up to my dreams and fantasies."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1321
translate chinese CR4_love_hotel_lab7_rep_76090a69:

    # MC "Did tonight, at least come close to how you imagined it would be?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1324
translate chinese CR4_love_hotel_lab7_rep_36fd1fc7:

    # Caroline "Here’s the strange thing..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1325
translate chinese CR4_love_hotel_lab7_rep_17b73922:

    # Caroline "...it was better than I’d ever imagined it would be. It was better than any dream I’d ever had, about us being together like this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1326
translate chinese CR4_love_hotel_lab7_rep_af0ceeff:

    # MC "I’m so happy to hear that."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1329
translate chinese CR4_love_hotel_lab7_rep_05d1b90c:

    # Caroline "Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1330
translate chinese CR4_love_hotel_lab7_rep_8f692224:

    # MC "(I never got the chance to tell her that I feel the same way, before she kissed me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1331
translate chinese CR4_love_hotel_lab7_rep_890577de:

    # MC "(Tonight was absolutely incredible. Indescribable actually.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1334
translate chinese CR4_love_hotel_lab7_rep_3168010c:

    # MC "It was like that for me too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1335
translate chinese CR4_love_hotel_lab7_rep_daa14446:

    # MC "And it’ll be like this every day, for the rest of our lives together, Caroline. I promise."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1336
translate chinese CR4_love_hotel_lab7_rep_10fecdfa:

    # Caroline "I love you, [player_name]."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1339
translate chinese CR4_love_hotel_lab7_rep_4e280471:

    # MC "I love you too, Car-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1340
translate chinese CR4_love_hotel_lab7_rep_7af033e3:

    # Caroline "Zzz..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1341
translate chinese CR4_love_hotel_lab7_rep_4a074974:

    # MC "Sweet dreams."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1344
translate chinese CR4_love_hotel_lab7_rep_822939ed:

    # MC "I love you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1345
translate chinese CR4_love_hotel_lab7_rep_c1b7500e:

    # MC "And I always will."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1346
translate chinese CR4_love_hotel_lab7_rep_8993c011:

    # Caroline "Zzz... me... too..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1354
translate chinese CR4_love_hotel_lab7_rep_875c7c25:

    # Caroline "YAWN!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1355
translate chinese CR4_love_hotel_lab7_rep_0465d0a3:

    # Caroline "(Clear skies. God, what a beautiful day!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1356
translate chinese CR4_love_hotel_lab7_rep_b0c98b47:

    # MC "Hmm... Zzz.."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1359
translate chinese CR4_love_hotel_lab7_rep_7f208eaa:

    # MC "Hmm?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1360
translate chinese CR4_love_hotel_lab7_rep_b8955d7c:

    # MC "Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1361
translate chinese CR4_love_hotel_lab7_rep_ba3bba91:

    # Caroline "Hey, sleepyhead. You’re finally awake. It doesn't surprise me, you slept in late. You kinda used up most of your energy last night."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1364
translate chinese CR4_love_hotel_lab7_rep_3e3259a1:

    # MC "Mmm... Morning... Heh, I guess I did"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1365
translate chinese CR4_love_hotel_lab7_rep_5f210e0f:

    # MC "How’d you sleep?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1366
translate chinese CR4_love_hotel_lab7_rep_d3106d0d:

    # Caroline "Like a baby. I felt so... safe, lying beside you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1368
translate chinese CR4_love_hotel_lab7_rep_147c0569:

    # Caroline "I really wish... It’s a shame the rest of the family can’t know about us being together."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1370
translate chinese CR4_love_hotel_lab7_rep_1e9c765c:

    # Caroline "I really wish... We should think about telling Bob, Linda, and Sara about us."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1371
translate chinese CR4_love_hotel_lab7_rep_0a5be413:

    # MC "Not yet, but someday soon."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1374
translate chinese CR4_love_hotel_lab7_rep_4d3c20fb:

    # MC "Someday soon, you’ll be able to feel the way you felt last night, for the rest of your life. I’m here till the very end, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1375
translate chinese CR4_love_hotel_lab7_rep_f628643a:

    # Caroline "I know..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1376
translate chinese CR4_love_hotel_lab7_rep_77d8677e:

    # Caroline "...and it’s the happy ending I’ve always wanted."
    Caroline ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:240
    old "I want you to suck my cock!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:240
    old "I want to titfuck you!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:612
    old "Leave the bath and rush to the bedroom to continue this there."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:612
    old "Stay in the bath and ask Caroline to give you a footjob."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:986
    old "Shoot your hot potent seed deep inside Caroline’s fertile womb."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:986
    old "Pull out and blow your load over Caroline’s back."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1128
    old "Fuck Caroline’s pussy again."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1128
    old "Fuck Caroline in the ass."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_We_rep.rpy:1176
    old "Empty your balls deep in her soaking wet pussy."
    new ""

