﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:128
translate chinese celia_webcam_scenes_menu1_57a7af8d:

    # Celia "Well? Here I am."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:129
translate chinese celia_webcam_scenes_menu1_4238c9d5:

    # MC "I’m glad to see you, only wore your underwear, like I instructed."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:130
translate chinese celia_webcam_scenes_menu1_568fe0f0:

    # Celia "I see you still aren’t showing your face, you fucking coward."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:132
translate chinese celia_webcam_scenes_menu1_d9001a55:

    # Celia "(Let’s see what [player_name] prepared this time?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:133
translate chinese celia_webcam_scenes_menu1_7ccb9fc9:

    # MC "Sit back and let me have a look at you."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:136
translate chinese celia_webcam_scenes_menu1_5748f373:

    # MC "Mmm... yes. Very nice. Now, where to begin?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:137
translate chinese celia_webcam_scenes_menu1_bf573964:

    # Celia "Begin? What do you mean?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:139
translate chinese celia_webcam_scenes_menu1_670f7455:

    # MC "Now, where should I begin my blackmail?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:141
translate chinese celia_webcam_scenes_menu1_961dfd62:

    # MC "Now, where should I begin my fun with you?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:200
translate chinese celia_webcam_scenes_open_mouth_c1d10c54:

    # MC "I want you to open your mouth for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:201
translate chinese celia_webcam_scenes_open_mouth_fd8c0731:

    # Celia "Open my mouth?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:202
translate chinese celia_webcam_scenes_open_mouth_07266d13:

    # MC "Yes."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:203
translate chinese celia_webcam_scenes_open_mouth_e8d7c423:

    # Celia "Why?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:204
translate chinese celia_webcam_scenes_open_mouth_283456a8:

    # MC "Because I asked, and because you can’t say ‘no’ to me right now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:207
translate chinese celia_webcam_scenes_open_mouth_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:208
translate chinese celia_webcam_scenes_open_mouth_027ffaa0:

    # MC "Oh, come on. That’s hardly open! Wider!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:209
translate chinese celia_webcam_scenes_open_mouth_fe10e82b:

    # Celia "Huh?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:210
translate chinese celia_webcam_scenes_open_mouth_eed785a6:

    # MC "I said wider! Do you want me to leak the photo to the college?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:213
translate chinese celia_webcam_scenes_open_mouth_01c229f7:

    # Celia "Ahhh..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:214
translate chinese celia_webcam_scenes_open_mouth_924de235:

    # MC "Much better."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:222
translate chinese celia_webcam_scenes_open_mouth_menu_9c216d1e:

    # MC "Now, what should I make you do next."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:228
translate chinese celia_webcam_scenes_open_mouth_menu_db14b541:

    # MC "Come closer to the screen for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:230
translate chinese celia_webcam_scenes_open_mouth_menu_61aebd1a:

    # Celia "Seriously? Fuck you, you fucking little creep!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:232
translate chinese celia_webcam_scenes_open_mouth_menu_2b36aa81:

    # Celia "When I find out who you are, I will-"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:234
translate chinese celia_webcam_scenes_open_mouth_menu_39197d84:

    # Celia "I will-"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:235
translate chinese celia_webcam_scenes_open_mouth_menu_1efdd3ab:

    # MC "*Ahem* I would do as I say, or I might just ring the Dean right now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:236
translate chinese celia_webcam_scenes_open_mouth_menu_6aebbe49:

    # Celia "Grr..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:238
translate chinese celia_webcam_scenes_open_mouth_menu_36c96c2f:

    # MC "Yes - very nice!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:239
translate chinese celia_webcam_scenes_open_mouth_menu_5097fb0f:

    # MC "Great view of your cleavage there, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:240
translate chinese celia_webcam_scenes_open_mouth_menu_ade06407:

    # Celia "Well? Have you had enough yet?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:241
translate chinese celia_webcam_scenes_open_mouth_menu_e74181ea:

    # MC "Just a couple more seconds."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:242
translate chinese celia_webcam_scenes_open_mouth_menu_f03a0a56:

    # MC "Okay, you can sit back down."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:256
translate chinese celia_webcam_scenes_open_mouth_menu_a7226c77:

    # MC "I want you to take out that pink dildo that I sent you."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:257
translate chinese celia_webcam_scenes_open_mouth_menu_bf963369:

    # Celia "Oh God... Seriously?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:258
translate chinese celia_webcam_scenes_open_mouth_menu_94c6e832:

    # MC "Seriously. Pick it up and kiss the tip."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:260
translate chinese celia_webcam_scenes_open_mouth_menu_a29ab6b3:

    # Celia "(God, this is so humiliating!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:261
translate chinese celia_webcam_scenes_open_mouth_menu_8803bf16:

    # MC "Perfect. See, you can be obedient when you want to be."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:262
translate chinese celia_webcam_scenes_open_mouth_menu_744f59e8:

    # Celia "Fuck you!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:263
translate chinese celia_webcam_scenes_open_mouth_menu_c1eda685:

    # MC "Well, I was going to go easy on you - but since you were so rude there, I’m going to have to up my game."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:264
translate chinese celia_webcam_scenes_open_mouth_menu_f8a9f021:

    # MC "Start pushing it into your mouth."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:266
translate chinese celia_webcam_scenes_open_mouth_menu_6676edc9:

    # Celia "(Grr... How far is he going to make me go with this?!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:268
translate chinese celia_webcam_scenes_open_mouth_menu_2c1a49b0:

    # Celia "(I wonder if it is one of my students who paid me to change their grade?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:270
translate chinese celia_webcam_scenes_open_mouth_menu_2b7c8e10:

    # Celia "(I wonder what's [player_name] is doing right now. Is he wanking himself off?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:271
translate chinese celia_webcam_scenes_open_mouth_menu_75705ed7:

    # Celia "(They would be the only ones who knew about my scheme.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:272
translate chinese celia_webcam_scenes_open_mouth_menu_90e4858e:

    # MC "Deeper!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:274
translate chinese celia_webcam_scenes_open_mouth_menu_caae4fbb:

    # Celia "*Gag!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:275
translate chinese celia_webcam_scenes_open_mouth_menu_8a1905bb:

    # MC "(Wow! She’s actually taking it pretty deep! I wonder if I can push her to go any further.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:277
translate chinese celia_webcam_scenes_open_mouth_menu_e4a03bf1:

    # Celia "*Gasp!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:278
translate chinese celia_webcam_scenes_open_mouth_menu_25d959a8:

    # Celia "*Cough!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:279
translate chinese celia_webcam_scenes_open_mouth_menu_89c6e608:

    # MC "Hey - did I say you could take it out?!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:280
translate chinese celia_webcam_scenes_open_mouth_menu_2e92b478:

    # MC "I’m gonna have to punish you for that. Tilt your head back and push it right down your throat!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:281
translate chinese celia_webcam_scenes_open_mouth_menu_2d08a5dd:

    # Celia "(Oh no! I haven’t done this since my sorority days!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:283
translate chinese celia_webcam_scenes_open_mouth_menu_81b735b0:

    # Celia "*GAG!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:284
translate chinese celia_webcam_scenes_open_mouth_menu_dc9cce44:

    # Celia "Mppppfffff!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:285
translate chinese celia_webcam_scenes_open_mouth_menu_d0e5c8bd:

    # Celia "Shllurrrrrp!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:286
translate chinese celia_webcam_scenes_open_mouth_menu_3056e69a:

    # MC "(Wow! That’s so fucking hot! I can’t believe she could actually do it!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:288
translate chinese celia_webcam_scenes_open_mouth_menu_e4a03bf1_1:

    # Celia "*Gasp!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:289
translate chinese celia_webcam_scenes_open_mouth_menu_b8964b2e:

    # Celia "Okay! You’ve had your fun, creep! I’m done with this fucking dildo now."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:290
translate chinese celia_webcam_scenes_open_mouth_menu_37450676:

    # MC "Haha! Okay, let’s move on to something else..."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:297
translate chinese celia_webcam_scenes_open_mouth_menu_5dd3a0ab:

    # MC "Alright, that’s me satisfied for today. You were a good slave."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:298
translate chinese celia_webcam_scenes_open_mouth_menu_043ad6cf:

    # Celia "Fuck you, creep!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:299
translate chinese celia_webcam_scenes_open_mouth_menu_9e910f9b:

    # MC "I’m looking forward to playing with you again tomorrow."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:318
translate chinese celia_webcam_scenes_showtounge_2cfc7272:

    # MC "Okay, I want to see your tongue now. Can you stick it out for me?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:321
translate chinese celia_webcam_scenes_showtounge_b182dbb1:

    # Celia "Ahhh...."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:323
translate chinese celia_webcam_scenes_showtounge_af31a1fb:

    # Celia "(This guy is REALLY weird. Why couldn’t I get a normal guy, who wanted to blackmail me for money?!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:325
translate chinese celia_webcam_scenes_showtounge_8437af47:

    # Celia "([player_name] is REALLY dragging this out. Is he actually getting off to me sticking my tongue out?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:332
translate chinese celia_webcam_scenes_showtounge_menu_e57fbcfd:

    # MC "(Now, should I make her come closer? Or suck on her fingers?)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:337
translate chinese celia_webcam_scenes_showtounge_menu_fd02a5fb:

    # MC "Could you come closer for me?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:339
translate chinese celia_webcam_scenes_showtounge_menu_f42ec986:

    # Celia "(Sigh... Let’s just get this over with.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:341
translate chinese celia_webcam_scenes_showtounge_menu_8bc67cd8:

    # Celia "(I’m so horny right now. I never realised just how much I wanted to be told what to do like this.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:344
translate chinese celia_webcam_scenes_showtounge_menu_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:345
translate chinese celia_webcam_scenes_showtounge_menu_33c2963f:

    # MC "Very nice!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:347
translate chinese celia_webcam_scenes_showtounge_menu_b0ed8e05:

    # Celia "(I wonder if this creep is jerking off to me right now... Yuck!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:349
translate chinese celia_webcam_scenes_showtounge_menu_3679c71e:

    # Celia "(Seeing nothing but that faceless blinking red light of my webcam is so hot. I don’t know what [player_name] is doing on the other side. He could be jerking himself off, and there’s no way I can tell.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:355
translate chinese celia_webcam_scenes_showtounge_menu_45774be8:

    # MC "I want you to put two fingers in your mouth and suck on them."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:356
translate chinese celia_webcam_scenes_showtounge_menu_a7ddef7d:

    # Celia "Seriously?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:358
translate chinese celia_webcam_scenes_showtounge_menu_8f93bac6:

    # MC "Unless you want the picture passed around school, then yeah. I’m serious."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:360
translate chinese celia_webcam_scenes_showtounge_menu_d79d828e:

    # MC "Unless you want the picture passed around campus, then yeah. I’m serious."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:362
translate chinese celia_webcam_scenes_showtounge_menu_42a524e7:

    # MC "That’s it - just like that."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:364
translate chinese celia_webcam_scenes_showtounge_menu_9d3687ff:

    # Celia "(Why do I always attract the creeps?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:366
translate chinese celia_webcam_scenes_showtounge_menu_dc4cd801:

    # Celia "(I gotta say, it’s really hot pretending to be completely at his mercy like this...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:367
translate chinese celia_webcam_scenes_showtounge_menu_c61b3798:

    # MC "Hurry up!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:370
translate chinese celia_webcam_scenes_showtounge_menu_bfe4d9c5:

    # MC "Great! Now start sucking on them."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:371
translate chinese celia_webcam_scenes_showtounge_menu_eb0a0c57:

    # Celia "*Suck Suck*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:372
translate chinese celia_webcam_scenes_showtounge_menu_4f5c8744:

    # MC "Perfect! Suck on them, like you’d suck on my cock."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:374
translate chinese celia_webcam_scenes_showtounge_menu_966f7f1e:

    # Celia "(Eww!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:376
translate chinese celia_webcam_scenes_showtounge_menu_530ffbcb:

    # Celia "(Mmm...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:377
translate chinese celia_webcam_scenes_showtounge_menu_4f8dac31:

    # MC "And turn your head to the side - I want a better view of this."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:380
translate chinese celia_webcam_scenes_showtounge_menu_2a6d1cf3:

    # MC "Perfect!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:381
translate chinese celia_webcam_scenes_showtounge_menu_bbdab7f1:

    # Celia "*Shlurp Suck*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:383
translate chinese celia_webcam_scenes_showtounge_menu_7babacaf:

    # Celia "(God... This is so fucking embarrassing!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:385
translate chinese celia_webcam_scenes_showtounge_menu_c9bfc30e:

    # Celia "(Ugh... This is so fucking embarrasing... but it’s turning me on too.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:386
translate chinese celia_webcam_scenes_showtounge_menu_3e4a5822:

    # MC "Alright - that’ll do for now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:396
translate chinese celia_webcam_scenes_take_off_your_bra_626acf7e:

    # MC "Let’s start by having you take off your bra today. I’m looking forward to seeing those perky tits of yours!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:397
translate chinese celia_webcam_scenes_take_off_your_bra_9b324fb5:

    # Celia "You’re a fucking creep. You know that, right?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:398
translate chinese celia_webcam_scenes_take_off_your_bra_54d106ac:

    # MC "Yeah, but you really don’t have a choice here. So hurry up and lose the bra."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:401
translate chinese celia_webcam_scenes_take_off_your_bra_27d57ca5:

    # MC "That’s it - nice and slow for the camera."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:402
translate chinese celia_webcam_scenes_take_off_your_bra_94cb61d6:

    # Celia "You better not be recording this..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:403
translate chinese celia_webcam_scenes_take_off_your_bra_300bae76:

    # MC "(Damn, I should have thought about recording this! Oh well...)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:406
translate chinese celia_webcam_scenes_take_off_your_bra_a438dc60:

    # MC "Very nice. Keep going."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:408
translate chinese celia_webcam_scenes_take_off_your_bra_a6dfd297:

    # Celia "(I shouldn’t have taken money, to change those grades...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:409
translate chinese celia_webcam_scenes_take_off_your_bra_b1bafb36:

    # Celia "(It was the worst fucking idea of my entire life!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:411
translate chinese celia_webcam_scenes_take_off_your_bra_e9d99857:

    # Celia "(I’m kinda glad [player_name] caught me taking bribes to change grades... I don’t think I’d find a man willing to do this kind of relationship with me any other way.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:412
translate chinese celia_webcam_scenes_take_off_your_bra_bd8ba0b1:

    # Celia "(The idea of having to flash my breasts on camera to [player_name] as he pretends to blackmail me is just so fucking hot... It’s so liberating not being in control for a change.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:415
translate chinese celia_webcam_scenes_take_off_your_bra_34dc40e8:

    # Celia "... Well?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:416
translate chinese celia_webcam_scenes_take_off_your_bra_ba0187c1:

    # MC "Awesome!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:426
translate chinese celia_webcam_scenes_take_off_your_bra_menu_97a7c8e5:

    # MC "(Now, what should I make her do?)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:431
translate chinese celia_webcam_scenes_take_off_your_bra_menu_02419a89:

    # MC "I want you to lean in closer to the camera for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:433
translate chinese celia_webcam_scenes_take_off_your_bra_menu_e6135dea:

    # MC "Good - but that’s not close enough. Bring your tits closer to the camera!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:434
translate chinese celia_webcam_scenes_take_off_your_bra_menu_c9ef9bb8:

    # Celia "Ugh! You’re disgusting."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:435
translate chinese celia_webcam_scenes_take_off_your_bra_menu_c61b3798:

    # MC "Hurry up!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:437
translate chinese celia_webcam_scenes_take_off_your_bra_menu_9b8ae0e8:

    # Celia "Happy now?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:438
translate chinese celia_webcam_scenes_take_off_your_bra_menu_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:439
translate chinese celia_webcam_scenes_take_off_your_bra_menu_9f5bcaae:

    # MC "(Just look at those sexy puppies! They’re gorgeous!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:440
translate chinese celia_webcam_scenes_take_off_your_bra_menu_f03a0a56:

    # MC "Okay, you can sit back down."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:446
translate chinese celia_webcam_scenes_take_off_your_bra_menu_6c2aafae:

    # MC "Okay, next thing I want you to do is lick your nipple."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:447
translate chinese celia_webcam_scenes_take_off_your_bra_menu_d233190b:

    # MC "It shouldn’t be difficult, for someone with boobs as big as yours!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:450
translate chinese celia_webcam_scenes_take_off_your_bra_menu_e457d91a:

    # Celia "(Grr... He’s a cheeky bastard!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:451
translate chinese celia_webcam_scenes_take_off_your_bra_menu_59710b77:

    # Celia "(I swear - whenever I find out who this really is, I’ll strangle them with my own bare hands.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:453
translate chinese celia_webcam_scenes_take_off_your_bra_menu_1d7241f0:

    # Celia "(Oh, he’s a cheeky one!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:454
translate chinese celia_webcam_scenes_take_off_your_bra_menu_691372fd:

    # Celia "(I wonder what he’s going to make me do next. I noticed that he’s gradually upping the intensity of our interactions. How far is he going to take things?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:455
translate chinese celia_webcam_scenes_take_off_your_bra_menu_a63fbbfa:

    # MC "Well, hurry up! I haven’t got all night."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:457
translate chinese celia_webcam_scenes_take_off_your_bra_menu_a49f4795:

    # MC "(Awesome! She actually did it! Hahaha!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:459
translate chinese celia_webcam_scenes_take_off_your_bra_menu_35cd67b3:

    # Celia "(I hate this fucking creep!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:460
translate chinese celia_webcam_scenes_take_off_your_bra_menu_4bdaac6b:

    # Celia "(I have to figure out his real identity soon, or he’ll keep asking me to do weirder stuff!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:462
translate chinese celia_webcam_scenes_take_off_your_bra_menu_08cca380:

    # Celia "*Lick* *Lick*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:463
translate chinese celia_webcam_scenes_take_off_your_bra_menu_bf7a8b3d:

    # Celia "(Mmm... I love imagining myself being blackmailed like this. The thrill of knowing that if I don’t figure out a way to stop him quickly enough, then he’ll keep making me do weirder and weirder stuff!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:469
translate chinese celia_webcam_scenes_take_off_your_bra_menu_294aa804:

    # MC "Okay, next thing I want you to do is stand up and rest your tits on the back of the chair."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:470
translate chinese celia_webcam_scenes_take_off_your_bra_menu_5c242c12:

    # Celia "*Sigh* Fine."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:472
translate chinese celia_webcam_scenes_take_off_your_bra_menu_d05b2df2:

    # Celia "(This isn’t the worst thing he could have asked me to do.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:473
translate chinese celia_webcam_scenes_take_off_your_bra_menu_298debb5:

    # MC "(She really does have a great pair of boobs. I can’t wait to play with them someday.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:474
translate chinese celia_webcam_scenes_take_off_your_bra_menu_f8250ae3:

    # MC "(Maybe I’ll get a nice titjob out of her?)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:475
translate chinese celia_webcam_scenes_take_off_your_bra_menu_f03a0a56_1:

    # MC "Okay, you can sit back down."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:481
translate chinese celia_webcam_scenes_take_off_your_bra_menu_95b888c7:

    # MC "And... could you turn to the side for me?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:483
translate chinese celia_webcam_scenes_take_off_your_bra_menu_6e26f759:

    # Celia "Like this?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:484
translate chinese celia_webcam_scenes_take_off_your_bra_menu_71f6e781:

    # MC "Yeah, that’s perfect."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:485
translate chinese celia_webcam_scenes_take_off_your_bra_menu_a565729d:

    # Celia "(How much longer is he going to make me, flash on webcam for him?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:486
translate chinese celia_webcam_scenes_take_off_your_bra_menu_db8bd80f:

    # Celia "(I’ve got coursework to mark and dinner to cook!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:487
translate chinese celia_webcam_scenes_take_off_your_bra_menu_1178a925:

    # MC "Okay, you can turn back round."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:493
translate chinese celia_webcam_scenes_take_off_your_bra_menu_4d9a8274:

    # MC "Right, I want you to pinch your nipples for me now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:494
translate chinese celia_webcam_scenes_take_off_your_bra_menu_3584883f:

    # Celia "Oh, come on!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:495
translate chinese celia_webcam_scenes_take_off_your_bra_menu_5fbc21d8:

    # MC "You’re not in a position to argue with me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:497
translate chinese celia_webcam_scenes_take_off_your_bra_menu_7640e41f:

    # Celia "Grr... Fine."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:498
translate chinese celia_webcam_scenes_take_off_your_bra_menu_2055c732:

    # MC "You’re not even trying! Pinch them harder!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:499
translate chinese celia_webcam_scenes_take_off_your_bra_menu_ce607e4d:

    # MC "I want to see you pull your tits up!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:502
translate chinese celia_webcam_scenes_take_off_your_bra_menu_ab87f00d:

    # Celia "(Ouch! This is so fucking humiliating!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:503
translate chinese celia_webcam_scenes_take_off_your_bra_menu_b19725d6:

    # MC "(Haha! Revenge is sweet!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:505
translate chinese celia_webcam_scenes_take_off_your_bra_menu_566398dc:

    # Celia "Ouch! (This is so fucking humiliating... my panties are soaked!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:506
translate chinese celia_webcam_scenes_take_off_your_bra_menu_362bc980:

    # MC "(Haha! Even if it’s all an act... That revenge is sweet!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:507
translate chinese celia_webcam_scenes_take_off_your_bra_menu_a300dcda:

    # MC "Okay, you can let go now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:513
translate chinese celia_webcam_scenes_take_off_your_bra_menu_bc46ae0b:

    # MC "That was great fun - but I’ve had enough for today."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:514
translate chinese celia_webcam_scenes_take_off_your_bra_menu_2eabf3df:

    # MC "See you tomorrow evening, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:530
translate chinese celia_webcam_scenes_take_off_panties_6519bffc:

    # MC "Let’s turn up the heat today."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:531
translate chinese celia_webcam_scenes_take_off_panties_90629f6b:

    # MC "How about you take off those panties?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:532
translate chinese celia_webcam_scenes_take_off_panties_4b81581a:

    # Celia "I-"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:533
translate chinese celia_webcam_scenes_take_off_panties_4307aa8c:

    # MC "And please, don’t bother protesting. I’m getting tired of your whining."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:536
translate chinese celia_webcam_scenes_take_off_panties_27d57ca5:

    # MC "That’s it - nice and slow for the camera."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:538
translate chinese celia_webcam_scenes_take_off_panties_d78bb37c:

    # Celia "(Of ALL the guys on campus who could have found out my secret, why did it have to be this creep?!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:540
translate chinese celia_webcam_scenes_take_off_panties_ca34256d:

    # Celia "(Of ALL the guys on campus who could have found out my secret, I’m glad it was [player_name]. He REALLY knows how to properly dominate me in this roleplay.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:543
translate chinese celia_webcam_scenes_take_off_panties_573128d8:

    # MC "Nice! I see you keep yourself trimmed down there."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:544
translate chinese celia_webcam_scenes_take_off_panties_26ddb50d:

    # Celia "Fuck off! I don’t need a running commentary."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:545
translate chinese celia_webcam_scenes_take_off_panties_ca1efa09:

    # MC "Watch your language! I have an email ready to send to the Dean!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:546
translate chinese celia_webcam_scenes_take_off_panties_4df604a1:

    # Celia "Fine! Just don’t send it!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:549
translate chinese celia_webcam_scenes_take_off_panties_bcd2f3c1:

    # Celia "There... Happy now?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:550
translate chinese celia_webcam_scenes_take_off_panties_dffa0d8f:

    # MC "Yeah. Now we can move on to the fun part."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:552
translate chinese celia_webcam_scenes_take_off_panties_8306af1e:

    # Celia "(Oh God...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:554
translate chinese celia_webcam_scenes_take_off_panties_d49e492d:

    # Celia "(Oh my... What’s he going to make me do?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:564
translate chinese celia_webcam_scenes_take_off_panties_menu_97a7c8e5:

    # MC "(Now, what should I make her do?)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:569
translate chinese celia_webcam_scenes_take_off_panties_menu_894b63dc:

    # MC "Okay, how about you lean in closer for me?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:571
translate chinese celia_webcam_scenes_take_off_panties_menu_6e26f759:

    # Celia "Like this?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:572
translate chinese celia_webcam_scenes_take_off_panties_menu_4a152cf3:

    # MC "Yeah, that’s good."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:573
translate chinese celia_webcam_scenes_take_off_panties_menu_d95b9b0b:

    # MC "Actually, I want you to climb up on your desk, so I can see your pussy."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:575
translate chinese celia_webcam_scenes_take_off_panties_menu_e1ef7dea:

    # Celia "I swear - if my desk breaks because of this..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:576
translate chinese celia_webcam_scenes_take_off_panties_menu_914adadf:

    # MC "Relax - it’s not going to break. You can’t be THAT heavy."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:578
translate chinese celia_webcam_scenes_take_off_panties_menu_3c73c95b:

    # Celia "Fine! Here we go. Happy now, you little perv?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:579
translate chinese celia_webcam_scenes_take_off_panties_menu_a811c9ad:

    # MC "(Awesome! I can see her pussy! She looks really tight!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:580
translate chinese celia_webcam_scenes_take_off_panties_menu_57d371da:

    # MC "(I’d love to fuck that someday.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:581
translate chinese celia_webcam_scenes_take_off_panties_menu_1d9402c0:

    # MC "Okay, you can get back down now."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:587
translate chinese celia_webcam_scenes_take_off_panties_menu_4bcc3388:

    # MC "I want you to turn around and flash your ass."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:588
translate chinese celia_webcam_scenes_take_off_panties_menu_a78bf700:

    # Celia "(Sigh... Nothing I haven’t done before, I guess.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:590
translate chinese celia_webcam_scenes_take_off_panties_menu_5d596beb:

    # Celia "How’s that?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:591
translate chinese celia_webcam_scenes_take_off_panties_menu_8c2af0ea:

    # MC "Turn the whole way around!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:592
translate chinese celia_webcam_scenes_take_off_panties_menu_0f5dbd96:

    # Celia "Fine!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:594
translate chinese celia_webcam_scenes_take_off_panties_menu_61cd7b17:

    # Celia "How about this?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:595
translate chinese celia_webcam_scenes_take_off_panties_menu_32f7330c:

    # MC "Mmm... Much better!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:596
translate chinese celia_webcam_scenes_take_off_panties_menu_40ec8a8e:

    # MC "(She’s got a great ass on her!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:598
translate chinese celia_webcam_scenes_take_off_panties_menu_5c5433c4:

    # MC "(Just look at those plump cheeks!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:599
translate chinese celia_webcam_scenes_take_off_panties_menu_650350cd:

    # Celia "Have you had enough yet?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:600
translate chinese celia_webcam_scenes_take_off_panties_menu_4e103e06:

    # MC "Yeah, you can turn back around."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:606
translate chinese celia_webcam_scenes_take_off_panties_menu_dd043397:

    # MC "I want you to turn around, so your ass is facing the camera. Then, spread your asscheeks as wide as you can."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:607
translate chinese celia_webcam_scenes_take_off_panties_menu_1683b606:

    # Celia "Eww... You’re gross!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:608
translate chinese celia_webcam_scenes_take_off_panties_menu_b536ca99:

    # MC "I know. Now chop chop! Don’t keep me waiting!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:610
translate chinese celia_webcam_scenes_take_off_panties_menu_d6ee7dda:

    # MC "You’ve got a tight looking asshole! Do you ever do anal?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:611
translate chinese celia_webcam_scenes_take_off_panties_menu_1252995a:

    # Celia "Shut up!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:612
translate chinese celia_webcam_scenes_take_off_panties_menu_16984830:

    # MC "Answer the question."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:613
translate chinese celia_webcam_scenes_take_off_panties_menu_f3265d66:

    # Celia "*Sigh* Once or twice a year."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:614
translate chinese celia_webcam_scenes_take_off_panties_menu_04b126ae:

    # MC "Alright, I’ll let you turn back around."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:620
translate chinese celia_webcam_scenes_take_off_panties_menu_343554ae:

    # MC "Take a step closer and spread your pussy lips for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:621
translate chinese celia_webcam_scenes_take_off_panties_menu_9fb8aa65:

    # MC "Let’s see what you’ve got going on down there."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:623
translate chinese celia_webcam_scenes_take_off_panties_menu_07cd6e05:

    # MC "Cool! You look like a REALLY good fuck."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:624
translate chinese celia_webcam_scenes_take_off_panties_menu_8b31a5da:

    # Celia "Is that supposed to be a compliment?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:625
translate chinese celia_webcam_scenes_take_off_panties_menu_ba86a564:

    # MC "It’s as close to a compliment as you’ll ever get from me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:626
translate chinese celia_webcam_scenes_take_off_panties_menu_66033ab2:

    # Celia "Jerk!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:632
translate chinese celia_webcam_scenes_take_off_panties_menu_9a352b8a:

    # MC "Thanks for showing me your pussy. That’ll do for today’s session."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:633
translate chinese celia_webcam_scenes_take_off_panties_menu_2eabf3df:

    # MC "See you tomorrow evening, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:648
translate chinese celia_webcam_scenes_get_nude_653bb1ce:

    # MC "Change of plans - I want to see you get nude."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:649
translate chinese celia_webcam_scenes_get_nude_ae1b0593:

    # Celia "Like... completely?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:650
translate chinese celia_webcam_scenes_get_nude_db476195:

    # MC "Bare naked."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:653
translate chinese celia_webcam_scenes_get_nude_269a3f14:

    # Celia "Ugh... I can’t believe I have to do this..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:654
translate chinese celia_webcam_scenes_get_nude_54d8afd0:

    # MC "More undressing, less complaining!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:655
translate chinese celia_webcam_scenes_get_nude_875f685c:

    # Celia "Shut up - bras aren’t easy to get off!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:658
translate chinese celia_webcam_scenes_get_nude_006d3440:

    # Celia "Happy now?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:659
translate chinese celia_webcam_scenes_get_nude_2a6db1fd:

    # MC "Getting better."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:660
translate chinese celia_webcam_scenes_get_nude_e2d37326:

    # Celia "You’re an impatient little bastard."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:663
translate chinese celia_webcam_scenes_get_nude_0552287b:

    # MC "(Once I get her fully naked, I’ll be able to make her pose and pleasure herself for me!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:665
translate chinese celia_webcam_scenes_get_nude_7b0065a2:

    # Celia "(I hope he hasn’t got anything too embarrassing planned for this evening...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:667
translate chinese celia_webcam_scenes_get_nude_db591506:

    # Celia "(I hope he has some REALLY embarrassing things planned for this evening...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:670
translate chinese celia_webcam_scenes_get_nude_5a908a92:

    # Celia "Well, that’s me naked. What now?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:671
translate chinese celia_webcam_scenes_get_nude_e3687517:

    # MC "Hmm... Let’s see..."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:682
translate chinese celia_webcam_scenes_get_nude_menu_97a7c8e5:

    # MC "(Now, what should I make her do?)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:690
translate chinese celia_webcam_scenes_get_nude_menu_d785fecc:

    # MC "How about we start off, with you fucking that pink dildo I sent you?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:691
translate chinese celia_webcam_scenes_get_nude_menu_ec11aa94:

    # Celia "You want me to fuck myself on camera!?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:692
translate chinese celia_webcam_scenes_get_nude_menu_f71a54c8:

    # MC "Well, you do have another choice."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:693
translate chinese celia_webcam_scenes_get_nude_menu_cbac2e22:

    # Celia "What’s that?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:694
translate chinese celia_webcam_scenes_get_nude_menu_69995d6b:

    # MC "Don’t fuck yourself, and have your, grades-for-cash scam exposed."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:695
translate chinese celia_webcam_scenes_get_nude_menu_91b57388:

    # MC "Now hurry up and spread those legs, nice and wide for me!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:697
translate chinese celia_webcam_scenes_get_nude_menu_8a53fbcd:

    # MC "That’s perfect!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:699
translate chinese celia_webcam_scenes_get_nude_menu_c172e6a8:

    # Celia "Grr... (Fucking bastard!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:700
translate chinese celia_webcam_scenes_get_nude_menu_43d8c30b:

    # Celia "(I swear, when I find out who he really is, I’ll smash his face in!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:702
translate chinese celia_webcam_scenes_get_nude_menu_0cf2780b:

    # Celia "Grr... (This bastard REALLY knows how to turn me on!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:703
translate chinese celia_webcam_scenes_get_nude_menu_a13a05e7:

    # Celia "(I wonder if he has the balls to try and boss me around in person. God, that would be so hot.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:704
translate chinese celia_webcam_scenes_get_nude_menu_5d33a7bd:

    # MC "Now, where’s that dildo I gave you?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:706
translate chinese celia_webcam_scenes_get_nude_menu_7b4c56af:

    # MC "Brilliant! There’s a good girl."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:707
translate chinese celia_webcam_scenes_get_nude_menu_1818ff95:

    # MC "You already look wet enough - so I’m going to assume that you’re good to go."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:708
translate chinese celia_webcam_scenes_get_nude_menu_c73b5ea3:

    # Celia "I am NOT wet!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:709
translate chinese celia_webcam_scenes_get_nude_menu_dd747d01:

    # MC "Are you sure? You look pretty damn soaked, from this angle. Do you get off on being watched?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:710
translate chinese celia_webcam_scenes_get_nude_menu_a215b950:

    # Celia "Grrr..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:712
translate chinese celia_webcam_scenes_get_nude_menu_60a0921d:

    # MC "Yes, that’s it! Push it in, nice and deep!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:713
translate chinese celia_webcam_scenes_get_nude_menu_31b92986:

    # Celia "(I have to go through with this, but I can’t show any emotion.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:714
translate chinese celia_webcam_scenes_get_nude_menu_86ffbdc3:

    # Celia "(If he thinks that I’m actually enjoying this, then he wins.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:716
translate chinese celia_webcam_scenes_get_nude_menu_72e0c343:

    # MC "Deeper! That’s it!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:717
translate chinese celia_webcam_scenes_get_nude_menu_7615162a:

    # Celia "Ah..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:718
translate chinese celia_webcam_scenes_get_nude_menu_738636eb:

    # MC "Was that a gasp of pleasure there?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:719
translate chinese celia_webcam_scenes_get_nude_menu_7b1b027c:

    # Celia "(Shit! I have to try and not moan!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:720
translate chinese celia_webcam_scenes_get_nude_menu_b1630989:

    # Celia "N-No."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:722
translate chinese celia_webcam_scenes_get_nude_menu_c8acd6bb:

    # Celia "Ah... "
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:723
translate chinese celia_webcam_scenes_get_nude_menu_e4a03bf1:

    # Celia "*Gasp!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:724
translate chinese celia_webcam_scenes_get_nude_menu_62d36ba1:

    # MC "(Hehe! She’s starting to lose it!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:725
translate chinese celia_webcam_scenes_get_nude_menu_c3065b53:

    # MC "(I haven’t even asked her to push it in any deeper, but she’s still going!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:727
translate chinese celia_webcam_scenes_get_nude_menu_4702382f:

    # MC "Start thrusting it in and out of yourself."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:728
translate chinese celia_webcam_scenes_get_nude_menu_8604e224:

    # Celia "Ah... Ah..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:729
translate chinese celia_webcam_scenes_get_nude_menu_1553ca6e:

    # MC "Faster!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:730
translate chinese celia_webcam_scenes_get_nude_menu_8dc5f47e:

    # Celia "Ah! Ah!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:731
translate chinese celia_webcam_scenes_get_nude_menu_c54980b8:

    # MC "I said FASTER!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:733
translate chinese celia_webcam_scenes_get_nude_menu_f6f33b2b:

    # Celia "AHHH! AHHH!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:734
translate chinese celia_webcam_scenes_get_nude_menu_e6a08f67:

    # Celia "(SHIT! I’m cumming!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:735
translate chinese celia_webcam_scenes_get_nude_menu_b958430e:

    # MC "(Woohoo! I made this bitch cum on camera!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:737
translate chinese celia_webcam_scenes_get_nude_menu_1429eeb9:

    # Celia "(Pant. Gasp.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:739
translate chinese celia_webcam_scenes_get_nude_menu_00609a95:

    # Celia "(Damn... I can’t believe he blackmailed me into, cumming for him like that...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:741
translate chinese celia_webcam_scenes_get_nude_menu_68422f49:

    # Celia "(Damn... I can’t believe I came that hard in our blackmail roleplay! That was the hottest thing ever!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:742
translate chinese celia_webcam_scenes_get_nude_menu_975dbe78:

    # MC "Looks like you had fun with that. Put that away and let’s see what we can make you do next."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:752
translate chinese celia_webcam_scenes_get_nude_menu_696151d6:

    # MC "Bring out that pink dildo I sent you..."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:753
translate chinese celia_webcam_scenes_get_nude_menu_d95a1dcf:

    # MC "This time I want you to set it up in front of the webcam."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:755
translate chinese celia_webcam_scenes_get_nude_menu_6e26f759:

    # Celia "Like this?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:756
translate chinese celia_webcam_scenes_get_nude_menu_f34203aa:

    # MC "Yeah."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:757
translate chinese celia_webcam_scenes_get_nude_menu_14c18b8d:

    # Celia "You want me to suck it, or something?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:758
translate chinese celia_webcam_scenes_get_nude_menu_9f8ccad9:

    # MC "No, I want you to sit on it!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:759
translate chinese celia_webcam_scenes_get_nude_menu_fca601cf:

    # Celia "Y-You mean anal?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:760
translate chinese celia_webcam_scenes_get_nude_menu_4e886e02:

    # MC "Yup! Chop chop! Time’s a wastin’."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:763
translate chinese celia_webcam_scenes_get_nude_menu_615779b3:

    # Celia "(I swear, when this blackmail is over, nothing is EVER going in my ass again.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:764
translate chinese celia_webcam_scenes_get_nude_menu_5b776a95:

    # Celia "(I don’t care how much my hubby begs on his birthday - it’s NOT happening!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:766
translate chinese celia_webcam_scenes_get_nude_menu_8fc24181:

    # Celia "(I wonder what a dildo this big will feel like as it slides into my ass...)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:767
translate chinese celia_webcam_scenes_get_nude_menu_cbfc2d73:

    # Celia "(I can’t believe how easily I gave in to [player_name] though. My husband, Gustav, has to BEG for it on his birthday each year!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:768
translate chinese celia_webcam_scenes_get_nude_menu_1bbfe34f:

    # MC "That’s it - keep going."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:770
translate chinese celia_webcam_scenes_get_nude_menu_3dc138c6:

    # MC "Nice spreading of the asscheeks - You’re clearly a pro at this."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:771
translate chinese celia_webcam_scenes_get_nude_menu_5da7889c:

    # Celia "Fuck you! I don’t need a running commentary."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:772
translate chinese celia_webcam_scenes_get_nude_menu_2f3db85a:

    # MC "I was just trying to be helpful."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:773
translate chinese celia_webcam_scenes_get_nude_menu_38bbd493:

    # Celia "(Okay... here we go. Deep breaths. One, two, three!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:775
translate chinese celia_webcam_scenes_get_nude_menu_71cec796:

    # Celia "Oooohhh!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:776
translate chinese celia_webcam_scenes_get_nude_menu_8cf67f52:

    # Celia "(Jesus Christ! This must be, at least a third, thicker than my husband!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:777
translate chinese celia_webcam_scenes_get_nude_menu_b315f619:

    # MC "Very good! Let’s see you bounce up and down on it a bit!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:778
translate chinese celia_webcam_scenes_get_nude_menu_57bbded4:

    # Celia "Seriously!?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:780
translate chinese celia_webcam_scenes_get_nude_menu_e8b8f423:

    # MC "Nice!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:781
translate chinese celia_webcam_scenes_get_nude_menu_4ccdf65e:

    # Celia "Ah! Ah... Ha-happy now!? Ah..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:782
translate chinese celia_webcam_scenes_get_nude_menu_66f196cf:

    # MC "You sound like you’re enjoying yourself a bit too much there!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:783
translate chinese celia_webcam_scenes_get_nude_menu_26b09b38:

    # Celia "I- I- am not!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:784
translate chinese celia_webcam_scenes_get_nude_menu_b3af6c89:

    # MC "Okay - in that case, I’ll let you take a seat again."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:791
translate chinese celia_webcam_scenes_get_nude_menu_79cc515c:

    # MC "I want you to sit on your keyboard."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:792
translate chinese celia_webcam_scenes_get_nude_menu_fe10e82b:

    # Celia "Huh?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:793
translate chinese celia_webcam_scenes_get_nude_menu_15a72238:

    # MC "Did you not hear me?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:794
translate chinese celia_webcam_scenes_get_nude_menu_d1c5e136:

    # Celia "I did... It’s just a little strange."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:796
translate chinese celia_webcam_scenes_get_nude_menu_9a1d53e0:

    # Celia "(I honestly thought he’d have me doing something more perverted than this.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:797
translate chinese celia_webcam_scenes_get_nude_menu_ad1bc8b6:

    # Celia "(How much longer, until he gets bored and calls it a night?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:798
translate chinese celia_webcam_scenes_get_nude_menu_ff0d5fb5:

    # MC "Okay, you can sit back down on your chair."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:807
translate chinese celia_webcam_scenes_get_nude_menu_ca4b944c:

    # MC "I left you another present, Ms. Celia. I think you’re going to really like this one."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:808
translate chinese celia_webcam_scenes_get_nude_menu_0fc12980:

    # MC "It’s an outfit. So go and get dressed. Come back when you’re ready."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:810
translate chinese celia_webcam_scenes_get_nude_menu_b64497bf:

    # MC "(Whistle!) Looking good, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:811
translate chinese celia_webcam_scenes_get_nude_menu_952bfdc4:

    # MC "(I knew she’d look great in this outfit. I took Judy’s advice, and decided to go for something that wasn’t too intense.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:812
translate chinese celia_webcam_scenes_get_nude_menu_f8160d90:

    # MC "(The lingerie has some BDSM themes to it, but it isn’t the most kinky one I could have chosen!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:813
translate chinese celia_webcam_scenes_get_nude_menu_6ebd2081:

    # MC "Stand in front of the camera for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:815
translate chinese celia_webcam_scenes_get_nude_menu_6e26f759_1:

    # Celia "Like this?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:816
translate chinese celia_webcam_scenes_get_nude_menu_75715e4e:

    # MC "Perfect."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:819
translate chinese celia_webcam_scenes_get_nude_menu_55e4c9e7:

    # Celia "(Hopefully he’ll just want to look at me for a bit, tonight.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:821
translate chinese celia_webcam_scenes_get_nude_menu_cc0df622:

    # Celia "(I’m hoping he wants to do more than just look at me tonight.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:823
translate chinese celia_webcam_scenes_get_nude_menu_2948ead3:

    # MC "Okay, go ahead and take a seat."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:825
translate chinese celia_webcam_scenes_get_nude_menu_c7e57302:

    # MC "You look great in that lingerie, Ms. Celia."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:826
translate chinese celia_webcam_scenes_get_nude_menu_534f91e8:

    # MC "That said, I think the bra I chose, was perhaps a size too small."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:827
translate chinese celia_webcam_scenes_get_nude_menu_1d1b1617:

    # Celia "Creep..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:828
translate chinese celia_webcam_scenes_get_nude_menu_c124e620:

    # MC "Let’s see how you look from behind."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:829
translate chinese celia_webcam_scenes_get_nude_menu_ede3d4c9:

    # MC "Sit up on the desk for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:831
translate chinese celia_webcam_scenes_get_nude_menu_7cdfce84:

    # MC "Mmm! Very good!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:832
translate chinese celia_webcam_scenes_get_nude_menu_bc0da447:

    # Celia "(God, this is so fucking humiliating!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:833
translate chinese celia_webcam_scenes_get_nude_menu_36565c50:

    # MC "Now, lean forward and let me get a better view of your ass."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:835
translate chinese celia_webcam_scenes_get_nude_menu_2d7439bc:

    # MC "(Ms. Celia’s got an incredible ass!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:836
translate chinese celia_webcam_scenes_get_nude_menu_c961f779:

    # MC "(I could fuck that, all day long!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:837
translate chinese celia_webcam_scenes_get_nude_menu_5489d4ed:

    # MC "Lean a bit further forward for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:839
translate chinese celia_webcam_scenes_get_nude_menu_6e26f759_2:

    # Celia "Like this?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:840
translate chinese celia_webcam_scenes_get_nude_menu_38ec070e:

    # MC "That’s great!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:841
translate chinese celia_webcam_scenes_get_nude_menu_2d7bf073:

    # MC "Okay, now turn around. I want you to squat on the chair and spread your thighs for me."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:842
translate chinese celia_webcam_scenes_get_nude_menu_57bbded4_1:

    # Celia "Seriously!?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:843
translate chinese celia_webcam_scenes_get_nude_menu_6b407b1e:

    # MC "And while you’re doing that, I want you to start rubbing your pussy."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:846
translate chinese celia_webcam_scenes_get_nude_menu_a942869d:

    # Celia "You sick, fucking pervert!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:848
translate chinese celia_webcam_scenes_get_nude_menu_a320690e:

    # Celia "You sick, fucking pervert! ([player_name]... You're slowly getting better and better.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:849
translate chinese celia_webcam_scenes_get_nude_menu_2807f15e:

    # MC "You know what? I was going to end it here tonight, but since you’re being so rude, you’re gonna have to take your panties off, as punishment."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:850
translate chinese celia_webcam_scenes_get_nude_menu_744f59e8:

    # Celia "Fuck you!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:851
translate chinese celia_webcam_scenes_get_nude_menu_e8995369:

    # MC "Now you have to finger yourself, to climax for me too. Unless, of course, you want me to send the pictures to the Dean."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:852
translate chinese celia_webcam_scenes_get_nude_menu_ddaed137:

    # Celia "Grr... Fine! Hang on..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:854
translate chinese celia_webcam_scenes_get_nude_menu_b7dca97a:

    # MC "Much better! Okay, start working your pussy with those fingers."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:855
translate chinese celia_webcam_scenes_get_nude_menu_7615162a_1:

    # Celia "Ah..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:856
translate chinese celia_webcam_scenes_get_nude_menu_3bd7211d:

    # MC "Come on - is that how you masturbate?! Get your fingers in deeper!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:858
translate chinese celia_webcam_scenes_get_nude_menu_5c8afb9d:

    # Celia "Oh! Ah!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:859
translate chinese celia_webcam_scenes_get_nude_menu_1553ca6e_1:

    # MC "Faster!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:860
translate chinese celia_webcam_scenes_get_nude_menu_eb4ae9fe:

    # Celia "Ahh! Ahhhhhh!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:861
translate chinese celia_webcam_scenes_get_nude_menu_1af23ae3:

    # MC "Don’t stop! I want to see you cum for me!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:863
translate chinese celia_webcam_scenes_get_nude_menu_6be0e503:

    # Celia "Oh! Oh shit!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:864
translate chinese celia_webcam_scenes_get_nude_menu_7776709d:

    # MC "Cum for me!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:865
translate chinese celia_webcam_scenes_get_nude_menu_afc3c848:

    # Celia "Ahhhhhhh!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:866
translate chinese celia_webcam_scenes_get_nude_menu_70cd2508:

    # Celia "(Holy Fuck! I can’t believe I came, while being filmed!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:867
translate chinese celia_webcam_scenes_get_nude_menu_ae2fa314:

    # MC "Wonderful! Take a seat again, Ms. Celia."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:885
translate chinese celia_webcam_scenes_get_nude_menu_a0184c83:

    # MC "Okay, that’s all for today. Go ahead and put your clothes back on."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:886
translate chinese celia_webcam_scenes_get_nude_menu_bd6ed941:

    # MC "I’ll see you again, tomorrow evening."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:887
translate chinese celia_webcam_scenes_get_nude_menu_9850f5f6:

    # Celia "(He’s seen me naked. How much further can he take this?!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:908
translate chinese CeR1_vibrator_event_f491e5c9:

    # MC "Okay, next I want you to check your locker. I’ve left you a little present there."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:909
translate chinese CeR1_vibrator_event_8773c9e0:

    # Celia "What?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:910
translate chinese CeR1_vibrator_event_31c0ab77:

    # MC "A little pink vibrator. I’m sure you’ll grow to love it."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:912
translate chinese CeR1_vibrator_event_eaf15615:

    # MC "That’s the one!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:913
translate chinese CeR1_vibrator_event_f09727e5:

    # Celia "You can’t be serious."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:914
translate chinese CeR1_vibrator_event_5b154e92:

    # MC "I’m sure you know the drill by now. Stand up, put it in your body and I’ll turn it on."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:915
translate chinese CeR1_vibrator_event_1d1b1617:

    # Celia "Creep..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:917
translate chinese CeR1_vibrator_event_7615162a:

    # Celia "Ah..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:918
translate chinese CeR1_vibrator_event_f0d4a1a8:

    # MC "Deeper! I don’t want it falling out when it starts vibrating."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:920
translate chinese CeR1_vibrator_event_13ff39ca:

    # Celia "(Shit! I hope this creep doesn't make me cum on camera!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:922
translate chinese CeR1_vibrator_event_32a6e5a3:

    # Celia "(This vibe looks so tiny... It can’t be that powerful, right?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:924
translate chinese CeR1_vibrator_event_c94e8930:

    # Celia "There, it’s in. Happy now?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:925
translate chinese CeR1_vibrator_event_a8f6080a:

    # MC "Okay, here we go."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:926
translate chinese CeR1_vibrator_event_ddba6703:

    # MC "(Just need to press the button and...)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:928
translate chinese CeR1_vibrator_event_ccebb97c:

    # Celia "Ahhh!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:929
translate chinese CeR1_vibrator_event_80a6012d:

    # Celia "(Holy shit! This thing is powerful!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:931
translate chinese CeR1_vibrator_event_76766aa7:

    # Celia "Oh God! Ah! AHHH!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:932
translate chinese CeR1_vibrator_event_f1833156:

    # Celia "T-Turn it off! Ohhh! Oh fuck!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:933
translate chinese CeR1_vibrator_event_453215b6:

    # MC "What’s wrong Ms. Celia?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:934
translate chinese CeR1_vibrator_event_20781122:

    # Celia "Fuck! AHHHHHH!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:935
translate chinese CeR1_vibrator_event_e66767f6:

    # MC "(Good to know, this thing works well!)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:936
translate chinese CeR1_vibrator_event_ac2c04b4:

    # MC "(I guess I’ll turn it off now, and save the battery for later.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:938
translate chinese CeR1_vibrator_event_1c35ddeb:

    # Celia "*Pant!* *Gasp!*"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:940
translate chinese CeR1_vibrator_event_2e6cdf48:

    # Celia "(Fucking creep... That was sooo embarrassing.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:942
translate chinese CeR1_vibrator_event_d7cf8d42:

    # Celia "(Oh my God... That was so embarrassing! I came sooo hard! I hope he does it again.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:943
translate chinese CeR1_vibrator_event_9204ae2c:

    # MC "Now that I know it works, I want you to wear it to college tomorrow."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:944
translate chinese CeR1_vibrator_event_972585a5:

    # Celia "No way!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:945
translate chinese CeR1_vibrator_event_48844f3a:

    # MC "Oh, and no panties either."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:946
translate chinese CeR1_vibrator_event_60f4e51b:

    # Celia "Ugh! When I get my hands on you, I swear to God I will-"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:947
translate chinese CeR1_vibrator_event_91d25007:

    # MC "You’re forgetting that I can end your career with a single email, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:948
translate chinese CeR1_vibrator_event_ca7ce194:

    # Celia "Hmmph.... Fine!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:949
translate chinese CeR1_vibrator_event_982596ab:

    # MC "Okay, let’s see what else I can make you do tonight..."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:961
translate chinese celia_webcam_scenes_get_my_present_cf5c4cff:

    # MC "Good evening, Ms. Celia!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:962
translate chinese celia_webcam_scenes_get_my_present_7b819a4d:

    # Celia "Alright, what’s the gig tonight? You gonna have me flash my tits or ass again?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:963
translate chinese celia_webcam_scenes_get_my_present_deca2c54:

    # MC "Nothing so vulgar. I left you a present actually - take a look in your locker."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:965
translate chinese celia_webcam_scenes_get_my_present_48502d84:

    # Celia "A dildo?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:966
translate chinese celia_webcam_scenes_get_my_present_2aca321d:

    # MC "And look, it’s your favourite colour too!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:967
translate chinese celia_webcam_scenes_get_my_present_7c5eb3ff:

    # Celia "I don’t even like pink!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:969
translate chinese celia_webcam_scenes_get_my_present_360973c4:

    # Celia "What the fuck are you expecting me to do with this?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:970
translate chinese celia_webcam_scenes_get_my_present_89582761:

    # Celia "You want me to perform some perverted camshow for you?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:971
translate chinese celia_webcam_scenes_get_my_present_59ce0318:

    # MC "No no! You two have only just met. How about you introduce yourself to your new toy, with a kiss?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:974
translate chinese celia_webcam_scenes_get_my_present_7e29ae3d:

    # Celia "(Mwah!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:975
translate chinese celia_webcam_scenes_get_my_present_9c21f0b4:

    # MC "See? A match made in Heaven."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:976
translate chinese celia_webcam_scenes_get_my_present_e9373ec4:

    # MC "I’m sure you two will have a lot of fun together, in the coming days."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:998
translate chinese CeR1_order1_first_f1ca4e15:

    # MC "We’re going to do something a little different tonight, Ms. Celia."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:999
translate chinese CeR1_order1_first_8c67cc17:

    # Celia "Hmm? And what’s that going to be?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1001
translate chinese CeR1_order1_first_ff49db26:

    # MC "Tomorrow, in college, you are going to have to make out with [player_name]."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1002
translate chinese CeR1_order1_first_868633fe:

    # Celia "..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1005
translate chinese CeR1_order1_first_ae90f7cd:

    # Celia "Hahahahaha!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1006
translate chinese CeR1_order1_first_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1007
translate chinese CeR1_order1_first_67e65d90:

    # Celia "You can’t be serious! Ahahahahaha!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1008
translate chinese CeR1_order1_first_eaebb4f5:

    # MC "HEY! STOP LAUGHING!"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1012
translate chinese CeR1_order1_first_4b5b8052:

    # Celia "Why [player_name]? That’s a very specific request for you to make."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1013
translate chinese CeR1_order1_first_4acfdcdb:

    # MC "Because I was there, the day you humiliated him."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1015
translate chinese CeR1_order1_first_9cc5446a:

    # Celia "And why do you think I’d make out with [player_name] on campus?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1016
translate chinese CeR1_order1_first_c2cd569a:

    # MC "Because I want you to feel the humiliation [player_name] felt when you publicly mocked him for asking you out."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1017
translate chinese CeR1_order1_first_4638a483:

    # MC "I was there, the day everyone laughed, while you treated him so cruelly."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1020
translate chinese CeR1_order1_first_4e046e07:

    # MC "So, tomorrow afternoon, you are going to go into the boy’s toilets."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1021
translate chinese CeR1_order1_first_b7ce09be:

    # MC "I will arrange for [player_name] to be there - he won’t know why though."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1022
translate chinese CeR1_order1_first_d120181a:

    # MC "You MUST make out with him. If you don’t, I will know, and the photograph will be released to the Dean. Do you understand?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1023
translate chinese CeR1_order1_first_c1f14762:

    # Celia "(Mmm... This fantasy is so hot! I can’t wait to see what else he has planned for me!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1025
translate chinese CeR1_order1_first_21759228:

    # Celia "Yes... (Dammit! This bastard has me like a puppet on a string."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1027
translate chinese CeR1_order1_first_8e45d07a:

    # Celia "Yes... (Mmm... This blackmail fantasy just keeps getting hotter! He’s controlling me like I’m a marionette on a string!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1045
translate chinese CeR1_order2_38697a51:

    # MC "Did you have fun making-out with [player_name]?"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1046
translate chinese CeR1_order2_f1281640:

    # MC "I must say, he looked rather happy, coming out of the toilets. So I knew you must have gone through with it. Nice job!."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1047
translate chinese CeR1_order2_e6b87a9f:

    # Celia "Grr... You disgusting bastard."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1048
translate chinese CeR1_order2_8f444d90:

    # MC "I think that [player_name] is still owed, more of an apology, than a simple kiss though."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1049
translate chinese CeR1_order2_cbe8a2bc:

    # Celia "WHAT?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1050
translate chinese CeR1_order2_c9b8350f:

    # MC "I want you to offer him, either a blowjob, or to let him fuck your ass."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1051
translate chinese CeR1_order2_7e9b21ce:

    # Celia "That’s fucking insane!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1052
translate chinese CeR1_order2_139b2838:

    # MC "Well, if that’s how you feel... I can just send a quick email here..."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1055
translate chinese CeR1_order2_88206a4f:

    # Celia "W-Wait!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1056
translate chinese CeR1_order2_53eddde0:

    # Celia "I... I’ll do it..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1057
translate chinese CeR1_order2_a0bc4f82:

    # MC "Good girl! I thought you’d come around."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1058
translate chinese CeR1_order2_552b38af:

    # MC "I will ensure that [player_name] is waiting in the boy’s toilets, again for you."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1059
translate chinese CeR1_order2_09ebe611:

    # MC "He won’t know what’s coming, so you shall have to proposition him."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1061
translate chinese CeR1_order2_0e43f7d5:

    # Celia "(God... [player_name] is going to think I’m some kind of horny slut now!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1063
translate chinese CeR1_order2_6f59366b:

    # Celia "(God, this fantasy is starting to turn me into a horny slut!)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1077
translate chinese CeR1_order2_8860b6dc:

    # Celia "Alright you little creep. I’m here."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1078
translate chinese CeR1_order2_2f1be4bf:

    # MC "(Hehe, let’s see if I can get another blowjob out of her.)"
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1079
translate chinese CeR1_order2_2543179d:

    # MC "Sit up straight for me. No slouching."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1082
translate chinese CeR1_order2_ca934746:

    # MC "Good girl."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1083
translate chinese CeR1_order2_8ea70e80:

    # MC "Now, your next assignment is going to involve you going into the college toilets again."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1084
translate chinese CeR1_order2_3b2847c9:

    # MC "This time you’re to go into the third male stall. You’ll find the door open."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1087
translate chinese CeR1_order2_20ac30e3:

    # Celia "You’re joking! Do you have any idea how risky it’ll be to go into the male toilets a third time!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1088
translate chinese CeR1_order2_4870f318:

    # Celia "Haha, I could lose my job if I get caught! You’re insane!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1089
translate chinese CeR1_order2_bc41fb6f:

    # MC "I’m not insane. And let me assure you - there will be someone waiting for you in the next cubicle."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1092
translate chinese CeR1_order2_6f4c18ef:

    # Celia "What?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1093
translate chinese CeR1_order2_8b6a2803:

    # MC "You will suck their cock through a glory hole that has been installed."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1094
translate chinese CeR1_order2_ca535894:

    # Celia "Ugh! That’s fucking disgusting!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1096
translate chinese CeR1_order2_3621205d:

    # Celia "(Nice... [player_name] remembered that I wanted to try it?)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1098
translate chinese CeR1_order2_9e9d12ea:

    # MC "Watch your language. Do I need to remind you that failure to cooperate will lead to your secrets being released to the Dean, and to the police."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1099
translate chinese CeR1_order2_6aebbe49:

    # Celia "Grr..."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1100
translate chinese CeR1_order2_ca608997:

    # MC "Good. Now, I shall send someone to meet you there."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1103
translate chinese CeR1_order2_8fdf627c:

    # Celia "Sending someone yet again? Too scared to show your own damned face?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1104
translate chinese CeR1_order2_08c2e0dd:

    # MC "I’m not scared. I am simply sitting back and enjoying the show."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1105
translate chinese CeR1_order2_fb7b59cb:

    # MC "Make sure your give my friend some excellent head tomorrow. I expect you to be on top of your blowjob game."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1116
translate chinese CeR1_order2_fd088b71:

    # MC "My accomplice left me a very good review. Apparently you are a Grade A cocksucker."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1117
translate chinese CeR1_order2_bd337c69:

    # Celia "Fucking pig."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1118
translate chinese CeR1_order2_86d76912:

    # MC "You should know the routine by now. Sit up straight and await your next command."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1120
translate chinese CeR1_order2_37026c56:

    # Celia "What’s it gonna be this time? Handjob in an alley?"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1121
translate chinese CeR1_order2_4a45e0b5:

    # Celia "This little game of yours won’t last forever, you know. Sooner or later, I’m going to find you - and then I’m going to rip your fucking balls off."
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1122
translate chinese CeR1_order2_3b0d5002:

    # MC "I WAS going to be nice to you, but if you’re insisting on being rude..."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1124
translate chinese CeR1_order2_03264fbf:

    # MC "Return to the glory hole. I’ll send another friend of mine your way."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1125
translate chinese CeR1_order2_e4fa50c1:

    # MC "This time you are to fuck him through the glory hole using your pussy."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1126
translate chinese CeR1_order2_002244bc:

    # Celia "I swear to God... when I find you, I’ll-"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1128
translate chinese CeR1_order2_a0e5a8c3:

    # MC "Oh, and don’t use a condom. My friend enjoys filling slutty bitches like you up."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1130
translate chinese CeR1_order2_41c4cac7:

    # Celia "Wh-What if it’s a dangerous time of the month?!"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1132
translate chinese CeR1_order2_d7a33657:

    # Celia "Wh-What if it’s a dangerous time of the month?! (Good that it’s actually isn’t.)"
    Celia ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1133
translate chinese CeR1_order2_e8e6af74:

    # MC "You should have been nicer to me, Celia. I might have let you use a condom if you were."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1135
translate chinese CeR1_order2_6e120882:

    # MC "My friend will see you tomorrow. As always, I expect good reviews."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1136
translate chinese CeR1_order2_14759a5c:

    # MC "Don’t disappoint my friend with a lacklustre performance."
    MC ""

# game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:1138
translate chinese CeR1_order2_1948f038:

    # Celia "(I’m planing to change our little game after that, [player_name].)"
    Celia ""

translate chinese strings:

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Open your mouth"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Take off your bra (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Take off your bra"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Take off your panties (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Take off your panties"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Get nude (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "{image=images/NS_B/New1.png}{color=#00ff00}Get nude{/color}{image=images/NS_B/New1.png}"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Get nude"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Did you get my present? (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Did you get my present?"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Orders (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "{image=images/NS_B/New1.png}{color=#00ff00}Orders{/color}{image=images/NS_B/New1.png}"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:145
    old "Orders"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:224
    old "Come closer"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:224
    old "Show me your tongue"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:224
    old "Dildo (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:224
    old "Dildo"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:224
    old "That’s all for today"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:334
    old "Put two fingers in your mouth"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:428
    old "Lick your nipple"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:428
    old "Put your tits on the chair"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:428
    old "Turn to the side"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:428
    old "Pinch your nipples"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:566
    old "Flash ass"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:566
    old "Spread ass"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:566
    old "Spread Pussy"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Play with dildo (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Play with dildo"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Sit on dildo (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Sit on dildo"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Sit on the keyboard"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Try new clothes (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Try new clothes"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Vibrator event (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "{image=images/NS_B/New1.png}{color=#00ff00}Vibrator event{/color}{image=images/NS_B/New1.png}"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:684
    old "Vibrator event"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:991
    old "{image=images/NS_B/New1.png}{color=#00ff00}Make Out with [player_name].{/color}{image=images/NS_B/New1.png}"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:991
    old "Blowjob or Anal with [player_name] (disabled)"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:991
    old "{image=images/NS_B/New1.png}{color=#00ff00}Blowjob or Anal with [player_name].{/color}{image=images/NS_B/New1.png}"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:991
    old "{image=images/NS_B/New1.png}{color=#00ff00}Blowjob using Gloryhole{/color}{image=images/NS_B/New1.png}"
    new ""

    # game/scripts/gui/computer/webcam_scenes/cela_webcam_scenes_menu.rpy:991
    old "{image=images/NS_B/New1.png}{color=#00ff00}Pussy using Glory Hole{/color}{image=images/NS_B/New1.png}"
    new ""

