﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:11
translate chinese CeR2_AS2_rep_a178f234:

    # MC "(Here we go again, once more unto the breach!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:13
translate chinese CeR2_AS2_rep_647d38bd:

    # MC "(I wonder if Celia will put up any resistance at first - fucking my cock is a bit more intimate than a blowjob, after all.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:15
translate chinese CeR2_AS2_rep_b2898835:

    # MC "(I wonder if Celia is as excited for this as I am! She seems to have enjoyed everything so far, she hasn’t asked for the roleplay to end yet.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:18
translate chinese CeR2_AS2_rep_ba6654ea:

    # MC "(Regardless, it’s going to feel amazing. I can’t wait to fuck her cunt!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:19
translate chinese CeR2_AS2_rep_a2f8a38a:

    # MC "(She should be here any minute now...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:22
translate chinese CeR2_AS2_rep_ccafdb57:

    # MC "(I better get myself ready for the show. Let’s strip these off.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:24
translate chinese CeR2_AS2_rep_a8084d9e:

    # "*Creeaak*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:25
translate chinese CeR2_AS2_rep_bc2c3f1e:

    # MC "(That’s the toilet door opening - perfect timing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:28
translate chinese CeR2_AS2_rep_764b87b5:

    # MC "(Okay, I’ll give her a minute to get ready. Then I’ll stick my cock through and we’ll see what happens!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:30
translate chinese CeR2_AS2_rep_91ea4cf9:

    # "*Thud*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:31
translate chinese CeR2_AS2_rep_3ba634ee:

    # MC "(Yup! That’s the door to her stall closed now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:35
translate chinese CeR2_AS2_rep_434ac0bc:

    # Celia "(Ugh, I can’t believe I have to do this again. I was SO sure I would have caught the bastard doing this to me by now.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:36
translate chinese CeR2_AS2_rep_394932ce:

    # Celia "(Fuck. I didn’t even remember to bring condoms with me...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:38
translate chinese CeR2_AS2_rep_22b7291a:

    # Celia "(I can’t believe I’m actually doing this again... I never realised I was such a slut!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:39
translate chinese CeR2_AS2_rep_45dda7f7:

    # Celia "(His cock is going to be raw inside me... No condom to protect me. Mmm... That's so hot.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:42
translate chinese CeR2_AS2_rep_b7e80568:

    # MC "(That should be long enough for her to get ready.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:44
translate chinese CeR2_AS2_rep_ca1626b0:

    # MC "(Time to stick my cock through the glory hole before she tries peeping through it to see who I really am.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:46
translate chinese CeR2_AS2_rep_513a7a09:

    # MC "(Alright, let's stick my cock through the glory hole and get this party started!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:49
translate chinese CeR2_AS2_rep_3dd1f209:

    # Celia "Disgusting..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:51
translate chinese CeR2_AS2_rep_fdf3f15c:

    # Celia "(Is this the same dick as last time?)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:52
translate chinese CeR2_AS2_rep_8c56d81a:

    # Celia "(I can’t remember if my blackmailer said it was the same friend or a different guy.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:54
translate chinese CeR2_AS2_rep_dde295ab:

    # Celia "(That’s going inside me today...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:55
translate chinese CeR2_AS2_rep_0f17cb38:

    # Celia "(There’s something so much hotter when the cock belongs to a completely anonymous man.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:58
translate chinese CeR2_AS2_rep_dbaa524c:

    # MC "(Now, let’s play the waiting game and see how long it takes for Celia to make a move and start riding my cock.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:59
translate chinese CeR2_AS2_rep_104cadc2:

    # Celia "*Sigh*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:60
translate chinese CeR2_AS2_rep_97439291:

    # Celia "(I better get undressed now.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:63
translate chinese CeR2_AS2_rep_90de7314:

    # Celia "(There isn’t even a fucking coat hanger in these stalls.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:65
translate chinese CeR2_AS2_rep_64ce63a9:

    # Celia "My dress will have to go on the floor - I'm sure as shit not leaving it on that filthy toilet."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:67
translate chinese CeR2_AS2_rep_736e01b2:

    # Celia "(My dress will have to go on the floor - I’m sure as shit not leaving it on that filthy toilet.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:70
translate chinese CeR2_AS2_rep_eacc014a:

    # Celia "(Okay... let’s get this over with.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:71
translate chinese CeR2_AS2_rep_c6930478:

    # MC "(I can feel her ass up against my dick, she must be about to start fucking me!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:74
translate chinese CeR2_AS2_rep_da526e5e:

    # Celia "(Alright, here we go...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:75
translate chinese CeR2_AS2_rep_b07c12ce:

    # Celia "(Take a deep breath, Celia. You can do this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:77
translate chinese CeR2_AS2_rep_6c1e7f06:

    # Celia "(Once you’ve finished this filthy ordeal you’ll be able to nail the bastard for good this time.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:79
translate chinese CeR2_AS2_rep_7f230029:

    # Celia "(I’ll have to try and be quiet. I can’t allow myself to scream or moan - no matter how horny I get!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:86
translate chinese CeR2_AS2_rep_f0f37f31:

    # Celia "(And then, he’ll pay. Oh yes, he’ll pay!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:88
translate chinese CeR2_AS2_rep_629edc86:

    # Celia "(You can do it. Just bite your tongue and ride him.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:89
translate chinese CeR2_AS2_rep_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:90
translate chinese CeR2_AS2_rep_921df271:

    # MC "(That’s it, she’s sliding onto my cock now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:93
translate chinese CeR2_AS2_rep_48266352:

    # Celia "Ahh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:95
translate chinese CeR2_AS2_rep_e86d52ab:

    # Celia "(Dammit, why does this have to feel so good?!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:96
translate chinese CeR2_AS2_rep_4b3ce99d:

    # MC "Ugh... Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:99
translate chinese CeR2_AS2_rep_1459a3a1:

    # MC "*Whispered* Fuck... You’re tight, Celia..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:100
translate chinese CeR2_AS2_rep_5625ccfe:

    # Celia "Ohh! Mmm..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:103
translate chinese CeR2_AS2_rep_a79ede7b:

    # Celia "*Pant*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:104
translate chinese CeR2_AS2_rep_fde1236b:

    # Celia "(I need to slow down, before I get carried away...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:106
translate chinese CeR2_AS2_rep_f4468ed4:

    # Celia "(This is so fucking degrading - screwing in a bathroom stall. Why am I getting so damn turned on by it?!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:109
translate chinese CeR2_AS2_rep_3c8c56e0:

    # Celia "Uhhh! Ohhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:110
translate chinese CeR2_AS2_rep_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:111
translate chinese CeR2_AS2_rep_bcc790e9:

    # MC "(Holy shit, this is even better than the blowjob she gave me in here!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:114
translate chinese CeR2_AS2_rep_5f495a36:

    # Celia "Ah!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:115
translate chinese CeR2_AS2_rep_e7f92310:

    # Celia "(Oh God, his cock feels better than my husband’s! He must be at least a full inch longer!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:116
translate chinese CeR2_AS2_rep_1c73c620:

    # Celia "(Shit. Why am I even THINKING about that?!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:119
translate chinese CeR2_AS2_rep_567eb999:

    # Celia "Ah! Ah... Wow..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:121
translate chinese CeR2_AS2_rep_ef034b6b:

    # Celia "(This feels so good, my legs are getting weak with pleasure!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:122
translate chinese CeR2_AS2_rep_574fdf99:

    # MC "Ugh! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:125
translate chinese CeR2_AS2_rep_fcae186d:

    # Celia "Fuck! Ahh..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:127
translate chinese CeR2_AS2_rep_fcf231cf:

    # Celia "(Dammit, I just realised why this feels so good. My husband ALWAYS wears condoms.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:129
translate chinese CeR2_AS2_rep_06d57331:

    # Celia "(It just feels so much more pleasurable when I’m doing it raw like this.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:131
translate chinese CeR2_AS2_rep_574fdf99_1:

    # MC "Ugh! Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:133
translate chinese CeR2_AS2_rep_5f495a36_1:

    # Celia "Ah!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:135
translate chinese CeR2_AS2_rep_1291f568:

    # MC "Ugh... Ohh... Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:137
translate chinese CeR2_AS2_rep_5625ccfe_1:

    # Celia "Ohh! Mmm..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:139
translate chinese CeR2_AS2_rep_cf8a65c8:

    # Celia "Ahhh! F-Fuck! *Pant*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:143
translate chinese CeR2_AS2_rep_c3564b7e:

    # Celia "*GASP* Ohhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:144
translate chinese CeR2_AS2_rep_165c9b60:

    # Celia "H-Holy shit! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:147
translate chinese CeR2_AS2_rep_12ce766d:

    # MC "(She’s started to thrust her hips back really quickly now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:148
translate chinese CeR2_AS2_rep_2c427902:

    # MC "(And it sounds like she’s actually getting into being fucked like this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:149
translate chinese CeR2_AS2_rep_924c61d1:

    # MC "(Damn, I wish I could see her face right now.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:152
translate chinese CeR2_AS2_rep_65aa3061:

    # Celia "AHH! AHHHH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:154
translate chinese CeR2_AS2_rep_c2fb704e:

    # MC "(Christ, she’s loud! Hopefully nobody outside the toilets hears her, or we could both get caught!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:157
translate chinese CeR2_AS2_rep_e34540de:

    # Celia "Ugh! Harder! Yes! Ahh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:158
translate chinese CeR2_AS2_rep_e22f2b42:

    # Celia "*Whispered* F-Fuck... It’s so good..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:161
translate chinese CeR2_AS2_rep_2b153a4d:

    # Celia "(His fat cock is turning me on so much. I love the feeling of it filling up my pussy each, time it plunges inside me.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:162
translate chinese CeR2_AS2_rep_16f5bc31:

    # Celia "(God... I’m so fucking wet right now. I need him to start hitting my g-spot.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:165
translate chinese CeR2_AS2_rep_f6c15487:

    # Celia "Ugh... "
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:167
translate chinese CeR2_AS2_rep_43daa77a:

    # Celia "(Got it. This ought to do the trick!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:169
translate chinese CeR2_AS2_rep_e6caec06:

    # MC "AHH! AHHHH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:171
translate chinese CeR2_AS2_rep_b0785c2f:

    # Celia "Ohhhh yeeaaah..... Mmm..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:173
translate chinese CeR2_AS2_rep_87c09660:

    # Celia "(That’s the spot right there!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:174
translate chinese CeR2_AS2_rep_4cda5c62:

    # Celia "(I can feel the tip of his cock pushing up against the top of my cunt with each thrust now.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:177
translate chinese CeR2_AS2_rep_11956399:

    # MC "Ugh! Hnnnggg! Aahhhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:178
translate chinese CeR2_AS2_rep_14c7a848:

    # Celia "OHH! YES! MMMM! AHAHHHH!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:181
translate chinese CeR2_AS2_rep_6d08a1fe:

    # MC "(Her pussy is clamping down around my cock! She must be cumming!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:182
translate chinese CeR2_AS2_rep_25523b5e:

    # Celia "AYAAAHHHH! AHHHHH! GOD YES!!!!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:185
translate chinese CeR2_AS2_rep_c0a18508:

    # MC "Mmm! Ugh! Fuck... Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:186
translate chinese CeR2_AS2_rep_7cf95140:

    # Celia "*Pant* Ohhh! *Pant*"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:187
translate chinese CeR2_AS2_rep_fd71fc94:

    # Celia "(This is heavenly!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:190
translate chinese CeR2_AS2_rep_50cb1ba2:

    # Celia "(I haven’t cum that hard in at least three years!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:191
translate chinese CeR2_AS2_rep_2f984b7c:

    # Celia "*Gasp* Ohhh!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:192
translate chinese CeR2_AS2_rep_3130fd53:

    # MC "(When I told her to do this, I never imagined she’d get so excited by it. I was kinda hoping she’d hate it.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:195
translate chinese CeR2_AS2_rep_09e2e85a:

    # MC "Mmm! Ahh... fuck..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:196
translate chinese CeR2_AS2_rep_6dd5194b:

    # Celia "Ahhh! Yeeessssss! Mmm!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:197
translate chinese CeR2_AS2_rep_1ef08026:

    # Celia "(God, I’m so close to cumming again!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:200
translate chinese CeR2_AS2_rep_080e7d6b:

    # MC "HNNNNGGG! UGH!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:202
translate chinese CeR2_AS2_rep_ae462d7c:

    # MC "(Fuck! I can’t hold myself back any longer! I’m cumming!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:204
translate chinese CeR2_AS2_rep_fe10e82b:

    # Celia "Huh?"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:207
translate chinese CeR2_AS2_rep_cfb00b1f:

    # MC "Ugh! Hnnngg!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:208
translate chinese CeR2_AS2_rep_b987e77d:

    # MC "Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:212
translate chinese CeR2_AS2_rep_62081586:

    # Celia "No! Not inside me!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:214
translate chinese CeR2_AS2_rep_bef65c7d:

    # Celia "Oh my God! Inside me!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:224
translate chinese CeR2_AS2_rep_832638bc:

    # Celia "(Fuck! I just felt something really hot inside me! The little bastard must have blew his load in me!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:226
translate chinese CeR2_AS2_rep_49a3a91f:

    # Celia "(Fuck! I felt something really hot inside me! He must have emptied his balls in my pussy! Mmmm! God, that’s so fucking sexy.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:229
translate chinese CeR2_AS2_rep_99201933:

    # Celia "Fuck! Did you not think to give a girl a warning?!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:230
translate chinese CeR2_AS2_rep_0fa779d6:

    # MC "(That was amazing...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:232
translate chinese CeR2_AS2_rep_db5b95c2:

    # MC "(She really sounds pissed that I came inside her though.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:234
translate chinese CeR2_AS2_rep_19261fc9:

    # MC "(I think she’s pretending to be pissed off that I came inside her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:237
translate chinese CeR2_AS2_rep_24893435:

    # Celia "Ugh, this is going to take me forever to properly clean out!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:238
translate chinese CeR2_AS2_rep_ee389422:

    # Celia "You better hope I don't get pregnant!"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:242
translate chinese CeR2_AS2_rep_f6f4900d:

    # Celia "(Black trainers. I’ll try and remember this brand.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:243
translate chinese CeR2_AS2_rep_5dd4e0c1:

    # Celia "(I don’t care if I miss my next three classes. I’ll search this entire goddamn college for ANY dickhead wearing these fucking things.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:245
translate chinese CeR2_AS2_rep_77eb44aa:

    # Celia "(That was intense... I don’t think I’ll be able to walk straight for the rest of the day!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:246
translate chinese CeR2_AS2_rep_f6402bb6:

    # Celia "(I’ve NEVER been fucked that hard in my entire life!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:247
translate chinese CeR2_AS2_rep_6e303dd0:

    # MC "*Pant* (I’ll hang around here for half an hour until I’m sure she’s gone.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:253
translate chinese CeR2_AS2_rep_d34af7a6:

    # MC "(Okay, that’s about thirty minutes. She’ll have definitely left now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:255
translate chinese CeR2_AS2_rep_1e96354d:

    # MC "(Time to slip back into a classroom and act as if nothing happened.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:257
translate chinese CeR2_AS2_rep_0ec9a592:

    # MC "(Time to slip back to class before my professor marks me absent!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:260
translate chinese CeR2_AS2_rep_b0ee3731:

    # Celia "Come on... Come on..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:261
translate chinese CeR2_AS2_rep_667db3e5:

    # Celia "(There isn’t a second exit to that toilet. There’s only one way out.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:262
translate chinese CeR2_AS2_rep_8fddfe44:

    # Celia "(And sooner or later you are going to get hungry. You can’t stay in there forever!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:266
translate chinese CeR2_AS2_rep_bcd56577:

    # Celia "(WHAT?!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:267
translate chinese CeR2_AS2_rep_d3b762a1:

    # Celia "(Black trainers... It can’t be...)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:270
translate chinese CeR2_AS2_rep_e6a5638a:

    # Celia "Fuck. Fuck. Shit. Cunt."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:271
translate chinese CeR2_AS2_rep_70014f51:

    # Celia "(It all makes sense... This is after I rejected him asking me out.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:272
translate chinese CeR2_AS2_rep_012871ab:

    # Celia "(Fucking disgusting little creep.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:274
translate chinese CeR2_AS2_rep_12cbf89e:

    # Celia "(And there we go. I’ve “caught” him. So now I can advance to stage two of our little roleplay scenario - with ME as the dominant one this time!)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:275
translate chinese CeR2_AS2_rep_e94222e1:

    # Celia "Mwahahaha..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:278
translate chinese CeR2_AS2_rep_02729a7e:

    # Celia "Oh, the things I’m going to make you do to me... Mmm..."
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:279
translate chinese CeR2_AS2_rep_f6a314d8:

    # Celia "(You’re going to be my personal little fucktoy - just like you made me yours.)"
    Celia ""

# game/scripts/gui/computer/scenes_gallery/scenes/Ce/R2/CeR2_AS2_rep.rpy:280
translate chinese CeR2_AS2_rep_57e9edc9:

    # Celia "(I’m soaking right now. I wonder if I have time to slip into the bathroom and finger myself before my next class...)"
    Celia ""

