﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:17
translate chinese CR3_week2_rep_b66738c1:

    # "*Tweet Tweet*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:19
translate chinese CR3_week2_rep_a1f51002:

    # MC "Ugh... Bloody birds..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:20
translate chinese CR3_week2_rep_300cfddf:

    # MC "*YAWN* It’s about time I get up, anyway."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:25
translate chinese CR3_week2_rep_6b89b9dd:

    # MC "(God... the Sun is so bright today!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:26
translate chinese CR3_week2_rep_fe75b313:

    # MC "(I can only imagine how rough Caroline is feeling right now after drinking so much last night!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:27
translate chinese CR3_week2_rep_d63be206:

    # MC "(Her head must be killing her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:31
translate chinese CR3_week2_rep_b82d3956:

    # MC "(I can’t wait to see her today. We can finally talk about what happened, and maybe get the deal back on.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:32
translate chinese CR3_week2_rep_baae8e39:

    # MC "(Or even better - get a proper relationship going!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:36
translate chinese CR3_week2_rep_d69fcc96:

    # MC "(Having Caroline as a girlfriend, would be amazing - and now that she’s told me exactly how she feels, there’s no barriers to it, right?)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:37
translate chinese CR3_week2_rep_b77e79d0:

    # MC "(I mean, I can just walk up, and kiss her, whenever I want!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:39
translate chinese CR3_week2_rep_d9018f3c:

    # "*KNOCK KNOCK*"
    ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:41
translate chinese CR3_week2_rep_fc8391c1:

    # MC "Come in!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:45
translate chinese CR3_week2_rep_616913b1:

    # Caroline "Hey - it’s just me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:46
translate chinese CR3_week2_rep_4f388c78:

    # MC "Morning, Caroline. Are you not hungover?!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:47
translate chinese CR3_week2_rep_e215935d:

    # Caroline "I was pretty bad, for a few minutes. But I learnt a trick or two in college, to make it pass."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:51
translate chinese CR3_week2_rep_83259496:

    # Caroline "Now, I’ve just got a little bit of a headache but it’ll pass."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:52
translate chinese CR3_week2_rep_5896c14e:

    # MC "What’s the trick?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:53
translate chinese CR3_week2_rep_ccfb64b3:

    # Caroline "You take two very small glasses of whisky, and down them quickly. Then you hop in a hot shower - It refreshes you and wakes you up."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:57
translate chinese CR3_week2_rep_9dbf2321:

    # Caroline "Anyway, thanks for coming out with me, last night. I’m not gonna lie - I don’t really remember everything that happened. Most of it, is just a blur."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:58
translate chinese CR3_week2_rep_a56dff8b:

    # Caroline "I mean, I recall Charles being a dickhead, and trying to ruin our night. And I know you got punched, saving me - but the rest is... all foggy."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:59
translate chinese CR3_week2_rep_f017d095:

    # MC "Yeah, it was a wild night..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:63
translate chinese CR3_week2_rep_776af718:

    # Caroline "Um... while we’re on the subject. I didn’t say anything... personal or secret, did I?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:64
translate chinese CR3_week2_rep_4a075af6:

    # MC "What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:65
translate chinese CR3_week2_rep_6a34f979:

    # Caroline "I mean, something that sounded like, I probably shouldn’t have said?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:69
translate chinese CR3_week2_rep_ee9921ca:

    # MC "Well, you told me that you love me. Does that count?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:73
translate chinese CR3_week2_rep_cf67231a:

    # Caroline "I what?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:74
translate chinese CR3_week2_rep_a09e9904:

    # Caroline "(FUCK! I knew that drinking with him, was going to be a bad idea! Why did I decide to do it?!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:75
translate chinese CR3_week2_rep_56c78407:

    # Caroline "D-Did I actually say that?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:76
translate chinese CR3_week2_rep_7f9b5e24:

    # MC "Multiple times..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:80
translate chinese CR3_week2_rep_abf6aabc:

    # Caroline "Haha! It was... a... a joke! I make silly jokes when I’m drunk!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:81
translate chinese CR3_week2_rep_118d2ac0:

    # MC "It didn’t... sound like a joke."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:82
translate chinese CR3_week2_rep_e7845b00:

    # Caroline "It was a joke! End of story. Let’s not talk about this again..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:83
translate chinese CR3_week2_rep_cca71f48:

    # MC "(Wow, she’s engaging in more censorship than one big country in Asia, right now! She’s just trying to backtrack, and redefine what happened!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:89
translate chinese CR3_week2_rep_1d05c90e:

    # MC "Nope! Nothing unusual! Just drunken nonsense."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:93
translate chinese CR3_week2_rep_7d4ccbef:

    # Caroline "Oh, thank God."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:94
translate chinese CR3_week2_rep_ffc0c727:

    # Caroline "(Fuck... that could have gone terribly. If I had told him the real reason why I ended the deal, I would be in so much shit right now!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:95
translate chinese CR3_week2_rep_7e165438:

    # MC "Are you okay, Caroline?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:99
translate chinese CR3_week2_rep_75011a19:

    # Caroline "Y-Yeah - all’s good!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:101
translate chinese CR3_week2_rep_8db30648:

    # Caroline "(Okay. In future, I REALLY need to take more care, about how much I drink, when I’m around my brother.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:103
translate chinese CR3_week2_rep_c164ced4:

    # Caroline "(Okay, in future I REALLY need to take more care about how much I drink when I’m around him.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:109
translate chinese CR3_WE_label_mor_con1_rep_e2e84cdc:

    # MC "(I should ask her about Charles, as well - so I know what’s going on there.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:110
translate chinese CR3_WE_label_mor_con1_rep_e5399d22:

    # MC "How are you feeling, by the way?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:111
translate chinese CR3_WE_label_mor_con1_rep_0997d057:

    # Caroline "I told you - I’m fine! Hangovers haven’t ever bothered me."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:115
translate chinese CR3_WE_label_mor_con1_rep_5c321d26:

    # MC "I meant, with Charles."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:116
translate chinese CR3_WE_label_mor_con1_rep_7ff66546:

    # Caroline "The police have taken him into custody. He’s out of the picture now - Hopefully, for a long time."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:117
translate chinese CR3_WE_label_mor_con1_rep_c4fd54ce:

    # MC "Thank God. He was a real dickhead."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:121
translate chinese CR3_WE_label_mor_con1_rep_7add0a5e:

    # Caroline "Anyway, I better get dressed. I’ll talk to you later."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:122
translate chinese CR3_WE_label_mor_con1_rep_07a58874:

    # MC "W-Wait! We need to talk about something."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:126
translate chinese CR3_WE_label_mor_con1_rep_41134dab:

    # MC "I... I know you don’t want to hear this... but I want to talk with you about the deal we made."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:127
translate chinese CR3_WE_label_mor_con1_rep_37711565:

    # Caroline "(Dammit... he’s still going on about that. Did I do something last night, to rekindle his hope that it might come back?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:131
translate chinese CR3_WE_label_mor_con1_rep_a785c918:

    # Caroline "What is it, [player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:133
translate chinese CR3_WE_label_mor_con1_rep_2c9ee260:

    # MC "This deal... It isn’t just me that enjoys it. I know you do too."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:134
translate chinese CR3_WE_label_mor_con1_rep_c32bf2b7:

    # Caroline "[player_name]..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:138
translate chinese CR3_WE_label_mor_con1_rep_d3d309f1:

    # MC "Caroline! This isn’t just some silly crush I have on you. We make each other happy, when this deal is on. You KNOW it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:139
translate chinese CR3_WE_label_mor_con1_rep_a6faff16:

    # Caroline "[player_name], I-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:143
translate chinese CR3_WE_label_mor_con1_rep_c222ab59:

    # MC "Just... Just hear me out, okay?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:144
translate chinese CR3_WE_label_mor_con1_rep_db17d745:

    # MC "I want to propose, that we make a new deal this time. We can alter it, so that it’s something that you’re comfortable with."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:145
translate chinese CR3_WE_label_mor_con1_rep_b2498540:

    # MC "But I can’t go on, living like this - being so close to you, but never being able to experience what we had, ever again. It’s killing me!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:149
translate chinese CR3_WE_label_mor_con1_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:151
translate chinese CR3_WE_label_mor_con1_rep_029e34e2:

    # Caroline "(Holy shit! I knew he was attracted to me, but I didn’t realise it was THIS strongly!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:155
translate chinese CR3_WE_label_mor_con1_rep_a1efb3f2:

    # MC "(God... I wish I’d kissed her, last night, after she told me that she loved me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:156
translate chinese CR3_WE_label_mor_con1_rep_e066cff9:

    # MC "(It would have been, such a perfect end to the evening.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:157
translate chinese CR3_WE_label_mor_con1_rep_e080d9ce:

    # MC "(Maybe she would have remembered, if I did it then...)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:161
translate chinese CR3_WE_label_mor_con1_rep_1ae8d314:

    # Caroline "Y-You can’t just... do that... without warning..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:162
translate chinese CR3_WE_label_mor_con1_rep_f0e8ac20:

    # MC "How do you think I feel?! You did the EXACT same thing to me, when it came to our deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:163
translate chinese CR3_WE_label_mor_con1_rep_17a42e80:

    # MC "You ended it, without warning or explanation. If I’d done something wrong, then I deserved to know why."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:167
translate chinese CR3_WE_label_mor_con1_rep_689d6d87:

    # MC "I’ve been beating myself up inside, thinking about all the things I might have done, that hurt you enough to cause you to back away from the deal."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:168
translate chinese CR3_WE_label_mor_con1_rep_4ad31af7:

    # MC "But I know that it wasn’t the case - I never hurt you. You were scared of how close we were becoming, isn’t that right?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:169
translate chinese CR3_WE_label_mor_con1_rep_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:170
translate chinese CR3_WE_label_mor_con1_rep_0b3c7761:

    # Caroline "Fine... It’s true. I got a little bit scared- That’s a lie. I got VERY scared of what we were becoming."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:171
translate chinese CR3_WE_label_mor_con1_rep_230b4a06:

    # MC "Why couldn’t you just talk to me about it? We could sort this out between ourselves and figure it out?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:172
translate chinese CR3_WE_label_mor_con1_rep_734b8fa0:

    # MC "C’mon - let’s make a new deal today. The same as before - but you use your mouth, as well? How does that sound?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:176
translate chinese CR3_WE_label_mor_con1_rep_4f60e30d:

    # Caroline "You’re not getting blowjobs... but I might be willing to kiss you."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:177
translate chinese CR3_WE_label_mor_con1_rep_feecc69e:

    # MC "Deal! Now and how about we also add a clause - that you have to be nude - as well? It’s not fun, that only you get to look at me naked!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:178
translate chinese CR3_WE_label_mor_con1_rep_4a2a95d6:

    # Caroline "Ugh... fine. Deal!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:182
translate chinese CR3_WE_label_mor_con1_rep_ca9cb782:

    # MC "Now! How about we put this new deal of ours to the test?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:183
translate chinese CR3_WE_label_mor_con1_rep_17b720bd:

    # Caroline "What are you thinking..?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:184
translate chinese CR3_WE_label_mor_con1_rep_b0a58a6c:

    # MC "Let’s begin by, getting you out of that bathrobe."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:188
translate chinese CR3_WE_label_mor_con1_rep_c1595d70:

    # Caroline "Err... That’s not such a good idea."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:189
translate chinese CR3_WE_label_mor_con1_rep_45013756:

    # MC "Why not?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:190
translate chinese CR3_WE_label_mor_con1_rep_65f08c26:

    # Caroline "I’m not exactly clad in anything underneath it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:194
translate chinese CR3_WE_label_mor_con1_rep_b69f776a:

    # MC "You’ve seen me naked LOADS of times. It seems fair to me, that I should get to see you in the nude today."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:195
translate chinese CR3_WE_label_mor_con1_rep_cdab1eae:

    # Caroline "Gah, you’re persistent. You know that?!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:200
translate chinese CR3_WE_label_mor_con1_rep_dc3a39ac:

    # MC "C’mon, Caroline - off with the towel!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:201
translate chinese CR3_WE_label_mor_con1_rep_e27865ca:

    # Caroline "Fine. Just give me a second, to unwrap it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:205
translate chinese CR3_WE_label_mor_con1_rep_01505071:

    # Caroline "Hang on - you’re still wearing your underwear! Our deal states that both of us have to be naked!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:206
translate chinese CR3_WE_label_mor_con1_rep_3985ceeb:

    # Caroline "C’mon - get them off too!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:210
translate chinese CR3_WE_label_mor_con1_rep_526f2ffc:

    # MC "*Sigh* You got me there."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:211
translate chinese CR3_WE_label_mor_con1_rep_a0a0505f:

    # MC "Fine, I’ll take them off - but you better not welch out of taking that towel off!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:215
translate chinese CR3_WE_label_mor_con1_rep_5097f161:

    # Caroline "*Gulp* Well, here you go."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:216
translate chinese CR3_WE_label_mor_con1_rep_5c95b76a:

    # MC "(Oh yeah! She’s completely naked! This is awesome!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:217
translate chinese CR3_WE_label_mor_con1_rep_533d22d3:

    # MC "(I wonder how far I’ll be able to take things, today.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:221
translate chinese CR3_WE_label_mor_con1_rep_cc4aa9f5:

    # MC "(She’s got a smoking hot body... Hopefully I’ll get to play with it, in a few minutes!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:222
translate chinese CR3_WE_label_mor_con1_rep_b38046de:

    # Caroline "Well? Are you done leering at me?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:223
translate chinese CR3_WE_label_mor_con1_rep_c8f593b0:

    # MC "Just a few more seconds..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:224
translate chinese CR3_WE_label_mor_con1_rep_53eb20e5:

    # MC "Can I grab your tits?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:225
translate chinese CR3_WE_label_mor_con1_rep_5d8aa705:

    # Caroline "Yeah, I guess so. Go ahead."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:229
translate chinese CR3_WE_label_mor_con1_rep_084a83e1:

    # MC "Sweet!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:230
translate chinese CR3_WE_label_mor_con1_rep_265da619:

    # MC "(This is awesome! Her tits are so firm!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:231
translate chinese CR3_WE_label_mor_con1_rep_df0bd9d5:

    # Caroline "Ah..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:235
translate chinese CR3_WE_label_mor_con1_rep_9b189c58:

    # MC "(Heh. It sounds like she’s enjoying, me squeezing them, too!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:236
translate chinese CR3_WE_label_mor_con1_rep_96dbf492:

    # MC "(God, these are fucking incredible!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:237
translate chinese CR3_WE_label_mor_con1_rep_021b0d61:

    # Caroline "Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:241
translate chinese CR3_WE_label_mor_con1_rep_7e09c747:

    # MC "(Hmm? I wonder if I can convince her to let me, play with her pussy, too.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:242
translate chinese CR3_WE_label_mor_con1_rep_a062a12b:

    # MC "This is great - I really love playing with your tits, but do you think I could try something different?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:243
translate chinese CR3_WE_label_mor_con1_rep_a1c29f25:

    # Caroline "Something different? You mean like sucking on them, or something?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:247
translate chinese CR3_WE_label_mor_con1_rep_ef16d5cc:

    # MC "(It’s not part of our deal - but here goes nothing!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:248
translate chinese CR3_WE_label_mor_con1_rep_f5b5b3b5:

    # MC "I was thinking that, maybe I could pleasure you with my fingers, for a bit."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:252
translate chinese CR3_WE_label_mor_con1_rep_78053e5e:

    # Caroline "Ah! No no no!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:253
translate chinese CR3_WE_label_mor_con1_rep_437c4889:

    # MC "Aww, c’mon! You’ll really enjoy it! I promise!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:254
translate chinese CR3_WE_label_mor_con1_rep_0b152b90:

    # Caroline "Haha! No way! Nice try, though!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:259
translate chinese CR3_WE_label_mor_con1_rep_73f45a09:

    # MC "Aww... I’m just so horny - and I really wanted to feel, what your pussy was like."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:260
translate chinese CR3_WE_label_mor_con1_rep_ee8b4859:

    # Caroline "Hmm... Okay, I can let you feel it - but I have to be in control, at all times. Okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:261
translate chinese CR3_WE_label_mor_con1_rep_4ff7d0bd:

    # MC "Sure! What do you want me to do?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:262
translate chinese CR3_WE_label_mor_con1_rep_3e23b669:

    # Caroline "Lie down on your bed. I’ll climb on top of you, and we’ll take things from there."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:266
translate chinese CR3_WE_label_mor_con1_rep_e3e54439:

    # MC "(Sweet! This is going better than I expected!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:267
translate chinese CR3_WE_label_mor_con1_rep_3869caa1:

    # MC "(To be honest, it’s even better than getting to finger her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:268
translate chinese CR3_WE_label_mor_con1_rep_b0f45890:

    # Caroline "You’ve got quite the smile on your face!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:269
translate chinese CR3_WE_label_mor_con1_rep_9ba00a8f:

    # MC "How could I not? I’ve got the world’s most gorgeous woman lying on top of me."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:273
translate chinese CR3_WE_label_mor_con1_rep_343cc01c:

    # Caroline "Haha! You and your silver tongue!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:274
translate chinese CR3_WE_label_mor_con1_rep_97a6c9e2:

    # MC "I’m being serious - you’ve just woken up, you’ve got a hangover, and you’re still - a solid ten."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:275
translate chinese CR3_WE_label_mor_con1_rep_854f081f:

    # Caroline "Aww... C’mere!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:279
translate chinese CR3_WE_label_mor_con1_rep_609432c2:

    # Caroline "Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:280
translate chinese CR3_WE_label_mor_con1_rep_c9ef9ed5:

    # MC "(I can feel her breasts pressing down, into my chest, as she’s making out with me.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:281
translate chinese CR3_WE_label_mor_con1_rep_f6bbe4c7:

    # MC "(And my cock’s rubbing up against her belly as she moves!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:285
translate chinese CR3_WE_label_mor_con1_rep_d768e39f:

    # Caroline "(I’m so fucking horny right now... I know I didn’t let him finger me - but I think he’ll enjoy me, rubbing my vulva back and forth across his shaft.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:286
translate chinese CR3_WE_label_mor_con1_rep_4aaf2bfc:

    # MC "(Fuck... It can’t get any better than this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:287
translate chinese CR3_WE_label_mor_con1_rep_17a104a2:

    # Caroline "Mmm... I bet you’re thinking, that it doesn’t get any better than this."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:291
translate chinese CR3_WE_label_mor_con1_rep_a9cd1df9:

    # Caroline "How does that feel?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:292
translate chinese CR3_WE_label_mor_con1_rep_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:293
translate chinese CR3_WE_label_mor_con1_rep_63023fd6:

    # Caroline "I’m gonna slide my hips, back and forth, but you have to promise me, you’re not gonna try and put it inside, okay?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:297
translate chinese CR3_WE_label_mor_con1_rep_e32cadd2:

    # MC "Y-Yeah, okay..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:298
translate chinese CR3_WE_label_mor_con1_rep_37ec816a:

    # Caroline "I’m serious. If your cock goes inside me and I don’t care if it happens accidentally then I am OUT of here. Understand?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:299
translate chinese CR3_WE_label_mor_con1_rep_63ee96b4:

    # MC "Yes, I understand! No fucking! I got it."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:303
translate chinese CR3_WE_label_mor_con1_rep_4751f3b3:

    # Caroline "Okay, here we go..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:304
translate chinese CR3_WE_label_mor_con1_rep_f4864c18:

    # MC "Mmm... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:305
translate chinese CR3_WE_label_mor_con1_rep_3cf00287:

    # MC "(I can feel her hot wetness sliding along my cock. It feels so good!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:309
translate chinese CR3_WE_label_mor_con1_rep_dceb847c:

    # Caroline "Ah... God..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:310
translate chinese CR3_WE_label_mor_con1_rep_0c4635ad:

    # Caroline "(This is perfect... I can have his dick, rub my clitoris, while I ride him!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:314
translate chinese CR3_WE_label_mor_con1_rep_0a9b1258:

    # Caroline "Are you enjoying this?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:315
translate chinese CR3_WE_label_mor_con1_rep_01253201:

    # MC "Oh yeah... I wasn’t aware this was part of our deal though?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:316
translate chinese CR3_WE_label_mor_con1_rep_4d39a9c1:

    # Caroline "Consider it a part of the new contract signing bonus. It won’t be happening again - so you better enjoy it!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:320
translate chinese CR3_WE_label_mor_con1_rep_6187e2c0:

    # MC "Y-Yeah, I’ll make sure to enjoy, every single second."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:321
translate chinese CR3_WE_label_mor_con1_rep_59a3c231:

    # MC "Ah... Fuck... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:322
translate chinese CR3_WE_label_mor_con1_rep_84e09ab8:

    # Caroline "Ah!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:323
translate chinese CR3_WE_label_mor_con1_rep_d02b9bf1:

    # MC "It sounds like you’re making the most of it too, though."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:327
translate chinese CR3_WE_label_mor_con1_rep_beb0a23d:

    # Caroline "A-Am not!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:328
translate chinese CR3_WE_label_mor_con1_rep_e708f36e:

    # MC "Haha! I HEARD you moaning! You can’t deny that!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:329
translate chinese CR3_WE_label_mor_con1_rep_aabca656:

    # Caroline "...Gah! Fine, you got me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:333
translate chinese CR3_WE_label_mor_con1_rep_56981b1a:

    # MC "I knew it! Heh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:334
translate chinese CR3_WE_label_mor_con1_rep_19533c0d:

    # Caroline "Mmm... It’s not like I have any say in the matter. When my pussy rubs up against something warm and hard I can’t help but, moan a little."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:338
translate chinese CR3_WE_label_mor_con1_rep_39b8eb10:

    # Caroline "Speaking of which, I can feel your cock throbbing. Ah... Oh..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:339
translate chinese CR3_WE_label_mor_con1_rep_f901e457:

    # Caroline "Are you about to cum soon, [player_name]?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:340
translate chinese CR3_WE_label_mor_con1_rep_019dcb39:

    # MC "I’m getting there... Oh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:344
translate chinese CR3_WE_label_mor_con1_rep_aa141777:

    # Caroline "Ah! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:345
translate chinese CR3_WE_label_mor_con1_rep_5c045f3b:

    # Caroline "(Christ, this feels so fucking good! His dick is, right at the entrance to my cunt. One little slip of my hips and I could have him inside me.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:346
translate chinese CR3_WE_label_mor_con1_rep_bab30521:

    # Caroline "(I could actually be riding him...)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:350
translate chinese CR3_WE_label_mor_con1_rep_9da6fb69:

    # Caroline "(Mmm... I could finally feel [player_name]’s thick cock buried, deep inside my pussy.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:352
translate chinese CR3_WE_label_mor_con1_rep_977b11a3:

    # MC "Ah... (What’s Caroline doing? If she’s not careful, my dick could slip inside her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:356
translate chinese CR3_WE_label_mor_con1_rep_1d7b18b1:

    # MC "C-Caroline! Careful! It’s almost slipping inside!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:357
translate chinese CR3_WE_label_mor_con1_rep_364ad65e:

    # Caroline "Ohh... Mmm..."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:358
translate chinese CR3_WE_label_mor_con1_rep_d2782490:

    # Caroline "(Just another half inch and his glans will be inside me.)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:362
translate chinese CR3_WE_label_mor_con1_rep_5347d363:

    # Caroline "(If I just take the tip in, it couldn’t hurt, right?)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:363
translate chinese CR3_WE_label_mor_con1_rep_a760b62d:

    # MC "Caroline! I’m gonna cum!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:364
translate chinese CR3_WE_label_mor_con1_rep_3e245554:

    # Caroline "(Fuck! It’s far too dangerous... What was I thinking? If I let the tip inside me, there’s no way I’d be able to resist, him pushing the whole thing in!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:368
translate chinese CR3_WE_label_mor_con1_rep_1c8c6ab0:

    # MC "Ahh... Oh God... Yes!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:369
translate chinese CR3_WE_label_mor_con1_rep_f7a40ecb:

    # Caroline "That’s it, [player_name]. Cum for me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:370
translate chinese CR3_WE_label_mor_con1_rep_2d76c68d:

    # Caroline "Ah! Ah! Oh! Ahhh!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:374
translate chinese CR3_WE_label_mor_con1_rep_5ead11f2:

    # MC "Hnnnng! Gahhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:375
translate chinese CR3_WE_label_mor_con1_rep_5c9b8fc8:

    # Caroline "Ohhhhh, yes! Mmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:386
translate chinese CR3_WE_label_mor_con1_rep_aa608936:

    # MC "Ohh... Fuck me..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:387
translate chinese CR3_WE_label_mor_con1_rep_ddf5fa3d:

    # Caroline "Oh wow... That’s A LOT of cum! Somebody must have been REALLY horny!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:388
translate chinese CR3_WE_label_mor_con1_rep_01ea9d0c:

    # MC "Hell yeah, I was... *Pant*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:392
translate chinese CR3_WE_label_mor_con1_rep_3655c25c:

    # Caroline "Well, I’ll leave you, to catch your breath and rest up. I need to go and get dressed."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:393
translate chinese CR3_WE_label_mor_con1_rep_0a977cc4:

    # MC "Are you leaving already?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:394
translate chinese CR3_WE_label_mor_con1_rep_1476438a:

    # Caroline "Yeah. I’ve got a lot to do today. Sorry!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:398
translate chinese CR3_WE_label_mor_con1_rep_6331eb26:

    # Caroline "Aww, don’t look so downhearted. We’ve got this new deal now, remember?"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:399
translate chinese CR3_WE_label_mor_con1_rep_73a45f25:

    # MC "Yeah, you’re right. I was just hoping to cuddle you, for a while."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:400
translate chinese CR3_WE_label_mor_con1_rep_09884573:

    # Caroline "Haha! There’s NO way I’m cuddling you, when you’re covered in cum!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:401
translate chinese CR3_WE_label_mor_con1_rep_ddf77226:

    # Caroline "I’ll go, and try to finish most of my business crap today. Give me a shout, later on."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:402
translate chinese CR3_WE_label_mor_con1_rep_d285cfb3:

    # MC "Okay, Caroline. See you then!"
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:67
    old "Well, you told me you loved me. Does that count?"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/CR3_week2_rep.rpy:67
    old "Nope. Nothing unusual!"
    new ""

