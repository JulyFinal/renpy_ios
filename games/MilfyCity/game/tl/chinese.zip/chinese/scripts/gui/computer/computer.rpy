﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/computer.rpy:50
translate chinese computer_menu_cc018785:

    # MC "I'm too tired."
    MC ""

# game/scripts/gui/computer/computer.rpy:84
translate chinese computer_menu_9d8913ab:

    # MC "Okay. That’s enough."
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/computer.rpy:20
    old "Use Computer"
    new ""

    # game/scripts/gui/computer/computer.rpy:20
    old "Play Computer Games (skip time)"
    new ""

