﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:9
translate chinese MLR2_NS2_rep_1635f365:

    # MC "*Gulp...*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:11
translate chinese MLR2_NS2_rep_d8c2bb68:

    # MC "(Well, there’s Dad. I wonder where Mom is, though.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:13
translate chinese MLR2_NS2_rep_f0302f28:

    # MC "(Well, there’s Bob. I wonder where Linda is, though.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:14
translate chinese MLR2_NS2_rep_669b06ec:

    # MC "(Jesus, my heart’s racing right now. If he wakes up and catches me - I’m sooo dead.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:21
translate chinese MLR2_NS2_rep_a273bc10:

    # Mom "Hello, Sweetie!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:22
translate chinese MLR2_NS2_rep_7f4d8697:

    # MC "Ah-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:23
translate chinese MLR2_NS2_rep_2689a93f:

    # Mom "Shush! Quiet! "
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:27
translate chinese MLR2_NS2_rep_f9c2077a:

    # Mom "You have to be quiet, or we’ll wake up my husband."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:28
translate chinese MLR2_NS2_rep_a264fef9:

    # MC "O-Okay. You scared the shit out of me there, though!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:29
translate chinese MLR2_NS2_rep_94c21d29:

    # MC "Could you not have just lied on the bed, waiting for me? "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:33
translate chinese MLR2_NS2_rep_bc13d24c:

    # Mom "I didn’t want to risk, falling asleep and missing your visit."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:35
translate chinese MLR2_NS2_rep_f4b5b47f:

    # Mom "Besides, If I got into bed, your father would have wanted to have sex with me again."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:37
translate chinese MLR2_NS2_rep_8699478f:

    # Mom "Besides, if I got into bed my husband would have wanted to have sex with me again."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:38
translate chinese MLR2_NS2_rep_f46b288f:

    # Mom "I just wasted time, sorting out my clothes, until he drifted off to sleep."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:42
translate chinese MLR2_NS2_rep_3cf98474:

    # MC "Ahh, I see. Just one thing - Maybe next time you could tap on my shoulder or whisper my name?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:43
translate chinese MLR2_NS2_rep_335c3e4d:

    # Mom "Aww, where’s the fun in that?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:44
translate chinese MLR2_NS2_rep_d9ebec3f:

    # MC "*Sigh*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:45
translate chinese MLR2_NS2_rep_2d77fa7f:

    # Mom "Now... about that promise I made..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:49
translate chinese MLR2_NS2_rep_1efbec24:

    # Mom "I DID tell you that I would keep my boring husband off your back and make sure no harm ever came to you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:51
translate chinese MLR2_NS2_rep_b180f91a:

    # Mom "I DID tell you that I would keep Bob off your back and make sure no harm ever came to you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:52
translate chinese MLR2_NS2_rep_7e8db8cd:

    # Mom "HOWEVER - I want something in return."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:54
translate chinese MLR2_NS2_rep_695e36bc:

    # MC "S-Sure, Mom. What are you thinking of?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:57
translate chinese MLR2_NS2_rep_515adb9f:

    # MC "S-Sure, Linda. What are you thinking of?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:61
translate chinese MLR2_NS2_rep_d4c6276c:

    # Mom "I want you to pleasure me, like my husband never could."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:62
translate chinese MLR2_NS2_rep_5282eb3d:

    # Mom "You can do whatever you want - but focus on MY pleasure, not yours."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:63
translate chinese MLR2_NS2_rep_4aa1c22b:

    # Mom "Do you understand?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:65
translate chinese MLR2_NS2_rep_ffd35e1f:

    # MC "Yeah, no problem, Mom."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:67
translate chinese MLR2_NS2_rep_7a6223f6:

    # MC "Yeah, no problem."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:68
translate chinese MLR2_NS2_rep_e0d253b6:

    # Mom "Great! Let me just get undressed here."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:73
translate chinese MLR2_NS2_rep_5fceac4c:

    # MC "(Wow! She’s so fucking hot!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:74
translate chinese MLR2_NS2_rep_c0211add:

    # Mom "There we go."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:75
translate chinese MLR2_NS2_rep_438c8961:

    # MC "Umm... are we sneaking into MY room now?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:76
translate chinese MLR2_NS2_rep_12902d33:

    # Mom "Why would we do that?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:78
translate chinese MLR2_NS2_rep_9ed562ed:

    # MC "Because Dad is LITERALLY sleeping, right beside you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:80
translate chinese MLR2_NS2_rep_9fcdd1ee:

    # MC "Bob is LITERALLY sleeping right beside you."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:81
translate chinese MLR2_NS2_rep_88731e23:

    # Dad "*Snooooreeee*"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:82
translate chinese MLR2_NS2_rep_ff6f4cee:

    # Mom "But that’s HALF the fun, Sweetie!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:86
translate chinese MLR2_NS2_rep_569ac33a:

    # Mom "Now, how about you get over here and start playing with my tits, before I end up falling asleep too."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:88
translate chinese MLR2_NS2_rep_a730a18b:

    # MC "(I guess Mom had a little bit of an exhibitionist streak in her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:89
translate chinese MLR2_NS2_rep_5aefc8d6:

    # MC "Sure, Mom!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:91
translate chinese MLR2_NS2_rep_b6af5245:

    # MC "(I guess Linda had a little bit of an exhibitionist streak in her!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:92
translate chinese MLR2_NS2_rep_dec05245:

    # MC "Sure, Linda!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:96
translate chinese MLR2_NS2_rep_2e259b32:

    # MC "*Mwah!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:97
translate chinese MLR2_NS2_rep_6d21a26b:

    # Mom "Oooohhh...."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:99
translate chinese MLR2_NS2_rep_cd7f6e60:

    # MC "*Suck Suck*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:100
translate chinese MLR2_NS2_rep_991a4935:

    # Mom "Ahh..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:104
translate chinese MLR2_NS2_rep_375da4db:

    # Mom "Mmm... harder... yes!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:105
translate chinese MLR2_NS2_rep_d732edc7:

    # MC "*SUCK SUCK!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:107
translate chinese MLR2_NS2_rep_9318227b:

    # Mom "MMMM!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:108
translate chinese MLR2_NS2_rep_daafc5cf:

    # Dad "*Snooorrreeee*"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:112
translate chinese MLR2_NS2_rep_86d0df00:

    # Mom "Eeek...."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:113
translate chinese MLR2_NS2_rep_47833a80:

    # Mom "Ah... Ah... AH..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:114
translate chinese MLR2_NS2_rep_caaf27ab:

    # Mom "Don’t stop. Don’t stop..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:115
translate chinese MLR2_NS2_rep_4d23c013:

    # Mom "Fuck, that’s good."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:119
translate chinese MLR2_NS2_rep_3d1e8d2f:

    # Mom "Phew... Okay... That’s enough."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:123
translate chinese MLR2_NS2_rep_ffe73db8:

    # Mom "Change of plans..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:124
translate chinese MLR2_NS2_rep_718fd13a:

    # Mom "I need you down at my pussy, RIGHT NOW."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:128
translate chinese MLR2_NS2_rep_66fdeac0:

    # Mom "Mmm... here we go. Hurry up!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:129
translate chinese MLR2_NS2_rep_2068f6f0:

    # Mom "I’m so wet right now, I need to feel your tongue inside me!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:131
translate chinese MLR2_NS2_rep_720b90d4:

    # MC "Shush - careful you don’t wake Dad!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:133
translate chinese MLR2_NS2_rep_6eb80dfc:

    # MC "Shush - careful you don’t wake Bob!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:134
translate chinese MLR2_NS2_rep_29bef8d4:

    # Mom "Mmm... Fuck him!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:138
translate chinese MLR2_NS2_rep_8ca5f841:

    # Mom "God, I’m so hot right now. Please, start sucking on my clit. I need to feel, your hot wet mouth, clamped over it NOW!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:139
translate chinese MLR2_NS2_rep_dfc1280c:

    # MC "(Wow, she really can’t hold herself back!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:140
translate chinese MLR2_NS2_rep_49fe76d2:

    # MC "Okay, hold still! Just try to keep your voice down."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:144
translate chinese MLR2_NS2_rep_a95c0769:

    # MC "(Let’s begin by spreading her vulva.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:146
translate chinese MLR2_NS2_rep_4cb1d63d:

    # MC "(There’s her clitoris at the top there. I can either focus on that, or plunge a finger inside and go for her g-spot.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:147
translate chinese MLR2_NS2_rep_102867af:

    # MC "(Let’s start with the g-spot.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:151
translate chinese MLR2_NS2_rep_dc94f028:

    # Mom "Oooh..... Mmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:153
translate chinese MLR2_NS2_rep_a3a635a2:

    # Mom "Yes... Yes, [player_name]. I love you!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:154
translate chinese MLR2_NS2_rep_ffc8e3fb:

    # MC "(Sounds like I made a good choice - She’s really enjoying this!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:155
translate chinese MLR2_NS2_rep_bf0171e8:

    # Mom "Deeper!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:159
translate chinese MLR2_NS2_rep_152a45c2:

    # Mom "OOOHHHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:160
translate chinese MLR2_NS2_rep_62f1feb2:

    # MC "Shush! You’re gonna wake-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:161
translate chinese MLR2_NS2_rep_e4e54e75:

    # Mom "Stir up my slutty little pussy! Ahhh! AHHHH!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:162
translate chinese MLR2_NS2_rep_82f61160:

    # MC "(Damn, she’s so loud right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:166
translate chinese MLR2_NS2_rep_3e78837f:

    # Mom "Oh yeah! Make me cum!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:167
translate chinese MLR2_NS2_rep_19a65732:

    # Dad "(Snore...)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:169
translate chinese MLR2_NS2_rep_f1f4c52e:

    # MC "(Thank God, Dad’s a deep sleeper!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:171
translate chinese MLR2_NS2_rep_331d0b87:

    # MC "(Thank God that my Bob’s a deep sleeper!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:172
translate chinese MLR2_NS2_rep_84dafd3f:

    # Dad "YAWN!"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:176
translate chinese MLR2_NS2_rep_652f8bb3:

    # MC "Oh shit..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:177
translate chinese MLR2_NS2_rep_2cfbe32f:

    # Mom "(Fuck...)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:178
translate chinese MLR2_NS2_rep_7c24069c:

    # Dad "(Snoooree...)"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:179
translate chinese MLR2_NS2_rep_db1fd57c:

    # MC "Phew..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:180
translate chinese MLR2_NS2_rep_39f9cec1:

    # Mom "(I thought he was gonna wake up, there!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:184
translate chinese MLR2_NS2_rep_b9cd5384:

    # Mom "Did I not tell you to use your tongue?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:185
translate chinese MLR2_NS2_rep_4fb80981:

    # MC "Yeah, but-"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:186
translate chinese MLR2_NS2_rep_5c25772b:

    # Mom "Get your face, pressed between my thighs, RIGHT NOW!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:190
translate chinese MLR2_NS2_rep_e18bb05d:

    # Mom "Hurry! I’m so close to cumming!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:192
translate chinese MLR2_NS2_rep_5d690a2e:

    # Mom "I need to feel my son’s tongue writhing and flicking deep inside my pussy!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:193
translate chinese MLR2_NS2_rep_196f7126:

    # MC "(Here we go... Let’s give Mom the best cunnilingus she’s ever had!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:195
translate chinese MLR2_NS2_rep_6e9959fc:

    # Mom " I need to feel your tongue writhing and flicking deep inside my pussy!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:196
translate chinese MLR2_NS2_rep_289843ef:

    # MC "(Here we go... Let’s give Linda the best cunnilingus she’s ever had!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:200
translate chinese MLR2_NS2_rep_08dac948:

    # Mom "Ahh! Yes!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:202
translate chinese MLR2_NS2_rep_1c40ba1b:

    # MC "*Lick! Slurp!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:204
translate chinese MLR2_NS2_rep_67f21d80:

    # Mom "Right there! Don’t stop! Ah!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:208
translate chinese MLR2_NS2_rep_233ff878:

    # MC "*Suck! Lick! Shlurp!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:209
translate chinese MLR2_NS2_rep_174e0fa7:

    # Mom "AHHH! Holy fuck! Ahhh! Mmmm!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:210
translate chinese MLR2_NS2_rep_ffe13ab3:

    # Mom "Oh God! Oh God! Yes! Don’t stop!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:214
translate chinese MLR2_NS2_rep_95b1dc34:

    # Mom "Deeper! Harder!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:215
translate chinese MLR2_NS2_rep_1d3370e0:

    # Dad "*Snoooore...*"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:216
translate chinese MLR2_NS2_rep_40a672d9:

    # MC "(She’s pulling my head in, right now!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:221
translate chinese MLR2_NS2_rep_77346719:

    # Mom "Oh! Oh! Oh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:222
translate chinese MLR2_NS2_rep_d3acac58:

    # MC "(Her breathing has become REALLY quick and rapid! It sounds like she’s on the verge of a climax!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:223
translate chinese MLR2_NS2_rep_867181d8:

    # MC "*Lick! Lick! Lick!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:227
translate chinese MLR2_NS2_rep_d8aea037:

    # Mom "Ohhhhh yeeeeessssss! C-Cuummmmmiiiinnng! Eeeeeekkk!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:228
translate chinese MLR2_NS2_rep_02b4da1b:

    # Mom "Ahhhhhhh! Oooohhhhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:230
translate chinese MLR2_NS2_rep_737c79a9:

    # Mom "(My son’s hot wet tongue is making me cum!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:232
translate chinese MLR2_NS2_rep_0156d288:

    # Mom "([player_name]’s hot wet tongue is making me cum!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:233
translate chinese MLR2_NS2_rep_2767597b:

    # Mom "Hnnnnnngggggg!!! Aaaahhhh!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:237
translate chinese MLR2_NS2_rep_c2e41871:

    # Mom "*Pant...*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:238
translate chinese MLR2_NS2_rep_63eba0ae:

    # Mom "*Gasp...*"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:239
translate chinese MLR2_NS2_rep_73839d03:

    # Dad "*Snooorreeee...*"
    Dad ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:240
translate chinese MLR2_NS2_rep_8008bb1f:

    # MC "*Lick!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:241
translate chinese MLR2_NS2_rep_174e833d:

    # Mom "W-Wait... I’ve already... ahhh... cum!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:242
translate chinese MLR2_NS2_rep_95f1358e:

    # MC "*Lick Lick Lick!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:246
translate chinese MLR2_NS2_rep_66be4b50:

    # Mom "(Oh God! It’s soooo sensitive! Why isn’t he stopping?!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:248
translate chinese MLR2_NS2_rep_4b896cc0:

    # Mom "MMMMMM!!!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:249
translate chinese MLR2_NS2_rep_786ce35e:

    # Mom "(It feels sooooo fucking good!)"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:253
translate chinese MLR2_NS2_rep_382a8db6:

    # Mom "MMMM! MMMMMPPFFFFFF!!!"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:254
translate chinese MLR2_NS2_rep_38656094:

    # MC "*LICK LICK LICK!*"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:259
translate chinese MLR2_NS2_rep_7afb98bb:

    # MC "(I think I made her cum, a second time!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:261
translate chinese MLR2_NS2_rep_17897f52:

    # MC "(Damn, she’s writhing and thrashing all over the bed! I’m surprised Dad hasn’t woken up!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:263
translate chinese MLR2_NS2_rep_25b7e257:

    # MC "(Damn, she’s writhing and thrashing all over the bed! I’m surprised Bob hasn’t woken up!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:268
translate chinese MLR2_NS2_rep_41714ad4:

    # Mom "Holy shit... that was amazing."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:269
translate chinese MLR2_NS2_rep_f8b79541:

    # Mom "Where did you learn to do that?"
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:270
translate chinese MLR2_NS2_rep_a87941d5:

    # MC "Honestly? This is the first time I’ve ever given cunnilingus to a girl."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:274
translate chinese MLR2_NS2_rep_75ec659b:

    # Mom "Mmm... You’re a natural, then."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:275
translate chinese MLR2_NS2_rep_1293240d:

    # MC "Heh! I guess so."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:276
translate chinese MLR2_NS2_rep_3a932b18:

    # Mom "That second one was the best orgasm I have ever had in my life."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:277
translate chinese MLR2_NS2_rep_4541baa7:

    # Mom "I love you."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:281
translate chinese MLR2_NS2_rep_1824127c:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:282
translate chinese MLR2_NS2_rep_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:286
translate chinese MLR2_NS2_rep_c81a085f:

    # MC "(Was I really THAT good at giving oral sex? I never realised!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:287
translate chinese MLR2_NS2_rep_f29f1366:

    # MC "(I’ll have to remember that, in future, for other girls.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:288
translate chinese MLR2_NS2_rep_1824127c_1:

    # Mom "Mmm..."
    Mom ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:290
translate chinese MLR2_NS2_rep_bff17d01:

    # MC "(I hope I get to fuck Mom, someday soon. I can’t wait for that.)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/MLR2_NS2_rep.rpy:292
translate chinese MLR2_NS2_rep_1dc7a71f:

    # MC "(I hope I get to fuck Linda, someday soon. I can’t wait for that.)"
    MC ""

