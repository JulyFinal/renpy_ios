﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:10
translate chinese CR4_MS1_rep_2412b2ba:

    # Caroline "Oh wow! You are really, really hard right now!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:11
translate chinese CR4_MS1_rep_f33ccd6a:

    # MC "Well, that cute outfit you are wearing certainly helped!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:12
translate chinese CR4_MS1_rep_1b9caaf2:

    # Caroline "Well, if I’m the one that’s caused this problem, then it’s MY responsibility to fix it."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:16
translate chinese CR4_MS1_rep_f28d9ef9:

    # Caroline "*Mwah*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:18
translate chinese CR4_MS1_rep_6e3035ee:

    # MC "Mmm... "
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:19
translate chinese CR4_MS1_rep_bf6a0190:

    # MC "(Her lips are so warm and wet!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:23
translate chinese CR4_MS1_rep_4b3fb359:

    # MC "(I honestly can’t think of a better way to start the day!)"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:24
translate chinese CR4_MS1_rep_98a6b6ae:

    # Caroline "(I almost forgot how delicious his cock looks. I could suck on his thick dick all morning!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:28
translate chinese CR4_MS1_rep_052dbed6:

    # Caroline "(Time to blow [player_name]’s mind!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:29
translate chinese CR4_MS1_rep_eec57016:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:31
translate chinese CR4_MS1_rep_4065a836:

    # MC "Ohhh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:35
translate chinese CR4_MS1_rep_2e746551:

    # Caroline "Mmmpfff!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:36
translate chinese CR4_MS1_rep_f43f2205:

    # MC "Uggghh! Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:37
translate chinese CR4_MS1_rep_eec57016_1:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:38
translate chinese CR4_MS1_rep_76cf17b4:

    # Caroline "(Sounds like he’s really enjoying this!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:42
translate chinese CR4_MS1_rep_79e429af:

    # MC "Oh yeah... Mmm! Just like that! Ugh! Don’t stop!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:43
translate chinese CR4_MS1_rep_54d3900c:

    # Caroline "*Suck* *Suck*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:44
translate chinese CR4_MS1_rep_d4844943:

    # MC "Can you go deeper? Ahh..."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:48
translate chinese CR4_MS1_rep_14b8c0c3:

    # Caroline "Mmm hmm!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:49
translate chinese CR4_MS1_rep_a46882ac:

    # MC "Uhh, I guess that means, ‘yes’?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:51
translate chinese CR4_MS1_rep_eec57016_2:

    # Caroline "*Shlurp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:55
translate chinese CR4_MS1_rep_1e7d28ed:

    # Caroline "*SHHLLLURRRRP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:57
translate chinese CR4_MS1_rep_978eca9b:

    # MC "Oh yeah! Mmm! Deeper!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:58
translate chinese CR4_MS1_rep_23c6a712:

    # Caroline "(Maybe I should just let [player_name] take control this time? If he’s not satisfied with my technique, then he can manage it himself!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:62
translate chinese CR4_MS1_rep_9ec8acad:

    # Caroline "Y’know what? You’re in charge now, big guy."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:63
translate chinese CR4_MS1_rep_8e916436:

    # MC "Huh? What do you mean?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:64
translate chinese CR4_MS1_rep_465447ff:

    # Caroline "Just grab my hair and hold my head however you want it. Then thrust your hips and fuck my face."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:65
translate chinese CR4_MS1_rep_dac4a4e5:

    # MC "Seriously?"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:66
translate chinese CR4_MS1_rep_cada94fb:

    # Caroline "That’s what you want, isn’t it? To feel your sensitive cock slide down my tight little throat? You can even talk dirty to me, if that’s what you’re into."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:67
translate chinese CR4_MS1_rep_867edafc:

    # MC "Hell yeah!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:68
translate chinese CR4_MS1_rep_bf5509d8:

    # Caroline "Then what are you waiting for? Man up and-"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:72
translate chinese CR4_MS1_rep_59eefd4b:

    # Caroline "GLLLUMPPFFF!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:73
translate chinese CR4_MS1_rep_6c36f123:

    # MC "Thanks, Caroline! This is gonna be awesome!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:75
translate chinese CR4_MS1_rep_d39f85da:

    # Caroline "(Jesus, [player_name]! Give a girl a warning! Or at least let her finish her sentence!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:79
translate chinese CR4_MS1_rep_5bfc67e3:

    # MC "Ugh! Ahh! Oh fuck!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:80
translate chinese CR4_MS1_rep_806b4ec1:

    # Caroline "MMPFF! GLMPPFF!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:81
translate chinese CR4_MS1_rep_7808d7e8:

    # Caroline "*SHLURP* *SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:83
translate chinese CR4_MS1_rep_8d7796cd:

    # MC "Mmm! Ahhhh! Yes! Ohhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:91
translate chinese CR4_MS1_rep_a9aa2c8e:

    # MC "Fuck, that’s it! Suck on my cock, you fucking slut!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:92
translate chinese CR4_MS1_rep_45164930:

    # Caroline "MPPLFFFF!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:93
translate chinese CR4_MS1_rep_8b69c07f:

    # MC "Ugh! Fuck! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:99
translate chinese CR4_MS1_rep_45164930_1:

    # Caroline "MPPLFFFF!!!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:100
translate chinese CR4_MS1_rep_8b69c07f_1:

    # MC "Ugh! Fuck! Ahh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:109
translate chinese CR4_MS1_blow_con1_rep_9711b6d4:

    # MC "Oh yeah, just like that! Hnnnggg! Suck it, you whore!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:110
translate chinese CR4_MS1_blow_con1_rep_aee4e290:

    # Caroline "(Hearing [player_name] talk so dirty is getting me all wet! Maybe this wasn’t such a good idea to do in the morning! I’m going to have to spend another hour with my dildo before I head out to work!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:119
translate chinese CR4_MS1_blow_con2_rep_e2ca262b:

    # Caroline "*Shlluurrrp*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:123
translate chinese CR4_MS1_blow_con2_rep_2224fedc:

    # MC "Oh shit! I’m cumming! Hnnnggg! Ugh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:124
translate chinese CR4_MS1_blow_con2_rep_e37e4656:

    # Caroline "(Holy crap! I can feel his shaft pulsating on my tongue - he’s about to blow his load in my mouth!)"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:125
translate chinese CR4_MS1_blow_con2_rep_bc91f3ee:

    # Caroline "*SUCK SUCK*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:136
translate chinese CR4_MS1_blow_con2_rep_95ab1a75:

    # MC "Aahhhhh!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:137
translate chinese CR4_MS1_blow_con2_rep_bac0bb42:

    # Caroline "*GULP GULP*"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:138
translate chinese CR4_MS1_blow_con2_rep_50e05bbb:

    # MC "Ohhh... fuck... Mmm! Your mouth is incredible, Caroline."
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:142
translate chinese CR4_MS1_blow_con2_rep_1bae7db2:

    # Caroline "Well, it certainly felt like you enjoyed facefucking me!"
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:143
translate chinese CR4_MS1_blow_con2_rep_09ce4eef:

    # MC "It was the best! *Pant* I’m still catching my breath! Haha!"
    MC ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:144
translate chinese CR4_MS1_blow_con2_rep_ed3808b2:

    # Caroline "I’m glad you liked it. Don’t forget to drop by the shop later on today to discuss our date."
    Caroline ""

# game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:145
translate chinese CR4_MS1_blow_con2_rep_dee3e7a4:

    # MC "Oh yeah, I won’t. I’ll catch up with you in the afternoon."
    MC ""

translate chinese strings:

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:87
    old "Fuck, that’s it! Suck on my cock, you fucking slut!"
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:87
    old "..."
    new ""

    # game/scripts/gui/computer/scenes_gallery/scenes/C/R4/CR4_MS1_rep.rpy:106
    old "Oh yeah, just like that! Hnnnggg! Suck it, you whore!"
    new ""

