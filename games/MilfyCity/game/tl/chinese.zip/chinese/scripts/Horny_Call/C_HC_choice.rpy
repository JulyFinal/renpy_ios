﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Horny_Call/C_HC_choice.rpy:172
translate chinese C_HC_choice_bedf28bd:

    # MC "(That went pretty well!)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:176
translate chinese C_HC_choice_b073015a:

    # MC "(Now I just have to wait for her. Shouldn’t take too long.)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:180
translate chinese C_HC_choice_bca3ac64:

    # "*Knock* *Knock*"
    ""

# game/scripts/Horny_Call/C_HC_choice.rpy:182
translate chinese C_HC_choice_f59f4a1a:

    # MC "(That was quick!)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:186
translate chinese C_HC_choice_b39ef889:

    # MC "*Whistle*"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:188
translate chinese C_HC_choice_4d23b90c:

    # MC "Love the tartan bra, Caroline! You look amazing!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:192
translate chinese C_HC_choice_74259274:

    # Caroline "I’m glad you appreciate it, [player_name]. So, what was it you had planned for us tonight?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:194
translate chinese C_HC_choice_b2b4bcec:

    # MC "What are you down for?"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:198
translate chinese C_HC_choice_09ee29a9:

    # Caroline "Perhaps you want me to use my mouth? Or I could give you an assjob again? You loved that when we were doing photography together, didn’t you?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:200
translate chinese C_HC_choice_a6c50e0e:

    # MC "Hmm..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:223
translate chinese C_CH_sexypose_43e6503e:

    # MC "Let’s try something a bit different tonight, Caroline. I want you to pose for me."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:227
translate chinese C_CH_sexypose_bc42f52a:

    # Caroline "You want me to... pose for you?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:229
translate chinese C_CH_sexypose_136219f1:

    # MC "Yeah, like the way you used to do when we were taking photos in your shop."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:233
translate chinese C_CH_sexypose_9c247139:

    # Caroline "Uhh... Okay? Is this what you’re looking for?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:235
translate chinese C_CH_sexypose_42653e50:

    # MC "Yeah, you’re getting there."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:239
translate chinese C_CH_sexypose_e65dc392:

    # MC "You can do better though. Turn around and show me your ass."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:243
translate chinese C_CH_sexypose_25e2806f:

    # MC "Mmm... Perfect. Bring it a bit closer for me."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:245
translate chinese C_CH_sexypose_1c62dcfa:

    # Caroline "Like this?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:249
translate chinese C_CH_sexypose_c04d513e:

    # MC "Nice. Just hold it there."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:251
translate chinese C_CH_sexypose_abbb8fa7:

    # MC "You’re really fucking hot, Caroline. You know that?"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:255
translate chinese C_CH_sexypose_bc568e8a:

    # MC "*Pant* Hnnng..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:257
translate chinese C_CH_sexypose_94a91736:

    # Caroline "Do you want me to touch you or anything?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:261
translate chinese C_CH_sexypose_a5090d1f:

    # MC "No, just keep ugh... like that."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:265
translate chinese C_CH_sexypose_3e946bbd:

    # Caroline "Are you alright? Why do you keep groaning like-"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:270
translate chinese C_CH_sexypose_1e490079:

    # Caroline "Oh!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:272
translate chinese C_CH_sexypose_06127660:

    # MC "What’s wrong, Caroline?"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:276
translate chinese C_CH_sexypose_1dad0495:

    # Caroline "I just- I wasn’t expecting to see you jerking yourself off!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:278
translate chinese C_CH_sexypose_b1e756ee:

    # MC "Really? What do you think I’ve been longing to do every time you dressed up in those sexy costumes? You know I ALWAYS got a boner."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:282
translate chinese C_CH_sexypose_1057592f:

    # Caroline "You really wanted to masturbate while watching me in those?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:284
translate chinese C_CH_sexypose_b5767ac9:

    # MC "Hell yeah, I did! You’re drop-dead gorgeous!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:286
translate chinese C_CH_sexypose_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:288
translate chinese C_CH_sexypose_39f31b9e:

    # Caroline "Would you like me to pose some more for you?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:292
translate chinese C_CH_sexypose_62b7686c:

    # MC "Fuck yeah!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:294
translate chinese C_CH_sexypose_145da06c:

    # Caroline "How’s this?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:296
translate chinese C_CH_sexypose_78fe96ec:

    # MC " God... you look amazing with your legs spread. Can you do something else for me?"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:300
translate chinese C_CH_sexypose_0712d571:

    # Caroline "Sure! Anything."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:302
translate chinese C_CH_sexypose_df2f5ed4:

    # MC "I want you to moan. Pant and scream like you’re being fucked."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:304
translate chinese C_CH_sexypose_118a8421:

    # Caroline "...ah!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:306
translate chinese C_CH_sexypose_581c951b:

    # MC "C’mon Caroline, you can be louder than that. These walls aren’t THAT thin."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:310
translate chinese C_CH_sexypose_2e9687b3:

    # Caroline "*Gulp* Ah! Ah! Ahhh!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:312
translate chinese C_CH_sexypose_682a4034:

    # MC "Mmm... That’s it."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:314
translate chinese C_CH_sexypose_3e0bb7cf:

    # Caroline "Oh! Mmm! Ah!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:318
translate chinese C_CH_sexypose_74af5bdc:

    # MC "*Pant* Hnnng... Yes!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:320
translate chinese C_CH_sexypose_b279080a:

    # Caroline "Ayahhhh! AHHHH! Cum for me, [player_name]! Cum for me!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:324
translate chinese C_CH_sexypose_6520bc2f:

    # MC "Hnnnggg! I want to finish over your tits!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:326
translate chinese C_CH_sexypose_13b00e9d:

    # Caroline "Oh yeah?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:330
translate chinese C_CH_sexypose_408c8056:

    # Caroline "Go on, do it. Cum all over my tits."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:331
translate chinese C_CH_sexypose_df937636:

    # MC "*Pant* Ohh! Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:335
translate chinese C_CH_sexypose_32d94e19:

    # Caroline "Hurry up and paint my boobs with your cum, [player_name]! Ah! Ahh! Cum for me!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:338
translate chinese C_CH_sexypose_ecb0c521:

    # MC "Hnngng!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:341
translate chinese C_CH_sexypose_fc748fdc:

    # Caroline "Ah! AH!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:345
translate chinese C_CH_sexypose_34fb8388:

    # MC "HNNGG ARRGHHH!!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:347
translate chinese C_CH_sexypose_e52d191e:

    # Caroline "YES! CUM FOR ME!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:348
translate chinese C_CH_sexypose_8cc46aa8:

    # MC "ARRGHHH! Ohhhh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:358
translate chinese C_CH_sexypose_4d274728:

    # MC "*Pant* Oh God... *Pant* Wow..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:359
translate chinese C_CH_sexypose_f3d60ac3:

    # Caroline "Did you enjoy that, [player_name]?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:363
translate chinese C_CH_sexypose_e4a8aa44:

    # MC "It was like a dream come true. I’ve fantasised about that ever since I started taking pictures of you for your shop."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:365
translate chinese C_CH_sexypose_c8709e58:

    # Caroline "I’m glad you enjoyed it. I better get washed up and head to bed."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:367
translate chinese C_CH_sexypose_badd05da:

    # MC "Goodnight, Caroline."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:369
translate chinese C_CH_sexypose_c660810b:

    # Caroline "Goodnight, [player_name]. Sweet dreams."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:376
translate chinese C_CH_ball_32ea1672:

    # MC "Actually, I’m in the mood for something a little different tonight. Take off your bra for me."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:378
translate chinese C_CH_ball_2767ebb4:

    # Caroline "Alright..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:380
translate chinese C_CH_ball_b11d142c:

    # MC "This is something I haven’t tried before, so I’m kinda excited about-"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:386
translate chinese C_CH_ball_32fc2dc0:

    # Caroline "Oh God... Please don’t be something weird. This isn’t some ahegao hentai shit, is it?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:388
translate chinese C_CH_ball_6b35cca6:

    # MC "What? No!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:390
translate chinese C_CH_ball_b9e5f118:

    # Caroline "You’re not going to ask me to pee on you, are you?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:394
translate chinese C_CH_ball_3570d6e8:

    # MC "If you let me finish my sentence, you’d know it isn’t weird!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:396
translate chinese C_CH_ball_48bd3c8d:

    # MC "I just wanted to ask you for oral tonight, but with you sucking my balls instead of my dick."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:400
translate chinese C_CH_ball_8743b633:

    # Caroline "..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:402
translate chinese C_CH_ball_b4db4b5b:

    # Caroline "That’s it?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:406
translate chinese C_CH_ball_7ac2c5e6:

    # MC "That’s all there is to it."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:408
translate chinese C_CH_ball_f02c58ad:

    # Caroline "Huh. That’s not too bad. I was getting worried you’d been lurking on weird websites again."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:412
translate chinese C_CH_ball_1d68df51:

    # MC "That was one time!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:414
translate chinese C_CH_ball_6152b22e:

    # Caroline "What were those tags again? Futa, tentacle, impregnation, vore-"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:418
translate chinese C_CH_ball_affd2228:

    # MC "ALRIGHT! Enough of that! Let’s not relive that."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:420
translate chinese C_CH_ball_b1437ac2:

    # Caroline "Hehe..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:422
translate chinese C_CH_ball_4b9c1e58:

    # Caroline "(I love how easy it is to get him flustered! God, I must have teased him for months about that time he left his laptop unlocked!)"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:426
translate chinese C_CH_ball_951cc58a:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:428
translate chinese C_CH_ball_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:432
translate chinese C_CH_ball_472f5f0e:

    # MC "Ohh... That’s perfect, Caroline. Just like that. *Pant* Ohhh..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:434
translate chinese C_CH_ball_951cc58a_1:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:438
translate chinese C_CH_ball_c1170cce:

    # MC "Ah..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:440
translate chinese C_CH_ball_7d191740:

    # Caroline "*Lick*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:444
translate chinese C_CH_ball_b398beb5:

    # Caroline "(Let’s extend the licking a bit longer before I begin the main event.)"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:446
translate chinese C_CH_ball_951cc58a_2:

    # Caroline "*Lick* *Lick*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:449
translate chinese C_CH_ball_f12ed1c8:

    # MC "*Pant* Mmm... Your tongue is incredible."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:453
translate chinese C_CH_ball_801449e5:

    # Caroline "*Suck* *Shluurrrp*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:455
translate chinese C_CH_ball_c2f08897:

    # MC "Hnnng... Ohh..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:459
translate chinese C_CH_ball_72ae91d7:

    # MC "Mmm... God... Just like that... Ah..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:461
translate chinese C_CH_ball_54d3900c:

    # Caroline "*Suck* *Suck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:465
translate chinese C_CH_ball_8f6e06b1:

    # MC "Hnnng... *Pant*"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:467
translate chinese C_CH_ball_705050d4:

    # Caroline "*Suck* *Shlurp*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:469
translate chinese C_CH_ball_131ce13e:

    # Caroline "(His balls are clenching up! Judging by his moans, he must be REALLY enjoying this!)"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:471
translate chinese C_CH_ball_c8b91082:

    # MC "Ah! I’m about to cum! "
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:475
translate chinese C_CH_ball_878a66c4:

    # MC "Hnnngg! Ohh! Fuck! Mmmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:477
translate chinese C_CH_ball_3b319603:

    # Caroline "Do you want to finish over my tits or my face?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:487
translate chinese C_CH_ball_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:489
translate chinese C_CH_ball_8743b633_1:

    # Caroline "..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:491
translate chinese C_CH_ball_99c247f1:

    # Caroline "I guess both was an option too..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:495
translate chinese C_CH_ball_61c616d1:

    # MC "Heh, sorry... That was a bit more cum than I expected."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:497
translate chinese C_CH_ball_ec914d00:

    # Caroline "I’m just happy you enjoyed it. I need to go and wash up, and you need to get some rest."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:499
translate chinese C_CH_ball_badd05da:

    # MC "Goodnight, Caroline."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:501
translate chinese C_CH_ball_c6bbcfd9:

    # Caroline "Sweet dreams, [player_name]."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:508
translate chinese C_CH_blow_31d63617:

    # MC "I’ll take you up on that offer to suck my cock. You’ve always been the best at giving head."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:512
translate chinese C_CH_blow_b4a79a6d:

    # Caroline "I’m the best at giving head?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:514
translate chinese C_CH_blow_892ea1e7:

    # MC "Oh yeah!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:516
translate chinese C_CH_blow_4fe4cf68:

    # Caroline "(That’s just the compliment every girl wants to hear...)"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:520
translate chinese C_CH_blow_af0b1aa2:

    # Caroline "Well, if you’re going to put it in my mouth, then you’re going to need to get undressed first."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:525
translate chinese C_CH_blow_0c88abea:

    # Caroline "Time to lose those shorts."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:527
translate chinese C_CH_blow_fbbf53dc:

    # MC "Only if you lose that bra."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:531
translate chinese C_CH_blow_d589290b:

    # Caroline "Alright, deal. Now, get your ass over here, so I can suck on that delicious cock of yours."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:535
translate chinese C_CH_blow_e33d5988:

    # MC "(That’s more like it! She seems really enthusiastic about this, tonight!)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:539
translate chinese C_CH_blow_8f950ba4:

    # Caroline "Mmm! You’re nice and hard for me already."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:541
translate chinese C_CH_blow_b93ab111:

    # MC "How could I not be? You’ve got a perfect body."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:545
translate chinese C_CH_blow_00019eda:

    # Caroline "I’m going to drain your balls tonight, [player_name]. I’m talking about caressing, every last inch of your dick with my tongue."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:547
translate chinese C_CH_blow_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:551
translate chinese C_CH_blow_0a2eb983:

    # Caroline "Locking my lips around your shaft, and sucking out every last drop of your cum."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:553
translate chinese C_CH_blow_dea714cb:

    # MC "Oohh..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:555
translate chinese C_CH_blow_79e54e0e:

    # Caroline "*Whispered* You’re not going to be able to stand, by the time I’m finished with you."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:559
translate chinese C_CH_blow_705050d4:

    # Caroline "*Suck* *Shlurp*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:560
translate chinese C_CH_blow_311cbd35:

    # MC "Hnnng! Ohhh God!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:564
translate chinese C_CH_blow_2dbc9652:

    # MC "Ah... Haah...."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:566
translate chinese C_CH_blow_1b044bae:

    # Caroline "*Shlurp* *Suck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:570
translate chinese C_CH_blow_7953d2f7:

    # MC "Ah! Deeper! Mmm! I want to feel you take it deeper! Hnnng!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:573
translate chinese C_CH_blow_908e461b:

    # Caroline "*Shlurp* *Suuuuuck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:577
translate chinese C_CH_blow_353123db:

    # MC "Ah! God! Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:579
translate chinese C_CH_blow_cc05b71f:

    # Caroline "*Suck* *Shlurp* *Suck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:584
translate chinese C_CH_blow_7a8d96d3:

    # Caroline "*Glompf* *Shlurp* *Suck* *Suck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:586
translate chinese C_CH_blow_70eac9f9:

    # MC "*Pant* Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:590
translate chinese C_CH_blow_0342752a:

    # MC "Hnnng... That’s fucking amazing, Caroline."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:592
translate chinese C_CH_blow_ec5750b8:

    # Caroline "*Suck* *Suck* *Suck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:596
translate chinese C_CH_blow_cceb26c0:

    # MC "I’m getting close! *Pant* Hnnng!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:599
translate chinese C_CH_blow_1b044bae_1:

    # Caroline "*Shlurp* *Suck*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:601
translate chinese C_CH_blow_8b8b7ff4:

    # MC "*Pant* Hnnng! Ohh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:605
translate chinese C_CH_blow_7edd244b:

    # MC "Argh! Fuck! I’m gonna cum!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:607
translate chinese C_CH_blow_cc504950:

    # Caroline "*Shlurp* *SUCK* *SUCK* *SHLUUURRRP*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:611
translate chinese C_CH_blow_624c2e47:

    # MC "*Pant* Ahhh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:617
translate chinese C_CH_blow_53433351:

    # MC "Ah! AHH! HNNNGG! Yes! Don’t stop sucking, Caroline!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:619
translate chinese C_CH_blow_3df0ae2a:

    # Caroline "*SHLURP* *SUUUUUCK*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:621
translate chinese C_CH_blow_d31869bf:

    # MC "HNNNGG! OHHHH!!!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:632
translate chinese C_CH_blow_c1d9effc:

    # Caroline "*Gulp* *Gulp* *Suck* *Gulp*"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:634
translate chinese C_CH_blow_9243934f:

    # MC "*Pant* HNnngg! Ohhh! Yess... Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:641
translate chinese C_CH_blow_da498b3a:

    # MC "Argh! I’m gonna cum!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:643
translate chinese C_CH_blow_52f0fdff:

    # Caroline "*Gasp* That’s it! Cum for me! Finish all over my-"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:653
translate chinese C_CH_blow_ca1e64a6:

    # MC "Arrghhh! HNNNGG!!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:655
translate chinese C_CH_blow_03ccdbde:

    # MC "Ohh... God... Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:657
translate chinese C_CH_blow_b3e1d76e:

    # Caroline "...face."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:663
translate chinese C_HC_blow_end_6ac1cb25:

    # MC "*Pant* That was incredible, Caroline. You can do phenomenal things with that mouth!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:665
translate chinese C_HC_blow_end_6644ede5:

    # Caroline "*Gulp* I’m glad you enjoyed it. We better get some sleep now, or we’ll both be exhausted tomorrow!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:667
translate chinese C_HC_blow_end_56241452:

    # MC "Night, Caroline."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:669
translate chinese C_HC_blow_end_687dc46b:

    # Caroline "Sleep tight, [player_name]."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:676
translate chinese C_CH_AssJob_edf64f84:

    # MC "Can I fuck your asscheeks again, the way we did in your shop?"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:681
translate chinese C_CH_AssJob_a8cebfe6:

    # Caroline "Mmm, you want another one of those? Alright. Just an assjob though - no anal tonight."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:685
translate chinese C_CH_AssJob_ed454e42:

    # MC "Alright. Slide your panties off for me and come over here."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:689
translate chinese C_CH_AssJob_c911790c:

    # MC "Nice and slowly, that’s it."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:691
translate chinese C_CH_AssJob_8519b21c:

    # MC "Okay, now lie down on this chair. I’m going to fuck you from behind on it."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:695
translate chinese C_CH_AssJob_76b38463:

    # Caroline "What put you in the mood for an assjob today? Why not a blowjob? Or a footjob?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:697
translate chinese C_CH_AssJob_1d7b4936:

    # MC "Have you seen your ass in the mirror lately? You look phenomenal, Caroline!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:699
translate chinese C_CH_AssJob_b1437ac2:

    # Caroline "Hehe..."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:703
translate chinese C_CH_AssJob_4429fcdc:

    # MC "I honestly can’t make up my mind whether your breasts or your ass are your best part. Every inch of you is sculpted to perfection."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:705
translate chinese C_CH_AssJob_c87f1bd4:

    # Caroline "You’re gonna make me blush, [player_name]."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:709
translate chinese C_CH_AssJob_aae778b1:

    # MC "Seeing you in that tartan bra reminded me of the fun we had in your shop though, and I’m very much looking forward to reliving that feeling."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:713
translate chinese C_CH_AssJob_5b178e6f:

    # MC "You were just so sexy, dressed up in those skimpy little costumes."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:715
translate chinese C_CH_AssJob_6d901d3e:

    # Caroline "I enjoyed it too, [player_name]. "
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:719
translate chinese C_CH_AssJob_15cc13dc:

    # Caroline "Well, I’m ready whenever you are."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:723
translate chinese C_CH_AssJob_e0f42853:

    # MC "(Here we go!)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:727
translate chinese C_CH_AssJob_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:731
translate chinese C_CH_AssJob_fc2fccf2:

    # Caroline "Oh! It’s just an assjob, right? You’re not planning on going inside?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:733
translate chinese C_CH_AssJob_186380d5:

    # MC "I’m just going to fuck your asscheeks."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:737
translate chinese C_CH_AssJob_ef566fee:

    # Caroline "Are you sure? It FEELS like you’re aiming for the inside!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:739
translate chinese C_CH_AssJob_0c9d28e6:

    # MC "(Just a little bit more...)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:743
translate chinese C_CH_AssJob_40eb1ca9:

    # Caroline "You’re getting DANGEROUSLY close to my hole for this to be an assjob!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:745
translate chinese C_CH_AssJob_32aee227:

    # MC "*Ahem*"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:749
translate chinese C_CH_AssJob_ed8e436a:

    # MC "Goodness me, how’d that happen? I must have missed..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:751
translate chinese C_CH_AssJob_519d11fe:

    # Caroline "Ahaha! Uh huh! Sure! I’ve heard that one before!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:755
translate chinese C_CH_AssJob_7a5b69a6:

    # MC "Alright, alright. Just an assjob tonight."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:757
translate chinese C_CH_AssJob_43b8826f_1:

    # MC "Mmm..."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:760
translate chinese C_CH_AssJob_b4528e19:

    # MC "Mmm! Hnngg... *Gasp* Oh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:762
translate chinese C_CH_AssJob_29052c1b:

    # MC "*Pant* Argh! Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:766
translate chinese C_CH_AssJob_21a5522b:

    # MC "(Fuck, her ass feels amazing! Her cheeks are clinging to my shaft as I thrust!)"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:768
translate chinese C_CH_AssJob_9b66e067:

    # Caroline "You’re moaning a lot, there! You must REALLY be enjoying this."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:772
translate chinese C_CH_AssJob_40c33b46:

    # MC "*Pant* MmM! Ugh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:774
translate chinese C_CH_AssJob_24d91e92:

    # Caroline "Are you going to finish soon?"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:778
translate chinese C_CH_AssJob_66b0a3ef:

    # MC "Ah! Arrghhh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:780
translate chinese C_CH_AssJob_4ac3504d:

    # Caroline "Go on, keep thrusting against my ass until you cum."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:784
translate chinese C_CH_AssJob_2076f9ed:

    # MC "*Pant* Oh! Mmm! Ahh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:786
translate chinese C_CH_AssJob_93bb7567:

    # Caroline "I want to feel your hot jizz coat my back, [player_name]!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:790
translate chinese C_CH_AssJob_402ad7da:

    # Caroline "Do it! Cum for me!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:792
translate chinese C_CH_AssJob_a3d0f4e8:

    # MC "Ah! Ah! Mmm! Ugh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:796
translate chinese C_CH_AssJob_a9cdf217:

    # MC "Ohh! Fuck! Mmm!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:798
translate chinese C_CH_AssJob_de7f7b6a:

    # Caroline "Yes! Yes!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:802
translate chinese C_CH_AssJob_92835e0b:

    # MC "Arrghhh! HNNNGGG!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:804
translate chinese C_CH_AssJob_8a6cfe7d:

    # Caroline "That’s it! Cum for me!"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:808
translate chinese C_CH_AssJob_bf750ead:

    # MC "OHHH FUCK! MMMM!!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:818
translate chinese C_CH_AssJob_91a52a27:

    # MC "Ughhh! Ohhh!"
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:820
translate chinese C_CH_AssJob_eb0fe24d:

    # Caroline "(Goodness me! That felt like an awful lot! I can feel it trickling down my sides!)"
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:824
translate chinese C_CH_AssJob_657ae838:

    # MC "*Pant* That was... *Pant* amazing, Caroline. Thank you."
    MC ""

# game/scripts/Horny_Call/C_HC_choice.rpy:826
translate chinese C_CH_AssJob_51381d08:

    # Caroline "I’m happy you liked it. I better go and take a shower now. Night, [player_name]."
    Caroline ""

# game/scripts/Horny_Call/C_HC_choice.rpy:828
translate chinese C_CH_AssJob_03c37c8c:

    # MC "*Pant* Night, Caroline. Thanks for coming over."
    MC ""

translate chinese strings:

    # game/scripts/Horny_Call/C_HC_choice.rpy:613
    old "Send a salty load into Caroline’s mouth."
    new ""

    # game/scripts/Horny_Call/C_HC_choice.rpy:613
    old "Pull out at the last second and coat her face with your semen."
    new ""

