﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Horny_Call/S_HC_choice.rpy:74
translate chinese S_HC_choice_aa71f55e:

    # MC "(Alright! Score! Sara should be here shortly.)"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:78
translate chinese S_HC_choice_f76e2ed1:

    # MC "(I wonder what she’ll be down for doing tonight? Perhaps I can get her to strip for me. Maybe a handjob?)"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:87
translate chinese S_HC_choice_6a0be368:

    # Sara "Hey, [player_name]! I can’t believe we’re doing this!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:89
translate chinese S_HC_choice_4aa815c5:

    # Sara "I feel so naughty sneaking into your room like this."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:93
translate chinese S_HC_choice_567fd215:

    # MC "Hey Sara, you look gorgeous in that nightdress."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:95
translate chinese S_HC_choice_d19805f3:

    # Sara "Hehe, thanks [player_name]!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:99
translate chinese S_HC_choice_0ec15140:

    # Sara "So, what did you want to do?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:101
translate chinese S_HC_choice_a76e5aae:

    # MC "I’ve got a couple of ideas. I was thinking you could either give me a handjob, or just flash your pussy for me."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:105
translate chinese S_HC_choice_94d093a6:

    # Sara "Which would YOU prefer?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:161
translate chinese S_CH_HandJob_f049053d:

    # MC "Y’know what? I’d love to feel your fingers wrapped around my cock tonight."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:163
translate chinese S_CH_HandJob_a21ca5b4:

    # MC "I always loved how soft your hands were."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:167
translate chinese S_CH_HandJob_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:169
translate chinese S_CH_HandJob_6b6c46a9:

    # MC "I’m not joking, your handjobs feel amazing."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:173
translate chinese S_CH_HandJob_6725e70a:

    # MC "C’mon over here and sit down in front of me."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:175
translate chinese S_CH_HandJob_9e004259:

    # Sara "Okay!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:179
translate chinese S_CH_HandJob_714d3a5e:

    # Sara "So, do you want to take your shorts off before I start?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:183
translate chinese S_CH_HandJob_10b84dcd:

    # MC "Nah, just start rubbing it while I still have them on. You can slide them down when you feel ready."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:185
translate chinese S_CH_HandJob_3ec8fa5e:

    # Sara "Okay! "
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:189
translate chinese S_CH_HandJob_a0ec8b77:

    # Sara "(I can see his dick bulging beneath them! Did he get hard from just seeing me in my nightie?)"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:193
translate chinese S_CH_HandJob_0fd3dba3:

    # MC "No need to be shy. Just play with it however you want, Sara."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:197
translate chinese S_CH_HandJob_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:201
translate chinese S_CH_HandJob_a3f137a4:

    # Sara "Hehe! It feels so big!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:203
translate chinese S_CH_HandJob_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:207
translate chinese S_CH_HandJob_ad974064:

    # Sara "Oh! It’s growing bigger!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:209
translate chinese S_CH_HandJob_0536cffc:

    # Sara "(I have to take it out and get a look now!)"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:213
translate chinese S_CH_HandJob_5115818d:

    # Sara "Wow..."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:215
translate chinese S_CH_HandJob_d79c9825:

    # MC "You sound like you’ve never seen it before, Sara! Haha!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:219
translate chinese S_CH_HandJob_118c4c87:

    # Sara "I know, but I still get stunned by its size each time. It looks so..."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:221
translate chinese S_CH_HandJob_7facf295:

    # MC "Hnnng... Oh..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:225
translate chinese S_CH_HandJob_1dc0cf7b:

    # Sara "Hehe! I love the way it twitches when I stroke it!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:227
translate chinese S_CH_HandJob_418b963c:

    # MC "*Pant* Mmm... "
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:231
translate chinese S_CH_HandJob_0c736009:

    # Sara "Wow... it’s so thick..."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:233
translate chinese S_CH_HandJob_fb32e779_1:

    # MC "Ohh..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:235
translate chinese S_CH_HandJob_f08e1af6:

    # MC "Mmmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:239
translate chinese S_CH_HandJob_78a59d67:

    # Sara "You really like it when I do this, don’t you, [player_name]?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:243
translate chinese S_CH_HandJob_fa0bd41e:

    # Sara "Slowly moving my hand up... and down."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:245
translate chinese S_CH_HandJob_b6927d8b:

    # MC "Hnng..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:247
translate chinese S_CH_HandJob_7facf295_1:

    # MC "Hnnng... Oh..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:250
translate chinese S_CH_HandJob_def30e7b:

    # Sara "Up... and... down."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:252
translate chinese S_CH_HandJob_f1b4eb1c:

    # MC "*Pant* Ohh..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:256
translate chinese S_CH_HandJob_1f54d66a:

    # MC "*Pant* Hnnngg! Oh fuck! That feels so good, Sara! Mmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:258
translate chinese S_CH_HandJob_4cbc6032:

    # Sara "I’m gonna go faster now!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:262
translate chinese S_CH_HandJob_f723cc93:

    # MC "Ah! Hnnng! Mmmmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:264
translate chinese S_CH_HandJob_1d4b8598:

    # Sara "*Pant* Are you gonna cum soon, [player_name]?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:266
translate chinese S_CH_HandJob_f08e1af6_1:

    # MC "Mmmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:269
translate chinese S_CH_HandJob_757b4b50:

    # MC "Haahh.... *Pant*"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:271
translate chinese S_CH_HandJob_9a134135:

    # Sara "C’mon! Cum for me!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:275
translate chinese S_CH_HandJob_56d5a58a:

    # MC "Hnnng! Arrghhh! Oh fuck! I’m cumming!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:277
translate chinese S_CH_HandJob_93666f43:

    # Sara "Hehe! That’s it! Cum all over my face!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:281
translate chinese S_CH_HandJob_debfe91f:

    # MC "Arrgghhhh! HNNNGG!!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:292
translate chinese S_CH_HandJob_ea549581:

    # MC "Oohhh... Fuck.... Mmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:294
translate chinese S_CH_HandJob_445a267b:

    # Sara "Oh! Haha! You scared me, there!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:296
translate chinese S_CH_HandJob_efe95f12:

    # MC "*Pant* Thank, Sara. That was amazing."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:300
translate chinese S_CH_HandJob_8b5f17f3:

    # Sara "Call me if you get horny again, okay?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:302
translate chinese S_CH_HandJob_18b8787f:

    # MC "Yeah, *Pant* I will."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:304
translate chinese S_CH_HandJob_15aa7485:

    # Sara "And ONLY me! You better not be bringing any other women back to your room!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:306
translate chinese S_CH_HandJob_d1d2b4e0:

    # MC "Of course not! Just you."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:308
translate chinese S_CH_HandJob_8c854aeb:

    # Sara "Hehe, night [player_name]!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:310
translate chinese S_CH_HandJob_f92b3e7b:

    # MC "Night Sara."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:317
translate chinese S_CH_Pussy_1189713f:

    # MC "Can you lift your nightie for me? I want to see your pussy."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:321
translate chinese S_CH_Pussy_50b07f9f:

    # Sara "You... You don’t want to touch me or anything?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:323
translate chinese S_CH_Pussy_54572fe2:

    # MC "Nope."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:325
translate chinese S_CH_Pussy_5f719ba5:

    # Sara "Or have me give you a blowjob?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:327
translate chinese S_CH_Pussy_b8d8ec55:

    # MC "Nope, just lift your dress."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:331
translate chinese S_CH_Pussy_d870eda2:

    # Sara "Like this?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:333
translate chinese S_CH_Pussy_fe604d0b:

    # MC "Mmm, that’s perfect."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:337
translate chinese S_CH_Pussy_25c1627d:

    # Sara "I don’t get it, [player_name]."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:339
translate chinese S_CH_Pussy_67d88021:

    # MC "You’ve got a stunningly beautiful body, Sara. I just want to admire you for a while."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:343
translate chinese S_CH_Pussy_bdb6eeec:

    # Sara "Hehe, you’re FAR too sweet, [player_name]."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:345
translate chinese S_CH_Pussy_43783d1b:

    # Sara "I can see you’re getting REALLY turned on, just by watching me."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:349
translate chinese S_CH_Pussy_553404ab:

    # MC "How could you tell? Haha!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:351
translate chinese S_CH_Pussy_64bd9212:

    # Sara "Hehe!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:355
translate chinese S_CH_Pussy_a8dbd100:

    # Sara "You like seeing my pussy, then?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:357
translate chinese S_CH_Pussy_47d4af36:

    # MC "Mmm! I love how smooth it looks."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:361
translate chinese S_CH_Pussy_512b3722:

    # Sara "I’ll make sure to keep shaving it every day, then - so you can enjoy it."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:363
translate chinese S_CH_Pussy_00d9141d:

    # MC "*Pant* Mmm..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:367
translate chinese S_CH_Pussy_e38beb2b:

    # MC "Can you turn around so I can see your ass as well?"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:369
translate chinese S_CH_Pussy_90d909d0:

    # Sara "Sure!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:373
translate chinese S_CH_Pussy_8e637806:

    # Sara "How’s this?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:375
translate chinese S_CH_Pussy_ecc4d11b:

    # MC "That’s perfect. Lift your nightie for me again."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:379
translate chinese S_CH_Pussy_b3e12243:

    # MC "Oh yeah... Mmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:383
translate chinese S_CH_Pussy_a3b4584e:

    # MC "*Pant* God, your bubble butt is so cute."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:385
translate chinese S_CH_Pussy_f6755a23:

    # Sara " Hehe! I’m glad you like it!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:389
translate chinese S_CH_Pussy_f820c6f6:

    # Sara "Do you think about me often when you masturbate?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:391
translate chinese S_CH_Pussy_0f5abaa7:

    # MC "Mmm, sometimes when I’m having a bath. I like to imagine you’re sucking my cock."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:395
translate chinese S_CH_Pussy_6f2bce0e:

    # MC "I’ve not done it as often since you and I started having more fun together."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:397
translate chinese S_CH_Pussy_06bbbf5c:

    # Sara "Aww, I’m glad I could be of assistance."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:401
translate chinese S_CH_Pussy_9d0dc9e9:

    # Sara "Oh! Is it better if I do this?!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:403
translate chinese S_CH_Pussy_d3a329bf:

    # MC "Whoa..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:407
translate chinese S_CH_Pussy_d0784d2c:

    # Sara "Now you can see my pussy and ass at the same time!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:409
translate chinese S_CH_Pussy_fbe3ce77:

    # MC "Mmm, you’re so hot, Sara."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:413
translate chinese S_CH_Pussy_f071be0f:

    # MC "*Pant* Hnng..."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:415
translate chinese S_CH_Pussy_039f4863:

    # Sara "Which hole do you like more, [player_name]?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:419
translate chinese S_CH_Pussy_bb58d3b0:

    # MC "Mmm! Your pussy looks great, but I LOVE trying anal with you."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:421
translate chinese S_CH_Pussy_a68d9202:

    # Sara "Hehe, I KNEW you’d say that."
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:425
translate chinese S_CH_Pussy_ff23418f:

    # MC "*Pant* You always look so fucking hot every time we do stuff like this."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:427
translate chinese S_CH_Pussy_9fbaa5e3:

    # Sara "Are you gonna cum soon?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:431
translate chinese S_CH_Pussy_1f1c4dc6:

    # MC "*Pant* Yeah! Hnnng!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:433
translate chinese S_CH_Pussy_b5b6b66b:

    # Sara "Do it! Cum all over my butt!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:437
translate chinese S_CH_Pussy_b03787a2:

    # MC "Ah... Hnnngg! Oh!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:441
translate chinese S_CH_Pussy_6e777147:

    # Sara "That’s it! Cum for me! "
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:443
translate chinese S_CH_Pussy_aae1ea98:

    # MC "Arrghh! Hnnngg!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:447
translate chinese S_CH_Pussy_81a90a3c:

    # Sara "Cover my butt with your cum!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:449
translate chinese S_CH_Pussy_2ff1f26d:

    # MC "Oh! God! Mmm!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:453
translate chinese S_CH_Pussy_ab88aafc:

    # MC "Ah! Arrghhh! Ohhh!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:455
translate chinese S_CH_Pussy_578757d1:

    # Sara "Yes!"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:459
translate chinese S_CH_Pussy_0b032b54:

    # MC "Ohhh fuck! I’m cumming!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:461
translate chinese S_CH_Pussy_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:472
translate chinese S_CH_Pussy_28465585:

    # MC "Ohhh... Hnnngg!"
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:474
translate chinese S_CH_Pussy_ea7f33d0:

    # Sara "(Wow! That’s A LOT! It feels all warm and sticky!)"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:478
translate chinese S_CH_Pussy_7839a8b3:

    # Sara "Did you enjoy that, [player_name]?"
    Sara ""

# game/scripts/Horny_Call/S_HC_choice.rpy:480
translate chinese S_CH_Pussy_83777cc8:

    # MC "*Pant* Yeah! It was amazing, Sara."
    MC ""

# game/scripts/Horny_Call/S_HC_choice.rpy:482
translate chinese S_CH_Pussy_6a59bd8d:

    # Sara "Call me again if you have another HARD problem you need help with."
    Sara ""

