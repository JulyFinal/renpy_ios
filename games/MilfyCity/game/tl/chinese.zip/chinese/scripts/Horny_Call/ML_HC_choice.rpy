﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Horny_Call/ML_HC_choice.rpy:182
translate chinese ML_HC_choice_7d64b3c3:

    # MC "Nice..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:184
translate chinese ML_HC_choice_da9567fd:

    # MC "(I wonder if she’ll be down for letting me fuck her tits tonight?)"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:188
translate chinese ML_HC_choice_4ed5df85:

    # MC "(Or maybe I could convince her to try out anal?)"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:192
translate chinese ML_HC_choice_ea758682:

    # Linda "Evening, [player_name]. This was unexpected."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:196
translate chinese ML_HC_choice_e83ad57e:

    # MC "Oh wow! You look so hot, right now!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:200
translate chinese ML_HC_choice_8b46aa2e:

    # Linda "In this red thing? I didn’t have much time to get ready, so I just threw on an old vest."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:202
translate chinese ML_HC_choice_3b492b1e:

    # MC "An old vest? You look fucking incredible!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:206
translate chinese ML_HC_choice_58d2dc53:

    # Linda "Hehe, I appreciate the compliment, Sweetie."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:210
translate chinese ML_HC_choice_01619ec3:

    # Linda "So, what did you call me over here for?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:227
translate chinese ML_CH_anal_c6c1187f:

    # MC "I just realised that we’ve never really done anal before. Do you fancy giving it a go tonight?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:231
translate chinese ML_CH_anal_d297dd95:

    # Linda "Sure Honey, no prob-"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:235
translate chinese ML_CH_anal_4ccb3b69:

    # Linda "Wait, did you say anal?!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:237
translate chinese ML_CH_anal_9593c42a:

    # MC "Yeah, something wrong?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:241
translate chinese ML_CH_anal_f7d31386:

    # Linda "I’ve... uh... never taken it there before."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:243
translate chinese ML_CH_anal_88d1dc54:

    # MC "No way!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:245
translate chinese ML_CH_anal_d09497f6:

    # Linda "Bob would ask every now and then, but I never let him."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:249
translate chinese ML_CH_anal_99acb58f:

    # MC "It’s cool if you aren’t comfortable doing it, we can always try something else instead."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:253
translate chinese ML_CH_anal_164c4473:

    # Linda "No, no. It’s fine. You just caught me by surprise, is all."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:255
translate chinese ML_CH_anal_62632b50:

    # Linda "I wouldn’t mind giving it a go with you. How exactly do you want to do this?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:257
translate chinese ML_CH_anal_5febd8a5:

    # MC "Pull out that chair and sit in reverse on it. That’ll give me easy access to your ass."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:261
translate chinese ML_CH_anal_bb3b9095:

    # Linda "Like this?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:265
translate chinese ML_CH_anal_e443d035:

    # MC "That’s perfect. Don’t worry, Linda. I’ll take it slow so it doesn’t hurt."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:269
translate chinese ML_CH_anal_f019840d:

    # Linda "This is going to hurt, isn’t it?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:271
translate chinese ML_CH_anal_ccac771c:

    # MC "Not if I take it slowly. It also helps if you’re relaxed."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:275
translate chinese ML_CH_anal_62ba0e75:

    # Linda "*Gulp*"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:277
translate chinese ML_CH_anal_eec75d3a:

    # MC "Let’s just lift this out of the way..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:281
translate chinese ML_CH_anal_44e8d2e6:

    # MC "Honestly, try not to worry, Linda. I think you’re going to enjoy it. And if you don’t, we’ll just stop and try something else instead."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:283
translate chinese ML_CH_anal_c2631cd1:

    # Linda "Okay... Thanks, [player_name]."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:287
translate chinese ML_CH_anal_805792c0:

    # Linda "I never really got mens’ obsession with anal - given that there’s a perfectly good vagina you can fuck next door to it."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:289
translate chinese ML_CH_anal_4acae1d5:

    # MC "Maybe you’ll change your mind when I begin."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:293
translate chinese ML_CH_anal_fa889910:

    # Linda "Ha! I doubt it!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:295
translate chinese ML_CH_anal_72b75bad:

    # MC "Are you ready?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:299
translate chinese ML_CH_anal_291e44ac:

    # Linda "*Gulp* Ready."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:301
translate chinese ML_CH_anal_e6565d90:

    # MC "Try to relax, Linda. I’ll start pushing forward now, okay?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:305
translate chinese ML_CH_anal_98d1303c:

    # Linda "(Oh God, I hope this doesn’t hurt...)"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:309
translate chinese ML_CH_anal_026f2be6:

    # Linda "*GASP*"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:311
translate chinese ML_CH_anal_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:313
translate chinese ML_CH_anal_3b94f721:

    # MC "Are you okay there, Linda?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:317
translate chinese ML_CH_anal_e880220b:

    # Linda "Y-Yeah. Good."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:319
translate chinese ML_CH_anal_1c3437ff:

    # MC "You sure? Do you want me to st-"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:321
translate chinese ML_CH_anal_9fedc461:

    # Linda "Keep going. Just... slowly."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:325
translate chinese ML_CH_anal_fc0651f3:

    # MC "Hnnng! Mmm! You’ve got such a tight ass, Linda! Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:327
translate chinese ML_CH_anal_931c7897:

    # Linda "Ahh...."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:331
translate chinese ML_CH_anal_94682f39:

    # Linda "(Holy shit. Why does this feel good?!)"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:333
translate chinese ML_CH_anal_f76dbbbf:

    # Linda "Ahh... Mmm..."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:337
translate chinese ML_CH_anal_cecc6ac7:

    # MC "Are you alright there, Lin-"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:339
translate chinese ML_CH_anal_d58ff57f:

    # Linda "F-Faster! Ah!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:341
translate chinese ML_CH_anal_bab9562e:

    # MC "Are you sure you-"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:343
translate chinese ML_CH_anal_9712c580:

    # Linda "Fuck my ass!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:347
translate chinese ML_CH_anal_02a2b333:

    # MC "Hnng!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:350
translate chinese ML_CH_anal_9cc7aa84:

    # Linda "Ah! Ahhh! Ohhhh!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:354
translate chinese ML_CH_anal_809a7de2:

    # Linda "Oh God! Yes! Ohh!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:356
translate chinese ML_CH_anal_bc48f6f4:

    # MC "(Well, that exceeded my best expectations for how this was going to go!)"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:358
translate chinese ML_CH_anal_907ea435:

    # MC "Hnng! *Pant* Ohh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:362
translate chinese ML_CH_anal_375f23db:

    # Linda "Ayaaahhhh! Ohhhh! That feels amazing! Haaahhhh!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:364
translate chinese ML_CH_anal_619d1219:

    # Linda "(Why did I never try this sooner?! It feels incredible!)"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:368
translate chinese ML_CH_anal_7b537bc2:

    # Linda "Ah! AH! AHH! *Pant* Oh! God! Mmm!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:370
translate chinese ML_CH_anal_907ea435_1:

    # MC "Hnng! *Pant* Ohh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:372
translate chinese ML_CH_anal_9cc7aa84_1:

    # Linda "Ah! Ahhh! Ohhhh!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:375
translate chinese ML_CH_anal_026f2be6_1:

    # Linda "*GASP*"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:377
translate chinese ML_CH_anal_dde2484f:

    # Linda "Yes! Slam your fat cock deep into my tight ass! Ahh!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:381
translate chinese ML_CH_anal_fcef6dcd:

    # Linda "Ohhhh! Oh God! I’m cumming! *Gasp* I’m cumming!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:383
translate chinese ML_CH_anal_6ab31951:

    # MC "Hnnng! Ugh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:385
translate chinese ML_CH_anal_8be9b4b6:

    # Linda "Ah! Ahhhh! AHHHH!!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:389
translate chinese ML_CH_anal_7eff5099:

    # Linda "Oh my God! I’m cumming from having my ass fucked!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:391
translate chinese ML_CH_anal_fbd57551:

    # MC "Arrghhh! HNNNGG!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:393
translate chinese ML_CH_anal_82c38b80:

    # Linda "Ayyaaaahhhhhh!!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:397
translate chinese ML_CH_anal_16cfe336:

    # Linda "HARDER! OHHH!!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:399
translate chinese ML_CH_anal_890d50aa:

    # MC "Ugh! Ohh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:403
translate chinese ML_CH_anal_68e6a555:

    # Linda "AH! AH! AHHHHH!!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:405
translate chinese ML_CH_anal_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:407
translate chinese ML_CH_anal_3cf250f7:

    # Linda "Cum inside me! Ohh! Fill me up! Plleeeasse!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:411
translate chinese ML_CH_anal_f158c18c:

    # MC "HNNNGG! *Pant* ArrghhH!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:413
translate chinese ML_CH_anal_e5e317f6:

    # Linda "Yesssss! Ayaahhhhh!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:417
translate chinese ML_CH_anal_6c6298d2:

    # MC "Arrghhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:419
translate chinese ML_CH_anal_c351e97b:

    # Linda "Ah! AH! AHHHHHH!!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:426
translate chinese ML_CH_anal_c4edc761:

    # Linda "(It’s so warm! I can feel his semen flooding inside my ass!)"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:428
translate chinese ML_CH_anal_b2b5f826:

    # MC "Oohhh.... *Pant* Fuck..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:438
translate chinese ML_CH_anal_e00e3f4d:

    # MC "*Pant* Oh..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:440
translate chinese ML_CH_anal_bc533a1d:

    # Linda "*Gasp* *Pant* That was... amazing..."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:444
translate chinese ML_CH_anal_a3cf2a40:

    # Linda "Ohhh... "
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:446
translate chinese ML_CH_anal_18b2235d:

    # Linda "(I can feel his hot cum dripping out of me) Mmm..."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:454
translate chinese ML_CH_anal_f0534491:

    # MC "*Pant* Hnnng! Arrghhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:464
translate chinese ML_CH_anal_daa04e52:

    # MC "Ohh! Mmmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:465
translate chinese ML_CH_anal_1377cae5:

    # Linda "(Oh! That’s warm!)"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:472
translate chinese ML_HC_anal_end_4bd10b48:

    # MC "*Pant* That was amazing, Linda. Thank you so much."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:474
translate chinese ML_HC_anal_end_7abe2c81:

    # Linda "I must say... *Pant* ...I enjoyed that A LOT more than I thought I would."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:476
translate chinese ML_HC_anal_end_890481fe:

    # MC "It didn’t hurt?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:478
translate chinese ML_HC_anal_end_05ef51fe:

    # Linda "Only a slight bit at the start, but it became VERY pleasurable after that. I better get back now. It’s getting late."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:482
translate chinese ML_HC_anal_end_3ff1cd19:

    # MC "Night Linda!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:484
translate chinese ML_HC_anal_end_95fdd1cb:

    # Linda "Sweet dreams, Sweetie."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:491
translate chinese ML_CH_foot_4eea79e4:

    # MC "What I really want is for you to rub your feet all over my cock tonight."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:495
translate chinese ML_CH_foot_5462a3fa:

    # Linda "Heh, you have ALWAYS loved my feet, haven’t you?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:499
translate chinese ML_CH_foot_c209e143:

    # Linda "I never quite understood why guys like them so much. They’re not inherently sexual - like my ass or my breasts."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:503
translate chinese ML_CH_foot_609ac043:

    # Linda "And yet, you’re already rock-hard right now, just looking at them."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:507
translate chinese ML_CH_foot_a0be0079:

    # Linda "I can see your dick bulging in your underwear. You can’t wait to slip it out and slide it between my soles, can you?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:509
translate chinese ML_CH_foot_a1547319:

    # MC "You know me too well, Linda. Haha!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:513
translate chinese ML_CH_foot_53effd3a:

    # Linda "Well, go on! Let’s see it. I’m dying to stroke your cock with my feet."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:517
translate chinese ML_CH_foot_7d847dfb:

    # Linda "I love watching you writhe in pleasure, as I curl my toes around your shaft."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:521
translate chinese ML_CH_foot_d52abc6a:

    # MC "Why don’t you try taking my cock out for me?"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:523
translate chinese ML_CH_foot_ffdff9dc:

    # Linda "Alright, if that’s what you want."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:527
translate chinese ML_CH_foot_43b8826f:

    # MC "Mmm..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:529
translate chinese ML_CH_foot_15c659e5:

    # Linda "My, my... You’re so hard, right now."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:533
translate chinese ML_CH_foot_3ce08d65:

    # Linda "Are you enjoying me rubbing my sole, all over your cock?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:535
translate chinese ML_CH_foot_d4926199:

    # MC "*Pant*"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:539
translate chinese ML_CH_foot_5de87885:

    # Linda "Of course you are. Let’s see if I can use my toes to pull the elastic on your underwear down."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:543
translate chinese ML_CH_foot_e2f01682:

    # Linda "Ta da! Hehe!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:545
translate chinese ML_CH_foot_81317e96:

    # MC "Ohh... *Gasp*"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:549
translate chinese ML_CH_foot_122ba7e2:

    # MC "*Gasp* Mmm! God... I love your feet, Linda..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:551
translate chinese ML_CH_foot_4e628f00:

    # Linda "That’s it. Moan for me, [player_name]."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:555
translate chinese ML_CH_foot_a76cd6ed:

    # MC "Ah! Mmmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:557
translate chinese ML_CH_foot_2978d212:

    # Linda "Oh, it feels much better when I use both of them, doesn’t it?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:561
translate chinese ML_CH_foot_4d3b794c:

    # Linda "(I love watching his reactions to this. It’s so cute seeing him squirm, and moan in pleasure, when I do this.)"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:563
translate chinese ML_CH_foot_965b2106:

    # MC "Ah... Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:567
translate chinese ML_CH_foot_532c0b9b:

    # MC "*Pant* Oh! God! *Gasp* Ohh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:569
translate chinese ML_CH_foot_d6cac7aa:

    # Linda "Are you getting close to cumming?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:573
translate chinese ML_CH_foot_6c8bad38:

    # Linda "I want you to finish, all over my feet."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:575
translate chinese ML_CH_foot_d174ea9d:

    # MC "Hnnng..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:579
translate chinese ML_CH_foot_42be8306:

    # Linda "Go on, cum all over your landlady's toes."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:581
translate chinese ML_CH_foot_48d83c84:

    # MC "Argghh! *Pant* Ohhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:585
translate chinese ML_CH_foot_10899030:

    # MC "Hnnnggg!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:587
translate chinese ML_CH_foot_df48c0a4:

    # Linda "Focus on the feeling of my soft soles, sliding down your shaft."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:589
translate chinese ML_CH_foot_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:593
translate chinese ML_CH_foot_34df0481:

    # MC "*Pant* Oh God! Linda! Hnng! Ohhh! Fuck!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:595
translate chinese ML_CH_foot_8acba202:

    # Linda "That’s it. Be a good boy, and moan for me."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:599
translate chinese ML_CH_foot_6221cf15:

    # MC "Arrghhh! Oh God! Yes! Mmmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:601
translate chinese ML_CH_foot_549c785a:

    # MC "Ah! AHHH!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:605
translate chinese ML_CH_foot_b5503821:

    # Linda "Good boy. Finish all over my feet."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:607
translate chinese ML_CH_foot_8f66351f:

    # MC "Arrghhh! HNNGG!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:611
translate chinese ML_CH_foot_96d5e0f6:

    # MC "OH FUCK! *GASP* Ohhh! YES! HNNNGGG!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:613
translate chinese ML_CH_foot_eef80245:

    # MC "Arrghh! Linda! Ohhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:623
translate chinese ML_CH_foot_af37c7e1:

    # MC "Ohhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:625
translate chinese ML_CH_foot_30e5f8c6:

    # MC "*Pant* Ah..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:629
translate chinese ML_CH_foot_6c8dfd25:

    # Linda "Mmm, that’s it. Empty your balls all over my feet. Get your sticky cum all over my toes."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:631
translate chinese ML_CH_foot_e3cb0636:

    # MC "*Pant* Ohh... Linda... Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:635
translate chinese ML_CH_foot_234a8b11:

    # Linda "It seems like you enjoyed that, Sweetie."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:637
translate chinese ML_CH_foot_058a5ed0:

    # MC "It was *Pant* unbelievable, Linda."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:639
translate chinese ML_CH_foot_9ba5009a:

    # Linda "Hehe! We both better get some sleep, now. Sweet dreams."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:641
translate chinese ML_CH_foot_af2c6f69:

    # MC "*Pant* Night, Linda. Thanks for that."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:659
translate chinese ML_CH_tits_20005e82:

    # MC "I want to fuck your tits tonight, Linda."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:663
translate chinese ML_CH_tits_51f5134e:

    # Linda "I can see you’re already rock hard."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:667
translate chinese ML_CH_tits_0753392e:

    # Linda "You can’t wait to feel my soft breasts wrapped around your cock, can you?"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:669
translate chinese ML_CH_tits_5c20e6b1:

    # MC "(God, she’s so fucking hot...)"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:673
translate chinese ML_CH_tits_be4bf061:

    # Linda "Well, I won’t be able to do much with that vest in the way."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:677
translate chinese ML_CH_tits_474cc5a3:

    # Linda "There we go! Much better."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:679
translate chinese ML_CH_tits_fb32e779:

    # MC "Ohh..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:683
translate chinese ML_CH_tits_a7d1081f:

    # MC "Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:685
translate chinese ML_CH_tits_da86e826:

    # MC "(She’s a walking Sex Goddess! I can’t believe how lucky I am, to have her willing to do this for me!)"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:689
translate chinese ML_CH_tits_fb32e779_1:

    # MC "Ohh..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:691
translate chinese ML_CH_tits_2338be2f:

    # Linda "Good boy. Moan for me while I massage your cock between my tits."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:695
translate chinese ML_CH_tits_30e5f8c6:

    # MC "*Pant* Ah..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:697
translate chinese ML_CH_tits_5685aa66:

    # Linda "Mmm! I love feeling you squirm."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:699
translate chinese ML_CH_tits_a7d1081f_1:

    # MC "Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:702
translate chinese ML_CH_tits_9ccd335d:

    # MC "Hnng! Ugh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:704
translate chinese ML_CH_tits_eb8ebf4f:

    # Linda "Hehe! Your cock is throbbing, right now. It must feel soooo good to have my big breasts rubbing up against your thick shaft."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:708
translate chinese ML_CH_tits_be438bda:

    # MC "Ah... You’re so hot, Linda."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:710
translate chinese ML_CH_tits_0fa28d00:

    # Linda "I want to hear you moan for me as you thrust your cock between my titties."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:715
translate chinese ML_CH_tits_c743926a:

    # MC "Mmm! Ah... *Gasp*"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:717
translate chinese ML_CH_tits_2a3ef5be:

    # Linda "That’s it. Again!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:721
translate chinese ML_CH_tits_b4eadead:

    # MC "Argh! Hnnngg!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:723
translate chinese ML_CH_tits_8263803f:

    # Linda "Again!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:725
translate chinese ML_CH_tits_9a554c15:

    # MC "Ohh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:729
translate chinese ML_CH_tits_05caa1d2:

    # Linda "Keep fucking my boobs, [player_name]!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:731
translate chinese ML_CH_tits_c1567567:

    # MC "Ah! Ahh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:735
translate chinese ML_CH_tits_5efb4d91:

    # MC "*Pant* Oh God! Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:737
translate chinese ML_CH_tits_1e6acb3e:

    # Linda "Don’t stop thrusting till you cum!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:741
translate chinese ML_CH_tits_ab873996:

    # MC "Ah! Ahh! Mmmm! Hnnngg!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:743
translate chinese ML_CH_tits_e78869e0:

    # Linda "That’s it, Sweetie! Keep fucking my tits."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:747
translate chinese ML_CH_tits_6bc0e4fa:

    # MC "*Pant* *Gasp* Oh! Hnng! MMM!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:749
translate chinese ML_CH_tits_2782d264:

    # MC "Ah!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:753
translate chinese ML_CH_tits_b42ae840:

    # Linda "Go on. Cum for me, [player_name]. Blow your hot load all over my boobs."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:755
translate chinese ML_CH_tits_102add15:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:759
translate chinese ML_CH_tits_5efb4d91_1:

    # MC "*Pant* Oh God! Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:761
translate chinese ML_CH_tits_85f3cf98:

    # Linda "Yes! Cum for me!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:765
translate chinese ML_CH_tits_66b0a3ef:

    # MC "Ah! Arrghhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:767
translate chinese ML_CH_tits_102add15_1:

    # MC "Hnnngg!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:771
translate chinese ML_CH_tits_4ad8a400:

    # MC "Oh God! Fuck! Mmm!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:773
translate chinese ML_CH_tits_14a587aa:

    # MC "Ah! Arrghh! I’m cumming!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:784
translate chinese ML_CH_tits_a1e51cbd:

    # MC "Hnngg! Ugh! Ohhh!"
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:786
translate chinese ML_CH_tits_76765e92:

    # Linda "That’s it! Mmmm!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:788
translate chinese ML_CH_tits_383816c5:

    # MC "Arrghhh! *Pant* Ohhh..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:792
translate chinese ML_CH_tits_1b83fcf0:

    # MC "*Pant* Oh God... That was amazing..."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:794
translate chinese ML_CH_tits_b67fb805:

    # Linda "You look exhausted. Haha!"
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:796
translate chinese ML_CH_tits_e4d239b3:

    # MC "Heh... I’m wrecked."
    MC ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:798
translate chinese ML_CH_tits_2678a53b:

    # Linda "Try and get some sleep. I’ll see you tomorrow, [player_name]."
    Linda ""

# game/scripts/Horny_Call/ML_HC_choice.rpy:800
translate chinese ML_CH_tits_39313620:

    # MC "*Yawn* Goodnight, Linda."
    MC ""

translate chinese strings:

    # game/scripts/Horny_Call/ML_HC_choice.rpy:421
    old "Cum deep inside Linda’s ass."
    new ""

