﻿# TODO: Translation updated at 2023-11-20 15:50

# game/scripts/Horny_Call/Horny_Call.rpy:44
translate chinese C_hc_found_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:46
translate chinese C_hc_found_56d48da3:

    # MC "(What’s this thing?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:50
translate chinese C_hc_found_fe2ec446:

    # MC "(Did Caroline leave this here for me?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:54
translate chinese C_hc_found_c0ede3b8:

    # MC "Caroline... New horny call unlocked?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:56
translate chinese C_hc_found_1ea16529:

    # MC "(These greeting cards get weirder every year.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:81
translate chinese S_hc_found_97d3bb2e:

    # MC "(What the heck is that thing?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:86
translate chinese S_hc_found_164d635b:

    # MC "(Sara... New horny call... unlocked?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:90
translate chinese S_hc_found_d019f733:

    # MC "Hughhh!"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:93
translate chinese S_hc_found_f6ffdec8:

    # MC "(Weird... Who left something like this lying around campus? Anyone could have gotten it!)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:119
translate chinese ML_hc_found_e79ed82a:

    # MC "Huh?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:121
translate chinese ML_hc_found_314f4c62:

    # MC "(Is that a card pinned to the bulletin board?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:125
translate chinese ML_hc_found_22a753c4:

    # MC "Linda... New horny call unlocked?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:127
translate chinese ML_hc_found_05cdd82c:

    # MC "Heh... "
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:131
translate chinese ML_hc_found_3a5e4b37:

    # MC "(She must have left this here for me to find.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:135
translate chinese ML_hc_found_6e98d540:

    # MC "(Alright, let’s give this thing a whirl tonight!)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:155
translate chinese HC_day_some_inroom_83fb482d:

    # MC "(It's better not to call when someone is in my room...)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:165
translate chinese HC_day_check_368e1dbf:

    # MC "(I've already called for someone today.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:179
translate chinese HC_day_check_77a20deb:

    # MC "(Now, calling doesn't seem sensible, it's better to do it at night when everyone will be at home.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:211
translate chinese HC_menu_50ae85b3:

    # MC "(Okay, let’s give Linda a ring and see if she’s down for a horny call!)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:216
translate chinese HC_menu_5fd7eb03:

    # "*Ring Ring*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:218
translate chinese HC_menu_5fd7eb03_1:

    # "*Ring Ring*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:223
translate chinese HC_menu_7cde3bb3:

    # Dad "*Snore* Zzz...."
    Dad ""

# game/scripts/Horny_Call/Horny_Call.rpy:225
translate chinese HC_menu_f51d0231:

    # Linda "(Crap! I really want to answer him... Bob’s sleeping right there though... *Gulp* I shouldn’t...)"
    Linda ""

# game/scripts/Horny_Call/Horny_Call.rpy:229
translate chinese HC_menu_afd595f6:

    # MC "(Huh... Guess she must be asleep.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:235
translate chinese HC_menu_b55858a0:

    # MC "Hey, are you still up?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:237
translate chinese HC_menu_b4452d6a:

    # Linda "Yeah? What is it, Sweetie?"
    Linda ""

# game/scripts/Horny_Call/Horny_Call.rpy:239
translate chinese HC_menu_667ee6bc:

    # MC "Do you want to sneak over to my room for some fun?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:243
translate chinese HC_menu_e6fab38b:

    # Linda "*Whispered* Alright, just give me a few minutes to prepare myself."
    Linda ""

# game/scripts/Horny_Call/Horny_Call.rpy:245
translate chinese HC_menu_21753486:

    # MC "I’ll be waiting right here for you."
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:251
translate chinese HC_menu_1dfc4f7b:

    # MC "Hey Linda, are you free to come over tonight?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:255
translate chinese HC_menu_c9cb3558:

    # Linda "Absolutely. I was beginning to wonder when you’d get around to calling me."
    Linda ""

# game/scripts/Horny_Call/Horny_Call.rpy:257
translate chinese HC_menu_42a4b5e0:

    # MC "Great, I’m really looking forward to seeing you!"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:259
translate chinese HC_menu_f54ca45c:

    # Linda "Mmm, me too! Just give me a few minutes to slip into something sexy."
    Linda ""

# game/scripts/Horny_Call/Horny_Call.rpy:276
translate chinese HC_menu_ada30b27:

    # MC "(Alright... Let’s try calling Caroline and see if she’s up for one of these horny calls!)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:277
translate chinese HC_menu_4c662835:

    # MC "(I know she ended the deal, but she might still be feeling a little horny, right?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:281
translate chinese HC_menu_ada30b27_1:

    # MC "(Alright... Let’s try calling Caroline and see if she’s up for one of these horny calls!)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:285
translate chinese HC_menu_5fd7eb03_2:

    # "*Ring Ring*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:287
translate chinese HC_menu_5fd7eb03_3:

    # "*Ring Ring*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:292
translate chinese HC_menu_d335745f:

    # Caroline "...what the fuck is he calling me at this time for?"
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:296
translate chinese HC_menu_f3fc0c4d:

    # MC "(Huh, guess she must be asleep.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:304
translate chinese HC_menu_db1c7039:

    # Caroline "Ugh... What part of “the deal is off” does he not understand?!"
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:306
translate chinese HC_menu_b8a7705e:

    # "*Beep*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:309
translate chinese HC_menu_46a73d2a:

    # MC "(Hmm... Perhaps not. Maybe I should work on getting that deal with Caroline restarted before I try this again.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:318
translate chinese HC_menu_48253072:

    # Caroline "*Yawn* Hello?"
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:320
translate chinese HC_menu_bbfb0db6:

    # MC "Hey Caroline, are you still awake?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:322
translate chinese HC_menu_da7c0482:

    # Caroline "Yeah... barely. What’s up?"
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:326
translate chinese HC_menu_bffc6522:

    # MC "Fancy dropping by my room for some fun?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:328
translate chinese HC_menu_3e6cf17b:

    # Caroline "You literally live next door to me. Would it not have been easier to just get up and knock?"
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:330
translate chinese HC_menu_45b7e201:

    # MC "So... is that a “no” on you coming over?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:332
translate chinese HC_menu_ced63502:

    # Caroline "*Sigh* I’ll be there in a couple of minutes."
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:334
translate chinese HC_menu_0bbe7d26:

    # MC "Can you wear something that I haven’t seen before?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:336
translate chinese HC_menu_b8a7705e_1:

    # "*Beep*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:344
translate chinese HC_menu_1e1c969f:

    # MC "Hey there Caroline, fancy coming over for some fun?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:348
translate chinese HC_menu_9f1f43b1:

    # Caroline "Mmm, absolutely! I’ll be there shortly. Don’t start having fun without me!"
    Caroline ""

# game/scripts/Horny_Call/Horny_Call.rpy:350
translate chinese HC_menu_fa55f09b:

    # MC "Awesome! Looking forward to it!"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:365
translate chinese HC_menu_941bfb48:

    # MC "(I know Sara seemed quite pissed about Lily, but maybe she'd be up for coming over to have some fun?)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:368
translate chinese HC_menu_9c02e936:

    # MC "(Alright... Let’s see if Sara is in the mood for a horny call!)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:372
translate chinese HC_menu_5fd7eb03_4:

    # "*Ring Ring*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:374
translate chinese HC_menu_5fd7eb03_5:

    # "*Ring Ring*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:379
translate chinese HC_menu_884312ad:

    # Sara "Arrghh! Go away! Go away!"
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:381
translate chinese HC_menu_b8a7705e_2:

    # "*Beep*"
    ""

# game/scripts/Horny_Call/Horny_Call.rpy:382
translate chinese HC_menu_3932cf43:

    # Sara "Stupid [player_name]! Stupid Lily! I hate you all!"
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:385
translate chinese HC_menu_f740a642:

    # MC "(Hmm... No answer... I guess I need to sort out that situation with Lily first.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:392
translate chinese HC_menu_479b5c83:

    # Sara "...ugh... (It’s the middle of the night! I’ll talk with him tomorrow.)"
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:396
translate chinese HC_menu_f52af181:

    # MC "(Hmm... Perhaps not. Maybe I should try getting to know her a bit better first.)"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:402
translate chinese HC_menu_8cb072b1:

    # Sara "Hmm? What is it, [player_name]?"
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:404
translate chinese HC_menu_17a3584d:

    # MC "Hey Sara, are you awake?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:406
translate chinese HC_menu_b371782a:

    # Sara "Obviously. I’m talking to you on the phone right now, aren’t I?"
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:410
translate chinese HC_menu_8f595765:

    # MC "Would you like to sneak over to my room and hang out?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:412
translate chinese HC_menu_71acc09c:

    # Sara "*Sigh* It’s pretty late..."
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:414
translate chinese HC_menu_3364fcb5:

    # MC "Aw, c’mon! It’ll be fun!"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:416
translate chinese HC_menu_8b8322e7:

    # Sara "Alright. Just give me a couple of minutes."
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:423
translate chinese HC_menu_d6d49e9c:

    # MC "Hey Sara, do you wanna come over tonight?"
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:427
translate chinese HC_menu_f042f1f0:

    # Sara "Really?! When?"
    Sara ""

# game/scripts/Horny_Call/Horny_Call.rpy:429
translate chinese HC_menu_8c6d0580:

    # MC "Yeah! Right now! Everyone else is asleep."
    MC ""

# game/scripts/Horny_Call/Horny_Call.rpy:431
translate chinese HC_menu_377e97a3:

    # Sara "Okay! Just give me a minute to get ready! I’m on my way!"
    Sara ""

translate chinese strings:

    # game/scripts/Horny_Call/Horny_Call.rpy:189
    old "[Mom_name] (disabled)"
    new ""

    # game/scripts/Horny_Call/Horny_Call.rpy:189
    old "Caroline (disabled)"
    new ""

    # game/scripts/Horny_Call/Horny_Call.rpy:189
    old "Sara (disabled)"
    new ""

    # game/scripts/Horny_Call/Horny_Call.rpy:189
    old "[Mom_name]"
    new ""

    # game/scripts/Horny_Call/Horny_Call.rpy:189
    old "Caroline"
    new ""

    # game/scripts/Horny_Call/Horny_Call.rpy:189
    old "Sara"
    new ""

