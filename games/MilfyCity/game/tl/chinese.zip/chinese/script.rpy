﻿# TODO: Translation updated at 2023-11-20 15:50

translate chinese strings:

    # game/script.rpy:812
    old "{image=images/NS_B/New1.png} {color=#00ff00}Meet up with Caroline{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/script.rpy:812
    old "Take a nap"
    new ""

    # game/script.rpy:812
    old "Sleep until next day"
    new ""

    # game/script.rpy:812
    old "Weekend Events"
    new ""

    # game/script.rpy:812
    old "{image=images/NS_B/New1.png} {color=#00ff00}Weekend Events{/color} {image=images/NS_B/New1.png}"
    new ""

    # game/script.rpy:812
    old "Skip weekend"
    new ""

    # game/script.rpy:812
    old "Back"
    new ""

