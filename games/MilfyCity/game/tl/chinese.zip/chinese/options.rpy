﻿# TODO: Translation updated at 2023-11-20 15:50

translate chinese strings:

    # game/options.rpy:15
    old "Milfy City"
    new ""

