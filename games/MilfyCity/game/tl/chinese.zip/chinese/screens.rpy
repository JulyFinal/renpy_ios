﻿# TODO: Translation updated at 2023-11-20 15:50

translate chinese strings:

    # game/screens.rpy:105
    old "Changelog"
    new ""

    # game/screens.rpy:139
    old "Return"
    new ""

    # game/screens.rpy:324
    old "History"
    new ""

    # game/screens.rpy:325
    old "Skip"
    new ""

    # game/screens.rpy:326
    old "Auto"
    new ""

    # game/screens.rpy:327
    old "Save"
    new ""

    # game/screens.rpy:328
    old "Q.Save"
    new ""

    # game/screens.rpy:329
    old "Q.Load"
    new ""

    # game/screens.rpy:330
    old "Prefs"
    new ""

    # game/screens.rpy:374
    old "Start"
    new ""

    # game/screens.rpy:383
    old "Load"
    new ""

    # game/screens.rpy:385
    old "Preferences"
    new ""

    # game/screens.rpy:390
    old "End Replay"
    new ""

    # game/screens.rpy:394
    old "Main Menu"
    new ""

    # game/screens.rpy:396
    old "Credits"
    new ""

    # game/screens.rpy:402
    old "Quit"
    new ""

    # game/screens.rpy:741
    old "Save  "
    new ""

    # game/screens.rpy:749
    old "Load  "
    new ""

    # game/screens.rpy:754
    old "Page {}"
    new ""

    # game/screens.rpy:754
    old "Automatic saves"
    new ""

    # game/screens.rpy:754
    old "Quick saves"
    new ""

    # game/screens.rpy:797
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new ""

    # game/screens.rpy:797
    old "empty slot"
    new ""

    # game/screens.rpy:814
    old "<"
    new ""

    # game/screens.rpy:817
    old "{#auto_page}A"
    new ""

    # game/screens.rpy:820
    old "{#quick_page}Q"
    new ""

    # game/screens.rpy:826
    old ">"
    new ""

    # game/screens.rpy:884
    old "Display"
    new ""

    # game/screens.rpy:885
    old "Window"
    new ""

    # game/screens.rpy:886
    old "Fullscreen"
    new ""

    # game/screens.rpy:890
    old "Rollback Side"
    new ""

    # game/screens.rpy:891
    old "Disable"
    new ""

    # game/screens.rpy:892
    old "Left"
    new ""

    # game/screens.rpy:893
    old "Right"
    new ""

    # game/screens.rpy:898
    old "Unseen Text"
    new ""

    # game/screens.rpy:899
    old "After Choices"
    new ""

    # game/screens.rpy:900
    old "Transitions"
    new ""

    # game/screens.rpy:904
    old "Skip Minigames"
    new ""

    # game/screens.rpy:922
    old "Text Speed"
    new ""

    # game/screens.rpy:926
    old "Auto-Forward Time"
    new ""

    # game/screens.rpy:933
    old "Music Volume"
    new ""

    # game/screens.rpy:940
    old "Sound Volume"
    new ""

    # game/screens.rpy:946
    old "Test"
    new ""

    # game/screens.rpy:954
    old "Mute All"
    new ""

    # game/screens.rpy:1074
    old "The dialogue history is empty."
    new ""

    # game/screens.rpy:1138
    old "Help"
    new ""

    # game/screens.rpy:1147
    old "Keyboard"
    new ""

    # game/screens.rpy:1148
    old "Mouse"
    new ""

    # game/screens.rpy:1151
    old "Gamepad"
    new ""

    # game/screens.rpy:1164
    old "Enter"
    new ""

    # game/screens.rpy:1165
    old "Advances dialogue and activates the interface."
    new ""

    # game/screens.rpy:1168
    old "Space"
    new ""

    # game/screens.rpy:1169
    old "Advances dialogue without selecting choices."
    new ""

    # game/screens.rpy:1172
    old "Arrow Keys"
    new ""

    # game/screens.rpy:1173
    old "Navigate the interface."
    new ""

    # game/screens.rpy:1176
    old "Escape"
    new ""

    # game/screens.rpy:1177
    old "Accesses the game menu."
    new ""

    # game/screens.rpy:1180
    old "Ctrl"
    new ""

    # game/screens.rpy:1181
    old "Skips dialogue while held down."
    new ""

    # game/screens.rpy:1184
    old "Tab"
    new ""

    # game/screens.rpy:1185
    old "Toggles dialogue skipping."
    new ""

    # game/screens.rpy:1188
    old "Page Up"
    new ""

    # game/screens.rpy:1189
    old "Rolls back to earlier dialogue."
    new ""

    # game/screens.rpy:1192
    old "Page Down"
    new ""

    # game/screens.rpy:1193
    old "Rolls forward to later dialogue."
    new ""

    # game/screens.rpy:1197
    old "Hides the user interface."
    new ""

    # game/screens.rpy:1201
    old "Takes a screenshot."
    new ""

    # game/screens.rpy:1205
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new ""

    # game/screens.rpy:1211
    old "Left Click"
    new ""

    # game/screens.rpy:1215
    old "Middle Click"
    new ""

    # game/screens.rpy:1219
    old "Right Click"
    new ""

    # game/screens.rpy:1223
    old "Mouse Wheel Up\nClick Rollback Side"
    new ""

    # game/screens.rpy:1227
    old "Mouse Wheel Down"
    new ""

    # game/screens.rpy:1234
    old "Right Trigger\nA/Bottom Button"
    new ""

    # game/screens.rpy:1238
    old "Left Trigger\nLeft Shoulder"
    new ""

    # game/screens.rpy:1242
    old "Right Shoulder"
    new ""

    # game/screens.rpy:1247
    old "D-Pad, Sticks"
    new ""

    # game/screens.rpy:1251
    old "Start, Guide"
    new ""

    # game/screens.rpy:1255
    old "Y/Top Button"
    new ""

    # game/screens.rpy:1258
    old "Calibrate"
    new ""

    # game/screens.rpy:1323
    old "Yes"
    new ""

    # game/screens.rpy:1324
    old "No"
    new ""

    # game/screens.rpy:1370
    old "Skipping"
    new ""

    # game/screens.rpy:1592
    old "Menu"
    new ""

